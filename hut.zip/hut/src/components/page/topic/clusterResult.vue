<template>
  <div class="conpalinDiv edealFind" id="xyaudioMore">
    <div style="border-bottom: 1px solid #E0E6ED;">
      <div
        @click="getbackNow"
        style="display: inline-block;padding: 20px;cursor: pointer;color: #20A0FF;"
      >
        &lt; 任务列表
      </div>
      <div style="display: inline-block;float: right;padding: 10px;">
        <form :action="importUrl" method="get" style="display: inline">
          <el-button style="margin-left: 19px;padding:0;">
            <a
              :href="eUrl"
              download="w3logo"
              style="color: #606266;padding:12px 20px;display: inline-block;"
            >
              导出
            </a>
          </el-button>
        </form>
      </div>
    </div>
    <div
      style="padding-bottom:60px;box-sizing:border-box;height:100%;display: inline-block;width: 30%;border-right: 1px solid #E0E6ED;float: left;"
    >
      <div>
        <div style="padding: 15px;font-size: 14px;">共{{ vedioLong }}条录音</div>
        <div style="padding: 0 15px;font-size: 14px;">共{{ sumTitle }}个主题</div>
        <el-button
          funcId="000367"
          style="margin-right: 19px;float: right;"
          @click="newList"
        >
          新建分类
        </el-button>
        <div style="height:10px;clear:both;"></div>
      </div>
      <div
        id="blockDiv"
        class="block"
        style="clear: both;height: 100%;overflow: auto;padding-bottom: 125px;box-sizing: border-box"
      >
        <el-tree
          :data="data5"
          node-key="id"
          draggable
          :expand-on-click-node="false"
          ref="keyWordsMenu"
          @node-drag-start="treeMove"
          @node-drag-end="treeLeave"
          @node-click="treeClick"
          :allow-drop="allowDrop"
        >
          <span
            class="custom-tree-node"
            style="position: relative"
            slot-scope="{ node, data }"
          >
            <span
              class="overWide"
              :style="'right: ' + (data.isTopic == '0' ? '65' : '90') + 'px'"
              >{{ node.label }}</span
            >
            <span v-if="data.isTopic == 0" class="cluster-result-right"
              >({{ data.topicCount }})</span
            >
            <span v-if="data.isTopic == '1'" class="cluster-result-right">
              <el-button type="text" size="mini" @click="append(data)">
                编辑
              </el-button>
              <el-button type="text" size="mini" @click="removeDataes(node, data)">
                删除
              </el-button>
            </span>
          </span>
        </el-tree>
      </div>
      <el-dialog
        class="smellmodel speshow"
        :visible.sync="setInput"
        width="520px"
        title="新建分类"
        :close-on-click-modal="false"
      >
        <div style="padding: 20px 0 0 20px;width: 70%;">
          <el-form
            label-width="100px"
            ref="threeForm"
            :model="taskForm"
            :rules="threeRules"
          >
            <el-form-item label="分类名称" prop="name">
              <el-input v-model="taskForm.name" placeholder="请输入分类名称"></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div
          class="footerAll"
          style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
        >
          <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
            <el-button @click="notChange">取 消</el-button>
            <el-button type="primary" style="margin-right: 18px;" @click="newContent"
              >确 定</el-button
            >
          </div>
        </div>
      </el-dialog>
      <el-dialog
        class="smellmodel speshow"
        :visible.sync="edirDeal"
        width="520px"
        title="编辑分类"
        :close-on-click-modal="false"
      >
        <div style="padding: 20px 0 0 20px;width: 70%;">
          <el-form
            label-width="100px"
            ref="offForm"
            :model="removeMessage"
            :rules="offRules"
          >
            <el-form-item label="分类名称" prop="name">
              <el-input
                v-model="removeMessage.name"
                placeholder="请修改分类名称"
              ></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div
          class="footerAll"
          style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
        >
          <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
            <el-button @click="notChange">取 消</el-button>
            <el-button type="primary" style="margin-right: 18px;" @click="goSend(1)"
              >确 定</el-button
            >
          </div>
        </div>
      </el-dialog>
      <el-dialog
        class="smellmodel speshow"
        :visible.sync="redInput"
        width="520px"
        title="主题解读"
        :close-on-click-modal="false"
      >
        <div style="padding: 20px 0 0 20px;width: 70%;">
          <el-form label-width="100px" ref="twoForm" :model="readCell" :rules="twoRules">
            <el-form-item label="主题名称" prop="name">
              <el-input v-model="readCell.name" placeholder="请输入主题名称"></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div
          class="footerAll"
          style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
        >
          <div style="display: inline-block;margin: 15px 20px;">
            <el-button @click="deleRead">删除解读</el-button>
          </div>
          <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
            <el-button @click="notChange">取 消</el-button>
            <el-button type="primary" style="margin-right: 18px;" @click="goSend(2)"
              >确 定</el-button
            >
          </div>
        </div>
      </el-dialog>
      <el-dialog
        :title="treeTitle"
        :visible.sync="dialogVisible"
        width="760px"
        :close-on-click-modal="false"
        @close="treeFormClose"
      >
        <el-form
          v-if="dialogVisible"
          :model="treeForm"
          ref="treeForm"
          :rules="treeFormRules"
          label-width="100px"
          style=" overflow-y: auto;margin: 20px;"
        >
          <el-form-item label="分类树名称" prop="treeSelectOption">
            <el-select
              v-model="treeForm.treeSelectOption"
              placeholder="请选择"
              @change="changeTreeType"
            >
              <el-option
                v-for="(item, index) in treeSelectOptions"
                :key="index"
                :label="item.label"
                :value="item"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-tree
            ref="ttData"
            default-expand-all
            empty-text=" "
            :data="treeData"
            :props="defaultProps"
            @node-click="handleNodeClick"
            highlight-current
            :expand-on-click-node="false"
            node-key="sortID"
          >
            <span class="custom-tree-node" slot-scope="{ node, data }">
              <span>{{ node.label }}</span>
              <span>
                <el-button type="text" size="mini" @click="edit(node, data)">
                  编辑
                </el-button>
                <el-button type="text" size="mini" @click="remove(node, data)">
                  删除
                </el-button>
              </span>
            </span>
          </el-tree>
          <el-button class="add-type" :disabled="addTypeDisabled" @click="addTreeType"
            >添加分类</el-button
          >
          <div class="el-dialog-box-clor" v-if="addTypeDisabled">
            <el-form-item id="cengji" class="fn-bor-b-c">
              <el-col :span="12">
                <el-form-item
                  label="分类名称"
                  prop="typename"
                  v-if="this.addTreeTypeYes === true"
                >
                  <el-input
                    v-if="this.existTopicData.length < 1"
                    v-model="treeForm.typename"
                    placeholder="请输入"
                    maxlength="10"
                    style="width: 200px;"
                  ></el-input>
                  <el-select
                    v-if="this.existTopicData.length > 0"
                    v-model="treeForm.typename"
                    placeholder="请选择"
                    filterable
                    :allow-create="true"
                  >
                    <el-option
                      :key="index"
                      v-for="(item, index) in existTopicData"
                      :props="existProps"
                      :label="item.topicName"
                      :value="item.topicName"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="所属层级" v-if="this.edittree === true">
                  <el-select
                    v-model="treeForm.type"
                    placeholder="请选择"
                    style="width: 120px;"
                  >
                    <el-option label="无" value="无"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-form-item>
            <el-form-item label="" v-if="this.clearAddShow === true">
              <el-select
                v-model="treeForm.dybq"
                placeholder="请选择"
                :props="selectDefaultProps"
                style="width: 112px;"
                @change="dyLabelChange"
              >
                <el-option
                  v-for="item in biaoqianList"
                  :key="item.labelId"
                  :label="item.labelName"
                  :value="item.labelId"
                >
                </el-option>
              </el-select>
              <i
                class="el-icon-circle-plus"
                style="cursor: pointer; font-size: 16px; margin-right: 10px;"
                @click="addDomain(this.number)"
              ></i>
              <el-button type="text" size="mini" @click="clearAddLogic">
                取消
              </el-button>
            </el-form-item>
            <div v-if="this.clearAddShow === true" class="flex-box">
              <el-form-item
                class="flex-box-list"
                v-for="(domain, index) in treeForm.domains"
                :key="index"
                prop="domains"
              >
                <el-select v-model="domain.relation" style="width: 112px;">
                  <el-option
                    v-for="item in logicList"
                    :key="item.label"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
                <el-select
                  v-model="domain.labelId"
                  :props="selectDefaultProps"
                  placeholder="请选择"
                  style="width: 112px;"
                >
                  <el-option
                    v-for="item in biaoqianList"
                    :key="item.labelId"
                    :label="item.labelName"
                    :value="item.labelId"
                  >
                  </el-option>
                </el-select>
                <i
                  class="el-icon-remove"
                  style="cursor: pointer; font-size: 16px;"
                  @click.prevent="removeDomain(domain)"
                ></i>
              </el-form-item>
            </div>
            <el-form-item
              v-if="this.newBiaoData.length > 0 && this.showNewLabel === true"
            >
              <div class="newBiaoQian" v-for="(item, index) in newBiaoData" :key="index">
                <el-select
                  v-if="index > 0 || clearAddShow === true"
                  v-model="item.relation"
                  @change="selectChange"
                  :props="selectDefaultProps"
                  style="width: 112px;"
                >
                  <el-option
                    v-for="item in logicList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
                <div class="lists">
                  <p>{{ item.labelName }}</p>
                  <span @click="editNewBiao(index, item)">更改</span>
                  <span @click="deleteNewBiao(index, item)">删除</span>
                </div>
              </div>
            </el-form-item>
            <el-dropdown
              class="el-dropdown-box"
              trigger="click"
              v-if="this.addTreeTypeYes === true"
            >
              <el-button style="width: 120px;">
                +
              </el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item><p @click="addLabel">创建新标签</p></el-dropdown-item>
                <el-dropdown-item><p @click="diaoyong">调用标签</p></el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <el-form-item
              v-if="this.addTreeTypeYes === true"
              style="text-align: right; margin-right: 10px"
            >
              <el-button @click="canelAddTreeJie">{{ addEditTitle }}</el-button>
              <el-button @click="addTreeJieYes" type="primary">提交</el-button>
            </el-form-item>
          </div>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="quXiao">取 消</el-button>
          <el-button type="primary" :disabled="addTypeDisabled" @click="treeFormSave"
            >确 定</el-button
          >
        </div>
      </el-dialog>
      <vAddNewLabel
        @submitted="submitted"
        @close="close"
        @formData="formData"
        ref="addRecordLabelComponent"
        v-if="addRecordLabelComponentShow"
        :pageName="pageName"
        :typeHide="typeHide"
        :treeid="treeid"
        :newBiaoData="newBiaoData"
        :editNewBiaoIndex="editNewBiaoIndex"
        :editNewLabelItem="editNewLabelItem"
        :labelId="labelId"
        :editType="editType"
      >
      </vAddNewLabel>
    </div>
    <div
      v-loading="recordsLoading"
      style="height:93%;display: inline-block;width: 69%;float: left;overflow-y: auto;"
    >
      <div
        style="padding: 10px 20px;height:30px;line-height:30px;font-size: 14px;font-weight: bolder;"
      >
        <span>{{ topName }}{{ topKey }}</span>
        <i
          funcId="000368"
          v-show="ghlArr && ghlArr.length"
          class="el-icon-edit-outline editIcon"
          @click="newDadit"
        ></i>
      </div>
      <el-collapse v-model="activeNames" v-loading="collapseLoading">
        <div
          v-for="(item, index) in ghlArr"
          :key="index"
          style="margin: 15px 20px 20px 20px;border: 1px solid #E0E6ED;font-size: 14px;border-radius: 5px;background: #9ED9F3;"
        >
          <el-collapse-item>
            <template slot="title">
              <div
                class="nextDiv"
                style="padding: 0px 20px;background: #E0E6ED;"
                @click="tabClick(index, $event)"
              >
                <span>编号:</span
                ><span style="color: #20A0FF;">&nbsp;{{ item.callID }}</span>
                <span style="float: right;color: #20A0FF;cursor: pointer;">{{
                  item.expand ? '收起详情' : '展开详情'
                }}</span>
                <span
                  style="font-size: 14px;float: right;color: #20A0FF;margin-right: 5px;"
                  :class="[
                    item.expand
                      ? 'iconfont icon-zhanshixiangqing secondBox'
                      : 'iconfont icon-zhanshixiangqing startBox',
                  ]"
                ></span>
              </div>
              <div
                class="parentDic"
                style="padding: 0px 20px;background: #E0E6ED;"
                @click="tabClick(index, $event)"
              >
                <div style="width: 80%;display: inline-block;">
                  <span
                    v-for="(list, indextwo) in ghlArr[index].labelContentList"
                    :key="indextwo"
                    style="margin-left: 10px;display: inline-block;color: #1791EC;text-align:center;line-height:17px;border-radius:4px;border: 1px solid #9ED9F3;padding: 5px 10px;height: 17px;background: #9ED9F3;"
                    >{{ list }}</span
                  >
                  <span
                    v-for="(list, indexdoen) in ghlArr[index].algLabelContentList"
                    :key="indexdoen"
                    style="display: inline-block;margin-left: 10px;color: #12A080;text-align:center;line-height:17px;border-radius:4px;border: 1px solid #6BDEC4;padding: 5px 10px;height: 17px;background: #CAF7ED;"
                    >{{ list }}</span
                  >
                </div>
                <div
                  style="width: 20%;float: right;text-align: right;display: inline-block;"
                >
                  <span
                    v-if="
                      item.sentimentWhole != null &&
                        item.sentimentWhole.indexOf('消极') != -1
                    "
                    style="display: inline-block;margin-left: 10px;color: #12A080;text-align:center;line-height:17px;border-radius:4px;border: 1px solid red;padding: 5px 10px;height: 17px;padding: 5px 10px;color: red;"
                    >{{ item.sentimentWhole }}</span
                  >
                  <span
                    v-if="
                      item.sentimentWhole != null &&
                        item.sentimentWhole.indexOf('积极') != -1
                    "
                    style="display: inline-block;margin-left: 10px;color: #12A080;text-align:center;line-height:17px;border-radius:4px;border: 1px solid #6BDEC4;padding: 5px 10px;height: 17px;padding: 5px 10px;color: #12A080;"
                    >{{ item.sentimentWhole }}</span
                  >
                </div>
              </div>
            </template>
            <div @mouseenter="showPlay(index)" @mouseleave="hidePlay(index)" style="position: relative">
              <div style="height: 70px; padding: 20px 20px 0px 20px; overflow: hidden;">
                <p v-html="item.wholeContent"></p>
              </div>
              <div class="play" v-show="item.display" @click="showDetail(item.callID, item.recordFileURL)">
                <img src="../../../assets/img/u493.png" />
              </div>
            </div>
          </el-collapse-item>
        </div>
      </el-collapse>
    </div>
    <div class="autoGrading-page">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import global from '@/global'
import { validModelTrim } from '@/utry-sdk/common/constants'
import Qs from 'qs'
import vAddNewLabel from '../Analysis/addNewLabel'
import recordingplay from '../recordingPlay/recordingPlayResultScore.vue'
import bus from '../../common/bus.js'
let currentBaseUrl = global.currentBaseUrl
let requestUrls = {
  getTreeType: currentBaseUrl + '/recordSort/trees',
  getTreeListBySortID: currentBaseUrl + '/recordSort/trees',
  deleteTree: currentBaseUrl + '/recordSort/trees',
  clusterResultExport: currentBaseUrl + '/ivsClusterRule/clusterResultExport',
  addTree: currentBaseUrl + '/recordSort/trees',
  getRadioBySortID: currentBaseUrl + '/recordSort/',
  getAllInProgress: currentBaseUrl + '/recordLabel/allInProgress',
  getExistTopic: currentBaseUrl + '/ivsClusterRule/getExistTopic', // 分类名称下拉list
  getRoleType: currentBaseUrl + '/hotAnlys/type/keyword',
}
const deleteEmptyChildren = function deleteEmptyChildren(treeArr) {
  if (!treeArr) {
    return
  }
  treeArr.forEach((item) => {
    if (item.children && item.children instanceof Array && item.children.length > 0) {
      deleteEmptyChildren(item.children)
    } else {
      delete item.children
    }
  })
}
export default {
  props: ['message'],
  components: {
    vAddNewLabel,
    recordingplay,
  },
  data() {
    let checkName = (rule, valueOne, callback) => {
      console.log(valueOne)
      if (!valueOne) {
        return callback(new Error('请输入分类名称'))
      }
      let reg = new RegExp(/^\s+$/)
      if (reg.test(valueOne)) {
        callback(new Error('请勿输入空格'))
      }
    }
    return {
      recordDialogVisible: false,
      importUrl: '',
      collapseLoading: false,
      tableData: [],
      existTopicData: [],
      biaoqianList: [],
      existProps: {
        value: 'topicName',
        label: 'topicName',
      },
      selectDefaultProps: {
        value: 'labelId',
        label: 'labelName',
      },
      data5: [],
      vedioLong: '',
      sumTitle: '',
      firstIds: '',
      currentPage: 1,
      taskForm: {
        name: '',
      },
      removeMessage: {
        name: '',
      },
      threeRules: {
        name: [
          { min: 1, max: 10, message: '长度在 1 到 10 个字符', trigger: 'blur' },
          { required: true, validator: checkName, trigger: 'blur' },
        ],
      },
      offRules: {
        name: [
          { min: 1, max: 10, message: '长度在 1 到 10 个字符', trigger: 'blur' },
          { required: true, validator: checkName, trigger: 'blur' },
        ],
      },
      twoRules: {
        name: [
          { min: 1, max: 10, message: '长度在 1 到 10 个字符', trigger: 'blur' },
          { required: true, validator: checkName, trigger: 'blur' },
        ],
      },
      readCell: {
        name: '',
      },
      ghlArr: [],
      number: 1,
      treeDataEdit: {},
      setInput: false,
      redInput: false,
      edittree: false,
      edirDeal: false,
      appendClick: true,
      isEditTree: false,
      clearAddShow: false,
      addTreeTypeYes: false,
      addTypeDisabled: false,
      addLogicShow: false,
      showNewLabel: false,
      pageName: 'audio',
      typeHide: true,
      treeid: '',
      tData: [],
      existTopicDataMap: {},
      newBiaoData: [],
      editNewBiaoIndex: 0,
      editNewLabelItem: {},
      labelId: '',
      editType: 'new',
      addRecordLabelComponentShow: true, // 清除缓存数据
      selectedOptions3: [],
      treeTitle: '编辑分类树',
      dialogVisible: false,
      addEditTitle: '取消',
      logicList: [
        {
          value: 'OR',
          label: 'OR',
        },
        {
          value: 'AND',
          label: 'AND',
        },
      ],
      treeForm: {
        domains: [
          {
            relation: '',
            add: '',
            labelName: '',
            labelId: '',
          },
        ],
        type: '无', // 所属层级
        name: '',
        treeName: '',
        level: '0',
        treeSelectOption: '',
        typename: '',
        dybq: '',
      },
      treeFormRules: {
        treeSelectOption: [
          { required: true, message: '请选择分类树名称', trigger: 'change' },
        ],
        typename: [{ required: true, validator: validModelTrim, trigger: 'blur' }],
      },
      defaultProps: {
        children: 'children',
        label: 'sortName',
      },
      sortID: '',
      formLabelWidth: '100px',
      treeSelectOptions: [],
      treeData: [],
      num: 0,
      dataId: '',
      readId: '',
      topName: '',
      topKey: '',
      treeDataId: '',
      activeNames: ['0'],
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
      recordsLoading: false,
    }
  },
  methods: {
    filter() {
      this.$emit('filterButton')
    },
    // 鼠标放到录音内容上时展示播放按钮
    showPlay(index) {
      this.ghlArr[index].display = true
      this.$forceUpdate()
    },
    // 鼠标移出录音内容上时展示播放按钮
    hidePlay(index) {
      this.ghlArr[index].display = false
      this.$forceUpdate()
    },
    recordPlayCloseHandler() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    showDetail(callID, recordFileURL) {
      let obj = {}
      obj.from = 'clusterTrain'
      obj.callId = callID
      obj.recordFileURL = recordFileURL
      obj.pageNumber = this.currentPage
      obj.pageSize = this.pageSize
      obj.sortID = this.sortID
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    formatDate(obj) {
      let date = new Date(obj)
      let y = 1900 + date.getYear()
      let m = '0' + (date.getMonth() + 1)
      let d = '0' + date.getDate()
      let h = '0' + date.getHours()
      let f = '0' + date.getMinutes()
      let s = '0' + date.getSeconds()
      return (
        y +
        '-' +
        m.substring(m.length - 2, m.length) +
        '-' +
        d.substring(d.length - 2, d.length) +
        ' ' +
        h.substring(h.length - 2, h.length) +
        ':' +
        f.substring(f.length - 2, f.length) +
        ':' +
        s.substring(s.length - 2, s.length)
      )
    },
    getbackNow: function() {
      this.$emit('sendof', false)
    },
    append(data) {
      this.appendClick = false
      this.treeDataId = data.id
      this.edirDeal = true
      this.removeMessage.name = ''
    },
    notChange: function() {
      this.setInput = false
      this.redInput = false
      this.edirDeal = false
    },
    newList: function() {
      this.setInput = true
      this.taskForm.name = ''
    },
    newContent: function() {
      let _this = this
      let firty = this
      firty.$refs.threeForm.validate(function(validate) {
        if (!validate) {
          throw new Error('填写必填项')
        }
      })
      let params = {
        clusterRuleId: this.message,
        topicName: this.taskForm.name,
      }
      this.axios
        .post(currentBaseUrl + '/ivsClusterRule/newClassTopic.do', Qs.stringify(params))
        .then((resp) => {
          console.log(resp)
          if (resp.data.state == '1') {
            _this.$message({
              type: 'success',
              message: '创建成功',
            })
            this.setInput = false
            this.goSidetree()
          } else {
            _this.$message({
              type: 'error',
              message: '创建失败,分类名称已重复',
            })
          }
        })
    },
    allowDrop(draggingNode, dropNode, type) {
      if (dropNode.data.isTopic === 0) {
        return type !== 'inner'
      } else {
        return true
      }
    },
    newDadit() {
      this.readCell.name = this.topName
      this.redInput = true
    },
    goSend(index) {
      let moreName = ''
      if (index == 1) {
        let secofr = this
        secofr.$refs.offForm.validate(function(validate) {
          if (!validate) {
            throw new Error('填写必填项')
          }
        })
        moreName = this.removeMessage.name
      } else {
        let secofr = this
        secofr.$refs.twoForm.validate(function(validate) {
          if (!validate) {
            throw new Error('填写必填项')
          }
        })
        moreName = this.readCell.name
      }
      let _this = this
      let params = {
        topicClusterId: this.treeDataId,
        topicName: moreName,
        parentId: this.parentKey,
        clusterRuleId: this.message,
      }
      this.axios
        .post(currentBaseUrl + '/ivsClusterRule/clusterRead.do', Qs.stringify(params))
        .then((resp) => {
          console.log(resp)
          if (resp.data.state == '1') {
            _this.$message({
              type: 'success',
              message: '修改成功',
            })
            this.redInput = false
            this.edirDeal = false
            this.topName = this.readCell.name || moreName
            this.topKey = this.topKey ? '(' + this.topKey + ')' : ''
            console.log(this.topName)
            this.goSidetree()
          } else {
            _this.$message({
              type: 'error',
              message: resp.data.message,
            })
          }
        })
    },
    deleRead: function() {
      let _this = this
      let params = {
        clusterTopicId: this.readId,
      }
      this.axios
        .post(currentBaseUrl + '/ivsClusterRule/deleteRead.do', Qs.stringify(params))
        .then((resp) => {
          console.log(resp)
          if (resp.data.state == '1') {
            _this.$message({
              type: 'success',
              message: '删除成功',
            })
            this.redInput = false
            this.goSidetree()
            this.topName = ''
            this.topKey = this.topKey.replace('(', '')
            this.topKey = this.topKey.replace(')', '')
          } else {
            _this.$message({
              type: 'error',
              message: '删除失败',
            })
          }
        })
    },
    // 节点删除按钮
    removeDataes(node, data) {
      let _this = this
      let params = {
        topicClusterId: node.key,
      }
      this.axios
        .post(currentBaseUrl + '/ivsClusterRule/untieDelete.do', Qs.stringify(params))
        .then((resp) => {
          console.log(resp)
          if (resp.data.state == '1') {
            _this.$message({
              type: 'success',
              message: '删除成功',
            })
            this.redInput = false
            this.goSidetree()
          } else {
            _this.$message({
              type: 'error',
              message: '删除失败',
            })
          }
        })
    },
    tabClick: function(index, flag) {
      this.num = index
      if (this.ghlArr[index].expand != null && this.ghlArr[index].expand == true) {
        this.ghlArr[index].expand = false
      } else {
        this.ghlArr[index].expand = true
      }
    },
    treeClick: function(event, data) {
      if (data.data.isTopic === 0) {
        this.treeDataId = data.data.id
      }
      if (this.appendClick == false) {
        this.appendClick = true
      } else {
        this.currentPage = 1
        this.contentChange(event, data)
      }
    },
    contentChange: function(event, data) {
      const node = this.$refs.keyWordsMenu.getCurrentNode()
      console.log(node)
      if (node == null) {
        this.readId = this.firstIds
      } else {
        this.readId = node.id
        console.log(data)
        if (data == undefined) {
          this.parentKey = ''
        } else {
          if (data.parent.key == undefined) {
            this.parentKey = ''
          } else {
            this.parentKey = data.parent.key
          }
        }
      }
      const topicName = node ? node.label : ''
      let params = {
        clusterTopicId: this.readId,
        pageNumber: this.currentPage,
        pageSize: this.pageSize,
      }
      this.recordsLoading = true
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getClusterTopicRecordDetailByTopicId.do',
          Qs.stringify(params)
        )
        .then((resp) => {
          this.recordsLoading = false
          console.log(resp)
          if (resp.data.failed == '0') {
            return
          } else {
            this.activeNames = ['0']
            let data = resp.data.data
            data.forEach(item=>{
              item.display = false
            })
            this.ghlArr = data
            this.total = resp.data.count
            this.topName = resp.data.topicName
            if (resp.data.topicKeyword == null || resp.data.topicName == null) {
              this.topKey = resp.data.topicKeyword
            } else {
              this.topKey = '(' + resp.data.topicKeyword + ')'
            }
            if (this.topName === undefined) {
              this.topName = topicName
            }
            console.log(this.topName)
          }
        })
        .catch(() => {
          this.recordsLoading = false
          this.ghlArr = []
          this.total = 0
          this.topName = topicName
          this.topKey = ''
        })
    },
    treeMove: function(data) {
      // console.log(data)
      console.log(data.label)
      console.log(data.key)
      this.moveVale = data.label
      this.dataId = data.key
      this.dragParent = data.parent
    },
    treeLeave: function(draggingNode, dropNode, dropType, ev) {    
      // 主题同级但不是同一父类，这种情况拖拽是无效的
      if (
        draggingNode.level === dropNode.level &&
        (dropNode.level === 1 || dropNode.parent.key === draggingNode.key) &&
        draggingNode.data.isTopic === dropNode.data.isTopic &&
        draggingNode.data.isTopic === 0
      ) {
        return
      }
      if (this.dataId == dropNode.key) {
        return
      } else {
        if (dropNode.data.isTopic === 0) {
          console.log(this.dataId)
          if (dropType !== 'none') {
            let parentId = this.dataId
            let isInner = 0
            // 移到分类中
            if (dropNode.level > 1) {
              parentId = dropNode.parent.key
              isInner = 1
            }
            // 从里移到外面
            if (dropNode.level === 1 && draggingNode.level > 1) {
              parentId = this.dragParent.key
            }
            let paramare = {
              childTopicClusterId: this.dataId,
              parentTopicClusterId: parentId,
              isInner,
            }
            console.log(dropType)
            this.axios
              .post(
                currentBaseUrl + '/ivsClusterRule/updateTopicClassTree.do',
                Qs.stringify(paramare)
              )
              .then((resp) => {
                console.log(resp)
                if (resp.data.state == '1') {
                  this.$message({
                    type: 'success',
                    message: '拖拽成功',
                  })
                } else {
                  this.$message({
                    type: 'error',
                    message: '拖拽失败',
                  })
                }
              })
          }
        } else {
          let _this = this
          let stringDeal = ''
          if (dropType == 'inner') {
            stringDeal = 1
          } else {
            stringDeal = 0
          }
          console.log(this.dataId)
          let params = {
            childTopicClusterId: this.dataId,
            parentTopicClusterId: dropNode.key,
            isInner: stringDeal,
          }
          console.log(dropType)
          this.axios
            .post(
              currentBaseUrl + '/ivsClusterRule/updateTopicClassTree.do',
              Qs.stringify(params)
            )
            .then((resp) => {
              console.log(resp)
              if (resp.data.state == '1') {
                _this.$message({
                  type: 'success',
                  message: '拖拽成功',
                })
              } else {
                _this.$message({
                  type: 'error',
                  message: '拖拽失败',
                })
              }
            })
        }
      }
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.contentChange()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      console.log(val)
      this.contentChange()
    },
    goSidetree: function() {
      let params = {
        clusterRuleId: this.message,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getTopicClusterData.do',
          Qs.stringify(params)
        )
        .then((resp) => {
          console.log(resp.data.data)
          this.data5 = resp.data.data
          this.sumTitle = resp.data.topicCount
          this.vedioLong = resp.data.recordCount
        })
    },
    commonUtil(cellValue) {
      cellValue = cellValue / 1000
      let theTime = parseInt(cellValue) // 秒
      let theTime1 = 0 // 分
      let theTime2 = 0 // 小时
      if (theTime > 60) {
        theTime1 = parseInt(theTime / 60)
        theTime = parseInt(theTime % 60)
        if (theTime1 > 60) {
          theTime2 = parseInt(theTime1 / 60)
          theTime1 = parseInt(theTime1 % 60)
        }
      }
      let result = '' + parseInt(theTime) + '秒'
      if (theTime1 > 0) {
        result = '' + parseInt(theTime1) + '分' + result
      }
      if (theTime2 > 0) {
        result = '' + parseInt(theTime2) + '小时' + result
      }
      return result
    },
    editTreeType() {
      this.dialogVisible = true
      this.treeForm.name = this.sortLabel
      this.treeData = JSON.parse(JSON.stringify(this.tData))
      this.getTreeType()
      deleteEmptyChildren(this.addEditCascaderData)
      this.getAllInProgress()
      this.getExistTopic()
    },
    // 关闭弹框 里面所填写的内容也将释放
    treeFormClose() {
      let that = this
      that.dialogVisible = false
      that.addTreeTypeYes = false
      that.clearAddShow = false
      that.treeForm.domains = []
      that.treeForm.treeSelectOption = ''
      that.newBiaoData.length = 0
      that.showNewLabel = false
    },
    // 复制一棵树分类
    /*
     * 根据分类树id 查询 tree节点 显示tree
     * */
    changeTreeType(value) {
      let that = this
      console.log(value)
      that.sortID = value.value
      // 根据分类树id 查询 tree节点 需要调接口
      that.getTreeListBySortIDT()
    },
    // 获取某个分类树下面的tree结构
    getTreeListBySortIDT() {
      this.treeData = []
      this.axios
        .get(requestUrls['getTreeListBySortID'] + '/' + this.sortID)
        .then((res) => {
          // 复制成功 给 显示tree节点
          let childs = res.data.data.children
          this.treeData = childs
        })
        .catch(() => {
          // this.$message.error('获取分类树下面的树发生异常')
        })
    },
    handleNodeClick(data) {
      let that = this
      if (this.isEditTree === true) {
        // that.treeForm.typename = data.sortName
      } else {
        that.treeForm.type = data.sortName
      }
      that.treeDataEdit = data
    },
    // 编辑tree节点
    edit(node, data) {
      let that = this
      let obj = {}
      obj.sortID = data.sortID
      obj.sortName = data.sortName
      obj.children = data.children
      obj.parentSortID = data.parentSortID
      obj.count = data.count
      if (data.labels === null) {
        data.labels = []
      }
      console.log(data)
      console.log(data.labels)
      if (data.labels.length > 0) {
        let biaoqianLabelIdList = []
        for (let i = 0; i < this.biaoqianList.length; i++) {
          biaoqianLabelIdList.push(this.biaoqianList[i].labelId)
        }
        let dataLabels = []
        for (let i = 0; i < data.labels.length; i++) {
          if (
            data.labels[i].labelId == '' ||
            biaoqianLabelIdList.indexOf(data.labels[i].labelId) > -1
          ) {
            dataLabels.push(data.labels[i])
          }
        }
        data.labels = dataLabels
        let diaoyongListNew = []
        if (data.labels.length > 0) {
          for (let u = 0; u < data.labels.length; u++) {
            // 把新标签列表刷选出来
            if (data.labels[u].add === true) {
              diaoyongListNew.push(data.labels[u])
            }
          }
        }
        if (data.labels.length > 0 && diaoyongListNew.length > 0) {
          that.newBiaoData = diaoyongListNew
          this.showNewLabel = true
        } else {
          that.newBiaoData = []
        }
        if (data.labels.length > 0) {
          for (let i = 0; i < 1; i++) {
            // 把调用标签列表刷选出来
            if (data.labels[0].add === false) {
              that.clearAddShow = true
              that.treeForm.dybq = data.labels[0].labelId
            }
          }
        }
        // 移除数组中第一个 调用标签
        // data.labels.splice(0, 1)
        let deleteData = []
        data.labels.forEach(function(item) {
          let obj = {}
          for (let v in item) {
            obj[v] = item[v]
          }
          deleteData.push(obj)
        })
        if (deleteData) {
          deleteData.splice(0, 1)
        }
        let deleteShu = []
        for (let k = 0; k < deleteData.length; k++) {
          // 把调用标签列表刷选出来
          if (deleteData[k].add === false) {
            deleteShu.push(deleteData[k])
          }
        }
        that.treeForm.domains = deleteShu
        if (data.labels.length > diaoyongListNew.length) {
          that.clearAddShow = true
        }
        that.addLogicShow = true
        obj.labels = data.labels
      } else {
        obj.labels = []
        that.newBiaoData = []
        that.treeForm.domains = []
        that.clearAddShow = false
      }
      obj.otherCount = data.otherCount
      that.objBiao = obj
      if (node.parent.parent != null) {
        console.log('有父级')
        if (node.parent.parent.data != null) {
          if (node.parent.parent.data instanceof Array) {
            // 判断是不是数组
            if (node.parent.parent.data[0].children.length > 0) {
              for (let j = 0; j < node.parent.parent.data[0].children.length; j++) {
                this.getParentId(node.parent.parent.data[0].children)
              }
            }
          } else {
            if (node.parent.parent.data.children.length > 0) {
              that.getParentId(node.parent.parent.data.children)
            }
            console.log('点击了最后一级')
          }
        } else {
          console.log(111)
        }
      } else {
        that.selectedOptions3[0] = node.data.id
        console.log('你就是父级')
      }
      that.addTypeDisabled = true
      that.isEditTree = true
      that.addTreeTypeYes = true
      that.edittree = false
      this.treeForm.typename = data.sortName
      that.treeForm.sortID = data.sortID
      that.treeJieId = data.id
    },
    getParentId(childrenData) {
      let that = this
      for (let i = 0; i < childrenData.length; i++) {
        if (childrenData[i].children === undefined || childrenData[i].children === null) {
          let jj = []
          jj[0] = childrenData[i].id
          that.selectedOptions3.concat(jj)
        } else {
          that.selectedOptions3.push(childrenData[i].id)
          that.getParentId(childrenData[i].children)
        }
      }
    },
    // 移除一个节点
    remove(node, data) {
      for (let i = 0; i < this.treeData.length; i++) {
        if (this.treeData[i].sortID === data.sortID) {
          this.treeData[i].labels = []
          this.treeData.splice(i, 1)
        } else {
          if (this.treeData[i].children.length > 0) {
            this.getChildRemove(this.treeData[i].children, data)
          }
        }
      }
      if (this.treeData.length === 0) {
        this.treeForm.type = '无'
      }
      this.treeData = JSON.parse(JSON.stringify(this.treeData))
      this.$forceUpdate()
    },
    getChildRemove(children, data) {
      let that = this
      for (let i = 0; i < children.length; i++) {
        if (children[i].sortID === data.sortID) {
          children[i].labels = []
          children.splice(i, 1)
        } else {
          if (children[i].children.length > 0) {
            that.getChildRemove(children[i].children, data)
          }
        }
      }
    },
    addTreeType() {
      if (this.addTypeDisabled) {
        return
      }
      this.addTreeTypeYes = true
      this.addTypeDisabled = true
      this.treeForm.typename = ''
      this.edittree = true
      this.treeForm.domains = []
      this.treeForm.dybq = ''
      console.log(this.treeForm.domains)
    },
    // 调用标签选择
    dyLabelChange(value) {
      console.log(value)
      let that = this
      that.treeForm.dybq = value
    },
    addDomain() {
      this.addLogicShow = true
      console.log(this.number)
      this.treeForm.domains.push({
        relation: '',
        add: false,
        labelId: '',
        labelName: '',
      })
      console.log(this.treeForm.domains)
    },
    // 取消添加标签
    clearAddLogic() {
      let that = this
      that.clearAddShow = false
      that.treeForm.domains = []
      that.treeForm.dybq = ''
    },
    removeDomain(item) {
      let that = this
      let index = that.treeForm.domains.indexOf(item)
      if (index !== -1) {
        that.treeForm.domains.splice(index, 1)
      }
    },
    selectChange() {
      console.log(this.newBiaoData)
    },
    // 编辑新标签
    editNewBiao(index, item) {
      console.log(index)
      let that = this
      that.editType = 'edit'
      that.$refs.addRecordLabelComponent.showDialog = true
      that.$refs.addRecordLabelComponent.topicClusterId =
        that.existTopicDataMap[that.treeForm.typename]
      that.editNewBiaoIndex = index // 编辑新标签的时候需要传 当前的索引 和 data
      that.editNewLabelItem = item
      that.labelId = item.labelId
    },
    // 删除一个新标签
    deleteNewBiao(index, item) {
      this.$confirm('确定要删除' + item.labelName + '吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.newBiaoData.splice(index, 1)
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 添加新标签
    addLabel() {
      let that = this
      that.showNewLabel = true
      this.addRecordLabelComponentShow = false // 强制清除数据
      this.$nextTick(() => {
        this.addRecordLabelComponentShow = true
        setTimeout(() => {
          that.$refs.addRecordLabelComponent.showDialog = true // hack写法，强制清除数据
          that.$refs.addRecordLabelComponent.topicClusterId =
            that.existTopicDataMap[that.treeForm.typename]
          that.editType = 'new'
          if (that.tid !== '') {
            that.treeid = that.tid
          }
        }, 30)
      })
    },
    // 点击 调用标签
    diaoyong() {
      this.clearAddShow = true
    },
    // 取消添加分类树的tree节点
    canelAddTreeJie() {
      let that = this
      that.addTreeTypeYes = false
      that.addTypeDisabled = false
      that.edittree = false
      that.isEditTree = false
      that.treeForm.type = '无'
      that.treeForm.typename = ''
      that.newBiaoData = []
      that.editNewBiaoIndex = 0
      that.clearAddShow = false
    },
    // 确认添加分类树的tree节点
    addTreeJieYes() {
      let that = this
      console.info(this.sortID)
      this.$refs.treeForm.validate((valid) => {})
      if (this.treeForm.typename.length > 10) {
        // this.$message('分类名称不能超过10个字符。')
        return
      }
      if (this.treeForm.typename) {
        // 判断是调用标签的去重
        // -- start ---
        // 判断锚
        if (this.treeForm.typename.indexOf(' ') >= 0) {
          return
        }
        let domainsDb = true
        if (this.treeForm.domains.length) {
          this.treeForm.domains.forEach((val, i) => {
            let domains = JSON.parse(JSON.stringify(this.treeForm.domains))
            domains.splice(i, 1)
            let domainsString = domains.map((item) => item.labelId).join('||')
            if (domainsString.indexOf(val.labelId) >= 0) {
              domainsDb = false
            }
          })
        }
        // 调用标签异常判断
        if (!domainsDb) {
          this.$message({
            type: 'info',
            message: '调用标签不能重复',
          })
          return
        }
        // -- end --
        // 判断是调用标签的去重
        // ------------------
        // 分类名称重复判断
        const { typename, sortID } = this.treeForm
        let db = true
        this.treeData.forEach((val) => {
          if (val.sortID != sortID) {
            if (val.sortName === typename) {
              console.log(typename)
              db = false
            }
          }
        })
        // 为了不影响不懂的逻辑，清除数据
        this.treeForm.sortID = ''
        if (!db) {
          this.$message('分类名称不能相同！')
          return
        }
        // 分类名称重复判断--end---
        if (that.isEditTree === true) {
          that.treeDataEdit.sortName = that.treeForm.typename
          console.log(that.newBiaoData)
          let newDataList = that.treeForm.domains
          let params = {}
          let shuzu = []
          if (that.treeForm.dybq !== '') {
            params.labelId = that.treeForm.dybq
            shuzu[0] = params
          }
          let data = shuzu.concat(newDataList)
          that.treeDataEdit.labels = data
          if (that.newBiaoData.length > 0) {
            console.log(that.newBiaoData)
            that.treeDataEdit.labels.push(...that.newBiaoData)
          }
          console.log(that.treeDataEdit.labels)
          this.$message({
            type: 'success',
            message: '已保存!',
          })
          console.log(that.treeData)
          that.addTypeDisabled = false
          that.addTreeTypeYes = false
          that.edittree = false
          that.clearAddShow = false
          that.treeJieId = ''
          that.treeForm.typename = ''
          that.treeForm.type = '无'
          that.isEditTree = false
          that.treeForm.sortID = ''
          that.newBiaoData = []
        } else {
          // 添加分类
          let object = {}
          object.sortName = that.treeForm.typename
          // object.sortID = that.getUUID()
          object.sortID = that.getUUID()
          object.children = []
          object.count = 64
          object.otherCount = 64
          object.labels = []
          let params = {}
          if (that.treeForm.dybq !== '') {
            params.labelId = that.treeForm.dybq
            object.labels.push(params)
          }
          let dData = []
          if (that.treeForm.domains.length > 0) {
            for (let p = 0; p < that.treeForm.domains.length; p++) {
              dData[p] = {
                add: that.treeForm.domains[p].add,
                labelId: that.treeForm.domains[p].labelId,
                labelName: that.treeForm.domains[p].labelName,
                relation: that.treeForm.domains[p].relation,
              }
              object.labels.push(dData[p])
            }
          }
          let nData = []
          if (that.newBiaoData.length > 0) {
            for (let n = 0; n < that.newBiaoData.length; n++) {
              nData[n] = {
                add: that.newBiaoData[n].add,
                avgSpeedMax: that.newBiaoData[n].avgSpeedMax,
                avgSpeedMin: that.newBiaoData[n].avgSpeedMin,
                classId: that.newBiaoData[n].classId,
                className: that.newBiaoData[n].className,
                firstRecordTimeMax: that.newBiaoData[n].firstRecordTimeMax,
                keyWordJsonStr: that.newBiaoData[n].keyWordJsonStr,
                labelId: that.newBiaoData[n].labelId,
                labelName: that.newBiaoData[n].labelName,
                overlapMax: that.newBiaoData[n].overlapMax,
                overlapMin: that.newBiaoData[n].overlapMin,
                relation: that.newBiaoData[n].relation,
                silenceLongMax: that.newBiaoData[n].silenceLongMax,
                silenceLongMin: that.newBiaoData[n].silenceLongMin,
                silenceType: that.newBiaoData[n].silenceType,
              }
              object.labels.push(nData[n])
            }
          }
          let objShuZu = []
          that.treeData.forEach((item) => {
            let obj = {}
            for (let v in item) {
              obj[v] = item[v]
            }
            objShuZu.push(obj)
          })
          if (that.treeForm.type !== '无') {
            object.parentSortID = that.treeDataEdit.sortID
            that.treeDataEdit.children.push(object)
          } else {
            object.parentSortID = that.sortID
            that.treeData.push(object)
          }
          this.$message({
            type: 'success',
            message: '已保存!',
          })
          that.addTreeTypeYes = false
          that.clearAddShow = false
          that.treeForm.typename = ''
          that.treeForm.type = '无'
          that.treeForm.sortID = ''
          that.newBiaoData = []
          that.treeForm.domains = [
            {
              relation: '',
              add: '',
              labelName: '',
              labelId: '',
            },
          ]
        }
        that.isEditTree == false
        that.edittree = false
        that.addTypeDisabled = false
        that.saveDisabled = false
      }
    },
    quXiao() {
      let that = this
      that.dialogVisible = false
      that.addTreeTypeYes = false
      that.edittree = false
      that.addTypeDisabled = false
      that.treeForm.typename = ''
      that.clearAddShow = false
      that.treeForm.domains = []
      that.treeForm.treeSelectOption = ''
      that.newBiaoData = []
      that.showNewLabel = false
    },
    // 新建/编辑 分类树 点击 确定
    treeFormSave() {
      let that = this
      console.log()
      that.$refs['treeForm'].validate((valid) => {
        if (valid) {
          let paramsList = {
            sortName: that.treeForm.treeSelectOption.label,
            parentSortID: '0',
            children: that.treeData,
            sortID: that.sortID,
          }
          if (that.treeTitle === '编辑分类树') {
            that.axios
              .put(requestUrls['getTreeType'], paramsList, {
                headers: {
                  'Content-Type': 'application/json',
                  'prefer-service-zone': 'fangjunhao',
                  accessToken: this.$store.state.token,
                },
              })
              .then((response) => {
                if (response.data.code === 0) {
                  that.$message.success('分类树编辑成功')
                  // 脏代码，塞入改动后的数据，绑定更新
                  this.treeList.forEach((val, i) => {
                    if (val.sortID === paramsList.sortID) {
                      this.treeList[i].sortName = paramsList.sortName
                    }
                  })
                }
                if (response.data.code === 500) {
                  this.$message.error(response.data.message)
                }
              })
              .catch(() => {})
            this.dialogDbBack()
          } else {
            const sortName = paramsList.sortName
            let db = true
            this.treeList.forEach((val) => {
              if (val.sortName === sortName) {
                this.$message('分类名称不能相同！')
                db = false
              }
            })
            if (db) {
              console.log()
              this.axios
                .post(requestUrls['getTreeType'], paramsList, {
                  headers: {
                    'Content-Type': 'application/json',
                    'prefer-service-zone': 'fangjunhao',
                    accessToken: this.$store.state.token,
                  },
                })
                .then((response) => {
                  if (response.data.code === 0) {
                    this.$message.success('分类树添加成功')
                    that.getTreeType()
                  }
                  if (response.data.code === 500) {
                    this.$message.error(response.data.message)
                  }
                })
                .catch(() => {})
              this.dialogDbBack()
            }
          }
        }
      })
      this.showNewLabel = false
    },
    // 获取分类树
    getTreeType() {
      let that = this
      this.axios({
        method: 'get',
        url: requestUrls['getTreeType'],
      })
        .then((response) => {
          that.sortIDPID = response.data.data[0].sortID
          that.sortID = response.data.data[0].sortID
          that.resultLabelId = response.data.data[0].sortID
          that.treeList = response.data.data
          that.activeName = response.data.data[0].sortID
          that.dName = response.data.data[0].sortName
          that.tName = response.data.data[0].sortName
          let dataNew = that.treeList
          if (that.treeSelectOptions.length > 0) {
          } else {
            for (let i = 0; i < dataNew.length; i++) {
              let dataH = {}
              dataH.value = dataNew[i].sortID
              dataH.label = dataNew[i].sortName
              that.treeSelectOptions.push(dataH)
              console.log(that.treeSelectOptions)
            }
          }
          that.getTreeListBySortID()
        })
        .catch(() => {})
    },
    submitted(data) {
      let that = this
      this.$refs.addRecordLabelComponent.showDialog = false
    },
    // 关闭标签弹框
    close() {
      let that = this
      that.$refs.addRecordLabelComponent.showDialog = false
    },
    // 添加新标签传值过来
    formData(data) {
      console.log(data)
      let that = this
      that.$refs.addRecordLabelComponent.showDialog = false
      if (that.editType === 'edit') {
        that.newBiaoData.splice(that.editNewBiaoIndex, 1)
        that.newBiaoData.push(data)
      } else {
        that.newBiaoData.push(data)
        if (that.newBiaoData.length > 0) {
          that.areadyYes = true
        }
      }
    },
    getExistTopic() {
      this.axios
        .post(requestUrls['getExistTopic'])
        .then((res) => {
          if (res.data) {
            this.existTopicData = res.data
            let existTopicDataMap = {}
            if (res.data != null && res.data.length > 0) {
              for (let i = 0; i < res.data.length; i++) {
                let topicName = res.data[i].topicName
                if (topicName != null && topicName != '') {
                  existTopicDataMap[topicName] = res.data[i].topicClusterId
                }
              }
            }
            this.existTopicDataMap = existTopicDataMap
          }
        })
        .catch(() => {})
    },
    // 获取所有启用标签
    getAllInProgress() {
      this.axios
        .get(requestUrls['getAllInProgress'])
        .then((res) => {
          if (res.data.data.length > 0) {
            // that.treeForm.dybq = res.data.data[0].labelId
            this.biaoqianList = res.data.data
          }
        })
        .catch(() => {
          this.$message.error('获得启用标签异常！')
        })
    },
    dialogDbBack() {
      this.dropSuccess = false
      this.dialogVisible = false
      this.treeForm.type = '无'
      this.addTypeDisabled = false
      this.edittree = false
      this.getTreeType()
      this.showNewLabel = false
    },
    // 获取某个分类树下面的tree结构
    getTreeListBySortID() {
      let that = this
      this.loading = true
      this.treeData = []
      this.axios
        .get(requestUrls['getTreeListBySortID'] + '/' + that.sortID)
        .then(function(res) {
          // 复制成功 给 显示tree节点
          that.sortLabel = res.data.data.sortName
          that.counts = res.data.data.count
          let childs = res.data.data.children
          let shuzuList = []
          if (childs.length > 0) {
            for (let i = 0; i < childs.length; i++) {
              shuzuList[i] = {
                sortName: childs[i].sortName,
                sortID: childs[i].sortID,
                count: childs[i].count,
                labels: null,
                otherCount: childs[i].otherCount,
                parentSortID: childs[i].parentSortID,
                children: that.getChildS(childs[i].children, [], childs[i]),
              }
            }
          }
          that.tDataAddOtherChild = Object.assign(shuzuList)
          that.tData = Object.assign(childs) // 获取下面的tree结构
          this.loading = false
        })
        .catch(() => {
          this.loading = false
        })
    },
    getUUID() {
      return Number(
        Math.random()
          .toString()
          .substr(3, length) + Date.now()
      ).toString(36)
    },
    lizationList() {
      let params = {
        clusterRuleId: this.message,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getTopicClusterData.do',
          Qs.stringify(params)
        )
        .then((resp) => {
          console.log(resp.data.data)
          this.data5 = resp.data.data
          this.sumTitle = resp.data.topicCount
          this.vedioLong = resp.data.recordCount
          this.firstIds = resp.data.firstTopicClusterId
          this.treeDataId = this.firstIds
          let sendVael = {
            clusterTopicId: this.firstIds,
            pageNumber: this.currentPage,
            pageSize: this.pageSize,
          }
          this.collapseLoading = true
          this.axios
            .post(
              currentBaseUrl + '/ivsClusterRule/getClusterTopicRecordDetailByTopicId.do',
              Qs.stringify(sendVael)
            )
            .then((resp) => {
              this.collapseLoading = false
              this.ghlArr = resp.data.data
              this.total = resp.data.count
              this.topName = resp.data.topicName
              this.readId = this.firstIds
              if (resp.data.topicKeyword == null || resp.data.topicName == null) {
                this.topKey = resp.data.topicKeyword
              } else {
                this.topKey = '(' + resp.data.topicKeyword + ')'
              }
              console.log(this.topName)
            })
        })
    },
  },
  mounted: function() {
    this.lizationList()
    this.filter()
  },
  computed: {
    eUrl() {
      return (
        requestUrls['clusterResultExport'] +
        '?clusterRuleId=' +
        this.message +
        '&accessToken=' +
        this.$store.state.token
      )
    },
  },
  created() {},
}
</script>
<style lang="less" scoped="scoped">
.startBox {
  transition: all 0.5s;
}
.secondBox {
  transform: rotate(-180deg);
  transition: all 0.5s;
}
.flex-box {
  display: flex;
  flex-flow: row wrap;
  width: 700px;
  .flex-box-list {
    width: 50%;
  }
}
.fn-bor-b-c {
  border-bottom: 1px solid #d1d9e2;
  padding-bottom: 20px;
}
.editIcon {
  float: right;
  margin-right: 5px;
  font-size: 26px;
  cursor: pointer;
}
.overWide {
  display: inline-block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  position: absolute;
  left: 0px;
}
#soundfeature {
  box-sizing: border-box;
  height: 100%;
  width: 100%;
  overflow: hidden;
  .conpalinDiv {
    width: 100%;
  }
  .autoGrading-page {
    height: 35px;
    position: absolute;
    background: white;
    right: 0px;
    bottom: 0px;
    text-align: right;
    .el-pagination {
      display: inline-block;
      height: 28px;
      line-height: 28px;
      padding: 0px 10px;
    }
  }
  .cluster-result-right {
    position: absolute;
    right: 20px;
  }
}
</style>
<style lang="less">
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
#blockDiv .el-tree {
  padding: 20px;
}
.edealFind .el-collapse {
  border-bottom: 0px solid #ebeef5;
}
.edealFind .el-collapse-item__header {
  height: 100%;
}
.add-type {
  margin: 18px 0 10px 10px;
  font-size: 14px;
  display: block;
  cursor: pointer;
}
.el-dialog-box-clor {
  background: #eff2f7;
  padding: 10px 0;
}
#xyaudioMore .newBiaoQian {
  width: 100%;
  float: left;
}
#xyaudioMore .newBiaoQian .lists {
  margin: 10px;
}
#xyaudioMore .newBiaoQian span {
  float: right;
  display: inline;
  padding-right: 10px;
  color: #20a0ff;
  cursor: pointer;
}
#xyaudioMore .newBiaoQian p {
  display: inline;
  float: left;
  font-size: 14px;
  color: #222;
}
#xyaudioMore .el-dropdown-box {
  margin: 10px 0 18px 10px;
}
#xyaudioMore .el-collapse-item__header {
  height: auto !important;
  display: block !important;
}
#xyaudioMore .el-collapse-item__arrow {
  display: none !important;
}
#xyaudioMore .play {
  position: absolute;
  height: 120px;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  background: rgba(00, 00, 00, 0.4);
  text-align: center;
  line-height: 145px;
}
#xyaudioMore .play img {
  display: inline;
  width: 51px;
  height: 51px;
}
#xyaudioMore .recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
.single {
  &.el-dialog__wrapper {
    position: fixed;
    top: 106px;
    left: 20px;
    right: 20px;
    bottom: 12px;
    .el-dialog {
      width: 100%;
      height: 100%;
      margin: 0 !important;
    }
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}
</style>
