<template>
  <div id="enableThesa" class="enableThesa">
    <div class="addTrainSampleHeader" v-if="this.pageType != 3">
      <ul>
        <li><p>填写主题聚类</p></li>
        <li><p>添加训练样本</p></li>
        <li>
          <p>启用词表</p>
          <img src="../../../assets/img/icon-yuan.png" />
        </li>
      </ul>
    </div>
    <div v-else=""></div>
    <div class="enableContent">
      <div class="enableTable">
        <div id="content">
          <div class="formHeader">
            <el-form
              :inline="true"
              :model="formInline"
              class="demo-form-inline"
              style="padding-top: 10px"
            >
              <el-form-item label="词汇">
                <el-input v-model="formInline.wordName" placeholder="请输入"></el-input>
              </el-form-item>
              <el-form-item label="应用状态">
                <el-select v-model="formInline.useStatus" clearable>
                  <el-option value="1" label="启用">启用</el-option>
                  <el-option value="2" label="停用">停用</el-option>
                </el-select>
              </el-form-item>
              <!--<el-form-item label="来源">
                <el-select v-model="formInline.wordSource" clearable>
                  <el-option value="1" label="算法输出">算法输出</el-option>
                  &lt;!&ndash;<el-option  value="2" label="手工添加">手工添加</el-option>&ndash;&gt;
                </el-select>
              </el-form-item>-->
              <el-form-item>
                <el-button type="primary" @click="search">查询</el-button>
              </el-form-item>
            </el-form>
            <div class="top">
              <span>应用状态为启用的词汇数:{{ numsCount }}</span>
              <el-button class="fr" @click="del">删除</el-button>
              <el-button class="fr" style="margin-right: 10px" @click="batchStart(1)"
                >批量启动</el-button
              >
              <el-button class="fr" @click="batchStart(2)">批量停用</el-button>
              <i
                class="el-icon-d-caret fr"
                @click="sortQuery"
                style="cursor:pointer;margin-top:25px"
                >词频</i
              >
            </div>
          </div>
          <div class="tableContent">
            <div class="table" style="width: 100%; height: 100%; overflow: auto">
              <el-table
                ref="multipleTable"
                :data="tableData3"
                border
                tooltip-effect="dark"
                style="width: 100%"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"> </el-table-column>
                <el-table-column prop="wordName" label="词汇" width="120">
                </el-table-column>
                <el-table-column prop="docNum" label="词频" sortable width="120">
                </el-table-column>
                <el-table-column prop="useStatus" label="应用状态">
                  <template scope="scope">
                    <div v-if="scope.row.useStatus === 1">
                      <el-tag type="success">启用</el-tag>
                    </div>
                    <div v-else="">
                      <el-tag type="gray">停用</el-tag>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column
                  prop="createTime"
                  label="生成时间"
                  :formatter="dateFormat"
                  show-overflow-tooltip
                >
                </el-table-column>
              </el-table>
            </div>
            <div class="pages">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageindex"
                :page-sizes="[20, 30, 40, 200]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </div>
      <div class="enableBottom" v-if="this.pageType != 3">
        <el-button type="primary" @click="start">开始</el-button>
        <el-button @click="prev">上一步</el-button>
        <el-button @click="canel">取消</el-button>
      </div>
      <div v-else=""></div>
    </div>
  </div>
</template>
<script>
import Qs from 'qs'
import global from '../../../global.js'
import formatdate from '../../../utils/formatdate.js'
let currentBaseUrl = global.currentBaseUrl
export default {
  data() {
    return {
      sortType: false,
      numsCount: 0,
      isShow: true,
      isShowTwo: false,
      value1: false,
      value2: true,
      addForm: {
        name: '',
      },
      pageindex: 1,
      pagesize: 10,
      totalCount: 0,
      tableData3: [
        {
          date: '2016-05-03',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-04',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-01',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-08',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-06',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-07',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
      ],
      formInline: {
        wordName: '',
        useStatus: '',
        wordSource: '',
      },
      clusterWordIds: '',
      clusterWordId: '',
      norNameList: '',
      selectionNums: '',
    }
  },
  methods: {
    // 批量停用、启用
    batchStart: function(val) {
      let that = this
      if (that.clusterWordIds == '') {
        this.$message({
          type: 'warning',
          message: '至少选择一条数据',
        })
      } else {
        let uSta
        if (val == 1) {
          uSta = 'enable'
        } else {
          uSta = 'disable'
        }
        let params = {
          clusterWordIds: that.clusterWordIds,
          useStatus: uSta,
        }
        this.axios
          .post(
            currentBaseUrl + '/ivsClusterRule/bulkUpdateClusterWordUseStatus.do',
            Qs.stringify(params)
          )
          .then((res) => {
            this.getClusterWordData()
            this.getEnableClusterWordNum()
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    change: function(val, id) {
      let enableTitle
      if (val == 1) {
        enableTitle = 'disable'
      } else {
        enableTitle = 'enable'
      }
      let params = {
        clusterWordIds: this.clusterWordIds,
        useStatus: enableTitle,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/bulkUpdateClusterWordUseStatus.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.getClusterWordData()
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     *词频排序
     * **/
    sortQuery() {
      this.sortType = !this.sortType
      if (this.sortType) {
        this.getClusterWordData()
      } else {
        this.getClusterWordDataByWordnum()
      }
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    canel: function() {
      this.$router.push('/clusterRule_hrlist')
    },
    // 点击开始
    start: function() {
      let params = {
        clusterRuleId: this.clusterRuleId,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/createClusterRuleModel.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.$router.push('/clusterRule_hrlist')
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 点击删除
    del: function() {
      if (this.clusterWordIds == '') {
        this.$message({
          type: 'warning',
          message: '至少选择一条数据',
        })
      } else {
        this.delClusterWord()
      }
    },
    // table全选
    handleSelectionChange: function(selection) {
      if (selection) {
        let nums = selection
        let tids = []
        for (let i = 0; i < nums.length; i++) {
          tids[i] = nums[i].clusterWordId
        }
        let newId = tids.join(',')
        this.clusterWordIds = newId

        let names = []
        for (let i = 0; i < nums.length; i++) {
          names[i] = nums[i].wordName
        }
        let norName = names
        this.norNameList = norName.slice(0, 3)
        this.selectionNums = selection.length
      }
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.getClusterWordData()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.getClusterWordData()
    },
    prev: function() {
      this.$router.push('/addTrainSample')
    },
    // 查询
    search() {
      this.getClusterWordData()
    },
    // 删除聚类规则的词语 传ids
    delClusterWord: function() {
      let params = {
        clusterWordIds: this.clusterWordIds,
      }
      this.$confirm(
        '确定要删除【' + this.norNameList + '】等' + this.selectionNums + '个项目吗？',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      )
        .then(() => {
          this.axios
            .post(
              currentBaseUrl + '/ivsClusterRule/delClusterWord.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data) {
                this.$message({
                  type: 'success',
                  message: '删除成功',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '删除失败',
                })
              }
              this.getClusterWordData()
            })
            .catch(function(error) {
              console.log(error)
            })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
          this.$refs.multipleTable.clearSelection()
        })
    },
    // 批量停用或者启用词语
    WordUseStatus: function() {
      let params = {
        clusterWordIds: this.clusterRuleId,
        useStatus: 'disable',
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/bulkUpdateClusterWordUseStatus.do',
          Qs.stringify(params)
        )
        .then((res) => {
          console.log(res.data)
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 查询词表
    getClusterWordData: function() {
      let params = {
        clusterRuleId: this.clusterRuleId,
        pageindex: this.pageindex,
        pagesize: this.pagesize,
        jsonStr: JSON.stringify({
          clusterRuleId: this.clusterRuleId,
          wordName: this.formInline.wordName,
          useStatus: this.formInline.useStatus,
        }),
        sort: JSON.stringify({ docNum: 1 }),
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getClusterWordData.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.tableData3 = res.data.Data
          this.totalCount = res.data.Count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    getClusterWordDataByWordnum: function() {
      let params = {
        clusterRuleId: this.clusterRuleId,
        pageindex: this.pageindex,
        pagesize: this.pagesize,
        jsonStr: JSON.stringify({
          clusterRuleId: this.clusterRuleId,
          /* wordSource: this.formInline.wordSource, */
          wordName: this.formInline.wordName,
          useStatus: this.formInline.useStatus,
        }),
        sort: JSON.stringify({ docNum: 0 }),
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getClusterWordData.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.tableData3 = res.data.Data
          this.totalCount = res.data.Count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 查询启动词表的数量
    getEnableClusterWordNum: function() {
      let params = {
        clusterRuleId: this.clusterRuleId,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getEnableClusterWordNum.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.numsCount = res.data.endableWordNum
        })
        .catch(function(error) {
          console.log(error)
        })
    },
  },
  computed: {
    pageType() {
      return this.$store.state.StringData.pageType
    },
    clusterRuleId() {
      return this.$store.state.StringData.clusterRuleId
    },
  },
  mounted() {
    this.getClusterWordData()
    this.getEnableClusterWordNum()
  },
}
</script>
<style lang="less" scoped="scoped">
.enableThesa {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .addTrainSampleHeader {
    float: left;
    margin-top: 10px;
    box-sizing: border-box;
    top: 0px;
    height: 60px;
    width: 100%;
    border-bottom: 1px dashed #d1dbe5;
    background-color: #eef1f6;
    p {
      width: 100%;
      height: 34px;
      text-align: center;
    }
    ul {
      text-align: center;
      list-style: none;
      li {
        float: left;
        display: inline-block;
        font-size: 14px;
        text-align: center;
        color: #5e6d82;
        line-height: 60px;
        font-weight: bold;
        width: 30%;
        img {
          width: 99px;
          display: inline;
        }
      }
    }
  }
  .enableContent {
    padding-top: 78px;
    padding-bottom: 60px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    .enableBottom {
      width: 100%;
      text-align: right;
      padding-top: 10px;
      float: right;
      box-sizing: border-box;
      border-top: 1px solid #d1dbe5;
      right: 10px;
      bottom: 10px;
    }
    .enableTable {
      width: 100%;
      height: 100%;
      overflow: auto;
      #content {
        width: 100%;
        padding: 0 10px;
        box-sizing: border-box;
        height: 100%;
        position: relative;
        .tableContent {
          padding-top: 130px;
          padding-bottom: 60px;
          box-sizing: border-box;
          width: 100%;
          height: 100%;
          .pages {
            right: 10px;
            position: absolute;
            bottom: 10px;
          }
        }
        .formHeader {
          float: left;
          box-sizing: border-box;
          top: 0px;
          height: 120px;
          width: 100%;
          .top {
            height: 60px;
            border-top: 1px dashed #d1dbe5;
            padding-top: 10px;
          }
        }
      }
    }
  }
}
</style>
<style>
#enableBottom .enableHeader img {
  display: inline;
}
</style>
