<template>
  <div id="addTrainSample" class="addTrainSample">
    <div v-if="this.pageType == 1">
      <div class="addTrainSampleHeader">
        <ul>
          <li><p>填写主题聚类</p></li>
          <li>
            <p>添加训练样本</p>
            <img src="../../../assets/img/icon-yuan.png" />
          </li>
          <li>启用词表</li>
        </ul>
      </div>
    </div>
    <div v-else=""></div>
    <div class="addTrainSampleContent">
      <div class="table">
        <div id="cols">
          <el-row>
            <el-col :span="12" :class="hidden ? 'hidden' : ''">
              <div class="addTrainLeft">
                <div class="header">
                  <span style="font-size: 14px">筛选条件</span>
                  <div class="btns">
                    <el-button type="primary" @click="search">查询</el-button>
                    <el-button @click="resetSearchForm">清空</el-button>
                  </div>
                </div>
                <div class="content">
                  <my-comp ref="myComp"></my-comp>
                </div>
              </div>
            </el-col>
            <el-col :span="rightSpan">
              <div class="tableListSecond">
                <div
                  class="toggleBtn"
                  @click="toggleContainer"
                  :class="hidden ? 'toggle-hidden' : 'toggle-show'"
                ></div>
                <div id="list">
                  <div class="search">
                    <el-radio-group v-model="displayType" @change="change">
                      <el-radio class="radio" :label="2">按数据展示</el-radio>
                      <el-radio class="radio" :label="1">按详情展示</el-radio>
                    </el-radio-group>
                    <div style="float: right">
                      <el-select
                        @change="selectChange"
                        v-model="value"
                        placeholder="请选择"
                      >
                        <el-option
                          v-for="item in options"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"
                        >
                        </el-option>
                      </el-select>
                      <!--<el-badge :value="0" class="item">
                        <el-button @click="getNoneCheck" size="small" class="icon-bg" style="border:none"> </el-button>
                      </el-badge><br/>
                      <el-badge :value="totalCountJoin" class="item">
                        <el-button @click="getMyCheck" size="small" class="icon-bg" style="border:none"> </el-button>
                      </el-badge>-->
                    </div>
                    <el-button @click="join">加入样本</el-button>
                    <div v-show="this.isShowSelectAll == true">
                      <!-- <el-button @click="selectAllSample" v-if="selectAllBtn" style="float: left; margin-left: 10px;">全选</el-button>
                       <el-button @click="canelSelectAllSample" v-if="!selectAllBtn" style="float: left; margin-left: 10px;">全不选</el-button>-->
                    </div>
                  </div>
                  <div class="tableBox">
                    <div class="tableGroup" style="overflow: auto; padding-left: 10px">
                      <el-table
                        filter-multiple
                        toggleRowSelection
                        id="tableListOne"
                        ref="multipleTable"
                        :data="detailTableData"
                        border
                        tooltip-effect="dark"
                        style="width: 100%; display: none"
                        @selection-change="selectAll"
                      >
                        <el-table-column reserve-selection type="selection" width="55">
                        </el-table-column>
                        <el-table-column prop="callId" label="录音编号" width="120">
                          <template scope="scope">
                            <el-button
                              type="text"
                              @click="
                                showDetail(scope.row.callId, scope.row.recordFileURL)
                              "
                              >{{ scope.row.callId }}
                            </el-button>
                          </template>
                        </el-table-column>
                        <el-table-column
                          prop="callSTime"
                          sortable
                          :formatter="dateFormat"
                          label="录音时间"
                          width="120"
                        >
                        </el-table-column>
                        <el-table-column
                          prop="seatName"
                          label="坐席姓名"
                          show-overflow-tooltip
                        >
                        </el-table-column>
                      </el-table>
                      <el-checkbox-group v-model="checkedRecordList" id="tableDetailOne">
                        <div
                          class="sampleList"
                          v-for="item in detailTableData"
                          @mouseenter="tapeEnter"
                          @mouseleave="tapeLeave"
                          style="cursor: pointer;position: relative;"
                        >
                          <div class="sample-header">
                            <el-checkbox
                              size="small"
                              :key="item.callId"
                              :label="item.callId"
                            ></el-checkbox>
                            <span
                              >录音编号<span
                                @click="showDetail(item.callId, item.recordFileURL)"
                                class="callId"
                                >{{ item.callId }}</span
                              ></span
                            >
                          </div>
                          <div
                            class="sample-content"
                            @mouseenter="showPlay"
                            @mouseleave="hidePlay"
                          >
                            <div style="padding: 10px;">{{ item.wholeContent }}</div>
                            <div
                              class="play"
                              @click="showDetail(item.callId, item.recordFileURL)"
                            >
                              <img src="../../../assets/img/u493.png" />
                            </div>
                          </div>
                          <div class="sample-footer">
                            <span class="seatName">坐席姓名：{{ item.seatName }}</span>
                            <span>录音时长：{{ getCallTime(item.callTime) }}</span>
                          </div>
                        </div>
                      </el-checkbox-group>
                    </div>
                    <div class="tablePage">
                      <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="pageindex"
                        :page-sizes="[20, 30, 40, 200]"
                        :page-size="pagesize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="totalCount"
                      >
                      </el-pagination>
                    </div>
                  </div>
                </div>
                <div id="mydetail">
                  <div class="search">
                    <el-radio-group v-model="displayTypeRemove" @change="changeTwo">
                      <el-radio class="radio" :label="2">按数据展示</el-radio>
                      <el-radio class="radio" :label="1">按详情展示</el-radio>
                    </el-radio-group>
                    <el-button @click="delSample">移除训练样本</el-button>
                    <div
                      v-show="this.isShowSelectAllTwo == true"
                      style="float: left"
                    ></div>
                    <div style="float: right">
                      <el-select
                        @change="selectChange"
                        v-model="value"
                        placeholder="请选择"
                      >
                        <el-option
                          v-for="item in options"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"
                        >
                        </el-option>
                      </el-select>
                    </div>
                  </div>
                  <div class="tableBox">
                    <div class="tableGroup" style="overflow: auto; padding-left: 10px">
                      <el-table
                        filter-multiple
                        toggleRowSelection
                        id="tableListSecond"
                        ref="multipleTable"
                        :data="listTableData"
                        border
                        tooltip-effect="dark"
                        style="width: 100%; display: none"
                        @selection-change="selectAllTwo"
                      >
                        <el-table-column reserve-selection type="selection" width="55">
                        </el-table-column>
                        <el-table-column prop="callId" label="录音编号" width="120">
                          <template scope="scope">
                            <el-button
                              type="text"
                              @click="
                                showDetail(scope.row.callId, scope.row.recordFileURL)
                              "
                              >{{ scope.row.callId }}
                            </el-button>
                          </template>
                        </el-table-column>
                        <el-table-column
                          prop="callSTime"
                          :formatter="dateFormat"
                          sortable
                          label="录音时间"
                          width="120"
                        >
                        </el-table-column>
                        <el-table-column
                          prop="seatNo"
                          label="坐席姓名"
                          show-overflow-tooltip
                        >
                        </el-table-column>
                      </el-table>
                      <el-checkbox-group
                        v-model="checkedRecordListRemove"
                        id="tableDetailSecond"
                      >
                        <div
                          class="sampleList"
                          v-for="item in listTableData"
                          @mouseenter="tapeEnter"
                          @mouseleave="tapeLeave"
                          style="cursor: pointer;position: relative;"
                          :key="item.callId"
                        >
                          <div class="sample-header">
                            <el-checkbox :label="item.callId"></el-checkbox>
                            <span
                              >录音编号<span
                                @click="showDetail(item.callId, item.recordFileURL)"
                                class="callId"
                                >{{ item.callId }}</span
                              ></span
                            >
                          </div>
                          <div
                            class="sample-content"
                            @mouseenter="showPlayRemove"
                            @mouseleave="hidePlayRemove"
                          >
                            <div style="padding: 10px;">{{ item.wholeContent }}</div>
                            <div
                              class="playRemove"
                              @click="showDetail(item.callId, item.recordFileURL)"
                            >
                              <img src="../../../assets/img/u493.png" />
                            </div>
                          </div>
                          <!--<div class="sample-content" >{{item.wholeContent}}</div>
                          <a class="sample-content wholeContent">
                            <img class="img" src="../../../assets/img/u493.png">
                          </a>-->
                          <div class="sample-footer">
                            <span class="seatName">坐席姓名：{{ item.seatName }}</span>
                            <span>录音时长：{{ getCallTime(item.callTime) }}</span>
                          </div>
                        </div>
                      </el-checkbox-group>
                    </div>
                    <div class="tablePage">
                      <el-pagination
                        @size-change="handleSizeChangeJoin"
                        @current-change="handleCurrentChangeJoin"
                        :current-page="pageIndexJoin"
                        :page-sizes="[20, 30, 40, 200]"
                        :page-size="pageSizeJoin"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="totalCountJoin"
                      >
                      </el-pagination>
                    </div>
                  </div>
                </div>
              </div>
            </el-col>
          </el-row>
        </div>
      </div>
      <div class="pages" v-if="this.pageType == 1">
        <el-button @click="prev">上一步</el-button>
        <el-button type="primary" @click="next" :disabled="isTrue">下一步</el-button>
        <el-button @click="canel">取消</el-button>
      </div>
      <div class="pages" v-else=""></div>
    </div>
    <el-dialog
      :modal="false"
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import Qs from 'qs'
import formatdate from '../../../utils/formatdate.js'
import global from '../../../global.js'
import recordingplay from '../recordingPlay/recordingPlayNew.vue'
import bus from '../../common/bus.js'
import nativeaxios from 'axios'
import cache from '../../../utils/cache.js'
import addTrainSampleMyCompVue from './addTrainSampleMyComp.vue'

let currentBaseUrl = global.currentBaseUrl
let formEngineUrl = global.formEngineUrl
export default {
  components: {
    // 局部注册
    'my-comp': addTrainSampleMyCompVue,
    // 'my-comp': (resolve, reject) => {
    //   nativeaxios
    //     .post(
    //       formEngineUrl +
    //         '/creating.do?formIds=fastFilterLuyin,fastFilterYuangong,fastFilterKehu,fastFilterYuyin&accessToken=' +
    //         cache.getItem('tgt_id')
    //     )
    //     .then(function(response) {
    //       $('body').append(response.data.Validate)
    //       let myHtml = response.data.Html
    //       resolve({
    //         template: myHtml,
    //         watch: {
    //           // 监听
    //         },
    //         data() {
    //           return {
    //             /* eslint-disable */
    //             fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model: JSON.parse(
    //               JSON.stringify(
    //                 fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_
    //               )
    //             ),
    //             fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Rules: fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Rules,
    //             /* eslint-enable */
    //           }
    //         },
    //       })
    //     })
    // },
    recordingplay,
  },
  data() {
    return {
      recordDialogVisible: false,
      options: [
        {
          value: 1,
          label: '全部录音',
        },
        {
          value: 2,
          label: '样本池',
        },
      ],
      value: 1,
      displayType: 1,
      displayTypeRemove: 1,
      isShowSelectAllTwo: true,
      isShowSelectAll: true,
      isSelectAll: false,
      isSelectAllTwo: false,
      selectAllBtn: true,
      selectAllBtnTwo: true,
      checkListOne: {
        checkList: [],
      },
      checkListSecond: {
        checkList: [],
      },
      isTrue: false,
      listTableData: [],
      nums: '11',
      pageindex: 1,
      pagesize: 20,
      pageIndexJoin: 1,
      pageSizeJoin: 10,
      totalCount: 0,
      detailTableData: [],
      checkedRecordList: [], // 选中的录音列表
      checkedRecordListRemove: [], // 选中的录音列表
      // 获取row的key值
      getRowKeys(row) {
        return row.id
      },
      // 要展开的行，数值的元素是row的key值
      expands: [],
      formInline: {
        tapeCode: '', // 录音编号
        callingNumber: '', // 主叫号码
        calledNumber: '', // 被叫号码
        extensionNumber: '', // 分机号码
        tapeTime: [], // 录音时长
        callingTime: {
          callingTimeMax: '', // 通话时长最大值
          callingTimeMin: '', // 通话时长的最小值
        },
        systemRating: {
          // 系统评分值
          systemRatingMin: '',
          systemRatingMax: '',
        },
        tapeContent: {
          value1Type: '与',
          value1min: '',
          value1max: '',
          value2Type: '与',
          value2min: '',
          value2max: '',
          value3Type: '与',
          value3min: '',
          value3max: '',
        }, // 录音内容
      },
      joinid: '',
      callId: '',
      totalCountJoin: 0,
      cblist: '',
      delSampleId: '',
      cblisttwo: '',
      callIdTwo: '',
      valList: [],
      searchType: '0', // 查询未移入样本池样本'0'， 查询已移入样本池样本'1'
      hidden: false, // 左侧部分是否隐藏
    }
  },
  methods: {
    getCallTime(callTime) {
      if (callTime) {
        return (callTime / 1000).toFixed(2) + '秒'
      } else {
        return ''
      }
    },
    toggleContainer() {
      this.hidden = !this.hidden
    },
    // 清空表单
    resetSearchForm: function() {
      let _this = this
      this.$nextTick(function() {
        _this.$refs['myComp']['$refs'][
          'fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Ref'
        ].resetFields()
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model.wholeContent_firstKey =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model.wholeContent_firstLogic =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model.wholeContent_secondKey =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model.wholeContent_MidLogic =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model.wholeContent_thirdKey =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model.wholeContent_LastLogic =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model.wholeContent_LastKey =
          ''
      })
    },
    // 鼠标放到录音内容上时展示播放按钮
    showPlay() {
      event.target.querySelector('.play').style.display = 'block'
    },
    // 鼠标移出录音内容上时展示播放按钮
    hidePlay() {
      event.target.querySelector('.play').style.display = 'none'
    },
    // 鼠标放到录音内容上时展示播放按钮
    showPlayRemove() {
      event.target.querySelector('.playRemove').style.display = 'block'
    },
    // 鼠标移出录音内容上时展示播放按钮
    hidePlayRemove() {
      event.target.querySelector('.playRemove').style.display = 'none'
    },
    // 调到录音播放页
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'integratedSearchHr'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 取消
    canel: function() {
      this.$router.push('/clusterRule_hrlist')
    },
    // 获得已经加入样本的列表
    multipleEsQueryJoin: function() {
      let _this = this
      let searchModel = {}
      searchModel.pageNumber = this.pageIndexJoin
      searchModel.pageSize = this.pageSizeJoin
      searchModel.sortField = 'callSTime'
      searchModel.selectType = 'select'
      searchModel.sortType = 'DESC'
      searchModel.termRole = this.clusterRole
      searchModel.clusterRuleId = this.clusterRuleId
      let obj = {}
      obj.searchModel = JSON.parse(JSON.stringify(searchModel))
      obj.searchModel.searchType = this.searchType
      obj.searchModel.searchObj = _this.$refs['myComp']
        ? _this.$refs['myComp']
            .fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model
        : ''
      this.$store.commit('setRecordingPlayPage', obj)
      _this.getParams(
        searchModel,
        _this.$refs['myComp']
          .fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model
      )
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/multipleEsQuery.do',
          Qs.stringify(searchModel)
        )
        .then((res) => {
          this.listTableData = res.data.Data
          this.totalCountJoin = res.data.Count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    getMyCheck: function() {
      $('#mydetail').show()
      $('#list').hide()
      this.searchType = '1'
      this.multipleEsQueryJoin()
    },
    selectChange: function(val) {
      if (val == 1) {
        $('#mydetail').hide()
        $('#list').show()
        this.searchType = '0'
        this.multipleEsQuery()
      } else {
        $('#mydetail').show()
        $('#list').hide()
        this.searchType = '1'
        this.multipleEsQueryJoin()
      }
    },
    getNoneCheck: function() {
      $('#mydetail').hide()
      $('#list').show()
      this.searchType = '0'
      this.multipleEsQuery()
    },
    selectAllTwo: function(selection) {
      if (selection) {
        let nums = selection
        let tids = []
        for (let i = 0; i < nums.length; i++) {
          tids[i] = nums[i].callId
        }
        let newId = tids.join(',')
        this.callIdTwo = newId
      }
    },
    selectAll: function(selection) {
      if (selection) {
        let nums = selection
        let tids = []
        for (let i = 0; i < nums.length; i++) {
          tids[i] = nums[i].callId
        }
        let newId = tids.join(',')
        this.callId = newId
      }
    },
    // 加入样本
    join: function() {
      let joinList = this.checkedRecordList.join(',')
      let joinTableList = this.callId
      console.log(joinList.length)
      console.log('t' + joinTableList)
      if (joinList.length == 0 && joinTableList == '') {
        this.$message({
          type: 'warning',
          message: '请选择一条数据',
        })
      } else {
        this.$confirm('确认要加入样本吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
          .then(() => {
            let params = {
              selectCallIds: this.isShowSelectAll == true ? joinList : joinTableList,
              clusterRuleId: this.clusterRuleId,
            }
            this.axios
              .post(
                currentBaseUrl + '/ivsClusterRule/addToTrainSample.do',
                Qs.stringify(params)
              )
              .then((res) => {
                let data = res.data
                if (data['state'] === '1') {
                  this.$message.info(data['message'])
                } else {
                  this.$message.error(data['message'])
                }
                this.multipleEsQuery()
                this.checkedRecordList = []
                // this.multipleEsQueryJoin()
              })
              .catch(function(error) {
                console.log(error)
              })
          })
          .catch(() => {
            this.checkedRecordList = []
          })
      }
    },
    change: function(val) {
      if (val == 1) {
        $('#tableListOne').hide()
        $('#tableDetailOne').show()
        this.isShowSelectAll = true
      } else {
        $('#tableListOne').show()
        $('#tableDetailOne').hide()
        this.isShowSelectAll = false
      }
    },
    delSample: function() {
      let joinList = this.checkedRecordListRemove.join(',')
      let joinTableList = this.callIdTwo
      if (joinList.length == 0 && joinTableList == '') {
        this.$message({
          type: 'warning',
          message: '请选择要移除的数据',
        })
      } else {
        this.$confirm('确认要移除样本吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
          .then(() => {
            let params = {
              selectType: 'select',
              selectCallIds: this.isShowSelectAllTwo == true ? joinList : joinTableList,
              cancelCallIds: '',
              clusterRuleId: this.clusterRuleId,
              seatNo: '',
              seatName: '',
              customerName: '',
            }
            this.axios
              .post(
                currentBaseUrl + '/ivsClusterRule/delTrainSample.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data) {
                  this.$message({
                    type: 'success',
                    message: '操作成功',
                  })
                }
                // this.multipleEsQuery()
                this.multipleEsQueryJoin()
              })
              .catch(function(error) {
                console.log(error)
              })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '取消移除样本',
            })
            this.checkedRecordListRemove = []
          })
      }
    },
    changeTwo: function(val) {
      if (val == 1) {
        $('#tableDetailSecond').show()
        $('#tableListSecond').hide()
        this.isShowSelectAllTwo = true
      } else {
        $('#tableDetailSecond').hide()
        $('#tableListSecond').show()
        this.isShowSelectAllTwo = false
        this.isSelectAllTwo = false
      }
    },
    /**
     * 每页条数
     * **/
    handleSizeChangeJoin(val) {
      this.pageSizeJoin = val
      this.pageIndexJoin = 1
      this.multipleEsQueryJoin()
    },
    handleCurrentChangeJoin(val) {
      this.pageIndexJoin = val
      this.multipleEsQueryJoin()
    },
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.multipleEsQuery()
    },
    handleCurrentChange(val) {
      this.pageindex = val
      this.multipleEsQuery()
    },
    search: function() {
      if (this.searchType === '0') {
        this.multipleEsQuery()
      } else if (this.searchType === '1') {
        this.multipleEsQueryJoin()
      }
    },
    // 查询录音列表
    multipleEsQuery: function(strateObject) {
      let _this = this
      let searchModel = {}
      searchModel.pageNumber = _this.pageindex
      searchModel.pageSize = _this.pagesize
      searchModel.sortField = 'callSTime'
      searchModel.selectType = 'new'
      searchModel.sortType = 'DESC'
      searchModel.termRole = 0
      let obj = {}
      obj.searchModel = JSON.parse(JSON.stringify(searchModel))
      obj.searchModel.searchType = this.searchType
      obj.searchModel.searchObj = _this.$refs['myComp']
        ? _this.$refs['myComp']
            .fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model
        : ''
      this.$store.commit('setRecordingPlayPage', obj)
      if (strateObject) {
        _this.getParams(searchModel, strateObject)
      } else {
        _this.getParams(
          searchModel,
          _this.$refs['myComp']
            .fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model
        )
      }
      let keyword = ''
      if (strateObject) {
        keyword = _this.getKeyword(strateObject)
      } else {
        keyword = _this.getKeyword(
          _this.$refs['myComp']
            .fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model
        )
      }
      searchModel['wholeContent'] = keyword
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/multipleEsQuery.do',
          Qs.stringify(searchModel)
        )
        .then((res) => {
          _this.detailTableData = res.data.Data
          _this.totalCount = res.data.Count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    getKeyword(params) {
      let str = ''
      if (params['wholeContent_firstKey']) {
        str += params['wholeContent_firstKey'] + ' '

        if (params['wholeContent_firstLogic'] && params['wholeContent_secondKey']) {
          str +=
            params['wholeContent_firstLogic'] + ' ' + params['wholeContent_secondKey']
          if (params['wholeContent_MidLogic']) {
            if (params['wholeContent_thirdKey']) {
              str += ' ' + params['wholeContent_MidLogic'] + ' '
              str += params['wholeContent_thirdKey'] + ' '
              if (params['wholeContent_LastLogic'] && params['wholeContent_LastKey']) {
                str +=
                  params['wholeContent_LastLogic'] + ' ' + params['wholeContent_LastKey']
              }
            }
          }
        }
      }

      return str
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    getParams(param, formId) {
      for (let item in formId) {
        if (typeof formId[item] === 'string') {
          param[item] = formId[item]
        } else if (formId[item] instanceof Array) {
          if (formId[item].length === 2) {
            param[item + '_Min'] = formatdate.formatDate(formId[item][0])
            param[item + '_Max'] = formatdate.formatDate(formId[item][1])
          } else {
            param[item + '_Min'] = ''
            param[item + '_Max'] = ''
          }
        } else if (typeof formId[item] === 'object') {
          for (let jtm in formId[item]) {
            param[jtm] = formId[item][jtm]
          }
        }
      }
      return param
    },
    tapeEnter(event) {
      // 鼠标警告录音列表
      $(event.target)
        .children('a')
        .removeClass('dn')
    },
    tapeLeave(event) {
      // 鼠标离开录音列表
      $(event.target)
        .children('a')
        .addClass('dn')
    },
    // 下一步
    next: function() {
      this.$router.push('/enableThesaurus')
    },
    prev: function() {
      this.$router.push('/clusterRule_hrlist')
    },
  },
  mounted() {
    if (!this.clusterRuleId) {
      this.$router.push('/clusterRule_hrlist')
    } else {
      if (
        this.recordingPlayPage.fromPage === 'addTrainSample' &&
        this.recordingPlayPage.searchModel.searchType
      ) {
        this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_Model = this.recordingPlayPage.searchModel.searchObj
        if (this.recordingPlayPage.searchModel.searchType === '1') {
          this.pageIndexJoin = this.recordingPlayPage.searchModel.pageNumber
          this.pageSizeJoin = this.recordingPlayPage.searchModel.pageSize
          this.clusterRole = this.recordingPlayPage.searchModel.termRole
          this.clusterRuleId = this.recordingPlayPage.searchModel.clusterRuleId
          this.getMyCheck()
        } else if (this.recordingPlayPage.searchModel.searchType === '0') {
          this.pageindex = this.recordingPlayPage.searchModel.pageNumber
          this.pageSize = this.recordingPlayPage.searchModel.pageSize
          this.getNoneCheck()
        }
      }
    }
  },
  created() {},
  computed: {
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
    pageType() {
      return this.$store.state.StringData.pageType
    },
    clusterRuleId() {
      return this.$store.state.StringData.clusterRuleId
    },
    clusterRole() {
      return this.$store.state.StringData.clusterRole
    },
  },
}
</script>
<style scoped="scoped" lang="less">
@border-color: #d1dbe5;
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}

.addTrainSample {
  width: 100%;
  padding: 0 10px;
  /* top: 1px; */
  box-sizing: border-box;
  height: 100%;
  position: relative;
}

.addTrainSample .addTrainSampleHeader {
  float: left;
  box-sizing: border-box;
  top: 0px;
  margin-top: 10px;
  height: 60px;
  width: 100%;
  border-bottom: 1px solid #d1dbe5;
  background-color: #eef1f6;
}

.addTrainSample .addTrainSampleHeader p {
  width: 100%;
  height: 34px;
  text-align: center;
}

.addTrainSample .hidden {
  display: none;
}

.addTrainSample .toggleBtn {
  cursor: pointer;
  width: 20px;
  height: 30px;
  background-image: url('../../../assets/img/close.png');
  position: absolute;
  left: -20px;
  top: 45%;
  bottom: 0px;
  z-index: 999;
}

.addTrainSample .toggle-hidden {
  left: -10px;
  transform: rotate(180deg);
}

.addTrainSample .addTrainSampleHeader ul {
  text-align: center;
  list-style: none;
}

.addTrainSample .addTrainSampleHeader ul li {
  float: left;
  display: inline-block;
  font-size: 14px;
  text-align: center;
  color: #5e6d82;
  line-height: 60px;
  font-weight: bold;
  width: 30%;
}

.addTrainSample .addTrainSampleHeader ul li img {
  width: 99px;
  display: block;
}

.addTrainSample .addTrainSampleContent {
  padding-top: 78px;
  padding-bottom: 60px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}

.addTrainSample .addTrainSampleContent .table {
  width: 100%;
  height: 100%;
}

.addTrainSample .addTrainSampleContent .table #cols {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
}

.el-row {
  height: 100%;
  .el-col {
    height: 100%;
  }
}

.addTrainSample .addTrainSampleContent .pages {
  right: 10px;
  position: absolute;
  bottom: 10px;
}

.addTrainSample .addTrainSampleContent .table .header {
  box-sizing: border-box;
  height: 50px;
  line-height: 50px;
  border-bottom: 1px dashed #d1dbe5;
  position: absolute;
  top: 0px;
  left: 0px;
  right: 10px;
  .btns {
    text-align: right;
    float: right;
  }
}

.addTrainSample .addTrainSampleContent .table .content {
  position: absolute;
  top: 60px;
  right: 0px;
  left: 0px;
  bottom: 50px;
  overflow-y: auto;
}

.addTrainSample .addTrainSampleContent .table .search {
  box-sizing: border-box;
  height: 50px;
  line-height: 50px;
  border-bottom: 1px dashed #d1dbe5;
  position: absolute;
  top: 0px;
  left: 10px;
  right: 10px;
}

.search span {
  font-size: 14px;
  float: left;
  display: block;
}

.addTrainSample .addTrainSampleContent .table .tableBox {
  padding-bottom: 30px;
  padding-top: 60px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}

.addTrainSample .addTrainSampleContent .table .tableBox .tableGroup {
  padding-bottom: 120px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}

.addTrainSample .addTrainSampleContent .tableGroup .sampleList {
  width: 100%;
  height: 186px;
  margin: 10px 0;
  box-sizing: border-box;
  border: 1px solid #d1dae9;
}

.sampleList .sample-header {
  width: 100%;
  height: 44px;
  background: #eff2f7;
  color: #5d6d86;
  line-height: 44px;
  padding-left: 10px;
  box-sizing: border-box;
  span {
    font-weight: bold;
    color: #1f2d3d;
  }
}

.sampleList .play {
  display: none;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  background: rgba(00, 00, 00, 0.4);
  text-align: center;
  line-height: 145px;
  img {
    display: inline;
    width: 51px;
    height: 51px;
  }
}

.sampleList .playRemove {
  display: none;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  background: rgba(00, 00, 00, 0.4);
  text-align: center;
  line-height: 145px;
  img {
    display: inline;
    width: 51px;
    height: 51px;
  }
}

.sampleList .sample-content {
  position: absolute;
  top: 45px;
  left: 0;
  right: 0;
  bottom: 35px;
  overflow: hidden;
  &:hover {
    cursor: pointer;
  }
}

.sampleList .wholeContent {
  position: absolute;
  top: 44px;
  left: 0px;
  width: 100%;
  height: 104px;
  background: rgba(0, 0, 0, 0.2);
}

.sampleList .sample-content .img {
  width: 51px;
  height: 51px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.sampleList .sample-footer {
  position: absolute;
  box-sizing: border-box;
  height: 36px;
  bottom: 0px;
  width: 100%;
  line-height: 36px;
  border-top: 1px solid #d1dae9;
}

.sampleList .seatName {
  margin-right: 20px;
  margin-left: 10px;
}

.addTrainSample .addTrainSampleContent .table .tableBox .tablePage {
  overflow-x: scroll;
}

.addTrainSample .addTrainSampleContent .addTrainLeft {
  border-right: 1px solid @border-color;
  height: 100%;
  width: 100%;
  position: relative;
}

.addTrainSample .addTrainSampleContent .tableListSecond {
  height: 100%;
  width: 100%;
  position: relative;
  #list {
    height: 100%;
    position: relative;
    box-sizing: border-box;
    width: 100%;
  }
  #mydetail {
    height: 100%;
    position: relative;
    box-sizing: border-box;
    width: 100%;
    display: none;
  }
}

.addTrainSample .addTrainSampleContent .box {
  border-bottom: 1px dashed #d1dbe5;
  overflow: hidden;
}

.addTrainSample .addTrainSampleContent .box span {
  color: #bcc3d3;
  padding: 10px 0px;
  height: 33px;
  line-height: 33px;
  font-size: 14px;
}
</style>
<style>
#addTrainSample .el-badge__content {
  background-color: #20a0ff;
}

#addTrainSample .el-badge__content.is-fixed {
  top: 0;
  right: 50px;
  position: absolute;
  -ms-transform: translateY(-50%) translateX(100%);
  transform: translateY(-50%) translateX(100%);
}

#addTrainSample .icon-bg {
  background: url('../../../assets/img/icon-yuan02.png');
  width: 35px;
  height: 17px;
}

#addTrainSample .addTrainSampleHeader img {
  display: inline;
}

#addTrainSample .demo-table-expand {
  font-size: 0;
}

#addTrainSample .demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}

#addTrainSample .demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}

#addTrainSample .table .content h3 {
  padding-left: 10px;
  line-height: 30px;
  font-size: 14px;
  color: #9dadc2;
  font-weight: normal;
}

#addTrainSample .sampleList .sample-header .el-checkbox__label {
  display: none;
}

#addTrainSample .single .el-dialog__header {
  display: none;
}
#addTrainSample .single.el-dialog__wrapper {
  position: fixed;
  top: 106px;
  left: 20px;
  right: 20px;
  bottom: 12px;
}
#addTrainSample .single.el-dialog__wrapper .el-dialog {
  width: 100%;
  height: 100%;
  margin: 0 !important;
}
#addTrainSample .single .el-dialog__body {
  padding: 10px 20px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}
#addTrainSample .single .el-dialog--large {
  height: 84%;
  top: 5% !important;
}
</style>
