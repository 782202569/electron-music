<template>
  <el-form
    ref="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Ref"
    :inline="true"
    :rules="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Rules"
    :model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model"
    label-width="84px"
  >
    <h3>录音属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="callNo" style="color:#8691a5" label="主叫号码"
          ><el-input
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.callNo"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="calledNo" style="color:#8691a5" label="被叫号码"
          ><el-input
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.calledNo"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="24"
        ><el-form-item prop="callTime_Min" style="color:#8691a5" label="通话时长"
          ><el-input
            style="width:55px"
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.callTime_Min"
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="callTime_Max"
          ><el-input
            style="width:55px"
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.callTime_Max"
            placeholder=""
          ></el-input></el-form-item
        ><el-form-item prop="callId"
          ><el-select
            style="width:120px;margin-left:10px"
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.timeType"
            placeholder="请选择"
          >
            <el-option label="秒" value="2"></el-option
            ><el-option label="分" value="1"></el-option
            ><el-option label="时" value="0"></el-option></el-select
        ></el-form-item> </el-col
      ><el-col :span="12"
        ><el-form-item prop="callSTime" style="color:#8691a5" label="录音时间"
          ><el-date-picker
            style="width:160px"
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.callSTime"
            type="datetimerange"
            placeholder="选择时间范围"
            v-bind:default-time="['00:00:00', '23:59:59']"
          ></el-date-picker></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>坐席属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="seatNo" style="color:#8691a5" label="坐席工号"
          ><el-input
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.seatNo"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="seatName" style="color:#8691a5" label="坐席姓名"
          ><el-input
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.seatName"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12"
        ><el-form-item prop="deptId" style="color:#8691a5" label="坐席组"
          ><el-select
            style="width:160px"
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.deptId"
            placeholder="请选择"
            id="seatGroup"
            ><el-option
              label=""
              v-for="item in seatGroupOptions"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option></el-select></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>语音属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="avgSpeed_Min" style="color:#8691a5" label="平均语速"
          ><el-input
            style="width:55px"
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.avgSpeed_Min"
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="avgSpeed_Max"
          ><el-input
            style="width:55px"
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.avgSpeed_Max"
            placeholder=""
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="silenceLong_Min" style="color:#8691a5" label="静默时长"
          ><el-input
            style="width:55px"
            v-model="
              analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.silenceLong_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="silenceLong_Max"
          ><el-input
            style="width:55px"
            v-model="
              analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.silenceLong_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12"
        ><el-form-item prop="silencePer_Min" style="color:#8691a5" label="静默占比"
          ><el-input
            style="width:55px"
            v-model="
              analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.silencePer_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="silencePer_Max"
          ><el-input
            style="width:55px"
            v-model="
              analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.silencePer_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="silenceCount_Min" style="color:#8691a5" label="静默次数"
          ><el-input
            style="width:55px"
            v-model="
              analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.silenceCount_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="silenceCount_Max"
          ><el-input
            style="width:55px"
            v-model="
              analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.silenceCount_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12"
        ><el-form-item prop="overLap_Min" style="color:#8691a5" label="重叠次数"
          ><el-input
            style="width:55px"
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.overLap_Min"
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="overLap_Max"
          ><el-input
            style="width:55px"
            v-model="analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.overLap_Max"
            placeholder=""
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row
  ></el-form>
</template>

<script>
import global from '@/global'
import Qs from 'qs'
let currentBaseUrl = global.currentBaseUrl

export default {
  data() {
    return {
      seatGroupOptions: [],

      analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model: {
        callNo: '',
        callNo$CName: '主叫号码',
        calledNo: '',
        calledNo$CName: '被叫号码',
        callTime_Min: '',
        callTime_Min$CName: '通话时长(最小值)',
        callTime_Max: '',
        callTime_Max$CName: '通话时长(最大值)',
        callSTime: [],
        callSTime$CName: '录音时间',
        seatNo: '',
        seatNo$CName: '坐席工号',
        seatName: '',
        seatName$CName: '坐席姓名',
        deptId: '',
        deptId$CName: '坐席组',
        avgSpeed_Min: '',
        avgSpeed_Min$CName: '平均语速(最小值)',
        avgSpeed_Max: '',
        avgSpeed_Max$CName: '平均语速(最大值)',
        silenceLong_Min: '',
        silenceLong_Min$CName: '静默时长(最小值)',
        silenceLong_Max: '',
        silenceLong_Max$CName: '静默时长(最大值)',
        silencePer_Min: '',
        silencePer_Min$CName: '静默占比(最小值)',
        silencePer_Max: '',
        silencePer_Max$CName: '静默占比(最大值)',
        silenceCount_Min: '',
        silenceCount_Min$CName: '静默次数(最小值)',
        silenceCount_Max: '',
        silenceCount_Max$CName: '静默次数(最大值)',
        overLap_Min: '',
        overLap_Min$CName: '重叠次数(最小值)',
        overLap_Max: '',
        overLap_Max$CName: '重叠次数(最大值)',
      },
      analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Rules: {},
    }
  },
  mounted: function() {
    this.getSeatGroupValue()
  },
  methods: {
    getSeatGroupValue() {
      let _this = this
      let url = currentBaseUrl + '/pageConstant/getValue.do'
      let searchParam = {}
      searchParam.keys = 'seatGroup'
      this.axios
        .post(url, Qs.stringify(searchParam))
        .then(function(response) {
          _this.seatGroupOptions = response.data.seatGroup
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取常量值出现问题',
          })
        })
    },
  },
}
</script>

<style></style>
