<template>
  <div class="conpalinDiv edealFind" id="clusterlist">
    <div @click="getbackNow" style="padding: 30px;cursor: pointer;color: #20A0FF;">
      &lt; 任务列表
    </div>
    <div class="content">
      <div class="table">
        <div style="padding: 0 16px 40px 19px;">
          <el-table
            :data="tableData"
            border
            ref="multipleTable"
            tootip-effect="dark"
            @selection-change="handleSelectionChange"
          >
            <el-table-column prop="objectId" label="录音编号">
              <template scope="scope">
                <span
                  style="color:#20a0ff;cursor: pointer"
                  type="text"
                  @click="showDetail(scope.row.objectId, scope.row.recordFileURL)"
                  >{{ scope.row.objectId }}</span
                >
              </template>
            </el-table-column>
            <el-table-column
              prop="callStime"
              sortable
              :formatter="exeTimeFilter"
              label="录音时间"
              width="180"
            >
            </el-table-column>
            <el-table-column
              prop="callTime"
              sortable
              :formatter="commonUtil"
              label="通话时长"
            >
            </el-table-column>
            <el-table-column prop="seatName" label="坐席姓名"> </el-table-column>
          </el-table>
        </div>
      </div>
      <div class="autoGrading-page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="pageSizes"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        >
        </el-pagination>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import global from '@/global'
import Qs from 'qs'
import bus from '../../common/bus.js'
import moment from 'moment'
import recordingplay from '../recordingPlay/recordingPlayResultScore.vue'
let currentBaseUrl = global.currentBaseUrl
export default {
  props: ['message'],
  data() {
    return {
      recordDialogVisible: false,
      tableData: [],
      currentPage: 1,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
    }
  },
  components: {
    recordingplay,
  },
  methods: {
    recordPlayCloseHandler() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    showDetail(callID, recordFileURL) {
      let obj = {}
      obj.from = 'audioClassification'
      obj.callId = callID
      obj.recordFileURL = recordFileURL
      obj.pageNumber = this.pageNumber
      obj.pageSize = this.pageSize
      obj.sortID = this.sortID
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    formatDate(obj) {
      let date = new Date(obj)
      let y = 1900 + date.getYear()
      let m = '0' + (date.getMonth() + 1)
      let d = '0' + date.getDate()
      let h = '0' + date.getHours()
      let f = '0' + date.getMinutes()
      let s = '0' + date.getSeconds()
      return (
        y +
        '-' +
        m.substring(m.length - 2, m.length) +
        '-' +
        d.substring(d.length - 2, d.length) +
        ' ' +
        h.substring(h.length - 2, h.length) +
        ':' +
        f.substring(f.length - 2, f.length) +
        ':' +
        s.substring(s.length - 2, s.length)
      )
    },
    getbackNow: function() {
      this.$emit('send', false)
    },
    scoreInquery() {
      let params = {
        clusterRuleId: this.message,
        pageindex: this.currentPage,
        pagesize: this.pageSize,
      }
      this.axios
        .post(currentBaseUrl + '/ivsClusterRule/selectedSample.do', Qs.stringify(params))
        .then((resp) => {
          console.log(resp)
          if (resp.data.Count) {
            this.tableData = resp.data.Data
          } else {
            this.tableData = []
          }
          this.total = resp.data.Count
        })
    },
    handleSelectionChange(val) {
      console.log(val)
      this.selectedArr = val
    },
    // 跳转到录音播放页面
    jumpToSound: function(type, callId, status, appealId, recordFileURL) {
      let obj = {}
      obj.from = 'scoreResultInfo'
      obj.scoreResultRole = 'scoreResultZuoXi'
      obj.appealStatus = status
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.appealId = appealId
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlay')
      // 初始化play
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay', // 扩展样式
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 将录音时长转换为秒
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    commonUtil(row, column, cellValue) {
      let theTime = parseInt(cellValue) // 秒
      let theTime1 = 0 // 分
      let theTime2 = 0 // 小时
      if (theTime > 60) {
        theTime1 = parseInt(theTime / 60)
        theTime = parseInt(theTime % 60)
        if (theTime1 > 60) {
          theTime2 = parseInt(theTime1 / 60)
          theTime1 = parseInt(theTime1 % 60)
        }
      }
      let result = '' + parseInt(theTime) + '秒'
      if (theTime1 > 0) {
        result = '' + parseInt(theTime1) + '分' + result
      }
      if (theTime2 > 0) {
        result = '' + parseInt(theTime2) + '小时' + result
      }
      return result
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.scoreInquery()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.scoreInquery()
    },
  },
  mounted: function() {
    console.log(this.message)
    this.scoreInquery()
  },
  computed: {},
  created() {},
}
</script>
<style lang="less">
.dealCenter {
  padding-top: 20px;
  height: 544px;
  overflow: auto;
}
#clusterlist {
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
}

.titleRight {
  display: inline-block;
  padding-left: 20px;
}
.titleLeft {
  display: inline-block;
  padding: 10px 20px;
}
#soundfeature {
  box-sizing: border-box;
  height: 95%;
  width: 100%;
  overflow: hidden;

  .conpalinDiv {
    width: 100%;
    height: 100%;
    .recordingplayWrap {
      width: 100%;
      height: 100%;
      overflow-y: auto;
      position: relative;
    }
    .single {
      &.el-dialog__wrapper {
        position: fixed;
        top: 106px;
        left: 20px;
        right: 20px;
        bottom: 12px;
        .el-dialog {
          width: 100%;
          height: 100%;
          margin: 0 !important;
        }
      }
      .el-dialog__header {
        display: none;
      }
      .el-dialog__body {
        padding: 10px 20px;
        box-sizing: border-box;
        width: 100%;
        height: 100%;
      }
    }
    .changeCondtion {
      width: 100%;
      height: 44px;
      margin: 20px 0;
    }
    .content {
      padding-bottom: 80px;
      box-sizing: border-box;
      width: 100%;
      height: 94%;
    }
    .table {
      width: 100%;
      height: 100%;
      overflow: auto;
    }
    .autoGrading-page {
      height: 35px;
      position: absolute;
      background: white;
      right: 0px;
      bottom: 0px;
      text-align: right;
      .el-pagination {
        display: inline-block;
        height: 28px;
        line-height: 28px;
        padding: 0px 10px;
      }
    }
  }
}
</style>
<style lang="less">
#tableFindset th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}
.content .table th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}
.el-pagination__total {
  height: 35px;
  line-height: 35px;
}
.el-pager li {
  height: 35px;
  line-height: 35px;
}
.btn-prev,
.btn-next {
  height: 35px;
  line-height: 35px;
}
.el-textarea__inner {
  width: 80%;
  height: 200px;
}
.edealFind {
  .el-dialog__body {
    padding: 0;
  }
  .el-dialog__header {
    padding: 20px 0px 10px 0px;
    border-bottom: 1px solid #e0e6ed;
    .el-dialog__title {
      padding-left: 20px;
      font-size: 16px;
      font-weight: bolder;
    }
  }
  .speshowsl .dealCenter .el-input__inner {
    width: 240px;
  }
}
.el-popover {
  width: 25%;
}
.playuer {
  padding-left: 20px;
}
</style>
