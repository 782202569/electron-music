<template>
  <div class="newPage" id="newPage">
    <div class="newPageHeader">
      <ul>
        <li>
          <p>填写主题聚类</p>
          <img src="../../../assets/img/icon-yuan.png" />
        </li>
        <li>添加训练样本</li>
        <li>启用词表</li>
      </ul>
    </div>
    <div style="padding: 20px;overflow: hidden;">
      <div class="newPageForm">
        <div style="width: 500px; margin: 0 auto;">
          <el-form :model="addForm" ref="addForm" :rules="formRules" label-width="120px">
            <el-form-item label="聚类名称" prop="clusterRuleName">
              <el-input
                class="w200"
                v-model="addForm.clusterRuleName"
                placeholder="请输入名称"
              ></el-input>
            </el-form-item>
            <el-form-item label="显示主题词数" prop="showThemeWord">
              <el-input
                class="w200"
                v-model="addForm.showThemeWord"
                placeholder="请输入主题词数"
              ></el-input>
            </el-form-item>
            <el-form-item label="限制语句数" prop="limitMutualNum">
              <el-input
                class="w200"
                :disabled="this.disabled"
                v-model="addForm.limitMutualNum"
                placeholder="请输入限制语句数"
              >
                <el-button slot="append" @click="all">全部</el-button>
              </el-input>
            </el-form-item>
            <el-form-item label="分析对象" prop="clusterRole">
              <el-select v-model="addForm.clusterRole" placeholder="请选择分析对象">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div class="pages">
        <el-button type="primary" :disabled="nextDisabled" @click="saveForm"
          >下一步</el-button
        >
        <el-button @click="canel">取消</el-button>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import Qs from 'qs'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
export default {
  data() {
    const validName = (rule, value, callback) => {
      let p1 = /^\S{1,30}$/
      let params = /^[A-Za-z0-9\u4E00-\u9FA5]*$/
      if (!p1.test(value)) {
        callback(new Error('请输入30位之内的非空字符的名称！'))
      } else if (!params.test(value)) {
        callback(new Error('不能包含特殊字符！'))
      } else {
        callback()
      }
    }
    const validNum = (rule, value, callback) => {
      let param = RegExp('^-?\\d+$')
      let params = /^[A-Za-z0-9\u4E00-\u9FA5]*$/
      if (!param.test(value)) {
        callback(new Error('请输入整数'))
      } else if (!params.test(value)) {
        callback(new Error('不能包含特殊字符！'))
      } else {
        callback()
      }
    }
    const validWord = (rule, value, callback) => {
      let param = RegExp('^-?\\d+$')
      let params = /^[A-Za-z0-9\u4E00-\u9FA5]*$/
      if (!param.test(value)) {
        callback(new Error('请输入整数'))
      } else if (!params.test(value)) {
        callback(new Error('不能包含特殊字符！'))
      } else {
        callback()
      }
    }
    return {
      formRules: {
        clusterRuleName: [
          { required: true, message: '请输入名称', trigger: 'blur' },
          { validator: validName, trigger: 'blur' },
        ],
        showThemeWord: [{ validator: validWord, trigger: 'blur' }],
        limitMutualNum: [{ validator: validNum, trigger: 'blur' }],
      },
      disabled: false,
      nextDisabled: false,
      options: [
        {
          value: 0,
          label: '全部',
        },
        {
          value: 1,
          label: '客户',
        },
        {
          value: 2,
          label: '客服',
        },
      ],
      addForm: {
        clusterRuleName: '',
        showThemeWord: '',
        limitMutualNum: '',
        clusterRole: 0,
      },
    }
  },
  methods: {
    canel: function() {
      this.$router.push('/clusterRule_hrlist')
    },
    saveForm: function() {
      this.nextDisabled = true
      this.$refs.addForm.validate((valid) => {
        if (valid) {
          let params = {
            clusterRuleName: this.addForm.clusterRuleName,
            showThemeWord: this.addForm.showThemeWord,
            limitMutualNum: this.addForm.limitMutualNum,
            clusterRole: this.addForm.clusterRole,
            kValue: 100,
          }
          if (parseInt(params.showThemeWord) < 5 || parseInt(params.showThemeWord) > 9) {
            this.$message.error('主题词数必须在5-9之内!')
            this.nextDisabled = false
            return
          }
          if (
            parseInt(params.limitMutualNum) < 0 ||
            parseInt(params.limitMutualNum) > 99
          ) {
            this.$message.error('限制语句数在0-99之间!')
            this.nextDisabled = false
            return
          }
          this.axios
            .post(
              currentBaseUrl + '/ivsClusterRule/addClusterRule.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data.state == 1) {
                this.$message({
                  type: 'success',
                  message: '添加成功',
                })

                let clusterRuleId = res.data.other.rule.clusterRuleId
                let clusterRole = res.data.other.rule.clusterRole
                let StringData = {}
                StringData.pageType = 1
                StringData.clusterRole = clusterRole
                StringData.clusterRuleId = clusterRuleId
                this.$store.commit('setStringData', StringData)
                this.$router.push('/addTrainSample')
              } else if (res.data.state == 0) {
                this.$message({
                  type: 'warning',
                  message: res.data.message,
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '添加失败',
                })
              }
              this.nextDisabled = false
            })
            .catch((error) => {
              console.log(error)
              this.nextDisabled = false
            })
        } else {
          this.nextDisabled = false
        }
      })
    },
    all: function() {
      if (this.disabled == true) {
        this.disabled = false
      } else {
        this.disabled = true
      }
      this.addForm.limitMutualNum = 0
    },
  },
}
</script>
<style scoped="scoped">
.newPage {
  width: 100%;
  padding: 0 10px;
  /* top: 1px; */
  box-sizing: border-box;

  height: 100%;
  position: relative;
}

.newPage .newPageHeader {
  float: left;
  box-sizing: border-box;
  top: 0px;
  width: 100%;
  height: 60px;
  border-bottom: 1px solid #d1dbe5;
  background-color: #eef1f6;
}

.newPage .newPageHeader p {
  width: 100%;
  height: 34px;
  text-align: center;
}

.newPage .newPageHeader ul {
  text-align: center;
  list-style: none;
}

.newPage .newPageHeader ul li {
  float: left;
  display: inline-block;
  font-size: 14px;
  text-align: center;
  color: #5e6d82;
  line-height: 60px;
  font-weight: bold;
  width: 30%;
}

.newPage .newPageHeader ul li img {
  width: 99px;
  display: block;
}

.newPage .newPageForm {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}

.newPage .pages {
  width: 100%;
  text-align: right;
  border-top: 1px solid #d1dbe5;
  right: 10px;
  position: absolute;
  bottom: 20px;
  padding-top: 20px;
}

.newPage .w200 {
  width: 200px;
}
</style>
<style>
#newPage .newPageHeader img {
  display: inline;
}
</style>
