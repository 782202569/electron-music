<template>
  <div id="soundfeature" class="classTable">
    <div class="conpalinDiv edealFind" v-show="paryTasks">
      <div class="changeCondtion">
        <el-button funcId="000031" style="margin-left: 19px;" @click="newRenwu"
          >新建</el-button
        >
        <div style="float: right;margin-right: 0px;display: inline-block;">
          <el-select
            v-model="queryParams.taskNo"
            placeholder="是否基本模型"
            clearable
            style="margin-right: 5px;"
          >
            <el-option
              v-for="item in taskNo"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
          <el-select
            v-model="queryParams.taskState"
            placeholder="样本来源"
            clearable
            style="margin-right: 5px;"
          >
            <el-option
              v-for="item in taskStatus"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
          <el-date-picker
            v-model="searchForm.callSTime"
            type="datetimerange"
            :clearable="false"
            :editable="false"
            align="right"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            :default-time="['00:00:00', '23:59:59']"
            style="width: 375px;padding: 1px 10px;"
          >
          </el-date-picker>
          <el-button
            @click="scoreInquery"
            type="primary"
            style="margin-left: 7px;margin-right: 20px;"
            >查询</el-button
          >
        </div>
      </div>
      <div class="content" v-show="untrendSize">
        <div class="table">
          <div style="padding: 0 16px 40px 19px;">
            <el-table
              :data="tableData"
              border
              ref="multipleTable"
              tootip-effect="dark"
              @selection-change="handleSelectionChange"
            >
              <el-table-column prop="clusterRuleName" label="模型名称"> </el-table-column>
              <el-table-column
                prop="createTime"
                :formatter="exeTimeFilter"
                label="创建时间"
                width="100"
              >
              </el-table-column>
              <el-table-column prop="sampleSource" label="样本来源"> </el-table-column>
              <el-table-column prop="createUser" label="创建人" width="170">
              </el-table-column>
              <el-table-column
                prop="resultStatusName"
                :formatter="setStatus"
                label="状态"
              >
              </el-table-column>
              <el-table-column prop="baseModel" label="基本模型">
                <template scope="scope">
                  <el-switch
                    v-model="scope.row.baseModel"
                    :active-value="1"
                    :inactive-value="0"
                    @change="stateChange(scope.row.baseModel, scope.row.clusterRuleId)"
                  >
                  </el-switch>
                </template>
              </el-table-column>
              <el-table-column label="操作" width="280">
                <template scope="scope">
                  <div class="operation">
                    <i class="opeatLeft" @click="setLook(scope.row.clusterRuleId)"
                      ><i style="color: #20A0FF;cursor: pointer;">查看配置</i></i
                    >
                    <i class="opeatLeft" @click="setList(scope.row.clusterRuleId)"
                      ><i style="color: #20A0FF;cursor: pointer;">查看样本</i></i
                    >
                    <i
                      class="opeatLeft"
                      v-if="scope.row.resultStatus == 3"
                      @click="setResult(scope.row.clusterRuleId)"
                      ><i style="color: #20A0FF;cursor: pointer;">查看结果</i></i
                    >
                    <i
                      funcId="000365"
                      class="opeatLeft"
                      @click="copyTable(scope.row.clusterRuleId)"
                      ><i style="color: #20A0FF;cursor: pointer;">复制</i></i
                    >
                    <i
                      funcId="000366"
                      class="opeatLeft"
                      @click="deleteProjectConfirm(scope.row.clusterRuleId)"
                      ><i style="color: #20A0FF;cursor: pointer;">删除</i></i
                    >
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="autoGrading-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
      <el-dialog
        class="smellmodel speshow"
        :visible.sync="setInput"
        width="520px"
        title="分发任务"
        :close-on-click-modal="false"
      >
        <div class="dealCenter">
          <el-form label-width="100px" ref="fourForm">
            <el-form-item label="选择质检员"> </el-form-item>
          </el-form>
        </div>
        <div
          class="footerAll"
          style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
        >
          <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
            <el-button @click="notChange">取 消</el-button>
            <el-button type="primary" style="margin-right: 18px;">提 交</el-button>
          </div>
        </div>
      </el-dialog>
      <el-dialog
        class="smellmodel speshow abow_dialog"
        :visible.sync="LookDealog"
        width="640px"
        title="查看配置"
        :close-on-click-modal="false"
      >
        <div class="dealCenter">
          <div class="title-flex">
            <div class="title-flex-l">创建方式</div>
            <div class="title-flex-r">{{ setAlldate.createMode }}</div>
          </div>
          <div class="title-flex">
            <div class="title-flex-l">样本范围</div>
            <div class="title-flex-r" v-if="!belongClassName">
              {{ sample | calculationSample }}
            </div>
            <div class="title-flex-r" v-else v-html="belongClassName"></div>
          </div>
          <div class="title-flex">
            <div class="title-flex-l">样本数量</div>
            <div class="title-flex-r">{{ setAlldate.trainSampleNum }}</div>
          </div>
          <div class="title-flex">
            <div class="title-flex-l">主题个数</div>
            <div class="title-flex-r">{{ setAlldate.showThemeWord }}</div>
          </div>
          <div class="title-flex">
            <div class="title-flex-l">每个主题的词数</div>
            <div class="title-flex-r">{{ setAlldate.limitMutualNum }}</div>
          </div>
          <div class="title-flex">
            <div class="title-flex-l">训练模式</div>
            <div class="title-flex-r">{{ setAlldate.monitoringMode }}</div>
          </div>
          <div class="title-flex" v-if="setAlldate.monitoringMode == '半监督模式'">
            <div class="title-flex-l">先验主题词</div>
            <div class="title-flex-r">{{ setAlldate.themeWord.replace(/,/g, ', ') }}</div>
          </div>
          <div class="title-flex" v-if="setAlldate.monitoringMode == '半监督模式'">
            <div class="title-flex-l">影响强度</div>
            <div class="title-flex-r">{{ setAlldate.effectStrength }}</div>
          </div>
          <div class="title-flex" style="padding: 30px 20px 0 20px;">启用的特征词表</div>
          <div class="title-flex titleLeft">共{{ numCount }}个特征词</div>
          <div
            :class="['title-flex', tableDataswer.length > 10 ? 'heightCell' : '']"
            id="tableFindset"
            style="margin: 0 20px;"
          >
            <el-table height="189" :data="tableDataswer">
              <el-table-column prop="wordName" label="特征词"> </el-table-column>
              <el-table-column prop="docNum" label="词频"> </el-table-column>
            </el-table>
          </div>
        </div>
        <div
          class="footerAll"
          style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
        >
          <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
            <el-button @click="notChange">取 消</el-button>
            <el-button type="primary" style="margin-right: 18px;" @click="notChange"
              >确 定</el-button
            >
          </div>
        </div>
      </el-dialog>
      <el-dialog
        class="smellmodel speshow"
        :title="changeTitle"
        :visible.sync="exitPage"
        width="740px"
        :close-on-click-modal="false"
      >
        <div v-show="choiceData">
          <div style="width: 100%;border-bottom: 1px solid #E0E6ED;">
            <div style="color: #20A0FF;display: inline-block;padding: 15px;">
              筛选样本
            </div>
            <i class="angle-right">></i>
            <div style="display: inline-block;padding: 15px;">
              配置参数词表
            </div>
          </div>
          <div class="madeModel">
            <my-comp ref="myComp"></my-comp>
          </div>
          <div class="footerAll" style="width: 100%;height: 68px;">
            <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
              <el-button @click="notChange">取 消</el-button>
              <el-button
                type="primary"
                style="margin-right: 18px;"
                @click="getNext"
                :loading="checking"
                >下一步</el-button
              >
            </div>
          </div>
        </div>
        <div v-show="ConfigurationPage">
          <div style="width: 100%;border-bottom: 1px solid #E0E6ED;" v-show="copyNo">
            <div style="display: inline-block;padding: 15px;">
              筛选样本
            </div>
            <i class="angle-right">></i>
            <div style="color: #20A0FF;display: inline-block;padding: 15px;">
              配置参数词表
            </div>
          </div>
          <div class="dealCenter">
            <div v-show="copyNo">
              <div class="titleLeft">共{{ titleCount }}条录音</div>
              <div id="tableFindset" style="margin: 0 20px;">
                <el-table :data="tableTtile" style="width: 100%">
                  <el-table-column label="录音编号">
                    <template scope="scope">
                      <span
                        @click="showDetail(scope.row.callId, scope.row.recordFileURL)"
                        >{{ scope.row.callId }}</span
                      >
                    </template>
                  </el-table-column>
                  <el-table-column
                    prop="callSTime"
                    :formatter="exeTimeFilter"
                    label="录音时间"
                    width="200"
                  >
                  </el-table-column>
                  <el-table-column prop="callTime" label="通话时长" width="150">
                  </el-table-column>
                  <el-table-column prop="seatName" label="坐席姓名"> </el-table-column>
                </el-table>
              </div>
              <div class="block" style="text-align: right;padding: 20px 0;">
                <el-pagination
                  background
                  @size-change="litterChange"
                  @current-change="litterCurrentChange"
                  :current-page="litterPage"
                  :page-size="litterSize"
                  layout="prev, pager, next"
                  :total="numTotal"
                >
                </el-pagination>
              </div>
            </div>
            <div v-show="showCopy">
              <el-form
                label-width="125px"
                ref="threeForm"
                :model="task2Form"
                :rules="threeRules"
              >
                <div
                  class="audioAttrsInputs aloneChange"
                  style="margin:10px 20px 0 20px;height: 55px;"
                >
                  <el-col :span="14">
                    <el-form-item label="模型名称" prop="name">
                      <el-input
                        v-model="task2Form.name"
                        placeholder="请输入模型名称"
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </div>
              </el-form>
              <div v-show="!copyNo">
                <div style="padding: 20px 30px;">
                  <div class="titleFind">样本范围</div>
                  <div class="titleScrite" v-if="!longName">
                    {{ sample | calculationSample }}
                  </div>
                  <div class="titleScrite" v-else v-html="longName">{{ longName }}</div>
                </div>
                <div style="padding: 20px 30px;">
                  <span>样本数量</span
                  ><span style="padding-left: 60px;">{{ dataNumber }}条录音</span>
                </div>
              </div>
              <div style="clear: both;padding-left: 40px;height: 70px;line-height: 50px;">
                <el-radio-group v-model="makeVlue" @change="newModel">
                  <el-radio :label="0">训练新模型</el-radio>
                  <el-radio :label="1">使用基本模型</el-radio>
                </el-radio-group>
              </div>
              <div v-show="optionLeft">
                <div
                  style="height: 40px;line-height: 40px;padding-left: 40px;clear: both;"
                >
                  特征词表
                </div>
                <div style="padding: 0 28px;text-align: center;" class="findBorder">
                  <el-transfer
                    style="text-align: left; display: inline-block"
                    v-model="CharacterTable"
                    filterable
                    filter-placeholder="请输入特征词"
                    target-order="push"
                    :titles="['全部', '已选择']"
                    :data="dataValue"
                  >
                    <span slot-scope="{ option }"
                      ><span style="display: inline-block;">{{ option.label }}</span
                      ><span style="float: right;padding-right: 30px;">{{
                        option.value
                      }}</span></span
                    >
                  </el-transfer>
                </div>
                <div
                  id="block"
                  style="width: 286px;padding: 5px 0px;margin: 0 34px;border: 1px solid #E0E6ED;border-top: 0px solid #E0E6ED;"
                >
                  <el-pagination
                    background
                    @size-change="lastChange"
                    @current-change="lastCurrentChange"
                    :current-page="lastPage"
                    :page-size="lastSize"
                    layout="prev, pager, next"
                    :total="treeTotal"
                  >
                  </el-pagination>
                  <div class="pageChangeNo">
                    <span>共{{ treeNum }}条数据</span>
                    <el-select @change="lastNode" v-model="pageWide" placeholder="请选择">
                      <el-option
                        v-for="item in pageNum"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </div>
                </div>
                <div
                  v-show="newCopy"
                  class="footerAll"
                  style="width: 100%;height: 68px;clear: both;"
                >
                  <div
                    class="footInside"
                    style="float: right;height: 53px;padding-top: 15px"
                  >
                    <el-button @click="notChange">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="radioLeftclickThrottle"
                      >确 定</el-button
                    >
                  </div>
                </div>
                <div
                  v-show="!newCopy"
                  class="footerAll"
                  style="width: 100%;height: 68px;clear: both;"
                >
                  <div
                    class="footInside"
                    style="float: right;height: 53px;padding-top: 15px"
                  >
                    <el-button @click="notChange">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="copyDown"
                      >确 定</el-button
                    >
                  </div>
                </div>
              </div>
              <div v-show="!optionLeft">
                <el-form
                  label-width="125px"
                  ref="opinrightForm"
                  :model="modelSeat"
                  :rules="moreRules"
                >
                  <div class="audioAttrsInputs" style="margin:0 20px;height: 55px;">
                    <el-col :span="14">
                      <el-form-item label="选择模型" prop="chModel">
                        <el-select
                          v-model="modelSeat.chModel"
                          placeholder="请选择基本模型"
                        >
                          <el-option
                            v-for="item in modelList"
                            :key="item.clusterRuleName"
                            :label="item.clusterRuleName"
                            :value="item.clusterRuleName"
                          >
                          </el-option>
                        </el-select>
                      </el-form-item>
                    </el-col>
                  </div>
                </el-form>
                <div class="footerAll" style="width: 100%;height: 68px;clear: both;">
                  <div
                    class="footInside"
                    style="float: right;height: 53px;padding-top: 15px"
                  >
                    <el-button @click="notChange">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="radioLeftclickThrottle"
                      >确 定</el-button
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </el-dialog>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
    <!-- 进入查看样本List页面 -->
    <pTasks
      v-if="paryTaskslist"
      :message="this.flyId.taskId"
      v-on:send="sameShow"
    ></pTasks>
    <!-- 进入查看结果页面 -->
    <clustrRult
      v-if="paryTasksresult"
      @filterButton="filterButton"
      :message="this.flyId.cell"
      v-on:sendof="resultShow"
    ></clustrRult>
  </div>
</template>
<script>
import global from '@/global'
import $ from 'jquery'
import formatdate from '@/utils/formatdate.js'
import bus from '../../common/bus.js'
import Qs from 'qs'
import moment from 'moment'
import funcFilter from '@/utils/funcFilter.js'
let currentBaseUrl = global.currentBaseUrl
import recordingplay from '../recordingPlay/recordingPlayResultScore.vue'
import pTasks from './clusterList.vue'
import clustrRult from './clusterResult.vue'
import nativeaxios from 'axios'
import cache from '../../../utils/cache.js'
import sampleFilteringPageVue from './sampleFilteringPage.vue'
let formEngineUrl = global.formEngineUrl
export default {
  components: {
    pTasks,
    recordingplay,
    clustrRult,
    'my-comp': sampleFilteringPageVue,
  },
  data() {
    let checkName = (rule, valueOne, callback) => {
      if (!valueOne) {
        return callback(new Error('请输入模型名称'))
      }
      let reg = new RegExp(/^\s+$/)
      if (reg.test(valueOne)) {
        callback(new Error('请勿输入空格'))
      }
    }
    return {
      checking: false,
      showCopy: true,
      calculationSample: '',
      tempClusterRuleId: 1,
      dataValue: [],
      recordDialogVisible: false,
      CharacterTable: [],
      belongClassName: '',
      searchForm: {
        callSTime: [],
        byReson: '',
      },
      queryParams: {
        taskState: '',
        taskNo: '',
      },
      taskNo: [
        {
          value: '1',
          label: '基本模型',
        },
        {
          value: '0',
          label: '非基本模型',
        },
      ],
      taskStatus: [
        {
          value: '业务分类',
          label: '业务分类',
        },
        {
          value: '录音筛选',
          label: '录音筛选',
        },
      ],
      task2Form: {
        name: '',
      },
      threeRules: {
        name: [
          { min: 1, max: 10, message: '长度在 1 到 10 个字符', trigger: 'blur' },
          { required: true, validator: checkName, trigger: 'blur' },
        ],
      },
      addMake: {
        count: '',
        everyCount: 10,
        domains: [
          {
            value: '',
          },
        ],
      },
      addRules: {
        count: [{ required: true, message: '请输入先验主题词', trigger: 'blur' }],
      },
      cellModel: {
        chanceModel: '',
      },
      moreRules: {
        chModel: [{ required: true, message: '请选择基本模型', trigger: 'change' }],
      },
      tableData: [],
      tableDataswer: [],
      tableTtile: [],
      inputShow: false,
      makeVlue: 0,
      NoVlue: 0,
      pageWide: '10条/页',
      pageNum: [
        {
          value: '10',
          label: '10条/页',
        },
        {
          value: '50',
          label: '50条/页',
        },
        {
          value: '100',
          label: '100条/页',
        },
        {
          value: '200',
          label: '200条/页',
        },
      ],
      modelList: [],
      titleCount: '',
      treeNum: '',
      optionLeft: true,
      newCopy: true,
      paryTasksresult: false,
      setInput: false,
      choiceData: true,
      ConfigurationPage: false,
      copyNo: true,
      firstShow: false,
      changeTitle: '新建',
      exitPage: false,
      paryTaskslist: false,
      goodNice: [],
      filterData: [],
      temporaryAccess: [],
      timeType: 2,
      dataNumber: '',
      longName: '',
      setAlldate: {},
      sample: [],
      numCount: '',
      modelSeat: {
        chModel: '',
      },
      flyId: {},
      checkList: '',
      paryTasks: true,
      LookDealog: false,
      checkContent: false,
      untrendSize: true,
      currentPage: 1,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      litterSize: 10,
      litterPage: 1,
      lastPage: 1,
      lastSize: 10,
      total: 0,
      numTotal: 0,
      treeTotal: 0,
      searchType: '0',
    }
  },
  methods: {
    recordPlayCloseHandler() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    showDetail(callID, recordFileURL) {
      let obj = {}
      obj.from = 'audioClassification'
      obj.callId = callID
      obj.recordFileURL = recordFileURL
      obj.pageNumber = this.pageNumber
      obj.pageSize = this.pageSize
      obj.sortID = this.sortID
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    notChange: function() {
      this.setInput = false
      this.checkContent = false
      this.LookDealog = false
      this.exitPage = false
    },

    yesChange: function() {
      this.checkContent = false
      this.scoreInquery()
    },
    setList: function(index) {
      this.paryTasks = false
      this.paryTaskslist = true
      this.flyId = {
        taskId: index,
      }
    },
    setResult: function(index) {
      this.paryTasks = false
      this.paryTasksresult = true
      this.flyId = {
        cell: index,
      }
    },
    resetSearchForm: function() {
      this.CharacterTable = []
      this.NoVlue = 0
      this.treeTotal = 0
      this.makeVlue = 0
      this.optionLeft = true
      this.firstShow = false
      let _this = this
      this.$nextTick(function() {
        _this.$refs.threeForm.resetFields()
        _this.$refs.opinrightForm.resetFields()
        _this.$refs['myComp']['$refs'][
          'analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Ref'
        ].resetFields()
        _this.$refs[
          'myComp'
        ].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.wholeContent_firstKey =
          ''
        _this.$refs[
          'myComp'
        ].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.wholeContent_firstLogic =
          ''
        _this.$refs[
          'myComp'
        ].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.wholeContent_secondKey =
          ''
        _this.$refs[
          'myComp'
        ].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.wholeContent_MidLogic =
          ''
        _this.$refs[
          'myComp'
        ].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.wholeContent_thirdKey =
          ''
        _this.$refs[
          'myComp'
        ].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.wholeContent_LastLogic =
          ''
        _this.$refs[
          'myComp'
        ].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model.wholeContent_LastKey =
          ''
      })
    },
    sameShow(input) {
      // 关闭新建任务的弹窗
      this.paryTasks = true
      this.paryTaskslist = input
    },
    resultShow(input) {
      this.paryTasks = true
      this.paryTasksresult = input
    },
    newRenwu: function() {
      this.axios
        .get(
          currentBaseUrl +
            '/ivsClusterRule/checkClusterTrain?companyId=' +
            this.$store.state.loginUserinfo.companyId
        )
        .then((res) => {
          if (res.data === true) {
            this.changeTitle = '新建'
            this.exitPage = true
            this.filterButton() // 过滤权限按钮
            this.choiceData = true
            this.ConfigurationPage = false
            this.copyNo = true
            this.newCopy = true
            this.lastSize = 10
            this.pageWide = '10条/页'
            this.resetSearchForm()
            this.temporaryAccess = []
          } else {
            this.$message({
              type: 'info',
              message: '不能聚类训练，上次聚类还没有训练完成！',
            })
          }
        })
        .catch(() => {})
    },
    getNext: function() {
      this.checking = true
      this.axios
        .post(currentBaseUrl + '/ivsClusterRule/checkSampleCount')
        .then((res) => {
          this.checking = false
          if (res.data === true) {
            this.choiceData = false
            this.ConfigurationPage = true
            this.filterButton() // 过滤权限按钮
            this.NoVlue = 0
            this.litterPage = 1
            this.saveClusterKeyword()
          } else {
            this.$message({
              type: 'info',
              message: '录音文件不得少于50条！',
            })
          }
        })
        .catch(() => {
          this.checking = false
        })
    },
    addDomain() {
      this.addMake.domains.push({
        value: '',
        key: Date.now(),
      })
    },
    removeDomain(item) {
      let index = this.addMake.domains.indexOf(item)
      if (index !== -1) {
        this.addMake.domains.splice(index, 1)
      }
    },
    // 存储录音列表数据，只发一次
    saveClusterKeyword: function(strateObject) {
      let _this = this
      let searchModel = {}
      searchModel.selectType = 'new'
      searchModel.termRole = this.clusterRole
      searchModel.timeType = this.timeType
      let obj = {}
      obj.searchModel = JSON.parse(JSON.stringify(searchModel))
      obj.searchModel.searchType = this.searchType
      let clusterClient =
        _this.$refs['myComp'].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model
      _this.searchAttr(clusterClient) // 清空带参数名字数据

      obj.searchModel.searchObj = _this.$refs['myComp'] ? clusterClient : ''
      this.$store.commit('setRecordingPlayPage', obj)
      if (strateObject) {
        _this.getParams(searchModel, strateObject)
      } else {
        _this.getParams(
          searchModel,
          _this.$refs['myComp'].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model
        )
      }
      let keyword = ''
      if (strateObject) {
        keyword = _this.getKeyword(strateObject)
      } else {
        keyword = _this.getKeyword(
          _this.$refs['myComp'].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model
        )
      }
      searchModel['wholeContent'] = keyword
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/saveClusterKeyword.do',
          Qs.stringify(searchModel)
        )
        .then((res) => {
          if (res.data.data === true) {
            this.multipleEsQuery()
            this.getClusterWordByTreeId()
          } else {
            this.$message({
              type: 'error',
              message: '训练样本数量不得少于50条',
            })
            this.showCopy = false
            this.tableTtile = []
            this.titleCount = '0'
            this.numTotal = 0
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 查询录音列表
    multipleEsQuery: function(strateObject) {
      let _this = this
      let searchModel = {}
      searchModel.pageNumber = this.litterPage
      searchModel.pageSize = this.litterSize
      searchModel.sortField = 'callSTime'
      searchModel.selectType = 'new'
      searchModel.sortType = 'DESC'
      searchModel.termRole = this.clusterRole
      searchModel.timeType = this.timeType
      let obj = {}
      obj.searchModel = JSON.parse(JSON.stringify(searchModel))
      obj.searchModel.searchType = this.searchType
      obj.searchModel.searchObj = _this.$refs['myComp']
        ? _this.$refs['myComp'].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model
        : ''
      this.$store.commit('setRecordingPlayPage', obj)
      if (strateObject) {
        _this.getParams(searchModel, strateObject)
      } else {
        _this.getParams(
          searchModel,
          _this.$refs['myComp'].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model
        )
      }
      let keyword = ''
      if (strateObject) {
        keyword = _this.getKeyword(strateObject)
      } else {
        keyword = _this.getKeyword(
          _this.$refs['myComp'].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model
        )
      }
      searchModel['wholeContent'] = keyword
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/multipleEsQuery_v2.do',
          Qs.stringify(searchModel)
        )
        .then((res) => {
          this.titleCount = res.data.Count
          if (this.titleCount < 50) {
            this.$message({
              type: 'error',
              message: '训练样本数量不得少于50条',
            })
            this.showCopy = false
          } else {
            this.showCopy = true
          }
          this.numTotal = res.data.Count
          this.tableTtile = res.data.Data
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    //查询特征词列表
    getClusterWordByTreeId() {
      let params = {
        isOther: !!this.$route.params.isOtherZhu,
        pageSize: this.litterSize,
        pageNumber: this.litterPage,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getClusterWordByTreeId',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data.Data.length > 0) {
            let datalast = []
            const AssembleData = res.data.Data
            const dataLetter = res.data.element
            datalast = AssembleData.map((item, index) => {
              return {
                label: item.element,
                value: item.score,
                key: item.element,
                dataLetter: dataLetter[index],
              }
            })
            this.goodNice = datalast
            this.dataValue = datalast
            this.treeTotal = res.data.Count
            this.treeNum = res.data.Count
          }
        })
        .catch(function() {})
    },
    /**
     * 删除任务确认框
     */
    deleteProjectConfirm(projectName) {
      let _this = this
      _this
        .$confirm('确定要删除任务吗', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
        })
        .then(() => {
          let params = {
            icrId: projectName,
          }
          this.axios
            .post(
              currentBaseUrl + '/ivsClusterRule/delClusterRule.do',
              Qs.stringify(params)
            )
            .then(function(response) {
              if (response.data.state == 1) {
                _this.$message({
                  type: 'success',
                  message: '删除成功',
                })
                _this.scoreInquery()
              } else {
                _this.$message({
                  type: 'error',
                  message: '删除失败',
                })
              }
            })
            .catch(function() {
              _this.$message({
                type: 'error',
                message: '删除失败',
              })
            })
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 单独查询穿梭框数据
    aloneTree: function() {
      let reg = /[\u4e00-\u9fa5]/g
      let dataContent = this.pageWide.replace(reg, '')
      dataContent = dataContent.replace('/', '')
      this.lastSize = parseInt(dataContent)
      let searchModel = {
        pageNumber: this.lastPage,
        pageSize: dataContent,
      }
      let urlSuf = 'getClusterWordByTreeId'
      if (this.changeTitle == '复制') {
        urlSuf = 'getClusterWordDataPage'
        searchModel = {
          clusterRuleId: this.tempClusterRuleId,
          pageindex: this.lastPage,
          pagesize: dataContent,
        }
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/' + urlSuf + '.do',
          Qs.stringify(searchModel)
        )
        .then((res) => {
          let datalast = []
          this.treeTotal = res.data.Count
          this.treeNum = res.data.Count
          const AssembleData = res.data.Data
          const dataLetter = res.data.element
          datalast = AssembleData.map((item, index) => {
            return {
              label: item.element,
              value: item.score,
              key: item.element,
              dataLetter: dataLetter[index],
            }
          })
          const existence = this.goodNice.some((item) => {
            return item.label == datalast[0].label
          })
          if (!existence) {
            this.goodNice = this.goodNice.concat(datalast)
            this.dataValue = datalast.concat(this.temporaryAccess)
          } else {
            this.dataValue = datalast
            const specialWord = datalast.map((item) => {
              return item.label
            })
            let matchData = []
            if (this.temporaryAccess.length == 0) {
              this.dataValue = datalast
              this.goodNice = datalast
            } else {
              for (let i = 0; i < this.temporaryAccess.length; i++) {
                if ($.inArray(this.temporaryAccess[i].label, specialWord) < 0) {
                  matchData.push(this.temporaryAccess[i])
                  this.dataValue = datalast.concat(matchData)
                }
              }
            }
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    getParams(param, formId) {
      for (let item in formId) {
        if (typeof formId[item] === 'string') {
          param[item] = formId[item]
        } else if (formId[item] instanceof Array) {
          if (formId[item].length === 2) {
            param[item + '_Min'] = formatdate.formatDate(formId[item][0])
            param[item + '_Max'] = formatdate.formatDate(formId[item][1])
          } else {
            param[item + '_Min'] = ''
            param[item + '_Max'] = ''
          }
        } else if (typeof formId[item] === 'object') {
          for (let jtm in formId[item]) {
            param[jtm] = formId[item][jtm]
          }
        }
      }
      return param
    },
    getKeyword(params) {
      let str = ''
      if (params['wholeContent_firstKey']) {
        str += params['wholeContent_firstKey'] + ' '

        if (params['wholeContent_firstLogic'] && params['wholeContent_secondKey']) {
          str +=
            params['wholeContent_firstLogic'] + ' ' + params['wholeContent_secondKey']
          if (params['wholeContent_MidLogic']) {
            if (params['wholeContent_thirdKey']) {
              str += ' ' + params['wholeContent_MidLogic'] + ' '
              str += params['wholeContent_thirdKey'] + ' '
              if (params['wholeContent_LastLogic'] && params['wholeContent_LastKey']) {
                str +=
                  params['wholeContent_LastLogic'] + ' ' + params['wholeContent_LastKey']
              }
            }
          }
        }
      }

      return str
    },
    newModel: function() {
      if (this.makeVlue == 0) {
        this.optionLeft = true
      } else {
        this.optionLeft = false
        let _this = this
        let params = {}
        this.axios
          .post(currentBaseUrl + '/ivsClusterRule/getBaseModel.do', Qs.stringify(params))
          .then(function(response) {
            _this.modelList = response.data
          })
          .catch(function() {
            _this.$message({
              type: 'error',
              message: '模型获取失败',
            })
          })
      }
    },
    addShow: function() {
      this.inputShow = true
    },
    formatDate(obj) {
      let date = new Date(obj)
      let y = 1900 + date.getYear()
      let m = '0' + (date.getMonth() + 1)
      let d = '0' + date.getDate()
      let h = '0' + date.getHours()
      let f = '0' + date.getMinutes()
      let s = '0' + date.getSeconds()
      return (
        y +
        '-' +
        m.substring(m.length - 2, m.length) +
        '-' +
        d.substring(d.length - 2, d.length) +
        ' ' +
        h.substring(h.length - 2, h.length) +
        ':' +
        f.substring(f.length - 2, f.length) +
        ':' +
        s.substring(s.length - 2, s.length)
      )
    },
    // 复制功能
    copyTable: function(index) {
      this.axios
        .get(
          currentBaseUrl +
            '/ivsClusterRule/checkClusterTrain?companyId=' +
            this.$store.state.loginUserinfo.companyId
        )
        .then((res) => {
          if (res.data === true) {
            this.copyModel(index)
          } else {
            this.$message({
              type: 'info',
              message: '不能聚类训练，上次聚类还没有训练完成！',
            })
          }
        })
        .catch(() => {})
    },
    copyModel: function(index) {
      this.showCopy = true // 后改
      this.copyId = index
      this.changeTitle = '复制'
      this.exitPage = true
      this.choiceData = false
      this.ConfigurationPage = true
      this.copyNo = false
      this.newCopy = false
      this.lastSize = 10
      this.lastPage = 1
      this.pageWide = '10条/页'
      this.task2Form.name = ''
      this.tempClusterRuleId = index
      let params = {
        clusterRuleId: index,
        pageindex: this.currentPage,
      }
      this.axios
        .get(currentBaseUrl + '/ivsClusterRule/clusterRule/' + index)
        .then((resp) => {
          let dataBack = resp.data.data
          this.longName = dataBack.belongClassName
          this.dataNumber = dataBack.trainSampleNum
          if (dataBack.createMode == '训练新模型') {
            this.optionLeft = true
            this.makeVlue = 0
          } else {
            this.optionLeft = false
            this.makeVlue = 1
          }
          if (dataBack.monitoringMode == 1) {
            this.firstShow = true
          } else {
            this.firstShow = false
          }
        })
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getEnableClusterWords.do',
          Qs.stringify(params)
        )
        .then((resp) => {
          this.sample = resp.data.strategy
          let strategy = resp.data.strategy
          let paramArray = []
          if (strategy == null || strategy.length == 0) {
            let sortRecordQuery = resp.data.sortRecordQuery
            if (sortRecordQuery == null || sortRecordQuery.length == 0) {
              if (
                resp.data.clusterRule.belongClassName != null &&
                resp.data.clusterRule.belongClassName != ''
              ) {
                this.longName = resp.data.clusterRule.belongClassName
              } else {
                this.longName = '全部录音'
              }
            } else {
              if (
                resp.data.clusterRule.belongClassName != null &&
                resp.data.clusterRule.belongClassName != ''
              ) {
                paramArray.push(resp.data.clusterRule.belongClassName)
              }
              if (sortRecordQuery.callSTimeMax && sortRecordQuery.callSTimeMin) {
                paramArray.push(
                  '录音时间: ' +
                    sortRecordQuery.callSTimeMin +
                    ' - ' +
                    sortRecordQuery.callSTimeMax
                )
              }
              if (sortRecordQuery.keyWords) {
                paramArray.push('热词: ' + sortRecordQuery.keyWords)
              }
              if (sortRecordQuery.callId) {
                paramArray.push('编号: ' + sortRecordQuery.callId)
              }
              if (sortRecordQuery.labelIds) {
                paramArray.push('关键词标签: ' + sortRecordQuery.labelIds)
              }
              if (sortRecordQuery.sentimentRole && sortRecordQuery.sentimentLabel) {
                let sentimentRole = ''
                switch (sortRecordQuery.sentimentRole) {
                  case '0':
                    sentimentRole = '全部'
                    break
                  case '1':
                    sentimentRole = '客户'
                    break
                  default:
                    sentimentRole = '坐席'
                }
                let sentimentLabel
                switch (sortRecordQuery.sentimentLabel) {
                  case '0':
                    sentimentLabel = '积极'
                    break
                  case '1':
                    sentimentLabel = '正常'
                    break
                  default:
                    sentimentLabel = '消极'
                }
                paramArray.push('情绪标签: ' + sentimentRole + sentimentLabel)
              }
            }
          } else {
            let paramMap = {}
            let keys = []
            for (let i = 0; i < strategy.length; i++) {
              if (strategy[i].key.indexOf('最大') == 0) {
                let key = strategy[i].key.substring(2)
                let values = paramMap[key]
                if (values == null || values.length < 2) {
                  paramMap[key] = [null, strategy[i].value]
                  keys.push(key)
                } else {
                  values[1] = strategy[i].value
                }
              } else if (strategy[i].key.indexOf('最小') == 0) {
                let key = strategy[i].key.substring(2)
                let values = paramMap[key]
                if (values == null || values.length < 2) {
                  paramMap[key] = [strategy[i].value, null]
                  keys.push(key)
                } else {
                  values[0] = strategy[i].value
                }
              } else {
                paramMap[strategy[i].key] = [strategy[i].value]
                keys.push(strategy[i].key)
              }
            }
            for (let i = 0; i < keys.length; i++) {
              let values = paramMap[keys[i]]
              if (values.length == 1) {
                paramArray.push(keys[i] + ': ' + values[0])
              } else if (values.length == 2) {
                if (values[0] != null && values[1] != null) {
                  paramArray.push(keys[i] + ': ' + values[0] + ' - ' + values[1])
                } else if (values[0] == null && values[1] != null) {
                  paramArray.push(keys[i] + ': 小于等于' + values[1])
                } else if (values[0] != null && values[1] == null) {
                  paramArray.push(keys[i] + ': 大于等于' + values[0])
                }
              }
            }
          }
          if (paramArray.length > 0) {
            this.longName = paramArray.join('<br/>')
          }
        })
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getClusterWordData.do',
          Qs.stringify(params)
        )
        .then((resp) => {
          let datalast = []
          const AssembleData = resp.data.allKeyword
          const dataLetter = resp.data.enableKeyword
          datalast = AssembleData.map((item, index) => {
            return {
              label: item.wordName,
              value: item.docNum,
              key: index,
              dataLetter: dataLetter[index],
            }
          })
          this.treeNum = resp.data.count
          this.treeTotal = resp.data.count
          this.CharacterTable = dataLetter
          this.goodNice = datalast
          this.dataValue = datalast
        })
    },
    scoreInquery() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else if (this.searchForm.callSTime[0] != '') {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else if (this.searchForm.callSTime[1] != '') {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        createTimeMin: fromTime,
        createTimeMax: toTime,
        baseModel: this.queryParams.taskNo,
        sampleSource: this.queryParams.taskState,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getClusterRuleData.do',
          Qs.stringify(params)
        )
        .then((resp) => {
          if (resp.data.Count) {
            this.tableData = resp.data.Data
            this.filterButton() // 过滤权限按钮
          } else {
            this.tableData = []
          }
          this.total = resp.data.Count
        })
    },
    handleSelectionChange(val) {
      this.selectedArr = val
    },
    stateChange: function(index, cell) {
      let params = {
        baseModel: index,
        clusterRuleId: cell,
      }
      let _this = this
      this.axios
        .post(currentBaseUrl + '/ivsClusterRule/saveBaseMode.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.state == 1) {
            _this.$message({
              type: 'success',
              message: '操作成功',
            })
          } else {
            _this.$message({
              type: 'error',
              message: '操作失败',
            })
          }
        })
    },
    setLook(index) {
      let params = {
        clusterRuleId: index,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getEnableClusterWords.do',
          Qs.stringify(params)
        )
        .then((resp) => {
          // 这里只是查看配置数据的回填
          this.setAlldate = resp.data.clusterRule
          this.setAlldate.monitoringMode == 0
            ? (this.setAlldate.monitoringMode = '无监督模式')
            : (this.setAlldate.monitoringMode = '半监督模式')
          this.numCount = resp.data.Count
          this.tableDataswer = resp.data.Data
          let strategy = resp.data.strategy
          let paramArray = []
          if (strategy == null || strategy.length == 0) {
            let sortRecordQuery = resp.data.sortRecordQuery
            if (sortRecordQuery == null || sortRecordQuery.length == 0) {
              if (
                this.setAlldate.belongClassName != null &&
                this.setAlldate.belongClassName != ''
              ) {
                this.belongClassName = this.setAlldate.belongClassName
              } else {
                this.belongClassName = '全部录音'
              }
            } else {
              if (
                this.setAlldate.belongClassName != null &&
                this.setAlldate.belongClassName != ''
              ) {
                paramArray.push(this.setAlldate.belongClassName)
              }
              if (sortRecordQuery.callSTimeMax && sortRecordQuery.callSTimeMin) {
                paramArray.push(
                  '录音时间: ' +
                    sortRecordQuery.callSTimeMin +
                    ' - ' +
                    sortRecordQuery.callSTimeMax
                )
              }
              if (sortRecordQuery.keyWords) {
                paramArray.push('热词: ' + sortRecordQuery.keyWords)
              }
              if (sortRecordQuery.callId) {
                paramArray.push('编号: ' + sortRecordQuery.callId)
              }
              if (sortRecordQuery.labelIds) {
                paramArray.push('关键词标签: ' + sortRecordQuery.labelIds)
              }
              if (sortRecordQuery.sentimentRole && sortRecordQuery.sentimentLabel) {
                let sentimentRole = ''
                switch (sortRecordQuery.sentimentRole) {
                  case '0':
                    sentimentRole = '全部'
                    break
                  case '1':
                    sentimentRole = '客户'
                    break
                  default:
                    sentimentRole = '坐席'
                }
                let sentimentLabel
                switch (sortRecordQuery.sentimentLabel) {
                  case '0':
                    sentimentLabel = '积极'
                    break
                  case '1':
                    sentimentLabel = '正常'
                    break
                  default:
                    sentimentLabel = '消极'
                }
                paramArray.push('情绪标签: ' + sentimentRole + sentimentLabel)
              }
            }
          } else {
            let paramMap = {}
            let keys = []
            for (let i = 0; i < strategy.length; i++) {
              if (strategy[i].key.indexOf('最大') == 0) {
                let key = strategy[i].key.substring(2)
                let values = paramMap[key]
                if (values == null || values.length < 2) {
                  paramMap[key] = [null, strategy[i].value]
                  keys.push(key)
                } else {
                  values[1] = strategy[i].value
                }
              } else if (strategy[i].key.indexOf('最小') == 0) {
                let key = strategy[i].key.substring(2)
                let values = paramMap[key]
                if (values == null || values.length < 2) {
                  paramMap[key] = [strategy[i].value, null]
                  keys.push(key)
                } else {
                  values[0] = strategy[i].value
                }
              } else {
                paramMap[strategy[i].key] = [strategy[i].value]
                keys.push(strategy[i].key)
              }
            }
            for (let i = 0; i < keys.length; i++) {
              let values = paramMap[keys[i]]
              if (values.length == 1) {
                paramArray.push(keys[i] + ': ' + values[0])
              } else if (values.length == 2) {
                if (values[0] != null && values[1] != null) {
                  paramArray.push(keys[i] + ': ' + values[0] + ' - ' + values[1])
                } else if (values[0] == null && values[1] != null) {
                  paramArray.push(keys[i] + ': 小于等于' + values[1])
                } else if (values[0] != null && values[1] == null) {
                  paramArray.push(keys[i] + ': 大于等于' + values[0])
                }
              }
            }
          }
          if (paramArray.length > 0) {
            this.belongClassName = paramArray.join('<br>')
          }
          this.LookDealog = true
          this.filterButton() // 过滤权限按钮
        })
    },
    // 将录音时长转换为秒
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    // 将状态转换为数字
    setStatus(row, column) {
      if (row.resultStatus == 1) {
        return '待启动'
      } else if (row.resultStatus == 2) {
        return '训练中'
      } else if (row.resultStatus == 3) {
        return '已结束'
      } else {
        return '失败'
      }
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.scoreInquery()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.scoreInquery()
    },
    litterChange: function(val) {
      this.litterSize = val
      this.multipleEsQuery()
    },
    litterCurrentChange(val) {
      this.litterPage = val
      this.multipleEsQuery()
    },
    lastChange: function(val) {
      this.lastSize = val
      this.aloneTree()
    },
    lastCurrentChange: function(val) {
      this.lastPage = val
      console.log(this.CharacterTable)
      this.filterData = this.CharacterTable
      let filterArr = this.goodNice.filter((item) =>
        this.filterData.some((ele) => ele === item.label)
      )
      this.temporaryAccess = filterArr
      this.aloneTree()
    },
    lastNode: function() {
      this.aloneTree()
    },
    radioLeftclickThrottle: function() {
      this.lodashThrottle.throttle(this.radioLeftclick, this)
    },
    copyDown: function() {
      this.lodashThrottle.throttle(this.copyPremary, this)
    },
    copyPremary: function() {
      let _this = this
      let firty = this
      firty.$refs.threeForm.validate((validate) => {
        if (!validate) {
          this.$message.error('填写必填项')
          throw new Error('填写必填项')
        }
      })
      if (this.makeVlue == 1) {
        let addRight = this
        addRight.$refs.opinrightForm.validate((validate) => {
          if (!validate) {
            this.$message.error('填写必填项')
            throw new Error('填写必填项')
          }
        })
      }
      if (this.makeVlue == 1) {
        this.makeVlue = this.modelSeat.chModel
      }
      let stringArr = this.CharacterTable.join()
      let searchModel = {}
      searchModel.pageNumber = this.litterPage
      searchModel.pageSize = this.litterSize
      searchModel.sortField = 'callSTime'
      searchModel.selectType = 'new'
      searchModel.sortType = 'DESC'
      searchModel.termRole = this.clusterRole
      searchModel.timeType = this.timeType
      searchModel.clusterRuleName = this.task2Form.name
      searchModel.createMode = this.makeVlue
      searchModel.startKeyword = stringArr
      searchModel.clusterRuleId = this.copyId
      searchModel.sampleSource = '录音筛选'
      let obj = {}
      obj.searchModel = JSON.parse(JSON.stringify(searchModel))
      obj.searchModel.searchType = this.searchType
      this.$store.commit('setRecordingPlayPage', obj)
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/copyClusterRule.do',
          Qs.stringify(searchModel)
        )
        .then(function(response) {
          if (response.data.state == 1) {
            _this.$message({
              type: 'success',
              message: '新建成功',
            })
            _this.exitPage = false
            _this.scoreInquery()
          } else {
            _this.$message({
              type: 'error',
              message: response.data.message,
            })
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '新建失败',
          })
        })
    },
    radioLeftclick: function(strateObject) {
      let firty = this
      firty.$refs.threeForm.validate(function(validate) {
        if (!validate) {
          throw new Error('填写必填项')
        }
      })
      if (this.makeVlue == 1) {
        let addRight = this
        addRight.$refs.opinrightForm.validate(function(validate) {
          if (!validate) {
            throw new Error('填写必填项')
          }
        })
      }
      if (this.makeVlue == 1) {
        this.makeVlue = this.modelSeat.chModel
      }
      let _this = this
      let stringArr = this.CharacterTable.join()
      let searchModel = {}
      searchModel.pageNumber = this.litterPage
      searchModel.pageSize = this.litterSize
      searchModel.sortField = 'callSTime'
      searchModel.selectType = 'new'
      searchModel.sortType = 'DESC'
      searchModel.termRole = this.clusterRole
      searchModel.timeType = this.timeType
      searchModel.clusterRuleName = this.task2Form.name
      searchModel.createMode = this.makeVlue
      searchModel.startKeyword = stringArr
      searchModel.sampleSource = '录音筛选'
      let obj = {}
      obj.searchModel = JSON.parse(JSON.stringify(searchModel))
      obj.searchModel.searchType = this.searchType
      obj.searchModel.searchObj = _this.$refs['myComp']
        ? _this.$refs['myComp'].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model
        : ''
      this.$store.commit('setRecordingPlayPage', obj)
      if (strateObject) {
        _this.getParams(searchModel, strateObject)
      } else {
        _this.getParams(
          searchModel,
          _this.$refs['myComp'].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model
        )
      }
      let keyword = ''
      if (strateObject) {
        keyword = _this.getKeyword(strateObject)
      } else {
        keyword = _this.getKeyword(
          _this.$refs['myComp'].analyticRecordPro_reQaSampoolSeat_fastFilterYuyin_Model
        )
      }
      searchModel['wholeContent'] = keyword
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/addClusterRule.do',
          Qs.stringify(searchModel)
        )
        .then(function(response) {
          if (response.data.state == 1) {
            _this.$message({
              type: 'success',
              message: '新建成功',
            })
            _this.exitPage = false
            _this.scoreInquery()
          } else {
            _this.$message({
              type: 'error',
              message: response.data.message,
            })
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '新建失败',
          })
        })
    },
    searchAttr(formId) {
      for (let item in formId) {
        if (item.indexOf('$') != -1) {
          formId[item] = ''
        }
      }
    },
    /*
     * 过滤权限按钮
     * */
    filterButton() {
      /*
     获取数据后dom节点更改了，
      需要再获取一遍dom节点对[funcID]按钮进行过滤
     * */
      let menuId = localStorage.getItem('menuId')
      let path = this.$route.path.replace('/', '')
      funcFilter(menuId, path)
    },
  },
  computed: {
    clusterRole() {
      return this.$store.state.StringData.clusterRole
    },
  },
  created() {
    this.scoreInquery()
  },
}
</script>
<style lang="less">
.titleFind {
  display: inline-block;
  float: left;
}
.titleScrite {
  display: inline-block;
  margin-left: 60px;
}
.classTable {
  .operation {
    .opeatLeft {
      margin-right: 4px;
    }
  }
}
.heightCell {
  height: 185px;
}
.title-flex {
  display: flex;
  flex-direction: row;
  .title-flex-l {
    flex-basis: 100px;
    text-align: right;
    padding: 10px 15px;
  }
  .title-flex-r {
    flex-basis: 470px;
    padding: 10px 0;
  }
}
.pageChangeNo {
  padding: 5px 30px;
  text-align: center;
}
.titleRight {
  display: inline-block;
  padding-left: 20px;
}
.titleLeft {
  display: inline-block;
  padding: 10px 20px;
}
#soundfeature {
  box-sizing: border-box;
  height: 100%;
  width: 100%;
  overflow: hidden;
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
  .conpalinDiv {
    width: 100%;
    height: 90%;
    .changeCondtion {
      width: 100%;
      height: 44px;
      margin: 20px 0;
    }
    .content {
      padding-bottom: 80px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .table {
      width: 100%;
      height: 100%;
      overflow: auto;
    }
    .autoGrading-page {
      height: 35px;
      position: absolute;
      background: white;
      right: 0px;
      bottom: 0px;
      text-align: right;
      .el-pagination {
        display: inline-block;
        height: 28px;
        line-height: 28px;
        padding: 0px 10px;
      }
    }
  }
}
</style>
<style lang="less">
#tableFindset th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}
.content .table th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}
.el-pagination__total {
  height: 35px;
  line-height: 35px;
}
.classTable .el-pager li {
  height: 28px;
  line-height: 28px;
}
.btn-prev,
.btn-next {
  height: 35px;
  line-height: 35px;
}
.el-textarea__inner {
  width: 80%;
  height: 200px;
}
.edealFind {
  .el-dialog__body {
    padding: 0;
  }
  .el-dialog__header {
    padding: 20px 0px 10px 0px;
    border-bottom: 1px solid #e0e6ed;
    .el-dialog__title {
      padding-left: 20px;
      font-size: 16px;
      font-weight: bolder;
    }
  }
  .speshowsl .dealCenter .el-input__inner {
    width: 240px;
  }
}
.el-popover {
  width: 25%;
}
.playuer {
  padding-left: 20px;
}
.block .el-pagination button {
  height: 28px;
  line-height: 28px;
}
#block .el-pagination {
  text-align: center;
  .el-pager li {
    margin: 0;
    min-width: 0px;
    height: 28px;
    line-height: 28px;
    border: 1px solid #e0e6ed;
  }
  button {
    height: 28px;
    line-height: 28px;
    border: 1px solid #e0e6ed;
    margin: 0;
    min-width: 20px;
  }
}
.findBorder .el-transfer-panel {
  width: 288px;
}
.findBorder .el-checkbox:last-child {
  margin-right: 30px;
}
.pageChangeNo .el-select {
  width: 110px;
  .el-input__inner {
    height: 36px;
    line-height: 36px;
  }
}
.madeModel h3 {
  padding: 14px 32px;
}
.madeModel .el-row {
  margin-left: 16px;
}
.aloneChange .el-form-item__label {
  text-align: left;
}
.formDiv {
  display: inline-block;
  width: 280px;
}
.abow_dialog {
  display: flex;
  justify-content: center;
  align-items: center;
  .el-dialog {
    margin: 0 auto !important;
    height: 720px;
    .el-dialog__body {
      position: absolute;
      left: 0;
      top: 54px;
      bottom: 0;
      right: 0;
      padding: 0;
      z-index: 1;
    }
  }
}
</style>

<style scoped lang="less">
.addName {
  display: inline-block;
  height: 30px;
  margin: 4px 10px;
  line-height: 30px;
  width: 30px;
  text-align: center;
  border: 1px solid #dcdfe6;
  border-radius: 50%;
  cursor: pointer;
}
.cellDiv {
  .el-form-item__content {
    float: left;
  }
}
</style>
