<template>
  <div id="result" class="result">
    <div class="resultHeader">
      <div class="tabs">
        <p id="tabsOne" class="active" @click="tabsCheck(1)">主题聚类</p>
        <p id="tabsTwo" class="none" @click="tabsCheck(2)">典型问法</p>
      </div>
      <div class="buttons">
        <el-button type="primary" @click="again">重新执行</el-button>
        <el-button @click="editSample">修改样本</el-button>
        <el-button @click="maintain">维护词表</el-button>
        <el-button @click="returnIndex">返回</el-button>
      </div>
    </div>
    <el-dialog title="修改样本" :visible.sync="dialogVisible">
      <div style="height:530px; overflow: auto">
        <vAddTrainSample></vAddTrainSample>
      </div>
      <div style="float: right; padding-bottom: 20px;">
        <el-button @click="canel" type="primary">确定</el-button>
        <el-button @click="canel">取消</el-button>
      </div>
    </el-dialog>
    <el-dialog title="维护词表" :visible.sync="dialogMaintainVisible">
      <div style="height:500px; overflow: auto">
        <vEnableThesaurus></vEnableThesaurus>
      </div>
      <div style="float: right; padding-bottom: 20px;">
        <el-button @click="canelEnable" type="primary">确定</el-button>
        <el-button @click="canelEnable">取消</el-button>
      </div>
    </el-dialog>
    <div class="resultContent" style="padding-bottom: 80px" v-show="!isShow">
      <div class="table">
        <div class="resultContainer" v-if="topicData.length > 0">
          <div v-for="(item, index) in topicData">
            <div v-if="index % 2 == 0" class="themeSmall box">
              <div class="active">
                <div class="boxHeader">
                  <p>{{ item.key }} ({{ item.value.length }})</p>
                </div>
                <div class="tableContent">
                  <div style="width: 100%; overflow:auto;height: 100%;">
                    <el-table :data="item.value" style="width: 100%">
                      <el-table-column prop="objectId" label="录音编号" width="180">
                        <template scope="scope">
                          <el-button
                            type="text"
                            @click="
                              jumpToSound(scope.row.objectId, scope.row.recordFileURL)
                            "
                            >{{ scope.row.objectId }}
                          </el-button>
                        </template>
                      </el-table-column>
                      <el-table-column prop="seatName" label="坐席姓名" width="180">
                      </el-table-column>
                      <el-table-column label="录音时长">
                        <template slot-scope="scope">
                          {{ scope.row.callTime | convertCallTime }}
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </div>
              </div>
            </div>
            <div v-else class="box" style="float: right">
              <div class="active">
                <div class="boxHeader">
                  <p>{{ item.key }} ({{ item.value.length }})</p>
                </div>
                <div class="tableContent">
                  <div style="width: 100%; overflow:auto;height: 100%;">
                    <el-table :data="item.value" style="width: 100%">
                      <el-table-column prop="objectId" label="录音编号" width="180">
                        <template scope="scope">
                          <el-button
                            type="text"
                            @click="
                              jumpToSound(scope.row.objectId, scope.row.recordFileURL)
                            "
                            >{{ scope.row.objectId }}
                          </el-button>
                        </template>
                      </el-table-column>
                      <el-table-column prop="seatName" label="坐席姓名" width="180">
                      </el-table-column>
                      <el-table-column label="录音时长">
                        <template slot-scope="scope">
                          {{ scope.row.callTime | convertCallTime }}
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="resultContainer" v-else="">
          <p style="padding: 10px;text-align: center">暂无数据</p>
        </div>
      </div>
      <div class="page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageindex"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="pagesize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="totalCount"
        >
        </el-pagination>
      </div>
    </div>
    <div class="resultContent" v-show="isShow">
      <div class="rightTable">
        <div class="rightTableBox" v-if="questionData.length > 0">
          <div class="leftList">
            <div class="newList">
              <ul>
                <li
                  :class="item.isCheck"
                  v-for="(item, index) in questionData"
                  @click="clickItem(item, index)"
                >
                  {{ item.topicContent }}<span>{{ item.tqGroup }}</span>
                </li>
              </ul>
            </div>
            <div class="pages">
              <el-pagination
                @size-change="handleSizeChangeQues"
                @current-change="handleCurrentChangeQues"
                :current-page.sync="pageIndexQues"
                :page-size="pageSizeQues"
                layout="prev, pager, next"
                :total="totalQus"
              >
              </el-pagination>
            </div>
          </div>
          <div class="rightList">
            <div class="rightContent">
              <div class="detailData" v-for="item in detailList">
                {{ item.tquestionContent }}
              </div>
            </div>
            <div class="pageRight">
              <el-pagination
                @size-change="handleSizeChangeDetail"
                @current-change="handleCurrentChangeDetail"
                :current-page="pageIndexDetail"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="pageSizeDetail"
                layout="total, sizes, prev, pager, next, jumper"
                :total="detailCount"
              >
              </el-pagination>
            </div>
          </div>
        </div>
        <div class="rightTableBox" v-else="">
          <p style="padding: 10px; text-align: center">暂无数据</p>
        </div>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<style lang="less" scoped="scoped">
.result {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .rightTable {
    width: 100%;
    height: 100%;
    /* overflow: auto;*/
  }
  .rightTableBox {
    width: 100%;
    box-sizing: border-box;
    height: 100%;
    position: relative;
    .leftList {
      width: 350px;
      height: 100%;
      float: left;
      position: relative;
      .newList {
        position: absolute;
        top: 5px;
        left: 0px;
        bottom: 50px;
        overflow: auto;
        width: 100%;
        cursor: pointer;
        ul li {
          height: 40px;
          line-height: 40px;
          font-size: 14px;
          color: #1f2d3d;
          border-bottom: 1px dashed #d1dbe5;
          span {
            background: #20a0ff;
            width: 20px;
            height: 20px;
            line-height: 20px;
            text-align: center;
            border-radius: 70%;
            display: inline-block;
            float: right;
            margin-right: 10px;
            margin-top: 10px;
            font-size: 12px;
            color: #fff;
          }
        }
        .bg {
          background: #eef1f6;
        }
        ul li:hover {
          background: #eef1f6;
        }
      }
      .pages {
        position: absolute;
        bottom: 0px;
        left: 0px;
        width: 100%;
      }
    }
    .rightList {
      height: 100%;
      margin-left: 350px;
      position: relative;
      border-left: 1px solid #d1dbe5;
      .rightContent {
        position: absolute;
        top: 5px;
        left: 0px;
        bottom: 80px;
        overflow: auto;
        width: 100%;
        cursor: pointer;
        .detailData {
          margin-bottom: 10px;
          padding-bottom: 10px;
          padding-left: 10px;
          font-size: 14px;
          line-height: 26px;
          border-bottom: 1px dashed #ccc;
        }
      }
      .pageRight {
        right: 10px;
        position: absolute;
        bottom: 10px;
      }
    }
  }
  .resultHeader {
    float: left;
    box-sizing: border-box;
    top: 0px;
    width: 100%;
    height: 58px;
    .tabs {
      float: left;
      margin-top: 10px;
      .active {
        border-bottom: 5px solid #2a3747;
        color: #1f2d3d;
      }
      .none {
        border-bottom: 5px solid #d3dde6;
        color: #8691a5;
      }
      p {
        cursor: pointer;
        padding-bottom: 10px;
        margin: 0px 0px 0px 10px;
        font-size: 14px;
        display: inline-block;
        float: left;
        width: 110px;
        text-align: center;
      }
    }
    .buttons {
      margin-top: 10px;
      float: right;
    }
  }

  .resultContent {
    padding-top: 60px;
    padding-bottom: 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    .table {
      width: 100%;
      height: 100%;
      overflow: auto;
      .resultContainer {
        height: 100%;
        width: 100%;
        box-sizing: border-box;
        position: relative;
        .box {
          border: 1px solid #d1dbe5;
          margin-top: 10px;
          box-sizing: border-box;
          float: left;
          height: 400px;
          width: 49%;
          .active {
            width: 100%;
            box-sizing: border-box;
            height: 100%;
            position: relative;
          }
        }
        .tableContent {
          padding-top: 10px;
          padding-bottom: 60px;
          padding-left: 10px;
          padding-right: 10px;
          box-sizing: border-box;
          width: 100%;
          height: 100%;
        }
        .boxHeader {
          height: 45px;
          line-height: 45px;
          background: #eef1f6;
          width: 100%;
          box-sizing: border-box;
          p {
            color: #5e6d82;
            font-weight: bold;
            padding: 0px 10px 0px 10px;
          }
        }
      }
    }
    .page {
      right: 10px;
      position: absolute;
      bottom: 10px;
    }
  }
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
}
</style>
<style>
#result .el-dialog__body {
  padding: 0px 20px;
}

#result .addTrainSampleContent {
  padding-top: 0px;
  padding-bottom: 10px;
}

#result .enableContent {
  padding-top: 0px;
  padding-bottom: 10px;
}
#result .single.el-dialog__wrapper {
  position: fixed;
  top: 106px;
  left: 20px;
  right: 20px;
  bottom: 12px;
}
#result .single.el-dialog__wrapper .el-dialog {
  width: 100%;
  height: 100%;
  margin: 0 !important;
}

#result .single .el-dialog__header {
  display: none;
}

#result .single .el-dialog__body {
  padding: 10px 20px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}
#result .single .el-dialog--large {
  height: 84%;
  top: 5% !important;
}
</style>
<script>
import $ from 'jquery'
import vAddTrainSample from './addTrainSample'
import vEnableThesaurus from './enableThesaurus'
import Qs from 'qs'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
import recordingplay from '../recordingPlay/recordingPlayNew.vue'
import bus from '../../common/bus.js'
export default {
  components: {
    vAddTrainSample,
    vEnableThesaurus,
    recordingplay,
  },
  data() {
    return {
      recordDialogVisible: false,
      topicData: [],
      topicValueData: [],
      pageIndexDetail: 1,
      pageSizeDetail: 20,
      totalQus: 0,
      pageIndexQues: 1,
      pageSizeQues: 20,
      questionData: [],
      detailList: [],
      detailCount: 0,
      totalCount: 0,
      tableData: [],
      dialogVisible: false,
      isShow: false,
      pageindex: 1,
      pagesize: 10,
      dialogMaintainVisible: false,
      cRuleId: '',
      topicNo: '',
    }
  },
  methods: {
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    again: function() {
      let params = {
        clusterRuleId: this.clusterRuleId,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/createClusterRuleModel.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data.state === '1') {
            this.$message.success('操作成功')
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 跳转到录音播放页面
    jumpToSound: function(objectId, recordFileURL) {
      let obj = {}
      obj.from = 'result'
      obj.callId = objectId
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlay')
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    clickItem(data, itemindex) {
      let item
      this.cRuleId = data.clusterRuleId
      this.topicNo = data.topicNo
      for (item in this.questionData) {
        if (item == itemindex) {
          this.questionData[item].isCheck = 'bg'
        } else {
          this.questionData[item].isCheck = ''
        }
      }
      this.getTypicalQuestionDetailData()
    },
    // 获取典型问法详情
    getTypicalQuestionDetailData: function() {
      let params = {
        clusterRuleId: this.cRuleId,
        topicNo: this.topicNo,
        pageindex: this.pageIndexDetail,
        pagesize: this.pageSizeDetail,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getTypicalQuestionDetailData.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.detailList = res.data.Data
          this.detailCount = res.data.Count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.getTopicClusterData()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.getTopicClusterData()
    },
    /**
     * 每页条数
     * **/
    handleSizeChangeDetail(val) {
      this.pageSizeDetail = val
      this.pageIndexDetail = 1
      this.getTypicalQuestionDetailData()
    },
    /**
     *当前页数
     * */
    handleCurrentChangeDetail(val) {
      this.pageIndexDetail = val
      this.getTypicalQuestionDetailData()
    },
    /**
     * 每页条数
     * **/
    handleSizeChangeQues(val) {
      this.pageSizeQues = val
      this.pageIndexQues = 1
      this.getTypicalQuestionData()
    },
    /**
     *当前页数
     * */
    handleCurrentChangeQues(val) {
      this.pageIndexQues = val
      this.getTypicalQuestionData()
    },
    // 维护词表
    maintain: function() {
      let StringData = {}
      StringData.pageType = 3
      StringData.clusterRuleId = this.clusterRuleId
      this.$store.commit('setStringData', StringData)
      this.dialogMaintainVisible = true
    },
    canelEnable: function() {
      this.dialogMaintainVisible = false
    },
    canel: function() {
      this.dialogVisible = false
    },
    editSample: function() {
      let StringData = {}
      StringData.clusterRole = this.clusterRole
      StringData.pageType = 3
      StringData.clusterRuleId = this.clusterRuleId
      this.$store.commit('setStringData', StringData)
      this.dialogVisible = true
    },
    returnIndex() {
      this.$router.push('/clusterRule_hrlist')
    },
    // 获得典型问法数据
    getTypicalQuestionData: function() {
      let params = {
        clusterRuleId: this.clusterRuleId,
        pagesize: this.pageSizeQues,
        pageindex: this.pageIndexQues,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getTypicalQuestionData.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.totalQus = res.data.Count
          let qData = res.data.Data
          let item
          for (item in qData) {
            qData[item].isCheck = 'bg'
            qData[0].isCheck = 'bg'
          }
          this.questionData = qData
          if (this.questionData.length > 0) {
            this.clickItem(this.questionData[0], 0)
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    tabsCheck: function(val) {
      if (val == 1) {
        this.isShow = false
        $('#tabsOne').addClass('active')
        $('#tabsOne').removeClass('none')
        $('#tabsTwo').removeClass('active')
        $('#tabsTwo').addClass('none')
      } else {
        this.isShow = true
        $('#tabsTwo').addClass('active')
        $('#tabsTwo').removeClass('none')
        $('#tabsOne').removeClass('active')
        $('#tabsOne').addClass('none')
      }
    },
    // 获取主题聚类
    getTopicClusterData: function() {
      let params = {
        clusterRuleId: this.clusterRuleId,
        pagesize: this.pagesize,
        pageindex: this.pageindex,
      }
      let obj = {}
      obj.searchModel = params
      this.$store.commit('setRecordingPlayPage', obj)
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getTopicClusterData.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.topicData = res.data.Data
          console.log(res)
          this.topicValueData = res.data.Data[0].value
          this.totalCount = res.data.Data.length
        })
        .catch(function(error) {
          console.log(error)
        })
    },
  },
  mounted() {
    if (!this.clusterRuleId) {
      this.$router.push('/clusterRule_hrlist')
    } else {
      this.getTopicClusterData()
      this.getTypicalQuestionData()
    }
  },
  created() {
    this.recordPlayCloseHandler()
    if (
      this.recordingPlayPage.fromPage == 'result' &&
      this.recordingPlayPage.searchModel.pageindex
    ) {
      this.pageindex = this.recordingPlayPage.searchModel.pageindex
      this.pagesize = this.recordingPlayPage.searchModel.pagesize
      this.clusterRuleId = this.recordingPlayPage.searchModel.clusterRuleId
      this.getTopicClusterData()
      this.getTypicalQuestionData()
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
    /* clusterRole(){
       return this.$store.state.StringRule.clusterRole
       }, */
    clusterRuleId() {
      return this.$store.state.StringRule.clusterRuleId
    },
  },
}
</script>
