<template>
  <div style="width: 100%; height: 100%;">
    <div id="qualityCTemplate" v-show="templateShow">
      <div class="containTitle">质检评分模板</div>
      <div class="quality-header">
        <el-button funcId="000069" class="fr" @click="addTemplate">新建模板</el-button>
        <el-form
          ref="searchForm"
          :model="searchForm"
          :inline="true"
          class="demo-form-inline"
        >
          <el-form-item prop="status">
            <el-select placeholder="请选择状态" clearable v-model="searchForm.status">
              <el-option label="启用" value="1">启用</el-option>
              <el-option label="停用" value="2">停用</el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="modleTitle">
            <el-input placeholder="请输入名称" v-model="searchForm.modleTitle"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button @click="searchByName" type="primary" class="fr_primary"
              >查询</el-button
            >
          </el-form-item>
        </el-form>
        <el-dialog
          :close-on-click-modal="false"
          title="新增模板"
          width="640px"
          :visible.sync="addTemplateModal"
        >
          <el-form
            :label-position="labelPosition"
            :model="addTemForm"
            label-width="100px"
            ref="addTemForm"
            :rules="formRules"
          >
            <el-form-item label="模板名称" prop="modleTitle">
              <el-input v-model="addTemForm.modleTitle" class="w200"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="addTemplateYesThrottle">确定</el-button>
              <el-button @click="closeAddTemplateModal">取消</el-button>
            </el-form-item>
          </el-form>
        </el-dialog>
        <el-dialog
          :close-on-click-modal="false"
          title="复制模版"
          width="640px"
          :visible.sync="copyTemplateModal"
        >
          <el-form
            :label-position="labelPosition"
            :model="copyTemForm"
            label-width="100px"
            ref="copyTemForm"
            :rules="formRules"
          >
            <el-form-item label="模板名称" prop="modleTitle">
              <el-input v-model="copyTemForm.modleTitle" class="w200"></el-input>
            </el-form-item>
            <!-- <el-form-item label="合格分数" prop="qualityScore">
               <el-input v-model="addTemForm.qualityScore" class="w200"></el-input>
             </el-form-item>-->
            <el-form-item>
              <el-button type="primary" @click="copyTemplateYesThrottle">确定</el-button>
              <el-button @click="closeCopyTemplateModal">取消</el-button>
            </el-form-item>
          </el-form>
        </el-dialog>
        <el-dialog
          :close-on-click-modal="false"
          :title="modelTitle"
          :visible.sync="editTemplateModal"
        >
          <el-form
            :label-position="labelPosition"
            :model="editTemForm"
            label-width="100px"
            ref="editTemForm"
            :rules="editFormRules"
          >
            <el-form-item label="模板名称" prop="modleTitle">
              <el-input v-model="editTemForm.modleTitle" class="w200"></el-input>
            </el-form-item>
            <!-- <el-form-item label="合格分数" prop="qualityScore">
              <el-input v-model="editTemForm.qualityScore" class="w200"></el-input>
            </el-form-item>-->
            <el-form-item>
              <div v-if="this.modelTitle == '修改模板'">
                <el-button type="primary" @click="editTemplateYesThrottle"
                  >确定</el-button
                >
                <el-button @click="closeEditTemplateModal">取消</el-button>
              </div>
              <div v-else>
                <el-button @click="closeModel">关闭</el-button>
              </div>
            </el-form-item>
          </el-form>
        </el-dialog>
      </div>
      <div class="quality-content">
        <div class="quality-content-table" style="flex:1;overflow: auto;">
          <el-table
            class="fh-table"
            rel="qualityTable"
            border
            highlight-current-row
            height="100%"
            :data="tableData"
            style="width: 100%"
          >
            <el-table-column prop="modleTitle" label="模板名称">
              <template scope="scope">
                <el-button type="text" @click="editTemplateInfo(scope.row)">{{
                  scope.row.modleTitle
                }}</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="createUser" label="创建人"> </el-table-column>
            <el-table-column prop="createTime" label="创建时间" :formatter="dateFormat">
            </el-table-column>
            <el-table-column prop="status" label="状态" width="80">
              <template scope="scope">
                <div v-if="scope.row.status === 1">
                  <el-tag type="success">启用</el-tag>
                </div>
                <div v-else="">
                  <el-tag type="gray">停用</el-tag>
                </div>
              </template>
            </el-table-column>

            <el-table-column label="操作" width="180">
              <template scope="scope">
                <!-- <i class="iconfont icon-brush" @click="handleEdit(scope.$index, scope.row)">
                  <i style="padding-left: 3px; font-size: 14px">编辑</i></i>-->
                <i
                  funcId="000072"
                  style="margin-left: 10px"
                  v-if="scope.row.status === 1"
                  @click="pause(scope.$index, scope.row)"
                  ><i style="font-size: 13px;color:#20A0FF;">停用</i></i
                >
                <i
                  funcId="000071"
                  style="margin-left: 10px"
                  v-else=""
                  @click="pause(scope.$index, scope.row)"
                  ><i style="font-size: 13px;color:#20A0FF;">启用</i></i
                >
                <i
                  funcId="000073"
                  class="ml"
                  @click="copyTemplate(scope.row.modleId, scope.row.updateTime)"
                >
                  <i style="font-size: 13px;color:#20A0FF;">复制</i></i
                >
              </template>
            </el-table-column>
            <el-table-column prop="isRealTime" label="实时质检状态" width="80">
              <template scope="scope">
                <div v-if="scope.row.isRealTime === 1">
                  <el-tag type="success">启用</el-tag>
                </div>
                <div v-else="">
                  <el-tag type="gray">停用</el-tag>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="运用于实时评分" width="150">
              <template scope="scope">
                <!-- <i class="iconfont icon-brush" @click="handleEdit(scope.$index, scope.row)">
                  <i style="padding-left: 3px; font-size: 14px">编辑</i></i>-->
                <i
                  funcId="000329"
                  style="margin-left: 10px"
                  v-if="scope.row.isRealTime === 1"
                  @click="updateIsRealTime(scope.$index, scope.row)"
                  ><i style="font-size: 13px;color:#20A0FF;">停用</i></i
                >
                <i
                  funcId="000328"
                  style="margin-left: 10px"
                  v-else=""
                  @click="updateIsRealTime(scope.$index, scope.row)"
                  ><i style="font-size: 13px;color:#20A0FF;">启用</i></i
                >
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="quality-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="pageindex"
            :page-sizes="[20, 30, 40]"
            :page-size="pagesize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalCount"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <nTemplate
      ref="nTemplate"
      @filterButton="filterButton"
      v-show="!templateShow"
      :baseScore="baseScore"
      :info="countList"
      :mdtitle="textTitle"
      :modleIdNew="modleId"
      :updateTime="updateTime"
      :labelList="labelList"
      v-on:send="changeshow"
    ></nTemplate>
  </div>
</template>
<script>
import nTemplate from './newTemplate_new.vue'
import axios from 'axios'
import Qs from 'qs'
import global from '../../../global.js'
import funcFilter from '@/utils/funcFilter.js'
axios.defaults.withCredentials = true
axios.defaults.headers = {
  'Content-Type': 'application/x-www-form-urlencoded ;charset=UTF-8',
}
let manalScore = global.qualityUrl
let currentBaseUrl = global.currentBaseUrl
import formatdate from '../../../utils/formatdate.js'
export default {
  components: {
    nTemplate,
  },
  mounted() {
    this.getAllModleList()
    this.getAllRecordLabel()
  },
  data() {
    const validModelTitle = (rule, value, callback) => {
      if (value.trim().length > 50) {
        return callback(new Error('不能超过50个字符'))
      } else {
        return callback()
      }
    }
    return {
      copyModelId: '',
      copyModelUpdateTime: '',
      templateShow: true,
      updateTable: false,
      // isStatus: '',
      isStatusTwo: '',
      treedata: [],
      treedataManual: [],
      treeDataList: [],
      treedataManualList: [],
      textTitle: '',
      mdtitle: '',
      info: {},
      modelTitle: '修改模板',
      oldname: '',
      editFormRules: {
        modleTitle: [
          { required: true, message: '请输入模板名称！', trigger: 'blur' },
          { validator: validModelTitle, trigger: 'blur' },
        ],
        /* qualityScore:[{validator: validQualityScore, trigger: 'blur' }] */
      },
      editTemplateModal: false,
      formRules: {
        modleTitle: [
          { required: true, message: '请输入模板名称！', trigger: 'blur' },
          { validator: validModelTitle, trigger: 'blur' },
        ],

        /* qualityScore:[{validator: validQualityScore, trigger: 'blur' }] */
      },
      labelPosition: 'right',
      options: [
        {
          value: '1',
          label: '启用',
        },
        {
          value: '2',
          label: '停用',
        },
      ],
      editTemForm: {
        modleTitle: '',
        status: '',
        // qualityScore:'',
        remark: '',
      },
      addTemForm: {
        modleTitle: '',
        status: '启用',
        // qualityScore:'',
        remark: '',
      },
      copyTemForm: {
        modleTitle: '',
      },
      operation: '',
      modleId: '',
      searchForm: {
        status: '',
        modleTitle: '',
      },
      value3: true,
      value2: false,
      tableData: [],
      totalCount: 0,
      pageindex: 1,
      pagesize: 20,
      current: 1,
      mid: 0,
      isBatch: false,
      batchList: [],
      addTemplateModal: false,
      copyTemplateModal: false,
      mmid: '',
      treedatass: [],
      treedataListss: [],
      isStatus: '0',
      countList: {},
      modleIdNew: '',
      labelList:[],
      baseScore: 100,
      nextModel: false,
      modleIdTwoList: '',
      modleTitleN: '',
      updateTime: '',
    }
  },
  methods: {
    // 获取所有录音标签
    getAllRecordLabel() {
      this.axios
              .get(currentBaseUrl + '/recordLabel/allReordLabelListForModel')
              .then((res) => {
                this.labelList = res.data.data
              })
              .catch(() => {})
    },
    changeshow(input) {
      // 改变当前页面的显示情况（templateShow改变这个值）
      this.templateShow = input
      this.updateTable = false
      this.getAllModleList()
    },
    // 点击修改模板
    editTemplateInfo: function(row) {
      if (row.status != '1') {
        this.$message({
          type: 'warning',
          message: '该模板已经停用',
        })
      } else {
        this.modleId = row.modleId
        this.mmid = row.modleId
        this.modleIdNew = row.modleId
        this.baseScore = row.baseScore
        this.info = row
        this.textTitle = row.modleTitle
        this.countList = row
        this.updateTime = row.updateTime
        this.templateShow = false
      }
    },
    editTemplateYesThrottle() {
      this.lodashThrottle.throttle(this.editTemplateYes, this)
    },
    // 确定修改模板
    editTemplateYes: function() {
      if (this.oldname == this.editTemForm.modleTitle) {
        this.editTemplateModal = false
      } else {
        let status = this.addTemForm.status
        let ssTitle
        if (status == '启用') {
          ssTitle = '1'
        } else {
          ssTitle = '2'
        }
        let params = {
          modleTitle: this.editTemForm.modleTitle,
          qualityScore: this.editTemForm.qualityScore,
          status: ssTitle,
          remark: this.editTemForm.remark,
          modleType: 7,
          modleId: this.modleIdNew,
          linkModleId: '973e5ad4fe5511e6b042000c29a7c029',
          departId: '973e5ad4fe5511e6b042000c29a7c029',
        }
        this.$refs.editTemForm.validate((valid) => {
          if (valid) {
            this.axios
              .post(
                manalScore + '/manualQualityAssurance/saveModle.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data.flag == true) {
                  this.$message({
                    type: 'success',
                    message: '数据提交成功!',
                  })
                } else {
                  if (res.data.flag == false) {
                    this.$message({
                      type: 'error',
                      message: res.data.msg,
                    })
                  } else {
                    this.$message({
                      type: 'error',
                      message: '数据提交失败!',
                    })
                  }
                }
                this.editTemplateModal = false
                this.$refs['editTemForm'].resetFields()
                this.getAllModleList()
              })
              .catch(function(error) {
                console.log(error)
              })
          }
        })
      }
    },
    closeEditTemplateModal: function() {
      this.editTemplateModal = false
    },
    closeModel: function() {
      this.editTemplateModal = false
    },
    /**
     * 点击取消
     * **/
    closeAddTemplateModal: function() {
      this.addTemplateModal = false
      this.$refs['addTemForm'].resetFields()
      this.updateTable == false
    },
    closeCopyTemplateModal: function() {
      this.copyTemplateModal = false
      this.$refs['copyTemForm'].resetFields()
      this.updateTable == false
    },
    addTemplateYesThrottle() {
      this.lodashThrottle.throttle(this.addTemplateYes, this)
    },
    copyTemplateYesThrottle() {
      this.lodashThrottle.throttle(this.copyTemplateYes, this)
    },
    copyTemplateYes: function() {
      let modelTitle = this.copyTemForm.modleTitle.trim()
      if (modelTitle == '') {
        this.$message({
          type: 'error',
          message: '请输入模版名称!',
        })
        return
      }
      let params = {
        modelId: this.copyModelId,
        updateTime: this.copyModelUpdateTime,
        modelTitle: modelTitle,
      }
      this.axios
        .post(
          manalScore + '/manualQualityAssurance/copyNewModel.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data.flag == 'true') {
            this.$message.success('复制模板成功!')
            this.modleId = res.data.modelId
            this.textTitle = res.data.modelTitle
            this.updateTime = res.data.updateTime
            this.baseScore = res.data.baseScore
            this.templateShow = false
            this.getAllModleList()
            this.copyTemplateModal = false
            this.$refs['copyTemForm'].resetFields()
          } else {
            this.$message.error(res.data.msg)
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     * 新建模板确定
     * **/
    addTemplateYes: function() {
      let ssTitle
      ssTitle = '1'
      let modelTitle = this.addTemForm.modleTitle.trim()
      console.log('modelTitle' + modelTitle)
      if (modelTitle == '') {
        this.$message({
          type: 'error',
          message: '请输入模版名称!',
        })
        return
      }
      let params = {
        modleTitle: this.addTemForm.modleTitle,
        qualityScore: this.addTemForm.qualityScore,
        status: ssTitle,
        modleType: 7,
        modleId: '',
        linkModleId: '',
        departId: '',
        isRealTime: '2',
      }
      this.$refs.addTemForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(
              manalScore + '/manualQualityAssurance/saveModle.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data.flag) {
                this.$message.success('新建模板成功!')
                this.modleId = res.data.model['modleId']
                this.updateTime = res.data.model['updateTime']
                this.textTitle = res.data.model['modleTitle']
                this.baseScore = 100
                this.templateShow = false
                this.getAllModleList()
                this.addTemplateModal = false
                this.$refs['addTemForm'].resetFields()
              } else {
                this.$message.error(res.data.msg)
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    /**
     * 点击新建模板
     * **/
    addTemplate: function() {
      this.addTemplateModal = true
      this.treeDataList = []
      this.treedataManualList = []
    },
    // 复制模版
    copyTemplate: function(modelId, updateTime) {
      this.copyModelId = modelId
      this.copyModelUpdateTime = updateTime
      this.copyTemplateModal = true
    },
    /**
     * 根据模板名称/状态查询
     * **/
    searchByName: function() {
      this.pageindex = 1
      this.updateTable = false
      this.getAllModleList()
    },
    /**
     * 禁用
     * **/
    pause: function(index, row) {
      let status = row.status
      if (status == '1') {
        status = '2'
      } else {
        status = '1'
      }
      let params = {
        modleId: row.modleId,
        status: status,
      }
      this.axios
        .post(
          manalScore + '/manualQualityAssurance/updateModleStatus.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '操作成功!',
            })
            this.getAllModleList()
          } else {
            this.$message({
              type: 'error',
              message: '操作失败!',
            })
            this.getAllModleList()
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    updateIsRealTime: function(index, row) {
      let isRealTime = row.isRealTime
      if (isRealTime == '1') {
        //1、启用实时；2、停用实时
        isRealTime = '2'
      } else {
        isRealTime = '1'
      }
      let params = {
        modleId: row.modleId,
        isRealTime: isRealTime,
      }
      this.axios
        .post(
          manalScore + '/manualQualityAssurance/updateModleStatus.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '操作成功!',
            })
            this.getAllModleList()
          } else {
            this.$message({
              type: 'error',
              message: '操作失败!',
            })
            this.getAllModleList()
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     * select
     * **/
    select: function(selection, row) {
      if (selection.length > 0) {
        this.batchList = selection
        this.isBatch == true
      }
      this.isBatch == false
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },

    /**
     * 编辑
     * **/
    handleEdit: function(index, row) {
      this.modelTitle = '修改模板'
      this.editTemplateModal = true
      this.editTemForm.modleTitle = row.modleTitle
      this.editTemForm.qualityScore = row.qualityScore
      let stitle
      if (row.status == 1) {
        stitle = '启用'
      } else {
        stitle = '停用'
      }
      this.editTemForm.status = stitle
      this.editTemForm.remark = row.remark
      this.oldname = row.modleTitle
    },
    /**
     * 查看
     * **/
    handleLook: function(index, row) {
      this.editTemplateModal = true
      this.modelTitle = '查看模板'
      this.editTemForm.modleTitle = row.modleTitle
      this.editTemForm.qualityScore = row.qualityScore
      let stitle
      if (row.status == 1) {
        stitle = '启用'
      } else {
        stitle = '停用'
      }
      this.editTemForm.status = stitle
      this.editTemForm.remark = row.remark
    },

    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.getAllModleList()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.getAllModleList()
    },
    /**
     * 质检模板列表
     * **/
    getAllModleList: function() {
      let params = {
        modleTitle: this.searchForm.modleTitle,
        status: this.searchForm.status,
        pagesize: this.pagesize,
        pageindex: this.pageindex,
        modleType: 7,
      }
      this.axios
        .post(
          manalScore + '/manualQualityAssurance/getAllModleList.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.tableData = res.data.Data
          this.totalCount = res.data.Count
          this.filterButton() // 过滤权限按钮
        })
        .catch(function(error) {
          console.log(error)
        })
    },

      /*
  * 过滤权限按钮
  * */
    filterButton() {
        /*
       获取数据后dom节点更改了，
        需要再获取一遍dom节点对[funcID]按钮进行过滤
       * */
        let menuId = localStorage.getItem('menuId')
        let path = this.$route.path.replace('/', '')
        funcFilter(menuId, path)
    }
  },
}
</script>
<style scoped="scoped">
#qualityCTemplate {
  width: 100%;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  overflow: hidden;
}
#qualityCTemplate .containTitle {
  padding: 16px 26px 13px 19px;
  font-size: 14px;
  color: #1f2d3d;
}
#qualityCTemplate .quality-header {
  padding: 0 26px 0 19px;
  display: flex;
  flex-direction: row;
  align-items: center;
}
#qualityCTemplate .quality-header .fr {
  height: 36px;
  border-radius: 4px;
  width: 88px;
  padding: 0;
  color: #475669;
}
#qualityCTemplate .quality-header .fr_primary {
  height: 36px;
  border-radius: 4px;
  width: 88px;
  padding: 0;
  color: #ffffff;
  font-size: 14px;
  background-color: #20a0ff;
}
#qualityCTemplate .quality-header .demo-form-inline {
  flex: 1;
  text-align: right;
}
#qualityCTemplate .quality-content {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 20px 26px 110px 19px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}
#qualityCTemplate .quality-content .quality-content-table {
  width: 100%;
  height: 100%;
}
#qualityCTemplate .quality-page {
  height: 40px;
  display: flex;
  flex-direction: row-reverse;
  margin-top: 10px;
}
#qualityCTemplate .ml {
  margin-left: 10px;
}
#qualityCTemplate .quality-content i {
  cursor: pointer;
}
#qualityCTemplate .w200 {
  width: 440px;
}
</style>
<style lang="less">
#qualityCTemplate {
  .el-dialog--tiny {
    width: 400px;
    /* width: 30%; */
  }
  .quality-header {
    .el-form-item {
      .el-form-item__content {
        line-height: 36px;
        .el-input__inner {
          height: 36px;
          line-height: 36px;
        }
      }
      &:last-child {
        margin-right: 0;
      }
    }
  }
  .el-table.fh-table {
    height: 100%!important;
  }
  .quality-content-table th {
    background-color: #e5e9f2;
    color: #475669;
    padding: 10px 0;
    border-color: #e0e6ed;
    font-size: 13px;
    .cell {
      line-height: 22px;
      margin-top: 0;
      margin-bottom: 0;
    }
  }
}
</style>
