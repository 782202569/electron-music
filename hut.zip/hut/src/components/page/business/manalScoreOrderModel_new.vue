<template>
  <div style="width: 100%; height: 100%;">
    <div id="qualityCTemplate" v-show="templateShow">
      <div class="quality-header">
        <el-form
          ref="searchForm"
          :model="searchForm"
          :inline="true"
          style="float: right;margin-top: 10px"
          class="demo-form-inline"
        >
          <el-form-item prop="status">
            <el-select placeholder="请选择状态" clearable v-model="searchForm.status">
              <el-option label="启用" value="1">启用</el-option>
              <el-option label="停用" value="2">停用</el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="modleTitle">
            <el-input placeholder="请输入名称" v-model="searchForm.modleTitle"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button @click="searchByName" type="primary">查询</el-button>
          </el-form-item>
          <el-form-item>
            <!--<el-button class="fr" @click="editTemplateInfo" style="margin-left: 10px">编辑标准</el-button>-->
            <el-button class="fr" @click="addTemplate">新建模板</el-button>
          </el-form-item>
        </el-form>
        <el-dialog
          :close-on-click-modal="false"
          title="新增模板"
          :visible.sync="addTemplateModal"
        >
          <el-form
            :label-position="labelPosition"
            :model="addTemForm"
            label-width="100px"
            ref="addTemForm"
            :rules="formRules"
          >
            <el-form-item label="模板名称" prop="modleTitle">
              <el-input v-model="addTemForm.modleTitle" class="w200"></el-input>
            </el-form-item>
            <!-- <el-form-item label="合格分数" prop="qualityScore">
              <el-input v-model="addTemForm.qualityScore" class="w200"></el-input>
            </el-form-item>-->
            <el-form-item label="关联模板" prop="relateModel">
              <el-select
                clearable
                v-model="addTemForm.relateModel"
                placeholder="请选择"
                style="width: 240px;"
              >
                <el-option
                  v-for="item in call_template"
                  :key="item.modleId"
                  :label="item.modleTitle"
                  :value="item.modleId"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="状态" prop="status">
              <el-select
                clearable
                v-model="addTemForm.status"
                placeholder="请选择"
                style="width: 240px;"
              >
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="备注" prop="remark">
              <el-input
                type="textarea"
                class="w200"
                v-model="addTemForm.remark"
                :rows="4"
              >
              </el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="addTemplateYesThrottle">确定</el-button>
              <el-button @click="closeAddTemplateModal">取消</el-button>
            </el-form-item>
          </el-form>
        </el-dialog>
        <el-dialog
          :close-on-click-modal="false"
          :title="modelTitle"
          :visible.sync="editTemplateModal"
        >
          <el-form
            :label-position="labelPosition"
            :model="editTemForm"
            label-width="100px"
            ref="editTemForm"
            :rules="editFormRules"
          >
            <el-form-item label="模板名称" prop="modleTitle">
              <el-input v-model="editTemForm.modleTitle" class="w200"></el-input>
            </el-form-item>
            <el-form-item label="关联模板" prop="relateModel">
              <el-input v-model="editTemForm.relateModel" class="w200"></el-input>
            </el-form-item>
            <!-- <el-form-item label="合格分数" prop="qualityScore">
              <el-input v-model="editTemForm.qualityScore" class="w200"></el-input>
            </el-form-item>-->
            <el-form-item label="状态" prop="status">
              <el-select
                clearable
                v-model="editTemForm.status"
                placeholder="请选择"
                style="width: 240px;"
              >
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="备注" prop="remark">
              <el-input
                type="textarea"
                class="w200"
                v-model="editTemForm.remark"
                :rows="4"
              >
              </el-input>
            </el-form-item>
            <el-form-item>
              <div v-if="this.modelTitle == '修改模板'">
                <el-button type="primary" @click="editTemplateYesThrottle"
                  >确定</el-button
                >
                <el-button @click="closeEditTemplateModal">取消</el-button>
              </div>
              <div v-else>
                <el-button @click="closeModel">关闭</el-button>
              </div>
            </el-form-item>
          </el-form>
        </el-dialog>
      </div>
      <div class="quality-content">
        <div class="quality-content-table" style="overflow: auto;">
          <el-table
            rel="qualityTable"
            border
            highlight-current-row
            :data="tableData"
            style="width: 100%"
          >
            <el-table-column type="index" label="序号" width="70"> </el-table-column>
            <el-table-column prop="modleTitle" sortable label="模板名称">
            </el-table-column>
            <el-table-column prop="createUser" sortable label="创建人"> </el-table-column>
            <el-table-column
              prop="createTime"
              sortable
              label="创建时间"
              :formatter="dateFormat"
            >
            </el-table-column>
            <el-table-column prop="status" label="状态" width="80">
              <template scope="scope">
                <div v-if="scope.row.status === 1">
                  <el-tag type="success">启用</el-tag>
                </div>
                <div v-else="">
                  <el-tag type="gray">停用</el-tag>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="300">
              <template scope="scope">
                <i class="iconfont icon-brush" @click="editTemplateInfo(scope.row)">
                  <i style="padding-left: 3px; font-size: 14px">编辑标准</i></i
                >
                <!-- <i class="iconfont icon-brush" @click="handleEdit(scope.$index, scope.row)">
                  <i style="padding-left: 3px; font-size: 14px">编辑</i></i>-->
                <i
                  style="margin-left: 10px"
                  class="iconfont icon-pause"
                  v-if="scope.row.status === 1"
                  @click="pause(scope.$index, scope.row)"
                  ><i style="font-size: 14px">停用</i></i
                >
                <i
                  style="margin-left: 10px"
                  class="el-icon-caret-right"
                  v-else=""
                  @click="pause(scope.$index, scope.row)"
                  ><i style="font-size: 14px">启用</i></i
                >
                <i
                  class="iconfont icon-document ml"
                  @click="handleLook(scope.$index, scope.row)"
                >
                  <i style="font-size: 14px">查看</i></i
                >
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="quality-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="pageindex"
            :page-sizes="[20, 30, 40]"
            :page-size="pagesize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalCount"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <nTemplate
      v-show="!templateShow"
      :info="countList"
      :mdtitle="textTitle"
      :modleIdNew="modleId"
      v-on:send="changeshow"
    ></nTemplate>
  </div>
</template>
<script>
import nTemplate from './newOrderTemplate.vue'
import axios from 'axios'
import Qs from 'qs'
axios.defaults.withCredentials = true
axios.defaults.headers = {
  'Content-Type': 'application/x-www-form-urlencoded ;charset=UTF-8',
}
import global from '../../../global.js'
let manalScore = global.qualityUrl
import formatdate from '../../../utils/formatdate.js'
export default {
  components: {
    nTemplate,
  },
  mounted() {
    this.getAllModleList()
  },
  data() {
    const validModelTitle = (rule, value, callback) => {
      if (value.trim().length > 30) {
        callback(new Error('不能超过30个字符'))
      } else {
        callback()
      }
    }
    return {
      templateShow: true,
      updateTable: false,
      // isStatus: '',
      isStatusTwo: '',
      treedata: [],
      treedataManual: [],
      treeDataList: [],
      treedataManualList: [],
      textTitle: '',
      mdtitle: '',
      info: {},
      modelTitle: '修改模板',
      oldname: '',
      editFormRules: {
        modleTitle: [
          { required: true, message: '请输入模板名称！', trigger: 'blur' },
          { validator: validModelTitle, trigger: 'blur' },
        ],
        /* qualityScore:[{validator: validQualityScore, trigger: 'blur' }] */
      },
      editTemplateModal: false,
      formRules: {
        modleTitle: [
          { required: true, message: '请输入模板名称!', trigger: 'blur' },
          { validator: validModelTitle, trigger: 'blur' },
        ],
        relateModel: [{ required: true, message: '请选择关联模板!', trigger: 'blur' }],

        /* qualityScore:[{validator: validQualityScore, trigger: 'blur' }] */
      },
      labelPosition: 'right',
      options: [
        {
          value: '1',
          label: '启用',
        },
        {
          value: '2',
          label: '停用',
        },
      ],
      call_template: [],
      editTemForm: {
        modleTitle: '',
        status: '',
        relateModel: '',
        // qualityScore:'',
        remark: '',
      },
      addTemForm: {
        modleTitle: '',
        status: '启用',
        // qualityScore:'',
        relateModel: '请选择模板',
        remark: '',
      },
      operation: '',
      modleId: '',
      searchForm: {
        status: '',
        modleTitle: '',
      },
      value3: true,
      value2: false,
      tableData: [],
      totalCount: 0,
      pageindex: 1,
      pagesize: 20,
      current: 1,
      mid: 0,
      isBatch: false,
      batchList: [],
      addTemplateModal: false,
      mmid: '',
      treedatass: [],
      treedataListss: [],
      isStatus: '0',
      countList: {},
      modleIdNew: '',
      nextModel: false,
      modleIdTwoList: '',
      modleTitleN: '',
    }
  },
  methods: {
    changeshow(input) {
      // 改变当前页面的显示情况（templateShow改变这个值）
      this.templateShow = input
      this.updateTable = false
      this.getAllModleList()
    },
    // 点击修改模板
    editTemplateInfo: function(row) {
      if (row.status != '1') {
        this.$message({
          type: 'warning',
          message: '该模板已经停用',
        })
      } else {
        this.modleId = row.modleId
        this.mmid = row.modleId
        this.modleIdNew = row.modleId
        this.info = row

        this.textTitle = row.modleTitle
        this.countList = row

        this.templateShow = false
      }
    },
    editTemplateYesThrottle() {
      this.lodashThrottle.throttle(this.editTemplateYes, this)
    },
    // 确定修改模板
    editTemplateYes: function() {
      if (this.oldname == this.editTemForm.modleTitle) {
        this.editTemplateModal = false
      } else {
        let status = this.addTemForm.status
        let ssTitle
        if (status == '启用') {
          ssTitle = '1'
        } else {
          ssTitle = '2'
        }
        let params = {
          modleTitle: this.editTemForm.modleTitle,
          qualityScore: this.editTemForm.qualityScore,
          status: ssTitle,
          remark: this.editTemForm.remark,
          modleType: 7,
          modleId: this.modleIdNew,
          linkModleId: '973e5ad4fe5511e6b042000c29a7c029',
          departId: '973e5ad4fe5511e6b042000c29a7c029',
        }
        this.$refs.editTemForm.validate((valid) => {
          if (valid) {
            this.axios
              .post(
                manalScore + '/manualOrderQualityAssurance/saveModle.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data.flag == true) {
                  this.$message({
                    type: 'success',
                    message: '数据提交成功!',
                  })
                } else {
                  if (res.data.flag == false) {
                    this.$message({
                      type: 'error',
                      message: res.data.msg,
                    })
                  } else {
                    this.$message({
                      type: 'error',
                      message: '数据提交失败!',
                    })
                  }
                }
                this.editTemplateModal = false
                this.$refs['editTemForm'].resetFields()
                this.getAllModleList()
              })
              .catch(function(error) {
                console.log(error)
              })
          }
        })
      }
    },
    closeEditTemplateModal: function() {
      this.editTemplateModal = false
    },
    closeModel: function() {
      this.editTemplateModal = false
    },
    /**
     * 点击取消
     * **/
    closeAddTemplateModal: function() {
      this.addTemplateModal = false
      this.$refs['addTemForm'].resetFields()
      this.updateTable == false
    },
    addTemplateYesThrottle() {
      this.lodashThrottle.throttle(this.addTemplateYes, this)
    },
    /**
     * 新建模板确定
     * **/
    addTemplateYes: function() {
      if (this.addTemForm.relateModel === '请选择模板') {
        this.$message({
          type: 'error',
          message: '请选择关联模板！',
        })
        return
      }
      let status = this.addTemForm.status
      let ssTitle
      if (status == '启用') {
        ssTitle = '1'
      } else {
        ssTitle = '2'
      }
      let params = {
        modleTitle: this.addTemForm.modleTitle,
        qualityScore: this.addTemForm.qualityScore,
        status: ssTitle,
        remark: this.addTemForm.remark,
        modleType: 7,
        modleId: '',
        linkModleId: this.addTemForm.relateModel,
        departId: '',
      }
      let checkParams = {
        modleTitle: this.addTemForm.modleTitle,
        modleType: 7,
      }
      this.$refs.addTemForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(
              manalScore + '/manualOrderQualityAssurance/checkModleByType.do',
              Qs.stringify(checkParams)
            )
            .then((res) => {
              if (res.data) {
                this.$message({
                  type: 'error',
                  message: '这个模板已经存在，请重新输入模板名称！',
                })
              } else {
                this.axios
                  .post(
                    manalScore + '/manualOrderQualityAssurance/saveModle.do',
                    Qs.stringify(params)
                  )
                  .then((res) => {
                    if (res.data.flag == true) {
                      this.$message({
                        type: 'success',
                        message: '新建模板成功!',
                      })
                      // this.modleIdNew="";
                      this.templateShow = false
                    } else {
                      this.$message({
                        type: 'error',
                        message: '数据提交失败!',
                      })
                    }
                    this.getAllModleList()
                    this.addTemplateModal = false
                    this.$refs['addTemForm'].resetFields()
                  })
                  .catch(function(error) {
                    console.log(error)
                  })
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        } else {
        }
      })
    },
    /**
     * 点击新建模板
     * **/
    addTemplate: function() {
      this.addTemplateModal = true
      this.treeDataList = []
      this.treedataManualList = []
      this.axios
        .post(manalScore + '/manualQualityAssurance/getAllModleList.do', null)
        .then((res) => {
          this.call_template = res.data.Data
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     * 根据模板名称/状态查询
     * **/
    searchByName: function() {
      this.updateTable = false
      this.getAllModleList()
    },
    /**
     * 禁用
     * **/
    pause: function(index, row) {
      let status = row.status
      if (status == '1') {
        status = '2'
      } else {
        status = '1'
      }
      let params = {
        modleId: row.modleId,
        status: status,
      }
      this.axios
        .post(
          manalScore + '/manualOrderQualityAssurance/updateModleStatus.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '操作成功!',
            })
            this.getAllModleList()
          } else {
            this.$message({
              type: 'error',
              message: '操作失败!',
            })
            this.getAllModleList()
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     * select
     * **/
    select: function(selection, row) {
      if (selection.length > 0) {
        this.batchList = selection
        this.isBatch == true
      }
      this.isBatch == false
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },

    /**
     * 编辑
     * **/
    handleEdit: function(index, row) {
      this.modelTitle = '修改模板'
      this.editTemplateModal = true
      this.editTemForm.modleTitle = row.modleTitle
      this.editTemForm.qualityScore = row.qualityScore
      let stitle
      if (row.status == 1) {
        stitle = '启用'
      } else {
        stitle = '停用'
      }
      this.editTemForm.status = stitle
      this.editTemForm.remark = row.remark
      this.oldname = row.modleTitle
    },
    /**
     * 查看
     * **/
    handleLook: function(index, row) {
      this.editTemplateModal = true
      this.modelTitle = '查看模板'
      this.editTemForm.modleTitle = row.modleTitle
      this.editTemForm.qualityScore = row.qualityScore
      this.editTemForm.relateModel = row.linkModleId
      let stitle
      if (row.status == 1) {
        stitle = '启用'
      } else {
        stitle = '停用'
      }
      this.editTemForm.status = stitle
      this.editTemForm.remark = row.remark
    },

    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.getAllModleList()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.getAllModleList()
    },
    /**
     * 质检模板列表
     * **/
    getAllModleList: function() {
      let params = {
        modleTitle: this.searchForm.modleTitle,
        status: this.searchForm.status,
        pagesize: this.pagesize,
        pageindex: this.pageindex,
        modleType: 7,
      }
      this.axios
        .post(
          manalScore + '/manualOrderQualityAssurance/getAllModleList.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.tableData = res.data.Data
          this.totalCount = res.data.Count
          // this.modleTitleN=res.data.Data[0].modleTitle;
          // this.modleIdTwoList=res.data.Data[0].modleId;
          this.modleId = res.data.Data[0].modleId
          this.textTitle = res.data.Data[0].modleTitle
        })
        .catch(function(error) {
          console.log(error)
        })
    },
  },
}
</script>
<style scoped="scoped">
#qualityCTemplate {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
}
#qualityCTemplate .quality-header {
  float: left;
  box-sizing: border-box;
  top: 0px;
  width: 100%;
  height: 58px;
  border-bottom: 1px dashed #d1dbe7;
}
#qualityCTemplate .quality-header .fr {
  float: right;
}
#qualityCTemplate .quality-content {
  padding-top: 68px;
  padding-bottom: 80px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}
#qualityCTemplate .quality-content .quality-content-table {
  width: 100%;
  height: 100%;
}
#qualityCTemplate .quality-page {
  right: 10px;
  position: absolute;
  bottom: 10px;
}
#qualityCTemplate .ml {
  margin-left: 10px;
}
#qualityCTemplate .quality-content i {
  cursor: pointer;
}
#qualityCTemplate .w200 {
  width: 240px;
}
</style>
<style>
#qualityCTemplate .el-dialog--tiny {
  width: 400px;
  /* width: 30%; */
}
</style>
