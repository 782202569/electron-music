<template>
  <div class="newTemplate" id="qNewTemplate">
    <div class="autoGrading">
      <div class="templateHeader">
        <el-button type="text" @click="goBack">
          <span>&lt; 返回</span>
        </el-button>
        <div style="flex:1;text-align: center;">
          <span>{{ namesForm.modleTitle }}</span>
          <i
            class="iconfont icon-bianji"
            @click="handleIconClick"
            style="cursor: pointer;"
          ></i>
        </div>

        <div class="tmpClass3">
          <span class="tmpClass1">基准分:</span>
          <el-input
            class="tmpClass2"
            v-model.number="baseScore"
            @blur="setBaseScore"
            oninput="value=value.replace(/[^-\d]/g,'')"
            maxLength="3"
          ></el-input>
        </div>
        <div class="total_score">
          <!--<span>总分1：{{this.totalScores}}</span>-->
          <el-button class="viewBtn" @click="preview">预览</el-button>
          <el-button funcId="000395" class="viewBtn" @click="addTree">新建分类</el-button>
        </div>
      </div>
      <el-dialog
        :close-on-click-modal="false"
        title="修改名称"
        :visible.sync="handleIconModel"
      >
        <el-form
          ref="editNamesForm"
          :rules="namesRules"
          :model="editNamesForm"
          label-width="100px"
        >
          <el-form-item label="模板名称" prop="modleTitle">
            <el-input class="w200" v-model="editNamesForm.modleTitle"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="editNamesYesThrottle">确定</el-button>
            <el-button @click="handleIconModel = false">取消</el-button>
          </el-form-item>
        </el-form>
      </el-dialog>
      <el-dialog
        :close-on-click-modal="false"
        title="预览模板"
        :visible.sync="previewModel"
      >
        <div class="preview">
          <div>
            <span>模版名称:{{ this.perviewModel.modleTitle }}</span>
            <span style="float:right">基准分:{{ this.perviewModel.baseScore }}</span>
          </div>
          <div v-for="(tableRow, key) in tableData" :key="key">
            <div style="color: #000;font-weight: bold" class="normalNameClass">
              {{ key }}
            </div>
            <el-table :data="tableRow" style="width: 100%; height:350px; overflow:auto">
              <el-table-column prop="judge" label="标准名称" width="200">
                <template scope="scope">
                  <div>{{ scope.row.normalName }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="judge"
                :formatter="formatJudge"
                width="200"
                label="打分方式"
              >
              </el-table-column>
              <el-table-column label="规则">
                <template scope="scope">
                  <div v-if="scope.row.judge === 11">
                    <div v-for="keyValue in scope.row.resultsObject" :key="keyValue.id">
                      {{ keyValue.labelName }}
                      <span v-if="keyValue.score !== 0"
                        >{{ keyValue.increaseDeduction == '2' ? '减' : '加'
                        }}{{ keyValue.score }}分</span
                      >
                      <el-popover placement="right" width="120" trigger="hover">
                        <template v-if="keyValue.deadItem == '1'" slot="reference">
                          <i class="el-icon-warning" style="color: red"></i>
                        </template>
                        <p>{{ mingzhongTip }}</p>
                      </el-popover>
                    </div>
                  </div>
                  <div v-if="scope.row.judge === 12">
                    <div v-for="rules in scope.row.resultsObject" :key="rules.id">
                      {{ rules.labelName }}
                      <p>
                        {{ rules.firstRoleType == 1 ? '客服' : '客户' }}:{{
                          rules.firstContext
                        }}
                      </p>
                      <p>
                        {{ rules.secondRoleType == 1 ? '客服' : '客户' }}:{{
                          rules.secondContext
                        }}
                      </p>
                      <p>
                        规则：{{ rules.sentenceCount }}句内,
                        {{ rules.isAppear == 1 ? '出现' : '不出现' }}
                        <span v-if="rules.score !== 0"
                          >{{ rules.increaseDeduction == '2' ? '减' : '加'
                          }}{{ rules.score }}分</span
                        >
                      </p>
                      <el-popover placement="right" width="120" trigger="hover">
                        <template v-if="rules.sentenceDeadItem == '1'" slot="reference">
                          <i class="el-icon-warning" style="color: red"></i>
                        </template>
                        <p>{{ mingzhongTip }}</p>
                      </el-popover>
                    </div>
                  </div>
                  <div v-if="scope.row.judge === 13">
                    <p>意图:{{ scope.row.faqContent }}</p>
                    <div v-for="rules in scope.row.resultsObject" :key="rules.id">
                      <p>
                        话术:{{ rules.content }}。 规则：{{ scope.row.scoringRules }}句内,
                        {{ rules.isAppear == 1 ? '出现' : '不出现'
                        }}{{ rules.addsub == '2' ? '减' : '加' }}{{ rules.score }}分
                      </p>
                    </div>
                  </div>
                  <div v-if="scope.row.judge === 5">
                    <div v-if="scope.row.resultsObject != null">
                      <div :key="key" v-for="(rules, key) in scope.row.resultsObject">
                        <span>{{
                          rules.keywordContext + getKeywordScore(rules, scope.row.judge)
                        }}</span>
                        <el-popover placement="right" width="120" trigger="hover">
                          <template v-if="rules.deadItem == '1'" slot="reference">
                            <i class="el-icon-warning" style="color: red"></i>
                          </template>
                          <p>{{ mingzhongTip }}</p>
                        </el-popover>
                      </div>
                    </div>
                  </div>
                  <div v-else-if="scope.row.judge === 4">
                    <div v-for="(srrt, key) in scope.row.resultsObject" :key="key">
                      <p>
                        {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒
                        <span
                          >{{ srrt.increaseDeduction == '2' ? '减' : '加'
                          }}{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                  </div>
                  <div v-else-if="scope.row.judge === 1">
                    <div v-for="(srrt, key) in scope.row.resultsObject" :key="key">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次
                        <span
                          >{{ srrt.increaseDeduction == '2' ? '减' : '加'
                          }}{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                  </div>
                  <div v-else-if="scope.row.judge === 2">
                    <div v-for="(srrt, key) in scope.row.resultsObject" :key="key">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次
                        <span
                          >{{ srrt.increaseDeduction == '2' ? '减' : '加'
                          }}{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="lists" v-else-if="scope.row.judge === 6">
                    <!-- <el-input :disabled="true" class="titleInput" v-model="obj.defaultScore"></el-input> -->
                    <span style="margin-left:20px;"
                      >分值范围{{ scope.row.resultsObject.minScoreRange }}-{{
                        scope.row.resultsObject.maxScoreRange
                      }}分</span
                    >
                    <span style="margin-left:20px;"
                      >默认分数{{ scope.row.resultsObject.defaultScore }}分</span
                    >
                  </div>
                  <div class="judgeLists" v-else-if="scope.row.judge === 7">
                    <div class="services">
                      <el-checkbox-group
                        v-model="checkboxGroup1"
                        style="margin-left: 14px;"
                      >
                        <el-checkbox-button
                          v-for="title in scope.row.resultsObject"
                          :label="title"
                          :key="title"
                          >{{ title }}</el-checkbox-button
                        >
                      </el-checkbox-group>
                    </div>
                  </div>
                  <div v-else-if="scope.row.judge === 8">
                    <el-popover placement="right" width="120" trigger="hover">
                      <template slot="reference">
                        <el-radio-group
                          v-model="checkboxGroup1"
                          size="medium"
                          fill="#97a8be"
                        >
                          <el-radio-button :label="'1'">致命</el-radio-button>
                          <el-radio-button :label="'2'">非致命</el-radio-button>
                        </el-radio-group>
                      </template>
                      <p>{{ scope.row.normalContent || '无' }}</p>
                    </el-popover>
                    <el-popover trigger="hover" placement="right">
                      <template slot="reference">
                        <i class="el-icon-warning" style="color: red"></i>
                      </template>
                      <p>{{ mingzhongTip }}</p>
                    </el-popover>
                  </div>
                  <div v-else-if="scope.row.judge === 3">
                    <div v-for="(srrt, key) in scope.row.resultsObject" :key="key">
                      <div v-if="srrt.silenceType === 1">
                        <p>
                          {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒
                          <span
                            >{{ srrt.increaseDeduction == '2' ? '减' : '加'
                            }}{{ srrt.score }}分</span
                          >
                        </p>
                      </div>
                      <div v-else-if="srrt.silenceType === 2">
                        <p>
                          {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次
                          <span
                            >{{ srrt.increaseDeduction == '2' ? '减' : '加'
                            }}{{ srrt.score }}分</span
                          >
                        </p>
                      </div>
                      <div v-else-if="srrt.silenceType === 3">
                        <p>
                          {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%
                          <span
                            >{{ srrt.increaseDeduction == '2' ? '减' : '加'
                            }}{{ srrt.score }}分</span
                          >
                        </p>
                      </div>
                      <div v-else-if="srrt.silenceType === 4">
                        <p>
                          {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒
                          <span
                            >{{ srrt.increaseDeduction == '2' ? '减' : '加'
                            }}{{ srrt.score }}分</span
                          >
                        </p>
                      </div>
                      <div v-else-if="srrt.silenceType === 5">
                        {{ srrt.keywordContext + getKeywordScore(srrt, scope.row.judge) }}
                      </div>
                      <div v-else></div>
                    </div>
                  </div>
                  <div v-else></div>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div style="clear: both"></div>
        </div>
      </el-dialog>
      <el-dialog
        :close-on-click-modal="false"
        @close="cancel"
        title="新建分类"
        :visible.sync="dialogTreeFormVisible"
        width="640px"
      >
        <el-form :model="addTreeForm" ref="addTreeForm" :rules="treeFormRules">
          <el-form-item label="分类名称" prop="classTitle" :label-width="formLabelWidth">
            <el-input style="width:420px" v-model="addTreeForm.classTitle"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="cancel">取 消</el-button>
          <el-button type="primary" @click="saveClassThrottle">确 定</el-button>
        </div>
      </el-dialog>
      <el-dialog
        class="templateAutonormal"
        :close-on-click-modal="false"
        @close="addTableCanel"
        :title="myTitle"
        :visible.sync="dialogFormVisible"
      >
        <el-form
          :rules="tableFormRules"
          :label-position="labelPosition"
          label-width="120px"
          :model="addForm"
          ref="addForm"
          style="height: 400px; overflow: auto"
        >
          <el-form-item label="标准名称" prop="normalName" style="display: inline-block">
            <el-input v-model="addForm.normalName" :disabled="showDisabled"></el-input>
          </el-form-item>
          <el-form-item label="打分方式" prop="judge" style="display: inline-block">
            <el-select
              v-model="addForm.judge"
              :disabled="showDisabled"
              placeholder="请选择"
              @change="optionChange"
            >
              <el-option
                v-for="item in options2"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
          <div id="qingxu" v-show="judgeAuto === 1" style="cursor: pointer">
            <el-row>
              <el-col :span="24">
                <el-form-item
                  v-for="(domain, index) in addForm.domainsParamsQing.domains"
                  :key="domain.key"
                >
                  <el-input
                    oninput="value=value.replace(/[^-\d]/g,'')"
                    :disabled="showDisabled"
                    :maxlength="3"
                    placeholder="分"
                    v-model="domain.silenceTimeMin"
                    class="w120"
                  ></el-input>
                  <label>分</label>
                  <label class="ml">-</label>
                  <el-input
                    oninput="value=value.replace(/[^-\d]/g,'')"
                    :disabled="showDisabled"
                    :maxlength="3"
                    placeholder="分"
                    class="w120"
                    v-model="domain.silenceTimeMax"
                  ></el-input>
                  <label>分</label>
                  <el-select
                    :disabled="showDisabled"
                    style="width:100px;margin-right: 10px;"
                    v-model="domain.increaseDeduction"
                  >
                    <el-option key="1" label="加" value="1"></el-option>
                    <el-option key="2" label="减" value="2"></el-option>
                  </el-select>
                  <el-input
                    oninput="value=value.replace(/[^-\d]/g,'')"
                    :disabled="showDisabled"
                    placeholder=""
                    :maxlength="3"
                    v-model="domain.score"
                    class="w120"
                  ></el-input>
                  <label>分</label>
                  <div
                    class="el-form-item__error"
                    id="inputErrorShow"
                    style="display: none"
                  >
                    请输入整数
                  </div>
                  <a v-if="myTitle != '查看标准'">
                    <div class="plus-minus-button d-ib m-l-10">
                      <el-button class="icon" @click="addDomainQing">
                        <i class="el-icon-plus"></i>
                      </el-button>
                      <el-button
                        class="icon"
                        @click.prevent="removeDomainQing(index)"
                        v-show="index > 0"
                      >
                        <i class="el-icon-minus"></i>
                      </el-button>
                    </div>
                  </a>
                  <a v-else></a>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
          <div
            id="chongfu"
            v-show="judgeAuto === 2"
            style="display: none; cursor: pointer"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="角色" prop="chongDieRole">
                  <el-select v-model="chongDieRole" placeholder="请选择角色">
                    <el-option
                      v-for="item in roleOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item
                  v-for="(domain, index) in addForm.chongDomains.domains"
                  :key="index"
                >
                  <div class="demo-input-size">
                    <el-input
                      oninput="value=value.replace(/[^-\d]/g,'')"
                      :disabled="showDisabled"
                      :maxlength="3"
                      placeholder="次"
                      v-model="domain.silenceTimeMin"
                      class="w120"
                    ></el-input>
                    <label>次</label>
                    <label class="ml">-</label>
                    <el-input
                      oninput="value=value.replace(/[^-\d]/g,'')"
                      :disabled="showDisabled"
                      :maxlength="3"
                      placeholder="次"
                      class="w120"
                      v-model="domain.silenceTimeMax"
                    ></el-input>
                    <label>次</label>
                    <el-select
                      :disabled="showDisabled"
                      style="width:100px;margin-right: 10px;"
                      v-model="domain.increaseDeduction"
                    >
                      <el-option key="1" label="加" value="1"></el-option>
                      <el-option key="2" label="减" value="2"></el-option>
                    </el-select>
                    <el-input
                      oninput="value=value.replace(/[^-\d]/g,'')"
                      :disabled="showDisabled"
                      :maxlength="3"
                      class="w120"
                      v-model="domain.score"
                    ></el-input>
                    <label class="ml">分</label>
                    <a v-if="myTitle != '查看标准'">
                      <div class="plus-minus-button d-ib m-l-10">
                        <el-button class="icon" @click="addChongDomain">
                          <i class="el-icon-plus"></i>
                        </el-button>
                        <el-button
                          class="icon"
                          @click.prevent="removeChongDomain(index)"
                          v-show="index > 0"
                        >
                          <i class="el-icon-minus"></i>
                        </el-button>
                      </div>
                    </a>
                    <a v-else></a>
                  </div>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
          <div id="jingmo" v-show="judgeAuto === 3">
            <el-row>
              <el-col :span="24">
                <el-form-item label="静默类型">
                  <el-select
                    v-model="addForm.silenceType"
                    :disabled="showDisabled"
                    @change="changeRadio"
                    placeholder="请选择"
                  >
                    <el-option label="时长" :value="1"></el-option>
                    <el-option label="次数" :value="2"></el-option>
                    <el-option label="占比" :value="3"></el-option>
                    <el-option label="单次最大静默时长" :value="4"></el-option>
                    <el-option label="静默关键词" :value="5"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row v-if="addForm.silenceType != 5">
              <el-col :span="24">
                <el-form-item label="静默开始角色" prop="jMRoleBefore">
                  <el-select v-model="jMRoleBefore" placeholder="请选择角色">
                    <el-option
                      v-for="item in roleOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="静默结束角色" prop="jMRoleAfter">
                  <el-select v-model="jMRoleAfter" placeholder="请选择角色">
                    <el-option
                      v-for="item in roleOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <div id="nums" v-if="addForm.silenceType != 5">
              <el-row>
                <el-col :span="24">
                  <el-form-item
                    v-for="(domain, index) in addForm.jingDomains.domains"
                    :key="index"
                    prop="domains"
                  >
                    <div class="demo-input-size">
                      <el-input
                        oninput="value=value.replace(/[^-\d]/g,'')"
                        :disabled="showDisabled"
                        :maxlength="3"
                        class="w120"
                        v-model="domain.silenceTimeMin"
                      ></el-input>
                      <label>{{ numsTitle }}</label>
                      <label class="ml">-</label>
                      <el-input
                        oninput="value=value.replace(/[^-\d]/g,'')"
                        :disabled="showDisabled"
                        :maxlength="3"
                        class="w120"
                        v-model="domain.silenceTimeMax"
                      ></el-input>
                      <label>{{ numsTitle }}</label>
                      <el-select
                        :disabled="showDisabled"
                        style="width:100px;margin-right: 10px;"
                        v-model="domain.increaseDeduction"
                      >
                        <el-option key="1" label="加" value="1"></el-option>
                        <el-option key="2" label="减" value="2"></el-option>
                      </el-select>
                      <el-input
                        oninput="value=value.replace(/[^-\d]/g,'')"
                        :disabled="showDisabled"
                        :maxlength="3"
                        class="w120"
                        v-model="domain.score"
                      ></el-input>
                      <label class="ml">分</label>
                      <a v-if="myTitle != '查看标准'">
                        <div class="plus-minus-button d-ib m-l-10">
                          <el-button class="icon" @click="addJingDomain">
                            <i class="el-icon-plus"></i>
                          </el-button>
                          <el-button
                            class="icon"
                            @click.prevent="removeJingDomain(index)"
                            v-show="index > 0"
                          >
                            <i class="el-icon-minus"></i>
                          </el-button>
                        </div>
                      </a>
                      <a v-else></a>
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>
            </div>
          </div>
          <div id="yusu" v-show="judgeAuto === 4" style="display: none; cursor: pointer">
            <el-row>
              <el-col :span="24">
                <el-form-item label="语速类型" prop="judge">
                  <el-select
                    v-model="addForm.wordSpeedType"
                    :disabled="showDisabled"
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in yusuType"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </el-form-item>
                <el-col :span="24">
                  <el-form-item label="角色" prop="yuSuRole">
                    <el-select v-model="yuSuRole" placeholder="请选择角色">
                      <el-option
                        v-for="item in roleOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-form-item
                v-for="(domain, index) in addForm.domainsParamsYu.domains"
                :key="index"
                prop="domains"
              >
                <div class="demo-input-size">
                  <el-input
                    oninput="value=value.replace(/[^-\d]/g,'')"
                    :disabled="showDisabled"
                    :maxlength="3"
                    placeholder="字/秒"
                    v-model="domain.minWord"
                    class="w120"
                  ></el-input>
                  <a>字/秒</a>
                  <label class="ml">-</label>
                  <el-input
                    oninput="value=value.replace(/[^-\d]/g,'')"
                    :disabled="showDisabled"
                    :maxlength="3"
                    class="w120"
                    v-model="domain.maxWord"
                    placeholder="字/秒"
                  ></el-input>
                  <a>字/秒</a>
                  <el-select
                    :disabled="showDisabled"
                    style="width:100px;margin-right: 10px;"
                    v-model="domain.increaseDeduction"
                  >
                    <el-option key="1" label="加" value="1"></el-option>
                    <el-option key="2" label="减" value="2"></el-option>
                  </el-select>
                  <el-input
                    oninput="value=value.replace(/[^-\d]/g,'')"
                    :disabled="showDisabled"
                    :maxlength="3"
                    v-model="domain.score"
                    style="width: 60px"
                  ></el-input>
                  <label class="ml" style=" margin-right: 10px;">分</label>
                  <a v-if="myTitle != '查看标准'">
                    <div class="plus-minus-button d-ib m-l-10">
                      <el-button class="icon" @click="addDomainYu">
                        <i class="el-icon-plus"></i>
                      </el-button>
                      <el-button
                        class="icon"
                        @click.prevent="removeDomainYu(index)"
                        v-show="index > 0"
                      >
                        <i class="el-icon-minus"></i>
                      </el-button>
                    </div>
                  </a>
                  <a v-else></a>
                </div>
              </el-form-item>
            </el-row>
          </div>
          <div id="tags" v-show="judgeAuto === 11" style="padding: 0 30px;">
            <div class="flex-box">
              <el-form-item
                class="flex-box-list"
                v-for="(domain, index) in addForm.domainsTags.domains"
                :key="index"
                prop="domains"
              >
                <el-select
                  v-model="domain.labelId"
                  :props="selectDefaultProps"
                  filterable
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in labelList"
                    :key="item.labelId"
                    :label="getLabelName(item)"
                    :value="item.labelId"
                  >
                    <el-popover
                      v-if="item.keyWords && item.keyWords.length"
                      placement="right"
                      :open-delay="delay"
                      trigger="hover"
                    >
                      <div
                        v-for="word in item.keyWords"
                        :key="word.id"
                        style="max-width:400px;margin:5px 0;line-height:1.25em;"
                      >
                        {{ getKeywordLabel(word) }}
                      </div>
                      <div slot="reference">{{ getLabelName(item) }}</div>
                    </el-popover>
                  </el-option>
                </el-select>
                <div class="plus-minus-button d-ib m-l-10">
                  <el-button
                    class="icon"
                    @click.prevent="removeDomainTags(domain)"
                    v-if="addForm.domainsTags.domains.length > 1"
                  >
                    <i class="el-icon-minus"></i>
                  </el-button>
                  <el-button
                    class="icon"
                    @click="addDomainTags"
                    :disabled="index == 4 ? true : false"
                    v-if="index === addForm.domainsTags.domains.length - 1"
                  >
                    <i class="el-icon-plus"></i>
                  </el-button>
                </div>
              </el-form-item>
            </div>
          </div>
          <div v-show="judgeAuto === 6" id="shoudong">
            <el-form-item style="margin-left: 44px;">
              <label>分值范围&emsp;</label>
              <el-input
                :maxlength="4"
                :disabled="showDisabled"
                v-model="addForm.minScoreRange"
                class="w120"
              ></el-input>
              <label> - </label>
              <el-input
                :maxlength="4"
                :disabled="showDisabled"
                v-model="addForm.maxScoreRange"
                class="w120"
              ></el-input>
              <label>默认分数&emsp;</label>
              <el-input
                :disabled="showDisabled"
                :maxlength="4"
                v-model="addForm.defaultScore"
                class="w120"
              ></el-input>
            </el-form-item>
            <el-form-item label="评分标准" prop="normalContent">
              <el-input
                :disabled="showDisabled"
                :rows="6"
                style="width: 450px"
                type="textarea"
                v-model="addForm.normalContent"
              ></el-input>
            </el-form-item>
          </div>
          <div v-show="judgeAuto === 7" id="xuanxiang">
            <el-row>
              <el-col :span="24">
                <el-form-item
                  :span="24"
                  label="选项"
                  v-for="(domain, index) in addForm.xuanDomains.domains"
                  :key="index"
                  prop="domains"
                >
                  <el-input
                    style="width: 300px"
                    :disabled="showDisabled"
                    placeholder="请输入"
                    v-model.trim="domain.optionTexts"
                    :maxlength="10"
                  ></el-input>
                  <div class="plus-minus-button d-ib m-l-10">
                    <el-button class="icon" @click="addDomainMan">
                      <i class="el-icon-plus"></i>
                    </el-button>
                    <el-button
                      class="icon"
                      v-show="index > 0"
                      @click="removeDomainMan(domain)"
                    >
                      <i class="el-icon-minus"></i>
                    </el-button>
                  </div>
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="评分标准" prop="normalContent">
              <el-input
                :disabled="showDisabled"
                :rows="6"
                style="width: 450px"
                type="textarea"
                v-model="addForm.normalContent"
              ></el-input>
            </el-form-item>
          </div>
          <div v-show="judgeAuto === 8" id="zhimingxiang">
            <el-row>
              <el-col :span="24">
                <el-form-item label="致命项标准" prop="normalContent">
                  <el-input
                    :disabled="showDisabled"
                    :rows="6"
                    type="textarea"
                    style="width: 450px"
                    v-model="addForm.normalContent"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
          <el-form-item
            v-if="judgeAuto == 5 || (judgeAuto == 3 && addForm.silenceType == 5)"
            class="key-words"
            v-for="(item, index) in items"
            :model="item"
            :key="item.id"
            prop="keyWords"
            style="display: block;"
          >
            <div class="u-flex">
              <el-form
                class="key-word"
                size="small"
                ref="addKeyWord"
                :model="item.keyWordData"
              >
                <!-- 关键词配置规则 -->
                <el-form-item class="key-words-range">
                  <el-select
                    :disabled="showDisabled"
                    style="width: 110px"
                    v-model="item.keyWordData.roleType"
                  >
                    <el-option label="全部角色" :value="0"></el-option>
                    <el-option label="客服" :value="1"></el-option>
                    <el-option label="客户" :value="2"></el-option>
                  </el-select>
                  <span class="zai">在</span>
                  <span
                    class="d-ib"
                    style="width:400px"
                    v-if="judgeAuto == 3 && addForm.silenceType == 5"
                  >
                    <span class="zai">静默时间大于</span>
                    <el-input
                      class="number-input"
                      v-model.number="item.keyWordData.silenceTimeMax"
                      oninput="value=value.replace(/[^-\d]/g,'')"
                      maxLength="3"
                    ></el-input>
                    <span>秒</span>
                    <el-select
                      size="small"
                      class="gap size-select"
                      v-model="item.keyWordData.position"
                    >
                      <el-option label="前" value="0"></el-option>
                      <el-option label="后" value="1"></el-option>
                    </el-select>
                    <el-input
                      v-model.number="item.keyWordData.sceneTime"
                      oninput="value=value.replace(/[^-\d]/g,'')"
                      maxLength="3"
                      size="small"
                      class="gap size-ju"
                    ></el-input
                    >句
                  </span>
                  <el-select
                    v-else
                    size="small"
                    class="size-select"
                    v-model="item.keyWordData.position"
                  >
                    <el-option label="全文" value="0"></el-option>
                    <el-option label="开头" value="1"></el-option>
                    <el-option label="结束" value="2"></el-option>
                  </el-select>
                  <template v-if="judgeAuto !== 3 && item.keyWordData.position != '0'">
                    <el-input
                      v-model.number="item.keyWordData.offset"
                      oninput="value=value.replace(/[^-\d]/g,'')"
                      maxLength="3"
                      size="small"
                      class="gap size-ju"
                    ></el-input
                    >句
                  </template>
                  <el-select
                    size="small"
                    class="gap size-select"
                    v-model="item.keyWordData.isAppear"
                  >
                    <el-option label="出现" :value="1"></el-option>
                    <el-option label="未出现" :value="0"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item class="key-words-content" prop="keywordContext">
                  <el-input
                    @blur="changeKeywordContext($event, index)"
                    ref="textInput"
                    type="textarea"
                    v-model="item.keyWordData.keywordContext"
                    placeholder="请输入关键词"
                    size="small"
                    maxlength="4000"
                  ></el-input>
                  <div class="err-keyword" v-if="item.keyWordData.errKeywordContext">
                    <div class="itm-tip">
                      <p>!</p>
                      <span>提示：规则配置不符合规范,请修改错误提示处</span>
                    </div>
                    <div
                      class="itm-err"
                      v-html="item.keyWordData.errKeywordContext"
                    ></div>
                  </div>
                  <div class="logical-words u-flex">
                    <div class="u-flex-item">
                      <el-button
                        size="small"
                        :disabled="!item.keyWordData.keywordContext"
                        @click="AND(index)"
                        >AND</el-button
                      >
                      <el-button
                        size="small"
                        :disabled="!item.keyWordData.keywordContext"
                        @click="OR(index)"
                        >OR</el-button
                      >
                      <el-button
                        size="small"
                        :disabled="!item.keyWordData.keywordContext"
                        @click="AFTER(index)"
                        >AFTER</el-button
                      >
                      <el-button
                        size="small"
                        :disabled="!item.keyWordData.keywordContext"
                        @click="BEFORE(index)"
                        >BEFORE</el-button
                      >
                      <el-button
                        size="small"
                        :disabled="!item.keyWordData.keywordContext"
                        @click="NEAR(index)"
                        >NEAR</el-button
                      >
                      <el-button size="small" @click="CIRCLE(index)">( )</el-button>
                    </div>
                    <el-popover
                      placement="bottom"
                      title="使用说明"
                      width="400"
                      trigger="hover"
                    >
                      <div v-html="hoverTip"></div>
                      <el-button slot="reference" class="instructions" size="small"
                        >?</el-button
                      >
                    </el-popover>
                  </div>
                </el-form-item>
              </el-form>
              <div class="plus-minus-button">
                <el-button
                  class="icon"
                  @click="itemMinus(item)"
                  v-if="index == 0 && items.length == 1 ? false : true"
                >
                  <i class="el-icon-minus"></i>
                </el-button>
                <el-button
                  class="icon"
                  @click="itemPlus"
                  :disabled="index == 4 ? true : false"
                  v-if="index == items.length - 1 ? true : false"
                >
                  <i class="el-icon-plus"></i>
                </el-button>
              </div>
            </div>
          </el-form-item>
          <el-form-item
            v-if="
              judgeAuto == 5 ||
                judgeAuto == 11 ||
                (judgeAuto == 3 && addForm.silenceType == 5)
            "
            style="margin-bottom: 10px;display:inline-block"
            label-width="100px"
            label="满足任意"
          >
            <div class="u-flex">
              <el-input
                v-model.number="addForm.correctNumber"
                class="number-input"
                oninput="value=value.replace(/[^-\d]/g,'')"
                maxLength="3"
                size="small"
              ></el-input>
              <span>个</span>
            </div>
          </el-form-item>
          <el-form-item
            v-if="judgeAuto == 5"
            style="margin-bottom: 10px;display:inline-block"
          >
            <div class="u-flex" style="padding-left: 30px;margin-bottom: 10px;">
              <el-checkbox v-model="addForm.isSet">同步建立标签</el-checkbox>
              <el-input
                size="small"
                v-model="addForm.setLabelName"
                placeholder="标签名称"
              ></el-input>
            </div>
          </el-form-item>
          <el-form-item
            v-if="judgeAuto == 5 || judgeAuto == 11"
            label="是否致命"
            prop="deadItem"
          >
            <el-radio-group v-model="addForm.deadItem" @change="changeDeadItem">
              <el-radio :label="2">否</el-radio>
              <el-radio :label="1">是</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item
            v-if="
              judgeAuto == 5 ||
                judgeAuto == 11 ||
                (judgeAuto == 3 && addForm.silenceType == 5)
            "
            style="width:100%;margin-bottom: 10px;"
            label-width="100px"
            label="质检规则"
          >
            <div class="u-flex">
              <el-select
                :disabled="mingScoreDisabled"
                v-model="addForm.increaseDeduction"
                style="width:80px;"
                size="small"
              >
                <el-option label="加" :value="1"></el-option>
                <el-option label="减" :value="2"></el-option>
              </el-select>
              <el-input
                :disabled="mingScoreDisabled"
                size="small"
                class="number-input"
                v-model.number="addForm.mingScore"
                oninput="value=value.replace(/[^-\d]/g,'')"
                maxLength="3"
              ></el-input
              >分
            </div>
          </el-form-item>
          <div v-show="judgeAuto === 13" id="contentQa">
            <el-form-item :span="24" label="选择意图" prop="contentIntent">
              <el-select
                filterable
                @change="changeIntents"
                v-model="addForm.contentIntent"
                popper-class="select_drop"
                placeholder="请选择"
              >
                <el-option
                  v-for="item in intentionList"
                  :key="item.faqId"
                  :label="item.question"
                  :value="item.faqId"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="标准答案" prop="contentAnswer">
              <div class="content-answer" v-html="addForm.contentAnswer"></div>
            </el-form-item>
            <el-form-item label="评分规则" prop="">
              <el-input
                oninput="value=value.replace(/[^-\d]/g,'')"
                :maxlength="3"
                v-model="addForm.scoringRules"
                style="width: 100px"
                placeholder="请输入"
              ></el-input
              ><label class="m-l-10">句内</label>
            </el-form-item>
            <div
              style="margin-bottom: 30px;border-bottom:1px solid #ccc;padding-bottom: 30px;"
              v-for="(item, index) in addForm.contentParam"
              :key="index"
            >
              <el-row>
                <el-col :span="24">
                  <el-form-item label="设置话术" prop="">
                    <el-input
                      v-model="item.content"
                      style="width: 200px"
                      placeholder="请输入"
                    ></el-input>
                    <div class="plus-minus-button d-ib m-l-10">
                      <el-button type="text" @click="handleSimlarWords(index)">
                        <span v-if="item.ivsQaSpeechCrafts"
                          >{{ item.ivsQaSpeechCrafts.length }}条相似话术</span
                        >
                        <span v-else>+ 添加相似话术</span>
                      </el-button>
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>

              <el-row>
                <el-col :span="42" style="text-align:center;">
                  <el-select v-model="item.isAppear" style="width:100px;">
                    <el-option label="出现" value="1"> </el-option>
                    <el-option label="不出现" value="2"> </el-option>
                  </el-select>
                  <el-select v-model="item.addsub" style="width:100px;">
                    <el-option label="加" value="1"> </el-option>
                    <el-option label="减" value="2"> </el-option>
                  </el-select>
                  <el-input
                    oninput="value=value.replace(/[^-\d]/g,'')"
                    :maxlength="3"
                    v-model="item.score"
                    style="width: 100px;margin-left:90px;"
                    placeholder="请输入"
                  ></el-input
                  ><label class="m-l-10">分</label>
                  <el-button
                    type="text"
                    v-show="addForm.contentParam.length > 1"
                    style="margin-left:120px;"
                    @click="addForm.contentParam.splice(index, 1)"
                    >- 删除话术</el-button
                  >
                </el-col>
              </el-row>
            </div>
            <p style="text-align: center;">
              <el-button type="text" @click="addDiscourse">+ 添加话术</el-button>
            </p>
          </div>

          <!-- 上下文质检 -->
          <div v-show="judgeAuto === 12" id="contextQa">
            <el-form
              class="key-word"
              size="small"
              ref="contextData"
              :model="contextData"
              :rules="contextDataRules"
            >
              <el-form-item class="key-words-range" prop="firstRoleType">
                <el-select
                  :disabled="showDisabled"
                  style="width: 110px"
                  v-model="contextData.firstRoleType"
                >
                  <el-option label="客服" value="1"></el-option>
                  <el-option label="客户" value="2"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item class="key-words-content" prop="firstContext">
                <el-input
                  ref="textInput"
                  type="textarea"
                  v-model="contextData.firstContext"
                  placeholder="请输入关键词"
                  size="small"
                  maxlength="4000"
                ></el-input>
                <div class="logical-words u-flex">
                  <div class="u-flex-item">
                    <el-button
                      size="small"
                      :disabled="!contextData.firstContext"
                      @click="AND(index)"
                      >AND</el-button
                    >
                    <el-button
                      size="small"
                      :disabled="!contextData.firstContext"
                      @click="OR(index)"
                      >OR</el-button
                    >
                    <el-button
                      size="small"
                      :disabled="!contextData.firstContext"
                      @click="AFTER(index)"
                      >AFTER</el-button
                    >
                    <el-button
                      size="small"
                      :disabled="!contextData.firstContext"
                      @click="BEFORE(index)"
                      >BEFORE</el-button
                    >
                    <el-button
                      size="small"
                      :disabled="!contextData.firstContext"
                      @click="NEAR(index)"
                      >NEAR</el-button
                    >
                    <el-button size="small" @click="CIRCLE(index)">( )</el-button>
                  </div>
                  <el-popover
                    placement="bottom"
                    title="使用说明"
                    width="400"
                    trigger="hover"
                  >
                    <div v-html="hoverTip"></div>
                    <el-button slot="reference" class="instructions" size="small"
                      >?</el-button
                    >
                  </el-popover>
                </div>
              </el-form-item>
              <el-form-item class="key-words-range" prop="secondRoleType">
                <el-select
                  :disabled="showDisabled"
                  style="width: 110px"
                  v-model="contextData.secondRoleType"
                >
                  <el-option label="客服" value="1"></el-option>
                  <el-option label="客户" value="2"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item class="key-words-content" prop="secondContext">
                <el-input
                  ref="textInputSec"
                  type="textarea"
                  v-model="contextData.secondContext"
                  placeholder="请输入关键词"
                  size="small"
                  maxlength="4000"
                ></el-input>
                <div class="logical-words u-flex">
                  <div class="u-flex-item">
                    <el-button
                      size="small"
                      :disabled="!contextData.secondContext"
                      @click="AND(0, 'secContext')"
                      >AND</el-button
                    >
                    <el-button
                      size="small"
                      :disabled="!contextData.secondContext"
                      @click="OR(0, 'secContext')"
                      >OR</el-button
                    >
                    <el-button
                      size="small"
                      :disabled="!contextData.secondContext"
                      @click="AFTER(0, 'secContext')"
                      >AFTER</el-button
                    >
                    <el-button
                      size="small"
                      :disabled="!contextData.secondContext"
                      @click="BEFORE(0, 'secContext')"
                      >BEFORE</el-button
                    >
                    <el-button
                      size="small"
                      :disabled="!contextData.secondContext"
                      @click="NEAR(0, 'secContext')"
                      >NEAR</el-button
                    >
                    <el-button size="small" @click="CIRCLE(0, 'secContext')"
                      >( )</el-button
                    >
                  </div>
                  <el-popover
                    placement="bottom"
                    title="使用说明"
                    width="400"
                    trigger="hover"
                  >
                    <div v-html="hoverTip"></div>
                    <el-button slot="reference" class="instructions" size="small"
                      >?</el-button
                    >
                  </el-popover>
                </div>
              </el-form-item>
              <el-form-item label="是否致命" prop="deadItem">
                <el-radio-group
                  v-model="contextData.sentenceDeadItem"
                  @change="
                    contextData.sentenceDeadItem == 1
                      ? (contextData.score = 0)
                      : contextData.score
                  "
                >
                  <el-radio label="2">否</el-radio>
                  <el-radio label="1">是</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="评分规则" prop="sentenceCount">
                <el-input
                  oninput="value=value.replace(/[^-\d]/g,'')"
                  :maxlength="3"
                  v-model="contextData.sentenceCount"
                  style="width:100px"
                  placeholder="请输入"
                ></el-input
                ><label class="m-l-10">句内</label>
              </el-form-item>
              <el-row>
                <el-col :span="42" style="text-align:center;">
                  <el-select
                    v-model="contextData.isAppear"
                    style="width:100px;margin-left:10px;"
                  >
                    <el-option label="出现" value="1"> </el-option>
                    <el-option label="不出现" value="2"> </el-option>
                  </el-select>
                  <el-select
                    :disabled="contextData.sentenceDeadItem == 1"
                    v-model="contextData.increaseDeduction"
                    style="width:100px;margin-left:10px;"
                  >
                    <el-option label="加" value="1"> </el-option>
                    <el-option label="减" value="2"> </el-option>
                  </el-select>
                  <el-form-item prop="score" style="display: inline-block">
                    <el-input
                      oninput="value=value.replace(/[^-\d]/g,'')"
                      :maxlength="3"
                      :disabled="contextData.sentenceDeadItem == 1"
                      v-model="contextData.score"
                      style="width: 100px;margin-left:10px;"
                      placeholder="请输入"
                    ></el-input
                    ><label class="m-l-10">分</label>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
        </el-form>

        <div slot="footer" class="dialog-footer" v-if="myTitle != '查看标准'">
          <el-button @click="addTableCanel">取 消</el-button>
          <el-button type="primary" @click="addTableYesThrottle">确 定</el-button>
        </div>
        <div slot="footer" v-else class="dialog-footer">
          <el-button @click="addTableCanel">关闭</el-button>
        </div>
      </el-dialog>
      <el-dialog
        width="50%"
        title="编辑相似词"
        :visible.sync="simlarWordsVisible"
        :modal-append-to-body="false"
        :close-on-click-modal="false"
      >
        <div>
          <el-form :inline="true" v-model="simlarWordsForm" ref="simlarWordsForm">
            <el-form-item
              v-for="(itm, idx) in simlarWordsForm.ivsQaSpeechCrafts"
              :key="idx"
            >
              <el-input
                style="width:220px"
                placeholder="请输入"
                v-model="simlarWordsForm.ivsQaSpeechCrafts[idx].speechcraftContent"
              ></el-input>
              <el-button
                @click="simlarWordsForm.ivsQaSpeechCrafts.splice(idx, 1)"
                type="text"
                >删除</el-button
              >
            </el-form-item>
          </el-form>
          <el-button type="text" @click="addSimilarWord">+ 添加一条</el-button>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button @click="cancleSimlarWords">取 消</el-button>
          <el-button type="primary" @click="saveSimlarWords">确 定</el-button>
        </div>
      </el-dialog>
      <el-dialog
        :close-on-click-modal="false"
        @close="editCancel"
        title="修改分类"
        :visible.sync="editTreeModal"
      >
        <el-form :model="editTreeForm" ref="editTreeForm" :rules="editTreeRules">
          <el-form-item label="分类名称" prop="classTitle" :label-width="formLabelWidth">
            <el-input style="width:220px" v-model="editTreeForm.classTitle"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="editCancel">取 消</el-button>
          <el-button type="primary" @click="editSaveClassThrottle">确 定</el-button>
        </div>
      </el-dialog>
      <div class="autoGrading-body">
        <el-row>
          <el-col :span="24">
            <div class="contentLeft">
              <div class="standard">
                <ul
                  v-for="item in this.autoTemplateData"
                  :key="item.id"
                  style="display:flex;flex-direction:column;"
                >
                  <div class="standardClass">
                    <span class="standardClass_title">{{
                      item.classInfo.classTitle
                    }}</span>
                    <el-button
                      funcId="000398"
                      plain
                      size="mini"
                      class="button"
                      @click="addManualAuto(item.classInfo.classId)"
                      >添加标准</el-button
                    >
                    <div class="standardClass_right">
                      <div class="standardClass_btn">
                        <span
                          funcId="000399"
                          @click="editTree(item.classInfo.classId)"
                          style="margin-right:10px"
                          >编辑</span
                        >
                        <span
                          funcId="000400"
                          @click="
                            delTree(item.classInfo.classId, item.classInfo.classTitle)
                          "
                          style="margin-right:10px"
                          >删除</span
                        >
                      </div>
                    </div>
                  </div>
                  <el-table border tooltip-effect="dark" :data="item.normalList">
                    <el-table-column prop="normalName" label="标准名称" width="200">
                    </el-table-column>
                    <el-table-column
                      width="200"
                      prop="judge"
                      :formatter="formatJudge"
                      label="打分方式"
                    >
                    </el-table-column>
                    <el-table-column label="规则">
                      <template scope="scope">
                        <div v-if="scope.row.judge === 13">
                          <p>意图:{{ scope.row.faqContent }}</p>
                        </div>
                        <div v-for="rules in scope.row.rulesList" :key="rules.id">
                          <div v-if="scope.row.judge === 11">
                            <span>{{ rules.labelName }}</span>
                            <span v-if="rules.score !== 0"
                              >{{ rules.increaseDeduction == '2' ? '减' : '加'
                              }}{{ rules.score }}分</span
                            >
                            <el-popover placement="right" width="120" trigger="hover">
                              <template v-if="rules.deadItem == '1'" slot="reference">
                                <i class="el-icon-warning" style="color: red"></i>
                              </template>
                              <p>{{ mingzhongTip }}</p>
                            </el-popover>
                          </div>
                          <div v-if="scope.row.judge === 12">
                            <span>{{ rules.labelName }}</span>
                            <span
                              >{{ rules.firstRoleType == 1 ? '客服' : '客户' }}:{{
                                rules.firstContext
                              }}
                              {{ rules.secondRoleType == 1 ? '客服' : '客户' }}:{{
                                rules.secondContext
                              }}</span
                            >
                            <p>
                              {{ rules.sentenceCount }}句内,
                              {{ rules.isAppear == 1 ? '出现' : '不出现' }}
                              <span v-if="rules.score !== 0"
                                >{{ rules.increaseDeduction == '2' ? '减' : '加'
                                }}{{ rules.score }}分</span
                              >
                            </p>
                            <el-popover placement="right" width="120" trigger="hover">
                              <template
                                v-if="rules.sentenceDeadItem == '1'"
                                slot="reference"
                              >
                                <i class="el-icon-warning" style="color: red"></i>
                              </template>
                              <p>{{ mingzhongTip }}</p>
                            </el-popover>
                          </div>
                          <div v-if="scope.row.judge === 13">
                            <p>
                              话术:{{ rules.content }}。 规则：{{
                                scope.row.scoringRules
                              }}句内, {{ rules.isAppear == 1 ? '出现' : '不出现'
                              }}{{ rules.addsub == '2' ? '减' : '加' }}{{ rules.score }}分
                            </p>
                          </div>
                          <div v-if="scope.row.judge === 5">
                            <span>{{
                              rules.keywordContext +
                                getKeywordScore(rules, scope.row.judge)
                            }}</span>
                            <el-popover trigger="hover" placement="right">
                              <template
                                v-if="scope.row.judge === 5 && rules.deadItem == '1'"
                                slot="reference"
                              >
                                <i class="el-icon-warning" style="color: red"></i>
                              </template>
                              <p>{{ mingzhongTip }}</p>
                            </el-popover>
                          </div>
                          <p v-if="scope.row.judge === 4">
                            {{ rules.minWord }}-{{ rules.maxWord }}字/秒&nbsp;&nbsp;{{
                              rules.increaseDeduction == '2' ? '减' : '加'
                            }}{{ rules.score }}分
                          </p>
                          <p v-if="scope.row.judge === 3 && rules.silenceType === 1">
                            {{ rules.silenceTimeMin }}-{{
                              rules.silenceTimeMax
                            }}秒&nbsp;&nbsp;{{
                              rules.increaseDeduction == '2' ? '减' : '加'
                            }}{{ rules.score }}分
                          </p>
                          <p v-if="scope.row.judge === 3 && rules.silenceType === 2">
                            {{ rules.silenceTimeMin }}-{{
                              rules.silenceTimeMax
                            }}次&nbsp;&nbsp;{{
                              rules.increaseDeduction == '2' ? '减' : '加'
                            }}{{ rules.score }}分
                          </p>
                          <p v-if="scope.row.judge === 3 && rules.silenceType === 3">
                            {{ rules.silenceTimeMin }}-{{
                              rules.silenceTimeMax
                            }}%&nbsp;&nbsp;{{
                              rules.increaseDeduction == '2' ? '减' : '加'
                            }}{{ rules.score }}分
                          </p>
                          <p v-if="scope.row.judge === 3 && rules.silenceType === 4">
                            {{ rules.silenceTimeMin }}-{{
                              rules.silenceTimeMax
                            }}秒&nbsp;&nbsp;{{
                              rules.increaseDeduction == '2' ? '减' : '加'
                            }}{{ rules.score }}分
                          </p>
                          <p v-if="scope.row.judge === 3 && rules.silenceType === 5">
                            {{
                              rules.keywordContext +
                                getKeywordScore(rules, scope.row.judge)
                            }}
                          </p>
                          <p v-if="scope.row.judge === 2">
                            {{ rules.silenceTimeMin }}-{{
                              rules.silenceTimeMax
                            }}次&nbsp;&nbsp;{{
                              rules.increaseDeduction == '2' ? '减' : '加'
                            }}{{ rules.score }}分
                          </p>
                          <p v-if="scope.row.judge === 1">
                            {{ rules.silenceTimeMin }}-{{
                              rules.silenceTimeMax
                            }}次&nbsp;&nbsp;{{
                              rules.increaseDeduction == '2' ? '减' : '加'
                            }}{{ rules.score }}分
                          </p>
                        </div>
                        <div class="lists" v-if="scope.row.judge == 6">
                          <span style="margin-left:20px;"
                            >分值范围{{ scope.row.minScoreRange }}-{{
                              scope.row.maxScoreRange
                            }}分</span
                          >
                          <span style="margin-left:20px;"
                            >默认分数{{ scope.row.defaultScore }}分</span
                          >
                        </div>
                        <div class="services" v-if="scope.row.judge == 7">
                          <el-checkbox-group v-model="checkboxGroup3">
                            <el-checkbox-button
                              v-for="title in scope.row.optionTexts"
                              :label="title"
                              :key="title"
                              >{{ title }}</el-checkbox-button
                            >
                          </el-checkbox-group>
                        </div>
                        <div v-if="scope.row.judge == 8">
                          <el-popover placement="right" width="120" trigger="hover">
                            <template slot="reference">
                              <el-radio-group size="medium" fill="#97a8be">
                                <el-radio-button :label="'1'">致命</el-radio-button>
                                <el-radio-button :label="'2'">非致命</el-radio-button>
                              </el-radio-group>
                            </template>
                            <p>{{ scope.row.normalContent || '无' }}</p>
                          </el-popover>
                          <el-popover trigger="hover" placement="right">
                            <template slot="reference">
                              <i class="el-icon-warning" style="color: red"></i>
                            </template>
                            <p>{{ mingzhongTip }}</p>
                          </el-popover>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column label="操作" width="150">
                      <template scope="scope">
                        <span
                          funcId="000396"
                          @click="
                            editNormalInfo(scope.row.normalId, item.classInfo.classId, 1)
                          "
                          style="margin-right:10px;color:#20a0ff;cursor: pointer;"
                          >编辑</span
                        >
                        <span
                          funcId="000397"
                          @click="delNormalInfo(scope.row.normalId, scope.row.normalName)"
                          style="margin-right:10px;color:#20a0ff;cursor: pointer;"
                          >删除</span
                        >
                      </template>
                    </el-table-column>
                  </el-table>
                </ul>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import $ from 'jquery'
import Qs from 'qs'
import global from '../../../global.js'
let manalScore = global.qualityUrl
let currentBaseUrl = global.currentBaseUrl
import formatdate from '../../../utils/formatdate.js'
import { validModelTrim } from '@/utry-sdk/common/constants'
export default {
  props: ['modleIdNew', 'mdtitle', 'info', 'updateTime', 'baseScore','labelList'],
  data() {
    /**
     * 合格分数验证
     * **/
    const validQualityScore = (rule, value, callback) => {
      let param = /^[0-9]{1,3}$/
      if (value == '') {
        callback()
      } else if (!param.test(value)) {
        callback(new Error('请输入正确的分数'))
      } else {
        callback()
      }
    }
    const validclassTitle = (rule, value, callback) => {
      let param = /^[a-zA-Z0-9\u4e00-\u9fa5]+$/
      if (value.length > 10) {
        callback(new Error('分类名称长度不能大于10！'))
      } else if (!param.test(value)) {
        callback(new Error('请输入合法名称！'))
      } else {
        callback()
      }
    }
    const validremark = (rule, value, callback) => {
      if (value != null && value.length > 100) {
        callback(new Error('备注长度不能大于100！'))
      } else {
        callback()
      }
    }
    const validName = (rule, value, callback) => {
      let param = /^[a-zA-Z0-9\u4e00-\u9fa5]+$/
      if (value.length > 10) {
        callback(new Error('标准名称长度不能大于10！'))
      } else if (!param.test(value)) {
        callback(new Error('请输入合法的标准！'))
      } else {
        callback()
      }
    }
    const validDefaultScore = (rule, value, callback) => {
      let param = RegExp('^-?\\d+$')
      this.defaultNum = value
      if (this.addForm.judge <= 4 && (value + '').trim().length === 0) {
        callback(new Error('默认分数不能为空'))
      } else if (value != '' && !param.test(value)) {
        callback(new Error('默认分数应为整数！'))
      }
      if (value >= 100) {
        callback(new Error('默认分数应为两位数！'))
      }
      callback()
    }
    const validScoreRange = (rule, valueMin, callback) => {
      let param = RegExp('^-?\\d+$')
      if (!param.test(valueMin)) {
        callback(new Error('最小值应为整数！'))
      } else if (parseInt(valueMin) > this.maxv) {
        callback(new Error('命中分数在分值范围内！'))
      } else {
        callback()
      }
    }
    const validModelTitle = (rule, value, callback) => {
      if (value.trim().length > 50) {
        callback(new Error('不能超过50个字符'))
      } else {
        callback()
      }
    }
    const validFirstRoleType = (rule,value,callback)=>{
      if(value===this.contextData.secondRoleType){
        callback(new Error('角色不能重复'))
      }else{
        callback()
      }
    }
    const validSecondRoleType = (rule,value,callback)=>{
      if(value===this.contextData.firstRoleType){
        callback(new Error('角色不能重复'))
      }else{
        callback()
      }
    }
    return {
      //上下文质检
      contextData:{
        firstRoleType:'1',
        firstContext:'',
        secondRoleType:'2',
        secondContext:'',
        sentenceDeadItem:'2',
        sentenceCount:'',
        isAppear: '1',//出现or不出现
        increaseDeduction:'1',//加分减分
        score: '',//分数
      },
      contextDataRules:{
        firstContext:[{required:true,message:'请输入',trigger:'blur'}],
        secondContext:[{required:true,message:'请输入',trigger:'blur'}],
        sentenceCount:[{required:true,message:'请输入',trigger:'blur'}],
        score:[{required:true,message:'请输入',trigger:'blur'}],
        firstRoleType:[{required:true,message:'请输入',trigger:'blur'},
          {validator:validFirstRoleType,trigger:'blur'}],
        secondRoleType:[{required:true,message:'请输入',trigger:'blur'},
          {validator:validSecondRoleType,trigger:'blur'}],
      },
      simlarWordsForm:{
        simlarWords:[],
        ivsQaSpeechCrafts:[],
      },//相似词
      simlarWordsVisible:false,
      updateTime_sub: '',
      remnant: 500,
      showJingmoType: false,
      showScoreType: false,
      showSilenceType: true,
      showDisabled: false,
      mingScoreDisabled: false,
      showOffset: false,
      checkboxGroup1: ['上海'],
      checkboxGroup3: ['广州'],
      totalScore: 0,
      typelist: [],
      autoTemplateData: [],
      autoTotalScore: 0,
      yusuType: [
        {
          value: 1,
          label: '平均语速',
        },
        {
          value: 2,
          label: '最大语速',
        },
      ],
      options2: [
        {
          value: 1,
          label: '情绪',
        },
        {
          value: 2,
          label: '重叠次数',
        },
        {
          value: 3,
          label: '静默',
        },
        {
          value: 4,
          label: '语速',
        },
        {
          value: 5,
          label: '关键词',
        },
        {
          value: 11,
          label: '标签',
        },{
          value: 13,
          label: '内容质检',
        },
        {
          value: 12,
          label: '上下文质检',
        },
          {
              value: 6,
              label: '自定义输入',
          },
          {
              value: 7,
              label: '自定义选项',
          },
          {
              value: 8,
              label: '自定义致命项',
          },
      ],
      copyBaseScore: this.baseScore,
      tableData: [],
      resultObject: [],
      editNamesForm: {
        modleTitle: '',
        remark: '',
      },
      namesRules: {
        modleTitle: [
          {
            required: true,
            message: '请输入模板名称！',
            trigger: 'blur',
          },
          {
            validator: validModelTitle,
            trigger: 'blur',
          },
        ],
      },
      namesForm: {
        modleTitle: '',
      },
      Show: false,
      isShow: true,
      tableFormRules: {
        score: [
          {
            validator: validScoreRange,
            trigger: 'blur',
          },
        ],
        normalName: [
          {
            required: true,
            message: '请输入合法的标准！',
            trigger: 'blur',
          },
          {
            validator: validName,
            trigger: 'blur',
          },
        ],
        normalContent: [
          { min: 0, max: 250, message: '不能超过250个字符', trigger: 'change' }
        ],
        defaultScore: [
          {
            validator: validDefaultScore,
            trigger: 'blur',
          },
        ],
      },
      minx: '',
      maxv: '',
      manualTitle: '修改标准',
      formLabelWidth: '120px',
      editTreeRules: {
        classTitle: [
          {
            required: true,
            message: '请输入分类名称！',
            trigger: 'blur',
          },
          {
            validator: validclassTitle,
            trigger: 'blur',
          },
        ],
        remark: [
          {
            validator: validremark,
            trigger: 'blur',
          },
        ],
      },
      treeFormRules: {
        classTitle: [
          {
            required: true,
            message: '请输入分类名称！',
            trigger: 'blur',
          },
          {
            validator: validclassTitle,
            trigger: 'blur',
          },
        ],
        remark: [
          {
            validator: validremark,
            trigger: 'blur',
          },
        ],
      },
      addTreeForm: {
        classTitle: '',
        remark: '',
        classId: '',
        modleId: '',
        typeid: '',
        // parentClassId: '',
      },
      editTreeForm: {
        classTitle: '',
        remark: '',
        classId: '',
        modleId: '',
        typeid: '',
        // parentClassId: '',
      },
      dialogTreeFormVisible: false,
      defaultProps: {
        children: 'children',
        label: 'label',
      },
      formInlineAuto: {
        normalName: '',
        region: '',
      },
      formInlineArtificial: {
        user: '',
        region: '',
      },
      perviewModel: '',
      dialogFormVisible: false,
      selectDefaultProps: {
        value: 'labelId',
        label: 'labelName',
      },
      // 内容质检 意图对象
      simlarWordsIdx:'',
      intendsData:{
        faqId:'',
        faqContent:'',
        answer:'',
        answerId:'',
        customerIntention:'',
        faqUpdateTime:'',
      },
      addForm: {
        contentIntent:'',//内容质检意图
        contentAnswer:'',//内容质检标准答案
        scoringRules:'',//内容质检评分规则
        contentParam: [
            {
              content: '',//设置话术
              ivsQaSpeechCrafts:[],//相似话术
              isAppear: '1',//出现or不出现
              addsub:'1',//加分减分
              score: '',//分数
            },
          ],//内容质检参数
        domainsParamsQing: {
          domains: [
            {
              increaseDeduction: '1',
              silenceTimeMin: '',
              silenceTimeMax: '',
              score: '',
            },
          ],
        },
        chongDomains: {
          domains: [
            {
              increaseDeduction: '1',
              silenceTimeMin: '',
              silenceTimeMax: '',
              score: '',
            },
          ],
        },
        jingDomains: {
          domains: [
            {
              increaseDeduction: '1',
              silenceTimeMin: '',
              silenceTimeMax: '',
              score: '',
            },
          ],
        },
        domainsParamsYu: {
          domains: [{ minWord: '', maxWord: '', score: '', increaseDeduction: '1' }],
        },
        domainsTags: {
          domains: [
              {
                  add: false,
                  labelName: '',
                  labelId: '',
              },
          ],

      },
        xuanDomains: {
          domains: [{ optionTexts: '' }],
        },
        correctNumber:'', // 满足任意
        isSet:false, // 是否同步建立
        setLabelName:'',
        increaseDeduction: 1,
        status: 1,
        score: '',
        wordSpeedType: 1,
        judge: 1,
        normalName: '',
        normalContent: '',
        keywordContext: '',
        defaultScore: '',
        minScoreRange: '',
        maxScoreRange: '',
        modleType: 7,
        silenceTimeMin: '',
        silenceTimeMax: '',
        mingScore: 0,
        silenceType: 1,
        deadItem: 2,
        scoreType: 1,
        timeMax: '',
        sceneTime: '',
        sceneType: 1,
        sceneValue: '',
        sceneValueType: 1,
        increaseDeductionStr: 1,
        roleType:'0',
        isAppear: '1',
        position: '3',
        offset: '',
        timeMin: '',
        tags: [],
      },
      chongDieRole: '0',
      yuSuRole: '0',
      jMRoleBefore: '0',
      jMRoleAfter: '0',
      roleOptions: [
        {
          value: '0',
          label: '全部角色',
        },
        {
          value: '1',
          label: '客服',
        },
        {
          value: '2',
          label: '客户',
        },
      ],
      labelPosition: 'right',
      treeid: '',
      clist: [],
      editTreeModal: false,
      pid: '',
      pidMan: '',
      normalId: '',
      editModalTable: false,
      editTitle: '修改模板',
      previewModel: false,
      isBatch: false,
      normalIds: '',
      norNameList: '',
      selectionNums: 0,
      norNameListMan: '',
      selectionNumsMan: 0,
      handleIconModel: false,
      lookModalTable: false,
      lookStandardForm: {
        judge: '',
        normalName: '',
        normalContent: '',
        defaultScore: '1',
        minScoreRange: '',
        maxScoreRange: '',
        modleType: 7,
        silenceTimeMin: '',
        silenceTimeMax: '',
        score: '',
      },
      typeIdMan: '',
      cListMan: [],
      score: ['1', '2'],
      typeid: '',
      judge: '1',
      slienceType: '1',
      roleType: '0',
      silenceTimeMin: [],
      silenceTimeMax: [],
      increaseDeduction: [],
      silenceTimeMinEdit: [],
      silenceTimeMaxEdit: [],
      judgeAuto: 1,
      silenceIds: [],
      minWordList: [],
      maxWordList: [],
      yuScore: [],
      editJudge: '1',
      qaWordspeedIds: [],
      editMaxWord: [],
      editMinWord: [],
      editScore: [],
      myTitle: '新增标准',
      qingxuJudge: '1',
      silenceTimeMinChong: [],
      silenceTimeMaxChong: [],
      scoreChong: [],
      silenceIdsChong: [],
      silenceTimeMinChongAdd: [],
      silenceTimeMaxChongAdd: [],
      scoreChongAdd: [],
      addEditJudge: 1,
      silenceTimeMinQing: [],
      silenceTimeMaxQing: [],
      scoreQing: [],
      incDedQing: [],
      juid: 1,
      silenceIdsQing: [],
      scoreJing: [],
      silenceTimeMaxJing: [],
      silenceTimeMinJing: [],
      optionTextsList: [],
      artificialJudge: 6,
      parentid: '',
      parentIdAuto: '',
      trees: [],
      totalScores: '',
      editClassId: 0,
      MinValue: 0,
      MaxValue: 0,
      items: [
        {
          id: Date.now(),
          keyWordData: {
            offset: '',
            sceneTime: '',
            position: '0',
            isAppear: 1,
            keywordContext: '',
            errKeywordContext:'',//存储标红keywordContext
            roleType: 0,
            silenceTimeMax:'',
          },
        },
      ],
      errorKeywordContext:true,
      mingzhongTip:'此标准为致命项标准，命中则总分为 0',
      hoverTip:
        '<h4>1、AND</h4><p>与："腾讯 AND 网站"，同时包含"腾讯"和"网站"的录音是目标录音。</p><h4>2、OR</h4><p>或："腾讯 OR 网站"，包含"腾讯" 或者"网站" 的录音，是目标录音。</p><h4>3、NEAR</h4><p>近："腾讯 NEAR 网站"，同时包含"腾讯"，"网站"，并且二者相隔的词不超过5个词的录音，是目标录音。</p><h4>4、BEFORE</h4><p>前："腾讯 BEFORE 网站"，同时包含"腾讯"，"网站"，并且"腾讯"在"网站" 之前，二者相隔的词不超过5个词的录音，是目标录音。</p><h4>5、AFTER</h4><p>后："腾讯 AFTER 网站"，同时包含"腾讯"，"网站"，并且"腾讯" 在"网站" 之后，二者相隔的词不超过5个词的录音，是目标录音。"</p>',
      intentionList:[],//意图集合
    }
  },
  created() {
    this.updateTime_sub = this.updateTime
  },
  methods: {
    // 内容质检check是否更改或删除,父组件调用
    initCheckFaq(){
      if(!this.faqArr){
        return
      }
      let params ={
        keyWordJson:JSON.stringify(this.faqArr)
      }
      this.axios.post(manalScore+'/manualQualityAssurance/getCheckFaq.do',Qs.stringify(params))
        .then((res)=>{
          let {flag,msg,data} = res.data
          let err = data || msg
          if(!flag){
            this.$message.error(err)
          }
        })
        .catch((err)=>console.log(err))
    },
    // 检查是否存在特殊字符
    hasUnregularWord(val) {
      const reg=/[`~!@#$%^&*()_\-+=<>?:{}|,.\/;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”【】、；‘’，。、]/g
      return reg.test(val)
    },
    formatJudge(val){
      let j = val.judge
      switch (j){
        case 1:
          return '情绪'
        case 2:
          return '重叠次数'
        case 3:
          return '静默'
        case 4:
          return '语速'
        case 5:
          return '关键词'
        case 11:
          return '标签'
        case 6:
          return '自定义输入'
        case 7:
          return '自定义选项'
        case 8:
          return '自定义致命项'
        case 12:
          return '上下文质检'
        case 13:
          return '内容质检'
      }
    },
    filter() {
      this.$emit('filterButton')
    },
    // 关键词规范检查
    changeKeywordContext(e,index){
      let word = e.target.value
      let params={
        KeywordContext:word
      }
      this.errorKeywordContext = true
      this.axios.post(manalScore+'/manualQualityAssurance/checkKeyword.do',Qs.stringify(params))
      .then((res)=>{
        let {Data,msg,type} = res.data
        if(!Data){
          if(type==3){
            let newW = word.trim().split(' ')
            let html = ''
            let arr = newW
            newW.forEach((itm,itx)=>{
              if(itm==''){
                arr[itx-1]=`<span style="color:red">${arr[itx-1]}</span>`
                arr[itx+1]=`<span style="color:red">${arr[itx+1]}</span>`
              }
            })
            arr.forEach((itm)=>{
              html+=itm + ' '
            })
            this.$set(this.items[index].keyWordData,'errKeywordContext',html)
          }
          this.$message.error(msg)
          e.target.focus()
          this.errorKeywordContext = true
        }else{
          this.$set(this.items[index].keyWordData,'errKeywordContext','')
          this.errorKeywordContext = false
        }
      })
      .catch((err)=>console.log(err))
    },
    getKeywordScore(rules,judge) {
      const {roleOptions,positionOptions,positionOptionsText} = global
      const { increaseDeduction, score , isAppear, deadItem, offset, position, roleType, sceneTime, silenceTimeMax} = rules
      let str = ''
      if (deadItem !== '1'){
        let offsetValue = judge===5 && position!=0 ?`${offset} 句`:''
        judge===5?str = ` 在 ${roleOptions[roleType]}侧 在 ${positionOptionsText[position]} ${offsetValue} ${isAppear== '1' ? '出现' : '未出现'}${increaseDeduction == '2' ? '减' : '加'}${score}分`:str = ` 在${roleOptions[roleType]}侧 在静默时间大于 ${silenceTimeMax} 秒 ${positionOptions[position]} ${sceneTime} 句 ${isAppear== '1' ? '出现' : '未出现'}${increaseDeduction == '2' ? '减' : '加'}${score}分`
      }
      return str
    },
    // 设置基准分
    setBaseScore: function(val) {
      let data = val.target.value
      if (!data) {
        data = this.copyBaseScore
        this.baseScore = this.copyBaseScore
      }
      let params = {
        score: data,
        moduleId: this.modleIdNew,
      }
      this.axios
        .post(manalScore + '/qaDetail/setBaseScore.do', Qs.stringify(params))
        .then((res) => {
          if (res.data.flag) {
            this.$message({
              type: 'success',
              message: '设置分数成功',
            })
          } else {
            this.$message({
              type: 'error',
              message: '设置分数失败',
            })
          }
        })
        .catch(function(e) {
          console.log(e)
        })
    },
    descInput: function() {
      let txtVal = this.addForm.keywordContext.length
      this.remnant = 500 - txtVal
    },
    addManualAuto: function(val) {
      let _this = this
      this.judgeAuto = 1;
      _this.treeid = val
      _this.showDisabled = false
      _this.mingScoreDisabled = false
      _this.dialogFormVisible = true
      _this.getIntends ()
      _this.$refs.addForm && _this.$refs.addForm.resetFields(); // 第一次ref为空
      this.addForm.domainsParamsQing = {
        domains: [
          {
            increaseDeduction: '1',
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.addForm.chongDomains = {
        domains: [
          {
            increaseDeduction: '1',
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.addForm.jingDomains= {
        domains: [
          {
            increaseDeduction: '1',
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.addForm.domainsParamsYu= {
        domains: [{ minWord: '', maxWord: '', score: '', increaseDeduction: '1' }],
      }
      this.addForm.domainsTags = {
        domains: [
          {
            add: false,
            labelName: '',
            labelId: '',
          },
        ],
      }
      this.addForm.xuanDomains = {
        domains: [{ optionTexts: '' }],
      }
      this.addForm.contentParam = [
        {
          content: '',//设置话术
          ivsQaSpeechCrafts:[],//相似话术
          scoringRules: '',//评分规则
          isAppear: '1',//出现or不出现
          addsub:'1',//加分减分
          score: '',//分数
        }
      ]
      _this.handleResetKey()
      _this.myTitle = '新增标准'
    },
    /**
     * 自动打分 添加标准
     * **/
    addTableYesThrottle() {
      this.lodashThrottle.throttle(this.addTableYes, this)
    },
    // 保存
    addTableYes: function() {
      let _this = this
      let adJudge = this.addForm.judge
      let normalId = this.myTitle === '修改标准'?this.normalId:''
        // 新增编辑保存
        if (adJudge == 1) {
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCountK = _this.addForm.domainsParamsQing.domains.length
              let domainsK = _this.addForm.domainsParamsQing.domains
              for (let k = 0; k < domainsCountK; k++) {
                let min = domainsK[k].silenceTimeMin
                let max = domainsK[k].silenceTimeMax
                let score = domainsK[k].score
                let increaseDeduction = domainsK[k].increaseDeduction
                if (!increaseDeduction) {
                  _this.$message({
                    type: 'error',
                    message: '请选择增扣分方式',
                  })
                  return
                }
                // 循环判断silenceTimeMax要大于silenceTimeMin
                if (min === '' || max === '' || score === '') {
                  _this.$message({
                    type: 'error',
                    message: '请输入合法的分值',
                  })
                  return
                } else {
                  if (isNaN(min) || isNaN(max) || isNaN(score)) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      _this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                  }
                }
              }
              let dlist = _this.addForm.domainsParamsQing.domains
              let dscore = []
              for (let i = 0; i < dlist.length; i++) {
                dscore[i] = dlist[i].score
              }
              _this.score = dscore

              let sMinList = []
              let incDedArr = []
              for (let i = 0; i < dlist.length; i++) {
                incDedArr[i] = dlist[i].increaseDeduction
              }
              _this.increaseDeduction = incDedArr
              for (let i = 0; i < dlist.length; i++) {
                sMinList[i] = dlist[i].silenceTimeMin
              }
              _this.silenceTimeMin = sMinList

              let sMaxList = []
              for (let i = 0; i < dlist.length; i++) {
                sMaxList[i] = dlist[i].silenceTimeMax
              }
              _this.silenceTimeMax = sMaxList
              let params = {
                normalId:normalId,
                normalName: _this.addForm.normalName,
                scoreString: _this.score.toString(),
                defaultScore: _this.addForm.defaultScore,
                judge: _this.addForm.judge,
                silenceTimeMinString: _this.silenceTimeMin.toString(),
                silenceTimeMaxString: _this.silenceTimeMax.toString(),
                increaseDeductionString: _this.increaseDeduction.toString(),
                modelId: _this.modleIdNew,
                classId: _this.treeid,
                overLapRole: _this.chongDieRole,
                speedRole: _this.yuSuRole,
                silenceBeforeRole: _this.jMRoleBefore,
                silenceAfterRole: _this.jMRoleAfter,
              }
              this.axios
                .post(
                  manalScore + '/manualQualityAssurance/operateSilence.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.flag == true) {
                    _this.$message({
                      type: 'success',
                      message: '添加成功',
                    })
                    _this.updateTime_sub = res.data.updateTime
                    _this.myTitle = '新增标准'
                    _this.$refs.addForm.resetFields()
                    _this.dialogFormVisible = false
                    _this.getScore()
                    _this.getTemplateData()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            } else {
              console.log('error submit!!')
              return false
            }
          })
        } else if (adJudge === 2) {
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          let dlist = _this.addForm.chongDomains.domains
          let dscore = []
          for (let i = 0; i < dlist.length; i++) {
            dscore[i] = dlist[i].score
          }
          _this.score = dscore
          let incDedArr = []
          for (let i = 0; i < dlist.length; i++) {
            incDedArr[i] = dlist[i].increaseDeduction
          }
          _this.increaseDeduction = incDedArr
          let sMinList = []
          for (let i = 0; i < dlist.length; i++) {
            sMinList[i] = dlist[i].silenceTimeMin
          }
          _this.silenceTimeMin = sMinList

          let sMaxList = []
          for (let i = 0; i < dlist.length; i++) {
            sMaxList[i] = dlist[i].silenceTimeMax
          }
          _this.silenceTimeMax = sMaxList
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCountK = _this.addForm.chongDomains.domains.length
              let domainsK = _this.addForm.chongDomains.domains
              for (let k = 0; k < domainsCountK; k++) {
                let min = domainsK[k].silenceTimeMin
                let max = domainsK[k].silenceTimeMax
                let score = domainsK[k].score
                let increaseDeduction = domainsK[k].increaseDeduction
                if (!increaseDeduction) {
                  _this.$message({
                    type: 'error',
                    message: '请选择增扣分方式',
                  })
                  return
                }
                // 循环判断silenceTimeMax要大于silenceTimeMin
                if (min === '' || max === '' || score === '') {
                  _this.$message({
                    type: 'error',
                    message: '请输入合法的分值',
                  })
                  return
                } else {
                  if (isNaN(min) || isNaN(max) || isNaN(score)) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      _this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                  }
                }
              }
              let params = {
                normalId:normalId,
                normalName: _this.addForm.normalName,
                judge: _this.addForm.judge,
                defaultScore: _this.addForm.defaultScore,
                silenceTimeMinString: _this.silenceTimeMin.toString(),
                silenceTimeMaxString: _this.silenceTimeMax.toString(),
                scoreString: _this.score.toString(),
                increaseDeductionString: _this.increaseDeduction.toString(),
                modelId: _this.modleIdNew,
                classId: _this.treeid,
                overLapRole: _this.chongDieRole,
                speedRole: _this.yuSuRole,
                silenceBeforeRole: _this.jMRoleBefore,
                silenceAfterRole: _this.jMRoleAfter,
              }
              this.axios
                .post(
                  manalScore + '/manualQualityAssurance/operateSilence.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.flag == true) {
                    _this.$message({
                      type: 'success',
                      message: '添加成功',
                    })
                    _this.updateTime_sub = res.data.updateTime
                    _this.myTitle = '新增标准'
                    _this.$refs.addForm.resetFields()
                    _this.dialogFormVisible = false
                    _this.getScore()
                    _this.getTemplateData()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            } else {
              console.log('error submit!!')
              return false
            }
          })
        } else if (adJudge === 3) {
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let keywordRules = []
              let isWrong = false
              let wrongMessage = ''
              if(_this.slienceType!=5){
                let domainsCountK = _this.addForm.jingDomains.domains.length
                let domainsK = _this.addForm.jingDomains.domains
                for (let k = 0; k < domainsCountK; k++) {
                  let min = domainsK[k].silenceTimeMin
                  let max = domainsK[k].silenceTimeMax
                  let increaseDeduction = domainsK[k].increaseDeduction
                  if (!increaseDeduction) {
                    _this.$message({
                      type: 'error',
                      message: '请选择增扣分方式',
                    })
                    return
                  }
                  let score = domainsK[k].score
                  // 循环判断silenceTimeMax要大于silenceTimeMin
                  if (min === '' || max === '' || score === '') {
                    _this.$message({
                      type: 'error',
                      message: '请输入合法的分值',
                    })
                    return
                  } else {
                    if (isNaN(min) || isNaN(max) || isNaN(score)) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为数字',
                      })
                      return
                    } else {
                      if (
                        !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                        !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                        !(Math.ceil(parseInt(score)) == parseInt(score))
                      ) {
                        _this.$message({
                          type: 'error',
                          message: '分值应为整数',
                        })
                        return
                      }
                      if (Math.ceil(min) > Math.ceil(max)) {
                        _this.$message({
                          type: 'error',
                          message: '最大值应大于最小值',
                        })
                        return
                      }
                    }
                  }
                }

                let dlist = _this.addForm.jingDomains.domains
                let dscore = []
                for (let i = 0; i < dlist.length; i++) {
                  dscore[i] = dlist[i].score
                }
                _this.scoreJing = dscore
                let incDedArr = []
                for (let i = 0; i < dlist.length; i++) {
                  incDedArr[i] = dlist[i].increaseDeduction
                }
                _this.increaseDeduction = incDedArr
                let sMinList = []
                for (let i = 0; i < dlist.length; i++) {
                  sMinList[i] = dlist[i].silenceTimeMin
                }
                _this.silenceTimeMinJing = sMinList

                let sMaxList = []
                for (let i = 0; i < dlist.length; i++) {
                  sMaxList[i] = dlist[i].silenceTimeMax
                }
                _this.silenceTimeMaxJing = sMaxList
              }else{
                let score = _this.addForm.mingScore
                let correctNumber = _this.addForm.correctNumber
                _this.items.forEach((item) => {
                  keywordRules.push(item.keyWordData)
                })
                keywordRules.forEach((item)=>{
                  if(!item.silenceTimeMax || !item.sceneTime){
                    isWrong = true
                    wrongMessage = '请填写范围'
                  }
                  if(!item.keywordContext){
                    isWrong = true
                    wrongMessage = '请填写关键词'
                  } else if (item.keywordContext.length > 4000) {
                    isWrong = true
                    wrongMessage = '关键词规则长度超过限制'
                  }
                })
                if (isWrong) {
                  this.$message.warning(wrongMessage)
                  isWrong = false
                  wrongMessage = ''
                  return
                }
                if (correctNumber === '' || correctNumber==0 || correctNumber>keywordRules.length) {
                  _this.$message({
                    type: 'error',
                    message: '请输入合理的满足个数',
                  })
                  return
                }
                if (score === '') {
                  _this.$message({
                    type: 'error',
                    message: '请输入命中分数',
                  })
                  return
                }
              }
              if(!isWrong){
                let slienceTypeVal = _this.slienceType
                let params = {
                  normalId:normalId,
                  normalName: _this.addForm.normalName,
                  slienceType: _this.slienceType,
                  judge: _this.addForm.judge,
                  defaultScore: _this.addForm.defaultScore,
                  silenceTimeMinString: _this.silenceTimeMinJing.toString(),
                  silenceTimeMaxString: _this.silenceTimeMaxJing.toString(),
                  scoreString: slienceTypeVal!=5?_this.scoreJing.toString():_this.addForm.mingScore,
                  increaseDeductionString: slienceTypeVal!=5?_this.increaseDeduction.toString():_this.addForm.increaseDeduction,
                  modelId: _this.modleIdNew,
                  classId: _this.treeid,
                  overLapRole: _this.chongDieRole,
                  speedRole: _this.yuSuRole,
                  silenceBeforeRole: _this.jMRoleBefore,
                  silenceAfterRole: _this.jMRoleAfter,
                  matchCount:_this.addForm.correctNumber,
                  slienceJson:JSON.stringify(keywordRules)
                }
                this.axios
                  .post(
                      manalScore + '/manualQualityAssurance/operateSilence.do',
                      Qs.stringify(params)
                  )
                  .then((res) => {
                    if (res.data.flag == true) {
                      _this.$message({
                        type: 'success',
                        message: '添加成功',
                      })
                      _this.updateTime_sub = res.data.updateTime
                      _this.myTitle = '新增标准'
                      _this.$refs.addForm.resetFields()
                      _this.dialogFormVisible = false
                      _this.getScore()
                      _this.getTemplateData()
                    } else {
                      _this.$message({
                        type: 'error',
                        message: res.data.message,
                      })
                    }
                  })
                  .catch(function(error) {
                    console.log(error)
                  })
              }
            } else {
              console.log('error submit!!')
              return false
            }
          })
        } else if (adJudge === 4) {
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            let domainsCountK = _this.addForm.domainsParamsYu.domains.length
            let domainsK = _this.addForm.domainsParamsYu.domains
            for (let k = 0; k < domainsCountK; k++) {
              let min = domainsK[k].minWord
              let max = domainsK[k].maxWord
              let increaseDeduction = domainsK[k].increaseDeduction
              if (!increaseDeduction) {
                _this.$message({
                  type: 'error',
                  message: '请选择增扣分方式',
                })
                return
              }
              let score = domainsK[k].score
              // 循环判断silenceTimeMax要大于silenceTimeMin
              if (min === '' || max === '' || score === '') {
                _this.$message({
                  type: 'error',
                  message: '请输入合法的分值',
                })
                return
              } else {
                if (isNaN(min) || isNaN(max) || isNaN(score)) {
                  _this.$message({
                    type: 'error',
                    message: '分值应为数字',
                  })
                  return
                } else {
                  if (
                    !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                    !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                    !(Math.ceil(parseInt(score)) == parseInt(score))
                  ) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为整数',
                    })
                    return
                  }
                  if (Math.ceil(min) > Math.ceil(max)) {
                    _this.$message({
                      type: 'error',
                      message: '最大值应大于最小值',
                    })
                    return
                  }
                }
              }
            }

            let yuList = _this.addForm.domainsParamsYu.domains
            let yuOne = []
            for (let i = 0; i < yuList.length; i++) {
              yuOne[i] = yuList[i].score
            }
            _this.yuScore = yuOne
            let incDedArr = []
            for (let i = 0; i < yuList.length; i++) {
              incDedArr[i] = yuList[i].increaseDeduction
            }
            _this.increaseDeduction = incDedArr
            let yuMin = []
            for (let i = 0; i < yuList.length; i++) {
              yuMin[i] = yuList[i].minWord
            }
            _this.minWordList = yuMin

            let yuMax = []
            for (let i = 0; i < yuList.length; i++) {
              yuMax[i] = yuList[i].maxWord
            }
            _this.maxWordList = yuMax
            let params = {
              normalId:normalId,
              normalName: _this.addForm.normalName,
              judge: _this.addForm.judge,
              defaultScore: _this.addForm.defaultScore,
              wordSpeedType: _this.addForm.wordSpeedType,
              minWordString: _this.minWordList.toString(),
              maxWordString: _this.maxWordList.toString(),
              scoreString: _this.yuScore.toString(),
              increaseDeductionString: _this.increaseDeduction.toString(),
              modelId: _this.modleIdNew,
              classId: _this.treeid,
              overLapRole: _this.chongDieRole,
              speedRole: _this.yuSuRole,
              silenceBeforeRole: _this.jMRoleBefore,
              silenceAfterRole: _this.jMRoleAfter,
            }
            this.axios
              .post(
                manalScore + '/manualQualityAssurance/operateWordspeed.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data.flag == true) {
                  _this.$message({
                    type: 'success',
                    message: '添加成功',
                  })
                  _this.updateTime_sub = res.data.updateTime
                  _this.getScore()
                  _this.myTitle = '新增标准'
                  _this.$refs.addForm.resetFields()
                  _this.dialogFormVisible = false
                  _this.getTemplateData()
                } else {
                  _this.$message({
                    type: 'error',
                    message: res.data.message,
                  })
                }
              })
              .catch(function(error) {
                console.log(error)
              })
          })
        }  else if(adJudge === 12){
          //上下文质检
          _this.$refs.addForm.validate((valid) => {
            if(valid){
              _this.$refs.contextData.validate((vld)=>{
                if(vld){
                  let params = {
                    modelId:_this.modleIdNew,
                    classId:_this.treeid,
                    judge:_this.addForm.judge,
                    normalId:normalId,
                    normalName:this.addForm.normalName,
                    sentenceDeadItem:this.contextData.sentenceDeadItem,
                    sentenceCount:this.contextData.sentenceCount,
                    isAppear:this.contextData.isAppear,
                    increaseDeduction:this.contextData.increaseDeduction,
                    score:this.contextData.score,
                    firstContext:this.contextData.firstContext,
                    secondContext:this.contextData.secondContext,
                    firstRoleType:this.contextData.firstRoleType,
                    secondRoleType:this.contextData.secondRoleType,
                  }
                  this.axios
                    .post(
                      manalScore + '/manualQualityAssurance/operateContext.do',
                      Qs.stringify(params)
                    )
                    .then((res) => {
                      let {flag,updateTime} = res.data
                      if (flag == true) {
                        _this.$message({
                          type: 'success',
                          message: '添加成功',
                        })
                        _this.updateTime_sub = updateTime
                        _this.getScore()
                        _this.myTitle = '新增标准'
                        _this.$refs.addForm.resetFields()
                        _this.$refs.contextData.resetFields()
                        _this.dialogFormVisible = false
                        _this.getTemplateData()
                      } else {
                        _this.$message({
                          type: 'error',
                          message: res.data.message,
                        })
                      }
                    })
                    .catch(function(error) {
                      console.log(error)
                    })
                }
              })
            }
          })
        } else if(adJudge === 13){
          //内容质检
          if (this.addForm.contentParam.some(item => this.hasUnregularWord(item.content))) {
            this.$message.error('话术禁止输入特殊字符')
            return
          }
          _this.judgeFaqChange().then((err)=>{
            if(err){
              this.$message.error(err)
              return
            }
            _this.$refs.addForm.validate((valid) => {
              if(valid){
                // 判断是否为重复话术
                let err = this.checkRepeat()
                if(!err){
                  this.$message.error('请不要输入重复的话术或相似话术')
                  return;
                }
                if(!this.addForm.contentIntent){
                  this.$message.error('请选择意图')
                  return
                }
                if(!this.addForm.scoringRules){
                  this.$message.error('请填写评分规则')
                  return
                }
                let wrong = this.addForm.contentParam.find((item)=>{return !item.content||(!item.score&&item.score!=0)})
                if(wrong){
                  this.$message.error('请将内容项填写完整')
                  return;
                }
                // 后台检查设置话术重复
                _this.checkWordRepeat().then((wordErr)=>{
                  if(wordErr){
                    this.$message.error(wordErr)
                    return;
                  }
                  let keyWordJsonData = []
                  if(normalId){
                    this.addForm.contentParam.forEach((itm)=>{
                      let curCrafts = []
                      itm.ivsQaSpeechCrafts=itm.ivsQaSpeechCrafts?itm.ivsQaSpeechCrafts:[]
                      itm.ivsQaSpeechCrafts.forEach((i)=>{
                        if(i.speechcraftId){
                          curCrafts.push({
                            speechcraftId:i.speechcraftId,
                            speechcraftContent:i.speechcraftContent,
                            classSamplesId:i.classSamplesId,
                          })
                        }else{
                          curCrafts.push({speechcraftContent:i.speechcraftContent})
                        }
                      })
                      keyWordJsonData.push({
                        contentId:itm.contentId,
                        content:itm.content,
                        isAppear:itm.isAppear,
                        addsub:itm.addsub,
                        score:itm.score,
                        classifyId:itm.classifyId,
                        classSamplesId:itm.classSamplesId,
                        ivsQaSpeechCrafts:curCrafts,
                      })
                    })
                  }
                  console.log(keyWordJsonData)
                  let params = {
                    modelId:_this.modleIdNew,
                    classId:_this.treeid,
                    judge:_this.addForm.judge,
                    normalId:normalId,
                    normalName:_this.addForm.normalName,
                    faqId:_this.intendsData.faqId,
                    faqContent:_this.intendsData.faqContent,
                    answer:_this.intendsData.answer,
                    answerId:_this.intendsData.answerId,
                    customerIntention:_this.intendsData.customerIntention,
                    faqUpdateTime:_this.intendsData.faqUpdateTime,
                    scoringRules:_this.addForm.scoringRules,
                    keyWordJson:normalId?JSON.stringify(keyWordJsonData):JSON.stringify(this.addForm.contentParam),
                  }
                  this.axios
                    .post(
                      manalScore + '/manualQualityAssurance/operateContentQa.do',
                      Qs.stringify(params)
                    )
                    .then((res) => {
                      let {flag,updateTime} = res.data
                      if (flag == true) {
                        _this.$message({
                          type: 'success',
                          message: '添加成功',
                        })
                        _this.updateTime_sub = updateTime
                        _this.getScore()
                        _this.myTitle = '新增标准'
                        _this.$refs.addForm.resetFields()
                        _this.dialogFormVisible = false
                        _this.getTemplateData()
                      } else {
                        _this.$message({
                          type: 'error',
                          message: res.data.message,
                        })
                      }
                    })
                    .catch(function(error) {
                      console.log(error)
                    })
                })
              }
            })
          })
        }else if (adJudge === 5){
          _this.$refs.addForm.validate((valid) => {
            if (!valid) {
              return
            }else{
              let score = _this.addForm.mingScore
              let isSet = _this.addForm.isSet
              let setLabelName = _this.addForm.setLabelName
              let correctNumber = _this.addForm.correctNumber
              let keywordRules = []
              let isWrong = false
              let wrongMessage = ''
              _this.items.forEach((item) => {
                keywordRules.push(item.keyWordData)
              })
              keywordRules.forEach((item)=>{
                if(item.position!=0 && !item.offset){
                  isWrong = true
                  wrongMessage = '请填写范围'
                }
                if(!item.keywordContext){
                  isWrong = true
                  wrongMessage = '请填写关键词'
                } else if (item.keywordContext.length > 4000) {
                  isWrong = true
                  wrongMessage = '关键词规则长度超过限制'
                }
              })
              if (isWrong) {
                _this.$message.warning(wrongMessage)
                isWrong = false
                wrongMessage = ''
                return
              }
              if (correctNumber === '' || correctNumber==0 || correctNumber>keywordRules.length) {
                _this.$message({
                  type: 'error',
                  message: '请输入合理的满足个数',
                })
                return
              }
              if (isSet && !setLabelName) {
                _this.$message({
                  type: 'error',
                  message: '请输入同步标签名称',
                })
                return
              }
              if (score === '') {
                _this.$message({
                  type: 'error',
                  message: '请输入命中分数',
                })
                return
              }
              if(!isWrong){
                // 关键词
                let paramsGuan = {
                  normalId:normalId,
                  modelId: _this.modleIdNew,
                  classId: _this.treeid,
                  defaultScore: _this.addForm.defaultScore,
                  judge: _this.addForm.judge,
                  normalName: _this.addForm.normalName,
                  deadItem: _this.addForm.deadItem,
                  score: _this.addForm.mingScore,
                  increaseDeduction: _this.addForm.increaseDeduction,
                  matchCount:_this.addForm.correctNumber,
                  isSet:_this.addForm.isSet===false?'0':'1',
                  labelName:_this.addForm.setLabelName,
                  keyWordJson:JSON.stringify(keywordRules),
                }
                _this.axios
                  .post(manalScore + '/manualQualityAssurance/operateKeyword.do', Qs.stringify(paramsGuan))
                  .then((res) => {
                    if (res.data.flag == true) {
                      _this.$message({
                        type: 'success',
                        message: '添加成功',
                      })
                      _this.updateTime_sub = res.data.updateTime
                      _this.myTitle = '新增标准'
                      _this.$refs.addForm.resetFields()
                      _this.handleResetKey()
                      _this.dialogFormVisible = false
                      _this.getScore()
                      _this.getTemplateData()
                    } else {
                      _this.$message({
                        type: 'error',
                        message: res.data.message,
                      })
                    }
                  })
                  .catch(function(error) {
                    console.log(error)
                  })
              }
            }
          })
        } else if(adJudge === 11){
          // 标签
          this.tagSubmitAddEdit();
        }else {
          this.$refs.addForm.validate((valid) => {
            if (!valid) return
            this.addTableYesManAddEdit()
          })
        }
    },
    // tag保存 case11
    tagSubmitAddEdit() {
      this.$refs.addForm.validate((valid) => {
        if(valid){
          let score = this.addForm.mingScore
          let correctNumber = this.addForm.correctNumber
          let keywordRules=this.addForm.domainsTags.domains
          let keywordRulesVal = false
          keywordRules.map((item)=>{
            if (!item.labelId){
              this.$message.warning('请将标签项填写完整')
              keywordRulesVal = true
            }
          })
          if (keywordRulesVal){
            return;
          }
          if (correctNumber === '' || correctNumber==0 || correctNumber>keywordRules.length) {
            this.$message({
              type: 'error',
              message: '请输入合理的满足个数',
            })
            return
          }
          if (score === '') {
            this.$message({
              type: 'error',
              message: '请输入命中分数',
            })
            return
          }
          this.labelList.forEach((item)=>{
            for(let w=0;w<keywordRules.length;w++){
              let val = keywordRules[w]
              if(item.labelId == val.labelId){
                keywordRules[w].labelName=item.labelName
              }
            }
          })
          let params = {
            normalId:this.myTitle === '修改标准'?this.normalId:'',
            modelId: this.modleIdNew,
            classId: this.treeid,
            defaultScore: this.addForm.defaultScore,
            judge: this.addForm.judge,
            normalName: this.addForm.normalName,
            deadItem: this.addForm.deadItem,
            score: this.addForm.mingScore,
            increaseDeduction: this.addForm.increaseDeduction,
            matchCount:this.addForm.correctNumber,
            isSet:this.addForm.isSet===false?'0':'1',
            labelName:this.addForm.setLabelName,
            qaLabels:JSON.stringify(keywordRules),
          }
          this.axios
            .post(manalScore + '/manualQualityAssurance/operateLabel.do', Qs.stringify(params))
            .then((res) => {
              if (res.data.flag == true) {
                this.$message({
                  type: 'success',
                  message: '添加成功',
                })
                this.updateTime_sub = res.data.updateTime
                this.myTitle = '新增标准'
                this.$refs.addForm.resetFields()
                this.dialogFormVisible = false
                this.getScore()
                this.getTemplateData()
              } else {
                this.$message({
                  type: 'error',
                  message: res.data.message,
                })
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    // case 6 7 8 保存
    addTableYesManAddEdit: function() {
      let _this = this
        // 新增人工打分标准
        let xlist = _this.addForm.xuanDomains.domains
        let optext = []
        for (let i = 0; i < xlist.length; i++) {
          optext[i] = xlist[i].optionTexts
        }
        _this.optionTextsList = optext
        let params = {
          normalId:_this.myTitle === '修改标准'?_this.normalId:'',
          minScoreRange: _this.addForm.minScoreRange,
          maxScoreRange: _this.addForm.maxScoreRange,
          normalName: _this.addForm.normalName,
          defaultScore: _this.addForm.defaultScore,
          increaseDeduction: _this.addForm.increaseDeduction,
          normalContent: _this.addForm.normalContent,
          judge: _this.judgeAuto,
          modelId: _this.modleIdNew,
          classId: _this.treeid,
          optionTexts: _this.judgeAuto === 7 ? _this.optionTextsList : '',
        }
        if (_this.addForm.judge == 6) {
          let min = params.minScoreRange
          let max = params.maxScoreRange
          let score = params.defaultScore
          if (min === '' || max === '' || score === '') {
            this.$message({
              type: 'error',
              message: '请输入合法的分值',
            })
            return
          } else {
            if (isNaN(min) || isNaN(max) || isNaN(score)) {
              this.$message({
                type: 'error',
                message: '分值应为数字',
              })
              return
            } else {
              if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
              ) {
                this.$message({
                  type: 'error',
                  message: '分值应为整数',
                })
                return
              }
              if (Math.ceil(min) > Math.ceil(max)) {
                this.$message({
                  type: 'error',
                  message: '最大值应大于最小值',
                })
                return
              }
              if ((-999 > Math.ceil(min)||Math.ceil(min)>999) || (-999 > Math.ceil(max)||Math.ceil(max) > 999)) {
                this.$message({
                  type: 'error',
                  message: '请输入-999～999的数值',
                })
                return
              }
            }
          }
        }
        if (_this.judgeAuto === 8) {
          this.axios
                  .post(
                          manalScore + '/manualQualityAssurance/saveManNormal.do',
                          Qs.stringify(params)
                  )
                  .then(function(res) {
                    if (res.data.flag == true) {
                      _this.$message({
                        type: 'success',
                        message: '修改成功',
                      })
                      _this.updateTime_sub = res.data.updateTime
                      _this.$refs.addForm.resetFields()
                      _this.dialogFormVisible = false
                      _this.myTitle == '新增标准'
                      _this.getScore()
                      _this.getTemplateData()
                    } else {
                      _this.$message({
                        type: 'error',
                        message: res.data.message,
                      })
                    }
                  })
        } else if (_this.judgeAuto == 6) {
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              params.defaultScore = _this.addForm.defaultScore
              this.axios
                      .post(
                              manalScore + '/manualQualityAssurance/saveManNormal.do',
                              Qs.stringify(params)
                      )
                      .then((res) => {
                        if (res.data.flag == true) {
                          _this.$message({
                            type: 'success',
                            message: '新增成功',
                          })
                          _this.updateTime_sub = res.data.updateTime
                          _this.$refs.addForm.resetFields()
                          _this.dialogFormVisible = false
                          _this.myTitle == '新增标准'
                          _this.getScore()
                          _this.getTemplateData()
                        } else {
                          _this.$message({
                            type: 'error',
                            message: res.data.message,
                          })
                        }
                      })
                      .catch(function(error) {
                        console.log(error)
                      })
            }
          })
        } else if(_this.judgeAuto == 7) {
          _this.addForm.maxScoreRange = 2
          _this.addForm.minScoreRange = 1
          _this.addForm.defaultScore = 2
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCount = _this.addForm.xuanDomains.domains.length
              let domains = _this.addForm.xuanDomains.domains
              for (let i = 0; i < domainsCount; i++) {
                let optionText = domains[i].optionTexts
                // 循环判断选项不能为空
                if (optionText === '') {
                  _this.$message({
                    type: 'error',
                    message: '选项不能为空',
                  })
                  return
                } else if (
                        !isNaN(optionText) &&
                        optionText > 0 &&
                        optionText.length >= 4
                ) {
                  _this.$message({
                    type: 'error',
                    message: '选项为数字时，最大三位数',
                  })
                  return
                }
                for (let j = domainsCount - 1; j > i; j--) {
                  if (domains[i].optionTexts === domains[j].optionTexts) {
                    _this.$message({
                      type: 'error',
                      message: '选项内容不能重复',
                    })
                    return
                  }
                }
              }
              this.axios
                      .post(
                              manalScore + '/manualQualityAssurance/saveManNormal.do',
                              Qs.stringify(params)
                      )
                      .then((res) => {
                        if (res.data.flag == true) {
                          _this.$message({
                            type: 'success',
                            message: '新增成功',
                          })
                          _this.updateTime_sub = res.data.updateTime
                          _this.$refs.addForm.resetFields()
                          _this.dialogFormVisible = false
                          _this.myTitle == '新增标准'
                          _this.getScore()
                          _this.getTemplateData()
                        } else {
                          _this.$message({
                            type: 'error',
                            message: res.data.message,
                          })
                        }
                      })
                      .catch(function(error) {
                        console.log(error)
                      })
            }
          })
        }
    },
    // 重置关键词
    handleResetKey() {
      this.items = [
        {
          keyWordData: {
            offset: '',
            sceneTime: '',
            position: '0',
            isAppear: 1,
            keywordContext: '',
            errKeywordContext:'',
            roleType: 0,
            silenceTimeMax:'',
          },
        },
      ]
    },
    //在光标处插入逻辑词
    insertContent(ref, text, index) {
      index=!index?0:index
      const textInputs = ref
      let input = textInputs
      if (Array.isArray(textInputs)) {
        input = textInputs[index]
      }
      input = input.$el.querySelector('textarea')
      if (document.selection) {
        input.focus() //光标聚焦
        let sel = document.selection.createRange()
        sel.text = text
        sel.select()
      } else if (input.selectionStart || input.selectionStart == '0') {
        let startPos = input.selectionStart //得到光标前的位置
        let endPos = input.selectionEnd //得到光标后的位置
        //插入内容
        input.value =
                input.value.substring(0, startPos) +
                text +
                input.value.substring(endPos, input.value.length)

        // 同步值的内容到expression
        this.items[index].keyWordData.keywordContext = input.value

        input.focus()
        input.selectionStart = startPos + text.length
        input.selectionEnd = startPos + text.length
      } else {
        input.value += text
        // 同步值的内容到expression
        this.items[index].keyWordData.keywordContext = input.value

        input.focus()
      }
    },
    //逻辑词
    AND(index,type) {
      let text = ' AND '
      const ref = type === 'secContext'?this.$refs.textInputSec:this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    OR(index,type) {
      let text = ' OR '
      const ref = type === 'secContext'?this.$refs.textInputSec:this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    AFTER(index,type) {
      let text = ' AFTER#5 '
      const ref = type === 'secContext'?this.$refs.textInputSec:this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    BEFORE(index,type) {
      let text = ' BEFORE#5 '
      const ref = type === 'secContext'?this.$refs.textInputSec:this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    NEAR(index,type) {
      let text = ' NEAR#5 '
      const ref = type === 'secContext'?this.$refs.textInputSec:this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    CIRCLE(index,type) {
      let text = ' () '
      const ref = type === 'secContext'?this.$refs.textInputSec:this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    editNamesYesThrottle() {
      this.lodashThrottle.throttle(this.editNamesYes, this)
    },
    // 确定修改模板名称
    editNamesYes: function() {
      let that = this
      if (this.editNamesForm.modleTitle == this.mdtitle) {
        this.handleIconModel = false
      } else {
        this.$refs.editNamesForm.validate((valid) => {
          if (valid) {
            let params = {
              modleTitle: this.editNamesForm.modleTitle,
              qualityScore: this.info.qualityScore,
              status: this.info.status,
              remark: this.info.remark,
              modleType: 7,
              modelUpdateTime: this.updateTime_sub,
              updateFlag: 'true',
              modleId: this.modleIdNew,
            }
            if (params['modleTitle'].trim() === '') {
              this.$message.error('模板名称不能为空!')
              return
            }
            this.axios
              .post(
                manalScore + '/manualQualityAssurance/saveModle.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data.flag == true) {
                  this.$message({
                    type: 'success',
                    message: '数据提交成功!',
                  })
                  that.namesForm.modleTitle = this.editNamesForm.modleTitle
                  this.mdtitle = this.editNamesForm.modleTitle
                  that.handleIconModel = false
                } else {
                  this.$message({
                    type: 'error',
                    message: res.data.msg,
                  })
                }
              })
              .catch(function(error) {
                console.log(error)
              })
          }
        })
      }
    },
    // 修改模板名称
    handleIconClick() {
      this.handleIconModel = true
      this.$nextTick(() => {
        this.$refs['editNamesForm'].resetFields()
        this.editNamesForm.modleTitle = this.mdtitle
      })
    },
    // 点击预览
    preview: function() {
      let _this = this
      if (_this.modleIdNew == null || _this.modleIdNew == '') {
        _this.previewModel = false
      } else {
        _this.previewModel = true
        let params = {
          modleId: _this.modleIdNew,
        }
        this.axios
          .post(
            manalScore + '/manualQualityAssurance/yulanModleInfoScore.do',
            Qs.stringify(params)
          )
          .then((res) => {
            if (res.data != null) {
              _this.tableData = res.data.dataT
              _this.typelist = res.data.data_hand
              _this.perviewModel = res.data.modle
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    getOption: function(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        treeList[i] = {
          optionTexts: value[i],
        }
      }
      return treeList
    },
    // judge 1 2 3 4 5 11 12 13详情调用
    getJudgeInfo(params){
      this.axios
          .post(manalScore + '/manualQualityAssurance/getRulesByNormal.do', Qs.stringify(params))
          .then((res) => {
            let {Data,judge,Count,minScoreRange,maxScoreRange} = res.data
            let silenceId = []
            let autoWordspeedId = []
            switch (parseInt(params.judge)) {
              case 1:
                this.addForm.domainsParamsQing.domains = Data
                var sid = []
                for (let i = 0; i < Data.length; i++) {
                  sid[i] = Data[i].Data
                }
                // 得到
                var ssid = []
                for (let i = 0; i < Count; i++) {
                  ssid[i] = Data[i].silenceId
                }
                this.silenceIds = ssid
                break;
              case 2:
                this.qingxuJudge = judge
                this.chongDieRole = Data[0].overLapRole
                this.addForm.chongDomains.domains = Data
                // 得到
                for (let i = 0; i < Count; i++) {
                  silenceId[i] = Data[i].silenceId
                }
                this.silenceIdsChong = silenceId
                break;
              case 3:
                this.addForm.jingDomains.domains = Data
                this.addForm.correctNumber = Data[0].matchCount
                this.jMRoleBefore = Data[0].silenceBeforeRole
                this.jMRoleAfter = Data[0].silenceAfterRole
                // 得到
                this.addForm.silenceType = Data[0].silenceType
                this.slienceType=Data[0].silenceType
                for (let i = 0; i < Count; i++) {
                  silenceId[i] = Data[i].silenceId
                }
                this.silenceIds = silenceId
                if(Data[0].silenceType==5){
                  if (Array.isArray(Data)) {
                    this.items = Data.map((item) => ({
                      ...item,
                      keyWordData: item,
                    }))
                  }
                }
                for (var i = 0; i < this.items.length; i++) {
                  let item = this.items[i].keyWordData
                  this.$set(item,'roleType',parseInt(item.roleType))
                  this.$set(item,'isAppear',parseInt(item.isAppear))
                }
                break;
              case 4:
                this.addForm.domainsParamsYu.domains = Data
                this.yuSuRole = Data[0].speedRole
                this.addForm.wordSpeedType = parseInt(Data[0].wordSpeedType)
                // 得到
                for (let i = 0; i < Count; i++) {
                  autoWordspeedId[i] = Data[i].autoWordspeedId
                }
                this.qaWordspeedIds = autoWordspeedId
                break;
              case 5:
                this.addForm.minScoreRange = minScoreRange
                this.addForm.maxScoreRange = maxScoreRange
                this.addForm.mingScore = Data[0].score
                this.addForm.deadItem = parseInt(Data[0].deadItem)
                this.addForm.isAppear = Data[0].isAppear + ''
                this.addForm.increaseDeduction = parseInt(Data[0].increaseDeduction)
                this.addForm.correctNumber = Data[0].matchCount
                this.addForm.setLabelName = ''
                if (this.addForm.deadItem == '1') {
                  this.mingScoreDisabled = true
                }
                if (Array.isArray(Data)) {
                  this.items = Data.map((item) => ({
                    ...item,
                    keyWordData: item,
                  }))
                }
                for (var j = 0; j < this.items.length; j++) {
                  let item = this.items[i].keyWordData
                  this.$set(item,'roleType',parseInt(item.roleType))
                  this.$set(item,'isAppear',parseInt(item.isAppear))
                }
                break;
              case 11:
                this.addForm.domainsTags.domains = []
                this.addForm.correctNumber = Data[0].matchCount
                this.addForm.increaseDeduction = parseInt(Data[0].increaseDeduction)
                this.addForm.mingScore = Data[0].score
                this.addForm.deadItem = parseInt(Data[0].deadItem)
                this.changeDeadItem(this.addForm.deadItem)
                if(Array.isArray(Data)){
                  Data.map((item)=>{
                    this.addForm.domainsTags.domains.push({
                      labelId: item.labelId,
                      labelName: item.labelName,
                    })
                  })
                }
                break;
              case 12:
                this.contextData = Data&&Data[0]
                break;
              case 13:
                var {ivsQaContentList,scoringRules,faqId,answer,faqContent,answerId,customerIntention,faqUpdateTime} = Data
                this.addForm.scoringRules = scoringRules
                this.addForm.contentIntent = this.intentionList.findIndex((itm)=>{return itm.faqId===faqId})>-1?faqId:''
                this.intendsData.faqId = this.addForm.contentIntent
                if(this.addForm.contentIntent&&answer){
                  let str = ''
                  let arr = answer.split(',')
                  arr.forEach((item,index)=>{
                    if(!item){return}
                    index = index + 1
                    str  +='<p>'+index+' '+item+'</p>'
                  })
                  this.addForm.contentAnswer = str
                  this.intendsData.answer = answer
                  this.intendsData.faqContent = faqContent
                  this.intendsData.answerId = answerId
                  this.intendsData.customerIntention = customerIntention
                }else{
                  this.addForm.contentAnswer = ''
                  this.intendsData.answer = ''
                  this.intendsData.faqContent = ''
                  this.intendsData.answerId = ''
                  this.intendsData.customerIntention = ''
                }
                this.intendsData.faqUpdateTime = faqUpdateTime
                if(this.addForm.contentIntent){
                  this.changeIntents(this.intendsData.faqId)
                }
                this.addForm.contentParam = ivsQaContentList ? ivsQaContentList : []
                break;
              default:break
            }
          })
          .catch(function(error) {
            console.log(error)
          })
    },
    // 点击编辑标准
    editNormalInfo: function(normalId, classId, val) {
      let norid = normalId
      this.normalId = normalId
      this.treeid = classId
      let that = this
      this.dialogFormVisible = true
      this.getIntends ()
      if (val == 1) {
        that.myTitle = '修改标准'
        this.showDisabled = false
        this.mingScoreDisabled = false
      } else {
        that.myTitle = '查看标准'
        this.showDisabled = true
        this.mingScoreDisabled = true
      }
      let params = {
        normalId: norid,
      }
      this.axios
        .post(
          manalScore + '/manualQualityAssurance/getNormalInfo.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data) {
            let {judge,normalName,defaultScore,minScoreRange,maxScoreRange,normalContent,isSet,score,faqId,answer,faqContent,answerId,scoringRules,customerIntention,faqUpdateTime} = res.data
            this.judgeAuto = judge
            this.juid = judge
            this.addForm.judge = judge
            this.addForm.normalName = normalName
            this.addForm.defaultScore = defaultScore
            this.addForm.minScoreRange = minScoreRange
            this.addForm.maxScoreRange = maxScoreRange
            this.qingxuJudge = judge
            this.addForm.normalContent = normalContent
            this.addForm.mingScore = score
            this.addForm.isSet = false
            /*内容质检数据回显*/
            this.addForm.scoringRules = scoringRules
            this.addForm.contentIntent = faqId
            if(answer){
              let arr = answer.split(',')
              let str = ''
              arr.forEach((item,index)=>{
                if(!item){return}
                index = index + 1
                str +='<p>'+index+' '+item+'</p>'
              })
              this.addForm.contentAnswer = str
            }
            this.intendsData.faqId = faqId
            this.intendsData.answer = answer
            this.intendsData.faqContent = faqContent
            this.intendsData.answerId = answerId
            this.intendsData.customerIntention = customerIntention
            this.intendsData.faqUpdateTime = faqUpdateTime
            /*内容质检数据回显*/
            $('#yusu').hide()
            $('#qingxu').hide()
            $('#jingmo').hide()
            $('#chongfu').hide()
            $('#tags').hide()
            $('#shoudong').hide()
            $('#zhimingxiang').hide()
            $('#xuanxiang').hide()
            $('#contentQa').hide()
            $('#contextQa').hide()
            let paramsOne = {
              normalId: norid,
              judge: res.data.judge,
            }
            if (judge == 1) {
              $('#qingxu').show()
              this.getJudgeInfo(paramsOne)
            } else if (judge == 2) {
              $('#chongfu').show()
              this.getJudgeInfo(paramsOne)
            } else if (judge == 3) {
              $('#jingmo').show()
              this.getJudgeInfo(paramsOne)
            } else if (judge == 4) {
              $('#yusu').show()
              this.getJudgeInfo(paramsOne)
            } else if(judge==5){
              this.getJudgeInfo(paramsOne)
            } else if(judge==11){
              $('#tags').show()
              this.getJudgeInfo(paramsOne)
            }else if(judge==12){
              $('#contextQa').show()
              this.getJudgeInfo(paramsOne)
            }else if(judge==13){
              this.initCheckFaq() // 判断faq 删除或修改
              $('#contentQa').show()
              this.getJudgeInfo(paramsOne)
            }else {
              if(judge==6){
                $('#shoudong').show()
              }else if(judge==7){
                $('#xuanxiang').show()
              }else if(judge==8){
                $('#zhimingxiang').show()
              }
              if (
                res.data.optionTexts == '' ||
                res.data.optionTexts == undefined ||
                res.data.optionTexts == []
              ) {
                this.addForm.xuanDomains = {
                  domains: [{ optionTexts: '' }],
                }
              } else {
                let ops = res.data.optionTexts
                let trees = []
                this.getOption(ops, trees)
                this.trees = trees
                this.addForm.xuanDomains.domains = trees
              }
            }
          } else {
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 删除标准
    delNormalInfo: function(normalId, normalName) {
      let params = {
        normalId: normalId,
        modleId: this.modleIdNew
      }
      this.$confirm('确定要删除【' + normalName + '】吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.axios
            .post(
              manalScore + '/manualQualityAssurance/delNormalInfo.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data) {
                this.$message({
                  type: 'success',
                  message: '删除成功!',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '删除失败!',
                })
              }
              this.getScore()
              this.getTemplateData()
            })
        })
        .catch(() => {})
    },
    /**
     *时间戳
     * **/
    format: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // 自动打分 确定修改tree
    editSaveClassThrottle() {
      this.lodashThrottle.throttle(this.editSaveClass, this)
    },
    editSaveClass: function() {
      let _this=this
      _this.$refs.editTreeForm.validate((valid) => {
        if (valid) {
          let params = {
            classTitle: _this.editTreeForm.classTitle,
            remark: _this.editTreeForm.remark,
            classId: _this.treeid,
            modleId: _this.modleIdNew,
            // parentClassId: this.editTreeForm.parentClassId,
          }
          let checkParams={
            classTitle: _this.editTreeForm.classTitle,
            classId: _this.treeid,
            modleId: _this.modleIdNew,
            classType: '1'
          }
          _this.axios
            .post(
              manalScore + '/manualQualityAssurance/checkClassExist.do',
              Qs.stringify(checkParams)
            )
            .then((res) => {
              if (res.data === false) {
                _this.$message({
                  type: 'error',
                  message: '这个分类名称已经存在，请重新输入名称',
                })
              } else {
                _this.axios
                  .post(
                    manalScore + '/manualQualityAssurance/saveClass.do',
                    Qs.stringify(params)
                  )
                  .then((res) => {
                    if (res.data.flag == true) {
                      _this.updateTime_sub = res.data.updateTime
                      _this.$message({
                        type: 'success',
                        message: '修改成功!',
                      })
                    } else {
                      _this.$message({
                        type: 'error',
                        message: '修改失败!',
                      })
                    }
                    _this.$refs.editTreeForm.resetFields()
                    _this.getTemplateData()
                    _this.editTreeModal = false
                    _this.treeid = ''
                  })
                  .catch(function (error) {
                    console.log(error)
                    _this.$refs.editTreeForm.resetFields()
                    _this.editTreeModal = false
                    _this.treeid = ''
                  })
              }
            }).catch(function (error) {
              console.log(error)
              _this.$refs.editTreeForm.resetFields()
              _this.editTreeModal = false
              _this.treeid = ''
            })
        }
      })
    },
    // 自动打分 修改 取消
    editCancel: function() {
      this.treeid = ''
      this.editTreeForm.typeid = ''
      this.addTreeForm.typeid = ''
      this.editTreeModal = false
    },
    // 自动打分 添加 取消
    cancel: function() {
      this.dialogTreeFormVisible = false
      this.treeid = ''
      this.pid = ''
      this.addTreeForm.typeid = ''
      this.$refs.addTreeForm.resetFields()
    },
    addTableCanel: function() {
      this.addForm.domainsParamsQing = {
        domains: [
          {
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.addForm.chongDomains = {
        domains: [
          {
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.addForm.jingDomains = {
        domains: [
          {
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.addForm.domainsParamsYu = {
        domains: [
          {
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.myTitle = '新增标准'
      this.$refs.addForm.resetFields()
      this.$refs.contextData.resetFields()
      this.dialogFormVisible = false
    },
    /**
     * 删除tree
     * */
    delTree: function(treeid, typeid) {
      this.treeid = treeid
      this.typeid = typeid
      if (this.treeid == null || this.treeid == '') {
        this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        let params = {
          classId: this.treeid,
          modleId: this.modleIdNew
        }
        this.$confirm('确定要删除【' + this.typeid + '】吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
          .then(() => {
            this.axios
              .post(
                manalScore + '/manualQualityAssurance/deleteQaClass.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data == true) {
                  this.$message({
                    type: 'success',
                    message: '删除成功!',
                  })
                  /* if(this.parentid=='0'){
                   this.pid="";
                   } */
                  this.treeid = ''
                } else {
                  this.$message({
                    type: 'error',
                    message: '删除失败!',
                  })
                }
                this.treeid = ''
                this.getScore()
                this.getTemplateData()
                this.editTreeForm.typeid = ''
                this.addTreeForm.typeid = ''
                this.pidMan = ''
              })
              .catch(function(error) {
                console.log(error)
              })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除',
            })
          })
      }
    },
    addTree: function() {
      this.dialogTreeFormVisible = true
      this.addTreeForm.typeid = ''
    },
    /**
     * 修改tree
     * **/
    editTree: function(val) {
      this.treeid = val
      if (this.treeid == '') {
        this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        this.editTreeModal = true
      }
    },
    saveClassThrottle() {
      this.lodashThrottle.throttle(this.saveClass, this)
    },
    /**
     * 新增tree
     * **/
    saveClass: function() {
      let params = {
        classTitle: this.addTreeForm.classTitle,
        remark: this.addTreeForm.remark,
        modleId: this.modleIdNew,
        // parentClassId: this.treeid,
        classType: 1,
      }
      let checkParams = {
        classTitle: this.addTreeForm.classTitle,
        modleId: this.modleIdNew,
        // parentClassId: this.treeid,
        classType: 1,
      }
      this.$refs.addTreeForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(
              manalScore + '/manualQualityAssurance/checkClassExist.do',
              Qs.stringify(checkParams)
            )
            .then((res) => {
              if (res.data === false) {
                this.$message({
                  type: 'error',
                  message: '这个分类名称已经存在，请重新输入名称',
                })
              } else {
                this.axios
                  .post(
                    manalScore + '/manualQualityAssurance/saveClass.do',
                    Qs.stringify(params)
                  )
                  .then((res) => {
                    if (res.data.flag === true) {
                      this.updateTime_sub = res.data.updateTime
                      this.$message({
                        type: 'success',
                        message: '添加成功',
                      })
                    } else {
                      this.$message({
                        type: 'error',
                        message: '添加失败',
                      })
                    }
                    this.dialogTreeFormVisible = false
                    this.$refs['addTreeForm'].resetFields()
                    this.getTemplateData()
                    this.treeid = ''
                    this.pid = ''
                  })
                  .catch(function(error) {
                    console.log(error)
                  })
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    getTemplateData: function() {
      let params = {
        modleId: this.modleIdNew,
        updateTime: this.updateTime_sub,
      }
      this.axios
        .post(
          manalScore + '/manualQualityAssurance/getTemplateData.do',
          Qs.stringify(params)
        )
        .then((res) => {
          console.log(res)
          this.autoTemplateData = res.data.resultAuto
          this.autoTotalScore = res.data.autoScore
          this.filter()
          let data = res.data.resultAuto
          if(data){
            let arr = []
            data.forEach((itm,index)=>{
              itm.normalList.map((i,idx)=>{
                if(i.judge===13){
                  arr.push({
                    faqId:i.faqId,
                    faqContent:i.faqContent,
                    faqUpdateTime:i.faqUpdateTime,
                  })
                }
              })
            })
            this.faqArr = arr
            this.initCheckFaq()
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     * 选择打分纬度
     * **/
    optionChange: function(val) {
      this.addEditJudge = val
      this.addForm.judge = val
      this.chongDieRole = '0'
      this.yuSuRole = '0'
      this.jMRoleBefore = '0'
      this.jMRoleAfter = '0'
      this.judgeAuto = val;
      this.mingScoreDisabled = false
      if (val == 5) {
        this.showOffset = true
        this.showScoreType = true
        this.showJingmoType = false
        if (this.myTitle === '修改标准' || this.myTitle === '查看标准') {
        } else {
          this.addForm.minScoreRange = ''
          this.addForm.maxScoreRange = ''
          this.addForm.mingScore = ''
          this.addForm.correctNumber = ''
          this.addForm.setLabelName = ''
          this.addForm.isSet = false
          this.handleResetKey()
        }
      } else if(val === 3){
        this.addForm.silenceType = 1
        this.handleResetKey()
      }else if(val === 11){
        this.clearAddLogic()
      }else if (val === 6) {
            if (this.myTitle == '编辑标准') {
                console.log(this.addForm.maxScoreRange)
            }else {
                this.addForm.maxScoreRange = ''
                this.addForm.minScoreRange = ''
                this.addForm.defaultScore = ''
            }
        } else if (val === 7) {
            if (this.myTitle === '新增标准') {
                this.addForm.maxScoreRange = ''
                this.addForm.minScoreRange = ''
                this.addForm.defaultScore = ''
            }
        } else if (val === 8){
            if (this.myTitle === '新增标准') {
                this.addForm.maxScoreRange = ''
                this.addForm.minScoreRange = ''
                this.addForm.defaultScore = ''
            }
        }else if(val === 13) {
        this.addForm.contentParam = [
          {
            id:Date.now(),
            content: '',//设置话术
            ivsQaSpeechCrafts:[],//相似话术
            isAppear: '1',//出现or不出现
            addsub:'1',//加分减分
            score: '',//分数
          }
        ]
      }
    },
    changeDeadItem: function(val) {
      if (val == '1') {
        this.mingScoreDisabled = true
        this.addForm.mingScore = 0
        this.addForm.maxScoreRange = 1
        this.addForm.minScoreRange = 0
        this.addForm.defaultScore = 1
      } else {
        this.mingScoreDisabled = false
      }
    },
    changePosition: function(val) {
      if (val === '3') {
        this.showOffset = false
      } else {
        this.showOffset = true
      }
    },
    /**
     * 静默类型选择
     * **/
    changeRadio: function(val) {
      this.slienceType = val
    },
    removeDomainQing(item) {
      let index = this.addForm.domainsParamsQing.domains.indexOf(item)
      if (index === 1) {
        return
      } else {
        this.addForm.domainsParamsQing.domains.splice(index, 1)
      }
    },
    addDomainQing() {
      this.addForm.domainsParamsQing.domains.push({
        value: '',
        key: Date.now(),
        increaseDeduction: '1',
      })
    },
    getLabelName(item) {
      return item.executeState == '1' ? item.labelName : item.labelName + '（停用中）'
    },
    // tags 标签
    addDomainTags() {
        this.addForm.domainsTags.domains.push({
            add: false,
            labelId: '',
            labelName: '',
        })
    },
    removeDomainTags(item) {
        let that = this
        let index = that.addForm.domainsTags.domains.indexOf(item)
        if (index !== -1) {
            that.addForm.domainsTags.domains.splice(index, 1)
        }
        if (that.addForm.domainsTags.domains.length === 0) {
            that.addForm.domainsTags.domains = [
                {
                    add: false,
                    labelName: '',
                    labelId: '',
                },
            ]
        }
    },
    // 取消添加标签
    clearAddLogic() {
      this.addForm.correctNumber = ''
      this.addForm.domainsTags.domains = [
        {
          add: false,
          labelId: '',
          labelName: '',
        }
      ]
    },
    // 重叠次数 添加 删除 input
    addChongDomain() {
      this.addForm.chongDomains.domains.push({
        value: '',
        key: Date.now(),
        increaseDeduction: '1',
      })
    },
    // 重叠次数 添加 删除 input
    removeChongDomain(item) {
      let index = this.addForm.chongDomains.domains.indexOf(item)
      if (index !== -1) {
        this.addForm.chongDomains.domains.splice(index, 1)
      } else {
        this.addForm.chongDomains.domains.splice(index, 1)
      }
    },
    // 静默
    addJingDomain() {
      this.addForm.jingDomains.domains.push({
        value: '',
        key: Date.now(),
        increaseDeduction: '1',
      })
    },
    // 静默
    removeJingDomain: function(item) {
      let index = this.addForm.jingDomains.domains.indexOf(item)
      if (index !== -1) {
        this.addForm.jingDomains.domains.splice(index, 1)
      } else {
        this.addForm.jingDomains.domains.splice(index, 1)
      }
    },
    // 语速
    addDomainYu: function() {
      this.addForm.domainsParamsYu.domains.push({
        value: '',
        key: Date.now(),
        increaseDeduction: '1',
      })
    },
    // 添加语速
    removeDomainYu(item) {
      let index = this.addForm.domainsParamsYu.domains.indexOf(item)
      if (index !== -1) {
        this.addForm.domainsParamsYu.domains.splice(index, 1)
      } else {
        this.addForm.domainsParamsYu.domains.splice(index, 1)
      }
    },
    // 选项
    addDomainMan: function() {
      this.addForm.xuanDomains.domains.push({
        value: '',
        key: Date.now(),
        increaseDeduction: '1',
      })
    },
    // 选项
    removeDomainMan(item) {
      let index = this.addForm.xuanDomains.domains.indexOf(item)
      if (index !== -1) {
        this.addForm.xuanDomains.domains.splice(index, 1)
      }
    },
    /**
     * 返回父组件
     * **/
    goBack: function() {
      this.editTreeForm.classId = ''
      this.formInlineArtificial.user = ''
      this.formInlineAuto.normalName = ''
      this.treeid = ''
      this.$emit('send', true)
    },
    // 获取总分
    getScore: function() {
      let _this = this
      let params = {
        modelId: this.modleIdNew,
      }
      this.axios
        .post(
          manalScore + '/manualQualityAssurance/getTotalScore.do',
          Qs.stringify(params)
        )
        .then(function(res) {
          if (res.data.count <= 0) {
            _this.totalScores = 0
          } else {
            _this.totalScores = res.data.count
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    changeScoreType: function(val) {
      if (val !== 1) {
        // this.mingScoreDisabled = false
      }
      if (val === 1) {
        this.addForm.deadItem = '2'
        this.showScoreType = true
        this.showJingmoType = false
      } else if (val === 2) {
        this.showScoreType = false
        this.showJingmoType = true
      }
    },
    changeSilenceType: function(val) {
      if (val === 1) {
        this.showSilenceType = true
      } else {
        this.showSilenceType = false
      }
    },
    getMaxScore(arr) {
      let newarr = []
      for (let i = 0; i < arr.length; i++) {
        if (!isNaN(arr[i])) {
          newarr.push(parseInt(arr[i]))
        }
      }
      return Math.max.apply(Math, newarr)
    },
    totalScoresFun(val) {
      let count = val + this.autoTotalScore
      return (count > 0)? count: 0
    },
    // ‘+’ 按钮
    itemPlus() {
      if(this.errorKeywordContext){return}
      this.items.push({
        id: Date.now(),
        keyWordData: {
          offset: '',
          sceneTime: '',
          position: '0',
          isAppear: 1,
          keywordContext: '',
          errKeywordContext:'',
          roleType: 0,
          silenceTimeMax:'',
        },
      })
    },
    // ‘-’ 按钮
    itemMinus(item) {
      if(this.errorKeywordContext){return}
      let index = this.items.indexOf(item)
      if (index !== -1) {
        this.items.splice(index, 1)
      }
    },
    //------------------------内容质检 start-------------------------------
    // 判断Faq更改删除
    judgeFaqChange(){
      return new Promise((resolve,reject)=>{
        let arr = [{
          faqUpdateTime:this.intendsData.faqUpdateTime,
          faqId:this.intendsData.faqId,
          faqContent:this.intendsData.faqContent,
        }]
        let params ={
          keyWordJson:JSON.stringify(arr)
        }
        this.axios.post(manalScore+'/manualQualityAssurance/getCheckFaq.do',Qs.stringify(params))
          .then((res)=>{
            let {flag,msg,data} = res.data
            let err = data || msg
            if(flag){
              resolve('')
            }else{
              resolve(err)
            }
          })
          .catch((err)=>reject(err))
      })
    },

    // 后台设置话术判重
    checkWordRepeat(){
      return new Promise((resolve,reject)=>{
        let normalId = this.myTitle === '修改标准'?this.normalId:''
        if(normalId){
          resolve('')
          return
        }
        let arr = []
        this.addForm.contentParam.forEach((itm)=>{
          arr.push(itm.content)
        })
        let names = JSON.stringify(arr)
        let params = {
          names:names
        }
        this.axios.post(manalScore+'/manualQualityAssurance/getClassName.do',Qs.stringify(params))
          .then((res)=>{
            let {flag,msg} = res.data
            if(flag){
               resolve('')
            }else{
               resolve(msg)
            }
          })
          .catch((err)=>reject(err))
      })

    },
    // 相似话术判重
    checkRepeat(){
      let arr = []
      this.addForm.contentParam.forEach((itm)=>{
        if(!itm.ivsQaSpeechCrafts){return}
        itm.ivsQaSpeechCrafts.forEach((item)=>{
          arr.push(item.speechcraftContent)
        })
        arr.push(itm.content)
      })
      let len = arr.length || 0
      let obj = {}
      let newArr = arr.reduce((pre,cur)=>{
       obj[cur]?'':obj[cur]=true && pre.push(cur)
        return pre
      },[])
      let newL = newArr.length||0
      if(len!=newL){
        return false
      }else{
        return true
      }
    },
    // 获取意图
    getIntends () {
      this.axios.get(manalScore+'/manualQualityAssurance/getFaq.do')
        .then((res)=>{
          let {data} = res.data
          if(!data){return}
          this.intentionList = data
        })
        .catch((err)=>console.log(err))
    },
    //添加话术
    addDiscourse(){
      let param =  {
              id:Date.now(),
              content: '',//设置话术
              ivsQaSpeechCrafts:[],//相似话术
              isAppear: '1',//出现or不出现
              addsub:'1',//加分减分
              score: '',//分数
            }
            console.log(this.addForm.contentParam)
      this.addForm.contentParam.push(param)
    },
    // 更改意图查询答案
    changeIntents(val){
      let curData = this.intentionList.filter((item)=>{return item.faqId===val})
      this.intendsData={
        faqId:val,
        faqContent:curData&&curData[0].question,
        customerIntention:curData&&curData[0].classifyId,
        answer:'',
        answerId:'',
        faqUpdateTime:curData&&curData[0].updateTimeStamp,
      }
      let url = '/manualQualityAssurance/getAnswer.do?faqId='+val
      this.axios.get(manalScore+url)
        .then((res)=>{
          let {flag,data} = res.data
          if(!flag){return}
          this.addForm.contentAnswer = ''
          let str = ''
          data.forEach((item,index)=>{
            index = index+1
            str+='<p>'+index+' '+item.text+'</p>'
            this.intendsData.answer+=item.text+','
            this.intendsData.answerId+=item.answerId+','
          })
          this.addForm.contentAnswer = str
        })
        .catch((err)=>console.log(err))
    },
    // 添加相似话术
    handleSimlarWords(idx){
      this.simlarWordsIdx = idx
      this.simlarWordsVisible = true
      this.simlarWordsForm.ivsQaSpeechCrafts = Object.assign([],this.addForm.contentParam[idx].ivsQaSpeechCrafts)
    },
    // 取消保存
    cancleSimlarWords(){
      this.simlarWordsVisible = false
    },
    // 添加相似词
    addSimilarWord(){
      let simlarWordsItem = {
        id:Date.now(),
        speechcraftContent:'',
      }
      this.simlarWordsForm.ivsQaSpeechCrafts.push(simlarWordsItem)
    },
    // 保存相似话术
    saveSimlarWords(){
      let index = this.simlarWordsIdx
      let data = this.simlarWordsForm.ivsQaSpeechCrafts
      if (data.some(item => this.hasUnregularWord(item.speechcraftContent))) {
        this.$message.error('话术禁止输入特殊字符')
        return
      }
      this.simlarWordsVisible = false
      this.$set(this.addForm.contentParam[index],'ivsQaSpeechCrafts',data)
    },
    //------------------------内容质检 end----------------------------------
  },
  computed: {
    loadData() {
      if (this.modleIdNew !== '') {
        console.log('modelId' + this.modleIdNew)
        this.getScore(this.modleIdNew)
        this.updateTime_sub = this.updateTime_sub || this.updateTime
        this.getTemplateData()
        this.namesForm.modleTitle = this.mdtitle
        this.editNamesForm.remark = this.info.remark
        this.addTreeForm.typeid = ''
        return this.modleIdNew
      } else {
        this.addTreeForm.typeid = ''
      }
    },
    numsTitle() {
      const val = this.addForm.silenceType
      if (val === 1 || val === 4) {
        return '秒'
      } else if (val === 2) {
        return '次'
      } else if (val === 3){
        return '%'
      }
      return ''
    },
  },
  watch: {
    loadData(val, oldval) {},
    updateTime(val) {
      this.updateTime_sub = val
    },
  },
}
</script>
<style scoped="scoped" lang="less">
@border-color: #d1dbe5;
.el-row {
  height: 100%;
  .el-col {
    height: 100%;
  }
}
.d-ib {
  display: inline-block;
  padding: 0;
  margin: 0;
}
.m-l-10 {
  margin-left: 10px;
}
.m-l-120 {
  margin-left: 120px;
}
#tags {
  .flex-box {
    display: flex;
    flex-flow: row wrap;
    width: 700px;
    .iconDomain {
      font-size: 16px;
      cursor: pointer;
      margin-left: 10px;
    }
    .flex-box-list {
      width: 100%;
    }
  }
}
.templateClass {
  height: 50px;
  margin-left: 20px;
  margin-right: 18px;
  border-bottom: 1px solid @border-color;
  display: flex;
  flex-direction: row;
  align-items: center;
  button {
    width: 84px;
    height: 30px;
    padding: 7px 13px 8px 12px;
  }
  .tmptTitle {
    width: 52px;
    height: 20px;
    color: #475669;
    font-size: 13px;
    text-align: left;
    font-weight: 700;
    margin-right: 10px;
  }
}
.contentLeft {
  box-sizing: border-box;
  border-right: 1px solid @border-color;
  height: 100%;
  width: 100%;
  position: relative;
}
.standard {
  margin-right: 18px;
  margin-left: 32px;
  .standardClass {
    height: 50px;
    border-bottom: 1px solid @border-color;
    display: flex;
    flex-direction: row;
    align-items: center;
    .standardClass_title {
      max-width: 140px;
      height: 20px;
      color: #475669;
      font-size: 14px;
      text-align: left;
      margin-right: 12px;
    }
    button {
      width: 58px;
      height: 22px;
      padding: 4px 5px 6px 5px;
      color: #475669;
      font-size: 12px;
    }
    .standardClass_right {
      flex: 1;
      text-align: right;
      display: flex;
      flex-direction: row;
      justify-content: flex-end;
      .standardClass_btn {
        color: #20a0ff;
        font-size: 14px;
        margin-right: 52px;
        width: 79px;
        span {
          cursor: pointer;
          margin-right: 5px;
          &:last-child {
            margin-right: 0px;
          }
        }
      }
    }
  }
  .button {
    position: relative;
    margin-left: 12px;
    span {
      width: 48px;
      height: 12px;
      line-height: 12px;
      color: rgba(71, 86, 105, 1);
      font-size: 12px;
      text-align: center;
      font-family: MicrosoftYaHei;
    }
  }
  li.normal {
    min-height: 50px;
    border-bottom: 1px solid @border-color;
    margin-left: 50px;
    margin-right: 32px;
    display: flex;
    flex-direction: row;
    align-items: center;
    .normal_title {
      width: 140px;
      height: 20px;
      color: #475669;
      font-size: 14px;
      text-align: left;
      margin-right: 20px;
    }
    .normal_content {
      flex: 1;
      font-size: 14px;
      color: #475669;
      overflow-x: scroll;
      text-overflow: ellipsis;
      white-space: nowrap;
      p {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
    .normal_hand_content {
      flex: 1;
      font-size: 14px;
      color: #475669;
    }
    .normal_btn {
      color: #20a0ff;
      font-size: 14px;
      margin-right: 38px;
      width: 79px;
      text-align: right;
      span {
        cursor: pointer;
        margin-right: 5px;
        &:last-child {
          margin-right: 0px;
        }
      }
    }
    .normal_score {
      width: 30px;
      color: #475669;
      font-size: 14px;
      text-align: right;
    }
  }
}
.newTemplate {
  width: 100%;
  // padding: 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  #keylists {
    border: 1px solid #bfcbd9;
    box-sizing: border-box;
    border-radius: 4px;
    height: 200px;
  }
  .content-answer {
    background: #f6f8fa;
    width: 400px;
    height: 150px;
    overflow-y: auto;
  }
  .autoGrading {
    width: 100%;
    box-sizing: border-box;
    height: 100%;
    position: relative;
    .autoGrading-body {
      position: absolute;
      top: 58px;
      left: 0;
      bottom: 1px;
      width: 100%;
    }
    .templateHeader {
      height: 55px;
      border-bottom: 1px solid @border-color;
      display: flex;
      flex-direction: row;
      padding: 0 23px 0 20px;
      align-items: center;
      .total_score {
        line-height: 30px;
        span {
          color: #475669;
          font-size: 13px;
          margin-right: 18px;
        }
        .viewBtn {
          min-width: 80px;
          height: 30px;
          padding: 8px 20px;
        }
      }
    }
  }
  .buttons {
    button {
      width: 90px;
      margin-right: 10px;
      font-family: '微软雅黑';
      float: right;
    }
  }
  .preview {
    .total {
      float: right;
      label {
        color: #85ce61;
        font-size: 24px;
      }
    }
    .header {
      height: 30px;
      p {
        display: block;
        float: left;
      }
      span {
        display: block;
        float: right;
        em {
          font-style: normal;
          font-size: 18px;
          padding-left: 6px;
          color: #ff132f;
        }
      }
    }
    .border {
      border-bottom: 1px dashed #ccc;
      margin-top: 10px;
      margin-bottom: 10px;
    }
    .normalNameClass {
      margin-bottom: -8px;
      margin-top: 10px;
      height: 35px;
      color: #9dadc2;
    }
    .bodys {
      float: left;
      width: 100%;
      .qualityTitle {
        padding-bottom: 10px;
        color: #9dadc2;
        font-size: 14px;
        width: 100%;
        p {
          padding-left: 10px;
        }
      }
      .leftbody {
        width: 100%;
        float: left;
        .box {
          float: left; /*margin-top: 10px;*/
          overflow: hidden;
          width: 100%;
        }
        .lists {
          width: 45%;
          float: left;
          /*margin-bottom: 10px;*/
          padding-left: 15px;
          .titleInput {
            width: 140px;
            margin-left: 10px;
          }
          p {
            /*width:80px;*/
            display: inline-block;
          }
        }
      }
      .rightbody {
        float: left;
        width: 60%;
        margin-top: 30px;
      }
      .title {
        float: left;
        text-align: right;
        width: 60px;
      }
      .services {
        line-height: 36px;
        float: left;
        cursor: pointer;
        .defaultlabel {
          background: #97a8be;
          color: #fff;
        }
        p {
          border: 1px solid #bfcbd9;
          border-radius: 4px;
          margin: 6px 2px 0px 2px;
          float: left;
          border-right: 1px solid #ccc;
          display: inline-block;
          cursor: pointer;
          padding: 0px 10px 0px 10px;
          /*width: 80px;*/
          text-align: center;
        }
      }
    }
  }
  .w120 {
    width: 100px;
    margin-right: 10px;
  }
  .ra {
    width: 70px;
    margin-right: 10px;
  }
  .ml {
    margin-right: 10px;
  }
  .keys {
    cursor: pointer;
    margin-left: 45px;
    .keylabel {
      display: inline-block;
      border-radius: 5px;
      height: 36px;
      width: 68px;
      line-height: 36px;
      text-align: center;
      cursor: pointer;
      font-size: 12px;
      text-align: center;
      background-color: #e4e8f1;
      color: #48576a;
    }
    label:hover {
      background: #eef1f6;
      color: #8691a5;
    }
  }
  #keyRules {
    border: 1px solid #bfcbd9;
    box-shadow: 2px 2px 2px 2px #f4f4f4;
    padding: 20px 25px 30px 18px;
    box-sizing: border-box;
    width: 400px;
    overflow-y: auto;
    height: 380px;
    position: absolute;
    top: 120px;
    left: 160px;
  }
  .termRules {
    display: block;
    cursor: pointer;
    position: absolute;
    top: -10px;
    right: -60px;
    color: #5e6873;
    text-decoration: underline;
  }
}
.judgeLists {
  float: left;
  width: 100%; /*margin-bottom: 10px;*/
  .judgeTitle {
    /*width:100%;*/
    margin: 10px 0px 0px 0px; /*clear: both*/
    float: left;
    span {
      padding-left: 15px;
    }
  }
}
.number-input {
  width: 60px;
  margin: 0 10px;
}
::-webkit-scrollbar {
  background: none;
  width: 7px;
  height: 5px;
}
</style>
<style lang="less">
#qNewTemplate {
  .plus-minus-button {
    width: 120px;
    .icon {
      margin-left: 10px;
      padding: 5px 16px;
      background-color: #fff;
      width: 48px;
      height: 30px;
    }
  }
  .el-dialog__wrapper.templateAutonormal {
    .el-dialog {
      width: 66%;
    }
  }
  .el-tabs--border-card {
    overflow: hidden;
    height: 100%;
    position: relative;
  }

  .el-tabs--border-card > .el-tabs__content {
    width: 100%;
    position: absolute;
    padding: 0px !important;
    top: 40px;
    left: 0px;
    bottom: 1px;
  }

  .el-tabs__content .el-tab-pane {
    width: 100%;
    height: 100%;
  }

  .el-tabs--border-card > .el-tabs__header {
    height: 40px;
  }

  .el-tree {
    cursor: default;
    background: #fff;
    border: none;
  }

  .preview .el-table::before {
    left: 0;
    bottom: 0;
    width: 100%;
    height: 0px;
  }
  .templateHeader {
    .el-button span {
      color: #20a0ff;
    }
    .viewBtn {
      &.el-button span {
        color: #475669;
      }
    }
  }
  .templateClass {
    .el-button {
      i {
        font-size: 8px;
        margin-right: 6px;
      }
    }
  }
  .tmpClass3 {
    height: 50px;
    margin-left: 20px;
    margin-right: 18px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
  }
  .el-input.tmpClass2 {
    width: 100px;
  }
  .tmpClass1 {
    height: 20px;
    color: #475669;
    font-size: 13px;
    text-align: left;
    font-weight: 700;
    margin-right: 10px;
  }

  .el-form--inline .key-words .el-form-item__content {
    display: block;
  }
  .key-words {
    .key-word {
      flex: 1;
      border: 1px solid #dedede;
      border-radius: 5px;
      margin-left: 30px;
      padding: 20px 20px 0;
      .key-words-range {
        .zai {
          padding: 0 10px 0 5px;
        }
        .gap {
          margin-left: 10px;
        }
        .size-ju {
          width: 15%;
          margin-right: 5px;
        }
        .size-select {
          width: 90px;
        }
      }

      .key-words-content {
        width: 100%;
        .el-form-item__content {
          width: 100%;
        }
        .err-keyword {
          height: 60px;
          padding: 2px 20px;
          overflow-y: auto;
          font-size: 13px;
          margin-top: 10px;
          position: relative;
          background-color: #f2f2f2;
          .itm-tip {
            width: 100%;
            height: 20px;
            p {
              width: 16px;
              height: 16px;
              border-radius: 16px;
              display: inline-flex;
              align-items: center;
              justify-content: center;
              background-color: red;
              color: #fff;
            }
            span {
              font-size: 12px;
              line-height: 1.5;
            }
          }
          .itm-err {
            line-height: 1.5;
            margin: 10px 5px 0 0;
          }
        }
        .logical-words {
          margin-top: 10px;

          .el-button + .el-button {
            margin-left: 5px;
          }
        }
      }
    }
  }
}
/*下拉框优化*/
.select_drop {
  max-width: 243px;
  .el-select-dropdown__item {
    display: inline-block;
  }
  .el-select-dropdown__item span {
    min-width: 205px;
    display: inline-block;
  }
}
</style>
