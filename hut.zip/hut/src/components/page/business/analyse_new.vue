<template>
  <div id="analyse">
    <div class="box">
      <el-form
        :inline="true"
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-form-item label="静默" prop="silenceSeconds">
          <el-input v-model="ruleForm.silenceSeconds" class="w300"></el-input
          ><label class="text">秒</label
          ><label class="textTwo">(超过N秒为静默)</label> </el-form-item
        ><br />
        <el-form-item label="重叠" prop="consClusterSeconds">
          <el-input v-model="ruleForm.consClusterSeconds" class="w300"></el-input
          ><label class="text">秒</label
          ><label class="textTwo">(超过N秒为叠音)</label> </el-form-item
        ><br />
        <el-form-item label="情绪" prop="mood">
          <el-input v-model="ruleForm.mood" class="w300"></el-input
          ><label class="textTwo">(情绪值超过N时为负情绪)</label> </el-form-item
        ><br />
        <el-form-item prop="minSpeed" label="语速" style="float:left;">
          <el-input
            v-model="ruleForm.minSpeed"
            style="width: 115px;float:left;"
          ></el-input>
          <label style="float:left; padding-left: 10px;">-</label>
        </el-form-item>
        <el-form-item prop="maxSpeed">
          <el-input
            v-model="ruleForm.maxSpeed"
            style="width: 115px;float:left;"
          ></el-input>
        </el-form-item>
        <el-form-item style="margin-left:30px;clear:both;">
          <label class="textTwo" style=""
            >(配置最慢语速和最快语速标准，小于区间为过慢，大于区间为过快，区间内为正常)</label
          >
        </el-form-item>
        <el-form-item style="margin-left:100px;width:100%">
          <el-button funcId="000029" type="primary" @click="saveForm">确定</el-button>
          <el-button funcId="000028" @click="resetForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import axios from 'axios'
import Qs from 'qs'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
axios.defaults.withCredentials = true
axios.defaults.headers = {
  'Content-Type': 'application/x-www-form-urlencoded ;charset=UTF-8',
}
export default {
  data() {
    const validQualityScore = (rule, value, callback) => {
      let regFloat = /(^$)|^-?\d+$/
      if (value == '') {
        callback(new Error('不能为空'))
      } else if (regFloat.test(value)) {
        callback()
      } else {
        callback(new Error('请输入整数'))
      }
    }
    const validMinSpeedScore = (rule, value, callback) => {
      let regFloat = /(^$)|^-?\d+$/
      if (value == '') {
        callback(new Error('不能为空'))
      } else if (this.ruleForm.minSpeed >= this.ruleForm.maxSpeed) {
        callback(new Error('不能大于最快语速'))
      } else if (!regFloat.test(value)) {
        callback(new Error('请输入整数'))
      } else {
        callback()
      }
    }
    const validMaxSpeedScore = (rule, value, callback) => {
      let regFloat = /(^$)|^-?\d+$/
      if (value == '') {
        callback(new Error('不能为空'))
      } else if (this.ruleForm.maxSpeed <= this.ruleForm.minSpeed) {
        callback(new Error('不能小于最慢语速'))
      } else if (!regFloat.test(value)) {
        callback(new Error('请输入整数'))
      } else {
        callback()
      }
    }
    return {
      ruleForm: {
        silenceSeconds: '',
        consClusterSeconds: '',
        mood: '',
        minSpeed: '',
        maxSpeed: '',
      },
      rules: {
        silenceSeconds: [{ validator: validQualityScore, trigger: 'blur' }],
        consClusterSeconds: [{ validator: validQualityScore, trigger: 'blur' }],
        mood: [{ validator: validQualityScore, trigger: 'blur' }],
        minSpeed: [{ validator: validMinSpeedScore, trigger: 'blur' }],
        maxSpeed: [{ validator: validMaxSpeedScore, trigger: 'blur' }],
      },
    }
  },
  methods: {
    // 调用信息
    analyse: function() {
      this.axios
        .post(currentBaseUrl + '/externalBizInfo/analyse.do')
        .then((res) => {
          console.log(res.data)
          this.ruleForm.silenceSeconds = res.data.analyse.silenceSeconds
          this.ruleForm.consClusterSeconds = res.data.analyse.consClusterSeconds
          this.ruleForm.mood = res.data.analyse.mood
          this.ruleForm.minSpeed = res.data.analyse.minSpeed
          this.ruleForm.maxSpeed = res.data.analyse.maxSpeed
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 重置
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.ruleForm.silenceSeconds = 3
      this.ruleForm.consClusterSeconds = 1
      this.ruleForm.mood = 1
      this.ruleForm.minSpeed = 3
      this.ruleForm.maxSpeed = 7
    },
    // 确定
    saveForm: function() {
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(
              currentBaseUrl + '/externalBizInfo/saveAnalyseConfig.do',
              Qs.stringify(this.ruleForm)
            )
            .then((res) => {
              if (res.data == true) {
                this.$message({
                  type: 'success',
                  message: '保存成功!',
                })
              } else {
                this.$message({
                  type: 'success',
                  message: '保存失败，检查条件',
                })
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
  },
  mounted() {
    this.analyse()
  },
}
</script>
<style lang="less" scoped="scoped">
#analyse {
  width: 100%;
  height: 100%;
  .box {
    padding: 20px;
    overflow: hidden;
    .demo-ruleForm {
      .text {
        padding-left: 10px;
      }
      .textTwo {
        color: #fe1a3a;
        font-size: 14px;
        padding-left: 10px;
      }
      .w300 {
        width: 300px;
      }
    }
  }
}
</style>
