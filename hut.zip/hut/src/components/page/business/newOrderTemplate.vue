<template>
  <div class="newTemplate" id="qNewTemplate">
    <div class="autoGrading">
      <div class="autoGrading-header">
        <div class="names">
          <el-form ref="namesForm" :model="namesForm" label-width="80px">
            <el-form-item label="模板名称">
              <el-input
                v-model="namesForm.modleTitle"
                :disabled="true"
                class="names-input"
              ></el-input>
              <el-button
                icon="el-icon-edit"
                class="el-icon-edit"
                @click="handleIconClick"
              ></el-button>
              <label class="pl10"
                >模板总分：<label class="scores">{{ this.totalScores }}</label></label
              >
            </el-form-item>
          </el-form>
          <el-dialog
            :close-on-click-modal="false"
            title="修改名称"
            :visible.sync="handleIconModel"
          >
            <el-form
              ref="editNamesForm"
              :rules="namesRules"
              :model="editNamesForm"
              label-width="100px"
            >
              <el-form-item label="模板名称" prop="modleTitle">
                <el-input
                  style="width: 170px"
                  v-model="editNamesForm.modleTitle"
                ></el-input>
              </el-form-item>
              <el-form-item label="备注">
                <el-input
                  style="width: 170px"
                  :rows="6"
                  type="textarea"
                  v-model="editNamesForm.remark"
                ></el-input>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="editNamesYesThrottle">确定</el-button>
                <el-button @click="handleIconModel = false">取消</el-button>
              </el-form-item>
            </el-form>
          </el-dialog>
        </div>
        <div class="buttons">
          <el-button @click="goBack">返回</el-button>
          <el-button type="primary" @click="preview">预览</el-button>
        </div>
      </div>
      <el-dialog
        :close-on-click-modal="false"
        title="预览模板"
        :visible.sync="previewModel"
      >
        <div class="preview">
          <div class="header"><p>自动打分标准</p></div>
          <div v-for="(tableRow, key) in tableData" :key="key">
            <div class="normalNameClass">{{ key }}</div>
            <el-table :data="tableRow" style="width: 100%; height:200px; overflow:auto">
              <el-table-column prop="judge" label="质检标准" width="180">
                <template scope="scope">
                  <div>{{ scope.row.normalName }}</div>
                </template>
              </el-table-column>
              <el-table-column label="内容" width="180">
                <template scope="scope">
                  <div v-if="scope.row.judge === 5">
                    <p v-if="scope.row.resultsObject != null">
                      {{ scope.row.resultsObject.keywordContext }}
                      <el-popover placement="right" width="120" trigger="hover">
                        <template
                          v-if="scope.row.resultsObject.deadItem == '1'"
                          slot="reference"
                        >
                          <i class="el-icon-warning" style="color: red"></i>
                        </template>
                        <p>此标准为致命项标准，命中则分数为 0</p>
                      </el-popover>
                    </p>

                    <p v-else></p>
                  </div>
                  <div v-else-if="scope.row.judge === 4">
                    <div v-for="srrt in scope.row.resultsObject">
                      <p>
                        {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒
                        <span style="float:right;">得{{ srrt.score }}分</span>
                      </p>
                    </div>
                  </div>
                  <div v-else-if="scope.row.judge === 1">
                    <div v-for="srrt in scope.row.resultsObject">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}分
                        <span style="float:right;">得{{ srrt.score }}分</span>
                      </p>
                    </div>
                  </div>
                  <div v-else-if="scope.row.judge === 2">
                    <div v-for="srrt in scope.row.resultsObject">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次
                        <span style="float:right;">得{{ srrt.score }}分</span>
                      </p>
                    </div>
                  </div>
                  <div v-else-if="scope.row.judge === 3">
                    <div v-for="srrt in scope.row.resultsObject">
                      <div v-if="srrt.silenceType === 1">
                        <p>
                          {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒
                          <span style="float:right;">得{{ srrt.score }}分</span>
                        </p>
                      </div>
                      <div v-else-if="srrt.silenceType === 2">
                        <p>
                          {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次
                          <span style="float:right;">得{{ srrt.score }}分</span>
                        </p>
                      </div>
                      <div v-else-if="srrt.silenceType === 3">
                        <p>
                          {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%
                          <span style="float:right;">得{{ srrt.score }}分</span>
                        </p>
                      </div>
                      <div v-else></div>
                    </div>
                  </div>
                  <div v-else=""></div>
                </template>
              </el-table-column>
              <el-table-column label="分数">
                <template scope="scope">
                  <p>{{ scope.row.defaultScore }}分</p>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="border"></div>
          <div class="header">
            <p>人工标准</p>
          </div>
          <div class="bodys" style="height: 150px; overflow: auto">
            <div class="leftbody">
              <div class="box" v-for="(item, key) in typelist">
                <div v-if="item != ''">
                  <div class="qualityTitle">
                    <p>{{ key }}</p>
                  </div>
                  <div
                    v-for="obj in item"
                    style="width: 100%; clear: both; padding: 5px; overflow: hidden"
                  >
                    <div class="lists" v-if="obj.judge == 6">
                      <p>{{ obj.normalName }}</p>
                      <el-input
                        :disabled="true"
                        class="titleInput"
                        v-model="obj.defaultScore"
                      ></el-input>
                    </div>
                    <div class="judgeLists" v-if="obj.judge == 7">
                      <div class="judgeTitle">
                        <span>{{ obj.normalName }}</span>
                      </div>
                      <div class="services">
                        <!--<div v-for="title in obj.resultsObject" style="margin-left: 10px;">
                          <p  class="service-label label"  @click="good">{{title}}</p>
                        </div>-->
                        <el-checkbox-group
                          v-model="checkboxGroup1"
                          style="float: left;margin-left: 14px;"
                        >
                          <el-checkbox-button
                            v-for="title in obj.resultsObject"
                            :label="title"
                            :key="title"
                            >{{ title }}
                          </el-checkbox-button>
                        </el-checkbox-group>
                      </div>
                    </div>
                    <template v-if="obj.judge == 8">
                      <span style="padding-left: 15px;">{{ obj.normalName }} </span>
                      <el-popover placement="right" width="120" trigger="hover">
                        <template slot="reference">
                          <el-radio-group
                            v-model="checkboxGroup1"
                            size="medium"
                            fill="#97a8be"
                          >
                            <el-radio-button :label="'1'">致命</el-radio-button>
                            <el-radio-button :label="'2'">非致命</el-radio-button>
                          </el-radio-group>
                        </template>
                        <p>{{ obj.normalContent || '无' }}</p>
                      </el-popover>
                      <el-popover trigger="hover" placement="right">
                        <template slot="reference">
                          <i class="el-icon-warning" style="color: red"></i>
                        </template>
                        <p>选中致命项则总分为<font color="red"> 零</font></p>
                      </el-popover>
                    </template>
                  </div>
                </div>
                <div v-else></div>
              </div>
            </div>
          </div>
          <div style="clear: both"></div>
          <div class="border"></div>
          <div class="total">
            总分:<label>{{ this.totalScores }}</label>
          </div>
        </div>
      </el-dialog>
      <div class="autoGrading-body">
        <el-tabs v-model="activeName" type="border-card">
          <el-tab-pane label="自动打分" name="first">
            <div class="autoGrading-left">
              <div class="item">
                <a>
                  <el-button icon="el-icon-plus" @click="addTree"></el-button>
                  <el-button icon="el-icon-edit" @click="editTree"></el-button>
                  <el-button icon="el-icon-close" @click="delTree"></el-button>
                </a>
                <el-dialog
                  :close-on-click-modal="false"
                  @close="cancel"
                  title="新增分类"
                  :visible.sync="dialogTreeFormVisible"
                >
                  <el-form :model="addTreeForm" ref="addTreeForm" :rules="treeFormRules">
                    <el-form-item
                      label="当前类别："
                      prop="typeid"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        :disabled="true"
                        v-model="addTreeForm.typeid"
                      ></el-input>
                    </el-form-item>
                    <el-form-item
                      label="类别名称"
                      prop="classTitle"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        v-model="addTreeForm.classTitle"
                      ></el-input>
                    </el-form-item>
                    <el-form-item
                      label="备注"
                      prop="remark"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        v-model="addTreeForm.remark"
                      ></el-input>
                    </el-form-item>
                  </el-form>
                  <div slot="footer" class="dialog-footer">
                    <el-button @click="cancel">取 消</el-button>
                    <el-button type="primary" @click="saveClassThrottle">确 定</el-button>
                  </div>
                </el-dialog>
                <el-dialog
                  :close-on-click-modal="false"
                  @close="editCancel"
                  title="修改分类"
                  :visible.sync="editTreeModal"
                >
                  <el-form
                    :model="editTreeForm"
                    ref="editTreeForm"
                    :rules="editTreeRules"
                  >
                    <el-form-item
                      label="当前类别："
                      prop="typeid"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        :disabled="true"
                        v-model="editTreeForm.typeid"
                      ></el-input>
                    </el-form-item>
                    <el-form-item
                      label="类别名称"
                      prop="classTitle"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        v-model="editTreeForm.classTitle"
                      ></el-input>
                    </el-form-item>
                    <el-form-item
                      label="备注"
                      prop="remark"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        v-model="editTreeForm.remark"
                      ></el-input>
                    </el-form-item>
                  </el-form>
                  <div slot="footer" class="dialog-footer">
                    <el-button @click="editCancel">取 消</el-button>
                    <el-button type="primary" @click="editSaveClassThrottle"
                      >确 定</el-button
                    >
                  </div>
                </el-dialog>
              </div>
              <div class="typeList">
                <el-tree
                  :data="leftTreeData"
                  :props="defaultProps"
                  ref="funTree"
                  :filter-node-method="filterNode"
                  node-key="id"
                  highlight-current
                  default-expand-all
                  @node-click="nodeClick"
                  :expand-on-click-node="false"
                >
                </el-tree>
              </div>
            </div>
            <div class="autoGrading-right">
              <div class="bodys">
                <div class="autoGrading-right-header">
                  <el-form
                    :inline="true"
                    :model="formInlineAuto"
                    class="demo-form-inline"
                  >
                    <el-form-item label="">
                      <el-input
                        class="m10"
                        v-model="formInlineAuto.normalName"
                        placeholder="请输入标准名称"
                      ></el-input>
                    </el-form-item>
                    <el-form-item>
                      <el-button class="m10" @click="searchByName">查询</el-button>
                    </el-form-item>
                    <el-form-item style="float: right">
                      <el-button class="m10" type="primary" @click="addManualAuto"
                        >新增标准</el-button
                      >
                      <el-button class="m10" @click="batchDelete">批量删除</el-button>
                    </el-form-item>
                  </el-form>
                </div>
                <el-dialog
                  :close-on-click-modal="false"
                  @close="addTableCanel"
                  :title="myTitle"
                  :visible.sync="dialogFormVisible"
                  size="medium"
                >
                  <el-form
                    :rules="tableFormRules"
                    :label-position="labelPosition"
                    label-width="120px"
                    :model="addForm"
                    ref="addForm"
                    :inline="true"
                    style="height: 400px; overflow: auto"
                  >
                    <el-form-item label="打分标准名称" prop="normalName">
                      <el-input
                        v-model="addForm.normalName"
                        :disabled="showDisabled"
                      ></el-input>
                    </el-form-item>
                    <el-form-item label="选择打分方式" prop="judge">
                      <el-select
                        v-model="addForm.judge"
                        :disabled="showDisabled"
                        placeholder="请选择"
                        @change="optionChange"
                      >
                        <el-option
                          v-for="item in options2"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"
                        >
                        </el-option>
                      </el-select>
                    </el-form-item>
                    <el-form-item label="默认分数" prop="defaultScore">
                      <el-input
                        :maxlength="2"
                        v-model="addForm.defaultScore"
                        :disabled="mingScoreDisabled"
                      ></el-input>
                    </el-form-item>
                    <div id="qingxu" v-show="judgeAuto === 1" style="cursor: pointer">
                      <el-row>
                        <el-col :span="24">
                          <el-form-item
                            v-for="(domain, index) in addForm.domainsParamsQing.domains"
                            :key="domain.key"
                          >
                            <el-input
                              :disabled="showDisabled"
                              placeholder="分"
                              :maxlength="2"
                              v-model="domain.silenceTimeMin"
                              class="w120"
                            ></el-input>
                            <label>分</label>
                            <div
                              class="el-form-item__error"
                              id="inputErrorShow"
                              style="display: none"
                            >
                              请输入整数
                            </div>
                            <label class="ml">-</label>
                            <el-input
                              :disabled="showDisabled"
                              placeholder="分"
                              :maxlength="2"
                              v-model="domain.silenceTimeMax"
                              class="w120"
                            ></el-input>
                            <label>分</label>
                            <div
                              class="el-form-item__error"
                              id="inputErrorShowMax"
                              style="display: none"
                            >
                              请输入整数
                            </div>
                            <label class="ml">得分</label>
                            <el-input
                              :disabled="showDisabled"
                              :maxlength="2"
                              v-model="domain.score"
                              class="w120"
                            ></el-input>
                            <a v-if="myTitle != '查看标准'">
                              <i @click="addDomainQing" class="el-icon-plus ml"></i>
                              <i
                                v-show="index > 0"
                                class="el-icon-minus"
                                @click.prevent="removeDomainQing(index)"
                              ></i>
                            </a>
                            <a v-else=""></a>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </div>
                    <div
                      id="chongfu"
                      v-show="judgeAuto === 2"
                      style="display: none; cursor: pointer"
                    >
                      <el-row>
                        <el-col :span="24">
                          <el-form-item
                            v-for="(domain, index) in addForm.chongDomains.domains"
                            :key="index"
                          >
                            <div class="demo-input-size">
                              <el-input
                                :disabled="showDisabled"
                                :maxlength="2"
                                placeholder="次"
                                v-model="domain.silenceTimeMin"
                                class="w120"
                              ></el-input>
                              <label>次</label>
                              <label class="ml">-</label>
                              <el-input
                                :disabled="showDisabled"
                                :maxlength="2"
                                placeholder="次"
                                class="w120"
                                v-model="domain.silenceTimeMax"
                              ></el-input>
                              <label>次</label>
                              <label class="ml">得分</label>
                              <el-input
                                :disabled="showDisabled"
                                :maxlength="2"
                                class="w120"
                                v-model="domain.score"
                              ></el-input>
                              <a v-if="myTitle != '查看标准'">
                                <i @click="addChongDomain" class="el-icon-plus ml"></i>
                                <i
                                  v-show="index > 0"
                                  class="el-icon-minus"
                                  @click.prevent="removeChongDomain(index)"
                                ></i>
                              </a>
                              <a v-else></a>
                            </div>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </div>
                    <div
                      id="jingmo"
                      v-show="judgeAuto === 3"
                      style="display: none; cursor: pointer"
                    >
                      <el-row>
                        <el-col :span="24">
                          <el-form-item label="静默类型">
                            <el-radio-group
                              :disabled="showDisabled"
                              v-model="addForm.silenceType"
                              @change="changeRadio"
                            >
                              <el-radio class="radio" :label="1" value="1"
                                >总时长</el-radio
                              >
                              <el-radio class="radio" :label="2" value="2"
                                >总次数</el-radio
                              >
                              <el-radio class="radio" :label="3" value="3">占比</el-radio>
                              <el-radio class="radio" :label="4" value="4"
                                >平均时长</el-radio
                              >
                              <el-radio class="radio" :label="5" value="5"
                                >最长静默</el-radio
                              >
                            </el-radio-group>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <div id="nums">
                        <el-row>
                          <el-col :span="24">
                            <el-form-item
                              v-for="(domain, index) in addForm.jingDomains.domains"
                              :key="index"
                              prop="domains"
                            >
                              <div class="demo-input-size">
                                <el-input
                                  :disabled="showDisabled"
                                  :maxlength="2"
                                  class="w120"
                                  v-model="domain.silenceTimeMin"
                                ></el-input>
                                <label>{{ numsTitle }}</label>
                                <label class="ml">-</label>
                                <el-input
                                  :disabled="showDisabled"
                                  :maxlength="2"
                                  class="w120"
                                  v-model="domain.silenceTimeMax"
                                ></el-input>
                                <label>{{ numsTitle }}</label>
                                <label class="ml">得分</label>
                                <el-input
                                  :disabled="showDisabled"
                                  :maxlength="2"
                                  class="w120"
                                  v-model="domain.score"
                                ></el-input>
                                <a v-if="myTitle != '查看标准'">
                                  <i @click="addJingDomain" class="el-icon-plus ml"></i>
                                  <i
                                    v-show="index > 0"
                                    class="el-icon-minus"
                                    @click.prevent="removeJingDomain(index)"
                                  ></i>
                                </a>
                                <a v-else></a>
                              </div>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </div>
                    </div>
                    <div
                      id="yusu"
                      v-show="judgeAuto === 4"
                      style="display: none; cursor: pointer"
                    >
                      <el-row>
                        <el-col :span="24">
                          <el-form-item label="语速类型">
                            <el-radio-group
                              :disabled="showDisabled"
                              v-model="addForm.speedType"
                            >
                              <el-radio class="radio" :label="1" value="1"
                                >平均语速</el-radio
                              >
                              <el-radio class="radio" :label="2" value="2"
                                >最快语速</el-radio
                              >
                            </el-radio-group>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="24">
                          <el-form-item
                            v-for="(domain, index) in addForm.domainsParamsYu.domains"
                            :key="index"
                            prop="domains"
                          >
                            <div class="demo-input-size">
                              <el-input
                                :disabled="showDisabled"
                                :maxlength="2"
                                placeholder="字/秒"
                                v-model="domain.minWord"
                                class="w120"
                              ></el-input>
                              <a>字/秒</a>
                              <label class="ml">-</label>
                              <el-input
                                :disabled="showDisabled"
                                :maxlength="2"
                                class="w120"
                                v-model="domain.maxWord"
                                placeholder="字/秒"
                              ></el-input>
                              <a>字/秒 </a>
                              <label class="ml" style=" margin-right: 10px;">得分</label>
                              <el-input
                                :disabled="showDisabled"
                                :maxlength="2"
                                v-model="domain.score"
                                style="width: 60px"
                              ></el-input>
                              <a v-if="myTitle != '查看标准'">
                                <i @click="addDomainYu" class="el-icon-plus ml"></i>
                                <i
                                  v-show="index > 0"
                                  class="el-icon-minus"
                                  @click.prevent="removeDomainYu(index)"
                                ></i>
                              </a>
                              <a v-else></a>
                            </div>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </div>
                    <div
                      id="guanjianci"
                      v-show="judgeAuto === 5"
                      style="display: none; cursor: pointer"
                    >
                      <el-form-item label="分值范围" prop="minScoreRange">
                        <el-input
                          :disabled="mingScoreDisabled"
                          :maxlength="2"
                          class="w120"
                          v-model="addForm.minScoreRange"
                        ></el-input>
                        <label>-</label>
                      </el-form-item>
                      <el-form-item prop="maxScoreRange">
                        <el-input
                          :disabled="mingScoreDisabled"
                          :maxlength="2"
                          class="w120"
                          v-model="addForm.maxScoreRange"
                        ></el-input>
                      </el-form-item>
                      <el-form-item label="评分类型" prop="scoreType">
                        <el-select
                          :disabled="showDisabled"
                          v-model="addForm.scoreType"
                          style="width:90px"
                          @change="changeScoreType"
                        >
                          <el-option label="得分" :value="1"></el-option>
                          <el-option label="静默" :value="2"></el-option>
                        </el-select>
                      </el-form-item>
                      <el-form-item
                        label="位置"
                        v-show="this.showScoreType"
                        prop="position"
                      >
                        <el-select
                          :disabled="showDisabled"
                          v-model="addForm.position"
                          @change="changePosition"
                        >
                          <el-option label="全文" value="3"></el-option>
                          <el-option label="开头" value="1"></el-option>
                          <el-option label="结尾" value="2"></el-option>
                        </el-select>
                      </el-form-item>
                      <el-form-item
                        prop="offset"
                        v-show="this.showScoreType && addForm.position !== '3'"
                      >
                        <el-input
                          :disabled="showDisabled"
                          v-show="showOffset"
                          class="w120"
                          v-model="addForm.offset"
                        ></el-input>
                        <i v-show="showOffset">句</i>
                      </el-form-item>
                      <el-form-item
                        label="是否致命"
                        prop="deadItem"
                        v-show="this.showScoreType"
                      >
                        <el-select
                          :disabled="showDisabled"
                          v-model="addForm.deadItem"
                          style="width:70px"
                          @change="changeDeadItem"
                        >
                          <el-option label="是" value="1"></el-option>
                          <el-option label="否" value="2"></el-option>
                        </el-select>
                      </el-form-item>
                      <el-row>
                        <el-col :span="24">
                          <el-form-item
                            label="静默类型"
                            v-show="this.showJingmoType"
                            prop="keywordSilenceType"
                          >
                            <el-select
                              :disabled="showDisabled"
                              v-model="addForm.keywordSilenceType"
                              style="width:80px"
                              @change="changeSilenceType"
                            >
                              <el-option label="时长" :value="1"></el-option>
                              <el-option label="次数" :value="2"></el-option>
                            </el-select>
                          </el-form-item>
                          <el-form-item
                            label="时间"
                            prop="timeMin"
                            v-show="this.showJingmoType && this.showSilenceType"
                          >
                            <el-input
                              :disabled="showDisabled"
                              :maxlength="4"
                              class="w120"
                              v-model="addForm.timeMin"
                            ></el-input>
                            <label class="ml">-</label>
                          </el-form-item>
                          <el-form-item
                            prop="timeMax"
                            v-show="this.showJingmoType && this.showSilenceType"
                          >
                            <el-input
                              :disabled="showDisabled"
                              :maxlength="4"
                              class="w120"
                              v-model="addForm.timeMax"
                            ></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="24">
                          <el-form-item
                            label="场景"
                            v-show="this.showJingmoType"
                            prop="sceneTime"
                          >
                            <el-input
                              :disabled="showDisabled"
                              :maxlength="4"
                              class="w120"
                              v-model="addForm.sceneTime"
                            ></el-input>
                            <label>次</label>
                          </el-form-item>
                          <el-form-item prop="sceneType" v-show="this.showJingmoType">
                            <el-select
                              :disabled="showDisabled"
                              style="width: 80px;"
                              v-model="addForm.sceneType"
                            >
                              <el-option label="之前" :value="1"></el-option>
                              <el-option label="之后" :value="2"></el-option>
                            </el-select>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="24">
                          <el-form-item
                            label="场景数值"
                            v-show="this.showJingmoType"
                            prop="sceneValue"
                          >
                            <el-input
                              :disabled="showDisabled"
                              :maxlength="4"
                              style="width: 80px"
                              v-model="addForm.sceneValue"
                            ></el-input>
                          </el-form-item>
                          <el-form-item
                            v-show="this.showJingmoType"
                            prop="sceneValueType"
                          >
                            <el-select
                              :disabled="showDisabled"
                              style="width: 80px"
                              v-model="addForm.sceneValueType"
                            >
                              <el-option label="秒" :value="1"></el-option>
                              <el-option label="句" :value="2"></el-option>
                            </el-select>
                          </el-form-item>
                          <el-form-item>
                            <el-form-item label="命中得分" prop="mingScore">
                              <el-input
                                :disabled="mingScoreDisabled"
                                ref="mingScore"
                                :maxlength="2"
                                v-model="addForm.mingScore"
                              ></el-input>
                            </el-form-item>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="24">
                          <el-form-item label="关键词组合" prop="keywordContext">
                            <a class="termRules" @click="showkeyRules">术语规则</a>
                            <textarea
                              :disabled="showDisabled"
                              id="keylists"
                              style="width: 540px;"
                              v-model="addForm.keywordContext"
                            ></textarea>
                            <!--<div  id="keylists"  style="width: 550px;" ></div>-->
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-form-item>
                        <div class="keys">
                          <label class="keylabel" @click="insertAtCursor('OR')">OR</label>
                          <label class="keylabel" @click="insertAtCursor('AND')"
                            >AND</label
                          >
                          <label class="keylabel" @click="insertAtCursor('NOT')"
                            >NOT</label
                          >
                          <label class="keylabel" @click="insertAtCursor('NEAR')"
                            >NEAR</label
                          >
                          <label class="keylabel" @click="insertAtCursor('AFTER')"
                            >AFTER</label
                          >
                          <label class="keylabel" @click="insertAtCursor('BEFORE')"
                            >BEFORE</label
                          >
                          <label class="keylabel" @click="insertAtCursor('()')">()</label>
                          <el-radio-group
                            :disabled="showDisabled"
                            v-model="addForm.roleType"
                            @change="changeRadioRole"
                            style="padding-left: 10px"
                          >
                            <el-radio :label="1" value="1">客户</el-radio>
                            <el-radio :label="2" value="2">客服</el-radio>
                            <el-radio :label="3" value="3">全部</el-radio>
                          </el-radio-group>
                        </div>
                      </el-form-item>
                    </div>
                  </el-form>
                  <div slot="footer" class="dialog-footer" v-if="myTitle != '查看标准'">
                    <el-button @click="addTableCanel">取 消</el-button>
                    <el-button type="primary" @click="addTableYesThrottle"
                      >确 定</el-button
                    >
                  </div>
                  <div slot="footer" v-else class="dialog-footer">
                    <el-button @click="addTableCanel">关闭</el-button>
                  </div>
                  <div
                    id="keyRules"
                    style="position: absolute;background: #fff"
                    v-show="showKeyRules"
                  >
                    <p>
                      1.“AND” 关键字表示“与“的关系，可以匹配到同时存在关键字左右两个关键词
                    </p>
                    <p>
                      2.“OR”关键字表示“或”的关系，可以匹配到存在关键字左右其中至少一个关键词
                    </p>
                    ";
                    <p>3.“NOT”关键字表示“非”的关系，可以匹配到不存在关键字右侧的关键词</p>
                    ;
                    <p>
                      4.“BEFORE”关键字表示有先后顺序“临近”的关系，可以匹配到存在关键字右侧的关键词且之前的n个词内会存在关键字左侧的关键词
                    </p>
                    ;
                    <p>
                      5.“AFTER”关键字表示有先后顺序“临近”的关系，可以匹配到存在关键字右侧的关键词且之后的n个词内会存在关键字左侧的关键词
                    </p>
                    ;
                    <p>6.“NEAR”关键字表示有“临近”的关系</p>
                    ;
                    <p>7.“()”可以在括号中使用以上关键字并提高关键字的匹配优先级</p>
                    ;
                  </div>
                </el-dialog>
                <div class="autoGrading-content">
                  <div class="autoGrading-right-table" style="overflow: auto">
                    <el-table
                      ref="multipleTable"
                      border
                      highlight-current-row
                      :data="tableRightData"
                      @cell-click="rowClickTable"
                      @row-click="rowClickTable"
                      @selection-change="selectAll"
                      style="margin: 10px;"
                    >
                      <el-table-column type="selection" width="50"> </el-table-column>
                      <el-table-column type="index" label="序号" width="70">
                      </el-table-column>
                      <el-table-column prop="normalName" sortable label="标准名称">
                      </el-table-column>
                      <el-table-column prop="judge" sortable label="评分方式">
                        <template scope="scope">
                          <div v-if="scope.row.judge === 1">情绪</div>
                          <div v-else-if="scope.row.judge === 2">重叠次数</div>
                          <div v-else-if="scope.row.judge === 3">静默</div>
                          <div v-else-if="scope.row.judge === 4">语速</div>
                          <div v-else="">关键词</div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        prop="createTime"
                        :formatter="format"
                        sortable
                        label="创建时间"
                      >
                      </el-table-column>
                      <el-table-column width="230" label="操作">
                        <template scope="scope">
                          <i
                            class="el-icon-edit ml"
                            @click="editNormalInfo(scope.row.normalId, 1)"
                            ><i style="padding-left: 3px;">编辑</i></i
                          >
                          <i
                            class="el-icon-close ml"
                            @click="
                              delNormalInfo(scope.row.normalId, scope.row.normalName)
                            "
                            ><i style="padding-left: 3px;">删除</i></i
                          >
                          <i
                            class="el-icon-search ml"
                            @click="editNormalInfo(scope.row.normalId, 2)"
                            ><i style="padding-left: 3px;">查看</i></i
                          >
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                  <div class="autoGrading-page">
                    <el-pagination
                      @size-change="handleSizeChange"
                      @current-change="handleCurrentChange"
                      :current-page="pageindex"
                      :page-sizes="[20, 30, 40]"
                      :page-size="pagesize"
                      layout="total, sizes, prev, pager, next, jumper"
                      :total="totalCount"
                    >
                    </el-pagination>
                  </div>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="人工打分" name="second">
            <div class="autoGrading-left">
              <div class="item">
                <a>
                  <el-button icon="el-icon-plus" @click="addMMTree"></el-button>
                  <el-button icon="el-icon-edit" @click="editMMTree"></el-button>
                  <el-button icon="el-icon-close" @click="delMMTree"></el-button>
                </a>
                <el-dialog
                  :close-on-click-modal="false"
                  @close="cancalMunaul"
                  title="新增分类"
                  :visible.sync="dialogTreeFormVisibleMan"
                >
                  <el-form
                    :model="addTreeManual"
                    ref="addTreeManual"
                    :rules="treeFormRules"
                  >
                    <el-form-item
                      label="当前类别："
                      prop="typeid"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        :disabled="true"
                        v-model="addTreeManual.typeid"
                      ></el-input>
                    </el-form-item>
                    <el-form-item
                      label="类别名称"
                      prop="classTitle"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        v-model="addTreeManual.classTitle"
                      ></el-input>
                    </el-form-item>
                    <el-form-item
                      label="备注"
                      prop="remark"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        v-model="addTreeManual.remark"
                      ></el-input>
                    </el-form-item>
                  </el-form>
                  <div slot="footer" class="dialog-footer">
                    <el-button @click="cancalMunaul">取 消</el-button>
                    <el-button type="primary" @click="saveClassTwoThrottle"
                      >确 定</el-button
                    >
                  </div>
                </el-dialog>
                <el-dialog
                  :close-on-click-modal="false"
                  @close="editCancelArtificial"
                  title="修改分类"
                  :visible.sync="manualEditTreeModal"
                >
                  <el-form
                    :model="manualEditTreeForm"
                    ref="manualEditTreeForm"
                    :rules="editTreeRules"
                  >
                    <el-form-item
                      label="当前类别："
                      prop="typeid"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        :disabled="true"
                        v-model="manualEditTreeForm.typeid"
                      ></el-input>
                    </el-form-item>
                    <el-form-item
                      label="类别名称"
                      prop="classTitle"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        v-model="manualEditTreeForm.classTitle"
                      ></el-input>
                    </el-form-item>
                    <el-form-item
                      label="备注"
                      prop="remark"
                      :label-width="formLabelWidth"
                    >
                      <el-input
                        style="width:220px"
                        v-model="manualEditTreeForm.remark"
                      ></el-input>
                    </el-form-item>
                  </el-form>
                  <div slot="footer" class="dialog-footer">
                    <el-button @click="editCancelArtificial">取 消</el-button>
                    <el-button type="primary" @click="editSaveClassTwoThrottle"
                      >确 定</el-button
                    >
                  </div>
                </el-dialog>
              </div>
              <div class="typeList">
                <el-tree
                  :data="leftMMTreeData"
                  :props="defaultProps"
                  ref="funTree"
                  :filter-node-method="filterNode"
                  node-key="id"
                  highlight-current
                  default-expand-all
                  @node-click="nodeClickAuto"
                  :expand-on-click-node="false"
                >
                </el-tree>
              </div>
            </div>
            <div class="autoGrading-right">
              <div class="bodys">
                <div class="autoGrading-right-header">
                  <el-form
                    :inline="true"
                    :model="formInlineArtificial"
                    class="demo-form-inline"
                  >
                    <el-form-item label="">
                      <el-input
                        class="m10"
                        v-model="formInlineArtificial.user"
                        placeholder="请输入标准名称"
                      ></el-input>
                    </el-form-item>
                    <el-form-item>
                      <el-button class="m10" @click="searchByNameMan">查询</el-button>
                    </el-form-item>
                    <el-form-item style="float: right">
                      <el-button class="m10" type="primary" @click="addManualMan"
                        >新增标准</el-button
                      >
                      <el-button class="m10" @click="batchDeleteMan">批量删除</el-button>
                    </el-form-item>
                  </el-form>
                </div>
                <el-dialog
                  :close-on-click-modal="false"
                  @close="closeModel"
                  :title="standardTitle"
                  :visible.sync="dialogFormVisibleMan"
                >
                  <el-form
                    :rules="addManualFormRules"
                    :label-position="labelPosition"
                    label-width="120px"
                    :model="AddTableFormMan"
                    ref="AddTableFormMan"
                    :inline="true"
                    style="height: 400px; overflow: auto"
                  >
                    <el-form-item label="打分标准名称" prop="normalName">
                      <el-input
                        :disabled="showDisabledMan"
                        v-model="AddTableFormMan.normalName"
                      ></el-input>
                    </el-form-item>
                    <el-form-item label="选择打分方式" prop="judge">
                      <el-select
                        v-model="AddTableFormMan.judge"
                        :disabled="showDisabledMan"
                        placeholder="请输入打分方式"
                        @change="optionChangeArtificial"
                      >
                        <el-option
                          v-for="item in options3"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"
                        >
                        </el-option>
                      </el-select>
                    </el-form-item>
                    <div v-show="artificialJudge === 6" id="shoudong">
                      <el-form-item label="分值范围" prop="minScoreRange">
                        <el-input
                          :disabled="showDisabledMan"
                          :maxlength="2"
                          class="w120"
                          v-model="AddTableFormMan.minScoreRange"
                        ></el-input>
                        <label>-</label>
                      </el-form-item>
                      <el-form-item prop="maxScoreRange">
                        <el-input
                          :disabled="showDisabledMan"
                          :maxlength="2"
                          class="w120"
                          v-model="AddTableFormMan.maxScoreRange"
                        ></el-input>
                      </el-form-item>
                      <el-form-item label="默认分数" prop="defaultScore">
                        <el-input
                          :disabled="showDisabledMan"
                          :maxlength="2"
                          v-model="AddTableFormMan.defaultScore"
                        ></el-input>
                      </el-form-item>
                      <el-form-item label="评分标准" prop="normalContent">
                        <el-input
                          :disabled="showDisabledMan"
                          :rows="6"
                          style="width: 450px"
                          type="textarea"
                          v-model="AddTableFormMan.normalContent"
                        ></el-input>
                      </el-form-item>
                    </div>
                    <div v-show="artificialJudge === 7" id="xuanxiang">
                      <el-row>
                        <el-col :span="24">
                          <el-form-item
                            label="选项"
                            v-for="(domain, index) in AddTableFormMan.xuanDomains.domains"
                            :key="index"
                            prop="domains"
                          >
                            <el-input
                              :disabled="showDisabledMan"
                              placeholder="请输入"
                              v-model="domain.optionTexts"
                              style="width: 300px"
                            ></el-input>
                            <i
                              @click="addDomainMan"
                              class="el-icon-plus ml"
                              style="margin-left: 10px"
                            ></i>
                            <i
                              v-show="index > 0"
                              class="el-icon-minus"
                              @click.prevent="removeDomainMan(domain)"
                            ></i>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-form-item label="评分规则">
                        <el-input
                          :disabled="showDisabledMan"
                          :rows="6"
                          style="width: 450px"
                          type="textarea"
                          v-model="AddTableFormMan.normalContent"
                        ></el-input>
                      </el-form-item>
                    </div>
                    <div v-show="artificialJudge === 8" id="zhimingxiang">
                      <el-row>
                        <el-col :span="24">
                          <el-form-item label="致命项标准">
                            <el-input
                              :disabled="showDisabledMan"
                              :rows="6"
                              type="textarea"
                              style="width: 450px"
                              v-model="AddTableFormMan.normalContent"
                            ></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </div>
                  </el-form>
                  <div
                    slot="footer"
                    class="dialog-footer"
                    v-if="this.standardTitle != '查看标准'"
                  >
                    <el-button @click="addTableCanelAuto">取 消</el-button>
                    <el-button type="primary" @click="addTableYesAutoThrottle"
                      >确 定</el-button
                    >
                  </div>
                  <div v-else slot="footer" class="dialog-footer">
                    <el-button @click="closeModel">关闭</el-button>
                  </div>
                </el-dialog>
                <div class="autoGrading-content">
                  <div class="autoGrading-right-table" style="overflow: auto">
                    <el-table
                      border
                      highlight-current-row
                      :data="tableDataMan"
                      ref="multipleTableMan"
                      style="margin: 10px;"
                      @selection-change="selectAllMan"
                      @row-click="rowClickTableMan"
                    >
                      <el-table-column type="selection" width="50"> </el-table-column>
                      <el-table-column type="index" label="序号" width="70">
                      </el-table-column>
                      <el-table-column prop="normalName" sortable label="标准名称">
                      </el-table-column>
                      <el-table-column prop="judge" sortable label="评分方式">
                        <template scope="scope">
                          <div v-if="scope.row.judge === 6">手动打分</div>
                          <div v-else-if="scope.row.judge === 7">选项</div>
                          <div v-else>致命项</div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        prop="createTime"
                        sortable
                        :formatter="format"
                        label="创建时间"
                      >
                      </el-table-column>
                      <el-table-column label="操作">
                        <template scope="scope">
                          <i
                            class="el-icon-edit"
                            @click="
                              editManualTitle(
                                scope.row.classId,
                                scope.row.normalId,
                                1,
                                scope.row.judge
                              )
                            "
                            ><i>编辑</i></i
                          >
                          <i
                            class="el-icon-close"
                            @click="
                              deleteManualMan(scope.row.normalId, scope.row.normalName)
                            "
                            style="margin-left: 5px;"
                            ><i>删除</i></i
                          >
                          <i
                            class="el-icon-search"
                            @click="
                              editManualTitle(
                                scope.row.classId,
                                scope.row.normalId,
                                2,
                                scope.row.judge
                              )
                            "
                            style="margin-left: 5px;"
                            ><i>查看</i></i
                          >
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                  <div class="autoGrading-page">
                    <el-pagination
                      @size-change="handleSizeChangeAuto"
                      @current-change="handleCurrentChangeAuto"
                      :current-page="pageindexAuto"
                      :page-sizes="[20, 30, 40]"
                      :page-size="pagesizeAuto"
                      layout="total, sizes, prev, pager, next, jumper"
                      :total="totalCountMan"
                    >
                    </el-pagination>
                  </div>
                </div>
              </div>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import $ from 'jquery'
import Qs from 'qs'
import global from '../../../global.js'
let manalScore = global.qualityUrl
import formatdate from '../../../utils/formatdate.js'
export default {
  props: ['modleIdNew', 'mdtitle', 'info'],
  data() {
    /**
     * 合格分数验证
     * **/
    const validQualityScore = (rule, value, callback) => {
      let param = /^[0-9]{1,3}$/
      if (value == '') {
        callback()
      } else if (!param.test(value)) {
        callback(new Error('请输入正确的分数'))
      } else {
        callback()
      }
    }
    const validclassTitle = (rule, value, callback) => {
      let param = /^[a-zA-Z0-9\u4e00-\u9fa5]+$/
      if (value.length > 50) {
        callback(new Error('分类名称长度不能大于50！'))
      } else if (!param.test(value)) {
        callback(new Error('请输入合法名称！'))
      } else {
        callback()
      }
    }
    const validremark = (rule, value, callback) => {
      if (value != null && value.length > 100) {
        callback(new Error('备注长度不能大于100！'))
      } else {
        callback()
      }
    }
    const validName = (rule, value, callback) => {
      let param = /^[a-zA-Z0-9\u4e00-\u9fa5]+$/
      if (value.length > 150) {
        callback(new Error('标准名称长度超长！'))
      } else if (!param.test(value)) {
        callback(new Error('请输入合法的标准！'))
      } else {
        callback()
      }
    }
    const validDefaultScore = (rule, value, callback) => {
      let param = RegExp('^-?\\d+$')
      this.defaultNum = value
      if (value.trim().length === 0) {
        callback(new Error('默认分数不能为空'))
      } else if (!param.test(value)) {
        callback(new Error('默认分数应为整数！'))
      }
      /* if(value>this.maxv || value<this.minv){
         callback(new Error('默认分数在分值范围内！'));
         } */
      if (value >= 100) {
        callback(new Error('默认分数应为两位数！'))
      }
      /* if(value < this.minv || value > this.maxv){
         callback(new Error('默认值必须在分数范围之内！'));
         } */
      callback()
    }
    const validScoreRange = (rule, valueMin, callback) => {
      let param = RegExp('^-?\\d+$')
      // this.minv=valueMin;
      if (!param.test(valueMin)) {
        callback(new Error('最小值应为整数！'))
      } else if (parseInt(valueMin) > this.maxv) {
        callback(new Error('命中分数在分值范围内！'))
      } else {
        callback()
      }
    }
    const validModelTitle = (rule, value, callback) => {
      if (value.trim().length > 30) {
        callback(new Error('不能超过30个字符'))
      } else {
        callback()
      }
    }
    return {
      showJingmoType: false,
      showScoreType: false,
      showSilenceType: true,
      showDisabled: false,
      mingScoreDisabled: false,
      showDisabledMan: false,
      showOffset: false,
      checkboxGroup1: ['上海'],
      checkboxGroup3: ['广州'],
      totalScore: 0,
      typelist: [],
      options3: [
        {
          value: 6,
          label: '手动打分',
        },
        {
          value: 7,
          label: '选项',
        },
        {
          value: 8,
          label: '致命项',
        },
      ],
      options2: [
        {
          value: 1,
          label: '情绪',
        },
        {
          value: 2,
          label: '重叠次数',
        },
        {
          value: 3,
          label: '静默',
        },
        {
          value: 4,
          label: '语速',
        },
        {
          value: 5,
          label: '关键词',
        },
      ],
      standardTitle: '新增标准',
      qualityForm: {
        name: '',
      },
      tableData: [],
      resultObject: [],
      editNamesForm: {
        modleTitle: '',
        remark: '',
      },
      namesRules: {
        modleTitle: [
          {
            required: true,
            message: '请输入模板名称！',
            trigger: 'blur',
          },
          {
            validator: validModelTitle,
            trigger: 'blur',
          },
        ],
      },
      namesForm: {
        modleTitle: '',
      },
      showKeyRules: false,
      Show: false,
      isShow: true,
      addManualFormRules: {
        normalName: [
          {
            required: true,
            message: '请输入合法的标准！',
            trigger: 'blur',
          },
          {
            validator: validName,
            trigger: 'blur',
          },
        ],
      },
      tableFormRules: {
        score: [
          {
            validator: validScoreRange,
            trigger: 'blur',
          },
        ],
        normalName: [
          {
            required: true,
            message: '请输入合法的标准！',
            trigger: 'blur',
          },
          {
            validator: validName,
            trigger: 'blur',
          },
        ],
        defaultScore: [
          {
            validator: validDefaultScore,
            trigger: 'blur',
          },
        ],
      },
      minx: '',
      maxv: '',
      leftTreeData: [],
      manualTitle: '修改标准',
      formLabelWidth: '120px',
      editTreeRules: {
        classTitle: [
          {
            required: true,
            message: '请输入分类名称！',
            trigger: 'blur',
          },
          {
            validator: validclassTitle,
            trigger: 'blur',
          },
        ],
        remark: [
          {
            validator: validremark,
            trigger: 'blur',
          },
        ],
      },
      treeFormRules: {
        classTitle: [
          {
            required: true,
            message: '请输入分类名称！',
            trigger: 'blur',
          },
          {
            validator: validclassTitle,
            trigger: 'blur',
          },
        ],
        remark: [
          {
            validator: validremark,
            trigger: 'blur',
          },
        ],
      },
      addTreeForm: {
        classTitle: '',
        remark: '',
        classId: '',
        modleId: '',
        typeid: '',
        parentClassId: '',
      },
      addTreeManual: {
        classTitle: '',
        remark: '',
        classId: '',
        modleId: '',
        typeid: '',
        parentClassId: '',
      },
      editTreeForm: {
        classTitle: '',
        remark: '',
        classId: '',
        modleId: '',
        typeid: '',
        parentClassId: '',
      },
      manualEditTreeForm: {
        classTitle: '',
        remark: '',
        classId: '',
        modleId: '',
        typeid: '',
        parentClassId: '',
      },
      editManualSModel: false,
      dialogTreeFormVisible: false,
      dialogTreeFormVisibleMan: false,
      defaultProps: {
        children: 'children',
        label: 'label',
      },
      activeName: 'first',
      formInline: {
        modleTitle: '',
        qualityScore: '',
        modleType: 7,
        status: 1,
      },
      formInlineAuto: {
        normalName: '',
        region: '',
      },
      formInlineArtificial: {
        user: '',
        region: '',
      },
      tableDataMan: [],
      totalCountMan: 0,
      pageindexAuto: 1,
      pagesizeAuto: 20,
      tableRightData: [],
      dialogFormVisible: false,
      dialogFormVisibleMan: false,
      addForm: {
        domainsParamsQing: {
          domains: [
            {
              silenceTimeMin: '',
              silenceTimeMax: '',
              score: '',
            },
          ],
        },
        chongDomains: {
          domains: [
            {
              silenceTimeMin: '',
              silenceTimeMax: '',
              score: '',
            },
          ],
        },
        jingDomains: {
          domains: [
            {
              silenceTimeMin: '',
              silenceTimeMax: '',
              score: '',
            },
          ],
        },
        domainsParamsYu: {
          domains: [{ minWord: '', maxWord: '', score: '' }],
        },
        judge: 1,
        roleType: 1,
        normalName: '',
        normalContent: '',
        keywordContext: '',
        defaultScore: '',
        minScoreRange: '',
        maxScoreRange: '',
        modleType: 7,
        silenceTimeMin: '',
        silenceTimeMax: '',
        mingScore: '',
        silenceType: 1,
        deadItem: '2',
        scoreType: 1,
        position: '3',
        offset: '',
        keywordSilenceType: 1,
        timeMin: '',
        timeMax: '',
        sceneTime: '',
        sceneType: 1,
        sceneValue: '',
        sceneValueType: 1,
        speedType: 1,
        isAppear: 1
      },
      AddTableFormMan: {
        xuanDomains: {
          domains: [{ optionTexts: '' }],
        },
        normalName: '',
        defaultScore: '',
        minScoreRange: '',
        maxScoreRange: '',
        roleType: 1,
        keywordContext: '',
        normalContent: '',
        scoringRules: '',
        judge: 6,
        modleType: 7,
        status: 1,
        silenceTimeMin: '',
        silenceTimeMax: '',
        score: '',
        scoreType: 1,
      },
      radio: '1',
      formRules: {
        modleTitle: [{ required: true, message: '请输入模板名称', trigger: 'blur' }],
        qualityScore: [
          { required: true, message: '合格分数不能为空', trigger: 'change' },
          { validator: validQualityScore, trigger: 'blur' },
        ],
      },
      labelPosition: 'right',
      isTrue: false,
      treeTitle: '',
      operationTitle: '',
      treeid: '',
      clist: [],
      editTreeModal: false,
      totalCount: 0,
      pageindex: 1,
      pagesize: 20,
      current: 1,
      pid: '',
      pidMan: '',
      leftMMTreeData: [],
      normalId: '',
      editModalTable: false,
      editTitle: '修改模板',
      previewModel: false,
      isBatch: false,
      normalIds: '',
      norNameList: '',
      selectionNums: 0,
      norNameListMan: '',
      selectionNumsMan: 0,
      handleIconModel: false,
      lookModalTable: false,
      lookStandardForm: {
        judge: '',
        normalName: '',
        normalContent: '',
        defaultScore: '',
        minScoreRange: '',
        maxScoreRange: '',
        modleType: 7,
        silenceTimeMin: '',
        silenceTimeMax: '',
        score: '',
      },
      manualEditTreeModal: false,
      treeIdMan: '',
      typeIdMan: '',
      cListMan: [],
      score: ['1', '2'],
      typeid: '',
      normalIdMan: '',
      isBatchMan: false,
      normalIdsMan: '',
      judge: '1',
      slienceType: '1',
      roleType: '1',
      silenceTimeMin: [],
      silenceTimeMax: [],
      silenceTimeMinEdit: [],
      silenceTimeMaxEdit: [],
      judgeAuto: 1,
      silenceIds: [],
      minWordList: [],
      maxWordList: [],
      yuScore: [],
      editJudge: '1',
      qaWordspeedIds: [],
      editMaxWord: [],
      editMinWord: [],
      editScore: [],
      myTitle: '新增标准',
      qingxuJudge: '1',
      silenceTimeMinChong: [],
      silenceTimeMaxChong: [],
      scoreChong: [],
      silenceIdsChong: [],
      silenceTimeMinChongAdd: [],
      silenceTimeMaxChongAdd: [],
      scoreChongAdd: [],
      addEditJudge: 1,
      silenceTimeMinQing: [],
      silenceTimeMaxQing: [],
      scoreQing: [],
      juid: 1,
      silenceIdsQing: [],
      scoreJing: [],
      silenceTimeMaxJing: [],
      silenceTimeMinJing: [],
      selectValue: 6,
      optionTextsList: [],
      artificialJudge: 6,
      parentid: '',
      parentIdAuto: '',
      numsTitle: '秒',
      trees: [],
      totalScores: '',
      editClassId: 0,
      MinValue: 0,
      MaxValue: 0,
    }
  },
  methods: {
    // 人工打分 查看关闭
    closeModel: function() {
      let _this = this
      _this.artificialJudge = 6
      _this.standardTitle = '新增标准'
      _this.dialogFormVisibleMan = false
      _this.$refs['AddTableFormMan'].resetFields()
    },
    handleClose: function() {
      let _this = this
      _this.artificialJudge = 6
      _this.standardTitle = '新增标准'
      _this.$refs.AddTableFormMan.resetFields()
      _this.dialogFormVisibleMan = false
    },
    addTableCanelAuto: function() {
      let _this = this
      _this.$refs.AddTableFormMan.resetFields()
      _this.artificialJudge = 6
      _this.standardTitle = '新增标准'
      _this.dialogFormVisibleMan = false
    },
    // 人工打分 点击新增标准
    addManualMan: function() {
      let _this = this
      if (_this.treeIdMan === '') {
        _this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        _this.showDisabledMan = false
        _this.AddTableFormMan.normalName = ''
        _this.AddTableFormMan.judge = 6
        _this.AddTableFormMan.maxScoreRange = ''
        _this.AddTableFormMan.minScoreRange = ''
        _this.AddTableFormMan.defaultScore = ''
        _this.AddTableFormMan.normalContent = ''
        _this.dialogFormVisibleMan = true
        _this.artificialJudge = 6
        _this.AddTableFormMan.xuanDomains = {
          domains: [{ optionTexts: '' }],
        }
      }
    },
    addManualAuto: function() {
      let _this = this
      if (_this.treeid === '') {
        _this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        _this.showDisabled = false
        _this.mingScoreDisabled = false
        _this.dialogFormVisible = true
        _this.myTitle = '新增标准'
      }
    },
    /**
     * 自动打分 添加标准
     * **/
    addTableYesThrottle() {
      this.lodashThrottle.throttle(this.addTableYes, this)
    },
    addTableYes: function() {
      let _this = this
      let adJudge = _this.addEditJudge
      if (_this.myTitle === '修改标准') {
        if (adJudge === 1) {
          let dlist = _this.addForm.domainsParamsQing.domains
          let dscore = []
          for (let i = 0; i < dlist.length; i++) {
            dscore[i] = dlist[i].score
          }
          _this.scoreQing = dscore
          let dmin = []
          for (let i = 0; i < dlist.length; i++) {
            dmin[i] = dlist[i].silenceTimeMin
          }
          _this.silenceTimeMinQing = dmin
          let dmax = []
          for (let i = 0; i < dlist.length; i++) {
            dmax[i] = dlist[i].silenceTimeMax
          }
          _this.silenceTimeMaxQing = dmax
          let did = []
          for (let i = 0; i < dlist.length; i++) {
            did[i] = dlist[i].silenceIds
          }
          _this.silenceIdsQing = did
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCountK = _this.addForm.domainsParamsQing.domains.length
              let domainsK = _this.addForm.domainsParamsQing.domains
              for (let k = 0; k < domainsCountK; k++) {
                let min = domainsK[k].silenceTimeMin
                let max = domainsK[k].silenceTimeMax
                let score = domainsK[k].score
                // 循环判断silenceTimeMax要大于silenceTimeMin
                if (min === '' || max === '' || score === '') {
                  this.$message({
                    type: 'error',
                    message: '请输入合法的分值',
                  })
                  return
                } else {
                  if (isNaN(min) || isNaN(max) || isNaN(score)) {
                    this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
                    ) {
                      this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                  }
                }
              }
              let params = {
                silenceIds: _this.silenceIds,
                normalId: _this.normalId,
                normalName: _this.addForm.normalName,
                judge: adJudge,
                defaultScore: _this.addForm.defaultScore,
                silenceTimeMin: _this.silenceTimeMinQing,
                silenceTimeMax: _this.silenceTimeMaxQing,
                score: _this.scoreQing,
                modelId: _this.modleIdNew,
                classId: _this.treeid,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/operateSilence.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success == true) {
                    _this.tableRightData = res.data.Data
                    _this.totalCount = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '修改成功',
                    })
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                  _this.$refs['addForm'].resetFields()
                  _this.myTitle = '新增标准'
                  _this.dialogFormVisible = false
                  _this.getAllNormal()
                  _this.getScore()
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        } else if (adJudge === 2) {
          let clist = _this.addForm.chongDomains.domains
          let cscore = []
          for (let i = 0; i < clist.length; i++) {
            cscore[i] = clist[i].score
          }
          _this.scoreChongAdd = cscore
          let cmin = []
          for (let i = 0; i < clist.length; i++) {
            cmin[i] = clist[i].silenceTimeMin
          }
          _this.silenceTimeMinChongAdd = cmin

          let cmax = []
          for (let i = 0; i < clist.length; i++) {
            cmax[i] = clist[i].silenceTimeMax
          }
          _this.silenceTimeMaxChongAdd = cmax
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCountK = _this.addForm.chongDomains.domains.length
              let domainsK = _this.addForm.chongDomains.domains
              for (let k = 0; k < domainsCountK; k++) {
                let min = domainsK[k].silenceTimeMin
                let max = domainsK[k].silenceTimeMax
                let score = domainsK[k].score
                // 循环判断silenceTimeMax要大于silenceTimeMin
                if (min === '' || max === '' || score === '') {
                  _this.$message({
                    type: 'error',
                    message: '请输入合法的分值',
                  })
                  return
                } else {
                  if (isNaN(min) || isNaN(max) || isNaN(score)) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      _this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                  }
                }
              }
              let params = {
                silenceIds: _this.silenceIdsChong,
                normalId: _this.normalId,
                normalName: _this.addForm.normalName,
                judge: adJudge,
                defaultScore: _this.addForm.defaultScore,
                silenceTimeMin: _this.silenceTimeMinChongAdd,
                silenceTimeMax: _this.silenceTimeMaxChongAdd,
                score: _this.scoreChongAdd,
                modelId: _this.modleIdNew,
                classId: _this.treeid,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/operateSilence.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success) {
                    _this.tableRightData = res.data.Data
                    _this.totalCount = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '修改成功',
                    })
                    _this.myTitle = '新增标准'
                    _this.$refs['addForm'].resetFields()
                    _this.dialogFormVisible = false
                    _this.getAllNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        } else if (adJudge === 3) {
          let dscore = []
          let dlist = _this.addForm.jingDomains.domains
          for (let i = 0; i < dlist.length; i++) {
            dscore[i] = dlist[i].score
          }
          _this.scoreJingMan = dscore
          let dmin = []
          for (let i = 0; i < dlist.length; i++) {
            dmin[i] = dlist[i].silenceTimeMin
          }
          _this.silenceTimeMinJingMan = dmin
          let dmax = []
          for (let i = 0; i < dlist.length; i++) {
            dmax[i] = dlist[i].silenceTimeMax
          }
          _this.silenceTimeMaxJingMan = dmax
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCountK = this.addForm.jingDomains.domains.length
              let domainsK = this.addForm.jingDomains.domains
              for (let k = 0; k < domainsCountK; k++) {
                let min = domainsK[k].silenceTimeMin
                let max = domainsK[k].silenceTimeMax
                let score = domainsK[k].score
                // 循环判断silenceTimeMax要大于silenceTimeMin
                if (min === '' || max === '' || score === '') {
                  this.$message({
                    type: 'error',
                    message: '请输入合法的分值',
                  })
                  return
                } else {
                  if (isNaN(min) || isNaN(max) || isNaN(score)) {
                    this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      _this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                  }
                }
              }
              let params = {
                silenceIds: _this.silenceIds,
                normalId: _this.normalId,
                normalName: _this.addForm.normalName,
                slienceType: _this.slienceType,
                judge: adJudge,
                defaultScore: _this.addForm.defaultScore,
                silenceTimeMin: _this.silenceTimeMinJingMan,
                silenceTimeMax: _this.silenceTimeMaxJingMan,
                score: _this.scoreJingMan,
                modelId: _this.modleIdNew,
                classId: _this.treeid,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/operateSilence.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success == true) {
                    _this.tableRightData = res.data.Data
                    _this.totalCount = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '修改成功',
                    })
                    _this.myTitle = '新增标准'
                    _this.$refs['addForm'].resetFields()
                    _this.dialogFormVisible = false
                    _this.getAllNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        } else if (adJudge === 4) {
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCountK = _this.addForm.domainsParamsYu.domains.length
              let domainsK = _this.addForm.domainsParamsYu.domains
              for (let k = 0; k < domainsCountK; k++) {
                let min = domainsK[k].minWord
                let max = domainsK[k].maxWord
                let score = domainsK[k].score
                // 循环判断silenceTimeMax要大于silenceTimeMin
                if (min === '' || max === '' || score === '') {
                  this.$message({
                    type: 'error',
                    message: '请输入合法的分值',
                  })
                  return
                } else {
                  if (isNaN(min) || isNaN(max) || isNaN(score)) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      _this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                  }
                }
              }
              let ylist = _this.addForm.domainsParamsYu.domains
              let yscore = []
              for (let i = 0; i < ylist.length; i++) {
                yscore[i] = ylist[i].score
              }
              this.editScore = yscore
              let ymin = []
              for (let i = 0; i < ylist.length; i++) {
                ymin[i] = ylist[i].minWord
              }
              this.editMinWord = ymin

              let ymax = []
              for (let i = 0; i < ylist.length; i++) {
                ymax[i] = ylist[i].maxWord
              }
              this.editMaxWord = ymax

              let paramsInfo = {
                qaWordspeedIds: _this.qaWordspeedIds,
                normalId: _this.normalId,
                normalName: _this.addForm.normalName,
                judge: adJudge,
                defaultScore: _this.addForm.defaultScore,
                minWord: _this.editMinWord,
                maxWord: _this.editMaxWord,
                score: _this.editScore,
                modelId: _this.modleIdNew,
                classId: _this.treeid,
                speedType: _this.addForm.speedType,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/operateWordspeed.do',
                  Qs.stringify(paramsInfo)
                )
                .then((res) => {
                  if (res.data.flag == true) {
                    _this.tableRightData = res.data.Data
                    _this.totalCount = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '修改成功',
                    })
                    _this.myTitle = '新增标准'
                    _this.$refs['addForm'].resetFields()
                    _this.dialogFormVisible = false
                    _this.getAllNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.msg,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        } else {
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let min = _this.addForm.minScoreRange
              let max = _this.addForm.maxScoreRange
              let score = _this.addForm.mingScore
              let dscore = _this.addForm.defaultScore
              let scoreType = _this.addForm.scoreType
              let keywordSilenceType = _this.addForm.keywordSilenceType
              let timeMin = _this.addForm.timeMin
              let timeMax = _this.addForm.timeMax
              let sceneTime = _this.addForm.sceneTime
              // let sceneType = _this.addForm.sceneType
              let sceneValue = _this.addForm.sceneValue
              // let sceneValueType = _this.addForm.sceneValueType
              if (scoreType == '2') {
                if (sceneTime == '' || sceneValue == '') {
                  _this.$message({
                    type: 'error',
                    message: '请输入合法的数字',
                  })
                  return
                } else {
                  if (isNaN(sceneTime) || isNaN(sceneValue)) {
                    _this.$message({
                      type: 'error',
                      message: '场景和场景应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(sceneTime) == parseInt(sceneTime)) ||
                      !(Math.ceil(sceneValue) == parseInt(sceneValue)) ||
                      sceneTime == 0 ||
                      sceneValue == 0
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '场景和场景数值应为非零整数',
                      })
                      return
                    }
                  }
                }
                if (keywordSilenceType == '1') {
                  if (timeMin == '' && timeMax == '') {
                    _this.$message({
                      type: 'error',
                      message: '时间框至少一个不为空',
                    })
                    return
                  } else {
                    if (
                      (timeMin != '' && isNaN(timeMin)) ||
                      (timeMax != '' && isNaN(timeMax))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '时间框请输入数字',
                      })
                      return
                    }
                    if (
                      (timeMin != '' && Math.ceil(timeMin) != parseInt(timeMin)) ||
                      (timeMax != '' && Math.ceil(timeMax) != parseInt(timeMax))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '时间数值应为整数',
                      })
                      return
                    }
                    if (timeMin != '' && timeMax != '') {
                      if (Math.ceil(timeMin) > Math.ceil(timeMax)) {
                        _this.$message({
                          type: 'error',
                          message: '时间最大值应大于最小值',
                        })
                        return
                      }
                    }
                  }
                } else {
                  _this.addForm.timeMin = ''
                  _this.addForm.timeMax = ''
                }
              } else if (scoreType == '1') {
                // 位置选择开头和结尾时，需要判断开始句数offset非空和数字验证
                let position = _this.addForm.position
                if (position !== '' && position !== '3') {
                  if (
                    _this.addForm.offset === '' ||
                    _this.addForm.offset === null ||
                    isNaN(_this.addForm.offset)
                  ) {
                    _this.$message({
                      type: 'error',
                      message: '请输入合法的句数',
                    })
                    return
                  }
                }
              }
              // 循环判断silenceTimeMax要大于silenceTimeMin
              if (
                min === '' ||
                max === '' ||
                (_this.addForm.deadItem !== '1' && score === '')
              ) {
                _this.$message({
                  type: 'error',
                  message: '请输入合法的分值',
                })
                return
              } else {
                if (_this.addForm.scoreType == '1' || _this.addForm.scoreType == '2') {
                  if (
                    isNaN(min) ||
                    isNaN(max) ||
                    (_this.addForm.deadItem !== '1' && isNaN(score))
                  ) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      (_this.addForm.deadItem !== '1' &&
                        !(Math.ceil(parseInt(score)) == parseInt(score)))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      _this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                    if (
                      (_this.addForm.deadItem !== '1' && Math.ceil(score)) >
                        Math.ceil(max) ||
                      (_this.addForm.deadItem !== '1' &&
                        Math.ceil(score) < Math.ceil(min))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '命中得分在分值范围内',
                      })
                      return
                    }
                    if (
                      Math.ceil(dscore) > Math.ceil(max) ||
                      Math.ceil(dscore) < Math.ceil(min)
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '默认分数在分值范围内',
                      })
                      return
                    }
                  }
                }
              }
              let paramsGuan = {
                normalId: _this.normalId,
                keywordContext: document.getElementById('keylists').value,
                roleType: _this.roleType,
                score: _this.addForm.mingScore,
                modelId: _this.modleIdNew,
                classId: _this.treeid,
                defaultScore: _this.addForm.defaultScore,
                judge: adJudge,
                maxScoreRange: _this.addForm.maxScoreRange,
                minScoreRange: _this.addForm.minScoreRange,
                normalName: _this.addForm.normalName,
                deadItem: _this.addForm.deadItem,
                position: _this.addForm.position,
                offset: _this.addForm.offset,
                scoreType: _this.addForm.scoreType,
                silenceType: _this.addForm.keywordSilenceType,
                silenceTimeMin: _this.addForm.timeMin,
                silenceTimeMax: _this.addForm.timeMax,
                sceneTime: _this.addForm.sceneTime,
                sceneType: _this.addForm.sceneType,
                sceneValue: _this.addForm.sceneValue,
                sceneValueType: _this.addForm.sceneValueType,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/operateKeyword.do',
                  Qs.stringify(paramsGuan)
                )
                .then((res) => {
                  if (res.data.flag == true) {
                    _this.tableRightData = res.data.Data
                    _this.totalCount = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '修改成功',
                    })
                    _this.myTitle = '新增标准'
                    _this.$refs['addForm'].resetFields()
                    _this.dialogFormVisible = false
                    _this.getAllNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.msg,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        }
      } else {
        // 新增
        if (adJudge == 1) {
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCountK = _this.addForm.domainsParamsQing.domains.length
              let domainsK = _this.addForm.domainsParamsQing.domains
              for (let k = 0; k < domainsCountK; k++) {
                let min = domainsK[k].silenceTimeMin
                let max = domainsK[k].silenceTimeMax
                let score = domainsK[k].score
                // 循环判断silenceTimeMax要大于silenceTimeMin
                if (min === '' || max === '' || score === '') {
                  _this.$message({
                    type: 'error',
                    message: '请输入合法的分值',
                  })
                  return
                } else {
                  if (isNaN(min) || isNaN(max) || isNaN(score)) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      _this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                  }
                }
              }
              let dlist = _this.addForm.domainsParamsQing.domains
              let dscore = []
              for (let i = 0; i < dlist.length; i++) {
                dscore[i] = dlist[i].score
              }
              _this.score = dscore

              let sMinList = []
              for (let i = 0; i < dlist.length; i++) {
                sMinList[i] = dlist[i].silenceTimeMin
              }
              _this.silenceTimeMin = sMinList

              let sMaxList = []
              for (let i = 0; i < dlist.length; i++) {
                sMaxList[i] = dlist[i].silenceTimeMax
              }
              _this.silenceTimeMax = sMaxList
              let params = {
                normalName: _this.addForm.normalName,
                score: _this.score,
                defaultScore: _this.addForm.defaultScore,
                judge: _this.addForm.judge,
                silenceTimeMin: _this.silenceTimeMin,
                silenceTimeMax: _this.silenceTimeMax,
                modelId: _this.modleIdNew,
                classId: _this.treeid,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/operateSilence.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success == true) {
                    _this.tableRightData = res.data.Data
                    _this.totalCount = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '添加成功',
                    })
                    _this.myTitle = '新增标准'
                    _this.$refs.addForm.resetFields()
                    _this.dialogFormVisible = false
                    _this.getAllNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            } else {
              console.log('error submit!!')
              return false
            }
          })
        } else if (adJudge === 2) {
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          let dlist = _this.addForm.chongDomains.domains
          let dscore = []
          for (let i = 0; i < dlist.length; i++) {
            dscore[i] = dlist[i].score
          }
          _this.score = dscore

          let sMinList = []
          for (let i = 0; i < dlist.length; i++) {
            sMinList[i] = dlist[i].silenceTimeMin
          }
          _this.silenceTimeMin = sMinList

          let sMaxList = []
          for (let i = 0; i < dlist.length; i++) {
            sMaxList[i] = dlist[i].silenceTimeMax
          }
          _this.silenceTimeMax = sMaxList
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCountK = _this.addForm.chongDomains.domains.length
              let domainsK = _this.addForm.chongDomains.domains
              for (let k = 0; k < domainsCountK; k++) {
                let min = domainsK[k].silenceTimeMin
                let max = domainsK[k].silenceTimeMax
                let score = domainsK[k].score
                // 循环判断silenceTimeMax要大于silenceTimeMin
                if (min === '' || max === '' || score === '') {
                  _this.$message({
                    type: 'error',
                    message: '请输入合法的分值',
                  })
                  return
                } else {
                  if (isNaN(min) || isNaN(max) || isNaN(score)) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      _this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                  }
                }
              }
              let params = {
                normalName: _this.addForm.normalName,
                judge: _this.addForm.judge,
                defaultScore: _this.addForm.defaultScore,
                silenceTimeMin: _this.silenceTimeMin,
                silenceTimeMax: _this.silenceTimeMax,
                score: _this.score,
                modelId: _this.modleIdNew,
                classId: _this.treeid,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/operateSilence.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success == true) {
                    _this.tableRightData = res.data.Data
                    _this.totalCount = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '添加成功',
                    })
                    _this.myTitle = '新增标准'
                    _this.$refs.addForm.resetFields()
                    _this.dialogFormVisible = false
                    _this.getAllNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            } else {
              console.log('error submit!!')
              return false
            }
          })
        } else if (adJudge === 3) {
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let domainsCountK = _this.addForm.jingDomains.domains.length
              let domainsK = _this.addForm.jingDomains.domains
              for (let k = 0; k < domainsCountK; k++) {
                let min = domainsK[k].silenceTimeMin
                let max = domainsK[k].silenceTimeMax
                let score = domainsK[k].score
                // 循环判断silenceTimeMax要大于silenceTimeMin
                if (min === '' || max === '' || score === '') {
                  _this.$message({
                    type: 'error',
                    message: '请输入合法的分值',
                  })
                  return
                } else {
                  if (isNaN(min) || isNaN(max) || isNaN(score)) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                      !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                      !(Math.ceil(parseInt(score)) == parseInt(score))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '分值应为整数',
                      })
                      return
                    }
                    if (Math.ceil(min) > Math.ceil(max)) {
                      _this.$message({
                        type: 'error',
                        message: '最大值应大于最小值',
                      })
                      return
                    }
                  }
                }
              }

              let dlist = _this.addForm.jingDomains.domains
              let dscore = []
              for (let i = 0; i < dlist.length; i++) {
                dscore[i] = dlist[i].score
              }
              _this.scoreJing = dscore
              let sMinList = []
              for (let i = 0; i < dlist.length; i++) {
                sMinList[i] = dlist[i].silenceTimeMin
              }
              _this.silenceTimeMinJing = sMinList

              let sMaxList = []
              for (let i = 0; i < dlist.length; i++) {
                sMaxList[i] = dlist[i].silenceTimeMax
              }
              _this.silenceTimeMaxJing = sMaxList
              let params = {
                normalName: _this.addForm.normalName,
                slienceType: _this.slienceType,
                judge: _this.addForm.judge,
                defaultScore: _this.addForm.defaultScore,
                silenceTimeMin: _this.silenceTimeMinJing,
                silenceTimeMax: _this.silenceTimeMaxJing,
                score: _this.scoreJing,
                modelId: _this.modleIdNew,
                classId: _this.treeid,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/operateSilence.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success == true) {
                    _this.tableRightData = res.data.Data
                    _this.totalCount = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '添加成功',
                    })
                    _this.myTitle = '新增标准'
                    _this.$refs.addForm.resetFields()
                    _this.dialogFormVisible = false
                    _this.getScore()
                    _this.getAllNormal()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            } else {
              console.log('error submit!!')
              return false
            }
          })
        } else if (adJudge === 4) {
          _this.addForm.maxScoreRange = _this.addForm.defaultScore
          _this.addForm.minScoreRange = _this.addForm.defaultScore
          _this.addForm.mingScore = _this.addForm.defaultScore
          _this.$refs.addForm.validate((valid) => {
            let domainsCountK = _this.addForm.domainsParamsYu.domains.length
            let domainsK = _this.addForm.domainsParamsYu.domains
            for (let k = 0; k < domainsCountK; k++) {
              let min = domainsK[k].minWord
              let max = domainsK[k].maxWord
              let score = domainsK[k].score
              // 循环判断silenceTimeMax要大于silenceTimeMin
              if (min === '' || max === '' || score === '') {
                _this.$message({
                  type: 'error',
                  message: '请输入合法的分值',
                })
                return
              } else {
                if (isNaN(min) || isNaN(max) || isNaN(score)) {
                  _this.$message({
                    type: 'error',
                    message: '分值应为数字',
                  })
                  return
                } else {
                  if (
                    !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                    !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                    !(Math.ceil(parseInt(score)) == parseInt(score))
                  ) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为整数',
                    })
                    return
                  }
                  if (Math.ceil(min) > Math.ceil(max)) {
                    _this.$message({
                      type: 'error',
                      message: '最大值应大于最小值',
                    })
                    return
                  }
                }
              }
            }

            let yuList = _this.addForm.domainsParamsYu.domains
            let yuOne = []
            for (let i = 0; i < yuList.length; i++) {
              yuOne[i] = yuList[i].score
            }
            _this.yuScore = yuOne

            let yuMin = []
            for (let i = 0; i < yuList.length; i++) {
              yuMin[i] = yuList[i].minWord
            }
            _this.minWordList = yuMin

            let yuMax = []
            for (let i = 0; i < yuList.length; i++) {
              yuMax[i] = yuList[i].maxWord
            }
            _this.maxWordList = yuMax
            let params = {
              normalName: _this.addForm.normalName,
              judge: _this.addForm.judge,
              defaultScore: _this.addForm.defaultScore,
              minWord: _this.minWordList,
              maxWord: _this.maxWordList,
              score: _this.yuScore,
              modelId: _this.modleIdNew,
              classId: _this.treeid,
              speedType: _this.addForm.speedType,
            }
            this.axios
              .post(
                manalScore + '/manualOrderQualityAssurance/operateWordspeed.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data.flag == true) {
                  _this.tableRightData = res.data.Data
                  _this.totalCount = res.data.Count
                  _this.$message({
                    type: 'success',
                    message: res.data.msg,
                  })
                  _this.getScore()
                  _this.myTitle = '新增标准'
                  _this.$refs.addForm.resetFields()
                  _this.dialogFormVisible = false
                  _this.getAllNormal()
                } else {
                  _this.$message({
                    type: 'error',
                    message: res.data.msg,
                  })
                }
              })
              .catch(function(error) {
                console.log(error)
              })
          })
        } else {
          _this.$refs.addForm.validate((valid) => {
            if (valid) {
              let min = _this.addForm.minScoreRange
              let max = _this.addForm.maxScoreRange
              let score = _this.addForm.mingScore
              let dscore = _this.addForm.defaultScore
              let scoreType = _this.addForm.scoreType
              let keywordSilenceType = _this.addForm.keywordSilenceType
              let timeMin = _this.addForm.timeMin
              let timeMax = _this.addForm.timeMax
              let sceneTime = _this.addForm.sceneTime
              // let sceneType = _this.addForm.sceneType
              let sceneValue = _this.addForm.sceneValue
              // let sceneValueType = _this.addForm.sceneValueType
              if (scoreType == '2') {
                if (sceneTime == '' || sceneValue == '') {
                  _this.$message({
                    type: 'error',
                    message: '请输入合法的数字',
                  })
                  return
                } else {
                  if (isNaN(sceneTime) || isNaN(sceneValue)) {
                    _this.$message({
                      type: 'error',
                      message: '场景和场景应为数字',
                    })
                    return
                  } else {
                    if (
                      !(Math.ceil(sceneTime) == parseInt(sceneTime)) ||
                      !(Math.ceil(sceneValue) == parseInt(sceneValue)) ||
                      sceneTime == 0 ||
                      sceneValue == 0
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '场景和场景数值应为非零整数',
                      })
                      return
                    }
                  }
                }
                if (keywordSilenceType == '1') {
                  if (timeMin == '' && timeMax == '') {
                    _this.$message({
                      type: 'error',
                      message: '时间框至少一个不为空',
                    })
                    return
                  } else {
                    if (
                      (timeMin != '' && isNaN(timeMin)) ||
                      (timeMax != '' && isNaN(timeMax))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '时间框请输入数字',
                      })
                      return
                    }
                    if (
                      (timeMin != '' && Math.ceil(timeMin) != parseInt(timeMin)) ||
                      (timeMax != '' && Math.ceil(timeMax) != parseInt(timeMax))
                    ) {
                      _this.$message({
                        type: 'error',
                        message: '时间数值应为整数',
                      })
                      return
                    }
                    if (timeMin != '' && timeMax != '') {
                      if (Math.ceil(timeMin) > Math.ceil(timeMax)) {
                        _this.$message({
                          type: 'error',
                          message: '时间最大值应大于最小值',
                        })
                        return
                      }
                    }
                  }
                } else {
                  _this.addForm.timeMin = ''
                  _this.addForm.timeMax = ''
                }
              } else if (scoreType == '1') {
                // 位置选择开头和结尾时，需要判断开始句数offset非空和数字验证
                let position = _this.addForm.position
                if (position !== '' && position !== '3') {
                  if (
                    _this.addForm.offset === '' ||
                    _this.addForm.offset === null ||
                    isNaN(_this.addForm.offset)
                  ) {
                    _this.$message({
                      type: 'error',
                      message: '请输入合法的句数',
                    })
                    return
                  }
                }
              }
              // 循环判断silenceTimeMax要大于silenceTimeMin
              if (
                min === '' ||
                max === '' ||
                (score === '' && _this.addForm.deadItem !== '1')
              ) {
                _this.$message({
                  type: 'error',
                  message: '请输入合法的分值',
                })
                return
              } else {
                if (
                  isNaN(min) ||
                  isNaN(max) ||
                  (isNaN(score) && _this.addForm.deadItem !== '1')
                ) {
                  _this.$message({
                    type: 'error',
                    message: '分值应为数字',
                  })
                  return
                } else {
                  if (
                    !(Math.ceil(parseInt(min)) == parseInt(min)) ||
                    !(Math.ceil(parseInt(max)) == parseInt(max)) ||
                    (_this.addForm.deadItem !== '1' &&
                      !(Math.ceil(parseInt(score)) == parseInt(score)))
                  ) {
                    _this.$message({
                      type: 'error',
                      message: '分值应为整数',
                    })
                    return
                  }
                  if (Math.ceil(min) > Math.ceil(max)) {
                    _this.$message({
                      type: 'error',
                      message: '最大值应大于最小值',
                    })
                    return
                  }
                  if (
                    _this.addForm.deadItem !== '1' &&
                    (Math.ceil(score) > Math.ceil(max) ||
                      Math.ceil(score) < Math.ceil(min))
                  ) {
                    _this.$message({
                      type: 'error',
                      message: '命中得分在分值范围内',
                    })
                    return
                  }
                  if (
                    Math.ceil(dscore) > Math.ceil(max) ||
                    Math.ceil(dscore) < Math.ceil(min)
                  ) {
                    _this.$message({
                      type: 'error',
                      message: '默认分数在分值范围内',
                    })
                    return
                  }
                }
              }
              // 关键词
              let paramsGuan = {
                keywordContext: document.getElementById('keylists').value,
                roleType: this.roleType,
                score: this.addForm.mingScore,
                modelId: this.modleIdNew,
                classId: this.treeid,
                defaultScore: this.addForm.defaultScore,
                judge: this.addForm.judge,
                maxScoreRange: this.addForm.maxScoreRange,
                minScoreRange: this.addForm.minScoreRange,
                normalName: this.addForm.normalName,
                deadItem: _this.addForm.deadItem,
                position: _this.addForm.position,
                offset: _this.addForm.offset,
                scoreType: _this.addForm.scoreType,
                silenceType: _this.addForm.keywordSilenceType,
                silenceTimeMin: _this.addForm.timeMin,
                silenceTimeMax: _this.addForm.timeMax,
                sceneTime: _this.addForm.sceneTime,
                sceneType: _this.addForm.sceneType,
                sceneValue: _this.addForm.sceneValue,
                sceneValueType: _this.addForm.sceneValueType,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/operateKeyword.do',
                  Qs.stringify(paramsGuan)
                )
                .then((res) => {
                  if (res.data.flag == true) {
                    _this.tableRightData = res.data.Data
                    _this.totalCount = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: res.data.msg,
                    })
                    _this.myTitle = '新增标准'
                    _this.$refs.addForm.resetFields()
                    _this.dialogFormVisible = false
                    _this.getAllNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.msg,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        }
      }
    },
    // 人工打分 删除table
    deleteManualMan: function(normalId, normalName) {
      let _this = this
      let params = {
        normalId: normalId,
      }
      if (normalId === '' || normalId === null) {
        return
      } else {
        _this
          .$confirm('确定要删除【' + normalName + '】吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          })
          .then(() => {
            this.axios
              .post(
                manalScore + '/manualOrderQualityAssurance/delNormalInfo.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data) {
                  _this.$message({
                    type: 'success',
                    message: '删除成功!',
                  })
                } else {
                  _this.$message({
                    type: 'error',
                    message: '删除失败!',
                  })
                }
                _this.getAllManuslNormal()
              })
          })
          .catch(() => {
            _this.getAllManuslNormal()
          })
      }
    },
    // 人工打分 添加tree
    addMMTree: function() {
      let _this = this
      if (_this.pidMan == '') {
        _this.dialogTreeFormVisibleMan = true
        _this.addTreeManual.typeid = ''
      } else {
        _this.pidMan = _this.treeIdMan
        _this.dialogTreeFormVisibleMan = true
      }
    },
    insertAtCursor(myValue) {
      let myField = document.getElementById('keylists')
      // IE 浏览器
      if (document.selection) {
        myField.focus()
        let sel = document.selection.createRange()
        sel.text = myValue
        sel.select()
        // FireFox、Chrome等
      } else if (myField.selectionStart || myField.selectionStart == '0') {
        let startPos = myField.selectionStart
        let endPos = myField.selectionEnd
        // 保存滚动条
        let restoreTop = myField.scrollTop
        myField.value =
          myField.value.substring(0, startPos) +
          ' ' +
          myValue +
          ' ' +
          myField.value.substring(endPos, myField.value.length)
        if (restoreTop > 0) {
          myField.scrollTop = restoreTop
        }
        myField.focus()
        myField.selectionStart = startPos + myValue.length + 2
        myField.selectionEnd = startPos + myValue.length + 2
      } else {
        myField.value += myValue
        myField.focus()
      }
    },
    // 关键词组合
    labelClick: function(event) {
      let str
      if ($(event.target).html() == '{}') {
        str = ' ' + '(' + ' ' + ' ' + ')' + ' '
      } else {
        str = ' ' + $(event.target).html() + ' '
      }
      let valstr = this.addForm.keywordContext + str
      this.addForm.keywordContext = valstr
      $('#keylists').focus()
    },
    editNamesYesThrottle() {
      this.lodashThrottle.throttle(this.editNamesYes, this)
    },
    // 确定修改模板名称
    editNamesYes: function() {
      let that = this
      if (this.editNamesForm.modleTitle == this.mdtitle) {
        this.handleIconModel = false
      } else {
        this.$refs.editNamesForm.validate((valid) => {
          if (valid) {
            let params = {
              modleTitle: this.editNamesForm.modleTitle,
              qualityScore: this.info.qualityScore,
              status: this.info.status,
              remark: this.info.remark,
              modleType: 7,
              modleId: this.modleIdNew,
              linkModleId: '973e5ad4fe5511e6b042000c29a7c029',
              departId: '973e5ad4fe5511e6b042000c29a7c029',
            }
            if (params['modleTitle'].trim() === '') {
              this.$message.error('模板名称不能为空!')
              return
            }
            this.axios
              .post(
                manalScore + '/manualOrderQualityAssurance/saveModle.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data.flag == true) {
                  this.$message({
                    type: 'success',
                    message: '数据提交成功!',
                  })
                  that.namesForm.modleTitle = this.editNamesForm.modleTitle
                  this.mdtitle = this.editNamesForm.modleTitle
                  that.handleIconModel = false
                } else {
                  this.$message({
                    type: 'error',
                    message: res.data.msg,
                  })
                }
              })
              .catch(function(error) {
                console.log(error)
              })
          }
        })
      }
    },
    // 修改模板名称
    handleIconClick() {
      this.handleIconModel = true
      this.$nextTick(() => {
        this.$refs['editNamesForm'].resetFields()
        this.editNamesForm.modleTitle = this.mdtitle
      })
    },
    // 表格多选,获取批量删除需要的ids
    selectAll: function(selection) {
      if (selection.length > 0) {
        this.isBatch = true
        let nums = selection
        let tids = []
        for (let i = 0; i < nums.length; i++) {
          tids[i] = nums[i].normalId
        }
        let newId = tids.join(',')
        this.normalIds = newId

        let tnames = []
        for (let j = 0; j < nums.length; j++) {
          tnames[j] = nums[j].normalName
        }
        let norName = tnames
        this.norNameList = norName.slice(0, 3)
        this.selectionNums = selection.length
      } else {
        this.isBatch = false
        this.normalIds = ''
      }
    },
    // 人工表格多选,获取批量删除需要的ids
    selectAllMan: function(selection) {
      if (selection.length > 0) {
        this.isBatchMan = true
        let nums = selection
        let tids = []
        for (let i = 0; i < nums.length; i++) {
          tids[i] = nums[i].normalId
        }
        let newId = tids.join(',')
        this.normalIdsMan = newId

        let tnames = []
        for (let j = 0; j < nums.length; j++) {
          tnames[j] = nums[j].normalName
        }
        let norName = tnames
        this.norNameListMan = norName.slice(0, 3)
        this.selectionNumsMan = selection.length
      } else {
        this.isBatchMan = false
        this.normalIdsMan = ''
      }
    },
    // 批量删除
    batchDelete: function() {
      let _this = this
      if (_this.isBatch == false) {
        _this.$message({
          type: 'warning',
          message: '请至少选择一个条数据！',
        })
      } else {
        _this
          .$confirm(
            '确定要删除【' +
              _this.norNameList +
              '】等' +
              _this.selectionNums +
              '个项目吗？',
            '提示',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }
          )
          .then(() => {
            let params = {
              normalIds: this.normalIds,
            }
            this.axios
              .post(
                manalScore + '/manualOrderQualityAssurance/removeManyNormals.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data) {
                  _this.$message({
                    type: 'success',
                    message: '删除成功!',
                  })
                } else {
                  _this.$message({
                    type: 'error',
                    message: '删除失败',
                  })
                }
                _this.$refs.multipleTable.clearSelection()
                _this.getAllNormal()
                _this.getScore()
              })
              .catch(function(error) {
                console.log(error)
              })
          })
          .catch(() => {
            _this.$message({
              type: 'info',
              message: '已取消删除',
            })
          })
      }
    },
    // 人工打分批量删除
    batchDeleteMan: function() {
      let _this = this
      if (_this.isBatchMan == false) {
        _this.$message({
          type: 'warning',
          message: '请至少选择一个条数据！',
        })
      } else {
        _this
          .$confirm(
            '确定要删除【' +
              _this.norNameListMan +
              '】等' +
              _this.selectionNumsMan +
              '个项目吗？',
            '提示',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }
          )
          .then(() => {
            let params = {
              normalIds: this.normalIdsMan,
            }
            this.axios
              .post(
                manalScore + '/manualOrderQualityAssurance/removeManyNormals.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data) {
                  _this.$message({
                    type: 'success',
                    message: '删除成功!',
                  })
                } else {
                  _this.$message({
                    type: 'error',
                    message: '删除失败',
                  })
                }
                _this.$refs.multipleTableMan.clearSelection()
                _this.getAllManuslNormal()
                _this.getScore()
              })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除',
            })
          })
      }
    },
    // 点击预览
    preview: function() {
      let _this = this
      if (_this.modleIdNew == null || _this.modleIdNew == '') {
        _this.previewModel = false
      } else {
        _this.previewModel = true
        let params = {
          modleId: _this.modleIdNew,
        }
        this.axios
          .post(
            manalScore + '/manualOrderQualityAssurance/yulanModleInfoScore.do',
            Qs.stringify(params)
          )
          .then((res) => {
            if (res.data != null) {
              _this.tableData = res.data.dataT
              // this.resultObject=res.data.data.resultsObject;
              _this.typelist = res.data.data_hand
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    // 人工 编辑标准
    editManualTitle: function(classId, normalId, val, judge) {
      this.editClassId = classId
      let norid = normalId
      if (val == 1) {
        this.standardTitle = '编辑标准'
        this.showDisabledMan = false
      } else {
        this.standardTitle = '查看标准'
        this.showDisabledMan = true
      }
      let params = {
        normalId: norid,
      }
      this.axios
        .post(
          manalScore + '/manualOrderQualityAssurance/getNormalInfo.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data) {
            let judge = res.data.judge
            if (judge == 6) {
              this.artificialJudge = 6
              $('#shoudong').show()
              $('#zhimingxiang').hide()
              $('#xuanxiang').hide()
              this.AddTableFormMan.maxScoreRange = res.data.maxScoreRange
              this.AddTableFormMan.minScoreRange = res.data.minScoreRange
              this.AddTableFormMan.defaultScore = res.data.defaultScore
            } else if (judge == 7) {
              this.artificialJudge = 7
              $('#shoudong').hide()
              $('#zhimingxiang').hide()
              $('#xuanxiang').show()
            } else {
              $('#shoudong').hide()
              $('#xuanxiang').hide()
              $('#zhimingxiang').show()
              this.artificialJudge = 8
            }
            this.AddTableFormMan.judge = res.data.judge
            this.AddTableFormMan.normalName = res.data.normalName
            this.AddTableFormMan.normalContent = res.data.normalContent
            let that = this
            if (
              res.data.optionTexts == '' ||
              res.data.optionTexts == undefined ||
              res.data.optionTexts == []
            ) {
              that.AddTableFormMan.xuanDomains = {
                domains: [{ optionTexts: '' }],
              }
            } else {
              let ops = res.data.optionTexts
              let trees = []
              this.getOption(ops, trees)
              this.trees = trees
              that.AddTableFormMan.xuanDomains.domains = trees
            }
            this.dialogFormVisibleMan = true
          } else {
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    getOption: function(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        treeList[i] = {
          optionTexts: value[i],
        }
      }
      return treeList
    },
    // 人工打分点击编辑tree
    editMMTree: function() {
      if (this.treeIdMan == '') {
        this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        this.manualEditTreeModal = true
      }
    },
    // 人工打分点击删除tree
    delMMTree: function() {
      if (this.treeIdMan == null || this.treeIdMan == '') {
        this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        this.$confirm('确定要删除【' + this.typeIdMan + '】吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
          .then(() => {
            this.axios
              .post(
                manalScore +
                  '/manualOrderQualityAssurance/deleteQaClass.do?classId=' +
                  this.treeIdMan
              )
              .then((res) => {
                if (res.data == true) {
                  this.$message({
                    type: 'success',
                    message: '删除成功!',
                  })
                  /* if(this.parentIdAuto=='0'){
                   this.pidMan="";
                   } */
                } else {
                  this.$message({
                    type: 'error',
                    message: '删除失败!',
                  })
                }
                this.getLeftTreesArtificial()
                this.getAllManuslNormal()
                this.addTreeManual.typeid = ''
                this.manualEditTreeForm.typeid = ''
                this.treeidAuto = ''
              })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除',
            })
            this.getLeftTreesArtificial()
            this.getAllManuslNormal()
            this.addTreeManual.typeid = ''
            this.manualEditTreeForm.typeid = ''
            this.treeIdMan = ''
          })
      }
    },
    // 点击编辑标准
    editNormalInfo: function(normalId, val) {
      let norid = normalId
      let that = this
      if (val == 1) {
        that.myTitle = '修改标准'
        this.showDisabled = false
        this.mingScoreDisabled = false
      } else {
        that.myTitle = '查看标准'
        this.showDisabled = true
        this.mingScoreDisabled = true
      }
      this.dialogFormVisible = true

      let params = {
        normalId: norid,
      }
      this.axios
        .post(
          manalScore + '/manualOrderQualityAssurance/getNormalInfo.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data) {
            let judge = res.data.judge
            this.judgeAuto = judge
            this.juid = judge
            this.addForm.judge = res.data.judge
            this.addForm.offset = res.data.offset
            this.addForm.normalName = res.data.normalName
            this.addForm.defaultScore = res.data.defaultScore
            this.qingxuJudge = res.data.judge
            if (judge == 1) {
              $('#qingxu').show()
              $('#yusu').hide()
              $('#guanjianci').hide()
              $('#jingmo').hide()
              $('#chongfu').hide()
              let paramsOne = {
                normalId: norid,
                judge: judge,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/getRulesByNormal.do',
                  Qs.stringify(paramsOne)
                )
                .then((res) => {
                  let _that = this
                  _that.addForm.domainsParamsQing.domains = res.data.Data
                  let listCount = this.addForm.domainsParamsQing.domains
                  let sid = []
                  for (let i = 0; i < listCount.length; i++) {
                    sid[i] = listCount[i].silenceId
                  }
                  // 得到
                  let ssid = []
                  for (let i = 0; i < res.data.Count; i++) {
                    ssid[i] = res.data.Data[i].silenceId
                  }
                  this.silenceIds = ssid
                })
                .catch(function(error) {
                  console.log(error)
                })
            } else if (judge == 2) {
              $('#chongfu').show()
              $('#qingxu').hide()
              $('#guanjianci').hide()
              $('#jingmo').hide()
              $('#yusu').hide()
              let paramsOne = {
                normalId: norid,
                judge: res.data.judge,
              }
              this.qingxuJudge = res.data.judge
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/getRulesByNormal.do',
                  Qs.stringify(paramsOne)
                )
                .then((res) => {
                  if (res.data) {
                    let _this = this
                    _this.addForm.chongDomains.domains = res.data.Data
                    // 得到
                    let silenceId = []
                    for (let i = 0; i < res.data.Count; i++) {
                      silenceId[i] = res.data.Data[i].silenceId
                    }
                    this.silenceIdsChong = silenceId
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            } else if (judge == 3) {
              $('#yusu').hide()
              $('#chongfu').hide()
              $('#qingxu').hide()
              $('#guanjianci').hide()
              $('#jingmo').show()
              let paramsOne = {
                normalId: norid,
                judge: judge,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/getRulesByNormal.do',
                  Qs.stringify(paramsOne)
                )
                .then((res) => {
                  if (res.data) {
                    this.addForm.jingDomains.domains = res.data.Data
                    // 得到
                    this.addForm.silenceType = res.data.Data[0].silenceType
                    let silenceId = []
                    for (let i = 0; i < res.data.Count; i++) {
                      silenceId[i] = res.data.Data[i].silenceId
                    }
                    this.silenceIds = silenceId
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            } else if (judge == 4) {
              $('#yusu').show()
              $('#qingxu').hide()
              $('#guanjianci').hide()
              $('#jingmo').hide()
              $('#chongfu').hide()
              let paramsOne = {
                normalId: norid,
                judge: judge,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/getRulesByNormal.do',
                  Qs.stringify(paramsOne)
                )
                .then((res) => {
                  if (res.data) {
                    this.addForm.domainsParamsYu.domains = res.data.Data
                    // 得到
                    let autoWordspeedId = []
                    for (let i = 0; i < res.data.Count; i++) {
                      autoWordspeedId[i] = res.data.Data[i].autoWordspeedId
                    }
                    this.addForm.speedType = res.data.Data[0].speedType
                    this.qaWordspeedIds = autoWordspeedId
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            } else {
              $('#yusu').hide()
              $('#qingxu').hide()
              $('#guanjianci').show()
              $('#jingmo').hide()
              $('#chongfu').hide()
              this.addForm.minScoreRange = res.data.minScoreRange
              this.addForm.maxScoreRange = res.data.maxScoreRange
              this.addForm.mingScore = res.data.score
              let paramsOne = {
                normalId: norid,
                judge: judge,
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/getRulesByNormal.do',
                  Qs.stringify(paramsOne)
                )
                .then((res) => {
                  if (res.data) {
                    this.addForm.keywordContext = res.data.Data[0].keywordContext
                    this.addForm.roleType = res.data.Data[0].roleType
                    this.addForm.mingScore = res.data.Data[0].score
                    this.addForm.deadItem = res.data.Data[0].deadItem
                    this.addForm.offset = res.data.Data[0].offset
                    this.addForm.scoreType = res.data.Data[0].scoreType
                    this.addForm.position = res.data.Data[0].position
                    if (res.data.Data[0].scoreType == '2') {
                      this.addForm.keywordSilenceType = res.data.Data[0].silenceType
                      if (
                        res.data.Data[0].silenceTimeMin ||
                        res.data.Data[0].silenceTimeMin == 0
                      ) {
                        this.addForm.timeMin = res.data.Data[0].silenceTimeMin
                      }
                      if (
                        res.data.Data[0].silenceTimeMax ||
                        res.data.Data[0].silenceTimeMax == 0
                      ) {
                        this.addForm.timeMax = res.data.Data[0].silenceTimeMax
                      }
                      this.addForm.sceneTime = res.data.Data[0].sceneTime
                      this.addForm.sceneType = res.data.Data[0].sceneType
                      this.addForm.sceneValue = res.data.Data[0].sceneValue
                      this.addForm.sceneValueType = res.data.Data[0].sceneValueType
                    }
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          } else {
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // table点击一行
    rowClickTable: function(row, column, cell, event) {
      // this.editJudge=row.judge;
      this.normalId = row.normalId
    },
    // table点击一行
    rowClickTableMan: function(row) {
      this.normalIdMan = row.normalId
    },
    // 删除标准
    delNormalInfo: function(normalId, normalName) {
      let params = {
        normalId: normalId,
      }
      this.$confirm('确定要删除【' + normalName + '】吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.axios
            .post(
              manalScore + '/manualOrderQualityAssurance/delNormalInfo.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data) {
                this.$message({
                  type: 'success',
                  message: '删除成功!',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '删除失败!',
                })
              }
              this.getAllNormal()
              this.getScore()
            })
        })
        .catch(() => {})
    },
    /* 按名称查找 */
    searchByName: function() {
      let params = {
        classId: this.treeid,
        normalName: this.formInlineAuto.normalName,
      }
      this.axios
        .post(
          manalScore + '/manualOrderQualityAssurance/getAllNormal.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data.Data != null) {
            this.tableRightData = res.data.Data
            this.totalCount = res.data.Count
          } else {
            this.tableRightData = []
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 人工打分 按照名称查询table
    searchByNameMan: function() {
      let params = {
        classId: this.treeIdMan,
        normalName: this.formInlineArtificial.user,
      }
      this.axios
        .post(
          manalScore + '/manualOrderQualityAssurance/getAllNormal.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data.Data != null) {
            this.tableDataMan = res.data.Data
            this.totalCountMan = res.data.Count
          } else {
            this.tableDataMan = []
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     *时间戳
     * **/
    format: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    filterNode: function(value, data) {
      if (!value) return true
      return data.label.indexOf(value) !== -1
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.getAllNormal()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.getAllNormal()
    },
    /**
     * 每页条数
     * **/
    handleSizeChangeAuto(val) {
      this.pagesizeAuto = val
      this.pageindexAuto = 1
      this.getAllManuslNormal()
    },
    /**
     *当前页数
     * */
    handleCurrentChangeAuto(val) {
      this.pageindexAuto = val
      this.getAllManuslNormal()
    },
    editSaveClassTwoThrottle() {
      this.lodashThrottle.throttle(this.editSaveClassMan, this)
    },
    editSaveClassMan: function() {
      this.$refs.manualEditTreeForm.validate((valid) => {
        if (valid) {
          let params = {
            classTitle: this.manualEditTreeForm.classTitle,
            remark: this.manualEditTreeForm.remark,
            classId: this.manualEditTreeForm.classId,
            modleId: this.modleIdNew,
            parentClassId: this.manualEditTreeForm.parentClassId,
          }

          this.axios
            .post(
              manalScore + '/manualOrderQualityAssurance/saveClass.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data.flag == true) {
                this.$message({
                  type: 'success',
                  message: '修改成功!',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '修改失败!',
                })
              }
              this.$refs.manualEditTreeForm.resetFields()
              this.getLeftTreesArtificial()
              this.manualEditTreeModal = false
              this.treeIdMan = ''
              this.manualEditTreeForm.typeid = ''
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    // 自动打分 确定修改tree
    editSaveClassThrottle() {
      this.lodashThrottle.throttle(this.editSaveClass, this)
    },
    editSaveClass: function() {
      this.$refs.editTreeForm.validate((valid) => {
        if (valid) {
          let params = {
            classTitle: this.editTreeForm.classTitle,
            remark: this.editTreeForm.remark,
            classId: this.editTreeForm.classId,
            modleId: this.modleIdNew,
            parentClassId: this.editTreeForm.parentClassId,
          }

          this.axios
            .post(
              manalScore + '/manualOrderQualityAssurance/saveClass.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data.flag == true) {
                this.$message({
                  type: 'success',
                  message: '修改成功!',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '修改失败!',
                })
              }
              this.$refs.editTreeForm.resetFields()
              this.getLeftTreesArtificial()
              this.editTreeModal = false
              this.treeIdMan = ''
              this.addTreeManual.typeid = ''
              this.manualEditTreeForm.typeid = ''
            })
            .catch(function(error) {
              console.log(error)
              this.$refs.editTreeForm.resetFields()
              this.getLeftTreesArtificial()
              this.editTreeModal = false
              this.treeIdMan = ''
              this.addTreeManual.typeid = ''
              this.manualEditTreeForm.typeid = ''
            })
        }
      })
    },
    // 自动打分 修改 取消
    editCancel: function() {
      // this.manualEditTreeModal=false;
      this.getLeftTrees()
      this.treeid = ''
      this.editTreeForm.typeid = ''
      this.addTreeForm.typeid = ''
      this.editTreeModal = false
    },
    editCancelArtificial: function() {
      this.manualEditTreeModal = false
      this.getLeftTreesArtificial()
      this.addTreeManual.typeid = ''
      this.manualEditTreeForm.typeid = ''
      this.treeIdMan = ''
    },
    cancalMunaul: function() {
      this.dialogTreeFormVisibleMan = false
      this.treeIdMan = ''
      this.pidMan = ''
      this.addTreeManual.typeid = ''
      this.getLeftTreesArtificial()
      this.$refs.addTreeManual.resetFields()
    },
    // 自动打分 添加 取消
    cancel: function() {
      this.dialogTreeFormVisible = false
      this.treeid = ''
      this.pid = ''
      this.addTreeForm.typeid = ''
      this.$refs.addTreeForm.resetFields()
      this.getLeftTrees()
    },
    // 点击tree
    nodeClick: function(data) {
      this.pid = 1
      this.parentid = data.parentClassId
      this.treeid = data.id
      this.addTreeForm.typeid = data.label
      this.typeid = data.label
      this.clist = data.children
      this.editTreeForm.typeid = data.label
      this.editTreeForm.classTitle = data.label
      this.editTreeForm.classId = data.id
      this.editTreeForm.remark = data.remark
      this.editTreeForm.parentClassId = data.parentClassId
      this.getAllNormal()
    },
    // 人工打分点击tree
    nodeClickAuto: function(data) {
      this.pidMan = 1
      this.parentIdAuto = data.parentClassId
      this.treeIdMan = data.id
      this.addTreeManual.typeid = data.label
      this.typeIdMan = data.label
      this.cListMan = data.children
      this.manualEditTreeForm.typeid = data.label
      this.manualEditTreeForm.classTitle = data.label
      this.manualEditTreeForm.classId = data.id
      this.manualEditTreeForm.remark = data.remark
      this.manualEditTreeForm.parentClassId = data.parentClassId
      this.getAllManuslNormal()
    },
    // 人工打分根据treeid获取table
    getAllManuslNormal: function() {
      let params = {
        modelId: this.modleIdNew,
        classId: this.treeIdMan,
        pageindex: this.pageindexAuto,
        pagesize: this.pagesizeAuto,
        classType: '2',
      }
      if (this.treeIdMan == '' || this.treeIdMan == null) {
        this.tableDataMan = []
        this.totalCountMan = 0
      } else {
        this.axios
          .post(
            manalScore + '/manualOrderQualityAssurance/getAllNormal.do',
            Qs.stringify(params)
          )
          .then((res) => {
            if (res.data.Count > 0) {
              this.tableDataMan = res.data.Data
              this.totalCountMan = res.data.Count
            } else {
              this.tableDataMan = []
              this.totalCountMan = 0
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    // 查询标准
    getAllNormal: function() {
      let params = {
        modelId: this.modleIdNew,
        classId: this.treeid,
        pageindex: this.pageindex,
        pagesize: this.pagesize,
        classType: '1',
      }
      if (this.treeid == '' || this.treeid == null) {
        this.tableRightData = []
        this.totalCount = 0
      } else {
        this.axios
          .post(
            manalScore + '/manualOrderQualityAssurance/getAllNormal.do',
            Qs.stringify(params)
          )
          .then((res) => {
            if (res.data.Data != null) {
              this.tableRightData = res.data.Data
              this.totalCount = res.data.Count
            } else {
              this.tableRightData = []
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    showkeyRules() {
      // 显示术语规则
      this.showKeyRules = !this.showKeyRules
    },
    addTableCanel: function() {
      this.addForm.domainsParamsQing = {
        domains: [
          {
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.addForm.chongDomains = {
        domains: [
          {
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.addForm.jingDomains = {
        domains: [
          {
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.addForm.domainsParamsYu = {
        domains: [
          {
            silenceTimeMin: '',
            silenceTimeMax: '',
            score: '',
          },
        ],
      }
      this.myTitle = '新增标准'
      this.$refs.addForm.resetFields()
      this.dialogFormVisible = false
    },
    addTableYesAutoThrottle() {
      this.lodashThrottle.throttle(this.addTableYesAuto, this)
    },
    /**
     * 人工打分打分 添加标准
     * **/
    addTableYesAuto: function() {
      let _this = this
      if (_this.standardTitle == '编辑标准') {
        let xlist = _this.AddTableFormMan.xuanDomains.domains
        let optext = []
        for (let i = 0; i < xlist.length; i++) {
          optext[i] = xlist[i].optionTexts
        }
        _this.optionTextsList = optext
        let params = {
          normalId: _this.normalIdMan,
          normalName: _this.AddTableFormMan.normalName,
          defaultScore: _this.AddTableFormMan.defaultScore,
          minScoreRange: _this.AddTableFormMan.minScoreRange,
          maxScoreRange: _this.AddTableFormMan.maxScoreRange,
          normalContent: _this.AddTableFormMan.normalContent,
          judge: _this.AddTableFormMan.judge,
          modelId: _this.modleIdNew,
          classId: _this.editClassId,
          optionTexts: _this.selectValue == 6 ? '' : _this.optionTextsList,
        }
        if (_this.AddTableFormMan.judge == 6) {
          _this.$refs.AddTableFormMan.validate((valid) => {
            if (valid) {
              let defaultscore = _this.AddTableFormMan.defaultScore
              let minScoreRange = _this.AddTableFormMan.minScoreRange
              let maxScoreRange = _this.AddTableFormMan.maxScoreRange
              if (
                Math.ceil(parseInt(defaultscore)) != parseInt(defaultscore) ||
                Math.ceil(parseInt(minScoreRange)) != parseInt(minScoreRange) ||
                Math.ceil(parseInt(maxScoreRange)) != parseInt(maxScoreRange)
              ) {
                _this.$message({
                  type: 'error',
                  message: '分值应为整数',
                })
                return
              }
              if (
                Math.ceil(this.AddTableFormMan.defaultScore) <
                  Math.ceil(this.AddTableFormMan.minScoreRange) ||
                Math.ceil(this.AddTableFormMan.defaultScore) >
                  Math.ceil(this.AddTableFormMan.maxScoreRange)
              ) {
                _this.$message({
                  type: 'error',
                  message: '默认分数应在分值范围内',
                })
                return
              }
              if (
                Math.ceil(this.AddTableFormMan.minScoreRange) >
                Math.ceil(this.AddTableFormMan.maxScoreRange)
              ) {
                _this.$message({
                  type: 'error',
                  message: '最大值应大于最小值',
                })
                return
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/saveManNormal.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success == true) {
                    _this.tableDataMan = res.data.Data
                    _this.totalCountMan = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '修改成功',
                    })
                    _this.standardTitle = '新增标准'
                    _this.$refs['AddTableFormMan'].resetFields()
                    _this.dialogFormVisibleMan = false
                    _this.getAllManuslNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        } else {
          _this.AddTableFormMan.maxScoreRange = 2
          _this.AddTableFormMan.minScoreRange = 1
          _this.AddTableFormMan.defaultScore = 1
          _this.$refs.AddTableFormMan.validate((valid) => {
            if (valid) {
              let domainsCount = _this.AddTableFormMan.xuanDomains.domains.length
              let domains = _this.AddTableFormMan.xuanDomains.domains
              for (let i = 0; i < domainsCount; i++) {
                // 循环判断选项不能为空
                if (domains[i].optionTexts === '' && _this.AddTableFormMan.judge == 7) {
                  _this.$message({
                    type: 'error',
                    message: '选项不能为空',
                  })
                  return
                }
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/saveManNormal.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success == true) {
                    _this.tableDataMan = res.data.Data
                    _this.totalCountMan = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '修改成功',
                    })
                    _this.standardTitle = '新增标准'
                    _this.$refs['AddTableFormMan'].resetFields()
                    _this.dialogFormVisibleMan = false
                    _this.getAllManuslNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        }
      } else {
        // 新增人工打分标准
        let xlist = _this.AddTableFormMan.xuanDomains.domains
        let optext = []
        for (let i = 0; i < xlist.length; i++) {
          optext[i] = xlist[i].optionTexts
        }
        _this.optionTextsList = optext
        let params = {
          normalName: _this.AddTableFormMan.normalName,
          defaultScore: _this.AddTableFormMan.defaultScore,
          minScoreRange: _this.AddTableFormMan.minScoreRange,
          maxScoreRange: _this.AddTableFormMan.maxScoreRange,
          normalContent: _this.AddTableFormMan.normalContent,
          judge: _this.selectValue,
          modelId: _this.modleIdNew,
          classId: _this.treeIdMan,
          optionTexts: _this.selectValue == 6 ? '' : _this.optionTextsList,
        }
        if (_this.selectValue === 8) {
          this.axios
            .post(
              manalScore + '/manualOrderQualityAssurance/saveManNormal.do',
              Qs.stringify(params)
            )
            .then(function(res) {
              if (res.data.success == true) {
                _this.tableDataMan = res.data.Data
                _this.totalCountMan = res.data.Count
                _this.$message({
                  type: 'success',
                  message: '修改成功',
                })
                _this.standardTitle = '新增标准'
                _this.$refs['AddTableFormMan'].resetFields()
                _this.dialogFormVisibleMan = false
                _this.getAllManuslNormal()
                _this.getScore()
              } else {
                _this.$message({
                  type: 'error',
                  message: res.data.message,
                })
              }
            })
        } else if (_this.selectValue == 6) {
          _this.$refs.AddTableFormMan.validate((valid) => {
            if (valid) {
              if (Math.ceil(_this.AddTableFormMan.minScoreRange) < 0) {
                this.$message({
                  type: 'error',
                  message: '分值应为正整数或0',
                })
                return
              }
              if (
                !Math.ceil(_this.AddTableFormMan.defaultScore) ||
                !Math.ceil(_this.AddTableFormMan.maxScoreRange)
              ) {
                this.$message({
                  type: 'error',
                  message: '分值应为整数',
                })
                return
              }
              if (
                Math.ceil(_this.AddTableFormMan.defaultScore) <
                  Math.ceil(_this.AddTableFormMan.minScoreRange) ||
                Math.ceil(_this.AddTableFormMan.defaultScore) >
                  Math.ceil(_this.AddTableFormMan.maxScoreRange)
              ) {
                this.$message({
                  type: 'error',
                  message: '默认分数应在分值范围内',
                })
                return
              }
              if (
                Math.ceil(_this.AddTableFormMan.minScoreRange) >
                Math.ceil(_this.AddTableFormMan.maxScoreRange)
              ) {
                _this.$message({
                  type: 'error',
                  message: '最大值应大于最小值',
                })
                return
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/saveManNormal.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success == true) {
                    _this.tableDataMan = res.data.Data
                    _this.totalCountMan = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '新增成功',
                    })
                    _this.$refs['AddTableFormMan'].resetFields()
                    _this.dialogFormVisibleMan = false
                    _this.standardTitle == '新增标准'
                    _this.getAllManuslNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                  // this.tableDataMan=[];
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        } else {
          _this.AddTableFormMan.maxScoreRange = 2
          _this.AddTableFormMan.minScoreRange = 1
          _this.AddTableFormMan.defaultScore = 2
          _this.$refs.AddTableFormMan.validate((valid) => {
            if (valid) {
              let domainsCount = _this.AddTableFormMan.xuanDomains.domains.length
              let domains = _this.AddTableFormMan.xuanDomains.domains
              for (let i = 0; i < domainsCount; i++) {
                // 循环判断选项不能为空
                if (domains[i].optionTexts === '') {
                  _this.$message({
                    type: 'error',
                    message: '选项不能为空',
                  })
                  return
                }
              }
              this.axios
                .post(
                  manalScore + '/manualOrderQualityAssurance/saveManNormal.do',
                  Qs.stringify(params)
                )
                .then((res) => {
                  if (res.data.success == true) {
                    _this.tableDataMan = res.data.Data
                    _this.totalCountMan = res.data.Count
                    _this.$message({
                      type: 'success',
                      message: '新增成功',
                    })
                    _this.standardTitle = '新增标准'
                    _this.$refs['AddTableFormMan'].resetFields()
                    _this.dialogFormVisibleMan = false
                    _this.getAllManuslNormal()
                    _this.getScore()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: res.data.message,
                    })
                  }
                })
                .catch(function(error) {
                  console.log(error)
                })
            }
          })
        }
      }
    },
    /**
     * 删除tree
     * */
    delTree: function() {
      if (this.treeid == null || this.treeid == '') {
        this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        let params = {
          classId: this.treeid,
        }
        /* if(this.clist!=null){
           this.$message({
           type: 'warning',
           message: '此分类下有子分类，不能删除'
           });
           } */
        // else{
        this.$confirm('确定要删除【' + this.typeid + '】吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
          .then(() => {
            this.axios
              .post(
                manalScore + '/manualOrderQualityAssurance/deleteQaClass.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data == true) {
                  this.$message({
                    type: 'success',
                    message: '删除成功!',
                  })
                  /* if(this.parentid=='0'){
                   this.pid="";
                   } */
                } else {
                  this.$message({
                    type: 'error',
                    message: '删除失败!',
                  })
                }
                this.getLeftTrees()
                this.treeid = ''
                this.getAllNormal()
                this.getScore()
                this.editTreeForm.typeid = ''
                this.addTreeForm.typeid = ''
              })
              .catch(function(error) {
                console.log(error)
              })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除',
            })
          })
        //  }
      }
    },
    addTree: function() {
      if (this.pid == '') {
        this.dialogTreeFormVisible = true
        this.addTreeForm.typeid = ''
      } else {
        /* if (this.treeid == null || this.treeid == "") {
           this.$message({
           type: 'warning',
           message: '请选择一个分类'
           });
           } */
        //  else {
        this.pid = this.treeid
        this.dialogTreeFormVisible = true
        // }
      }
    },
    /**
     * 修改tree
     * **/
    editTree: function() {
      if (this.treeid == '') {
        this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        this.editTreeModal = true
      }
    },
    saveClassTwoThrottle() {
      this.lodashThrottle.throttle(this.saveClassMan, this)
    },
    saveClassMan: function() {
      // this.dialogTreeFormVisibleMan=false;
      let params = {
        classTitle: this.addTreeManual.classTitle,
        remark: this.addTreeManual.remark,
        modleId: this.modleIdNew,
        parentClassId: this.treeIdMan,
        classType: '2',
      }
      let checkParams = {
        classTitle: this.addTreeManual.classTitle,
        modleId: this.modleIdNew,
        parentClassId: this.treeIdMan,
        classType: '2',
      }
      this.$refs.addTreeManual.validate((valid) => {
        if (valid) {
          this.axios
            .post(
              manalScore + '/manualOrderQualityAssurance/checkClassExist.do',
              Qs.stringify(checkParams)
            )
            .then((res) => {
              if (res.data == false) {
                this.$message({
                  type: 'error',
                  message: '这个分类名称已经存在，请重新输入名称！',
                })
              } else {
                this.axios
                  .post(
                    manalScore + '/manualOrderQualityAssurance/saveClass.do',
                    Qs.stringify(params)
                  )
                  .then((res) => {
                    if (res.data.flag == true) {
                      this.$message({
                        type: 'success',
                        message: '添加成功',
                      })
                    } else {
                      this.$message({
                        type: 'error',
                        message: '添加失败',
                      })
                    }
                    this.dialogTreeFormVisibleMan = false
                    this.$refs.addTreeManual.resetFields()
                    this.getLeftTreesArtificial()
                    this.treeIdMan = ''
                    this.pidMan = ''
                  })
                  .catch(function(error) {
                    console.log(error)
                  })
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    saveClassThrottle() {
      this.lodashThrottle.throttle(this.saveClass, this)
    },
    /**
     * 新增tree
     * **/
    saveClass: function() {
      let params = {
        classTitle: this.addTreeForm.classTitle,
        remark: this.addTreeForm.remark,
        modleId: this.modleIdNew,
        parentClassId: this.treeid,
        classType: 1,
      }
      let checkParams = {
        classTitle: this.addTreeForm.classTitle,
        modleId: this.modleIdNew,
        parentClassId: this.treeid,
        classType: 1,
      }
      this.$refs.addTreeForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(
              manalScore + '/manualOrderQualityAssurance/checkClassExist.do',
              Qs.stringify(checkParams)
            )
            .then((res) => {
              if (res.data === false) {
                this.$message({
                  type: 'error',
                  message: '这个分类名称已经存在，请重新输入名称',
                })
              } else {
                this.axios
                  .post(
                    manalScore + '/manualOrderQualityAssurance/saveClass.do',
                    Qs.stringify(params)
                  )
                  .then((res) => {
                    if (res.data.flag === true) {
                      this.$message({
                        type: 'success',
                        message: '添加成功',
                      })
                    } else {
                      this.$message({
                        type: 'error',
                        message: '添加失败',
                      })
                    }
                    this.dialogTreeFormVisible = false
                    this.$refs['addTreeForm'].resetFields()
                    this.getLeftTrees()
                    this.treeid = ''
                    this.pid = ''
                  })
                  .catch(function(error) {
                    console.log(error)
                  })
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    // 获得自动打分左侧tree
    getLeftTrees: function() {
      let params = {
        modleId: this.modleIdNew,
        classType: '1',
      }
      this.axios
        .post(
          manalScore + '/manualOrderQualityAssurance/getTrees.do',
          Qs.stringify(params)
        )
        .then((res) => {
          let listenData = res.data
          let trees = []
          this.regroupTree(listenData, trees)
          this.leftTreeData = trees
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 给tree重新赋值
    regroupTree: function(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        if (value.length === 0) {
          this.leftMMTreeData = []
        } else {
          if (value[i].childIqc === null) {
            treeList[i] = {
              id: value[i].classId,
              label: value[i].classTitle,
              parentClassId: value[i].parentClassId,
              remark: value[i].remark,
              children: null,
            }
          } else {
            treeList[i] = {
              id: value[i].classId,
              label: value[i].classTitle,
              parentClassId: value[i].parentClassId,
              remark: value[i].remark,
              children: this.regroupTree(value[i].childIqc, []),
            }
          }
        }
      }
      return treeList
    },
    getLeftTreesArtificial: function() {
      let params = {
        modleId: this.modleIdNew,
        classType: 2,
      }
      this.axios
        .post(
          manalScore + '/manualOrderQualityAssurance/getTrees.do',
          Qs.stringify(params)
        )
        .then((res) => {
          let listenData = res.data
          let trees = []
          this.regroupTreeArtificial(listenData, trees)
          this.leftMMTreeData = trees
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 给人工打分 左侧tree重新赋值
    regroupTreeArtificial: function(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        if (value.length === 0) {
          this.leftTreeData = []
        } else {
          if (value[i].childIqc === null) {
            treeList[i] = {
              id: value[i].classId,
              label: value[i].classTitle,
              parentClassId: value[i].parentClassId,
              remark: value[i].remark,
              children: null,
            }
          } else {
            treeList[i] = {
              id: value[i].classId,
              label: value[i].classTitle,
              parentClassId: value[i].parentClassId,
              remark: value[i].remark,
              children: this.regroupTreeArtificial(value[i].childIqc, []),
            }
          }
        }
      }
      return treeList
    },
    /**
     * 选择打分纬度
     * **/
    optionChange: function(val) {
      this.addEditJudge = val
      if (val === 1) {
        $('#qingxu').show()
        $('#chongfu').hide()
        $('#jingmo').hide()
        $('#yusu').hide()
        $('#guanjianci').hide()
      } else if (val === 2) {
        $('#qingxu').hide()
        $('#chongfu').show()
        $('#jingmo').hide()
        $('#yusu').hide()
        $('#guanjianci').hide()
      } else if (val === 3) {
        $('#qingxu').hide()
        $('#chongfu').hide()
        $('#jingmo').show()
        $('#yusu').hide()
        $('#guanjianci').hide()
      } else if (val === 4) {
        $('#qingxu').hide()
        $('#chongfu').hide()
        $('#jingmo').hide()
        $('#yusu').show()
        $('#guanjianci').hide()
      } else {
        $('#qingxu').hide()
        $('#chongfu').hide()
        $('#jingmo').hide()
        $('#yusu').hide()
        $('#guanjianci').show()
        this.showOffset = true
        this.showScoreType = true
        if (this.myTitle === '修改标准' || this.myTitle === '查看标准') {
        } else {
          this.addForm.minScoreRange = ''
          this.addForm.maxScoreRange = ''
          this.addForm.mingScore = ''
        }
      }
    },
    optionChangeArtificial: function(val) {
      this.selectValue = val
      if (val === 6) {
        $('#shoudong').show()
        $('#xuanxiang').hide()
        $('#zhimingxiang').hide()
        if (this.standardTitle == '编辑标准') {
          console.log(this.AddTableFormMan.maxScoreRange)
        } else if (this.standardTitle == '查看标准') {
        } else {
          this.AddTableFormMan.maxScoreRange = ''
          this.AddTableFormMan.minScoreRange = ''
          this.AddTableFormMan.defaultScore = ''
        }
      } else if (val === 7) {
        $('#shoudong').hide()
        $('#zhimingxiang').hide()
        $('#xuanxiang').show()
        if (this.standardTitle === '新增标准') {
          this.AddTableFormMan.maxScoreRange = ''
          this.AddTableFormMan.minScoreRange = ''
          this.AddTableFormMan.defaultScore = ''
        }
      } else {
        $('#shoudong').hide()
        $('#xuanxiang').hide()
        $('#zhimingxiang').show()
        if (this.standardTitle === '新增标准') {
          this.AddTableFormMan.maxScoreRange = ''
          this.AddTableFormMan.minScoreRange = ''
          this.AddTableFormMan.defaultScore = ''
        }
      }
    },
    changeRadioRole: function(val) {
      this.roleType = val
    },
    changeDeadItem: function(val) {
      if (val === '1') {
        this.mingScoreDisabled = true
        this.addForm.mingScore = 0
        this.addForm.maxScoreRange = 1
        this.addForm.minScoreRange = 0
        this.addForm.defaultScore = 1
      } else {
        this.mingScoreDisabled = false
      }
    },
    changePosition: function(val) {
      if (val === '3') {
        this.showOffset = false
      } else {
        this.showOffset = true
      }
    },
    /**
     * 静默类型选择
     * **/
    changeRadio: function(val) {
      this.slienceType = val
      if (val === 1) {
        this.numsTitle = '秒'
      } else if (val === 2) {
        this.numsTitle = '次'
      } else if (val === 3) {
        this.numsTitle = '%'
      } else {
        this.numsTitle = '秒'
      }
    },
    removeDomainQing(item) {
      let index = this.addForm.domainsParamsQing.domains.indexOf(item)
      if (index === 1) {
        return
      } else {
        this.addForm.domainsParamsQing.domains.splice(index, 1)
      }
    },
    addDomainQing() {
      this.addForm.domainsParamsQing.domains.push({
        value: '',
        key: Date.now(),
      })
    },
    // 重叠次数 添加 删除 input
    addChongDomain() {
      this.addForm.chongDomains.domains.push({
        value: '',
        key: Date.now(),
      })
    },
    // 重叠次数 添加 删除 input
    removeChongDomain(item) {
      let index = this.addForm.chongDomains.domains.indexOf(item)
      if (index !== -1) {
        this.addForm.chongDomains.domains.splice(index, 1)
      } else {
        this.addForm.chongDomains.domains.splice(index, 1)
      }
    },
    // 静默
    addJingDomain() {
      this.addForm.jingDomains.domains.push({
        value: '',
        key: Date.now(),
      })
    },
    // 静默
    removeJingDomain: function(item) {
      let index = this.addForm.jingDomains.domains.indexOf(item)
      if (index !== -1) {
        this.addForm.jingDomains.domains.splice(index, 1)
      } else {
        this.addForm.jingDomains.domains.splice(index, 1)
      }
    },
    // 语速
    addDomainYu: function() {
      this.addForm.domainsParamsYu.domains.push({
        value: '',
        key: Date.now(),
      })
    },
    // 添加语速
    removeDomainYu(item) {
      let index = this.addForm.domainsParamsYu.domains.indexOf(item)
      if (index !== -1) {
        this.addForm.domainsParamsYu.domains.splice(index, 1)
      } else {
        this.addForm.domainsParamsYu.domains.splice(index, 1)
      }
    },
    // 选项
    addDomainMan: function() {
      this.AddTableFormMan.xuanDomains.domains.push({
        value: '',
        key: Date.now(),
      })
    },
    // 选项
    removeDomainMan(item) {
      let index = this.AddTableFormMan.xuanDomains.domains.indexOf(item)
      if (index !== -1) {
        this.AddTableFormMan.xuanDomains.domains.splice(index, 1)
      } else {
        this.addForm.xuanDomains.domains.splice(index, 1)
      }
    },
    /**
     * 返回父组件
     * **/
    goBack: function() {
      this.$emit('send', true)
    },
    // 获取总分
    getScore: function() {
      let _this = this
      let params = {
        modelId: this.modleIdNew,
      }
      this.axios
        .post(
          manalScore + '/manualOrderQualityAssurance/getTotalScore.do',
          Qs.stringify(params)
        )
        .then(function(res) {
          if (res.data.count <= 0) {
            _this.totalScores = 0
          } else {
            _this.totalScores = res.data.count
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    changeScoreType: function(val) {
      if (val !== 1) {
        this.mingScoreDisabled = false
      }
      if (val === 1) {
        this.addForm.deadItem = '2'
        this.showScoreType = true
        this.showJingmoType = false
      } else if (val === 2) {
        this.showScoreType = false
        this.showJingmoType = true
      }
    },
    changeSilenceType: function(val) {
      if (val === 1) {
        this.showSilenceType = true
      } else {
        this.showSilenceType = false
      }
    },
  },
  computed: {
    loadData() {
      if (this.modleIdNew !== '') {
        this.getScore(this.modleIdNew)
        this.getLeftTrees(this.modleIdNew)
        this.getLeftTreesArtificial(this.modleIdNew)
        this.tableRightData = []
        this.tableDataMan = []
        this.namesForm.modleTitle = this.mdtitle
        this.editNamesForm.remark = this.info.remark
        this.addTreeForm.typeid = ''
        this.addTreeManual.typeid = ''
        return this.modleIdNew
      } else {
        this.addTreeForm.typeid = ''
        this.addTreeManual.typeid = ''
        this.tableRightData = []
        this.tableDataMan = []
        this.leftTreeData = []
        this.leftMMTreeData = []
      }
    },
  },
  watch: {
    loadData(val, oldval) {},
  },
}
</script>
<style scoped="scoped">
.newTemplate {
  width: 100%;
  padding: 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
}

.newTemplate #keylists {
  border: 1px solid #bfcbd9;
  box-sizing: border-box;
  border-radius: 4px;
  height: 200px;
}

.newTemplate .autoGrading {
  width: 100%;
  box-sizing: border-box;
  height: 100%;
  position: relative;
}

.newTemplate .autoGrading-header {
  position: absolute;
  width: 100%;
  top: 0px;
  border-bottom: 1px solid #d1dbe7;
  height: 47px;
}

.newTemplate .autoGrading-header .names {
  float: left;
  /*width:400px;*/
}

.newTemplate .autoGrading-header .names .names-input {
  width: 160px;
}

.newTemplate .autoGrading-header .names .scores {
  color: #85ce61;
  font-size: 24px;
}

.newTemplate .autoGrading-header .names .pl10 {
  padding-left: 10px;
}

.newTemplate .autoGrading-header .buttons {
  height: 37px;
  padding-bottom: 10px;
  float: right;
}

.newTemplate .buttons button {
  width: 90px;
  margin-right: 10px;
  font-family: '微软雅黑';
  float: right;
}

.newTemplate .autoGrading-header .form {
  margin-top: 10px;
  padding-left: 10px;
  border-bottom: 1px dashed #d1dbe7;
}

.newTemplate .autoGrading-left {
  width: 230px;
  float: left;
  left: 0px;
  top: 0px;
  height: 100%;
  position: relative;
  border-right: 1px solid #d1dbe7;
}

.newTemplate .autoGrading-left .item {
  position: absolute;
  top: 0px;
  left: 0px;
  width: 100%;
  /*height: 57px;*/
  border-bottom: 1px dashed #d1dbe7;
}

.newTemplate .autoGrading-left .item a button {
  opacity: 0.7;
  width: 25px;
  height: 25px;
  padding: 0px;
}

.newTemplate .autoGrading-left .item a {
  float: right;
  margin: 10px 10px 10px 0px;
}

.newTemplate .autoGrading-left .item a i {
  cursor: pointer;
  margin-right: 10px;
  border: 1px solid #d1dbe7;
  padding: 5px;
  border-radius: 3px;
}

.newTemplate .autoGrading-right {
  margin-left: 231px;
  position: relative;
  height: 100%;
  top: 0;
}

.newTemplate .autoGrading-right .autoGrading-right-header {
  float: left;
  box-sizing: border-box;
  top: 0px;
  width: 100%;
  height: 58px;
}

.newTemplate .preview .total {
  float: right;
}

.newTemplate .preview .total label {
  color: #85ce61;
  font-size: 24px;
}

.newTemplate .preview .header {
  height: 30px;
}

.newTemplate .preview .border {
  border-bottom: 1px dashed #ccc;
  margin-top: 10px;
  margin-bottom: 10px;
}

.newTemplate .preview .normalNameClass {
  margin-bottom: -8px;
  margin-top: 10px;
  height: 35px;
  color: #9dadc2;
}

.newTemplate .preview .bodys {
  float: left;
  width: 100%;
}

.newTemplate .preview .bodys .qualityTitle {
  padding-bottom: 10px;
  color: #9dadc2;
  font-size: 14px;
  width: 100%;
}

.newTemplate .preview .bodys .qualityTitle p {
  padding-left: 10px;
}

.newTemplate .preview .bodys .leftbody {
  width: 100%;
  float: left;
}

.newTemplate .preview .bodys .leftbody .box {
  float: left; /*margin-top: 10px;*/
  overflow: hidden;
  width: 100%;
}

.judgeLists {
  float: left;
  width: 100%; /*margin-bottom: 10px;*/
}

.judgeLists .judgeTitle {
  /*width:100%;*/
  margin: 10px 0px 0px 0px; /*clear: both*/
  float: left;
}

.judgeLists .judgeTitle span {
  padding-left: 15px;
}

.newTemplate .preview .bodys .leftbody .lists {
  width: 45%;
  float: left;
  /*margin-bottom: 10px;*/
  padding-left: 15px;
}

.newTemplate .preview .bodys .leftbody .lists .titleInput {
  width: 140px;
  margin-left: 10px;
}

.newTemplate .preview .bodys .leftbody .lists p {
  /*width:80px;*/
  display: inline-block;
}

.newTemplate .preview .bodys .rightbody {
  float: left;
  width: 60%;
  margin-top: 30px;
}

.newTemplate .preview .bodys .title {
  float: left;
  text-align: right;
  width: 60px;
}

.newTemplate .preview .bodys .services {
  /*border: 1px solid #bfcbd9;*/
  /*clear: both;*/
  /*width: 100%;*/
  line-height: 36px;
  /*margin-left: 10px;*/
  /*margin-bottom: 10px;*/
  float: left;
  cursor: pointer;
}

.newTemplate .preview .bodys .services .defaultlabel {
  background: #97a8be;
  color: #fff;
}

.newTemplate .preview .bodys .services p {
  border: 1px solid #bfcbd9;
  border-radius: 4px;
  margin: 6px 2px 0px 2px;
  float: left;
  border-right: 1px solid #ccc;
  display: inline-block;
  cursor: pointer;
  padding: 0px 10px 0px 10px;
  /*width: 80px;*/
  text-align: center;
}

.newTemplate .preview .header p {
  display: block;
  float: left;
}

.newTemplate .preview .header span {
  display: block;
  float: right;
}

.newTemplate .preview .header span em {
  font-style: normal;
  font-size: 18px;
  padding-left: 6px;
  color: #ff132f;
}

.newTemplate .autoGrading-right .autoGrading-content {
  padding-top: 58px;
  padding-bottom: 80px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}

.newTemplate .autoGrading-right .autoGrading-right-table {
  /*padding-top: 68px;*/
  /* padding-bottom: 80px;
     box-sizing: border-box;*/
  width: 100%;
  height: 100%;
  cursor: pointer;
  /* position: absolute;
     top: 58px;
     left: 0;
     bottom: 60px;
     width: 100%;*/
}

.newTemplate .autoGrading-right .autoGrading-right-table .el-table {
  width: 98%;
  margin: 0 auto;
}

.newTemplate .autoGrading-page {
  right: 10px;
  position: absolute;
  bottom: 10px;
}

.newTemplate .autoGrading-right .bodys {
  height: 100%;
  width: 100%;
  box-sizing: border-box;
  position: relative;
  /*overflow: hidden;*/
}

.newTemplate .autoGrading-body {
  position: absolute;
  top: 58px;
  left: 0;
  bottom: 1px;
  width: 100%;
}

.newTemplate .w120 {
  width: 100px;
  margin-right: 10px;
}

.newTemplate .ml {
  margin-right: 10px;
}

.newTemplate .keys {
  cursor: pointer;
  margin-left: 130px;
}

.newTemplate .keys .keylabel {
  display: inline-block;
  border-radius: 5px;
  height: 20px;
  line-height: 20px;
  cursor: pointer;
  padding: 3px 5px 3px 5px;
  font-size: 12px;
  text-align: center;
  background-color: #e4e8f1;
  color: #48576a;
}

.newTemplate .keys label:hover {
  background: #eef1f6;
  color: #8691a5;
}

.newTemplate .autoGrading-left .typeList {
  position: absolute;
  top: 57px;
  left: 0px;
  bottom: 0px;
  overflow: auto;
  width: 100%;
  color: #777;
  cursor: pointer;
}

.newTemplate #keyRules {
  border: 1px solid #bfcbd9;
  box-shadow: 2px 2px 2px 2px #f4f4f4;
  padding: 20px 25px 30px 18px;
  box-sizing: border-box;
  width: 400px;
  overflow-y: auto;
  height: 380px;
  position: absolute;
  top: 120px;
  left: 280px;
}

/*.newTemplate #keyRules::before {
    content: "";
    height: 15px;
    position: absolute;
    width: 15px;
    background: #fff;
    top: 43%;
    right: -7px;
    transform: rotate(45deg);
    border-top: 1px solid #bfcbd9;
    border-right: 1px solid #bfcbd9;
  }*/
.newTemplate .m10 {
  margin: 10px 0px 0px 10px;
}

.newTemplate .w60 {
  width: 60px;
  margin-right: 10px;
}

.newTemplate .termRules {
  display: block;
  cursor: pointer;
  position: absolute;
  top: -10px;
  right: -60px;
  color: #5e6873;
  text-decoration: underline;
}
</style>
<style>
#qNewTemplate .el-tabs--border-card {
  /*width: 100%;
    background: #fff;
    border: 1px solid #d1dbe5;
    height: 100%;
    position: relative;*/
  overflow: hidden;
  height: 100%;
  position: relative;
}

#qNewTemplate .el-tabs--border-card > .el-tabs__content {
  width: 100%;
  position: absolute;
  padding: 0px !important;
  top: 40px;
  left: 0px;
  bottom: 1px;
}

#qNewTemplate .el-tabs__content .el-tab-pane {
  width: 100%;
  height: 100%;
}

#qNewTemplate .el-tabs--border-card > .el-tabs__header {
  height: 40px;
}

#qNewTemplate .el-tree {
  cursor: default;
  background: #fff;
  border: none;
}

#qNewTemplate .autoGrading-left .el-dialog--small {
  width: 32%;
}

#qNewTemplate .autoGrading-right .el-dialog--small {
  width: 58%;
}

#qNewTemplate .preview .el-table::before {
  left: 0;
  bottom: 0;
  width: 100%;
  height: 0px;
}
</style>
