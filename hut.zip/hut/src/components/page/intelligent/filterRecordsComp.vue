<template>
  <el-form
    ref="intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Ref"
    :inline="true"
    :rules="intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Rules"
    :model="intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model"
    label-width="84px"
  >
    <h3>录音属性</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item prop="callId" style="color:#8691a5" label="录音编号"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.callId
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="calledNo" style="color:#8691a5" label="被叫号码"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.calledNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="24"
        ><el-form-item prop="callTime_Min" style="color:#8691a5" label="通话时长"
          ><el-input
            style="width:55px"
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.callTime_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="callTime_Max"
          ><el-input
            style="width:55px"
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.callTime_Max
            "
            placeholder=""
          ></el-input></el-form-item
        ><el-form-item prop="callId"
          ><el-select
            style="width:120px;margin-left:10px"
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.timeType
            "
            placeholder="请选择"
          >
            <el-option label="秒" value="2"></el-option
            ><el-option label="分" value="1"></el-option
            ><el-option label="时" value="0"></el-option></el-select
        ></el-form-item> </el-col
      ><el-col :span="6"
        ><el-form-item prop="callNo" style="color:#8691a5" label="主叫号码"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.callNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="6"
        ><el-form-item prop="extenNo" style="color:#8691a5" label="分机号码"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.extenNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>员工属性</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item prop="seatNo" style="color:#8691a5" label="坐席工号"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.seatNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="seatName" style="color:#8691a5" label="坐席姓名"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.seatName
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="deptId" style="color:#8691a5" label="坐席组"
          ><el-select
            style="width:160px"
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.deptId
            "
            placeholder="请选择"
            id="seatGroup"
            ><el-option
              v-for="item in seatGroupOptions"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option></el-select></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>录音属性</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item prop="customerName" style="color:#8691a5" label="客户姓名"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.customerName
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>语音属性</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item prop="sourceFrom" style="color:#8691a5" label="业务来源"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.sourceFrom
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="callNum" style="color:#8691a5" label="累计拨打次数"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.callNum
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="note" style="color:#8691a5" label="小结备注"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.note
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="custAge" style="color:#8691a5" label="客户年龄"
          ><el-input
            v-model="
              intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model.custAge
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row
  ></el-form>
</template>

<script>
export default {
  data() {
    return {
      intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model: {
        callId: '',
        callId$CName: '录音编号',
        calledNo: '',
        calledNo$CName: '被叫号码',
        callTime_Min: '',
        callTime_Min$CName: '通话时长(最小值)',
        callTime_Max: '',
        callTime_Max$CName: '通话时长(最大值)',
        callNo: '',
        callNo$CName: '主叫号码',
        extenNo: '',
        extenNo$CName: '分机号码',
        seatNo: '',
        seatNo$CName: '坐席工号',
        seatName: '',
        seatName$CName: '坐席姓名',
        deptId: '',
        deptId$CName: '坐席组',
        customerName: '',
        customerName$CName: '客户姓名',
        sourceFrom: '',
        sourceFrom$CName: '业务来源',
        callNum: '',
        callNum$CName: '累计拨打次数',
        note: '',
        note$CName: '小结备注',
        custAge: '',
        custAge$CName: '客户年龄',
      },
      intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Rules: {},
      validateFunc: function() {},
    }
  },
}
</script>

<style></style>
