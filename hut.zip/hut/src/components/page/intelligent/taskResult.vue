<template>
  <div class="intelligent" id="intelligent">
    <div class="taskResult">
      <div class="intelligent-header">
        <div class="operation">
          <div class="tips">
            <label>抽出数量</label>
            <el-tag type="success">{{ sampleCount }}</el-tag>
            <label>周期录音数量</label>
            <el-tag type="warning">{{ allSampleCount }}</el-tag>
            <label>抽出率</label>
            <el-tag type="danger">{{ checkedRatio + '%' }}</el-tag>
          </div>
          <div class="btns">
            <el-button type="primary" @click="exportTaskResult">导出</el-button>
            <el-button style="width:100px" @click="showAreaChartDialog"
              >查看区域图</el-button
            >
            <el-button @click="turnToPrePage">返回</el-button>
          </div>
        </div>
      </div>
      <div class="intelligent-content">
        <div class="intelligent-content-pos" style="overflow-y:auto;">
          <div style="width:100%;height:100%;">
            <i
              class="el-icon-d-caret fr"
              @click="sortQuery"
              style="cursor:pointer;margin-top:25px;margin-bottom: 10px"
              >按照录音时间排序</i
            >
            <el-table
              ref="taskResultTable"
              :data="taskResultTableData"
              border
              tooltip-effect="dark"
            >
              <el-table-column type="index" label="序号" width="80"></el-table-column>
              <el-table-column prop="callId" label="录音编号">
                <template scope="scope">
                  <el-button type="text" @click.prevent="showDetail(scope.row.callId, scope.row.recordFileURL)">{{
                    scope.row.callId
                  }}</el-button>
                </template>
              </el-table-column>
              <el-table-column
                prop="callSTime"
                :formatter="convertTime"
                label="录音时间"
              ></el-table-column>
              <el-table-column
                prop="callTime"
                :formatter="convertCallTime"
                label="录音时长"
              ></el-table-column>
              <el-table-column prop="calledNo" label="电话号码"></el-table-column>
              <el-table-column
                prop="seatName"
                label="坐席姓名"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="seatGroup"
                label="坐席组"
                show-overflow-tooltip
              ></el-table-column>
            </el-table>
          </div>
        </div>
        <div class="intelligent-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog
      id="lookAreaDialog"
      :title="this.areaMap"
      :close-on-click-modal="false"
      :visible.sync="lookAreaDialogVisible"
      @open="getAreaStats"
    >
      <div class="chartCondition">
        <el-form :inline="true">
          <el-form-item>
            <el-col :span="11">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                v-model="startTime"
                style="width: 100%;"
              ></el-date-picker>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                v-model="endTime"
                style="width: 100%;"
              ></el-date-picker>
            </el-col>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="getAreaStats">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
      <div id="area_container" style="width: 100%; height: 600px;">
        <p>
          暂无数据
        </p>
      </div>
    </el-dialog>
    <el-dialog
      class="recordiplaywarp"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <template>
        <div class="recordingplayWrap">
          <recordingplay
            ref="recordPlay"
            @onclose="recordPlayCloseHandler"
            @onminimize="recordPlayMinimizeHandler"
          ></recordingplay>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
<script>
import vTask from '../intelligent/Newtask.vue'
import vPlayer from '../../common/player.vue'
import bus from '../../common/bus.js'
import recordingplay from '../recordingPlay/recordingPlayNew.vue'
import Qs from 'qs'
import moment from 'moment'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
export default {
  components: {
    vTask,
    vPlayer,
    recordingplay,
  },
  data() {
    return {
      recordDialogVisible: false,
      innerVisible: false,
      showVplayer: true,
      currentPage: 1,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      taskResultTableData: [], // 任务的执行情况数据
      sampleCount: '0', // 抽出数量
      allSampleCount: '0', // 周期录音数量
      checkedRatio: '0', // 抽出率
      maxCount: 0, // 默认最大值
      sortType: 'desc',
      lookAreaDialogVisible: false,
      startTime: null,
      endTime: null,
      areaChart: null,
      areaMap: '',
    }
  },
  methods: {
    convertTime: function(row, column, cellValue) {
      return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
    },
    showAreaChartDialog: function() {
      if (this.projectType == '1') {
        this.areaMap = '即时任务区域图'
      } else if (this.projectType == '2') {
        this.areaMap = '循环任务区域图'
      }
      this.lookAreaDialogVisible = true
    },
    getAreaStats: function() {
      let params = {
        startTime: this.gettimeform(this.startTime, false),
        endTime: this.gettimeform(this.endTime, false),
      }
      if (this.projectType == '1') {
        params['otherKey'] = this.projectId
      } else {
        params['otherKey'] = this.taskId
      }
      let self = this
      this.axios
        .post(currentBaseUrl + '/itFilter/getDetailAreaStats.do', Qs.stringify(params))
        .then(function(response) {
          self.createAreaStatsChart(response.data)
        })
    },
    gettimeform(val, toDate) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let hours = date.getHours()
      if (hours < 10) {
        hours = '0' + hours
      }
      let minute = date.getMinutes()
      if (minute < 10) {
        minute = '0' + minute
      }
      let second = date.getSeconds()
      if (second < 10) {
        second = '0' + second
      }
      let str = year + '-' + month + '-' + day + ' ' + hours + ':' + minute + ':' + second
      if (toDate) {
        str = year + '-' + month + '-' + day
      }
      return str
    },
    createAreaStatsChart(mmdata) {
      if (this.areaChart) {
        this.areaChart.dispose()
      }
      // 区域图最大值获取
      let countArr = []
      for (let a = 0; a < mmdata.length; a++) {
        countArr.push(mmdata[a]['count'])
      }
      this.maxCount = Math.max.apply(null, countArr)
      let legenddata = []
      for (let j = 0; j < mmdata.length; j++) {
        legenddata[j] = mmdata[j]['city_name']
      }
      let geoCoordMap = {
        海门: [121.15, 31.89],
        鄂尔多斯: [109.781327, 39.608266],
        招远: [120.38, 37.35],
        舟山: [122.207216, 29.985295],
        齐齐哈尔: [123.97, 47.33],
        盐城: [120.13, 33.38],
        赤峰: [118.87, 42.28],
        青岛: [120.33, 36.07],
        乳山: [121.52, 36.89],
        金昌: [102.188043, 38.520089],
        泉州: [118.58, 24.93],
        莱西: [120.53, 36.86],
        日照: [119.46, 35.42],
        胶南: [119.97, 35.88],
        南通: [121.05, 32.08],
        拉萨: [91.11, 29.97],
        云浮: [112.02, 22.93],
        梅州: [116.1, 24.55],
        文登: [122.05, 37.2],
        上海: [121.48, 31.22],
        攀枝花: [101.718637, 26.582347],
        威海: [122.1, 37.5],
        承德: [117.93, 40.97],
        厦门: [118.1, 24.46],
        汕尾: [115.375279, 22.786211],
        潮州: [116.63, 23.68],
        丹东: [124.37, 40.13],
        太仓: [121.1, 31.45],
        曲靖: [103.79, 25.51],
        烟台: [121.39, 37.52],
        福州: [119.3, 26.08],
        瓦房店: [121.979603, 39.627114],
        即墨: [120.45, 36.38],
        抚顺: [123.97, 41.97],
        玉溪: [102.52, 24.35],
        张家口: [114.87, 40.82],
        阳泉: [113.57, 37.85],
        莱州: [119.942327, 37.177017],
        湖州: [120.1, 30.86],
        汕头: [116.69, 23.39],
        昆山: [120.95, 31.39],
        宁波: [121.56, 29.86],
        湛江: [110.359377, 21.270708],
        揭阳: [116.35, 23.55],
        荣成: [122.41, 37.16],
        连云港: [119.16, 34.59],
        葫芦岛: [120.836932, 40.711052],
        常熟: [120.74, 31.64],
        东莞: [113.75, 23.04],
        河源: [114.68, 23.73],
        淮安: [119.15, 33.5],
        泰州: [119.9, 32.49],
        南宁: [108.33, 22.84],
        营口: [122.18, 40.65],
        惠州: [114.4, 23.09],
        江阴: [120.26, 31.91],
        蓬莱: [120.75, 37.8],
        韶关: [113.62, 24.84],
        嘉峪关: [98.289152, 39.77313],
        广州: [113.23, 23.16],
        延安: [109.47, 36.6],
        太原: [112.53, 37.87],
        清远: [113.01, 23.7],
        中山: [113.38, 22.52],
        昆明: [102.73, 25.04],
        寿光: [118.73, 36.86],
        盘锦: [122.070714, 41.119997],
        长治: [113.08, 36.18],
        深圳: [114.07, 22.62],
        珠海: [113.52, 22.3],
        宿迁: [118.3, 33.96],
        咸阳: [108.72, 34.36],
        铜川: [109.11, 35.09],
        平度: [119.97, 36.77],
        佛山: [113.11, 23.05],
        海口: [110.35, 20.02],
        江门: [113.06, 22.61],
        章丘: [117.53, 36.72],
        肇庆: [112.44, 23.05],
        大连: [121.62, 38.92],
        临汾: [111.5, 36.08],
        吴江: [120.63, 31.16],
        石嘴山: [106.39, 39.04],
        沈阳: [123.38, 41.8],
        苏州: [120.62, 31.32],
        茂名: [110.88, 21.68],
        嘉兴: [120.76, 30.77],
        长春: [125.35, 43.88],
        胶州: [120.03336, 36.264622],
        银川: [106.27, 38.47],
        张家港: [120.555821, 31.875428],
        三门峡: [111.19, 34.76],
        锦州: [121.15, 41.13],
        南昌: [115.89, 28.68],
        柳州: [109.4, 24.33],
        三亚: [109.511909, 18.252847],
        自贡: [104.778442, 29.33903],
        吉林: [126.57, 43.87],
        阳江: [111.95, 21.85],
        泸州: [105.39, 28.91],
        西宁: [101.74, 36.56],
        宜宾: [104.56, 29.77],
        呼和浩特: [111.65, 40.82],
        成都: [104.06, 30.67],
        大同: [113.3, 40.12],
        镇江: [119.44, 32.2],
        桂林: [110.28, 25.29],
        张家界: [110.479191, 29.117096],
        宜兴: [119.82, 31.36],
        北海: [109.12, 21.49],
        西安: [108.95, 34.27],
        金坛: [119.56, 31.74],
        东营: [118.49, 37.46],
        牡丹江: [129.58, 44.6],
        遵义: [106.9, 27.7],
        绍兴: [120.58, 30.01],
        扬州: [119.42, 32.39],
        常州: [119.95, 31.79],
        潍坊: [119.1, 36.62],
        重庆: [106.54, 29.59],
        台州: [121.420757, 28.656386],
        南京: [118.78, 32.04],
        滨州: [118.03, 37.36],
        贵阳: [106.71, 26.57],
        无锡: [120.29, 31.59],
        本溪: [123.73, 41.3],
        克拉玛依: [84.77, 45.59],
        渭南: [109.5, 34.52],
        马鞍山: [118.48, 31.56],
        宝鸡: [107.15, 34.38],
        焦作: [113.21, 35.24],
        句容: [119.16, 31.95],
        北京: [116.46, 39.92],
        徐州: [117.2, 34.26],
        衡水: [115.72, 37.72],
        包头: [110, 40.58],
        绵阳: [104.73, 31.48],
        乌鲁木齐: [87.68, 43.77],
        枣庄: [117.57, 34.86],
        杭州: [120.19, 30.26],
        淄博: [118.05, 36.78],
        鞍山: [122.85, 41.12],
        溧阳: [119.48, 31.43],
        库尔勒: [86.06, 41.68],
        安阳: [114.35, 36.1],
        开封: [114.35, 34.79],
        济南: [117, 36.65],
        德阳: [104.37, 31.13],
        温州: [120.65, 28.01],
        九江: [115.97, 29.71],
        邯郸: [114.47, 36.6],
        临安: [119.72, 30.23],
        兰州: [103.73, 36.03],
        沧州: [116.83, 38.33],
        临沂: [118.35, 35.05],
        南充: [106.110698, 30.837793],
        天津: [117.2, 39.13],
        富阳: [119.95, 30.07],
        泰安: [117.13, 36.18],
        诸暨: [120.23, 29.71],
        郑州: [113.65, 34.76],
        哈尔滨: [126.63, 45.75],
        聊城: [115.97, 36.45],
        芜湖: [118.38, 31.33],
        唐山: [118.02, 39.63],
        平顶山: [113.29, 33.75],
        邢台: [114.48, 37.05],
        德州: [116.29, 37.45],
        济宁: [116.59, 35.38],
        荆州: [112.239741, 30.335165],
        宜昌: [111.3, 30.7],
        义乌: [120.06, 29.32],
        丽水: [119.92, 28.45],
        洛阳: [112.44, 34.7],
        秦皇岛: [119.57, 39.95],
        株洲: [113.16, 27.83],
        石家庄: [114.48, 38.03],
        莱芜: [117.67, 36.19],
        常德: [111.69, 29.05],
        保定: [115.48, 38.85],
        湘潭: [112.91, 27.87],
        金华: [119.64, 29.12],
        岳阳: [113.09, 29.37],
        长沙: [113, 28.21],
        衢州: [118.88, 28.97],
        廊坊: [116.7, 39.53],
        菏泽: [115.480656, 35.23375],
        合肥: [117.27, 31.86],
        武汉: [114.31, 30.52],
        大庆: [125.03, 46.58],
      }
      let convertData = function(data) {
        let res = []
        for (let i = 0; i < data.length; i++) {
          let geoCoord = geoCoordMap[data[i].name]
          if (geoCoord) {
            res.push({
              name: data[i].name,
              value: geoCoord.concat(data[i].value),
            })
          }
        }
        return res
      }
      let convertMaxCount = function(maxCount) {
        if (maxCount % 5 != 0) {
          for (; ; maxCount++) {
            if (maxCount % 5 == 0) break
          }
        }
        return maxCount
      }
      let seriesdata = []
      for (let m = 0; m < mmdata.length; m++) {
        seriesdata[m] = {
          name: mmdata[m]['city_name'],
          mapType: 'china',
          type: 'scatter',
          symbolSize: function(val) {
            return val[2] / 20
          },
          coordinateSystem: 'geo',
          label: {
            normal: {
              color: '#fff',
              show: false,
            },
          },
          itemStyle: {
            normal: { label: { show: true } },
            emphasis: { label: { show: true } },
          },
          data: convertData([
            { name: mmdata[m]['city_name'], value: mmdata[m]['count'] },
          ]),
        }
      }
      let _this = this
      this.areaChart = _this.$echarts.init(document.getElementById('area_container'))
      this.areaChart.setOption({
        tooltip: {
          formatter: function(params) {
            return params.name + '(次数):' + params.value[2]
          },
          trigger: 'item',
        },
        legend: {
          left: 0,
          bottom: 20,
          top: 20,
          data: legenddata,
        },
        geo: [
          {
            show: true,
            map: 'china',
            roam: true,
          },
        ],
        visualMap: {
          inRange: {
            color: ['#d94e5d', '#eac736', '#50a3ba'],
            symbolSize: [5, 20],
          },
          min: 0,
          max: convertMaxCount(_this.maxCount),
          splitNumber: 5,
        },
        series: seriesdata,
      })
    },
    convertCallTime: function(row, column, cellValue) {
      return cellValue / 1000 + '秒'
    },
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    // 表格中选中项变化时执行的方法
    handleSelectionChange(val) {
      this.projects = val
    },
    renderCheckedRatio(ratio) {
      console.info('1111111111')
      console.info(ratio)
      if (ratio) {
        return Number(ratio * 100).toFixed(2)
      }
      return ratio
    },
    // 导出任务列表
    exportTaskResult() {
      let params = {}
      params.token = this.projectType == '1' ? this.projectId : this.taskId
      params.CASTGC = localStorage.getItem('tgt_id')
      let form = document.createElement('form')
      form.method = 'post'
      form.target = '_blank'
      for (let key in params) {
        let input = document.createElement('input')
        input.name = key
        input.value = params[key]
        form.appendChild(input)
      }
      form.action =
        currentBaseUrl +
        '/itFilter/exportTaskExecuteDetail.do?accessToken=' +
        params.CASTGC +
        '&token=' +
        params.token
      document.querySelector('body').appendChild(form)
      form.submit()
      document.querySelector('body').removeChild(form)
    },
    //   结果页的返回按钮
    turnToPrePage() {
      if (this.projectType == '2') {
        this.$router.push('/loopTask_result')
      } else {
        this.$router.push('/systemFilterIncoming')
      }
    },
    getTaskList() {
      let url = currentBaseUrl
      let params = {}
      let _this = this
      if (this.projectType == '1') {
        url += '/itFilter/queryImmediatelyTaskDetail.do'
        params.projectId = this.projectId
      } else if (this.projectType == '2') {
        url += '/itFilter/queryLoopTaskDetail.do'
        params.taskId = this.taskId
      }
      params.pageSize = this.pageSize
      params.pageNumber = this.currentPage
      params.sortType = this.sortType
      this.axios
        .post(url, Qs.stringify(params))
        .then(function(response) {
          _this.taskResultTableData = response.data.results
          _this.total = response.data.count || 0
          _this.sampleCount = response.data.other.sampleCount || 0
          _this.allSampleCount = response.data.other.allSampleCount || 0
          _this.checkedRatio = _this.renderCheckedRatio(
            response.data.other.checkedRatio || 0
          )
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取任务执行结果失败',
          })
        })
    },
    sortQuery() {
      if (this.sortType == 'desc') {
        this.sortType = 'asc'
      } else {
        this.sortType = 'desc'
      }
      this.currentPage = 1
      this.getTaskList()
    },
    // 录音播放页面 点击最小化触发
    toMinDialog: function(playInfo) {
      if (playInfo.isMaximization === false) {
        this.showVplayer = false
        let play = {}
        play.isMaximization = false
        play.exist = true
        this.$store.commit('setPlayerInfo', play)
      }
    },
    // 调到录音播放页
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'task_result'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      obj.projectId = this.projectId
      // 加入智能筛选的任务Id
      obj.taskId = this.taskId
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay', // 扩展样式
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
  },
  created() {
    this.recordPlayCloseHandler()
    if (!this.projectId || !this.projectType) {
      this.$router.push('/systemFilterIncoming')
    } else {
      this.getTaskList()
    }
  },
  computed: {
    projectId() {
      return this.$store.state.project.projectId
    },
    projectType() {
      return this.$store.state.project.projectType
    },
    taskId() {
      return this.$store.state.project.taskId
    },
  },
  watch: {
    currentPage() {
      this.getTaskList()
    },
    pageSize() {
      this.getTaskList()
    },
  },
}
</script>
<style lang="less">
.intelligent {
  .operation {
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
  .recordiplaywarp {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
}
</style>
<style scoped="scoped" lang="less">
@boder-color: #d1dbe5;
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
}

.innerrecordingwrap {
  width: 100%;
  height: 60px;
  position: absolute;
  bottom: 0;
  left: 0;
}

#innerdialog > div.el-dialog {
  top: 0;
}

.intelligent {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .operation {
    height: 55px;
    line-height: 55px;
    position: relative;
    border-bottom: 1px dashed @boder-color;
    padding-right: 10px;
    .el-form-item {
      margin-bottom: 0px;
      .el-form-item__content {
        line-height: 55px;
      }
    }
    & > div {
      display: inline-block;
      text-align: right;
      button {
        width: 90px;
      }
      &.searchForm {
        position: absolute;
        right: -10px;
        div.el-form-item__content {
          vertical-align: middle !important;
          border: 1px solid red;
        }
      }
    }
  }
  .taskResult {
    .operation {
      .tips {
        & > label {
          color: #9dadc2;
          font-size: 14px;
        }
        & > span {
          margin: 0px 10px 0px 5px;
        }
      }
      .btns {
        float: right;
        margin-right: -10px;
      }
    }
  }
  .intelligent-content {
    box-sizing: border-box;
    position: absolute;
    top: 65px;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 0px 10px;
    padding-bottom: 40px;
    overflow: hidden;
  }
  .intelligent-content .intelligent-content-pos {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .intelligent-content .intelligent-page {
    width: 100%;
    height: 35px;
    position: absolute;
    left: 0;
    right: 0px;
    bottom: 0;
    text-align: right;
  }
  .intelligent-page .el-pagination {
    display: inline-block;
    height: 28px;
    line-height: 28px;
    padding: 0px 10px;
  }
  #newTaskdialog .el-dialog__body {
  }
  #intelligent .intelligent-content-pos .el-table__body-wrapper {
    overflow-x: hidden;
  }
  .btns {
    text-align: right;
  }
  table .cell > i {
    width: 35px;
    & > i {
      font-family: '微软雅黑';
      margin-left: 4px;
      font-size: 14px;
    }
  }
}
</style>
