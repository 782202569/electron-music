<template>
  <div class="intelligent" id="intelligent">
    <div class="loopTaskResult">
      <div class="intelligent-header">
        <div class="operation">
          <div class="searchForm">
            <el-form :inline="true">
              <el-form-item label="任务时间">
                <el-date-picker
                  class="fr"
                  v-model="searchTime"
                  type="datetimerange"
                  placeholder="选择时间范围"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="queryLoopTask">查询</el-button>
              </el-form-item>
              <el-form-item>
                <el-button @click="showChartDialog">查看图表</el-button>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="exportData">导出</el-button>
              </el-form-item>
              <el-form-item>
                <el-button @click="turnToPrePage">返回</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <div class="intelligent-content">
        <div class="intelligent-content-pos" style="overflow-y:auto;">
          <div style="width:100%;height:100%;">
            <el-table
              ref="loopTaskTable"
              :data="loopTaskTableData"
              border
              tooltip-effect="dark"
            >
              <el-table-column label="序号" width="80" type="index"></el-table-column>
              <el-table-column prop="taskFinishTime" label="完成时间"></el-table-column>
              <el-table-column prop="sampleCount" label="样本数"></el-table-column>
              <el-table-column
                prop="allSampleCount"
                label="周期录音数"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="sampleTrendStr"
                label="样本趋势"
                show-overflow-tooltip
              >
                <template scope="scope">
                  <span
                    v-if="scope.row.sampleTrend != null"
                    style="display: inline-block"
                    >{{ scope.row.sampleTrendStr }}</span
                  >
                  <span
                    v-if="scope.row.sampleTrend == null"
                    style="display: inline-block"
                  >
                    -
                  </span>
                  <span v-if="scope.row.sampleTrend > 0" style="display: inline-block">
                    <img src="./ic_up.png" style="height: auto;width: auto" />
                  </span>
                  <span v-if="scope.row.sampleTrend < 0" style="display: inline-block">
                    <img src="./ic_down.png" style="height: auto;width: auto" />
                  </span>
                  <span v-if="scope.row.sampleTrend == 0" style="display: inline-block">
                    <img src="./ic_avg.png" style="height: auto;width: auto" />
                  </span>
                </template>
              </el-table-column>
              <el-table-column
                prop="checkedRatio"
                :formatter="toFixed"
                label="抽出率"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column prop="operate" label="操作" show-overflow-tooltip>
                <template scope="scope">
                  <i
                    class="iconfont icon-chakan"
                    style="cursor:pointer;margin-right:20px;"
                    @click="showDetail(scope.row.taskId)"
                  >
                    <i style="font-family: '微软雅黑';margin-left:4px;">查看</i>
                  </i>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="intelligent-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          ></el-pagination>
        </div>
      </div>
    </div>
    <!--查看图表弹出框-->
    <el-dialog
      id="lookChartDialog"
      :title="areaMap"
      :close-on-click-modal="false"
      :visible.sync="lookChartDialogVisible"
      @open="createChart"
    >
      <div class="chartCondition">
        <el-form :inline="true">
          <el-form-item>
            <el-col :span="5" style="margin-right: 10px">
              <el-select
                v-model="chartType"
                placeholder="图表类型"
                @change="handleChangeChartType"
              >
                <el-option
                  v-for="item in chartTypeData"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="7">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                v-model="startTime"
                style="width: 100%;"
              ></el-date-picker>
            </el-col>
            <el-col class="line" :span="1">-</el-col>
            <el-col :span="7" style="margin-right: 10px">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                v-model="endTime"
                style="width: 100%;"
              ></el-date-picker>
            </el-col>
            <el-col :span="3">
              <el-button type="primary" @click="createChart">查询</el-button>
            </el-col>
          </el-form-item>
        </el-form>
      </div>
      <div id="chart_container" style="width: 100%; height: 600px;">
        <p>
          暂无数据
        </p>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Qs from 'qs'
import moment from 'moment'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
export default {
  data() {
    return {
      maxCount: 0,
      projectName: '', // 任务名称
      currentProjectType: '1', // 当前页面中的数据所属的任务类型
      taskTypes: [],
      tableData: [],
      pickerOptions0: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7
        },
      },
      currentPage: 1,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      intelligentTotal: 0, // 任务获取的总条数
      taskStartTime: '', // 任务开始时间
      projectOperate: '', // 当前操作的任务id
      projects: [], // table中选中的任务,
      activePage: 'taskSetting', // 查询页'taskSetting',循环任务结果页'loopTaskResult',普通结果页'taskResult'
      loopTaskTableData: [], // 循环任务查询结果
      searchTime: [],
      lookChartDialogVisible: false, // 循环任务图表
      lookAreaDialogVisible: false,
      startTime: '',
      endTime: '',
      chartTypeData: [
        { label: '折线图', value: '1' },
        { label: '区域热力图', value: '2' },
      ],
      chartType: '1',
      areaData: [],
      taskStatsData: [],
      chart: null,
      areaMap: '',
    }
  },
  methods: {
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    // 表格中选中项变化时执行的方法
    handleSelectionChange(val) {
      this.projects = val
    },
    handleChangeChartType() {
      this.createChart()
    },
    // 查询循环任务
    queryLoopTask() {
      let taskBeginTime, updateDate
      if (!this.searchTime || this.searchTime[0] == null) {
        taskBeginTime = ''
        updateDate = ''
      } else {
        taskBeginTime = this.gettimeform(this.searchTime[0])
        updateDate = this.gettimeform(this.searchTime[1])
      }
      let params = {
        lastTaskExecuteTimeMin: taskBeginTime,
        lastTaskExecuteTimeMax: updateDate,
        projectId: this.projectId,
        pageNumber: this.currentPage,
        pageSize: this.pageSize,
      }
      let self = this
      this.axios
        .post(currentBaseUrl + '/itFilter/queryLoopTask.do', Qs.stringify(params))
        .then(function(response) {
          self.total = response.data.count
          self.loopTaskTableData = response.data.results
        })
        .catch(function(error) {
          console.log(error)
          self.$message.error('查询循环任务执行信息出错!')
        })
    },
    createChart() {
      if (this.chart) {
        this.chart.dispose()
      }
      if (this.chartType == '1') {
        this.getTaskStats()
      } else {
        this.getAreaStats()
      }
    },
    showChartDialog() {
      if (this.projectType == '1') {
        this.areaMap = '即时任务走势图'
      } else if (this.projectType == '2') {
        this.areaMap = '循环任务走势图'
      }
      this.lookChartDialogVisible = true
    },
    showAreaChartDialog() {
      this.lookAreaDialogVisible = true
    },
    // 查看图表
    lookChart(chartObj) {
      let _this = this
      let option = {
        tooltip: {
          trigger: 'axis',
        },
        grid: {
          top: '3%',
          left: '3%',
          right: '50',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: [],
          splitLine: {
            show: true,
          },
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
          },
        },
        series: [
          {
            name: '样本数量',
            type: 'line',
            stack: '总量',
            data: [],
            itemStyle: {
              normal: {
                color: '#50b4ff',
              },
            },
          },
        ],
      }
      let xAxis = []
      let yAxis = []
      if (chartObj && chartObj.length > 0) {
        chartObj.forEach(function(item) {
          xAxis.push(item.TIME)
          yAxis.push(item.COUNT)
        })
      }
      option.xAxis.data = xAxis
      option.series[0].data = yAxis
      this.$nextTick(function() {
        this.chart = _this.$echarts.init(document.querySelector('#chart_container'))
        this.chart.setOption(option)
      })
    },
    // 获取图标数据
    getTaskStats() {
      let startTime = this.gettimeform(this.startTime, 'todata')
      let endTime = this.gettimeform(this.endTime, 'todata')
      let params = {
        startTime: startTime,
        endTime: endTime,
        projectId: this.projectId,
      }
      let self = this
      this.axios
        .post(currentBaseUrl + '/itFilter/getTaskStats.do', Qs.stringify(params))
        .then(function(response) {
          if (response.data && response.data.length > 0) {
            self.lookChart(response.data)
          }
        })
        .catch(function(error) {
          console.log(error)
          self.$message.error('图标数据获取失败!')
        })
    },
    createAreaStatsChart(mmdata) {
      // 区域图最大值获取
      let countArr = []
      for (let a = 0; a < mmdata.length; a++) {
        countArr.push(mmdata[a]['count'])
      }
      this.maxCount = Math.max.apply(null, countArr)
      let legenddata = []
      for (let j = 0; j < mmdata.length; j++) {
        legenddata[j] = mmdata[j]['city_name']
      }
      let geoCoordMap = {
        海门: [121.15, 31.89],
        鄂尔多斯: [109.781327, 39.608266],
        招远: [120.38, 37.35],
        舟山: [122.207216, 29.985295],
        齐齐哈尔: [123.97, 47.33],
        盐城: [120.13, 33.38],
        赤峰: [118.87, 42.28],
        青岛: [120.33, 36.07],
        乳山: [121.52, 36.89],
        金昌: [102.188043, 38.520089],
        泉州: [118.58, 24.93],
        莱西: [120.53, 36.86],
        日照: [119.46, 35.42],
        胶南: [119.97, 35.88],
        南通: [121.05, 32.08],
        拉萨: [91.11, 29.97],
        云浮: [112.02, 22.93],
        梅州: [116.1, 24.55],
        文登: [122.05, 37.2],
        上海: [121.48, 31.22],
        攀枝花: [101.718637, 26.582347],
        威海: [122.1, 37.5],
        承德: [117.93, 40.97],
        厦门: [118.1, 24.46],
        汕尾: [115.375279, 22.786211],
        潮州: [116.63, 23.68],
        丹东: [124.37, 40.13],
        太仓: [121.1, 31.45],
        曲靖: [103.79, 25.51],
        烟台: [121.39, 37.52],
        福州: [119.3, 26.08],
        瓦房店: [121.979603, 39.627114],
        即墨: [120.45, 36.38],
        抚顺: [123.97, 41.97],
        玉溪: [102.52, 24.35],
        张家口: [114.87, 40.82],
        阳泉: [113.57, 37.85],
        莱州: [119.942327, 37.177017],
        湖州: [120.1, 30.86],
        汕头: [116.69, 23.39],
        昆山: [120.95, 31.39],
        宁波: [121.56, 29.86],
        湛江: [110.359377, 21.270708],
        揭阳: [116.35, 23.55],
        荣成: [122.41, 37.16],
        连云港: [119.16, 34.59],
        葫芦岛: [120.836932, 40.711052],
        常熟: [120.74, 31.64],
        东莞: [113.75, 23.04],
        河源: [114.68, 23.73],
        淮安: [119.15, 33.5],
        泰州: [119.9, 32.49],
        南宁: [108.33, 22.84],
        营口: [122.18, 40.65],
        惠州: [114.4, 23.09],
        江阴: [120.26, 31.91],
        蓬莱: [120.75, 37.8],
        韶关: [113.62, 24.84],
        嘉峪关: [98.289152, 39.77313],
        广州: [113.23, 23.16],
        延安: [109.47, 36.6],
        太原: [112.53, 37.87],
        清远: [113.01, 23.7],
        中山: [113.38, 22.52],
        昆明: [102.73, 25.04],
        寿光: [118.73, 36.86],
        盘锦: [122.070714, 41.119997],
        长治: [113.08, 36.18],
        深圳: [114.07, 22.62],
        珠海: [113.52, 22.3],
        宿迁: [118.3, 33.96],
        咸阳: [108.72, 34.36],
        铜川: [109.11, 35.09],
        平度: [119.97, 36.77],
        佛山: [113.11, 23.05],
        海口: [110.35, 20.02],
        江门: [113.06, 22.61],
        章丘: [117.53, 36.72],
        肇庆: [112.44, 23.05],
        大连: [121.62, 38.92],
        临汾: [111.5, 36.08],
        吴江: [120.63, 31.16],
        石嘴山: [106.39, 39.04],
        沈阳: [123.38, 41.8],
        苏州: [120.62, 31.32],
        茂名: [110.88, 21.68],
        嘉兴: [120.76, 30.77],
        长春: [125.35, 43.88],
        胶州: [120.03336, 36.264622],
        银川: [106.27, 38.47],
        张家港: [120.555821, 31.875428],
        三门峡: [111.19, 34.76],
        锦州: [121.15, 41.13],
        南昌: [115.89, 28.68],
        柳州: [109.4, 24.33],
        三亚: [109.511909, 18.252847],
        自贡: [104.778442, 29.33903],
        吉林: [126.57, 43.87],
        阳江: [111.95, 21.85],
        泸州: [105.39, 28.91],
        西宁: [101.74, 36.56],
        宜宾: [104.56, 29.77],
        呼和浩特: [111.65, 40.82],
        成都: [104.06, 30.67],
        大同: [113.3, 40.12],
        镇江: [119.44, 32.2],
        桂林: [110.28, 25.29],
        张家界: [110.479191, 29.117096],
        宜兴: [119.82, 31.36],
        北海: [109.12, 21.49],
        西安: [108.95, 34.27],
        金坛: [119.56, 31.74],
        东营: [118.49, 37.46],
        牡丹江: [129.58, 44.6],
        遵义: [106.9, 27.7],
        绍兴: [120.58, 30.01],
        扬州: [119.42, 32.39],
        常州: [119.95, 31.79],
        潍坊: [119.1, 36.62],
        重庆: [106.54, 29.59],
        台州: [121.420757, 28.656386],
        南京: [118.78, 32.04],
        滨州: [118.03, 37.36],
        贵阳: [106.71, 26.57],
        无锡: [120.29, 31.59],
        本溪: [123.73, 41.3],
        克拉玛依: [84.77, 45.59],
        渭南: [109.5, 34.52],
        马鞍山: [118.48, 31.56],
        宝鸡: [107.15, 34.38],
        焦作: [113.21, 35.24],
        句容: [119.16, 31.95],
        北京: [116.46, 39.92],
        徐州: [117.2, 34.26],
        衡水: [115.72, 37.72],
        包头: [110, 40.58],
        绵阳: [104.73, 31.48],
        乌鲁木齐: [87.68, 43.77],
        枣庄: [117.57, 34.86],
        杭州: [120.19, 30.26],
        淄博: [118.05, 36.78],
        鞍山: [122.85, 41.12],
        溧阳: [119.48, 31.43],
        库尔勒: [86.06, 41.68],
        安阳: [114.35, 36.1],
        开封: [114.35, 34.79],
        济南: [117, 36.65],
        德阳: [104.37, 31.13],
        温州: [120.65, 28.01],
        九江: [115.97, 29.71],
        邯郸: [114.47, 36.6],
        临安: [119.72, 30.23],
        兰州: [103.73, 36.03],
        沧州: [116.83, 38.33],
        临沂: [118.35, 35.05],
        南充: [106.110698, 30.837793],
        天津: [117.2, 39.13],
        富阳: [119.95, 30.07],
        泰安: [117.13, 36.18],
        诸暨: [120.23, 29.71],
        郑州: [113.65, 34.76],
        哈尔滨: [126.63, 45.75],
        聊城: [115.97, 36.45],
        芜湖: [118.38, 31.33],
        唐山: [118.02, 39.63],
        平顶山: [113.29, 33.75],
        邢台: [114.48, 37.05],
        德州: [116.29, 37.45],
        济宁: [116.59, 35.38],
        荆州: [112.239741, 30.335165],
        宜昌: [111.3, 30.7],
        义乌: [120.06, 29.32],
        丽水: [119.92, 28.45],
        洛阳: [112.44, 34.7],
        秦皇岛: [119.57, 39.95],
        株洲: [113.16, 27.83],
        石家庄: [114.48, 38.03],
        莱芜: [117.67, 36.19],
        常德: [111.69, 29.05],
        保定: [115.48, 38.85],
        湘潭: [112.91, 27.87],
        金华: [119.64, 29.12],
        岳阳: [113.09, 29.37],
        长沙: [113, 28.21],
        衢州: [118.88, 28.97],
        廊坊: [116.7, 39.53],
        菏泽: [115.480656, 35.23375],
        合肥: [117.27, 31.86],
        武汉: [114.31, 30.52],
        大庆: [125.03, 46.58],
      }
      let convertData = function(data) {
        let res = []
        for (let i = 0; i < data.length; i++) {
          let geoCoord = geoCoordMap[data[i].name]
          if (geoCoord) {
            res.push({
              name: data[i].name,
              value: geoCoord.concat(data[i].value),
            })
          }
        }
        return res
      }
      let convertMaxCount = function(maxCount) {
        if (maxCount % 5 != 0) {
          for (; ; maxCount++) {
            if (maxCount % 5 == 0) break
          }
        }
        return maxCount
      }
      let seriesdata = []
      for (let m = 0; m < mmdata.length; m++) {
        seriesdata[m] = {
          name: mmdata[m]['city_name'],
          mapType: 'china',
          type: 'scatter',
          symbolSize: function(val) {
            return val[2] / 20
          },
          coordinateSystem: 'geo',
          label: {
            normal: {
              color: '#fff',
              show: false,
            },
          },
          itemStyle: {
            normal: { label: { show: true } },
            emphasis: { label: { show: true } },
          },
          data: convertData([
            { name: mmdata[m]['city_name'], value: mmdata[m]['count'] },
          ]),
        }
      }
      let _this = this
      this.chart = _this.$echarts.init(document.getElementById('chart_container'))
      this.chart.setOption({
        tooltip: {
          formatter: function(params) {
            return params.name + '(次数):' + params.value[2]
          },
          trigger: 'item',
        },
        legend: {
          left: 0,
          bottom: 20,
          top: 20,
          data: legenddata,
        },
        geo: [
          {
            show: true,
            map: 'china',
            roam: true,
          },
        ],
        visualMap: {
          inRange: {
            color: ['#d94e5d', '#eac736', '#50a3ba'],
            symbolSize: [5, 20],
          },
          min: 0,
          max: convertMaxCount(_this.maxCount),
          splitNumber: 5,
        },
        series: seriesdata,
      })
    },
    getAreaStats() {
      let params = {
        startTime: this.gettimeform(this.startTime, false),
        endTime: this.gettimeform(this.endTime, false),
        otherKey: this.projectId,
      }
      let self = this
      this.axios
        .post(
          currentBaseUrl + '/itFilter/getLoopProjectAreaStats.do',
          Qs.stringify(params)
        )
        .then(function(response) {
          self.createAreaStatsChart(response.data)
        })
    },
    gettimeform(val, toDate) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let hours = date.getHours()
      if (hours < 10) {
        hours = '0' + hours
      }
      let minute = date.getMinutes()
      if (minute < 10) {
        minute = '0' + minute
      }
      let second = date.getSeconds()
      if (second < 10) {
        second = '0' + second
      }
      let str = year + '-' + month + '-' + day + ' ' + hours + ':' + minute + ':' + second
      if (toDate) {
        str = year + '-' + month + '-' + day
      }
      return str
    },
    // 导出
    exportData() {
      let params = {}
      params.projectId = this.projectId
      params.CASTGC = localStorage.getItem('tgt_id')
      let form = document.createElement('form')
      form.method = 'post'
      form.target = '_blank'
      for (let key in params) {
        let input = document.createElement('input')
        input.name = key
        input.value = params[key]
        form.appendChild(input)
      }
      form.action =
        currentBaseUrl + '/itFilter/exportTaskExecuteData.do?accessToken=' + params.CASTGC
      document.querySelector('body').appendChild(form)
      form.submit()
      document.querySelector('body').removeChild(form)
    },
    toFixed(x, y, ratio) {
      let _ratio = Number(ratio * 100).toFixed(2)
      return _ratio + '%'
    },
    //  结果页的返回按钮
    turnToPrePage() {
      this.$router.push('/systemFilterIncoming')
    },
    showDetail(taskId) {
      let project = {}
      project.projectType = '2'
      project.projectId = this.projectId
      project.taskId = taskId
      this.$store.commit('setProject', project)
      this.$router.push('/task_result')
    },
    createTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
      return ''
    },
  },
  mounted() {
    if (!this.projectId || !this.projectType) {
      this.$router.push('/systemFilterIncoming')
    } else {
      this.queryLoopTask()
    }
  },
  computed: {
    projectId() {
      return this.$store.state.project.projectId
    },
    projectType() {
      return this.$store.state.project.projectType
    },
  },
  watch: {
    currentPage() {
      this.queryLoopTask()
    },
    pageSize() {
      this.queryLoopTask()
    },
  },
}
</script>
<style lang="less">
.intelligent {
  .operation {
    .el-date-editor.fr.el-input.el-date-editor--datetimerange {
      width: 175px;
    }
  }
}
</style>
<style scoped="scoped" lang="less">
@boder-color: #d1dbe5;
.intelligent {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;

  .operation {
    height: 55px;
    line-height: 55px;
    position: relative;
    border-bottom: 1px dashed @boder-color;
    text-align: right;
    margin-right: -10px;

    .el-form-item {
      margin-bottom: 0px;

      .el-form-item__content {
        line-height: 55px;
      }
    }
    & > div {
      display: inline-block;
      text-align: right;

      button {
        width: 90px;
      }

      & .searchForm {
        position: absolute;
        right: -10px;

        div.el-form-item__content {
          vertical-align: middle !important;
          border: 1px solid red;
        }
      }
    }
  }
  .taskResult {
    .operation {
      .tips {
        & > label {
          color: #9dadc2;
          font-size: 14px;
        }

        & > span {
          margin: 0px 10px 0px 5px;
        }
      }
      .btns {
        float: right;
        margin-right: -10px;
      }
    }
  }
  .intelligent-content {
    box-sizing: border-box;
    position: absolute;
    top: 65px;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 0px 10px;
    padding-bottom: 40px;
    overflow: hidden;
  }

  .intelligent-content .intelligent-content-pos {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }

  .intelligent-content .intelligent-page {
    width: 100%;
    height: 35px;
    position: absolute;
    left: 0;
    right: 0px;
    bottom: 0;
    text-align: right;
  }

  .intelligent-page .el-pagination {
    display: inline-block;
    height: 28px;
    line-height: 28px;
    padding: 0px 10px;
  }

  #newTaskdialog .el-dialog__body {
  }

  #intelligent .intelligent-content-pos .el-table__body-wrapper {
    overflow-x: hidden;
  }

  .btns {
    text-align: right;
  }

  table .cell > i {
    width: 35px;

    & > i {
      font-family: '微软雅黑';
      margin-left: 4px;
      font-size: 14px;
    }
  }
}

.chartCondition {
  text-align: center;
}

#chart_container {
  width: 600px;
  height: 400px;
  margin: 0 auto;
}
</style>
