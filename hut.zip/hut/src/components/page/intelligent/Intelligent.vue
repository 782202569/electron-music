<template>
  <div class="intelligent" id="intelligent">
    <div class="taskSetting">
      <div class="intelligent-header">
        <div class="operation">
          <div class="searchForm">
            <el-form :inline="true">
              <el-form-item>
                <el-input v-model="projectName" placeholder="请输入配置名称"></el-input>
              </el-form-item>
              <el-form-item>
                <el-select
                  v-model="projectType"
                  clearable
                  placeholder="请选择任务类型"
                  class="fr"
                >
                  <el-option
                    v-for="item in taskTypes"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  ></el-option>
                </el-select>
              </el-form-item>
              <el-form-item class="time">
                <el-date-picker
                  class="fr"
                  v-model="searchTime"
                  type="datetimerange"
                  placeholder="选择时间范围"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="taskInquiry">查询</el-button>
              </el-form-item>
              <el-form-item>
                <el-button funcId="000355" @click="newTask">新建</el-button>
              </el-form-item>
              <el-form-item>
                <el-button funcId="000354" @click="batchDeleteConfirm"
                  >批量删除</el-button
                >
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <div class="intelligent-content">
        <div class="intelligent-content-pos" style="overflow-y:auto;">
          <div style="width:100%;height:100%;">
            <el-table
              ref="multipleTable"
              :data="tableData"
              border
              tooltip-effect="dark"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection"></el-table-column>
              <el-table-column prop="projectName" label="配置名称"></el-table-column>
              <el-table-column prop="createUser" label="创建人"></el-table-column>
              <el-table-column
                prop="lastTaskExecuteTime"
                :formatter="createTimeFilter"
                label="执行时间"
              ></el-table-column>
              <el-table-column
                prop="projectType"
                :formatter="projectTypeFilter"
                label="任务类型"
              ></el-table-column>
              <el-table-column
                prop="taskExecuteState"
                label="任务状态"
                show-overflow-tooltip
              >
                <template scope="scope">
                  <el-tag
                    close-transition
                    type="gray"
                    v-if="scope.row.taskExecuteState == 1"
                    >未开始</el-tag
                  >
                  <el-tag
                    close-transition
                    type="primary"
                    v-if="scope.row.taskExecuteState == 2"
                    >运行中</el-tag
                  >
                  <el-tag
                    close-transition
                    type="success"
                    v-if="scope.row.taskExecuteState == 3"
                    >已完成</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column
                prop="operate"
                label="操作"
                width="380"
                show-overflow-tooltip
              >
                <template scope="scope">
                  <i
                    funcId="000357"
                    class="iconfont icon-222"
                    style="cursor:pointer;margin-right:8px;"
                    @click="diableLoopTask(scope.row.projectId)"
                    v-if="
                      scope.row.taskExecuteState === '2' && scope.row.projectType == 2
                    "
                  >
                    <i style="font-family:'微软雅黑';margin-left:4px;">暂停</i>
                  </i>
                  <i
                    funcId="000358"
                    class="el-icon-caret-right"
                    style="cursor:pointer;margin-right:20px;"
                    @click="tapeStart(scope.row.projectType, scope.row.projectId)"
                    v-if="
                      scope.row.projectType == 2 &&
                        (scope.row.taskExecuteState === '1' ||
                          scope.row.taskExecuteState === '3')
                    "
                  >
                    <i style="font-family:'微软雅黑';margin-left:4px;">开始</i>
                  </i>
                  <i
                    funcId="000358"
                    class="el-icon-caret-right"
                    style="cursor:pointer;margin-right:20px;"
                    v-if="scope.row.projectType == 1 && scope.row.taskExecuteState != 2"
                    @click="tapeStart(scope.row.projectType, scope.row.projectId)"
                  >
                    <i style="font-family:'微软雅黑';margin-left:4px;">开始</i>
                  </i>
                  <i
                    funcId="000361"
                    class="el-icon-edit"
                    style="cursor:pointer;margin-right:20px;"
                    @click="editProject(scope.row, 'edit')"
                    v-if="scope.row.projectType == 1"
                  >
                    <i style="font-family: '微软雅黑';margin-left:4px;">编辑</i>
                  </i>
                  <i
                    funcId="000360"
                    class="el-icon-document"
                    style="cursor:pointer;margin-right:20px;"
                    @click="editProject(scope.row, 'copy')"
                    v-if="scope.row.projectType == 2"
                  >
                    <i style="font-family: '微软雅黑';margin-left:4px;">复制</i>
                  </i>
                  <i
                    funcId="000356"
                    class="el-icon-close"
                    style="cursor:pointer;margin-right:20px;font-size:12px;"
                    @click="
                      deleteProjectConfirm(scope.row.projectName, scope.row.projectId)
                    "
                  >
                    <i style="font-family: '微软雅黑';margin-left:5px;font-size:14px;"
                      >删除</i
                    >
                  </i>
                  <i
                    funcId="000359"
                    class="iconfont icon-chakan"
                    style="cursor:pointer;margin-right:20px;"
                    @click="showDetail(scope.row.projectType, scope.row.projectId)"
                  >
                    <i style="font-family: '微软雅黑';margin-left:4px;">查看</i>
                  </i>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="intelligent-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          ></el-pagination>
        </div>
      </div>
    </div>
    <el-dialog
      id="newTaskdialog"
      :width="'1150px'"
      title="新建任务"
      :close-on-click-modal="false"
      :visible.sync="dialogVisible"
    >
      <vTask v-on:send="closenewTask" v-if="dialogVisible"></vTask>
    </el-dialog>
    <el-dialog
      id="newTaskStarttime"
      title="开始任务"
      :close-on-click-modal="false"
      :visible.sync="dialogVisible1"
    >
      <el-form ref="saveStrategyModel" label-width="100px" label-position="top">
        <el-form-item label="请设置任务执行时间" prop="strategyName">
          <el-date-picker
            v-model="taskStartTime"
            type="datetime"
            placeholder="选择日期时间"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item>
          <div class="btns">
            <el-button type="primary" @click="sureTaskStarttime">确定</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog
      id="editTaskdialog"
      :width="'1150px'"
      class="dialog-box"
      :title="modalName"
      :visible.sync="editeDialogVisible"
      :close-on-click-modal="false"
    >
      <vTask
        v-on:send="closeEditTask"
        v-if="editeDialogVisible"
        :projectModel="projectModel"
      ></vTask>
    </el-dialog>
  </div>
</template>
<script>
import vTask from '../intelligent/Newtask.vue'
import Qs from 'qs'
import moment from 'moment'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
export default {
  components: {
    vTask,
  },
  data() {
    return {
      searchTime: '', // 选择的时间范围
      options: '',
      projectName: '', // 任务名称
      projectType: '', // 查询框的任务类型
      currentProjectType: '1', // 当前页面中的数据所属的任务类型
      taskTypes: [],
      tableData: [],
      pickerOptions0: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7
        },
      },
      currentPage: 1,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      dialogVisible: false,
      dialogVisible1: false, // 任务执行时间的弹出框
      intelligentTotal: 0, // 任务获取的总条数
      taskStartTime: '', // 任务开始时间
      projectOperate: '', // 当前操作的任务id
      projects: [], // table中选中的任务,
      modalName: '编辑任务', // 弹出框标题
      editeDialogVisible: false, // 编辑任务
      projectModel: {}, // 编辑任务时传入的任务数据对象
    }
  },
  methods: {
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    // 表格中选中项变化时执行的方法
    handleSelectionChange(val) {
      this.projects = val
    },
    // 启动一个定时任务
    tapeStart(type, id) {
      if (type == '2') {
        this.dialogVisible1 = true
        this.projectOperate = id
      } else if (type == '1') {
        let _this = this
        this.axios
          .post(currentBaseUrl + '/itFilter/startImmediatelyTask.do?projectId=' + id)
          .then(function(response) {
            if (response.data['state'] === '1') {
              _this.$message.success('任务已经启动!')
              _this.taskInquiry()
            } else {
              _this.$message.error(response['data']['message'])
              Promise.reject(response)
            }
          })
          .catch(function(error) {
            console.log(error)
            _this.$message.error('任务启动失败!')
          })
      }
    },
    // 暂停一个任务
    diableLoopTask(id) {
      let _this = this
      let params = {}
      params.projectId = id
      this.axios
        .post(currentBaseUrl + '/itFilter/diableLoopTask.do', Qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message.success('定时任务已暂停!')
            _this.taskInquiry()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message.error('暂停定时任务出现问题!')
        })
    },
    sureTaskStarttime() {
      // 点击填写任务执行时间的确定按钮
      let _this = this
      let params = {}
      params.projectId = this['projectOperate']
      let url = currentBaseUrl + '/itFilter/enableLoopTask.do'
      params.taskStartTime = this.gettimeform(this.taskStartTime)
      this.axios
        .post(url, Qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message.success('任务启动成功!')
            _this.dialogVisible1 = false
            _this.taskInquiry()
          } else {
            return Promise.reject(response)
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message.error('任务启动失败!')
        })
    },
    // 删除一个智能项目
    deleteProject(id) {
      let _this = this
      let params = {}
      params.projectId = id
      this.axios
        .post(currentBaseUrl + '/itFilter/remove.do', Qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message.success('任务删除成功!')
            _this.taskInquiry()
          } else {
            _this.$message.error('任务删除失败!')
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message.error('任务删除失败')
        })
    },
    deleteProjectConfirm(name, id) {
      let _this = this
      _this
        .$confirm('确定要任务[' + name + ']?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
        .then(function() {
          _this.deleteProject(id)
        })
        .catch(function() {
          _this.$message.info('已取消删除')
        })
    },
    batchDeleteConfirm() {
      let _this = this
      if (_this.projects.length < 1) {
        _this.$message.warning('请选择要删除的任务')
        return false
      }
      let names = []
      let ids = []
      _this.projects.forEach(function(item) {
        names.push(item.projectName)
        ids.push(item.projectId)
      })
      let msg = ''
      if (names.length <= 3) {
        msg = names.join(',')
      } else {
        msg = names.slice(0, 3).join(',') + '等' + names.length + '个项目'
      }
      _this
        .$confirm('确定要删除[' + msg + ']?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
        .then(function() {
          _this.batchDelete(ids.join(','))
        })
        .catch(function() {
          _this.$message.info('已取消删除')
        })
    },
    // 批量删除智能项目
    batchDelete(ids) {
      let _this = this
      let params = {}
      params.projectIdStr = ids
      this.axios
        .post(currentBaseUrl + '/itFilter/batchRemove.do', Qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message.success('任务删除成功')
            _this.taskInquiry()
          } else {
            return Promise.reject(response)
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message.error('任务删除失败')
        })
    },
    //   编辑或复制一个任务
    editProject(row, type) {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/itFilter/getProjectInfo.do',
          Qs.stringify({
            projectId: row.projectId,
          })
        )
        .then(function(response) {
          _this.projectModel = response.data
          _this.editeDialogVisible = true
          _this.projectModel.type = type
          if (type == 'edit') {
            _this.modalName = '编辑任务'
          } else if (type == 'copy') {
            _this.modalName = '复制任务'
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message.error('获取任务详情失败')
        })
    },
    // input=>是否关闭弹窗（true or false，flag=> 有任务执行时是否成功('success' or 'failed')
    closeEditTask(input, flag) {
      // 关闭新建任务的弹窗
      this.editeDialogVisible = input
      if (flag === 'success') {
        this.taskInquiry()
      }
    },
    showDetail(projectType, projectId) {
      let project = {}
      project.projectType = projectType
      project.projectId = projectId
      project.taskId = ''
      this.$store.commit('setProject', project)
      if (projectType == '1') {
        this.$router.push('/task_result')
      } else if (projectType == '2') {
        this.$router.push('/loopTask_result')
      }
    },
    newTask() {
      // 新建任务
      this.dialogVisible = true
      this.projectModel = null
    },
    // 查询智能筛选项目
    taskInquiry() {
      let taskBeginTime, updateDate
      if (!this.searchTime || this.searchTime[0] == null) {
        taskBeginTime = ''
        updateDate = ''
      } else {
        taskBeginTime = this.gettimeform(this.searchTime[0])
        updateDate = this.gettimeform(this.searchTime[1])
      }
      let params = {
        lastTaskExecuteTimeMin: taskBeginTime,
        lastTaskExecuteTimeMax: updateDate,
        pageNumber: this.currentPage,
        pageSize: this.pageSize,
        projectName: this.projectName,
        projectType: this.projectType,
      }
      let self = this
      this.axios
        .post(currentBaseUrl + '/itFilter/queryProject.do', Qs.stringify(params))
        .then(function(response) {
          self.total = response.data.count
          self.tableData = response.data.results
        })
        .catch(function(error) {
          console.log(error)
          self.$message.error('项目获取失败!')
        })
    },
    // 获取任务类型
    getTaskType() {
      let _this = this
      this.axios
        .post(currentBaseUrl + '/pageConstant/getValue.do?keys=ipType')
        .then(function(response) {
          _this.taskTypes = response['data']['ipType']
        })
        .catch(function(error) {
          console.log(error)
          _this.$message.error('获取任务类型失败!')
        })
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let hours = date.getHours()
      if (hours < 10) {
        hours = '0' + hours
      }
      let minute = date.getMinutes()
      if (minute < 10) {
        minute = '0' + minute
      }
      let second = date.getSeconds()
      if (second < 10) {
        second = '0' + second
      }
      let str = year + '-' + month + '-' + day + ' ' + hours + ':' + minute + ':' + second
      return str
    },
    // input=>是否关闭弹窗（true or false，flag=> 有任务执行时是否成功('success' or 'failed')
    closenewTask(input, flag) {
      // 关闭新建任务的弹窗
      this.dialogVisible = input
      if (flag === 'success') {
        this.taskInquiry()
      }
    },
    //   结果页的返回按钮
    turnToPrePage() {
      if (this.activePage == 'taskResult' && this.projectType == '2') {
        this.activePage = 'loopTaskResult'
      } else {
        this.activePage = 'taskSetting'
      }
    },
    createTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
      return ''
    },
    projectTypeFilter(row, column, cellValue) {
      if (cellValue == '1') {
        return '即时任务'
      } else if (cellValue == '2') {
        return '循环任务'
      }
    },
    // 获取单个智能筛选任务配置
    getProjectInfo(id) {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/itFilter/getProjectInfo.do',
          Qs.stringify({
            projectId: id,
          })
        )
        .then(function(response) {
          _this.projectModel = response.data
          return Promise.resolve(response)
        })
        .catch(function(error) {
          console.log(error)
          _this.$message.error('获取任务详情失败')
        })
    },
  },
  mounted() {
    this.$nextTick(function() {
      this.taskInquiry()
      this.getTaskType()
    })
  },
  watch: {
    pageSize() {
      this.taskInquiry()
    },
    currentPage() {
      this.taskInquiry()
    },
  },
}
</script>
<style lang="less">
.intelligent {
  .operation {
    .time {
      .el-date-editor.fr.el-input.el-date-editor--datetimerange,
      .el-select.fr {
        width: 175px;
      }
    }
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
}
</style>
<style scoped="scoped" lang="less">
@boder-color: #d1dbe5;
.intelligent {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .operation {
    height: 55px;
    line-height: 55px;
    position: relative;
    border-bottom: 1px dashed @boder-color;
    text-align: right;
    margin-right: -10px;

    .el-form-item {
      margin-bottom: 0px;

      .el-form-item__content {
        line-height: 55px;
      }
    }
    & > div {
      display: inline-block;
      text-align: right;

      button {
        width: 90px;
      }

      & .searchForm {
        position: absolute;
        right: -10px;

        div.el-form-item__content {
          vertical-align: middle !important;
          border: 1px solid red;
        }
      }
    }
  }
  .taskResult {
    .operation {
      .tips {
        & > label {
          color: #9dadc2;
          font-size: 14px;
        }

        & > span {
          margin: 0px 10px 0px 5px;
        }
      }
      .btns {
        float: right;
        margin-right: -10px;
      }
    }
  }
  .intelligent-content {
    box-sizing: border-box;
    position: absolute;
    top: 65px;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 0px 10px;
    padding-bottom: 40px;
    overflow: hidden;
  }

  .intelligent-content .intelligent-content-pos {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }

  .intelligent-content .intelligent-page {
    width: 100%;
    height: 35px;
    position: absolute;
    left: 0;
    right: 0px;
    bottom: 0;
    text-align: right;
  }

  .intelligent-page .el-pagination {
    display: inline-block;
    height: 28px;
    line-height: 28px;
    padding: 0px 10px;
  }

  #newTaskdialog .el-dialog__body {
  }

  #intelligent .intelligent-content-pos .el-table__body-wrapper {
    overflow-x: hidden;
  }

  .btns {
    text-align: right;
  }

  table .cell > i {
    width: 35px;

    & > i {
      font-family: '微软雅黑';
      margin-left: 4px;
      font-size: 14px;
    }
  }
}
</style>
