<template>
  <div id="newtask">
    <div class="attrs">
      <el-form
        label-width="100px"
        :model="TaskAttr"
        ref="TaskAttr"
        :rules="taskAttrRules"
      >
        <div class="audioAttrs_part taskAttrs">
          <h3>
            任务属性
          </h3>
          <div class="audioAttrsInputs">
            <el-col :span="6">
              <el-form-item label="任务名称" prop="projectName">
                <el-input
                  v-model="TaskAttr.projectName"
                  :disabled="dialogType == 'edit'"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="任务类型" prop="projectType">
                <el-select
                  v-model="TaskAttr.projectType"
                  :disabled="dialogType == 'edit'"
                  clearable
                  placeholder="请选择任务类型"
                  class="fl"
                >
                  <el-option
                    v-for="item in taskTypes"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id + ''"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="模板选择" prop="scriptId">
                <el-select v-model="TaskAttr.scriptId" clearable placeholder="请选择">
                  <el-option
                    v-for="item in scriptIdList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
                <i class="el-icon-setting setting" @click="gotoSetting"></i>
              </el-form-item>
            </el-col>
          </div>
        </div>
        <div class="audioAttrs_part" v-if="TaskAttr.projectType == '2'" :key="1">
          <h3>
            周期（天）
          </h3>
          <div class="audioAttrsInputs taskAttrs">
            <el-col :span="6">
              <el-form-item label="运行周期" prop="runCycle">
                <el-input v-model="TaskAttr.runCycle"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="抽样周期" prop="gatherCycle">
                <el-input v-model="TaskAttr.gatherCycle"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6"> </el-col>
            <el-col :span="6"> </el-col>
          </div>
        </div>
        <div class="audioAttrs_part" v-if="TaskAttr.projectType == '1'" :key="2">
          <h3>
            时间范围
          </h3>
          <div class="audioAttrsInputs taskAttrs">
            <el-col :span="7">
              <el-form-item label="开始时间" prop="callSTime_Min">
                <el-date-picker
                  v-model="TaskAttr.callSTime_Min"
                  type="datetime"
                  placeholder="选择日期时间"
                >
                </el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="7">
              <el-form-item label="结束时间" prop="callSTime_Max">
                <el-date-picker
                  v-model="TaskAttr.callSTime_Max"
                  type="datetime"
                  placeholder="选择日期时间"
                >
                </el-date-picker>
              </el-form-item>
            </el-col>
          </div>
        </div>
      </el-form>

      <!-- 表单引擎部分 -->
      <div class="form">
        <my-comp ref="myComp"></my-comp>
      </div>

      <div class="btns">
        <el-button type="primary" @click="taskCreateThrottle" v-if="dialogType == 'add'"
          >保存</el-button
        >
        <el-button type="primary" @click="taskEditThrottle" v-if="dialogType == 'edit'"
          >保存</el-button
        >
        <el-button type="primary" @click="taskCreate" v-if="dialogType == 'copy'"
          >保存</el-button
        >
        <el-button @click="resetForm('Task')" v-if="dialogType == 'add'">清空</el-button>
        <el-button @click="resetCopyForm('TaskAttr')" v-if="dialogType == 'copy'"
          >清空</el-button
        >
        <el-button @click="taskGoback">返回</el-button>
      </div>
    </div>
  </div>
</template>
<style lang="less">
#newtask {
  .attrs .audioAttrs_part .audioAttrsInputs .el-form-item label {
    color: #8691a5;
  }
  .attrs {
    .form {
      h3 {
        padding-left: 10px;
        line-height: 30px;
        color: #9dadc2;
        font-weight: normal;
      }
      label {
        color: #8691a5;
      }
      .el-row {
        padding: 0px 10px;
      }
    }
  }
}
</style>
<style scoped="scoped" lang="less">
@border-color: #d1dbe5;
.attrs {
  .audioAttrs_part {
    border-bottom: 1px dashed @border-color;
    overflow: hidden;
    .audioAttrsInputs {
      padding: 10px;
    }
  }
  h3 {
    padding-left: 10px;
    line-height: 30px;
    color: #9dadc2;
    font-weight: normal;
  }
  .btns {
    text-align: right;
    margin-top: 10px;
  }
}

.line {
  text-align: center;
}

.timeline {
  text-align: center;
  margin-top: 5px;
  margin-right: -5px;
}

.unit {
  margin: 0 5px;
}

.setting {
  font-size: 16px;
  color: #8691a5;
  margin: 8px 0px 10px 10px;
  cursor: pointer;
}
</style>
<script>
import Qs from 'qs'
import formatdate from '../../../utils/formatdate.js'
import global from '../../../global.js'
import nativeaxios from 'axios'
import cache from '../../../utils/cache.js'
import filterRecordsComp from './filterRecordsComp.vue'
let currentBaseUrl = global.currentBaseUrl
export default {
  props: ['projectModel'],
  components: {
    // 局部注册

    'my-comp': filterRecordsComp,
    // 'my-comp': (resolve, reject) => {
    //   nativeaxios
    //     .post(
    //       global.formEngineUrl +
    //         '/creating.do?formIds=intelFilterLuyin,intelFilterYuangong,intelFilterKehu,intelFilterYuyin&accessToken=' +
    //         cache.getItem('tgt_id')
    //     )
    //     .then(function(response) {
    //       $('body').append(response.data.Validate)
    //       let myHtml = response.data.Html
    //       resolve({
    //         template: myHtml,
    //         watch: {
    //           // 监听
    //         },
    //         data() {
    //           return {
    //             /* eslint-disable */
    //             intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model: JSON.parse(
    //               JSON.stringify(
    //                 intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_
    //               )
    //             ),
    //             intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Rules: intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Rules,
    //             /* eslint-enable */
    //           }
    //         },
    //       })
    //     })
    // },
  },
  data() {
    let checkNumber = (rule, value, callback) => {
      if (value == '') {
        callback(new Error('请输入数字'))
      } else if (isNaN(value)) {
        callback(new Error('请输入数字'))
      } else {
        callback()
      }
    }
    return {
      dialogType: 'add',
      silenceAttrType: '', // 静默特征类型
      projectId: '',
      TaskAttr: {
        projectName: '',
        projectType: '',
        scriptId: '',
        runCycle: '',
        gatherCycle: '',
        callSTime_Min: '',
        callSTime_Max: '',
      }, // 任务属性
      taskAttrRules: {
        // 任务属性验证
        projectName: [{ required: true, message: '任务名称不能为空', trigger: 'blur' }],
        projectType: [{ required: true, message: '请选择一种任务类型', trigger: 'blur' }],
        scriptId: [{ required: true, message: '请选择模板', trigger: 'blur' }],
        runCycle: [
          { required: true, message: '请输入运行周期', trigger: 'blur' },
          { validator: checkNumber, trigger: 'blur' },
        ],
        gatherCycle: [
          { required: true, message: '请输入抽样周期', trigger: 'blur' },
          { validator: checkNumber, trigger: 'blur' },
        ],
        callSTime_Min: [
          {
            type: 'date',
            required: true,
            message: '请输入录音开始时间',
            trigger: 'change',
          },
        ],
        callSTime_Max: [
          {
            type: 'date',
            required: true,
            message: '请输入录音结束时间',
            trigger: 'change',
          },
        ],
      },

      taskTypes: [],
      silenceAttrs: [
        {
          value: 'silenceLong',
          label: '时长',
        },
        {
          value: 'silenceCount',
          label: '次数',
        },
        {
          value: 'silencePer',
          label: '占比',
        },
      ],
      scriptIdList: [], // 模板列表
    }
  },
  methods: {
    taskCreateThrottle() {
      this.lodashThrottle.throttle(this.taskCreate, this)
    },
    taskCreate() {
      let _this = this
      this.$refs.TaskAttr.validate(function(valid) {
        if (!valid) {
          return false
        } else {
          let myComp = _this.$refs.myComp

          let params = {
            projectName: _this.TaskAttr.projectName,
            scriptId: _this.TaskAttr.scriptId,
            projectType: _this.TaskAttr.projectType,
            strategyObject: JSON.stringify(
              myComp.intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model
            ), // 替换成表单引擎的
            runCycle: _this.TaskAttr.runCycle,
            gatherCycle: _this.TaskAttr.gatherCycle,
          }
          let temp = JSON.parse(params.strategyObject)
          if (_this.TaskAttr.callSTime_Min) {
            temp.callSTime_Min = formatdate.formatDate(_this.TaskAttr.callSTime_Min)
          } else {
            temp.callSTime_Min = ''
          }
          if (temp.callSTime_Min.indexOf('NaN') >= 0) {
            console.log('assssss')
            temp.callSTime_Min = ''
          }

          if (_this.TaskAttr.callSTime_Max) {
            temp.callSTime_Max = formatdate.formatDate(_this.TaskAttr.callSTime_Max)
          } else {
            temp.callSTime_Max = ''
          }
          if (temp.callSTime_Max.indexOf('NaN') >= 0) {
            console.log('assssss')
            temp.callSTime_Max = ''
          }
          temp.callSTime = null
          params.strategyObject = JSON.stringify(temp)
          if (
            new Date(temp.callSTime_Max).getTime() <
            new Date(temp.callSTime_Min).getTime()
          ) {
            _this.$message({
              type: 'error',
              message: '任务结束时间应大于开始时间',
            })
            return false
          }
          _this.axios
            .post(currentBaseUrl + '/itFilter/saveProject.do', Qs.stringify(params))
            .then(function(response) {
              if (response.data.state == '1') {
                _this.$message({
                  type: 'success',
                  message: '策略保存成功',
                })
                _this.$emit('send', false, 'success')
              } else {
                _this.$message({
                  type: 'error',
                  message: '该策略名称已存在',
                })
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '策略保存失败',
              })
            })
        }
      })
    },
    taskEditThrottle() {
      this.lodashThrottle.throttle(this.taskEdit, this)
    },
    taskEdit() {
      let _this = this
      this.$refs.TaskAttr.validate(function(valid) {
        if (!valid) {
          return false
        } else {
          let myComp = _this.$refs.myComp
          let params = {
            projectName: _this.TaskAttr.projectName,
            scriptId: _this.TaskAttr.scriptId,
            projectType: _this.TaskAttr.projectType,
            strategyObject: JSON.stringify(
              myComp.intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model
            ),
            projectId: _this.projectId,
            runCycle: _this.TaskAttr.runCycle,
            gatherCycle: _this.TaskAttr.gatherCycle,
          }
          let temp = JSON.parse(params.strategyObject)
          if (_this.TaskAttr.callSTime_Min) {
            temp.callSTime_Min = formatdate.formatDate(_this.TaskAttr.callSTime_Min)
          } else {
            temp.callSTime_Min = ''
          }
          if (temp.callSTime_Min.indexOf('NaN') >= 0) {
            temp.callSTime_Min = ''
          }

          if (_this.TaskAttr.callSTime_Max) {
            temp.callSTime_Max = formatdate.formatDate(_this.TaskAttr.callSTime_Max)
          } else {
            temp.callSTime_Max = ''
          }
          if (temp.callSTime_Max.indexOf('NaN') >= 0) {
            temp.callSTime_Max = ''
          }
          if (
            new Date(temp.callSTime_Max).getTime() <
            new Date(temp.callSTime_Min).getTime()
          ) {
            _this.$message({
              type: 'error',
              message: '任务结束时间应大于开始时间',
            })
            return false
          }
          params.strategyObject = JSON.stringify(temp)
          let url = currentBaseUrl + '/itFilter/updateProject.do'
          _this.axios
            .post(url, Qs.stringify(params))
            .then(function(response) {
              if (response.data) {
                _this.$message({
                  type: 'success',
                  message: '策略保存成功',
                })
                _this.$emit('send', false, 'success')
              } else {
                Promise.reject(response)
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '策略保存失败',
              })
            })
        }
      })
    },
    taskGoback() {
      // 点击返回按钮callingTime
      this.$emit('send', false)
    },
    // 清空复制
    resetCopyForm(formName) {
      let myComp = this.$refs.myComp
      if (
        myComp.$refs
          .intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Ref
      ) {
        myComp.$refs.intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Ref.resetFields()
      }
      this.$refs.TaskAttr.resetFields()
    },
    resetForm(formName) {
      let myComp = this.$refs.myComp
      if (
        myComp.$refs
          .intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Ref
      ) {
        myComp.$refs.intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Ref.resetFields()
      }
      this.$refs.TaskAttr.resetFields()
      this.TaskAttr.projectType = this.taskTypes[0].id
    },
    // 点击配置进入到智能筛选模板界面
    gotoSetting() {
      this.$router.push('/clusterModelIndexHr')
    },
    // 获取模板列表
    getModleInfoByCondition() {
      let _this = this
      let params = {
        modleType: '7',
        pageindex: '',
        pagesize: '',
      }
      let url = currentBaseUrl + '/pageConstant/getValue.do?keys=fullModel,ipType'
      _this.axios
        .post(url, Qs.stringify(params))
        .then(function(response) {
          _this.scriptIdList = response.data['fullModel']
          _this.taskTypes = response.data['ipType']
          if (!_this.TaskAttr.projectType) {
            _this.TaskAttr.projectType = _this.taskTypes[0].id
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message.error('模板获取失败')
        })
    },
  },
  mounted() {
    this.getModleInfoByCondition()
    if (this.projectModel && this.projectModel.project) {
      this.TaskAttr.projectName = this.projectModel.project.projectName
      this.TaskAttr.projectType = this.projectModel.project.projectType
      this.TaskAttr.scriptId = this.projectModel.project.scriptId
      this.TaskAttr.runCycle =
        this.projectModel.project.runCycle != null
          ? this.projectModel.project.runCycle + ''
          : null
      this.TaskAttr.gatherCycle =
        this.projectModel.project.gatherCycle != null
          ? this.projectModel.project.gatherCycle + ''
          : null
      this.projectId = this.projectModel.project.projectId
      this.dialogType = this.projectModel.type
      this.Task = JSON.parse(this.projectModel.strategyObject)
      this.TaskAttr.callSTime_Min = this.Task.callSTime_Min
        ? new Date(this.Task.callSTime_Min)
        : ''
      this.TaskAttr.callSTime_Max = this.Task.callSTime_Max
        ? new Date(this.Task.callSTime_Max)
        : ''
      this.$refs.myComp.intelFilterLuyin_intelFilterYuangong_intelFilterKehu_intelFilterYuyin_Model = this.Task
    }
  },
}
</script>
