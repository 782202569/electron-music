<template>
  <div style="height: 100%;">
    <div class="QualityInspectionReport" v-show="!paryTasks">
      <div class="header">
        <i @click="refreshData" class="el-icon-refresh icon"></i>
      </div>
      <div class="content">
        <div class="content-line">
          <div class="item item1">
            <div class="toolBar">
              <img
                v-popover:generationSet
                @click="showSet('generation')"
                class="icon"
                src="../../../assets/img/setIng.png"
                alt=""
              />
              <el-popover
                ref="generationSet"
                popper-class="popperHover"
                placement="bottom"
                :visible-arrow="false"
                width="100"
                trigger="hover"
                content="自定义"
              >
              </el-popover>
              <img
                v-popover:generationExcel
                @click="exportExcel('generation')"
                class="icon"
                src="../../../assets/img/excelReport.png"
                alt=""
              />
              <el-popover
                ref="generationExcel"
                popper-class="popperHover"
                placement="bottom"
                :visible-arrow="false"
                width="100"
                trigger="hover"
                content="导出Excel"
              >
              </el-popover>
              <img
                v-popover:generationToPower
                @click="handleToLarge('generation')"
                class="icon"
                src="../../../assets/img/enLarge.png"
                alt=""
              />
              <el-popover
                ref="generationToPower"
                popper-class="popperHover"
                placement="bottom"
                :visible-arrow="false"
                width="100"
                trigger="hover"
                content="放大按钮"
              >
              </el-popover>
            </div>
            <div class="qaReport-dec">
              <div class="dec-item">
                <p class="dec-item-top">
                  <span>入库量</span>
                </p>
                <p class="dec-item-bottom">
                  <span class="bottomCount">{{ generationData.insertEsTotalCount }}</span>
                  <span class="right-count">{{ generationData.insertEsChain }}</span>
                </p>
              </div>
              <div class="dec-item">
                <p class="dec-item-top">
                  <span>初检量</span>
                </p>
                <p class="dec-item-bottom">
                  <span class="bottomCount">{{ generationData.firstQaTotalCount }}</span>
                  <span class="right-count">{{
                    generationData.firstQaTotalCountChain
                  }}</span>
                </p>
              </div>
              <div class="dec-item">
                <p class="dec-item-top">
                  <span>复检量</span>
                </p>
                <p class="dec-item-bottom">
                  <span class="bottomCount">{{ generationData.secondQaTotalCount }}</span>
                  <span class="right-count">{{
                    generationData.secondQaTotalCountChain
                  }}</span>
                </p>
              </div>
              <div class="dec-item dec-item-last">
                <p class="dec-item-top">
                  <span>逾期量</span>
                </p>
                <p class="dec-item-bottom">
                  <span class="bottomCount">{{ generationData.overdueTotalCount }}</span>
                  <span class="right-count">{{
                    generationData.overdueTotalCountChain
                  }}</span>
                </p>
              </div>
            </div>
            <div class="qaReport-table">
              <zk-table
                ref="table"
                sum-text="sum"
                index-text="#"
                :data="qaQualityReportResults"
                :columns="columns"
                :stripe="props.stripe"
                :border="props.border"
                :show-header="props.showHeader"
                :show-summary="props.showSummary"
                :show-row-hover="props.showRowHover"
                :show-index="props.showIndex"
                :tree-type="props.treeType"
                :is-fold="props.isFold"
                :expand-type="props.expandType"
                :selection-type="props.selectionType"
                @cell-contextmenu="handleGenerationExportDec"
              >
              </zk-table>
            </div>
            <!-- 录音时间 -->
            <div class="tableDealog" v-show="sustomShow1">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">录音时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange1" @change="changeValue1">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.generationTime"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour1"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('generationTime')"
                  >确 定</el-button
                >
              </div>
            </div>
            <div
              id="exportDec"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('0', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
          <div class="item item2">
            <div class="echartWrap" id="appRateQA">
              此处环形图
            </div>
            <!-- 录音时间 -->
            <div class="tableDealog" v-show="sustomShow">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">录音时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange" @change="changeValue">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.findTimer"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('findTimer')"
                  >确 定</el-button
                >
              </div>
            </div>
            <div
              id="exportDec1"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('1', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
          <div class="item item3">
            <div class="toolBar">
              <span class="title">评分被申诉率</span>
              <img
                v-popover:beishensulvToLarge
                @click="handleToLarge('beishensulv')"
                class="icon"
                src="../../../assets/img/enLarge.png"
                alt=""
              />
              <el-popover
                ref="beishensulvToLarge"
                popper-class="popperHover"
                placement="bottom"
                :visible-arrow="false"
                width="100"
                trigger="hover"
                content="放大按钮"
              >
              </el-popover>
              <img
                v-popover:beishensulvExcel
                @click="exportExcel('exportQABeAppedRate')"
                class="icon"
                src="../../../assets/img/excelReport.png"
                alt=""
              />
              <el-popover
                ref="beishensulvExcel"
                popper-class="popperHover"
                placement="bottom"
                :visible-arrow="false"
                width="100"
                trigger="hover"
                content="导出Excel"
              >
              </el-popover>
              <img
                v-popover:beishensulvSet
                @click="showSet('beishensulv')"
                class="icon"
                src="../../../assets/img/setIng.png"
                alt=""
              />
              <el-popover
                ref="beishensulvSet"
                popper-class="popperHover popperBeishensulv"
                placement="bottom"
                :visible-arrow="false"
                width="50"
                trigger="hover"
                content="自定义"
              >
              </el-popover>
            </div>
            <div class="shensu-table">
              <zk-table
                ref="table1"
                sum-text="sum"
                index-text="#"
                :data="tableDataShenSu"
                :columns="ShenSuColumns"
                :stripe="props.stripe"
                :border="props.border"
                :show-header="props.showHeader"
                :show-summary="props.showSummary"
                :show-row-hover="props.showRowHover"
                :show-index="props.showIndex"
                :tree-type="props.treeType"
                :is-fold="props.isFold"
                :expand-type="props.expandType"
                :selection-type="props.selectionType"
                @cell-click="handleSingleBeiShenSuLv"
                @cell-contextmenu="handleBeiShenSuExportDec"
              >
                <template slot="zjyName" scope="scope">
                  {{ scope.row.zjyName }}
                </template>
                <template slot="persent" scope="scope">
                  {{ scope.row.persent }}
                </template>
              </zk-table>
            </div>
            <!-- 录音时间 -->
            <div class="tableDealog" v-show="sustomShow2">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">录音时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange2" @change="changeValue2">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.beiShenSuLvTime"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour2"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('beiShenSuLvTime')"
                  >确 定</el-button
                >
              </div>
            </div>
            <div
              id="exportDec2"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('2', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
        </div>
        <div class="content-line">
          <div class="item item4">
            <div class="echartWrap" id="myChart"></div>
            <!-- 录音时间 -->
            <div class="tableDealog" v-show="sustomShow3">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">质检打分时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange3" @change="changeValue3">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.compelteTime"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour3"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('compelteTime')"
                  >确 定</el-button
                >
              </div>
            </div>
            <div
              id="exportDec3"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('3', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
          <div class="item item5">
            <div class="echartWrap" id="notCompelteChart"></div>
            <!-- 录音时间 -->
            <div class="tableDealog" v-show="sustomShow4">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">质检分发时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange4" @change="changeValue4">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.notCompelteTime"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour4"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('notCompelteTime')"
                  >确 定</el-button
                >
              </div>
            </div>
            <div
              id="exportDec4"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('4', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
          <div class="item item6">
            <div class="echartWrap" id="AverageScoreDeviation"></div>
            <!-- 录音时间 -->
            <div class="tableDealog" v-show="sustomShow5">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">录音时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange5" @change="changeValue5">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.avgTotalTime"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour5"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('avgTotalTime')"
                  >确 定</el-button
                >
              </div>
            </div>
            <div
              id="exportDec5"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('5', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 进入图片放大功能页面 -->
    <pTasks
      id="paryTasks"
      v-if="paryTasks"
      :message="this.otherValue"
      v-on:send="sellTill"
    ></pTasks>
  </div>
</template>
<script>
import ZkTable from 'vue-table-with-tree-grid'
import formatdate from '../../../utils/formatdate.js'
import global from '../../../global.js'
import Qs from 'qs'
import commonUtil from '../../../utils/commonUtil.js'
import pTasks from './reportBigimg.vue'
// let fileDownload = require('js-file-download')
let qualityUrl = global.qualityUrl
const colorList = [
  '#1890FF',
  '#41D9C7',
  '#2FC25B',
  '#FACC14',
  '#E6965C',
  '#223273',
  '#7564CC',
  '#8543E0',
  '#5C8EE6',
  '#13C2C2',
  '#5CA3E6',
  '#3436C7',
  '#B381E6',
  '#F04864',
  '#D598D9',
]
export default {
  components: {
    pTasks,
    ZkTable,
  },
  data() {
    return {
      initTime: [],
      qaUsers: '',
      paryTasks: false,
      sustomShow: false,
      sustomShow1: false,
      sustomShow2: false,
      sustomShow3: false,
      sustomShow4: false,
      sustomShow5: false,
      timeChange: 3,
      timeChange1: 3,
      timeChange2: 3,
      timeChange3: 3,
      timeChange4: 3,
      timeChange5: 3,
      searchForm: {
        findTimer: [], // 质检申诉率
        generationTime: [], // 概览
        notCompelteTime: [], // 未完成情况
        compelteTime: [], // 完成情况
        beiShenSuLvTime: [], // 被申诉率
        avgTotalTime: [], // 平均评分偏差
      },
      visible: false,
      abledFour: true,
      abledFour1: true,
      abledFour2: true,
      abledFour3: true,
      abledFour4: true,
      abledFour5: true,
      otherValue: {},
      exportDecParames: {}, // 导出明细对象
      timeArr: [],
      tableDataShenSu: [],
      generationData: {},
      qaQualityReportResults: [],
      columns: [
        {
          label: '质检员姓名',
          prop: 'qaUserName',
          width: '100px',
        },
        {
          label: '上岗天数',
          prop: 'workDays',
        },
        {
          label: '初检量',
          prop: 'firstQualityCount',
        },
        {
          label: '复检量',
          prop: 'secondQualityCount',
        },
        {
          label: '逾期量',
          prop: 'qualityOverDueCount',
        },
      ],
      ShenSuColumns: [
        {
          label: '质检员姓名',
          prop: 'zjyName',
          width: '100px',
        },
        {
          label: '被申诉率',
          prop: 'persent',
        },
      ],
      props: {
        stripe: false,
        border: true,
        showHeader: true,
        showSummary: false,
        showRowHover: false,
        showIndex: false,
        treeType: false,
        isFold: true,
        expandType: false,
        selectionType: false,
      },
    }
  },
  methods: {
    initMonthTime() {
      let fromData = ''
      let toform = ''
      let now = new Date()
      now.setDate(1)
      now.setHours(0)
      now.setMinutes(0)
      now.setSeconds(0)
      fromData = formatdate.formatDate(now)
      let currentMonth = now.getMonth()
      let nextMonth = ++currentMonth
      let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
      let oneDay = 1
      toform = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      this.initTime = [fromData, toform]
    },
    sellTill(input) {
      // 放大缩小功能
      this.paryTasks = false
    },
    // 录音数量筛选条件
    changeValue: function(value) {
      if (value == 4) {
        this.abledFour = false
      } else {
        this.abledFour = true
      }
    },
    changeValue1: function(value) {
      if (value == 4) {
        this.abledFour1 = false
      } else {
        this.abledFour1 = true
      }
    },
    changeValue2: function(value) {
      if (value == 4) {
        this.abledFour2 = false
      } else {
        this.abledFour2 = true
      }
    },
    changeValue3: function(value) {
      if (value == 4) {
        this.abledFour3 = false
      } else {
        this.abledFour3 = true
      }
    },
    changeValue4: function(value) {
      if (value == 4) {
        this.abledFour4 = false
      } else {
        this.abledFour4 = true
      }
    },
    changeValue5: function(value) {
      if (value == 4) {
        this.abledFour5 = false
      } else {
        this.abledFour5 = true
      }
    },
    sure(name) {
      let _this = this
      if (name == 'generationTime') {
        this.sustomShow1 = false
        if (this.timeChange1 == 1) {
          _this.abledFour1 = true
          _this.dayFunc(name)
        } else if (this.timeChange1 == 2) {
          _this.abledFour1 = true
          _this.weekFunc(name)
        } else if (this.timeChange1 == 3) {
          _this.abledFour1 = true
          _this.monthFunc(name)
        } else if (this.timeChange1 == 4) {
          _this.abledFour1 = false
          if (this.searchForm.generationTime.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.generationTime[0]),
          endTime: formatdate.formatDate(this.searchForm.generationTime[1]),
        }
        this.initTotalData(params)
      } else if (name == 'findTimer') {
        this.sustomShow = false
        if (this.timeChange == 1) {
          _this.abledFour = true
          _this.dayFunc(name)
        } else if (this.timeChange == 2) {
          _this.abledFour = true
          _this.weekFunc(name)
        } else if (this.timeChange == 3) {
          _this.abledFour = true
          _this.monthFunc(name)
        } else if (this.timeChange == 4) {
          _this.abledFour = false
          if (this.searchForm.findTimer.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          callSTime_Min: formatdate.formatDate(this.searchForm.findTimer[0]),
          callSTime_Max: formatdate.formatDate(this.searchForm.findTimer[1]),
        }
        this.drawAppRate(params)
      } else if (name == 'beiShenSuLvTime') {
        this.sustomShow2 = false
        if (this.timeChange2 == 1) {
          _this.abledFour2 = true
          _this.dayFunc(name)
        } else if (this.timeChange2 == 2) {
          _this.abledFour2 = true
          _this.weekFunc(name)
        } else if (this.timeChange2 == 3) {
          _this.abledFour2 = true
          _this.monthFunc(name)
        } else if (this.timeChange2 == 4) {
          _this.abledFour2 = false
          if (this.searchForm.beiShenSuLvTime.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          callSTime_Min: formatdate.formatDate(this.searchForm.beiShenSuLvTime[0]),
          callSTime_Max: formatdate.formatDate(this.searchForm.beiShenSuLvTime[1]),
        }
        this.initQABeAppedRate(params)
      } else if (name == 'compelteTime') {
        this.sustomShow3 = false
        if (this.timeChange3 == 1) {
          _this.abledFour3 = true
          _this.dayFunc(name)
        } else if (this.timeChange3 == 2) {
          _this.abledFour3 = true
          _this.weekFunc(name)
        } else if (this.timeChange3 == 3) {
          _this.abledFour3 = true
          _this.monthFunc(name)
        } else if (this.timeChange3 == 4) {
          _this.abledFour3 = false
          if (this.searchForm.compelteTime.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          begin: formatdate.formatDate(this.searchForm.compelteTime[0]),
          end: formatdate.formatDate(this.searchForm.compelteTime[1]),
        }
        this.initQaUserFinish(params)
      } else if (name == 'notCompelteTime') {
        this.sustomShow4 = false
        if (this.timeChange4 == 1) {
          _this.abledFour4 = true
          _this.dayFunc(name)
        } else if (this.timeChange4 == 2) {
          _this.abledFour4 = true
          _this.weekFunc(name)
        } else if (this.timeChange4 == 3) {
          _this.abledFour4 = true
          _this.monthFunc(name)
        } else if (this.timeChange4 == 4) {
          _this.abledFour4 = false
          if (this.searchForm.notCompelteTime.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          begin: formatdate.formatDate(this.searchForm.notCompelteTime[0]),
          end: formatdate.formatDate(this.searchForm.notCompelteTime[1]),
        }
        this.initQaUserUnFinish(params)
      } else if (name == 'avgTotalTime') {
        this.sustomShow5 = false
        if (this.timeChange5 == 1) {
          _this.abledFour5 = true
          _this.dayFunc(name)
        } else if (this.timeChange5 == 2) {
          _this.abledFour5 = true
          _this.weekFunc(name)
        } else if (this.timeChange5 == 3) {
          _this.abledFour5 = true
          _this.monthFunc(name)
        } else if (this.timeChange5 == 4) {
          _this.abledFour5 = false
          if (this.searchForm.avgTotalTime.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.avgTotalTime[0]),
          endTime: formatdate.formatDate(this.searchForm.avgTotalTime[1]),
        }
        this.initAverageScore(params)
      }
    },
    // 时间控件查本日的
    dayFunc(name) {
      let d = new Date()
      let str = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
      let startTime = str + ' 00:00:00'
      let endTime = str + ' 23:59:59'
      if (name == 'generationTime') {
        this.searchForm.generationTime = [startTime, endTime]
      } else if (name == 'notCompelteTime') {
        this.searchForm.notCompelteTime = [startTime, endTime]
      } else if (name == 'compelteTime') {
        this.searchForm.compelteTime = [startTime, endTime]
      } else if (name == 'findTimer') {
        this.searchForm.findTimer = [startTime, endTime]
      } else if (name == 'beiShenSuLvTime') {
        this.searchForm.beiShenSuLvTime = [startTime, endTime]
      } else if (name == 'avgTotalTime') {
        this.searchForm.avgTotalTime = [startTime, endTime]
      }
    },
    // 时间控件查本周的
    weekFunc(name) {
      let now = new Date()
      let nowTime = now.getTime()
      let day = now.getDay()
      let oneDayTime = 24 * 60 * 60 * 1000
      let startTime =
        formatdate.formatDateWithoutTimes(nowTime - (day - 1) * oneDayTime) + ' 00:00:00'
      let endTime =
        formatdate.formatDateWithoutTimes(nowTime + (7 - day) * oneDayTime) + ' 23:59:59'
      if (name == 'generationTime') {
        this.searchForm.generationTime = [startTime, endTime]
      } else if (name == 'notCompelteTime') {
        this.searchForm.notCompelteTime = [startTime, endTime]
      } else if (name == 'compelteTime') {
        this.searchForm.compelteTime = [startTime, endTime]
      } else if (name == 'findTimer') {
        this.searchForm.findTimer = [startTime, endTime]
      } else if (name == 'beiShenSuLvTime') {
        this.searchForm.beiShenSuLvTime = [startTime, endTime]
      } else if (name == 'avgTotalTime') {
        this.searchForm.avgTotalTime = [startTime, endTime]
      }
    },
    // 时间控件查本月的
    monthFunc(name) {
      let now = new Date()
      now.setDate(1)
      now.setHours(0)
      now.setMinutes(0)
      now.setSeconds(0)
      let startTime = formatdate.formatDate(now)
      let currentMonth = now.getMonth()
      let nextMonth = ++currentMonth
      let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
      let oneDay = 1000
      let endTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      if (name == 'generationTime') {
        this.searchForm.generationTime = [startTime, endTime]
      } else if (name == 'notCompelteTime') {
        this.searchForm.notCompelteTime = [startTime, endTime]
      } else if (name == 'compelteTime') {
        this.searchForm.compelteTime = [startTime, endTime]
      } else if (name == 'findTimer') {
        this.searchForm.findTimer = [startTime, endTime]
      } else if (name == 'beiShenSuLvTime') {
        this.searchForm.beiShenSuLvTime = [startTime, endTime]
      } else if (name == 'avgTotalTime') {
        this.searchForm.avgTotalTime = [startTime, endTime]
      }
    },
    cancelNot: function() {
      this.sustomShow = false
      this.sustomShow1 = false
      this.sustomShow2 = false
      this.sustomShow3 = false
      this.sustomShow4 = false
      this.sustomShow5 = false
    },
    showSet(name) {
      if (name == 'generation') {
        this.sustomShow1 = true
      } else {
        this.sustomShow2 = true
      }
    },
    // 质检完成情况
    initQaUserFinish(params) {
      let self = this
      this.axios
        .post(qualityUrl + '/reportForm/qaUserFinish.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            let completionQaData = {}
            let Xarr = []
            let Yarr = []
            let Y1arr = []
            let Y2arr = []
            // let completionQaDataY1 = []
            // let completionQaDataY2 = []
            res.data.forEach(function(item) {
              Xarr.push(item.date)
              Yarr.push(item.list)
              Y1arr.push(item.totalCount)
              Y2arr.push((item.totalAvgTime / 60).toFixed(2))
            })
            let Y1max = Math.ceil(Math.max.apply(Math, Y1arr))
            let Y2max = Math.ceil(Math.max.apply(Math, Y2arr))
            Y2max = Y2max.toFixed(2)
            completionQaData = {
              Xarr: Xarr,
              Yarr: Yarr,
              Y1max: Y1max,
              Y2max: Y2max,
            }
            self.completionQualityInspection(completionQaData, Y2arr)
          }
        })
    },
    // 质检未完成情况
    initQaUserUnFinish(params) {
      let self = this
      this.axios
        .post(qualityUrl + '/reportForm/qaUserUnFinish.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            let UnFinishData = []
            res.data.list.forEach(function(item) {
              UnFinishData.push({
                qaUserName: item.qaUserName,
                unFinish: item.unFinish,
                qaUserNameNo: item.qaUserNameNo,
                totcalTime: item.totcalTime,
                avgTime: item.avgTime,
              })
            })
            self.notCompletionQualityInspection(UnFinishData)
          }
        })
    },
    // 平均评分偏差
    initAverageScore(params) {
      let self = this
      this.axios
        .post(qualityUrl + '/averageScore/getAverageScore.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            self.AverageScoreDeviation(res.data)
          }
        })
    },
    // 质检被申诉率
    initQABeAppedRate(params) {
      let self = this
      this.axios
        .post(qualityUrl + '/appReport/getQABeAppedRate.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            self.tableDataShenSu = res.data.Data
          }
        })
    },
    // 总览
    initTotalData(paramsGenration) {
      let self = this
      this.axios
        .post(qualityUrl + '/qualityReport/totalData.do', Qs.stringify(paramsGenration))
        .then(function(res) {
          if (res.data) {
            self.generationData = res.data.Data
            self.qaQualityReportResults =
              res.data.Data.qaQualityReportResults == null
                ? []
                : res.data.Data.qaQualityReportResults
          }
        })
    },
    // 初始化数据
    initChartData() {
      this.initMonthTime()
      if (this.initTime == [] || this.initTime.length <= 0) {
        return
      }
      let start = this.initTime[0]
      let end = this.initTime[1]
      let params = {
        begin: start,
        end: end,
      }
      let paramsGenration = {
        startTime: start,
        endTime: end,
      }
      let paramesCall = {
        callSTime_Min: start,
        callSTime_Max: end,
      }
      this.initQaUserUnFinish(params)
      this.initQABeAppedRate(paramesCall)
      this.initTotalData(paramsGenration)
      this.drawAppRate(paramesCall)
      this.initQaUserFinish(params)
      this.initAverageScore(paramsGenration)
    },
    // 刷新数据以及取消联动
    refreshData() {
      let params1 = {}
      let params2 = {}
      let params3 = {}
      let params4 = {}
      let params5 = {}
      let params6 = {}
      this.qaUsers = ''
      if (this.searchForm.generationTime.length == 0) {
        params1 = {
          startTime: this.initTime[0],
          endTime: this.initTime[1],
          qaUsers: '',
        }
      } else {
        params1 = {
          startTime: formatdate.formatDate(this.searchForm.generationTime[0]),
          endTime: formatdate.formatDate(this.searchForm.generationTime[1]),
          qaUsers: this.qaUsers,
        }
      }
      if (this.searchForm.findTimer.length == 0) {
        params2 = {
          callSTime_Min: this.initTime[0],
          callSTime_Max: this.initTime[1],
          qaUsers: this.qaUsers,
        }
      } else {
        params2 = {
          callSTime_Min: formatdate.formatDate(this.searchForm.findTimer[0]),
          callSTime_Max: formatdate.formatDate(this.searchForm.findTimer[1]),
          qaUsers: this.qaUsers,
        }
      }
      if (this.searchForm.beiShenSuLvTime.length == 0) {
        params3 = {
          callSTime_Min: this.initTime[0],
          callSTime_Max: this.initTime[1],
          qaUsers: this.qaUsers,
        }
      } else {
        params3 = {
          callSTime_Min: formatdate.formatDate(this.searchForm.beiShenSuLvTime[0]),
          callSTime_Max: formatdate.formatDate(this.searchForm.beiShenSuLvTime[1]),
          qaUsers: this.qaUsers,
        }
      }
      if (this.searchForm.compelteTime.length == 0) {
        params4 = {
          begin: this.initTime[0],
          end: this.initTime[1],
          qaUsers: this.qaUsers,
        }
      } else {
        params4 = {
          begin: formatdate.formatDate(this.searchForm.compelteTime[0]),
          end: formatdate.formatDate(this.searchForm.compelteTime[1]),
          qaUsers: this.qaUsers,
        }
      }
      if (this.searchForm.notCompelteTime.length == 0) {
        params5 = {
          begin: this.initTime[0],
          end: this.initTime[1],
          qaUsers: this.qaUsers,
        }
      } else {
        params5 = {
          begin: formatdate.formatDate(this.searchForm.notCompelteTime[0]),
          end: formatdate.formatDate(this.searchForm.notCompelteTime[1]),
          qaUsers: this.qaUsers,
        }
      }
      if (this.searchForm.avgTotalTime.length == 0) {
        params6 = {
          startTime: this.initTime[0],
          endTime: this.initTime[1],
          qaUser: this.qaUsers,
        }
      } else {
        params6 = {
          startTime: formatdate.formatDate(this.searchForm.avgTotalTime[0]),
          endTime: formatdate.formatDate(this.searchForm.avgTotalTime[1]),
          qaUser: this.qaUsers,
        }
      }
      this.initTotalData(params1)
      this.drawAppRate(params2)
      this.initQABeAppedRate(params3)
      this.initQaUserFinish(params4)
      this.initQaUserUnFinish(params5)
      this.initAverageScore(params6)
    },
    // 质检完成情况
    completionQualityInspection(lineObject, avgTime) {
      let itemStyle = {
        normal: {},
        emphasis: {
          barBorderWidth: 1,
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowOffsetY: 0,
          shadowColor: 'rgba(0,0,0,0.5)',
        },
      }
      let seriesY = []
      for (let i = 0; i < lineObject.Yarr.length; i++) {
        let list = lineObject.Yarr[i]
        for (let j = 0; j < list.length; j++) {
          let obj = {}
          let item = list[j]
          obj.name = item.qaUserName
          obj.finish = item.finish
          obj.avgTime = item.avgTime
          obj.qaUserNameNo = item.qaUserNameNo
          obj.totcalTime = item.totcalTime
          obj.unFinish = item.unFinish
          seriesY.push(obj)
        }
      }
      let dataY = new Map()
      let dataAvgTime = new Map()
      for (let d = 0; d < seriesY.length; d++) {
        let subItem = seriesY[d]
        // 取录音条数
        if (
          dataY.get(subItem.name + ',' + subItem.qaUserNameNo) == null ||
          dataY.get(subItem.name + ',' + subItem.qaUserNameNo) == undefined
        ) {
          dataY.set(subItem.name + ',' + subItem.qaUserNameNo, [subItem.finish])
        } else {
          let vauless = dataY.get(subItem.name + ',' + subItem.qaUserNameNo) || []
          // console.info(Array.isArray(vauless))
          vauless.push(subItem.finish)
          dataY.set(subItem.name + ',' + subItem.qaUserNameNo, vauless)
        }
        // 取每个质检员的平均时长
        if (
          dataAvgTime.get(subItem.name + ',' + subItem.qaUserNameNo) == null ||
          dataAvgTime.get(subItem.name + ',' + subItem.qaUserNameNo) == undefined
        ) {
          dataAvgTime.set(subItem.name + ',' + subItem.qaUserNameNo, [subItem.avgTime])
        } else {
          let vauless = dataAvgTime.get(subItem.name + ',' + subItem.qaUserNameNo) || []
          // console.info(Array.isArray(vauless))
          vauless.push(subItem.avgTime)
          dataAvgTime.set(subItem.name + ',' + subItem.qaUserNameNo, vauless)
        }
      }
      let seriesData = []
      let legendNames = []
      for (let k of dataY.keys()) {
        // console.info(k)
        let keys = k.split(',')
        legendNames.push(keys[0])
        seriesData.push({
          name: keys[0],
          type: 'bar',
          stack: 'one',
          itemStyle: itemStyle,
          data: dataY.get(k),
          id: keys[1],
          value: dataAvgTime.get(k),
          aadata: dataAvgTime.get(k),
        })
      }
      seriesData.push({
        name: '平均时长',
        type: 'line',
        yAxisIndex: 1,
        data: avgTime,
      })
      let _this = this
      let option = {
        color: colorList,
        title: {
          text: '质检完成情况',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        legend: {
          type: 'scroll',
          bottom: 0,
          data: legendNames,
        },
        dataZoom: [{ type: 'inside' }],
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow',
          },
          formatter: function(parames) {
            let dataCountHtml = ''
            let dataAvgTimeHtml = ''
            for (let i = 0; i < parames.length - 1; i++) {
              let item = parames[i]
              dataCountHtml += '<p>' + item.seriesName + '：' + item.data + '</p>'
              let tempAvgTime = dataAvgTime.get(item.seriesName + ',' + item.seriesId)[
                item.dataIndex
              ]
              let value = tempAvgTime / 60
              value = value.toFixed(2)
              dataAvgTimeHtml += '<p>' + item.seriesName + '：' + value + '分钟' + '</p>'
            }
            let res = ''
            res +=
              '<div style="font-size: 12px;">' +
              parames[0].name +
              '</div>' +
              '<div  style="font-size: 12px;margin:10px 0;">' +
              '<span style="display: inline-block;width:10px;height:10px;border-radius: 10px;background: #fff;margin-right: 5px;"></span>' +
              '评分录音数' +
              '</div>' +
              '<div style="font-size: 12px;">' +
              dataCountHtml +
              '</div>' +
              '<div style="font-size: 12px;margin:10px 0;">' +
              '<span style="display: inline-block;width:10px;height:10px;border-radius: 10px;background: #fff;margin-right: 5px;"></span>' +
              '平均录音时长' +
              '</div>' +
              '<div style="font-size: 12px;">' +
              dataAvgTimeHtml +
              '</div>'
            return res
          },
          position: function(pos, params, el, elRect, size) {
            let obj = { top: 10 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30
            return obj
          },
          extraCssText: 'width: 150px;',
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = option
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('completionQa')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow3 = true
              },
            },
          },
        },
        xAxis: [
          {
            data: lineObject.Xarr,
            splitLine: { show: false },
          },
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: { show: false },
            name: '评分录音数',
            min: 0,
            max: lineObject.Y1max,
            axisLabel: {
              formatter: '{value}',
            },
          },
          {
            type: 'value',
            name: '平均录音时长(min)',
            splitLine: { show: false },
            min: 0,
            max: lineObject.Y2max,
            axisLabel: {
              formatter: '{value}',
            },
          },
        ],
        grid: {
          left: 40,
          top: 80,
          bottom: 50,
          right: 50,
        },
        series: seriesData,
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.querySelector('#myChart'))
        myChart.clear()
        myChart.setOption(option)
        myChart.on('click', function(params) {
          _this.qaUsers = params.seriesId
          console.log(params)
          _this.handleSingleComputed(params.seriesName, params.seriesId)
        })
        // echart 右击事件，导出明细
        myChart.on('contextmenu', function(param) {
          let menu = document.getElementById('exportDec3')
          let event = param.event
          let pageX = event.offsetX
          let pageY = event.offsetY
          menu.style.left = pageX + 'px'
          menu.style.top = pageY + 'px'
          if (param.seriesType !== 'line') {
            menu.style.display = 'block'
          } // 点击折线图时不展示导出明细按钮
          let timearr = param.name.split('-')
          _this.exportDecParames = {
            month: timearr[0],
            day: timearr[1],
            qaUsers: param.seriesId,
          }
        })
      })
    },
    // 质检未完成情况
    notCompletionQualityInspection(UnFinishData) {
      let allArr = []
      let obj = {}
      let seriseArr = []
      UnFinishData.map(function(e, item) {
        obj[e.qaUserName] = e.unFinish
      })
      let builderJson = {
        charts: obj,
      }
      for (let i = 0; i < UnFinishData.length; i++) {
        let item = UnFinishData[i]
        allArr.push(item.unFinish)
        seriseArr.push({
          value: item.unFinish,
          id: item.qaUserNameNo,
        })
      }
      let all = Math.max.apply(null, allArr)
      let cha = all / 4 > 150 ? 150 : all / 4
      all += cha
      let itemStyle = {
        normal: {},
        emphasis: {
          barBorderWidth: 1,
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowOffsetY: 0,
          shadowColor: 'rgba(0,0,0,0.1)',
        },
      }
      let _this = this
      let option = {
        color: colorList,
        title: {
          text: '质检未完成情况',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
          formatter: function(parames) {
            let res = ''
            res += '<span>' + parames[0].name + ':' + parames[0].data.value + '</span>'
            return res
          },
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = option
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('notCompletionQa')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow4 = true
              },
            },
          },
        },
        grid: {
          left: 10,
          top: 80,
          bottom: 0,
          right: 0,
          containLabel: true,
        },
        xAxis: {
          type: 'value',
          max: all,
          splitLine: {
            show: false,
          },
          axisLabel: {
            inside: true,
            textStyle: {
              color: '#fff',
            },
          },
          axisTick: {
            show: false,
          },
          axisLine: {
            show: false,
          },
        },
        yAxis: {
          type: 'category',
          splitLine: { show: false },
          data: Object.keys(builderJson.charts),
        },
        series: [
          {
            type: 'bar',
            itemStyle: itemStyle,
            label: {
              normal: {
                position: 'right',
                show: true,
              },
            },
            data: seriseArr,
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.querySelector('#notCompelteChart'))
        myChart.clear()
        myChart.setOption(option)
        myChart.on('click', function(params) {
          _this.qaUsers = params.data.id
          _this.handleSingleNotComputed(params.name, params.data.id)
        })
        // echart 右击事件，导出明细
        myChart.getZr().on('contextmenu', function(param) {
          let pointInPixel = [param.offsetX, param.offsetY]
          if (myChart.containPixel('grid', pointInPixel)) {
            let xIndex = myChart.convertFromPixel({ seriesIndex: 0 }, [
              param.offsetX,
              param.offsetY,
            ])[1]
            let menu = document.getElementById('exportDec4')
            let event = param.event
            let pageX = event.offsetX
            let pageY = event.offsetY
            menu.style.left = pageX + 'px'
            menu.style.top = pageY + 'px'
            menu.style.display = 'block'
            _this.isTimeNull(_this.searchForm.notCompelteTime)
            _this.exportDecParames = {
              begin: formatdate.formatDate(_this.timeArr[0]),
              end: formatdate.formatDate(_this.timeArr[1]),
              // qaUser: param.data.id
              qaUser: seriseArr[xIndex].id,
            }
          }
        })
      })
    },
    // 平均评分偏差
    AverageScoreDeviation(lineObject) {
      let XArr = []
      let YArr = []
      let seriesLabel = {
        normal: {
          show: true,
          position: ['55%', 5],
        },
      }
      for (let i = 0; i < lineObject.length; i++) {
        let item = lineObject[i]
        XArr.push(item.qaUserName)
        YArr.push({
          value: item.averageScore,
          id: item.qaUser + '-' + item.appealFrequency,
          // name: item.appealFrequency + '次被申诉,' + '平均比主管评分',
          name: item.qaUserName,
          label: seriesLabel,
        })
      }
      let itemStyle = {
        normal: {},
        emphasis: {
          barBorderWidth: 1,
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowOffsetY: 0,
          shadowColor: 'rgba(0,0,0,0.1)',
        },
      }
      let _this = this
      let option = {
        color: ['#41D9C7', '#2FC25B'],
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
          formatter: function(parames) {
            let times = parames[0].data.id.split('-')[1]
            let res = ''
            let LH = parames[0].data.value >= 0 ? '高' : '低'
            let score =
              parames[0].data.value >= 0
                ? parames[0].data.value
                : parames[0].data.value.toString().slice(1)
            res +=
              '<span>' +
              parames[0].name +
              ':' +
              times +
              '次被申诉,' +
              '平均比主管评分' +
              LH +
              score +
              '</span>'
            return res
          },
          position: function(pos, params, el, elRect, size) {
            let obj = { top: 10 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30
            return obj
          },
        },
        title: {
          text: '平均评分偏差',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = option
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('averageScoreDeviation')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow5 = true
              },
            },
          },
        },
        grid: {
          top: 60,
          left: 40,
          right: 0,
          bottom: 0,
        },
        xAxis: {
          type: 'category',
          axisLine: { show: false },
          axisLabel: { show: false },
          axisTick: { show: false },
          splitLine: { show: false },
          data: XArr,
        },
        yAxis: {
          type: 'value',
          position: 'top',
          splitLine: { lineStyle: { type: 'dashed' } },
        },
        series: [
          {
            type: 'bar',
            stack: '总量',
            itemStyle: itemStyle,
            label: {
              normal: {
                show: true,
                // formatter: '{b}',
                formatter: function(x) {
                  return x.name
                },
                rotate: 270,
                color: '#1F2D3D',
                align: 'left',
                position: 'inside',
              },
            },
            data: YArr,
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(
          document.querySelector('#AverageScoreDeviation')
        )
        myChart.clear()
        myChart.setOption(option)
        myChart.on('click', function(params) {
          let id = params.data.id.split('-')[0]
          _this.qaUsers = params.data.id
          _this.handleSingleAvg(params.name, id)
        })
        // echart 右击事件，导出明细
        myChart.getZr().on('contextmenu', function(param) {
          let pointInPixel = [param.offsetX, param.offsetY]
          if (myChart.containPixel('grid', pointInPixel)) {
            let xIndex = myChart.convertFromPixel({ seriesIndex: 0 }, [
              param.offsetX,
              param.offsetY,
            ])[0]
            let menu = document.getElementById('exportDec5')
            let event = param.event
            let pageX = event.offsetX
            let pageY = event.offsetY
            menu.style.left = pageX + 'px'
            menu.style.top = pageY + 'px'
            menu.style.display = 'block'
            _this.isTimeNull(_this.searchForm.avgTotalTime)
            _this.exportDecParames = {
              startTime: formatdate.formatDate(_this.timeArr[0]),
              endTime: formatdate.formatDate(_this.timeArr[1]),
              qaUser: YArr[xIndex].id.split('-')[0],
            }
          }
        })
      })
    },
    // 质检申诉率
    drawAppRate(params) {
      let _this = this
      let appRateOption = {
        color: colorList,
        title: {
          text: '质检申诉率',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} ({d}%)',
        },
        legend: {
          orient: 'vertical',
          x: 'left',
          top: '15%',
          data: ['未申诉', '一次申诉', '二次申诉'],
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = appRateOption
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: {
              show: true,
              icon: 'image://static/img/downLoad.png',
              type: 'jpeg',
            },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('appRateOption')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow = true
              },
            },
          },
        },
        series: {
          name: '申诉率：',
          type: 'pie',
          radius: ['50%', '70%'],
          center: ['50%', '55%'],
          avoidLabelOverlap: false,
          label: {
            normal: {
              show: false,
              position: 'center',
            },
            emphasis: {
              show: false,
              textStyle: {
                fontSize: '30',
                fontWeight: 'bold',
              },
            },
          },
          labelLine: {
            normal: {
              show: false,
            },
          },
          data: [
            { value: 0, name: '未申诉' },
            { value: 0, name: '一次申诉' },
            { value: 0, name: '二次申诉' },
          ],
        },
      }
      this.axios
        .post(qualityUrl + '/appReport/getQAAppealRateData.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            let names = []
            for (let i = 0; i < res.data.Data.length; i++) {
              names[i] = res.data.Data[i].name
            }
            appRateOption.legend.data = names
            appRateOption.series.data = res.data.Data
            _this.drawEcharts('appRateQA', appRateOption)
          }
        })
    },
    // 选择质检员联动
    // 质检被申诉率点击某项，联动
    handleSingleBeiShenSuLv(row, data) {
      let dataArr = data
      let rowCount = row.currentTarget.parentNode.rowIndex
      let cellIndex = row.currentTarget.cellIndex
      let qaUserId = dataArr[rowCount].zjyNo
      if (cellIndex == 0) {
        this.qaUsers = qaUserId
        if (this.searchForm.notCompelteTime.length == 0) {
          this.searchForm.notCompelteTime = this.initTime
        }
        if (this.searchForm.compelteTime.length == 0) {
          this.searchForm.compelteTime = this.initTime
        }
        if (this.searchForm.avgTotalTime.length == 0) {
          this.searchForm.avgTotalTime = this.initTime
        }
        let params1 = {
          begin: formatdate.formatDate(this.searchForm.notCompelteTime[0]),
          end: formatdate.formatDate(this.searchForm.notCompelteTime[1]),
          qaUsers: this.qaUsers,
        }
        let params2 = {
          begin: formatdate.formatDate(this.searchForm.compelteTime[0]),
          end: formatdate.formatDate(this.searchForm.compelteTime[1]),
          qaUsers: this.qaUsers,
        }
        let params3 = {
          startTime: formatdate.formatDate(this.searchForm.avgTotalTime[0]),
          endTime: formatdate.formatDate(this.searchForm.avgTotalTime[1]),
          qaUser: this.qaUsers,
        }
        this.initQaUserUnFinish(params1)
        this.initQaUserFinish(params2)
        this.initAverageScore(params3)
      }
    },
    // 质检完成情况 单个点击联动
    handleSingleComputed(name, id) {
      this.qaUsers = id
      if (this.searchForm.notCompelteTime.length == 0) {
        this.searchForm.notCompelteTime = this.initTime
      }
      if (this.searchForm.beiShenSuLvTime.length == 0) {
        this.searchForm.beiShenSuLvTime = this.initTime
      }
      if (this.searchForm.avgTotalTime.length == 0) {
        this.searchForm.avgTotalTime = this.initTime
      }
      let params1 = {
        begin: formatdate.formatDate(this.searchForm.notCompelteTime[0]),
        end: formatdate.formatDate(this.searchForm.notCompelteTime[1]),
        qaUsers: this.qaUsers,
      }
      let params2 = {
        callSTime_Min: formatdate.formatDate(this.searchForm.beiShenSuLvTime[0]),
        callSTime_Max: formatdate.formatDate(this.searchForm.beiShenSuLvTime[1]),
        qaUsers: this.qaUsers,
      }
      let params3 = {
        startTime: formatdate.formatDate(this.searchForm.avgTotalTime[0]),
        endTime: formatdate.formatDate(this.searchForm.avgTotalTime[1]),
        qaUser: this.qaUsers,
      }
      this.initQaUserUnFinish(params1)
      this.initQABeAppedRate(params2)
      this.initAverageScore(params3)
    },
    // 质检味完成情况 单个点击联动
    handleSingleNotComputed(name, id) {
      this.qaUsers = id
      if (this.searchForm.compelteTime.length == 0) {
        this.searchForm.compelteTime = this.initTime
      }
      if (this.searchForm.beiShenSuLvTime.length == 0) {
        this.searchForm.beiShenSuLvTime = this.initTime
      }
      if (this.searchForm.avgTotalTime.length == 0) {
        this.searchForm.avgTotalTime = this.initTime
      }
      let params1 = {
        begin: formatdate.formatDate(this.searchForm.compelteTime[0]),
        end: formatdate.formatDate(this.searchForm.compelteTime[1]),
        qaUsers: this.qaUsers,
      }
      let params2 = {
        callSTime_Min: formatdate.formatDate(this.searchForm.beiShenSuLvTime[0]),
        callSTime_Max: formatdate.formatDate(this.searchForm.beiShenSuLvTime[1]),
        qaUsers: this.qaUsers,
      }
      let params3 = {
        startTime: formatdate.formatDate(this.searchForm.avgTotalTime[0]),
        endTime: formatdate.formatDate(this.searchForm.avgTotalTime[1]),
        qaUser: this.qaUsers,
      }
      this.initQaUserFinish(params1)
      this.initQABeAppedRate(params2)
      this.initAverageScore(params3)
    },
    // 平均评分偏差 单个联动
    handleSingleAvg(name, id) {
      this.qaUsers = id
      if (this.searchForm.compelteTime.length == 0) {
        this.searchForm.compelteTime = this.initTime
      }
      if (this.searchForm.beiShenSuLvTime.length == 0) {
        this.searchForm.beiShenSuLvTime = this.initTime
      }
      if (this.searchForm.notCompelteTime.length == 0) {
        this.searchForm.notCompelteTime = this.initTime
      }
      let params1 = {
        begin: formatdate.formatDate(this.searchForm.compelteTime[0]),
        end: formatdate.formatDate(this.searchForm.compelteTime[1]),
        qaUsers: this.qaUsers,
      }
      let params2 = {
        callSTime_Min: formatdate.formatDate(this.searchForm.beiShenSuLvTime[0]),
        callSTime_Max: formatdate.formatDate(this.searchForm.beiShenSuLvTime[1]),
        qaUsers: this.qaUsers,
      }
      let params3 = {
        begin: formatdate.formatDate(this.searchForm.notCompelteTime[0]),
        end: formatdate.formatDate(this.searchForm.notCompelteTime[1]),
        qaUsers: this.qaUsers,
      }
      this.initQaUserFinish(params1)
      this.initQABeAppedRate(params2)
      this.initQaUserUnFinish(params3)
    },
    // 质检被申诉率 放大
    handleToLarge(name) {
      let start = ''
      let end = ''
      let params = {}
      if (name == 'generation') {
        if (this.searchForm.generationTime.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = formatdate.formatDate(this.searchForm.generationTime[0])
          end = formatdate.formatDate(this.searchForm.generationTime[1])
        }
        params = {
          startTime: start,
          endTime: end,
          qaUsers: this.qaUsers,
        }
      } else if (name == 'beishensulv') {
        if (this.searchForm.beiShenSuLvTime.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = formatdate.formatDate(this.searchForm.beiShenSuLvTime[0])
          end = formatdate.formatDate(this.searchForm.beiShenSuLvTime[1])
        }
        params = {
          callSTime_Min: start,
          callSTime_Max: end,
        }
      }
      this.otherValue.name = name
      this.otherValue.option = params
      this.paryTasks = true
    },
    // 头部图标导出
    exportExcel(type) {
      let start = ''
      let end = ''
      let url = ''
      let params = {}
      if (type == 'appRateOption') {
        url = qualityUrl + '/appReport/exportQAAppealRateData.do'
        if (this.searchForm.findTimer.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.findTimer[0]
          end = this.searchForm.findTimer[1]
        }
        params = {
          callSTime_Min: formatdate.formatDate(start),
          callSTime_Max: formatdate.formatDate(end),
        }
      } else if (type == 'completionQa') {
        url = qualityUrl + '/reportForm/exportQaUserFinish.do'
        if (this.searchForm.compelteTime.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.compelteTime[0]
          end = this.searchForm.compelteTime[1]
        }
        params = {
          begin: formatdate.formatDate(start),
          end: formatdate.formatDate(end),
        }
      } else if (type == 'notCompletionQa') {
        url = qualityUrl + '/reportForm/exportQaUserUnFinish.do'
        if (this.searchForm.notCompelteTime.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.notCompelteTime[0]
          end = this.searchForm.notCompelteTime[1]
        }
        params = {
          begin: formatdate.formatDate(start),
          end: formatdate.formatDate(end),
        }
      } else if (type == 'averageScoreDeviation') {
        url = qualityUrl + '/averageScore/exportAverageScore.do'
        if (this.searchForm.avgTotalTime.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.avgTotalTime[0]
          end = this.searchForm.avgTotalTime[1]
        }
        params = {
          startTime: formatdate.formatDate(start),
          endTime: formatdate.formatDate(end),
        }
      } else if (type == 'exportQABeAppedRate') {
        url = qualityUrl + '/appReport/exportQABeAppedRate.do'
        if (this.searchForm.beiShenSuLvTime.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.beiShenSuLvTime[0]
          end = this.searchForm.beiShenSuLvTime[1]
        }
        params = {
          callSTime_Min: formatdate.formatDate(start),
          callSTime_Max: formatdate.formatDate(end),
          qaUsers: this.qaUsers,
        }
      } else if (type == 'generation') {
        url = qualityUrl + '/qualityReport/exportTotalData'
        if (this.searchForm.generationTime.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.generationTime[0]
          end = this.searchForm.generationTime[1]
        }
        params = {
          startTime: formatdate.formatDate(start),
          endTime: formatdate.formatDate(end),
        }
      }
      // this.axios.post(url, Qs.stringify(params), {responseType: 'arraybuffer'})
      //   .then(function (res) {
      //     if (res.data) {
      //       console.log(res.headers)
      //       let fileName = res.headers['Content-disposition'].match(/fushun(\S*)xls/)[0]
      //       fileDownload(res.data, fileName)
      //     }
      //   })
      commonUtil.doExport(url, params, global.jsonHeader)
    },
    // 导出明细
    exportPerDec(type, parames) {
      let url = ''
      if (type == '5') {
        url = qualityUrl + '/averageScore/exportAverageScoreDetail.do'
      }
      if (type == '4') {
        url = qualityUrl + '/reportForm/exportQaUserUnFinishDetail.do'
      }
      if (type == '3') {
        url = qualityUrl + '/reportForm/exportQaUserFinishDetail.do'
      }
      if (type == '2') {
        url = qualityUrl + '/appReport/exportQABeAppedDetail.do'
      }
      if (type == '1') {
        url = qualityUrl + '/appReport/exportQAAppealDetail.do'
      }
      if (type == '0') {
        url = qualityUrl + '/qualityReport/exportTotalDataDetail.do'
      }
      let params = parames
      commonUtil.doExport(url, params, global.jsonHeader)
    },
    // 被申诉率右键
    handleBeiShenSuExportDec(row, rowIndex) {
      let dataArr = rowIndex
      let rowCount = row.currentTarget.parentNode.rowIndex
      let cellIndex = row.currentTarget.cellIndex
      let qaUserId = dataArr[rowCount].zjyNo
      let qaUserName = dataArr[rowCount].zjyName
      let menu = document.getElementById('exportDec2')
      let pageX = 100
      let pageY = row.pageY - 180
      menu.style.left = pageX + 'px'
      menu.style.top = pageY + 'px'
      if (cellIndex == 1) {
        menu.style.display = 'block'
      } else {
        menu.style.display = 'none'
      }
      this.isTimeNull(this.searchForm.beiShenSuLvTime)
      this.exportDecParames = {
        callSTime_Min: formatdate.formatDate(this.timeArr[0]),
        callSTime_Max: formatdate.formatDate(this.timeArr[1]),
        qaUserNo: qaUserId,
        qaUserName: qaUserName,
      }
    },
    // 概览右键
    handleGenerationExportDec(row, rowIndex) {
      let queryType = ''
      let dataArr = rowIndex
      let rowCount = row.currentTarget.parentNode.rowIndex
      let cellIndex = row.currentTarget.cellIndex
      let qaUserName = dataArr[rowCount].qaUserNameNo
      if (cellIndex == 2) {
        queryType = '1'
      } else if (cellIndex == 3) {
        queryType = '2'
      } else if (cellIndex == 4) {
        queryType = '3'
      }

      let menu = document.getElementById('exportDec')
      let pageX = row.pageX - 300
      let pageY = row.pageY - 170
      menu.style.left = pageX + 'px'
      menu.style.top = pageY + 'px'
      if (cellIndex != 0 && cellIndex != 1) {
        menu.style.display = 'block'
      } else {
        menu.style.display = 'none'
      }
      this.isTimeNull(this.searchForm.generationTime)
      this.exportDecParames = {
        startTime: formatdate.formatDate(this.timeArr[0]),
        endTime: formatdate.formatDate(this.timeArr[1]),
        queryType: queryType,
        qaUserName: qaUserName,
      }
    },
    // 判断模块时间是否为空
    isTimeNull(time) {
      if (time.length == 0) {
        this.timeArr = this.initTime
      } else {
        this.timeArr = time
      }
    },
    drawEcharts(id, option) {
      document.getElementById(id).setAttribute('_echarts_instance_', '')
      let myChart = this.$echarts.init(document.getElementById(id))
      myChart.setOption(option)
      // echart 右击事件，导出明细
      let _this = this
      if (id == 'appRateQA') {
        myChart.on('contextmenu', function(param) {
          let menu = document.getElementById('exportDec1')
          let event = param.event
          let pageX = event.offsetX
          let pageY = event.offsetY
          menu.style.left = pageX + 'px'
          menu.style.top = pageY + 'px'
          if (param.data.apType !== 0) {
            menu.style.display = 'block'
          }
          _this.isTimeNull(_this.searchForm.findTimer)
          _this.exportDecParames = {
            apType: param.data.apType,
            callSTime_Min: formatdate.formatDate(_this.timeArr[0]),
            callSTime_Max: formatdate.formatDate(_this.timeArr[1]),
          }
          console.log(_this.exportDecParames)
        })
      }
    },
  },
  mounted: function() {},
  created() {
    this.initChartData()
  },
}
</script>
<style lang="less">
.QualityInspectionReport {
  position: relative;
  th {
    background-color: #e0e6ed;
    color: #475669;
    padding: 10px 0;
  }
  #exportDec,
  #exportDec1,
  #exportDec2,
  #exportDec3,
  #exportDec4,
  #exportDec5 {
    width: 100px;
    height: 40px;
    background-color: rgba(0, 0, 0, 0.5);
    position: absolute;
    text-align: center;
    .el-button.btn {
      color: #fff;
    }
  }
  .echartWrap {
    div {
      overflow-x: auto !important;
    }
  }
}

.el-popover.el-popper.popperHover {
  border: none;
  background: none;
  box-shadow: none;
  color: #3b90bf;
  font-size: 12px;
  top: 135px !important;
  padding: 0;
  margin: 0;
  min-width: 50px;
  text-align: center;
  &.popperBeishensulv {
    text-align: right;
    margin-right: 13px;
  }
}
</style>
<style lang="less" scoped>
.QualityInspectionReport {
  width: 100%;
  height: 100%;
  background: #fff;
  padding: 0 18px;
  box-sizing: border-box;
  .header {
    height: 50px;
    display: flex;
    flex-direction: row-reverse;
    align-items: center;
    .icon {
      font-size: 30px;
      cursor: pointer;
    }
  }
  .content {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: calc(~'100% - 50px');
    .content-line {
      display: flex;
      flex: 1;
      flex-direction: row;
      flex-wrap: nowrap;
      justify-content: space-between;
      margin-bottom: 10px;
      .item {
        display: flex;
        flex-direction: column;
        padding: 0 10px 10px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        overflow: auto;
        position: relative;
        .toolBar {
          display: flex;
          height: 30px;
          flex-direction: row;
          align-items: center;
          .title {
            flex: 1;
          }
          .icon {
            width: 18px;
            height: 18px;
            cursor: pointer;
            margin-left: 5px;
          }
        }
        &.item1 {
          flex: 4;
          .toolBar {
            flex-direction: row-reverse;
          }
          .qaReport-dec {
            display: flex;
            flex-direction: row;
            height: 100px;
            .dec-item {
              display: flex;
              flex-direction: column;
              flex: 1;
              height: 100%;
              margin-right: 20px;
              &.dec-item-last {
                margin: 0;
              }
              .dec-item-top {
                height: 50%;
                flex: 1;
                display: flex;
                flex-direction: row;
              }
              .dec-item-bottom {
                height: 50%;
                flex: 1;
                display: flex;
                flex-direction: row;
                .bottomCount {
                  font-size: 22px;
                }
                .right-count {
                  flex: 1;
                  margin: 0 0 22px 12px;
                }
              }
            }
          }
          .qaReport-table {
            flex: 1;
            overflow: auto;
          }
        }
        &.item2 {
          margin: 0 10px;
          flex: 3;
          .echartWrap {
            display: flex;
            flex: 1;
            justify-content: center;
            align-items: center;
            overflow: auto;
          }
        }
        &.item3 {
          flex: 3;
          .shensu-table {
            flex: 1;
            overflow: auto;
          }
        }
        &.item4 {
          flex: 5;
          .echartWrap {
            display: flex;
            flex: 1;
            justify-content: center;
            align-items: center;
            overflow: auto;
          }
        }
        &.item5 {
          flex: 2;
          margin: 0 10px;
          .echartWrap {
            display: flex;
            flex: 1;
            justify-content: center;
            align-items: center;
            overflow: auto;
          }
        }
        &.item6 {
          flex: 3;
          .echartWrap {
            display: flex;
            flex: 1;
            justify-content: center;
            align-items: center;
            overflow: auto;
          }
        }
      }
    }
  }
}

.tableDealog {
  width: 98%;
  height: 240px;
  border: 1px solid #d1d9e2;
  border-radius: 4px;
  position: absolute;
  left: 1%;
  top: 2%;
  background: #fff;
  z-index: 1999;
  .aloneTitle {
    height: 45px;
    font-size: 14px;
    line-height: 45px;
    width: 100%;
    border-bottom: 1px solid #d1d9e2;
  }
  .aloneFooter {
    text-align: right;
    height: 45px;
    margin-top: 20px;
    padding-top: 5px;
    border-top: 1px solid #d1d9e2;
    line-height: 45px;
  }
}
</style>
