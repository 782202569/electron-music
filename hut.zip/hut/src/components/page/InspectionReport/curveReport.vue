<template>
  <div class="curveReportBox">
    <div class="curveReport">
      <div id="dataItem" class="item" style="height: 100%; width: auto;">
        <div id="data" style="height: 100%; width: 100%;"></div>
      </div>
      <div id="hotWordItem" class="item" style="height: 100%;width: auto;">
        <div id="hotWord" style="height: 100%; width: 100%;"></div>
        <div
          id="exportTitle2"
          style="display: none"
          onMouseLeave="this.style.display = 'none';"
        >
          <el-button
            @click="exportHotWordData(exportBussessParames)"
            type="text"
            class="btn"
            >导出明细</el-button
          >
        </div>
      </div>
      <div id="businessItem" class="item" style="z-index:99;height: 100%;width: auto;">
        <div id="business" style="height: 100%; width: 100%;"></div>
        <div
          id="exportTitle1"
          style="display: none"
          onMouseLeave="this.style.display = 'none';"
        >
          <el-button @click="exportBussessData()" type="text" class="btn"
            >导出明细</el-button
          >
        </div>
      </div>
    </div>
    <div id="bigShow" @click="smallShow">
      <img src="../../../assets/img/narrow.png" />
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
let currentBaseUrl = global.currentBaseUrl
import global from '../../../global.js'
import lineEchartTool from '../../../utils/lineEchartsTool.js' // 数据入库和趋势图的配置
import graphEchartTool from '../../../utils/graphEchartsTool.js' // 热词相关配置
let dataCharts
let businessCharts
let hotWordCharts
export default {
  props: {
    clickName: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    urlOther: {
      type: Boolean,
      required: true,
    },
    treeId: {
      type: String,
      required: true,
    },
    isData: {
      type: Boolean,
      required: true,
    },
    times: {
      type: Array,
      required: true,
    },
    isBigShow: {
      type: Boolean,
      required: true,
    },
    showItemName: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      bigValue: '',
      exportBussessParames: {},
      showData: true,
      showHotWord: true,
      showBusiness: true,
    }
  },
  computed: {
    /* loadData() {
      // console.log(this.times)
      if (this.treeId !== '' || this.treeId !== undefined || this.treeId !== null) {
        this.initialize()
      }
    }, */
    address() {
      const {
        clickName,
        title,
        urlOther,
        treeId,
        isData,
        times,
        isBigShow,
        showItemName,
      } = this
      return {
        clickName,
        title,
        urlOther,
        treeId,
        isData,
        times,
        isBigShow,
        showItemName,
      }
    },
  },
  watch: {
    // loadData(val, oldval) {},
    address: {
      handler: function(newval, oldval) {
        if (this.treeId !== '' || this.treeId !== undefined || this.treeId !== null) {
          this.initialize()
        }
      },
      deep: true,
    },
  },
  methods: {
    /*
     * 将视图还原
     * 需要销毁之前实例，在创建。
     * */
    smallShow() {
      $('#dataItem').show()
      $('#hotWordItem').show()
      $('#businessItem').show()
      this.$emit('bigViewShow', 'small')
      if (this.bigValue === 'dataItem') {
        dataCharts = this.$echarts.init(document.getElementById('data'))
        dataCharts.setOption({
          toolbox: {
            show: true,
          },
        })
        dataCharts.resize()
      } else if (this.bigValue === 'hotWordItem') {
        hotWordCharts = this.$echarts.init(document.getElementById('hotWord'))
        hotWordCharts.on('contextmenu', function() {
          let menu = document.getElementById('exportTitle2')
          menu.style.display = 'block'
        })
        hotWordCharts.setOption({
          toolbox: {
            show: true,
          },
        })
        hotWordCharts.resize()
      } else {
        businessCharts = this.$echarts.init(document.getElementById('business'))
        businessCharts.on('contextmenu', function() {
          let menu = document.getElementById('exportTitle1')
          menu.style.display = 'block'
        })
        businessCharts.setOption({
          toolbox: {
            show: true,
          },
        })
        businessCharts.resize()
      }
      document.getElementById('bigShow').style.display = 'none'
    },
    bigShow(item) {
      this.bigValue = item
      document.getElementById('bigShow').style.display = 'block'
      if (item === 'dataItem') {
        this.$emit('bigViewShow', 'dataItem')
        $('#hotWordItem').hide()
        $('#businessItem').hide()
        $('#dataItem').show()
        dataCharts = this.$echarts.init(document.getElementById('data'))
        dataCharts.setOption({
          toolbox: {
            show: false,
          },
        })
        dataCharts.resize()
      } else if (item === 'hotWordItem') {
        this.$emit('bigViewShow', 'hotWordItem')
        $('#dataItem').hide()
        $('#hotWordItem').show()
        $('#businessItem').hide()
        hotWordCharts = this.$echarts.init(document.getElementById('hotWord'))
        hotWordCharts.on('contextmenu', function() {
          let menu = document.getElementById('exportTitle2')
          menu.style.display = 'none'
        })
        hotWordCharts.setOption({
          toolbox: {
            show: false,
          },
        })
        hotWordCharts.resize()
      } else {
        this.$emit('bigViewShow', 'businessItem')
        $('#dataItem').hide()
        $('#hotWordItem').hide()
        $('#businessItem').show()
        businessCharts = this.$echarts.init(document.getElementById('business'))
        businessCharts.on('contextmenu', function() {
          let menu = document.getElementById('exportTitle1')
          menu.style.display = 'none'
        })
        businessCharts.setOption({
          toolbox: {
            show: false,
          },
        })
        businessCharts.resize()
      }
    },
    getHotWordView() {
      let that = this
      if (this.treeId === '') {
      } else {
        hotWordCharts = that.$echarts.init(document.getElementById('hotWord'))
        // hotWordCharts.resize()
        hotWordCharts.clear()
        let minDate = JSON.stringify(
          new Date(this.times[0].replace(new RegExp('-', 'gm'), '/')).getTime()
        ) // 年月日时分秒时间格式转换成lang类型时间戳
        let maxDate = JSON.stringify(
          new Date(this.times[1].replace(new RegExp('-', 'gm'), '/')).getTime()
        ) // 年月日时分秒时间格式转换成lang类型时间戳
        let params
        params = {
          sortID: that.treeId,
          callSTimeMin: minDate,
          callSTimeMax: maxDate,
          other: that.urlOther,
        }
        let url = currentBaseUrl + '/report/categoryWord/'
        this.axios
          .get(url, { params })
          .then((res) => {
            if (res.data.data) {
              let hotdata = res.data.data
              // 数据集合重构
              let dataTest = []
              // 类目集合重构
              let categoriesTest = []
              // 连接集合重构
              let linksTest = []
              // 去除重复临时字符串
              let strTest = ''
              for (let i = 0; i < hotdata.length; i++) {
                categoriesTest[i] = { name: hotdata[i].word }
                if (strTest.indexOf(hotdata[i].word) == -1) {
                  strTest += hotdata[i].word + ','
                  dataTest.push({
                    name: hotdata[i].word,
                    draggable: true,
                    // symbolSize: hotdata[i].times / 100,
                    symbolSize: [100, 100],
                    value: hotdata[i].times,
                    category: hotdata[i].word,
                    label: {
                      // 关系对象上的标签
                      normal: {
                        show: true,
                        position: 'inside',
                        textStyle: {
                          fontSize: 16,
                        },
                      },
                    },
                  })
                }
                for (let j = 0; j < hotdata[i].relateWords.length; j++) {
                  if (strTest.indexOf(hotdata[i].relateWords[j].name) == -1) {
                    strTest += hotdata[i].relateWords[j].name + ','
                    dataTest.push({
                      name: hotdata[i].relateWords[j].name,
                      draggable: true,
                      value: hotdata[i].relateWords[j].times,
                      // symbolSize: [50, 50],
                      symbolSize: hotdata[i].relateWords[j].score * 100,
                      category: hotdata[i].word,
                      label: {
                        // 关系对象上的标签
                        normal: {
                          show: false,
                          position: 'inside',
                          textStyle: {
                            fontSize: 16,
                          },
                        },
                      },
                    })
                  }
                  linksTest.push({
                    // 节点间的关系数据
                    target: hotdata[i].relateWords[j].name,
                    // symbolSize: hotdata[i].relateWords[j].score,
                    // times: hotdata[i].relateWords[j].times,
                    value: hotdata[i].relateWords[j].score,
                    source: hotdata[i].word,
                    category: hotdata[i].word, // 关系对象连接线上的标签内容
                  })
                }
              }
              let hotWordLine = graphEchartTool
              if (this.clickName !== '') {
                hotWordLine.title.text = '热词相关' + '(' + this.clickName + ')'
              } else {
                hotWordLine.title.text = '热词相关 （全部录音）'
              }
              hotWordLine.series[0].data = dataTest
              hotWordLine.series[0].links = linksTest
              hotWordLine.series[0].categories = categoriesTest
              hotWordLine.tooltip = {
                trigger: 'item',
                formatter: function(data) {
                  let dataV
                  let str
                  if (data.data.value < 1) {
                    dataV = data.data.value.toFixed(2)
                  } else {
                    dataV = data.data.value
                  }
                  if (data.dataType == 'edge') {
                    // dataV = data.data.times
                    str = data.data.category + '-' + data.data.target + ':' + dataV
                  } else {
                    str = data.name + ':' + dataV
                  }
                  return str
                },
              }
              hotWordLine.toolbox = {
                feature: {
                  myTool1: {
                    show: true,
                    title: '放大热词图',
                    icon: 'image://static/img/enLarge.png',
                    onclick: () => {
                      this.bigShow('hotWordItem')
                    },
                  },
                  saveAsImage: {
                    icon: 'image://static/img/downLoad.png',
                  },
                  myTool2: {
                    show: true,
                    title: '导出',
                    icon: 'image://static/img/excelReport.png',
                    onclick: () => {
                      this.exportData('hotWord')
                    },
                  },
                },
              }
              hotWordCharts.setOption(hotWordLine)
              hotWordCharts.on('contextmenu', function(param) {
                let menu = document.getElementById('exportTitle2')
                let event = param.event
                let pageX = event.offsetX
                let pageY = event.offsetY
                menu.style.left = pageX + 'px'
                menu.style.top = pageY + 'px'
                menu.style.display = 'block'
                that.exportBussessParames = {
                  title: param.name,
                }
                console.log('右击事件')
                console.log(that.exportBussessParames)
              })
            } else {
              hotWordCharts.dispose()
            }
          })
          .catch(() => {})
      }
    },
    getDataView() {
      dataCharts = this.$echarts.init(document.getElementById('data'))
      // dataCharts.resize()
      dataCharts.clear()
      let sDate = this.times[0]
      let eDate = this.times[1]
      let params = {
        startDate: sDate,
        endDate: eDate,
      }
      this.axios
        .get(currentBaseUrl + '/report/dataImport/list/', { params })
        .then((res) => {
          if (res.data.date.length > 0 && res.data.count.length > 0) {
            let xData = res.data.date
            let yData = res.data.count
            let dataLine = JSON.parse(JSON.stringify(lineEchartTool))
            dataLine.title.text = '数据入库'
            dataLine.xAxis = {
              type: 'category',
              boundaryGap: true,
              data: xData,
            }
            dataLine.series = [
              {
                data: yData,
                type: 'line',
                areaStyle: {},
              },
            ]
            dataLine.toolbox = {
              feature: {
                myTool1: {
                  show: true,
                  title: '放大数据入库图',
                  icon: 'image://static/img/enLarge.png',
                  onclick: () => {
                    this.bigShow('dataItem')
                  },
                },
                saveAsImage: {
                  icon: 'image://static/img/downLoad.png',
                },
                myTool2: {
                  show: true,
                  title: '导出',
                  icon: 'image://static/img/excelReport.png',
                  onclick: () => {
                    this.exportData('dataItem')
                  },
                },
              },
            }
            dataLine.tooltip = {
              trigger: 'item',
              formatter: function(data) {
                let str = ''
                str = data.name + '<br/>' + '共' + data.value + '条录音'
                return str
              },
            }
            dataCharts.setOption(dataLine)
          } else {
            dataCharts.dispose()
          }
        })
        .catch(() => {})
    },
    getAddNums(data) {
      let oneNum = 0
      for (let u = 0; u < data.length; u++) {
        oneNum += data[u]
      }
      return oneNum
    },
    getBusinessView() {
      let that = this
      if (this.treeId === '') {
      } else {
        businessCharts = that.$echarts.init(document.getElementById('business'))
        // businessCharts.resize()
        let minDate = JSON.stringify(
          new Date(this.times[0].replace(new RegExp('-', 'gm'), '/')).getTime()
        ) // 年月日时分秒时间格式转换成lang类型时间戳
        let maxDate = JSON.stringify(
          new Date(this.times[1].replace(new RegExp('-', 'gm'), '/')).getTime()
        ) // 年月日时分秒时间格式转换成lang类型时间戳
        let params
        params = {
          sortID: that.treeId,
          callSTimeMin: minDate,
          callSTimeMax: maxDate,
          other: that.urlOther,
        }
        let url = currentBaseUrl + '/report/trend/'
        this.axios
          .get(url, { params })
          .then((res) => {
            if (res.data.data.dates.length > 0) {
              let seriesData = []
              seriesData = res.data.data.data
              // let temp = []
              let temp2 = []
              /* for (let i in seriesData) {
                temp.push(i)
              } */
              for (let p in seriesData) {
                if (seriesData[p].length === 0) {
                  temp2.push([0])
                } else {
                  temp2.push(JSON.parse(JSON.stringify(seriesData[p].data)))
                }
              }
              let sDataNew = []
              for (let q = 0; q < seriesData.length; q++) {
                if (this.getAddNums(temp2[q]) == 0) {
                  continue
                } else {
                  sDataNew[q] = {
                    name: seriesData[q].sortName,
                    id: seriesData[q].sortID == null ? this.treeId : seriesData[q].sortID,
                    type: 'line',
                    data: temp2[q],
                  }
                }
              }
              businessCharts.clear()
              let xAxisData = []
              let xdata = res.data.data.dates
              for (let t = 0; t < xdata.length; t++) {
                xAxisData.push(xdata[t].replace(/\//g, '-'))
              }
              let businessLine = lineEchartTool
              // businessLine.legend.data = temp
              businessLine.tooltip = {
                trigger: 'axis',
              }
              businessLine.toolbox = {
                feature: {
                  myTool1: {
                    show: true,
                    title: '放大趋势分析图',
                    icon: 'image://static/img/enLarge.png',
                    onclick: () => {
                      this.bigShow('businessItem')
                    },
                  },
                  saveAsImage: {
                    icon: 'image://static/img/downLoad.png',
                  },
                  myTool2: {
                    show: true,
                    title: '导出',
                    icon: 'image://static/img/excelReport.png',
                    onclick: () => {
                      this.exportData('business')
                    },
                  },
                },
              }
              businessLine.xAxis = {
                type: 'category',
                boundaryGap: true,
                data: xAxisData,
              }

              businessLine.series = sDataNew
              businessLine.title.text = '各业务趋势分析'
              businessCharts.setOption(businessLine)
              // 业务趋势右键
              let that = this
              businessCharts.on('contextmenu', function(param) {
                console.log(param)
                let menu = document.getElementById('exportTitle1')
                let event = param.event
                let pageX = event.offsetX
                let pageY = event.offsetY
                menu.style.left = pageX + 'px'
                menu.style.top = pageY + 'px'
                menu.style.display = 'block'
                that.exportBussessParames = {
                  seriesName: param.seriesName,
                  title: param.name,
                  sortId: param.seriesId,
                }
                console.log('右击事件')
                console.log(that.exportBussessParames)
              })
            } else {
              businessCharts.dispose()
            }
          })
          .catch(() => {})
      }
    },
    /*
     * 初始化数据
     * 三个echarts展示图
     * 数据导入、热词相关、业务趋势分析
     * */
    initialize() {
      let that = this
      that.$nextTick(() => {
        // 业务趋势图
        that.getBusinessView()
        // 热词图
        that.getHotWordView()
        // 数据入库图
        if (that.isData === true) {
          that.getDataView()
        }
        document.oncontextmenu = function() {
          return false
        } // 禁止默认的右击事件
      })
    },
    /*
     * 数据导出
     * 数据导入、热词相关、业务趋势分析三个趋势图的导出数据
     * */
    exportData(typeData) {
      let that = this
      let minDate = JSON.stringify(
        new Date(this.times[0].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let maxDate = JSON.stringify(
        new Date(this.times[1].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      if (typeData === 'dataItem') {
        console.log('数据导入')
        let sDate = this.times[0]
        let eDate = this.times[1]
        window.location.href =
          currentBaseUrl +
          '/report/dataImport/export?startDate=' +
          sDate +
          '&endDate=' +
          eDate +
          '&accessToken=' +
          this.$store.state.token
      } else if (typeData === 'hotWord') {
        let url = ''
        this.clickName.indexOf('其他') != '-1'
          ? (url = '/report/categoryWord/excel/other/?sortID=')
          : (url = '/report/categoryWord/excel/?sortID=')
        window.location.href =
          currentBaseUrl +
          url +
          this.treeId +
          '&callSTimeMin=' +
          minDate +
          '&callSTimeMax=' +
          maxDate +
          '&accessToken=' +
          this.$store.state.token
        console.log('热词')
      } else {
        window.location.href =
          currentBaseUrl +
          '/report/trend/excel/?sortID=' +
          this.treeId +
          '&callSTimeMin=' +
          minDate +
          '&other=' +
          that.urlOther +
          '&callSTimeMax=' +
          maxDate +
          '&accessToken=' +
          this.$store.state.token
        console.log('业务趋势分析')
      }
    },
    /*
     * 导出热词相关某一个节点的数据
     * */
    exportHotWordData() {
      let title = this.exportBussessParames.title
      console.log(title)
      let minDate = JSON.stringify(
        new Date(this.times[0].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let maxDate = JSON.stringify(
        new Date(this.times[1].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let url = ''
      this.clickName.indexOf('其他') != '-1'
        ? (url = '/report/categoryWord/records/excel/other/?word=')
        : (url = '/report/categoryWord/records/excel/?word=')
      window.location.href =
        currentBaseUrl +
        url +
        title +
        '&sortID=' +
        this.treeId +
        '&callSTimeMin=' +
        minDate +
        '&callSTimeMax=' +
        maxDate +
        '&accessToken=' +
        this.$store.state.token
    },
    /*
     * 导出业务趋势某一个节点的数据
     * */
    exportBussessData() {
      let sortid = this.exportBussessParames.sortId
      let title = this.exportBussessParames.seriesName
      let times = this.exportBussessParames.title + ' ' + '00:00:00'
      let times2 = this.exportBussessParames.title + ' ' + '23:59:59'
      let minDate = JSON.stringify(
        new Date(times.replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let maxDate = JSON.stringify(
        new Date(times2.replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let url
      if (title === '其他') {
        url =
          currentBaseUrl +
          '/recordSort/' +
          sortid +
          '/records/excel/other/?' +
          'callSTimeMin=' +
          minDate +
          '&callSTimeMax=' +
          maxDate +
          '&accessToken=' +
          this.$store.state.token
      } else {
        url =
          currentBaseUrl +
          '/recordSort/' +
          sortid +
          '/records/excel/?' +
          'callSTimeMin=' +
          minDate +
          '&callSTimeMax=' +
          maxDate +
          '&accessToken=' +
          this.$store.state.token
      }
      window.location.href = url
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.curveReportBox {
  height: 100%;
  #bigShow {
    cursor: pointer;
    position: absolute;
    top: 10px;
    right: 20px;
    display: none;
    img {
      font-size: 26px;
      width: 20px;
      height: 20px;
      margin: 20px;
    }
  }
  #exportTitle1,
  #exportTitle2 {
    width: 100px;
    height: 40px;
    background-color: rgba(0, 0, 0, 0.5);
    position: absolute;
    text-align: center;
    .el-button.btn {
      color: #fff;
    }
  }
  .curveReport {
    display: flex;
    display: -webkit-flex; /* Safari */
    flex-direction: column;
    flex-wrap: wrap;
    flex: 1;
    width: 100%;
    height: 100%;
    .item {
      display: flex;
      flex: 10;
      flex-direction: column;
      margin: 0 10px 10px;
      box-sizing: border-box;
      border: 1px solid #ccc;
      overflow: auto;
      position: relative;
    }
  }
}
</style>
