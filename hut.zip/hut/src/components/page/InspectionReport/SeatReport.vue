<template>
  <div style="height: 100%;">
    <div class="SeatReport" v-show="!paryTasks">
      <div class="header">
        <i @click="refreshData" class="el-icon-refresh icon"></i>
      </div>
      <div class="content">
        <div class="content-line">
          <div class="item item1">
            <div class="echartWrap" id="callTimeChart"></div>
            <!-- 来电时段统计 —— （录音时间） -->
            <div class="tableDealog" v-show="sustomShow1">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">录音时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange1" @change="changeValue1">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.oneTimer"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour1"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('oneTimer')"
                  >确 定</el-button
                >
              </div>
            </div>
            <!-- 导出 -->
            <div
              id="exportDec1"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('1', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
          <div class="item item2">
            <div class="echartWrap" id="scoreResult"></div>
            <!--成绩统计 —— （录音时间 评分模版 组织） -->
            <div class="tableDealog" v-show="sustomShow2">
              <el-tabs v-model="activeName2">
                <el-tab-pane label="录音时间" name="first">
                  <div style="margin: 10px;">
                    <el-radio-group v-model="timeChange2" @change="changeValue2">
                      <el-radio :label="1">本日</el-radio>
                      <el-radio :label="2">本周</el-radio>
                      <el-radio :label="3">本月</el-radio>
                      <br />
                      <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                    </el-radio-group>
                  </div>
                  <el-date-picker
                    v-model="searchForm.twoTimer"
                    type="datetimerange"
                    :editable="false"
                    :clearable="false"
                    :disabled="abledFour2"
                    align="right"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    :default-time="['00:00:00', '23:59:59']"
                    style="width: 80%;margin: 10px;"
                  >
                  </el-date-picker>
                  <div class="aloneFooter aloneFooterS">
                    <el-button @click="cancelNot">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="sure('twoTimer')"
                      >确 定</el-button
                    >
                  </div>
                </el-tab-pane>
                <el-tab-pane label="评分模版" name="second">
                  <div style="margin:10px;">
                    <span style="margin-right:10px;font-size:14px;">评分模版</span>
                    <el-select v-model="templateModel2">
                      <el-option
                        v-for="item in templateModels"
                        :label="item.modleTitle"
                        :key="item.modleId"
                        :value="item.modleId"
                      >
                      </el-option>
                    </el-select>
                  </div>
                  <div class="aloneFooter">
                    <el-button @click="cancelNot">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="sureTemplate(templateModel2, 2)"
                      >确 定
                    </el-button>
                  </div>
                </el-tab-pane>
                <el-tab-pane label="组织" name="third">
                  <div style="margin:10px;font-size:14px;">
                    <span style="margin-right:10px;">人员范围</span>
                    <el-cascader
                      change-on-select
                      :options="ogzationOptions"
                      :props="ogzationProps"
                      v-model="selectedOgzation2"
                      expand-trigger="click"
                    ></el-cascader>
                  </div>
                  <div class="aloneFooter">
                    <el-button @click="cancelNot">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="sureDept(selectedOgzation2, 2)"
                      >确 定
                    </el-button>
                  </div>
                </el-tab-pane>
              </el-tabs>
            </div>
            <div
              id="exportDec2"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('2', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
          <div class="item item3">
            <div class="echartWrap" id="errorRateRadarMap"></div>
            <!--错误率雷达图 —— （录音时间 评分模版 组织） -->
            <div class="tableDealog tableDealog3" v-show="sustomShow3">
              <el-tabs v-model="activeName3">
                <el-tab-pane label="录音时间" name="first">
                  <div style="margin: 10px;">
                    <el-radio-group v-model="timeChange3" @change="changeValue3">
                      <el-radio :label="1">本日</el-radio>
                      <el-radio :label="2">本周</el-radio>
                      <el-radio :label="3">本月</el-radio>
                      <br />
                      <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                    </el-radio-group>
                  </div>
                  <el-date-picker
                    v-model="searchForm.threeTimer"
                    type="datetimerange"
                    :editable="false"
                    :clearable="false"
                    :disabled="abledFour3"
                    align="right"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    :default-time="['00:00:00', '23:59:59']"
                    style="width: 80%;margin: 10px;"
                  >
                  </el-date-picker>
                  <div class="aloneFooter aloneFooterS">
                    <el-button @click="cancelNot">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="sure('threeTimer')"
                      >确 定</el-button
                    >
                  </div>
                </el-tab-pane>
                <el-tab-pane label="评分模版" name="second">
                  <div style="margin:10px;">
                    <span style="margin-right:10px;font-size:14px;">评分模版</span>
                    <el-select v-model="templateModel3">
                      <el-option
                        v-for="item in templateModels"
                        :label="item.modleTitle"
                        :key="item.modleId"
                        :value="item.modleId"
                      >
                      </el-option>
                    </el-select>
                  </div>
                  <div class="aloneFooter">
                    <el-button @click="cancelNot">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="sureTemplate(templateModel3, 3)"
                      >确 定
                    </el-button>
                  </div>
                </el-tab-pane>
                <el-tab-pane label="组织" name="third">
                  <div style="margin:10px">
                    <span style="margin-right:10px;font-size:14px;">人员范围</span>
                    <el-cascader
                      change-on-select
                      :options="ogzationOptions"
                      :props="ogzationProps"
                      v-model="selectedOgzation3"
                      expand-trigger="click"
                    ></el-cascader>
                  </div>
                  <div class="aloneFooter">
                    <el-button @click="cancelNot">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="sureDept(selectedOgzation3, 3)"
                      >确 定
                    </el-button>
                  </div>
                </el-tab-pane>
              </el-tabs>
            </div>
            <div
              id="exportDec3"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('3', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
        </div>
        <div class="content-line">
          <div class="item item4">
            <div class="echartWrap" id="sourceOfDeath"></div>
            <!--致命项来源占比 —— （录音时间 评分模版 组织） -->
            <div class="tableDealog" v-show="sustomShow4">
              <el-tabs v-model="activeName4">
                <el-tab-pane label="录音时间" name="first">
                  <div style="margin: 10px;">
                    <el-radio-group v-model="timeChange4" @change="changeValue4">
                      <el-radio :label="1">本日</el-radio>
                      <el-radio :label="2">本周</el-radio>
                      <el-radio :label="3">本月</el-radio>
                      <br />
                      <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                    </el-radio-group>
                  </div>
                  <el-date-picker
                    v-model="searchForm.fourTimer"
                    type="datetimerange"
                    :editable="false"
                    :clearable="false"
                    :disabled="abledFour4"
                    align="right"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    :default-time="['00:00:00', '23:59:59']"
                    style="width: 80%;margin: 10px;"
                  >
                  </el-date-picker>
                  <div class="aloneFooter aloneFooterS">
                    <el-button @click="cancelNot">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="sure('fourTimer')"
                      >确 定</el-button
                    >
                  </div>
                </el-tab-pane>
                <el-tab-pane label="评分模版" name="second">
                  <div style="margin:10px;">
                    <span style="margin-right:10px;font-size:14px;">评分模版</span>
                    <el-select v-model="templateModel4">
                      <el-option
                        v-for="item in templateModels"
                        :label="item.modleTitle"
                        :key="item.modleId"
                        :value="item.modleId"
                      >
                      </el-option>
                    </el-select>
                  </div>
                  <div class="aloneFooter">
                    <el-button @click="cancelNot">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="sureTemplate(templateModel4, 4)"
                      >确 定
                    </el-button>
                  </div>
                </el-tab-pane>
                <el-tab-pane label="组织" name="third">
                  <div style="margin:10px">
                    <span style="margin-right:10px;font-size:14px;">人员范围</span>
                    <el-cascader
                      change-on-select
                      :options="ogzationOptions"
                      :props="ogzationProps"
                      v-model="selectedOgzation4"
                      expand-trigger="click"
                    ></el-cascader>
                  </div>
                  <div class="aloneFooter">
                    <el-button @click="cancelNot">取 消</el-button>
                    <el-button
                      type="primary"
                      style="margin-right: 18px;"
                      @click="sureDept(selectedOgzation4, 4)"
                      >确 定
                    </el-button>
                  </div>
                </el-tab-pane>
              </el-tabs>
            </div>
            <div
              id="exportDec4"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('4', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
          <div class="item item5">
            <div class="echartWrap" id="averageSilenceTops"></div>
            <!--坐席平均静默时长Top5 —— （录音时间） -->
            <div class="tableDealog" v-show="sustomShow5">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">录音时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange5" @change="changeValue5">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.fiveTimer"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour5"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('fiveTimer')"
                  >确 定</el-button
                >
              </div>
            </div>
            <div
              id="exportDec5"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('5', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
          <div class="item item6">
            <div class="echartWrap" id="appRateQA">
              此处环形图
            </div>
            <!--申诉率 —— （录音时间） -->
            <div class="tableDealog" v-show="sustomShow6">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">录音时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange6" @change="changeValue6">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.sixTimer"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour6"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('sixTimer')"
                  >确 定</el-button
                >
              </div>
            </div>
            <div
              id="exportDec6"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('6', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
          <div class="item item7">
            <div class="echartWrap" id="appealRateTops"></div>
            <!--坐席申诉率Top5 —— （录音时间） -->
            <div class="tableDealog" v-show="sustomShow7">
              <div class="aloneTitle">
                <span style="padding-left: 20px;">录音时间</span>
              </div>
              <div style="margin: 10px;">
                <el-radio-group v-model="timeChange7" @change="changeValue7">
                  <el-radio :label="1">本日</el-radio>
                  <el-radio :label="2">本周</el-radio>
                  <el-radio :label="3">本月</el-radio>
                  <br />
                  <el-radio :label="4" style="margin-top: 10px;">自定义</el-radio>
                </el-radio-group>
              </div>
              <el-date-picker
                v-model="searchForm.senvenTimer"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                :disabled="abledFour7"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 80%;margin: 10px;"
              >
              </el-date-picker>
              <div class="aloneFooter">
                <el-button @click="cancelNot">取 消</el-button>
                <el-button
                  type="primary"
                  style="margin-right: 18px;"
                  @click="sure('senvenTimer')"
                  >确 定</el-button
                >
              </div>
            </div>
            <div
              id="exportDec7"
              style="display: none"
              onMouseLeave="this.style.display = 'none';"
            >
              <el-button
                @click="exportPerDec('7', exportDecParames)"
                type="text"
                class="btn"
                >导出明细</el-button
              >
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 进入图片放大功能页面 -->
    <pTasks
      id="paryTasks"
      v-if="paryTasks"
      :message="this.otherValue"
      v-on:send="sellTill"
    ></pTasks>
  </div>
</template>
<script>
import formatdate from '../../../utils/formatdate.js'
import global from '../../../global.js'
import Qs from 'qs'
import commonUtil from '../../../utils/commonUtil.js'
import pTasks from './seatReportBigimg.vue'
let qualityUrl = global.qualityUrl
const colorList = [
  '#1890FF',
  '#41D9C7',
  '#2FC25B',
  '#FACC14',
  '#E6965C',
  '#223273',
  '#7564CC',
  '#8543E0',
  '#5C8EE6',
  '#13C2C2',
  '#5CA3E6',
  '#3436C7',
  '#B381E6',
  '#F04864',
  '#D598D9',
]
export default {
  components: {
    pTasks,
  },
  data() {
    return {
      initTime: [],
      qaUsers: '', // 坐席
      normalId: '', // 标准
      paryTasks: false,
      sustomShow1: false,
      sustomShow2: false,
      sustomShow3: false,
      sustomShow4: false,
      sustomShow5: false,
      sustomShow6: false,
      sustomShow7: false,
      timeChange1: 3,
      timeChange2: 3,
      timeChange3: 3,
      timeChange4: 3,
      timeChange5: 3,
      timeChange6: 3,
      timeChange7: 3,
      searchForm: {
        oneTimer: [],
        twoTimer: [],
        threeTimer: [],
        fourTimer: [],
        fiveTimer: [],
        sixTimer: [],
        senvenTimer: [],
      },
      visible: false,
      abledFour1: true,
      abledFour2: true,
      abledFour3: true,
      abledFour4: true,
      abledFour5: true,
      abledFour6: true,
      abledFour7: true,
      otherValue: {},
      exportDecParames: {}, // 导出明细对象
      timeArr: [],
      activeName2: 'first',
      activeName3: 'first',
      activeName4: 'first',
      templateModel: '', // 默认的templateID
      templateModel2: '',
      templateModel3: '',
      templateModel4: '',
      templateModels: [],
      selectedOgzation: [], // 默认的tOgzationID
      selectedOgzation2: [],
      selectedOgzation3: [],
      selectedOgzation4: [],
      ogzationOptions: [],
      ogzationProps: {
        value: 'id',
        label: 'name',
        children: 'child',
      },
    }
  },
  methods: {
    // 默认时间一个月
    initMonthTime() {
      let fromData = ''
      let toform = ''
      let now = new Date()
      now.setDate(1)
      now.setHours(0)
      now.setMinutes(0)
      now.setSeconds(0)
      fromData = formatdate.formatDate(now)
      let currentMonth = now.getMonth()
      let nextMonth = ++currentMonth
      let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
      let oneDay = 1
      toform = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      this.initTime = [fromData, toform]
    },
    dayFunc(name) {
      let d = new Date()
      let str = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
      let startTime = str + ' 00:00:00'
      let endTime = str + ' 23:59:59'
      if (name == 'oneTimer') {
        this.searchForm.oneTimer = [startTime, endTime]
      } else if (name == 'twoTimer') {
        this.searchForm.twoTimer = [startTime, endTime]
      } else if (name == 'threeTimer') {
        this.searchForm.threeTimer = [startTime, endTime]
      } else if (name == 'fourTimer') {
        this.searchForm.fourTimer = [startTime, endTime]
      } else if (name == 'fiveTimer') {
        this.searchForm.fiveTimer = [startTime, endTime]
      } else if (name == 'sixTimer') {
        this.searchForm.sixTimer = [startTime, endTime]
      } else if (name == 'senvenTimer') {
        this.searchForm.senvenTimer = [startTime, endTime]
      }
    },
    // 时间控件查本周的
    weekFunc(name) {
      let now = new Date()
      let nowTime = now.getTime()
      let day = now.getDay()
      let oneDayTime = 24 * 60 * 60 * 1000
      let startTime =
        formatdate.formatDateWithoutTimes(nowTime - (day - 1) * oneDayTime) + ' 00:00:00'
      let endTime =
        formatdate.formatDateWithoutTimes(nowTime + (7 - day) * oneDayTime) + ' 23:59:59'
      if (name == 'oneTimer') {
        this.searchForm.oneTimer = [startTime, endTime]
      } else if (name == 'twoTimer') {
        this.searchForm.twoTimer = [startTime, endTime]
      } else if (name == 'threeTimer') {
        this.searchForm.threeTimer = [startTime, endTime]
      } else if (name == 'fourTimer') {
        this.searchForm.fourTimer = [startTime, endTime]
      } else if (name == 'fiveTimer') {
        this.searchForm.fiveTimer = [startTime, endTime]
      } else if (name == 'sixTimer') {
        this.searchForm.sixTimer = [startTime, endTime]
      } else if (name == 'senvenTimer') {
        this.searchForm.senvenTimer = [startTime, endTime]
      }
    },
    // 时间控件查本月的
    monthFunc(name) {
      let now = new Date()
      now.setDate(1)
      now.setHours(0)
      now.setMinutes(0)
      now.setSeconds(0)
      let startTime = formatdate.formatDate(now)
      let currentMonth = now.getMonth()
      let nextMonth = ++currentMonth
      let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
      let oneDay = 1000
      let endTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      if (name == 'oneTimer') {
        this.searchForm.oneTimer = [startTime, endTime]
      } else if (name == 'twoTimer') {
        this.searchForm.twoTimer = [startTime, endTime]
      } else if (name == 'threeTimer') {
        this.searchForm.threeTimer = [startTime, endTime]
      } else if (name == 'fourTimer') {
        this.searchForm.fourTimer = [startTime, endTime]
      } else if (name == 'fiveTimer') {
        this.searchForm.fiveTimer = [startTime, endTime]
      } else if (name == 'sixTimer') {
        this.searchForm.sixTimer = [startTime, endTime]
      } else if (name == 'senvenTimer') {
        this.searchForm.senvenTimer = [startTime, endTime]
      }
    },
    sellTill(input) {
      // 放大缩小功能
      this.paryTasks = false
    },
    cancelNot: function() {
      this.sustomShow1 = false
      this.sustomShow2 = false
      this.sustomShow3 = false
      this.sustomShow4 = false
      this.sustomShow5 = false
      this.sustomShow6 = false
      this.sustomShow7 = false
      this.selectedOgzation2 = this.selectedOgzation
      this.selectedOgzation3 = this.selectedOgzation
      this.selectedOgzation4 = this.selectedOgzation
      this.templateModel2 = this.templateModel
      this.templateModel3 = this.templateModel
      this.templateModel4 = this.templateModel
    },
    // 选择“录音时间”确定按钮
    sure(name) {
      let _this = this
      if (name == 'oneTimer') {
        this.sustomShow1 = false
        if (this.timeChange1 == 1) {
          _this.abledFour1 = true
          _this.dayFunc(name)
        } else if (this.timeChange1 == 2) {
          _this.abledFour1 = true
          _this.weekFunc(name)
        } else if (this.timeChange1 == 3) {
          _this.abledFour1 = true
          _this.monthFunc(name)
        } else if (this.timeChange1 == 4) {
          _this.abledFour1 = false
          if (this.searchForm.oneTimer.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.oneTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.oneTimer[1]),
        }
        this.initCallTimeData(params)
      } else if (name == 'twoTimer') {
        this.sustomShow2 = false
        if (this.timeChange2 == 1) {
          _this.abledFour2 = true
          _this.dayFunc(name)
        } else if (this.timeChange2 == 2) {
          _this.abledFour2 = true
          _this.weekFunc(name)
        } else if (this.timeChange2 == 3) {
          _this.abledFour2 = true
          _this.monthFunc(name)
        } else if (this.timeChange2 == 4) {
          _this.abledFour2 = false
          if (this.searchForm.twoTimer.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.twoTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.twoTimer[1]),
        }
        this.initScoreData(params)
      } else if (name == 'threeTimer') {
        this.sustomShow3 = false
        if (this.timeChange3 == 1) {
          _this.abledFour3 = true
          _this.dayFunc(name)
        } else if (this.timeChange3 == 2) {
          _this.abledFour3 = true
          _this.weekFunc(name)
        } else if (this.timeChange3 == 3) {
          _this.abledFour3 = true
          _this.monthFunc(name)
        } else if (this.timeChange3 == 4) {
          _this.abledFour3 = false
          if (this.searchForm.threeTimer.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.threeTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.threeTimer[1]),
        }
        this.initErrorRateRadarMapData(params)
      } else if (name == 'fourTimer') {
        this.sustomShow4 = false
        if (this.timeChange4 == 1) {
          _this.abledFour4 = true
          _this.dayFunc(name)
        } else if (this.timeChange4 == 2) {
          _this.abledFour4 = true
          _this.weekFunc(name)
        } else if (this.timeChange4 == 3) {
          _this.abledFour4 = true
          _this.monthFunc(name)
        } else if (this.timeChange4 == 4) {
          _this.abledFour4 = false
          if (this.searchForm.fourTimer.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.fourTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.fourTimer[1]),
        }
        this.initSourceOfDeathData(params)
      } else if (name == 'fiveTimer') {
        this.sustomShow5 = false
        if (this.timeChange5 == 1) {
          _this.abledFour5 = true
          _this.dayFunc(name)
        } else if (this.timeChange5 == 2) {
          _this.abledFour5 = true
          _this.weekFunc(name)
        } else if (this.timeChange5 == 3) {
          _this.abledFour5 = true
          _this.monthFunc(name)
        } else if (this.timeChange5 == 4) {
          _this.abledFour5 = false
          if (this.searchForm.fiveTimer.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.fiveTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.fiveTimer[1]),
        }
        this.initAverageSilenceTopsData(params)
      } else if (name == 'sixTimer') {
        this.sustomShow6 = false
        if (this.timeChange6 == 1) {
          _this.abledFour6 = true
          _this.dayFunc(name)
        } else if (this.timeChange6 == 2) {
          _this.abledFour6 = true
          _this.weekFunc(name)
        } else if (this.timeChange6 == 3) {
          _this.abledFour6 = true
          _this.monthFunc(name)
        } else if (this.timeChange6 == 4) {
          _this.abledFour6 = false
          if (this.searchForm.sixTimer.length == 0) {
            _this.monthFunc(name)
          }
        }
        let parameAppRate = {
          startTime: formatdate.formatDate(this.searchForm.sixTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.sixTimer[1]),
        }
        this.drawAppRate(parameAppRate)
      } else if (name == 'senvenTimer') {
        this.sustomShow7 = false
        if (this.timeChange7 == 1) {
          _this.abledFour7 = true
          _this.dayFunc(name)
        } else if (this.timeChange7 == 2) {
          _this.abledFour7 = true
          _this.weekFunc(name)
        } else if (this.timeChange7 == 3) {
          _this.abledFour7 = true
          _this.monthFunc(name)
        } else if (this.timeChange7 == 4) {
          _this.abledFour7 = false
          if (this.searchForm.senvenTimer.length == 0) {
            _this.monthFunc(name)
          }
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.senvenTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.senvenTimer[1]),
        }
        this.initAppealRateTopsData(params)
      }
    },
    // 模版确定按钮
    sureTemplate(data, num) {
      let parames2 = {}
      let parames3 = {}
      let parames4 = {}
      if (num === 2) {
        let timeParmes = this.isTimerNull(this.searchForm.twoTimer)
        parames2 = {
          startTime: timeParmes.startTime,
          endTime: timeParmes.endTime,
        }
        this.templateModel2 = data
        this.sustomShow2 = false
        this.initScoreData(parames2)
      } else if (num === 3) {
        let timeParmes = this.isTimerNull(this.searchForm.threeTimer)
        parames3 = {
          startTime: timeParmes.startTime,
          endTime: timeParmes.endTime,
        }
        this.templateModel3 = data
        this.sustomShow3 = false
        this.initErrorRateRadarMapData(parames3)
      } else if (num === 4) {
        let timeParmes = this.isTimerNull(this.searchForm.threeTimer)
        parames4 = {
          startTime: timeParmes.startTime,
          endTime: timeParmes.endTime,
        }
        this.templateModel4 = data
        this.sustomShow4 = false
        this.initSourceOfDeathData(parames4)
      }
    },
    // 人员范围确定按钮
    sureDept(data, num) {
      let parames2 = {}
      let parames3 = {}
      let parames4 = {}
      if (num === 2) {
        let timeParmes = this.isTimerNull(this.searchForm.twoTimer)
        parames2 = {
          startTime: timeParmes.startTime,
          endTime: timeParmes.endTime,
        }
        this.selectedOgzation2 = data
        this.sustomShow2 = false
        this.initScoreData(parames2)
      } else if (num === 3) {
        let timeParmes = this.isTimerNull(this.searchForm.threeTimer)
        parames3 = {
          startTime: timeParmes.startTime,
          endTime: timeParmes.endTime,
        }
        this.selectedOgzation3 = data
        this.sustomShow3 = false
        this.initErrorRateRadarMapData(parames3)
      } else if (num === 4) {
        let timeParmes = this.isTimerNull(this.searchForm.fourTimer)
        parames4 = {
          startTime: timeParmes.startTime,
          endTime: timeParmes.endTime,
        }
        this.selectedOgzation4 = data
        this.sustomShow4 = false
        this.initSourceOfDeathData(parames4)
      }
    },
    // 刷新数据以及取消联动
    isTimerNull: function(timer, num) {
      let params = {}
      if (num === 6) {
        if (timer.length == 0) {
          params = {
            startTime: this.initTime[0],
            endTime: this.initTime[1],
          }
        } else {
          params = {
            startTime: formatdate.formatDate(timer[0]),
            endTime: formatdate.formatDate(timer[1]),
          }
        }
      } else {
        if (timer.length == 0) {
          params = {
            startTime: this.initTime[0],
            endTime: this.initTime[1],
          }
        } else {
          params = {
            startTime: formatdate.formatDate(timer[0]),
            endTime: formatdate.formatDate(timer[1]),
          }
        }
      }
      return params
    },
    refreshData() {
      this.qaUsers = ''
      this.normalId = ''
      let params1 = {}
      let params2 = {}
      let params3 = {}
      let params4 = {}
      let params5 = {}
      let params6 = {}
      let params7 = {}
      if (this.searchForm.oneTimer.length == 0) {
        params1 = this.isTimerNull(this.searchForm.oneTimer, 1)
      } else {
        params1 = {
          startTime: formatdate.formatDate(this.searchForm.oneTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.oneTimer[1]),
        }
      }
      if (this.searchForm.twoTimer.length == 0) {
        params2 = this.isTimerNull(this.searchForm.twoTimer, 2)
      } else {
        params2 = {
          startTime: formatdate.formatDate(this.searchForm.twoTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.twoTimer[1]),
        }
      }
      if (this.searchForm.threeTimer.length == 0) {
        params3 = this.isTimerNull(this.searchForm.threeTimer, 3)
      } else {
        params3 = {
          startTime: formatdate.formatDate(this.searchForm.threeTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.threeTimer[1]),
        }
      }
      if (this.searchForm.fourTimer.length == 0) {
        params4 = this.isTimerNull(this.searchForm.fourTimer, 4)
      } else {
        params4 = {
          startTime: formatdate.formatDate(this.searchForm.fourTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.fourTimer[1]),
        }
      }
      if (this.searchForm.fiveTimer.length == 0) {
        params5 = this.isTimerNull(this.searchForm.fiveTimer, 5)
      } else {
        params5 = {
          startTime: formatdate.formatDate(this.searchForm.fiveTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.fiveTimer[1]),
        }
      }
      if (this.searchForm.sixTimer.length == 0) {
        params6 = this.isTimerNull(this.searchForm.sixTimer, 6)
      } else {
        params6 = {
          startTime: formatdate.formatDate(this.searchForm.sixTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.sixTimer[1]),
        }
      }
      if (this.searchForm.senvenTimer.length == 0) {
        params7 = this.isTimerNull(this.searchForm.senvenTimer, 7)
      } else {
        params7 = {
          startTime: formatdate.formatDate(this.searchForm.senvenTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.senvenTimer[1]),
        }
      }
      this.initCallTimeData(params1)
      this.initScoreData(params2)
      this.initErrorRateRadarMapData(params3)
      this.initSourceOfDeathData(params4)
      this.initAverageSilenceTopsData(params5)
      this.drawAppRate(params6)
      this.initAppealRateTopsData(params7)
    },
    // 初始化数据
    initChartData() {
      let _this = this
      // 获取模板列表
      let paramsModel = {
        modleType: '7',
        pageindex: '',
        pagesize: '',
      }
      let url = qualityUrl + '/manualQualityAssurance/getModleInfoByCondition.do'
      _this.axios
        .post(url, Qs.stringify(paramsModel))
        .then(function(response) {
          _this.templateModels = response.data.Data
          // 获取坐席分类树
          _this.axios
            .post(qualityUrl + '/externalDataImport/getSeatMan.do')
            .then(function(response) {
              _this.ogzationOptions = response.data.data
              _this.initScoreData(params, 0)
              _this.initErrorRateRadarMapData(params, 0)
              _this.initSourceOfDeathData(params, 0)
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '获取坐席出现问题',
              })
            })
        })
        .catch(function(error) {
          console.log(error)
          _this.$message.error('模板获取失败')
        })
      this.initMonthTime()
      if (this.initTime == [] || this.initTime.length <= 0) {
        return
      }
      let start = this.initTime[0]
      let end = this.initTime[1]
      let params = {
        startTime: start,
        endTime: end,
      }
      /* let params = {
         startTime: '2018-09-01',
         endTime: '2018-09-30'
         } */
      let parameAppRate = {
        startTime: start,
        endTime: end,
      }
      this.initCallTimeData(params)
      this.initAverageSilenceTopsData(params)
      this.initAppealRateTopsData(params)
      this.drawAppRate(parameAppRate)
    },
    // 判断模块时间是否为空
    isTimeNull(time) {
      if (time.length == 0) {
        this.timeArr = this.initTime
      } else {
        this.timeArr = time
      }
    },
    /*
     * 录音时间change
     * */
    changeValue1: function(value) {
      if (value == 4) {
        this.abledFour1 = false
      } else {
        this.abledFour1 = true
      }
    },
    changeValue2: function(value) {
      if (value == 4) {
        this.abledFour2 = false
      } else {
        this.abledFour2 = true
      }
    },
    changeValue3: function(value) {
      if (value == 4) {
        this.abledFour3 = false
      } else {
        this.abledFour3 = true
      }
    },
    changeValue4: function(value) {
      if (value == 4) {
        this.abledFour4 = false
      } else {
        this.abledFour4 = true
      }
    },
    changeValue5: function(value) {
      if (value == 4) {
        this.abledFour5 = false
      } else {
        this.abledFour5 = true
      }
    },
    changeValue6: function(value) {
      if (value == 4) {
        this.abledFour6 = false
      } else {
        this.abledFour6 = true
      }
    },
    changeValue7: function(value) {
      if (value == 4) {
        this.abledFour7 = false
      } else {
        this.abledFour7 = true
      }
    },
    /*
     * 模块初始数据
     */
    // 来电时段统计
    initCallTimeData(params) {
      let self = this
      this.axios
        .post(qualityUrl + '/report/inCallData.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            self.callTimeChart(res.data)
          }
        })
    },
    // 选取的组织的最后一项属于什么类型？ 部门（department）或人员（account）
    getSeatId(child, id) {
      if (child && child.length > 0) {
        child.forEach((item) => {
          let type = item.id == id ? item.type : this.getSeatId(item.child, id)
          if (type) {
            this.type = type    // 选取的组织类型（部门或坐席）department（部门），account（坐席）
          }
        })
      }
    },
    // 设置组织选项传参
    setParams(arr1,arr2) {
      if (this.type == 'department') {
        arr1.push(arr2[0])
        arr1.push(arr2[arr2.length - 1])
      }
      if (this.type == 'account') {
        arr1.push(arr2[0])
        arr1.push(arr2[arr2.length - 2])
        arr1.push(arr2[arr2.length - 1])
      }
    },
    // 成绩查看
    initScoreData(params, num) {
      let self = this
      let seatId = []
      if (num === 0) {
        if (this.templateModels.length > 0) {
          this.templateModel2 = this.templateModels[0].modleId
          this.templateModel = this.templateModels[0].modleId
        }
        if (this.ogzationOptions.length > 0) {
          let idArr = []
          idArr.push(this.ogzationOptions[0].id)
          this.selectedOgzation2 = idArr
          this.selectedOgzation = idArr
          seatId = idArr
        }
      } else {
       // 组织选项前端传参，若选择的是部门，只传递一级部门和最后一级部门两个参数，若选择的是人员，则三个参数：一级部门，最末级部门，人员id
        let length = this.selectedOgzation2.length
        if (length >= 2) {
          this.getSeatId(
            this.ogzationOptions,
            this.selectedOgzation2[length - 1]
          )
          this.setParams(seatId,this.selectedOgzation2)
        } else {
          seatId = this.selectedOgzation2
        }
      }
      let parames = {
        startTime: params.startTime,
        endTime: params.endTime,
        modelId: this.templateModel2,
        seatNos: this.qaUsers == '' ? seatId : [this.qaUsers],
      }
      this.axios
        .post(qualityUrl + '/report/scoreData.do', Qs.stringify(parames))
        .then(function(res) {
          if (res.data) {
            self.scoreResultChart(res.data)
          }
        })
    },
    // 错误率雷达
    initErrorRateRadarMapData(params, num) {
      let seatId = []
      if (num === 0) {
        if (this.templateModels.length > 0) {
          this.templateModel3 = this.templateModels[0].modleId
        }
        if (this.ogzationOptions.length > 0) {
          let idArr = []
          idArr.push(this.ogzationOptions[0].id)
          this.selectedOgzation3 = idArr
          seatId = idArr
        }
      } else {
        let length = this.selectedOgzation3.length
        if (length >= 2) {
          this.getSeatId(
            this.ogzationOptions,
            this.selectedOgzation3[length - 1]
          )
          this.setParams(seatId,this.selectedOgzation3)
        } else {
          seatId = this.selectedOgzation3
        }
      }
      let parames = {
        startTime: params.startTime,
        endTime: params.endTime,
        modelId: this.templateModel3,
        seat: seatId.toString(),
        normalId: this.normalId,
        seatNo: this.qaUsers,
      }
      let self = this
      this.axios
        .post(qualityUrl + '/statistic/errorRate.do', Qs.stringify(parames))
        .then(function(res) {
          if (res.data) {
            self.errorRateRadarMapChart(res.data)
          }
        })
    },
    // 致命项来源
    initSourceOfDeathData(params, num) {
      let seatId = []
      if (num === 0) {
        if (this.templateModels.length > 0) {
          this.templateModel4 = this.templateModels[0].modleId
        }
        if (this.ogzationOptions.length > 0) {
          let idArr = []
          idArr.push(this.ogzationOptions[0].id)
          this.selectedOgzation4 = idArr
          seatId = idArr
        }
      } else {
        let length = this.selectedOgzation4.length
        if (length >= 2) {
          this.getSeatId(
            this.ogzationOptions,
            this.selectedOgzation4[length - 1]
          )
          this.setParams(seatId,this.selectedOgzation4)
        } else {
          seatId = this.selectedOgzation4
        }
      }
      let self = this
      let parames = {
        startTime: params.startTime,
        endTime: params.endTime,
        modelId: this.templateModel4,
        seat: seatId.toString(),
        normalId: this.normalId,
        seatNo: this.qaUsers,
      }
      this.axios
        .post(qualityUrl + '/statistic/deadItem.do', Qs.stringify(parames))
        .then(function(res) {
          if (res.data) {
            self.sourceOfDeathChart(res.data)
          }
        })
    },
    // 坐席静默时长tops
    initAverageSilenceTopsData(params) {
      let self = this
      this.axios
        .post(qualityUrl + '/statistic/seatSilence.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            self.averageSilenceTopsChart(res.data)
          }
        })
    },
    // 申诉率
    drawAppRate(params) {
      let _this = this
      let appRateOption = {
        color: colorList,
        title: {
          text: '申诉率',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} ({d}%)',
          position: function(pos, params, el, elRect, size) {
            let obj = { top: 10 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30
            return obj
          },
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = appRateOption
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: {
              show: true,
              icon: 'image://static/img/downLoad.png',
              type: 'jpeg',
            },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('sixBlock')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow6 = true
              },
            },
          },
        },
        series: {
          name: '数据分类：',
          type: 'pie',
          radius: ['50%', '70%'],
          center: ['50%', '55%'],
          avoidLabelOverlap: false,
          label: {
            normal: {
              show: false,
              position: 'center',
            },
            emphasis: {
              show: false,
              textStyle: {
                fontSize: '30',
                fontWeight: 'bold',
              },
            },
          },
          labelLine: {
            normal: {
              show: false,
            },
          },
          data: [
            { value: 0, name: '未申诉' },
            { value: 0, name: '一次申诉' },
            { value: 0, name: '二次申诉' },
          ],
        },
      }
      this.axios
        .post(qualityUrl + '/appReport/getSeatAppRateData.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            appRateOption.series.data = res.data.Data
            _this.drawEcharts('appRateQA', appRateOption)
          }
        })
    },
    // 坐席申诉率tops
    initAppealRateTopsData(params) {
      let self = this
      this.axios
        .post(qualityUrl + '/statistic/seatAppealRate.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            self.appealRateTopsChart(res.data)
          }
        })
    },
    /*
     * 模块echart参数配置
     */
    // 来电时段统计
    callTimeChart(lineObject) {
      let callTimeX = []
      let callTimeY = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']
      let callTimeData = []
      for (let i = 0; i < lineObject.length; i++) {
        let item = lineObject[i]
        // callTimeY.push(item.week)
        for (let j = 0; j < item.hourSum.length; j++) {
          item.hourSum.forEach(function(item) {
            callTimeData.push([i, item.hour, item.count])
          })
        }
      }
      lineObject[0].hourSum.forEach(function(item) {
        callTimeX.push(item.hour)
      })
      // let callTimeData = [[0, 0, 5], [0, 1, 1], [0, 2, 0], [0, 3, 0], [0, 4, 0], [0, 5, 0], [0, 6, 0], [0, 7, 0], [0, 8, 0], [0, 9, 0], [0, 10, 0], [0, 11, 2], [0, 12, 4], [0, 13, 1], [0, 14, 1], [0, 15, 3], [0, 16, 4], [0, 17, 6], [0, 18, 4], [0, 19, 4], [0, 20, 3], [0, 21, 3], [0, 22, 2], [0, 23, 5], [1, 0, 7], [1, 1, 0], [1, 2, 0], [1, 3, 0], [1, 4, 0], [1, 5, 0], [1, 6, 0], [1, 7, 0], [1, 8, 0], [1, 9, 0], [1, 10, 5], [1, 11, 2], [1, 12, 2], [1, 13, 6], [1, 14, 9], [1, 15, 11], [1, 16, 6], [1, 17, 7], [1, 18, 8], [1, 19, 12], [1, 20, 5], [1, 21, 5], [1, 22, 7], [1, 23, 2], [2, 0, 1], [2, 1, 1], [2, 2, 0], [2, 3, 0], [2, 4, 0], [2, 5, 0], [2, 6, 0], [2, 7, 0], [2, 8, 0], [2, 9, 0], [2, 10, 3], [2, 11, 2], [2, 12, 1], [2, 13, 9], [2, 14, 8], [2, 15, 10], [2, 16, 6], [2, 17, 5], [2, 18, 5], [2, 19, 5], [2, 20, 7], [2, 21, 4], [2, 22, 2], [2, 23, 4], [3, 0, 7], [3, 1, 3], [3, 2, 0], [3, 3, 0], [3, 4, 0], [3, 5, 0], [3, 6, 0], [3, 7, 0], [3, 8, 1], [3, 9, 0], [3, 10, 5], [3, 11, 4], [3, 12, 7], [3, 13, 14], [3, 14, 13], [3, 15, 12], [3, 16, 9], [3, 17, 5], [3, 18, 5], [3, 19, 10], [3, 20, 6], [3, 21, 4], [3, 22, 4], [3, 23, 1], [4, 0, 1], [4, 1, 3], [4, 2, 0], [4, 3, 0], [4, 4, 0], [4, 5, 1], [4, 6, 0], [4, 7, 0], [4, 8, 0], [4, 9, 2], [4, 10, 4], [4, 11, 4], [4, 12, 2], [4, 13, 4], [4, 14, 4], [4, 15, 14], [4, 16, 12], [4, 17, 1], [4, 18, 8], [4, 19, 5], [4, 20, 3], [4, 21, 7], [4, 22, 3], [4, 23, 0], [5, 0, 2], [5, 1, 1], [5, 2, 0], [5, 3, 3], [5, 4, 0], [5, 5, 0], [5, 6, 0], [5, 7, 0], [5, 8, 2], [5, 9, 0], [5, 10, 4], [5, 11, 1], [5, 12, 5], [5, 13, 10], [5, 14, 5], [5, 15, 7], [5, 16, 11], [5, 17, 6], [5, 18, 0], [5, 19, 5], [5, 20, 3], [5, 21, 4], [5, 22, 2], [5, 23, 0], [6, 0, 1], [6, 1, 0], [6, 2, 0], [6, 3, 0], [6, 4, 0], [6, 5, 0], [6, 6, 0], [6, 7, 0], [6, 8, 0], [6, 9, 0], [6, 10, 1], [6, 11, 0], [6, 12, 2], [6, 13, 1], [6, 14, 3], [6, 15, 4], [6, 16, 0], [6, 17, 0], [6, 18, 0], [6, 19, 0], [6, 20, 1], [6, 21, 2], [6, 22, 2], [6, 23, 6]]
      callTimeData = callTimeData.map(function(item) {
        return [item[1], item[0], item[2] || '-']
      })
      let _this = this
      let option = {
        color: colorList,
        title: {
          text: '来电时段统计',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = option
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('firstBlock')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow1 = true
              },
            },
          },
        },
        animation: false,
        grid: {
          left: 0,
          top: 55,
          bottom: 0,
          right: 0,
          containLabel: true,
        },
        xAxis: {
          type: 'category',
          data: callTimeX,
          splitArea: {
            show: true,
          },
        },
        yAxis: {
          type: 'category',
          data: callTimeY,
          splitArea: {
            show: true,
          },
        },
        series: [
          {
            name: 'Punch Card',
            type: 'heatmap',
            data: callTimeData,
            label: {
              normal: {
                show: true,
              },
            },
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
              },
            },
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.querySelector('#callTimeChart'))
        myChart.clear()
        myChart.setOption(option)
        // echart 右击事件，导出明细
        myChart.on('contextmenu', function(param) {
          let menu = document.getElementById('exportDec1')
          let event = param.event
          let pageX = event.offsetX
          let pageY = event.offsetY
          menu.style.left = pageX + 'px'
          menu.style.top = pageY + 'px'
          menu.style.display = 'block'
          _this.isTimeNull(_this.searchForm.oneTimer)
          _this.exportDecParames = {
            startTime: formatdate.formatDate(_this.timeArr[0]),
            endTime: formatdate.formatDate(_this.timeArr[1]),
            week: param.data[1] + 1,
            hourStart: param.data[0],
            hourEnd: param.data[0] + 1,
          }
          console.log('右击事件')
          console.log(_this.exportDecParames)
        })
      })
    },
    // 成绩统计
    scoreResultChart(data) {
      let itemStyle = {
        normal: {},
        emphasis: {
          barBorderWidth: 1,
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowOffsetY: 0,
          shadowColor: 'rgba(0,0,0,0.1)',
        },
      }
      let seriesData = []
      let avgSeries = []
      let avgLine = []
      let avgLineMax = []
      let avgLineArr = []
      let xArr = []
      let keys = []
      let idArr = []
      for (let i = 0; i < data.avgData.length; i++) {
        let item = data.avgData[i]
        avgSeries.push({
          name: item.description,
          value: item.sum,
          scoreMin: item.scoreMin,
          scoreMax: item.scoreMax,
          labelLine: {
            normal: {
              lineStyle: {},
              length: 0,
              length2: 0,
            },
          },
        })
      }
      let keyMap = new Map()
      for (let j = 0; j < data.slotData.length; j++) {
        let item = data.slotData[j]
        let dData = []
        avgLine.push({
          value: item.avg,
          id: item.scoreMin + ',' + item.scoreMax,
        })
        avgLineArr.push(item.avg)
        xArr.push(item.name)
        idArr.push(item.id)
        for (let d = 0; d < item.dataDetail.length; d++) {
          let dtem = item.dataDetail[d]
          dData.push(dtem.sum)
          keys.push(dtem.description + ',' + dtem.scoreMin + ',' + dtem.scoreMax)
          if (
            keyMap.get(dtem.description + ',' + dtem.scoreMin + ',' + dtem.scoreMax) ==
              null ||
            keyMap.get(dtem.description + ',' + dtem.scoreMin + ',' + dtem.scoreMax) ==
              undefined
          ) {
            keyMap.set(dtem.description + ',' + dtem.scoreMin + ',' + dtem.scoreMax, [
              dtem.sum,
            ])
          } else {
            let vauless =
              keyMap.get(dtem.description + ',' + dtem.scoreMin + ',' + dtem.scoreMax) ||
              []
            vauless.push(dtem.sum)
            keyMap.set(
              dtem.description + ',' + dtem.scoreMin + ',' + dtem.scoreMax,
              vauless
            )
          }
        }
      }
      xArr.push(' ')
      xArr.push(' ')
      avgLineMax = Math.max.apply(null, avgLineArr)
      avgLineMax = Math.floor(avgLineMax)
      for (let i = 0; i < keys.length; i++) {
        let keyArr = keys[i].split(',')
        seriesData.push({
          name: keyArr[0],
          type: 'bar',
          stack: 'one',
          itemStyle: itemStyle,
          data: keyMap.get(keys[i]),
          id: keyArr[1] + ',' + keyArr[2],
        })
      }
      // 数组去重
      let keyMapData = seriesData.reduce((map, item) => {
        map[item.name] = item
        return map
      }, {})
      seriesData = Object.keys(keyMapData).map((key) => keyMapData[key])
      seriesData.push({
        name: '平均成绩',
        type: 'line',
        data: avgLine,
      })
      seriesData.push({
        type: 'pie',
        radius: [0, '22%'],
        barWidth: 40,
        center: ['84%', '30%'],
        label: {
          normal: {
            position: 'outside',
          },
        },
        labelLine: {
          normal: {
            show: false,
          },
        },
        data: avgSeries,
      })
      console.log(seriesData)
      let _this = this
      let option = {
        color: colorList,
        title: {
          text: '成绩统计',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        dataZoom: [{ type: 'inside' }],
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow',
          },
          formatter: function(parames) {
            let str = ''
            for (let i = 0; i < parames.length; i++) {
              str += '<div>' + parames[i].seriesName + ':' + parames[i].value + '</div>'
            }
            let res = ''
            res +=
              '<div style="font-size: 12px;">' +
              parames[0].name +
              '</div>' +
              '<div style="font-size: 12px;">' +
              '<p>' +
              '成绩分布(录音数)' +
              '</p>' +
              str +
              '</div>'
            return res
          },
          position: function(pos, params, el, elRect, size) {
            let obj = { top: 10 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30
            return obj
          },
          extraCssText: 'width: 150px;',
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = option
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('twoBlock')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow2 = true
              },
            },
          },
        },
        xAxis: [
          {
            data: xArr,
            splitLine: { show: false },
          },
        ],
        yAxis: [
          {
            type: 'value',
            minInterval: 1,
            splitLine: { show: false },
            name: '成绩分布(录音数)',
            min: 0,
            axisLabel: {
              formatter: '{value}',
            },
          },
          {
            type: 'value',
            name: '平均成绩',
            splitLine: { show: false },
            min: 0,
            max: avgLineMax,
            axisLabel: {
              formatter: '{value}',
            },
          },
        ],
        grid: {
          left: 50,
          top: 80,
          bottom: 30,
          right: 30,
        },
        series: seriesData,
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.querySelector('#scoreResult'))
        myChart.clear()
        myChart.setOption(option)
        // echart 右击事件，导出明细
        myChart.on('contextmenu', function(param) {
          console.log(param)
          let menu = document.getElementById('exportDec2')
          let event = param.event
          let pageX = event.offsetX
          let pageY = event.offsetY
          menu.style.left = pageX + 'px'
          menu.style.top = pageY + 'px'
          if(param.seriesType!=='line'){
            menu.style.display = 'block'
          }
          _this.isTimeNull(_this.searchForm.twoTimer)
          let arr = param.seriesId.split(',')
          // 组织选项的传参设置
          let seatId = []
          let length = _this.selectedOgzation2.length
          if (length >= 2) {
            _this.getSeatId(
              _this.ogzationOptions,
              _this.selectedOgzation2[length - 1]
            )
            _this.setParams(seatId,_this.selectedOgzation2)
          } else {
            seatId = _this.selectedOgzation2
          }
          if (param.componentSubType == 'pie') {
            console.log("1111111111"+param.data)
            _this.exportDecParames = {
              startTime: formatdate.formatDate(_this.timeArr[0]),
              endTime: formatdate.formatDate(_this.timeArr[1]),
              modelId: _this.templateModel2,
              seatNos: null,
              scoreMin: param.data.scoreMin,
              scoreMax: param.data.scoreMax?param.data.scoreMax:null,
            }
          } else {
            console.log("22222222--"+arr[0]+"--2222"+arr[1])
            console.log( arr)
            _this.exportDecParames = {
              startTime: formatdate.formatDate(_this.timeArr[0]),
              endTime: formatdate.formatDate(_this.timeArr[1]),
              modelId: _this.templateModel2,
              seatNos: idArr.filter((item,index) => param.dataIndex === index ),
              scoreMin: arr[0],
              scoreMax: arr[1]==='undefined'?null:arr[1],
            }
          }
          console.log('右击事件')
          console.log(_this.exportDecParames)
        })
      })
    },
    // 错误率雷达图
    errorRateRadarMapChart(data) {
      let seriesData = []
      let indicatorData = []
      let maxArr = []
      let maxData = ''
      let names = []
      let ids = []
      if(data.texts) {
        for (let j = 0; j < data.texts.length; j++) {
          let item = data.texts[j]
          maxArr = data.data
          maxData = Math.max.apply(null, maxArr)
          indicatorData.push({
            name: item.text,
            id: item.normalId,
            max: maxData,
          })
          names.push(item.text)
          ids.push(item.normalId)
        }
        seriesData.push({
          name: names,
          id: ids,
          value: data.data,
        })
      }
      let _this = this
      let option = {
        color: colorList,
        title: {
          text: '错误率雷达图',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        tooltip: {
          formatter: function(parames) {
            let res = ''
            for (let i = 0; i < parames.data.name.length; i++) {
              res +=
                '<div style="font-size: 12px;">' +
                parames.data.name[i] +
                ':' +
                parames.data.value[i] +
                '%' +
                '</div>'
            }
            return res
          },
          position: function(pos, params, el, elRect, size) {
            let obj = { top: 10 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30
            return obj
          },
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = option
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('threeBlock')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow3 = true
              },
            },
          },
        },
        radar: {
          // shape: 'circle',
          name: {
            textStyle: {
              color: '#000',
            },
            formatter: (text) => {
              if(text) {
                text = text.replace(/\S{2}/g, function(match) {
                  return match + '\n'
                })
              }
              return text
            },
          },
          nameGap: 0,
          indicator: indicatorData.length === 0 ? [{}]:indicatorData,
          /* indicator: [
             {name: '销售（sales）', max: 6500},
             {name: '管理（Administration）', max: 16000},
             {name: '信息技术（Information Techology）', max: 30000},
             {name: '客服（Customer Support）', max: 38000},
             {name: '研发（Development）', max: 52000},
             {name: '市场（Marketing）', max: 25000}
             ] */
        },
        grid: {
          left: 40,
          top: 80,
          bottom: 30,
          right: 30,
        },
        series: [
          {
            type: 'radar',
            data: seriesData,
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.querySelector('#errorRateRadarMap'))
        myChart.clear()
        myChart.setOption(option)
        // echart 右击事件，导出明细
        myChart.on('contextmenu', function(param) {
          console.log(param)
          let ids = ''
          for (let i = 0; i < param.data.name.length; i++) {
            ids += param.data.id[i] + ','
          }
          let menu = document.getElementById('exportDec3')
          let event = param.event
          let pageX = event.offsetX
          let pageY = event.offsetY
          menu.style.left = pageX + 'px'
          menu.style.top = pageY + 'px'
          menu.style.display = 'block'
          _this.isTimeNull(_this.searchForm.threeTimer)
          // 组织选项的传参设置
          let seatId = []
          let length = _this.selectedOgzation3.length
          if (length >= 2) {
            _this.getSeatId(
              _this.ogzationOptions,
              _this.selectedOgzation3[length - 1]
            )
            _this.setParams(seatId,_this.selectedOgzation3)
          } else {
            seatId = _this.selectedOgzation3
          }
          _this.exportDecParames = {
            startTime: formatdate.formatDate(_this.timeArr[0]),
            endTime: formatdate.formatDate(_this.timeArr[1]),
            seat: seatId.toString(),
            normalId: _this.templateModel3,
            ids: ids,
          }
          console.log('右击事件')
          console.log(_this.exportDecParames)
        })
      })
    },
    // 致命项来源
    sourceOfDeathChart(data) {
      console.log(data)
      let sourceData = data.data
      // let totalCount = data.count
      // let totalCount = 500
      /* let sourceData = [
         {value: 335, name: '人工致命项标准', normalId: '0accb67eb26111e89a65ac2b6ebe4f33'},
         {value: 310, name: '邮件营销', normalId: '0accb67eb26111e89a65ac2b6ebe4f33'},
         {value: 274, name: '联盟广告', normalId: '0accb67eb26111e89a65ac2b6ebe4f33'},
         {value: 235, name: '视频广告', normalId: '0accb67eb26111e89a65ac2b6ebe4f33'},
         {value: 400, name: '搜索引擎', normalId: '0accb67eb26111e89a65ac2b6ebe4f33'}
         ] */
      let seriesData = []
      if(sourceData) {
        for (let i = 0; i < sourceData.length; i++) {
          let item = sourceData[i]
          seriesData.push({
            value: item.value,
            id: item.normalId,
            name: item.name,
            rate: item.value + '-' + item.count,
          })
        }
      }
      let _this = this
      let option = {
        color: colorList,
        title: {
          text: '致命项来源占比',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        tooltip: {
          trigger: 'item',
          formatter: function(parames) {
            let itemValue = parames.data.rate.split('-')[1]
            let itemRate = parames.data.rate.split('-')[0]
            let res = ''
            res +=
              '<div style="font-size: 12px;">' +
              parames.name +
              ':' +
              itemValue +
              '(' +
              itemRate +
              '%' +
              ')' +
              '</div>'
            return res
          },
          position: function(pos, params, el, elRect, size) {
            let obj = { top: 10 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30
            return obj
          },
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = option
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('fourBlock')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow4 = true
              },
            },
          },
        },
        grid: {
          left: 40,
          top: 80,
          bottom: 30,
          right: 30,
        },
        series: [
          {
            type: 'pie',
            radius: '60%',
            center: ['50%', '50%'],
            data: seriesData.sort(function(a, b) {
              return a.value - b.value
            }),
            roseType: 'radius',
            label: {
              normal: {
                fontSize: 12,
                formatter: (v) => {
                  let text = v.name.replace(/\S{1}/g, function(match) {
                    return match + '\n'
                  })
                  return text
                },
              },
            },
            labelLine: {
              normal: {
                lineStyle: {
                  color: 'rgba(255, 255, 255, 0.3)'
                },
                smooth: 0.2,
                length: 10,
                length2: 20
              }
            },
            animationType: 'scale',
            animationEasing: 'elasticOut',
            animationDelay: function(idx) {
              return Math.random() * 200
            },
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.querySelector('#sourceOfDeath'))
        myChart.clear()
        myChart.setOption(option)
        myChart.on('click', function(params) {
          _this.normalId = params.data.id
          _this.handleSingleNormal(params.data.name, params.data.id, 'death')
        })
        // echart 右击事件，导出明细
        myChart.on('contextmenu', function(param) {
          let menu = document.getElementById('exportDec4')
          let event = param.event
          let pageX = event.offsetX
          let pageY = event.offsetY
          menu.style.left = pageX + 'px'
          menu.style.top = pageY + 'px'
          menu.style.display = 'block'
          _this.isTimeNull(_this.searchForm.fourTimer)
          // 组织选项的传参设置
          let seatId = []
          let length = _this.selectedOgzation4.length
          if (length >= 2) {
            _this.getSeatId(
              _this.ogzationOptions,
              _this.selectedOgzation4[length - 1]
            )
            _this.setParams(seatId,_this.selectedOgzation4)
          } else {
            seatId = _this.selectedOgzation4
          }
          _this.exportDecParames = {
            startTime: formatdate.formatDate(_this.timeArr[0]),
            endTime: formatdate.formatDate(_this.timeArr[1]),
            seat: seatId.toString(),
            normalId: param.data.id,
            normalName: param.data.name,
          }
          console.log('右击事件')
          console.log(_this.exportDecParames)
        })
      })
    },
    // 坐席平均静默时长TOP5(s)
    averageSilenceTopsChart(data) {
      // 修改返回值类型为List
      console.info(data)
      let YArr = []
      let idArr = []
      let seriseArr = []
      for (let i = data.length - 1; i >= 0; i--) {
        let item = data[i].count
        let seatNo = data[i].seatNo
        let seatName = data[i].seatName
        YArr.push(seatName)
        idArr.push(seatNo)
        seriseArr.push({
          value: item,
          id: seatNo,
        })
      }
      console.info(seriseArr)
      /* let YArr = []
        let idArr = []
        for (let key in data.seats) {
          YArr.push(data.seats[key])
          idArr.push(key)
        }
        let seriseArr = []
        for (let i = 0; i < data.silences.length; i++) {
          let item = data.silences[i]
          seriseArr.push({
            value: item,
            id: idArr[i]
          })
        } */
      let itemStyle = {
        normal: {},
        emphasis: {
          barBorderWidth: 1,
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowOffsetY: 0,
          shadowColor: 'rgba(0,0,0,0.1)',
        },
      }
      let _this = this
      let option = {
        color: colorList,
        title: {
          text: '坐席平均静默时长Top5',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
          formatter: function(parames) {
            let res = ''
            res +=
              '<span>' +
              parames[0].name +
              '平均静默时长' +
              ' :' +
              parames[0].data.value +
              's' +
              '</span>'
            return res
          },
          position: function(pos, params, el, elRect, size) {
            let obj = { top: 10 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30
            return obj
          },
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = option
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('fiveBlock')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow5 = true
              },
            },
          },
        },
        grid: {
          left: 10,
          top: 80,
          bottom: 0,
          right: 0,
          containLabel: true,
        },
        xAxis: {
          type: 'value',
          splitLine: {
            show: false,
          },
          axisLabel: {
            inside: true,
            textStyle: {
              color: '#fff',
            },
          },
          axisTick: {
            show: false,
          },
          axisLine: {
            show: false,
          },
        },
        yAxis: {
          type: 'category',
          splitLine: { show: false },
          data: YArr,
        },
        series: [
          {
            type: 'bar',
            itemStyle: itemStyle,
            label: {
              normal: {
                position: 'right',
                show: true,
              },
            },
            data: seriseArr,
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.querySelector('#averageSilenceTops'))
        myChart.clear()
        myChart.setOption(option)
        myChart.on('click', function(params) {
          _this.qaUsers = params.data.id
          _this.handleSingleSeat(params.name, params.data.id, 'silence')
        })
        // echart 右击事件，导出明细
        myChart.getZr().on('contextmenu', function(param) {
          let pointInPixel = [param.offsetX, param.offsetY]
          if (myChart.containPixel('grid', pointInPixel)) {
            let xIndex = myChart.convertFromPixel({ seriesIndex: 0 }, [
              param.offsetX,
              param.offsetY,
            ])[1]
            let menu = document.getElementById('exportDec5')
            let event = param.event
            let pageX = event.offsetX
            let pageY = event.offsetY
            menu.style.left = pageX + 'px'
            menu.style.top = pageY + 'px'
            menu.style.display = 'block'
            _this.isTimeNull(_this.searchForm.fiveTimer)
            _this.exportDecParames = {
              startTime: formatdate.formatDate(_this.timeArr[0]),
              endTime: formatdate.formatDate(_this.timeArr[1]),
              seatNo: seriseArr[xIndex].id,
            }
            console.log('右击事件')
            console.log(_this.exportDecParames)
          }
        })
      })
    },
    // 申诉率
    drawEcharts(id, option) {
      document.getElementById(id).setAttribute('_echarts_instance_', '')
      let myChart = this.$echarts.init(document.getElementById(id))
      myChart.setOption(option)
      // echart 右击事件，导出明细
      let _this = this
      if (id == 'appRateQA') {
        myChart.on('contextmenu', function(param) {
          console.log(param)
          let menu = document.getElementById('exportDec6')
          let event = param.event
          let pageX = event.offsetX
          let pageY = event.offsetY
          menu.style.left = pageX + 'px'
          menu.style.top = pageY + 'px'
          if (param.data.apType !== 0) {
            menu.style.display = 'block'
          }
          console.log(_this.timeArr)
          let start = _this.initTime[0]
          let end = _this.initTime[1]
          _this.exportDecParames = {
            apType: param.data.apType,
            startTime: formatdate.formatDate(
              _this.timeArr.length === 0 ? start : _this.timeArr[0]
            ),
            endTime: formatdate.formatDate(
              _this.timeArr.length === 0 ? end : _this.timeArr[1]
            ),
          }
          console.log(_this.initTime)
          if (_this.searchForm.sixTimer[0]) {
            _this.exportDecParames.startTime = formatdate.formatDate(
              _this.searchForm.sixTimer[0]
            )
          }
          if (_this.searchForm.sixTimer[1]) {
            _this.exportDecParames.endTime = formatdate.formatDate(
              _this.searchForm.sixTimer[1]
            )
          }
          console.log('右击事件')
          console.log(_this.exportDecParames)
        })
      }
    },
    // 坐席申诉率TOP5
    appealRateTopsChart(data) {
      let YArr = []
      let idArr = []
      let seriseArr = []
      for (let i = 0; i < data.appeals.length; i++) {
        let item = data.appeals[i]
        let seatId = data.seatNames[i]
        idArr.unshift(seatId)
        YArr.unshift(data.seats[i])
        seriseArr.unshift({
          value: item,
          id: data.seatNames[i],
        })
      }
      let itemStyle = {
        normal: {},
        emphasis: {
          barBorderWidth: 1,
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowOffsetY: 0,
          shadowColor: 'rgba(0,0,0,0.1)',
        },
      }
      let maxValue = 200
      let _this = this
      let option = {
        color: colorList,
        title: {
          text: '坐席申诉率Top5',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
          formatter: function(parames) {
            let res = ''
            res += '<span>' + parames[0].name + ':' + parames[0].data.value + '%</span>'
            return res
          },
          position: function(pos, params, el, elRect, size) {
            let obj = { top: 10 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30
            return obj
          },
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTocol: {
              show: true,
              title: '放大按钮',
              icon: 'image://static/img/enLarge.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.otherValue.option = option
                this.otherValue.name = 'name'
                this.paryTasks = true
              },
            },
            saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('senvenBlock')
              },
            },
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow7 = true
              },
            },
          },
        },
        grid: {
          left: 10,
          top: 80,
          bottom: 0,
          right: 0,
          containLabel: true,
        },
        xAxis: {
          type: 'value',
          max: maxValue,
          splitLine: {
            show: false,
          },
          axisLabel: {
            inside: true,
            textStyle: {
              color: '#fff',
            },
          },
          axisTick: {
            show: false,
          },
          axisLine: {
            show: false,
          },
        },
        yAxis: {
          type: 'category',
          splitLine: { show: false },
          data: YArr,
        },
        series: [
          {
            type: 'bar',
            itemStyle: itemStyle,
            label: {
              normal: {
                position: 'right',
                show: true,
              },
            },
            data: seriseArr,
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.querySelector('#appealRateTops'))
        myChart.clear()
        myChart.setOption(option)
        myChart.on('click', function(params) {
          _this.qaUsers = params.data.id
          _this.handleSingleSeat(params.name, params.data.id, 'rate')
        })
        // echart 右击事件，导出明细
        myChart.getZr().on('contextmenu', function(param) {
          let pointInPixel = [param.offsetX, param.offsetY]
          if (myChart.containPixel('grid', pointInPixel)) {
            let xIndex = myChart.convertFromPixel({ seriesIndex: 0 }, [
              param.offsetX,
              param.offsetY,
            ])[1]
            let menu = document.getElementById('exportDec7')
            let event = param.event
            let pageX = event.offsetX
            let pageY = event.offsetY
            menu.style.left = pageX + 'px'
            menu.style.top = pageY + 'px'
            menu.style.display = 'block'
            _this.isTimeNull(_this.searchForm.senvenTimer)
            _this.exportDecParames = {
              startTime: formatdate.formatDate(_this.timeArr[0]),
              endTime: formatdate.formatDate(_this.timeArr[1]),
              seatNo: seriseArr[xIndex].id,             
            }
            console.log('右击事件')
            console.log(_this.exportDecParames)
          }
        })
      })
    },
    /*
     * 头部导出
     * */
    exportExcel(type) {
      let start = ''
      let end = ''
      let url = ''
      let params = {}
      if (type == 'firstBlock') {
        url = qualityUrl + '/report/inCallDataExport.do'
        if (this.searchForm.oneTimer.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.oneTimer[0]
          end = this.searchForm.oneTimer[1]
        }
      } else if (type == 'twoBlock') {
        url = qualityUrl + '/report/scoreDataExport.do'
        if (this.searchForm.twoTimer.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.twoTimer[0]
          end = this.searchForm.twoTimer[1]
        }
      } else if (type == 'threeBlock') {
        url = qualityUrl + '/statistic/errorRateExport.do'
        if (this.searchForm.threeTimer.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.threeTimer[0]
          end = this.searchForm.threeTimer[1]
        }
      } else if (type == 'fourBlock') {
        url = qualityUrl + '/statistic/deadItemExport.do'
        if (this.searchForm.fourTimer.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.fourTimer[0]
          end = this.searchForm.fourTimer[1]
        }
      } else if (type == 'fiveBlock') {
        url = qualityUrl + '/statistic/seatSilenceExport.do'
        if (this.searchForm.fiveTimer.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.fiveTimer[0]
          end = this.searchForm.fiveTimer[1]
        }
      } else if (type == 'sixBlock') {
        url = qualityUrl + '/appReport/exportSeatAppRateData.do'
        if (this.searchForm.sixTimer.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.sixTimer[0]
          end = this.searchForm.sixTimer[1]
        }
      } else if (type == 'senvenBlock') {
        url = qualityUrl + '/statistic/seatAppealRateExport.do'
        if (this.searchForm.senvenTimer.length == 0) {
          start = this.initTime[0]
          end = this.initTime[1]
        } else {
          start = this.searchForm.senvenTimer[0]
          end = this.searchForm.senvenTimer[1]
        }
      }
      if (type == 'sixBlock') {
        params = {
          startTime: formatdate.formatDate(start),
          endTime: formatdate.formatDate(end),
        }
      } else if (type == 'twoBlock') {
        params = {
          startTime: formatdate.formatDate(start),
          endTime: formatdate.formatDate(end),
          modelId: this.templateModel2,
          seatNos: this.selectedOgzation2,
        }
      } else if (type == 'threeBlock') {
        params = {
          startTime: formatdate.formatDate(start),
          endTime: formatdate.formatDate(end),
          modelId: this.templateModel3,
          seat: this.selectedOgzation3.toString(),
        }
      } else if (type == 'fourBlock') {
        params = {
          startTime: formatdate.formatDate(start),
          endTime: formatdate.formatDate(end),
          modelId: this.templateModel4,
          seat: this.selectedOgzation4.toString(),
        }
      } else {
        params = {
          startTime: formatdate.formatDate(start),
          endTime: formatdate.formatDate(end),
        }
      }
      console.log('111111111111111++++++++')
      console.log(params)
      console.log('111111111111111++++++++')
      commonUtil.doExport(url, params, global.jsonHeader)
    },
    /*
     * 导出明细
     * */
    exportPerDec(type, parames) {
      let url = ''
      if (type == '7') {
        url = qualityUrl + '/statistic/seatAppealDetailExport.do'
      }
      if (type == '6') {
        url = qualityUrl + '/appReport/exportSeatAppRateDetail.do'
      }
      if (type == '5') {
        url = qualityUrl + '/statistic/seatSilenceDetailExport.do'
      }
      if (type == '4') {
        url = qualityUrl + '/statistic/deadItemDetailExport.do'
      }
      if (type == '3') {
        url = qualityUrl + '/statistic/errorRateDetailExport.do'
      }
      if (type == '2') {
        url = qualityUrl + '/report/scoreDetailExport.do'
      }
      if (type == '1') {
        url = qualityUrl + '/report/inCallDetailExport.do'
      }
      let params = parames
      console.log(params)
      commonUtil.doExport(url, params, global.jsonHeader)
    },
    // 点击标准联动
    handleSingleNormal(name, id, type) {
      if (type == 'error') {
        if (this.searchForm.fourTimer.length == 0) {
          this.searchForm.fourTimer = this.initTime
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.fourTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.fourTimer[1]),
        }
        this.initSourceOfDeathData(params)
      }
      if (type == 'death') {
        if (this.searchForm.threeTimer.length == 0) {
          this.searchForm.threeTimer = this.initTime
        }
        let params = {
          startTime: formatdate.formatDate(this.searchForm.threeTimer[0]),
          endTime: formatdate.formatDate(this.searchForm.threeTimer[1]),
        }
        this.initErrorRateRadarMapData(params)
      }
    },
    // 点击坐席联动
    handleSingleSeat(name, id, type) {
      if (this.searchForm.twoTimer.length == 0) {
        this.searchForm.twoTimer = this.initTime
      }
      if (this.searchForm.threeTimer.length == 0) {
        this.searchForm.threeTimer = this.initTime
      }
      if (this.searchForm.fourTimer.length == 0) {
        this.searchForm.fourTimer = this.initTime
      }
      if (this.searchForm.fiveTimer.length == 0) {
        this.searchForm.fiveTimer = this.initTime
      }
      if (this.searchForm.senvenTimer.length == 0) {
        this.searchForm.senvenTimer = this.initTime
      }
      let params2 = {
        startTime: formatdate.formatDate(this.searchForm.twoTimer[0]),
        endTime: formatdate.formatDate(this.searchForm.twoTimer[1]),
      }
      let params3 = {
        startTime: formatdate.formatDate(this.searchForm.threeTimer[0]),
        endTime: formatdate.formatDate(this.searchForm.threeTimer[1]),
      }
      let params4 = {
        startTime: formatdate.formatDate(this.searchForm.fourTimer[0]),
        endTime: formatdate.formatDate(this.searchForm.fourTimer[1]),
      }
      let params5 = {
        startTime: formatdate.formatDate(this.searchForm.fiveTimer[0]),
        endTime: formatdate.formatDate(this.searchForm.fiveTimer[1]),
        seatNo: this.qaUsers,
      }
      let params7 = {
        startTime: formatdate.formatDate(this.searchForm.senvenTimer[0]),
        endTime: formatdate.formatDate(this.searchForm.senvenTimer[1]),
        seatNo: this.qaUsers,
      }
      if (type == 'silence') {
        this.initScoreData(params2)
        this.initErrorRateRadarMapData(params3)
        this.initSourceOfDeathData(params4)
        this.initAppealRateTopsData(params7)
      }
      if (type == 'rate') {
        this.initScoreData(params2)
        this.initErrorRateRadarMapData(params3)
        this.initSourceOfDeathData(params4)
        this.initAverageSilenceTopsData(params5)
      }
    },
  },
  mounted: function() {},
  created() {
    this.initChartData()
  },
}
</script>
<style lang="less">
.SeatReport {
  position: relative;
  th {
    background-color: #e0e6ed;
    color: #475669;
    padding: 10px 0;
  }
  #exportDec1,
  #exportDec2,
  #exportDec3,
  #exportDec4,
  #exportDec5,
  #exportDec6,
  #exportDec7 {
    width: 100px;
    height: 40px;
    background-color: rgba(0, 0, 0, 0.5);
    position: absolute;
    text-align: center;
    .el-button.btn {
      color: #fff;
    }
  }
  .echartWrap {
    div {
      overflow-x: auto !important;
    }
  }
}

.el-popover.el-popper.popperHover {
  border: none;
  background: none;
  box-shadow: none;
  color: #3b90bf;
  font-size: 12px;
  top: 135px !important;
  padding: 0;
  margin: 0;
  min-width: 50px;
  text-align: center;
  &.popperBeishensulv {
    text-align: right;
    margin-right: 13px;
  }
}
.tableDealog {
  .el-tabs__nav {
    margin-left: 10px;
  }
}
.tableDealog3 {
  .el-tabs__item {
    padding: 0 10px;
  }
  .el-radio + .el-radio {
    margin-left: 20px;
  }
}
</style>
<style lang="less" scoped>
.SeatReport {
  width: 100%;
  height: 100%;
  background: #fff;
  padding: 0 18px;
  box-sizing: border-box;
  .header {
    height: 50px;
    display: flex;
    flex-direction: row-reverse;
    align-items: center;
    .icon {
      font-size: 30px;
      cursor: pointer;
    }
  }
  .content {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: calc(~'100% - 50px');
    .content-line {
      display: flex;
      flex: 1;
      flex-direction: row;
      flex-wrap: nowrap;
      justify-content: space-between;
      margin-bottom: 10px;
      .item {
        display: flex;
        flex-direction: column;
        padding: 0 10px 10px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        overflow: auto;
        position: relative;
        .echartWrap {
          display: flex;
          flex: 1;
          justify-content: center;
          align-items: center;
          overflow: auto;
        }
        &.item1 {
          flex: 3;
        }
        &.item2 {
          margin: 0 10px;
          flex: 5;
        }
        &.item3 {
          flex: 2;
        }
        &.item4 {
          flex: 1;
        }
        &.item5 {
          flex: 1;
          margin: 0 10px;
        }
        &.item6 {
          flex: 1;
        }
        &.item7 {
          flex: 1;
        }
      }
    }
  }
}

.tableDealog {
  width: 98%;
  height: 240px;
  border: 1px solid #d1d9e2;
  border-radius: 4px;
  position: absolute;
  left: 1%;
  top: 2%;
  background: #fff;
  z-index: 1999;
  .aloneTitle {
    height: 45px;
    font-size: 14px;
    line-height: 45px;
    width: 100%;
    border-bottom: 1px solid #d1d9e2;
  }
  .aloneFooter {
    text-align: right;
    height: 45px;
    margin-top: 20px;
    padding-top: 5px;
    border-top: 1px solid #d1d9e2;
    line-height: 45px;
    &.aloneFooterS {
      margin-top: 10px;
    }
  }
}
</style>
