<template>
  <div style="height: 90%" class="reportToLarge">
    <div class="reportContent">
      <img src="../../../assets/img/narrow.png" class="editIcon" @click="gobackContent" />
    </div>
    <div
      id="ceshiImg"
      style="height: 100%;width: 100%;padding:20px;box-sizing: border-box;"
    ></div>
  </div>
</template>
<script>
export default {
  props: ['message'],
  data() {
    return {
      index: {},
    }
  },
  methods: {
    gobackContent() {
      this.$emit('send', true)
    },
  },
  mounted: function() {
    console.log(this.message)
    this.index = this.message.option
    // let self = this
    this.message.option.toolbox.show = false
    document.getElementById('ceshiImg').setAttribute('_echarts_instance_', '')
    let myChart = this.$echarts.init(document.getElementById('ceshiImg'))
    myChart.setOption(this.index)
  },
  created() {},
}
</script>
<style lang="less" scoped="scoped">
.reportToLarge {
  .reportContent {
    height: 50px;
    line-height: 50px;
    .editIcon {
      float: right;
      margin-right: 20px;
      margin-top: 10px;
      font-size: 26px;
      cursor: pointer;
      width: 20px;
      height: 20px;
    }
  }
}
</style>
