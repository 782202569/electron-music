<template>
  <div style="height: 90%" class="reportToLarge">
    <div class="reportContent">
      <img src="../../../assets/img/narrow.png" class="editIcon" @click="gobackContent" />
    </div>
    <div v-if="this.message.name == 'beishensulv'" class="tableWrap">
      <div class="title">评分被申诉率</div>
      <zk-table
        ref="table1"
        sum-text="sum"
        index-text="#"
        :data="tableDataShenSu"
        :columns="ShenSuColumns"
        :stripe="props.stripe"
        :border="props.border"
        :show-header="props.showHeader"
        :show-summary="props.showSummary"
        :show-row-hover="props.showRowHover"
        :show-index="props.showIndex"
        :tree-type="props.treeType"
        :is-fold="props.isFold"
        :expand-type="props.expandType"
        :selection-type="props.selectionType"
      >
        <template slot="zjyName" scope="scope">
          {{ scope.row.zjyName }}
        </template>
        <template slot="persent" scope="scope">
          {{ scope.row.persent }}
        </template>
      </zk-table>
    </div>
    <div v-if="this.message.name == 'generation'" class="tableWrap">
      <div class="qaReport-dec">
        <div class="dec-item">
          <p class="dec-item-top">
            <span>入库量</span>
          </p>
          <p class="dec-item-bottom">
            <span class="bottomCount">{{ generationData.insertEsTotalCount }}</span>
            <span class="right-count">{{ generationData.insertEsChain }}</span>
          </p>
        </div>
        <div class="dec-item">
          <p class="dec-item-top">
            <span>初检量</span>
          </p>
          <p class="dec-item-bottom">
            <span class="bottomCount">{{ generationData.firstQaTotalCount }}</span>
            <span class="right-count">{{ generationData.firstQaTotalCountChain }}</span>
          </p>
        </div>
        <div class="dec-item">
          <p class="dec-item-top">
            <span>复检量</span>
          </p>
          <p class="dec-item-bottom">
            <span class="bottomCount">{{ generationData.secondQaTotalCount }}</span>
            <span class="right-count">{{ generationData.secondQaTotalCountChain }}</span>
          </p>
        </div>
        <div class="dec-item dec-item-last">
          <p class="dec-item-top">
            <span>逾期量</span>
          </p>
          <p class="dec-item-bottom">
            <span class="bottomCount">{{ generationData.overdueTotalCount }}</span>
            <span class="right-count">{{ generationData.overdueTotalCountChain }}</span>
          </p>
        </div>
      </div>
      <div class="qaReport-table">
        <zk-table
          ref="table"
          sum-text="sum"
          index-text="#"
          :data="qaQualityReportResults"
          :columns="columns"
          :stripe="props.stripe"
          :border="props.border"
          :show-header="props.showHeader"
          :show-summary="props.showSummary"
          :show-row-hover="props.showRowHover"
          :show-index="props.showIndex"
          :tree-type="props.treeType"
          :is-fold="props.isFold"
          :expand-type="props.expandType"
          :selection-type="props.selectionType"
        >
          <template slot="firstQualityCount" scope="scope">
            {{ scope.row.firstQualityCount }}
          </template>
          <template slot="secondQualityCount" scope="scope">
            {{ scope.row.secondQualityCount }}
          </template>
          <template slot="qualityOverDueCount" scope="scope">
            {{ scope.row.qualityOverDueCount }}
          </template>
        </zk-table>
      </div>
    </div>
    <div v-else id="ceshiImg" style="height: 100%;width: 100%;"></div>
  </div>
</template>
<script>
import ZkTable from 'vue-table-with-tree-grid'
import global from '../../../global.js'
let qualityUrl = global.qualityUrl
import Qs from 'qs'
export default {
  props: ['message'],
  components: {
    ZkTable,
  },
  data() {
    return {
      index: {},
      tableDataShenSu: [],
      qaQualityReportResults: [],
      generationData: {},
      columns: [
        {
          label: '质检员姓名',
          prop: 'qaUserName',
          width: '100px',
        },
        {
          label: '上岗天数',
          prop: 'workDays',
        },
        {
          label: '初检量',
          prop: 'firstQualityCount',
        },
        {
          label: '复检量',
          prop: 'secondQualityCount',
        },
        {
          label: '逾期量',
          prop: 'qualityOverDueCount',
        },
      ],
      ShenSuColumns: [
        {
          label: '质检员姓名',
          prop: 'zjyName',
          width: '100px',
        },
        {
          label: '被申诉率',
          prop: 'persent',
        },
      ],
      props: {
        stripe: false,
        border: true,
        showHeader: true,
        showSummary: false,
        showRowHover: false,
        showIndex: false,
        treeType: false,
        isFold: true,
        expandType: false,
        selectionType: false,
      },
    }
  },
  methods: {
    gobackContent() {
      this.$emit('send', true)
    },
  },
  computed: {},
  mounted: function() {
    this.index = this.message.option
    let self = this
    if (this.message.name == 'beishensulv') {
      // 质检被申诉率
      console.log(this.message.option)
      this.axios
        .post(qualityUrl + '/appReport/getQABeAppedRate.do', Qs.stringify(this.index))
        .then(function(res) {
          if (res.data) {
            self.tableDataShenSu = res.data.Data
          }
        })
    } else if (this.message.name == 'generation') {
      // 总览
      console.log(this.message.option)
      this.axios
        .post(qualityUrl + '/qualityReport/totalData.do', Qs.stringify(this.index))
        .then(function(res) {
          if (res.data) {
            self.generationData = res.data.Data
            self.qaQualityReportResults =
              res.data.Data.qaQualityReportResults == null
                ? []
                : res.data.Data.qaQualityReportResults
          }
        })
    } else {
      this.message.option.toolbox.show = false
      document.getElementById('ceshiImg').setAttribute('_echarts_instance_', '')
      let myChart = this.$echarts.init(document.getElementById('ceshiImg'))
      myChart.setOption(this.index)
    }
  },
  created() {},
}
</script>
<style lang="less" scoped="scoped">
.reportToLarge {
  .reportContent {
    height: 50px;
    line-height: 50px;
    .editIcon {
      float: right;
      margin-right: 20px;
      margin-top: 10px;
      font-size: 26px;
      cursor: pointer;
      width: 20px;
      height: 20px;
    }
  }
  .tableWrap {
    width: 100%;
    height: 100%;
    padding: 18px;
    box-sizing: border-box;
    .title {
      margin-bottom: 10px;
    }
    .qaReport-dec {
      display: flex;
      flex-direction: row;
      height: 100px;
      .dec-item {
        display: flex;
        flex-direction: column;
        flex: 1;
        height: 100%;
        margin-right: 20px;
        &.dec-item-last {
          margin: 0;
        }
        .dec-item-top {
          height: 50%;
          flex: 1;
          display: flex;
          flex-direction: row;
        }
        .dec-item-bottom {
          height: 50%;
          flex: 1;
          display: flex;
          flex-direction: row;
          .bottomCount {
            font-size: 22px;
          }
          .right-count {
            flex: 1;
            margin: 0 0 22px 12px;
          }
        }
      }
    }
    .qaReport-table {
      flex: 1;
      overflow: auto;
    }
  }
}
</style>
