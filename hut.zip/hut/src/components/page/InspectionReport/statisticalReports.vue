<template>
  <div class="statisticalReports" id="statisticalReports">
    <div class="top">
      <div class="box" v-show="isShowTop">
        <el-select v-model="treeValue" placeholder="请选择" @change="changeTree">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
        <el-date-picker
          class="ml10"
          :default-time="['00:00:00', '23:59:59']"
          v-model="times"
          :clearable="clearable"
          type="datetimerange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          @change="dateChange"
        >
        </el-date-picker>
        <span class="refresh">
          <i @click="refreshData" class="el-icon-refresh icon"></i>
        </span>
      </div>
    </div>
    <div class="content">
      <div class="flexContent">
        <div id="leftview" style="height: 100%; position: relative">
          <div style="height: 100%; width: 100%; overflow: auto;">
            <div id="sunEchart" style="height: 100%; width: 100%;"></div>
          </div>
          <div
            id="exportTitle3"
            style="display: none"
            onMouseLeave="this.style.display = 'none';"
          >
            <el-button
              @click="exportSunData(exportBussessParames)"
              type="text"
              class="btn"
              >导出明细</el-button
            >
          </div>
          <div id="viewRadio">
            <el-radio-group v-model="viewRadio" @change="radioClick">
              <el-radio-button label="常规视图"></el-radio-button>
              <el-radio-button label="情绪视图"></el-radio-button>
              <el-radio-button label="涨跌趋势视图"></el-radio-button>
            </el-radio-group>
          </div>
          <div id="legend">
            <ul>
              <li><span class="span1"></span>业务量增长</li>
              <li><span class="span2"></span>业务量持平</li>
              <li><span class="span3"></span>业务量下跌</li>
            </ul>
          </div>
          <div id="emotion">
            <ul>
              <li><span class="span4"></span>积极情绪</li>
              <li><span class="span2"></span>正常情绪</li>
              <li><span class="span5"></span>消极情绪</li>
            </ul>
          </div>
        </div>
        <div id="rightview">
          <curveReport
            @bigViewShow="bigViewShow"
            :title="title"
            :clickName="clickName"
            :urlOther="urlOther"
            :isData="isData"
            :treeId="treeId"
            :times="times"
            :isBigShow="isBigShow"
            :showItemName="showItemName"
          ></curveReport>
        </div>
      </div>
    </div>
    <div id="homeShow" @click="smallShow">
      <img src="../../../assets/img/narrow.png" />
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import global from '@/global'
import formatdate from '../../../utils/formatdate.js'
import sunLineTool from '../../../utils/sunEchartsTool'
import curveReport from './curveReport.vue'
let currentBaseUrl = global.currentBaseUrl
let options = null
options = sunLineTool
let sunEcharts
export default {
  components: {
    curveReport,
  },
  data() {
    return {
      title: '',
      urlOther: false,
      viewRadio: '常规视图',
      showItemName: '',
      itemName: '',
      isShowTop: true,
      options: [],
      clearable: false,
      treeValue: '',
      getFirstreeid: '',
      treeId: '',
      isData: true,
      clickName: '',
      treePid: '',
      times: [],
      treeViewData: [],
      startDate: '',
      isBigSmall: true,
      endDate: '',
      newData: [],
      sunData: [],
      isBigShow: false,
      exportBussessParames: {},
    }
  },
  mounted() {
    this.getTree()
    this.getThisMonthDate()
  },
  methods: {
    getRandomColor() {
      return '#' + ('00000' + ((Math.random() * 0x1000000) << 0).toString(16)).slice(-6)
    },
    changeTree(value) {
      let that = this
      that.urlOther = false
      that.treeId = value
      that.treePid = value
      that.isData = false
      that.clickName = ''
      if (this.viewRadio === '常规视图') {
        that.gettreeViewBySortID(this.treeId)
      } else if (this.viewRadio === '情绪视图') {
        that.sentimentView()
      } else {
        that.getTrendView()
      }
    },
    // 涨跌趋势视图
    getTrendView() {
      let that = this
      sunEcharts = that.$echarts.init(document.getElementById('sunEchart'))
      sunEcharts.resize()
      sunEcharts.clear()
      sunEcharts.showLoading()
      let minDate = JSON.stringify(
        new Date(this.times[0].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let maxDate = JSON.stringify(
        new Date(this.times[1].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let params = {
        sortID: this.treePid,
        callSTimeMin: minDate,
        callSTimeMax: maxDate,
      }
      this.axios
        .get(currentBaseUrl + '/report/trendView/', { params })
        .then(function(res) {
          sunEcharts.hideLoading()
          let shuzuList = []
          if (res.data.data !== null) {
            let childs = res.data.data.children
            let color1 = ''
            let color2 = ''
            let radioNum = [] // 所有平级录音count的数量的集合
            let total = 0 // 所有平级录音总数
            let oneNum = 0 // 除了其他分类的count总数
            for (let p = 0; p < childs.length; p++) {
              radioNum.push(childs[p].count)
            }
            for (let u = 0; u < radioNum.length; u++) {
              oneNum += radioNum[u]
            }
            total = oneNum + res.data.data.otherCount
            for (let i = 0; i < childs.length; i++) {
              let nums = 0
              nums = (childs[i].count / total) * 100
              if (childs[i].percent == null) {
                color1 = '#cccccc'
              } else {
                if (childs[i].percent > 0) {
                  color1 = '#52B4FC'
                }
                if (childs[i].percent < 0) {
                  color1 = '#FFCC00'
                }
                if (childs[i].percent == 0) {
                  color1 = '#cccccc'
                }
              }
              shuzuList[i] = {
                itemStyle: {
                  color: color1,
                },
                allParentSortName: childs[i].allParentSortName,
                otherCount: childs[i].otherCount,
                sortName: childs[i].sortName,
                sortID: childs[i].sortID == null ? childs[i].parentID : childs[i].sortID,
                count: childs[i].count,
                name: childs[i].sortName,
                value: (childs[i].count / total) * 100,
                percent: childs[i].percent,
                children: that.getChild(
                  'viewTwo',
                  childs[i].children == null ? [{}] : childs[i].children,
                  [],
                  childs[i],
                  nums
                ),
              }
              if (res.data.data.otherCount > 0) {
                if (res.data.data.otherPercent == null) {
                  color2 = '#cccccc'
                } else {
                  if (res.data.data.otherPercent > 0) {
                    color2 = '#52B4FC'
                  }
                  if (res.data.data.otherPercent < 0) {
                    color2 = '#FFCC00'
                  }
                  if (res.data.data.otherPercent == 0) {
                    color2 = '#cccccc'
                  }
                }
                shuzuList[childs.length] = {
                  itemStyle: {
                    color: color2,
                  },
                  allParentSortName: res.data.data.allParentSortName,
                  name: '其他',
                  sortName: res.data.data.sortName,
                  otherCount: res.data.data.otherCount,
                  percent: res.data.data.otherPercent,
                  sortID: res.data.data.sortID,
                  count: res.data.data.otherCount,
                  value: (res.data.data.otherCount / total) * 100,
                  children: [{}],
                }
              }
            }
            options.series.data = shuzuList
            options.tooltip = {
              trigger: 'item',
              formatter: function(data) {
                let str = ''
                let count
                if (data.data.count == undefined) {
                  str = ''
                } else {
                  count = data.data.count
                  if (data.data.percent == null) {
                    str = data.name + '<br/>' + '共' + count + '通录音' + ':' + '--'
                  } else {
                    if (data.data.percent > 0) {
                      str =
                        data.name +
                        '<br/>' +
                        '共' +
                        count +
                        '通录音' +
                        ':' +
                        '+' +
                        (data.data.percent.toFixed(2) + '%')
                    } else {
                      str =
                        data.name +
                        '<br/>' +
                        '共' +
                        count +
                        '通录音' +
                        ':' +
                        (data.data.percent.toFixed(2) + '%')
                    }
                  }
                }
                return str
              },
            }
            if (that.isBigSmall === true) {
              options.toolbox.show = true
            }
            sunEcharts.setOption(options)
            sunEcharts.on('click', function(params) {
              let options = that.options
              let treeValue = that.treeValue
              const selectedTree = options.filter((item) => item.value === treeValue)
              that.isData = false
              if (params.name == '') {
                // that.getTreePid()
              } else {
                const treePathInfo = params.treePathInfo
                let path = ''
                treePathInfo.forEach((info) => {
                  if (info.name != '') {
                    path += '/' + info.name
                  }
                })
                that.clickName = selectedTree[0].label + path
                if (params.name === '其他') {
                  that.urlOther = true
                } else {
                  that.urlOther = false
                }
                that.getTreeId(params.data.sortID)
              }
            })
            sunEcharts.on('contextmenu', function(param) {
              that.exportBussessParames = {
                title: param.name,
                sortID: param.data.sortID,
                loadType: 'zhangdie',
              }
              that.urlOther = true
              console.log('右击事件')
              console.log(that.exportBussessParames)
            })
          } else {
            sunEcharts.hideLoading()
          }
        })
        .catch(() => {})
    },
    getTree() {
      this.axios({
        method: 'get',
        url: currentBaseUrl + '/recordSort/trees',
        headers: { accessToken: this.$store.state.token },
      })
        .then((response) => {
          let datalist = response.data.data
          for (let i = 0; i < datalist.length; i++) {
            let dataH = {}
            dataH.value = datalist[i].sortID
            dataH.label = datalist[i].sortName
            this.options.push(dataH)
          }
          this.treeValue = datalist[0].sortID
          this.getFirstreeid = datalist[0].sortID
          this.treeId = datalist[0].sortID
          this.treePid = datalist[0].sortID
          console.log(this.treeId)
          if (this.viewRadio === '常规视图') {
            this.gettreeViewBySortID(this.treeValue)
          } else if (this.viewRadio === '情绪视图') {
            this.sentimentView()
          } else {
            this.getTrendView()
          }
        })
        .catch(() => {})
    },
    // 常规视图
    gettreeViewBySortID(sortid) {
      let that = this
      sunEcharts = that.$echarts.init(document.getElementById('sunEchart'))
      sunEcharts.resize()
      sunEcharts.clear()
      sunEcharts.showLoading()
      let params = {}
      let minDate = JSON.stringify(
        new Date(this.times[0].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let maxDate = JSON.stringify(
        new Date(this.times[1].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      params.callSTimeMin = minDate
      params.callSTimeMax = maxDate
      this.axios
        .get(currentBaseUrl + '/recordSort/trees' + '/' + sortid, { params })
        .then(function(res) {
          let shuzuList = []
          sunEcharts.hideLoading()
          if (res.data.data !== null) {
            let childs = res.data.data.children
            let totalcount = res.data.data.count
            let nums = []
            let allnums = 0
            let strnums = 0
            for (let p = 0; p < childs.length; p++) {
              nums.push(childs[p].count)
            }
            for (let u = 0; u < nums.length; u++) {
              strnums += nums[u]
            }
            allnums = strnums + res.data.data.otherCount
            for (let i = 0; i < childs.length; i++) {
              let onenums = 0
              onenums = (childs[i].count / allnums) * 100
              shuzuList[i] = {
                allParentSortName: childs[i].allParentSortName,
                otherCount: childs[i].otherCount,
                sortName: childs[i].sortName,
                count: childs[i].count,
                name: childs[i].sortName,
                sortID: childs[i].sortID,
                value: (childs[i].count / allnums) * 100,
                children: that.getChild(
                  'view',
                  childs[i].children == null ? [{}] : childs[i].children,
                  [],
                  childs[i],
                  onenums
                ),
              }
            }
            if (res.data.data.otherCount > 0) {
              shuzuList[childs.length] = {
                allParentSortName: res.data.data.allParentSortName,
                name: '其他',
                sortName: res.data.data.sortName,
                otherCount: res.data.data.otherCount,
                sortID: res.data.data.sortID,
                count: res.data.data.otherCount,
                value: (res.data.data.otherCount / allnums) * 100,
                children: [{}],
              }
            }
            options.series.data = shuzuList
            let toolbox = {
              show: that.isBigSmall,
              right: '50',
              feature: {
                myTool1: {
                  show: true,
                  title: '放大旭日图',
                  icon: 'image://static/img/enLarge.png',
                  onclick: () => {
                    that.bigViewShow('sunItem')
                  },
                },
                saveAsImage: {
                  icon: 'image://static/img/downLoad.png',
                  name: '旭日图',
                },
              },
            }
            options.toolbox = toolbox
            options.tooltip = {
              trigger: 'item',
              formatter(data) {
                let nums = (data.data.count / totalcount) * 100
                if (data.data.count == undefined) {
                } else {
                  return (
                    data.name +
                    '<br/>' +
                    '共' +
                    data.data.count +
                    '通录音' +
                    '：' +
                    nums.toFixed(2) +
                    '%'
                  ) // 将小数转化为百分数显示
                }
              },
            }
            sunEcharts.setOption(options)
            sunEcharts.on('click', function(params) {
              let options = that.options
              let treeValue = that.treeValue
              const selectedTree = options.filter((item) => item.value === treeValue)
              that.isData = false
              console.log(params)
              if (params.name == '') {
                // that.getTreePid()
              } else {
                const treePathInfo = params.treePathInfo
                let path = ''
                treePathInfo.forEach((info) => {
                  if (info.name != '') {
                    path += '/' + info.name
                  }
                })
                that.clickName = selectedTree[0].label + path
                if (params.name === '其他') {
                  that.urlOther = true
                } else {
                  that.urlOther = false
                }
                that.getTreeId(params.data.sortID)
              }
            })
            sunEcharts.on('contextmenu', function(param) {
              console.info(param)
              let menu = document.getElementById('exportTitle3')
              let event = param.event
              let pageX = event.offsetX
              let pageY = event.offsetY
              menu.style.left = pageX + 'px'
              menu.style.top = pageY + 30 + 'px'
              menu.style.display = 'block'
              that.exportBussessParames = {
                title: param.name,
                sortID: param.data.sortID,
                loadType: 'normal',
              }
              // that.urlOther = true
              console.log('右击事件')
              console.log(that.exportBussessParames)
            })
          } else {
            sunEcharts.hideLoading()
          }
        })
    },
    getTreePid() {
      this.treeId = this.treePid
      console.log(this.treeId)
    },
    getTreeId(sortid) {
      let that = this
      that.treeId = sortid
    },
    getChild(type, value, treeList, parent, zhanbi) {
      let that = this
      let color1 = ''
      let color2 = ''
      let zhanbiDatas = []
      let zhanbiNums = 0 // 计算二级的占比
      let allzhanbiNums = 0
      for (let p = 0; p < value.length; p++) {
        zhanbiDatas.push(value[p].count)
      }
      for (let u = 0; u < zhanbiDatas.length; u++) {
        zhanbiNums += zhanbiDatas[u]
      }
      allzhanbiNums = zhanbiNums + parent.otherCount
      for (let i = 0; i < value.length; i++) {
        let secondzhanbi = 0
        secondzhanbi = (value[i].count / allzhanbiNums) * zhanbi
        if (type === 'viewTwo') {
          if (value[i].percent == null) {
            color1 = '#cccccc'
          } else {
            if (value[i].percent > 0) {
              color1 = '#52B4FC'
            }
            if (value[i].percent < 0) {
              color1 = '#FFCC00'
            }
            if (value[i].percent == 0) {
              color1 = '#cccccc'
            }
          }
          treeList[i] = {
            itemStyle: {
              color: color1,
            },
            allParentSortName: value[i].allParentSortName,
            sortName: value[i].sortName,
            otherCount: value[i].otherCount,
            count: value[i].count,
            sortID: value[i].sortID,
            percent: value[i].percent,
            name: value[i].sortName,
            value: (value[i].count / allzhanbiNums) * zhanbi,
            children: that.getChild(
              'viewTwo',
              value[i].children == null ? [{}] : value[i].children,
              [],
              value[i],
              secondzhanbi
            ),
          }
          if (parent.otherCount > 0) {
            if (parent.otherPercent == null) {
              color2 = '#cccccc'
            } else {
              if (parent.otherPercent > 0) {
                color2 = '#52B4FC'
              }
              if (parent.otherPercent < 0) {
                color2 = '#FFCC00'
              }
              if (parent.otherPercent == 0) {
                color2 = '#cccccc'
              }
            }
            treeList[value.length] = {
              name: '其他',
              itemStyle: {
                color: color2,
              },
              otherCount: parent.otherCount,
              allParentSortName: parent.allParentSortName,
              sortName: parent.sortName,
              percent: parent.otherPercent,
              sortID: parent.sortID,
              count: parent.otherCount,
              value: (parent.otherCount / allzhanbiNums) * zhanbi,
              children: [{}],
            }
          }
        } else {
          let secondzhanbi = 0
          secondzhanbi = (value[i].count / allzhanbiNums) * zhanbi
          treeList[i] = {
            name: value[i].sortName,
            count: value[i].count,
            otherCount: value[i].otherCount,
            sortName: value[i].sortName,
            sortID: value[i].sortID,
            allParentSortName: value[i].allParentSortName,
            value: (value[i].count / allzhanbiNums) * zhanbi,
            children: that.getChild(
              'view',
              value[i].children == null ? [{}] : value[i].children,
              [],
              value[i],
              secondzhanbi
            ),
          }
          if (parent.otherCount > 0) {
            treeList[value.length] = {
              name: '其他',
              otherCount: parent.otherCount,
              sortName: parent.sortName,
              allParentSortName: parent.allParentSortName,
              sortID: parent.sortID == null ? parent.parentID : parent.sortID,
              count: parent.otherCount,
              value: (parent.otherCount / allzhanbiNums) * zhanbi,
              children: [{}],
            }
          }
        }
      }
      if (treeList.length == 0) {
        treeList = [{}]
      }
      return treeList
    },
    radioClick(val) {
      let that = this
      that.clickName = ''
      this.viewRadio = val
      if (val === '涨跌趋势视图') {
        $('#legend').show()
        $('#emotion').hide()
        that.title = 'qushi'
        that.getTrendView()
      } else if (val === '常规视图') {
        $('#legend').hide()
        $('#emotion').hide()
        that.title = 'normal'
        that.gettreeViewBySortID(this.treePid)
      } else {
        $('#emotion').show()
        $('#legend').hide()
        that.sentimentView()
        that.title = 'qingxu'
      }
      this.urlOther = false
      that.treeId = JSON.parse(JSON.stringify(that.treePid))
    },
    // 情绪视图
    sentimentView() {
      let that = this
      sunEcharts = that.$echarts.init(document.getElementById('sunEchart'))
      sunEcharts.resize()
      sunEcharts.clear()
      sunEcharts.showLoading()
      let minDate = JSON.stringify(
        new Date(this.times[0].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let maxDate = JSON.stringify(
        new Date(this.times[1].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let params = {
        sortId: this.treePid,
        callSTimeMin: minDate,
        callSTimeMax: maxDate,
      }
      this.axios
        .get(currentBaseUrl + '/report/sentimentView/list/', { params })
        .then(function(res) {
          let shuzuList = []
          if (res.data.data !== null) {
            if (res.data.data.children !== null) {
              let childs = res.data.data.children
              let totalcount = res.data.data.count
              let color1 = ''
              let radioNum = [] // 所有平级录音count的数量的集合
              let total = 0 // 所有平级录音总数
              let oneNum = 0 // 除了其他分类的count总数
              for (let p = 0; p < childs.length; p++) {
                radioNum.push(childs[p].count)
              }
              for (let u = 0; u < radioNum.length; u++) {
                oneNum += radioNum[u]
              }
              // total = oneNum + res.data.data.otherCount
              total = oneNum
              for (let i = 0; i < childs.length; i++) {
                let nums = 0
                nums = (childs[i].count / total) * 100

                /*
                * 积极 = 消极 = 0 灰色
                * 积极 > 消极 绿色
                * 积极 < 消极 || 积极 === 消极 红色
                * */
                if(childs[i].activeCount === 0 && childs[i].passiveCount ===  0) {
                  color1 = '#CCCCCC'
                } else if (childs[i].activeCount >  childs[i].passiveCount) {
                  color1 = '#12A037'
                } else {
                  color1 = '#FF0000'
                }
                shuzuList[i] = {
                  itemStyle: {
                    color: color1,
                  },
                  allParentSortName: childs[i].allParentSortName,
                  sortName: childs[i].sortName,
                  otherCount: childs[i].otherCount,
                  count: childs[i].count,
                  sortID:
                    childs[i].sortID == null ? childs[i].parentID : childs[i].sortID,
                  sentimentView: childs[i].sentimentView,
                  passiveCount: childs[i].passiveCount,
                  normalCount: childs[i].normalCount,
                  activeCount: childs[i].activeCount,
                  name: childs[i].sortName,
                  value: (childs[i].count / total) * 100,
                  children: that.getEmotionChild(
                    childs[i].children == null ? [{}] : childs[i].children,
                    [],
                    childs[i],
                    nums
                  ),
                }
              }
              sunEcharts.hideLoading()
              options.series.data = shuzuList
              if (that.isBigSmall === false) {
                options.toolbox.show = false
              } else {
                options.toolbox.show = true
              }
              options.tooltip = {
                trigger: 'item',
                formatter: function(data) {
                  let res = ''
                  let sView = data.data.sentimentView
                  let aCount, pCount, nCount, aRatio, pRatio, nRatio
                  if (data.data.activeCount == null) {
                    aCount = '0'
                    aRatio = '0'
                  } else {
                    aCount = data.data.activeCount
                    aRatio = (data.data.activeCount / data.data.count) * 100
                  }
                  if (data.data.normalCount == null) {
                    nCount = '0'
                    nRatio = '0'
                  } else {
                    nCount = data.data.normalCount
                    nRatio = (data.data.normalCount / data.data.count) * 100
                  }
                  if (data.data.passiveCount == null) {
                    pCount = '0'
                    pRatio = '0'
                  } else {
                    pCount = data.data.passiveCount
                    pRatio = (data.data.passiveCount / data.data.count) * 100
                  }
                  // let passiveNum = data.data.passiveCount / data.data.count // 消极占比
                  let totalNum = (data.data.count / totalcount) * 100 // 没有情绪时的正常占比
                  res +=
                    data.name +
                    '(积极情绪)' +
                    '<br/>' +
                    '共' +
                    data.data.count +
                    '通录音' +
                    ':' +
                    '(' +
                    totalNum.toFixed(2) +
                    '%' +
                    ')' +
                    '<br/>'
                  res +=
                    '积极:' + aCount + '(' + aRatio.toFixed(2) + '%' + ')' + '<br/>'
                  res += '正常:' + nCount + '(' + nRatio.toFixed(2) + '%' + ')' + '<br/>'
                  res +=
                    '消极:' + pCount + '(' + pRatio.toFixed(2) + '%' + ')'
                  return res
                },
              }
              sunEcharts.on('click', function(params) {
                let options = that.options
                let treeValue = that.treeValue
                const selectedTree = options.filter((item) => item.value === treeValue)
                that.isData = false
                // that.getCiUrl(params.data)
                if (params.name == '') {
                  // that.getTreePid()
                } else {
                  const treePathInfo = params.treePathInfo
                  let path = ''
                  treePathInfo.forEach((info) => {
                    if (info.name != '') {
                      path += '/' + info.name
                    }
                  })
                  that.clickName = selectedTree[0].label + path
                  if (params.name === '其他') {
                    that.urlOther = true
                  } else {
                    that.urlOther = false
                  }
                  that.getTreeId(params.data.sortID)
                }
              })
              sunEcharts.on('contextmenu', function(param) {
                that.exportBussessParames = {
                  title: param.name,
                  sortID: param.data.sortID,
                  loadType: 'qingxu',
                }
                console.log('右击事件')
                console.log(that.exportBussessParames)
              })
              sunEcharts.setOption(options)
            }
          } else {
            sunEcharts.hideLoading()
            sunEcharts.dispose()
          }
        })
    },
    getCiUrl(data) {
      console.log(data)
      let isother = false
      if (data.sortName === '其他') {
        isother = true
      }
      this.axios
        .get(
          currentBaseUrl +
            '/recordSort/' +
            data.sortID +
            '?sortId=' +
            data.sortID +
            '&isOther=' +
            isother
        )
        .then((resp) => {
          console.log(resp.data)
        })
    },
    getEmotionChild(value, treeList, parent, proportion) {
      let that = this
      let radioNum = []
      let total = 0
      let oneNum = 0
      for (let p = 0; p < value.length; p++) {
        radioNum.push(value[p].count)
      }
      for (let u = 0; u < radioNum.length; u++) {
        oneNum += radioNum[u]
      }
      total = oneNum
      for (let i = 0; i < value.length; i++) {
        let nums = 0
        nums = (value[i].count / total) * proportion
        let color1 = ''
        if (value[i].sentimentView == '0') {
          color1 = '#12A037'
        } else if (value[i].sentimentView == '1') {
          color1 = '#CCCCCC'
        } else if (value[i].sentimentView == '2') {
          color1 = '#FF0000'
        } else {
          color1 = '#CCCCCC'
        }
        treeList[i] = {
          itemStyle: {
            color: color1,
          },
          allParentSortName: value[i].allParentSortName,
          otherCount: value[i].otherCount,
          sortID: value[i].sortID == null ? value[i].parentID : value[i].sortID,
          sortName: value[i].sortName,
          passiveCount: value[i].passiveCount,
          normalCount: value[i].normalCount,
          activeCount: value[i].activeCount,
          sentimentView: value[i].sentimentView,
          name: value[i].sortName,
          count: value[i].count,
          value: (value[i].count / total) * proportion,
          children: that.getEmotionChild(
            value[i].children == null ? [{}] : value[i].children,
            [],
            value[i],
            nums
          ),
        }
      }
      if (treeList.length == 0) {
        treeList = [{}]
      }
      return treeList
    },
    // 导出某一个分类信息
    exportSunData() {
      let that = this
      let sortid = that.exportBussessParames.sortID
      let title = that.exportBussessParames.title
      console.log(title)
      let url = ''
      let minDate = JSON.stringify(
        new Date(this.times[0].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      let maxDate = JSON.stringify(
        new Date(this.times[1].replace(new RegExp('-', 'gm'), '/')).getTime()
      ) // 年月日时分秒时间格式转换成lang类型时间戳
      if (sortid == undefined) {
        sortid = that.treePid
      }
      if (title === '其他') {
        url =
          currentBaseUrl +
          '/recordSort/' +
          sortid +
          '/records/excel/other/?' +
          'callSTimeMin=' +
          minDate +
          '&callSTimeMax=' +
          maxDate +
          '&accessToken=' +
          this.$store.state.token
      } else {
        url =
          currentBaseUrl +
          '/recordSort/' +
          sortid +
          '/records/excel/?' +
          'callSTimeMin=' +
          minDate +
          '&callSTimeMax=' +
          maxDate +
          '&accessToken=' +
          this.$store.state.token
      }
      console.log(url)
      window.location.href = url
    },
    smallShow() {
      let that = this
      $('#homeShow').hide()
      $('#rightview').show()
      document.getElementById('leftview').style.flex = 6
      document.getElementById('rightview').style.flex = 4
      // document.getElementById('viewRadio').style.width = 50 + '%'
      document.getElementById('legend').style.width = 50 + '%'
      this.isShowTop = true
      this.isBigSmall = true
      sunEcharts = that.$echarts.init(document.getElementById('sunEchart'))
      sunEcharts.setOption({
        toolbox: { show: true },
      })
      sunEcharts.resize()
      // this.getSunView()
    },
    /*
     * 设置默认日期为当前一个月的范围
     * */
    getThisMonthDate() {
      let fromTime = ''
      let toTime = ''
      if (this.times.length == 0) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        if (this.times[0] != undefined && this.times[0] != '') {
          fromTime = formatdate.formatDate(this.times[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (this.times[1] != undefined && this.times[1] != '') {
          toTime = formatdate.formatDate(this.times[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.times = [fromTime, toTime]
      this.startDate = fromTime
      this.endDate = toTime
    },
    /*
     *点击一个分类
     * 请求接口
     * 热词相关、趋势图数据更新
     */
    getViewDataByTreeId(paramsList) {
      console.log(paramsList)
    },
    refreshData() {
      let that = this
      that.treeId = JSON.parse(JSON.stringify(that.treePid))
      that.treeValue = that.getFirstreeid
      let fromTime = ''
      let toTime = ''
      let now = new Date()
      now.setDate(1)
      now.setHours(0)
      now.setMinutes(0)
      now.setSeconds(0)
      fromTime = formatdate.formatDate(now)
      let currentMonth = now.getMonth()
      let nextMonth = ++currentMonth
      let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
      let oneDay = 1000
      toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      that.times = [fromTime, toTime]
      that.startDate = fromTime
      that.endDate = toTime
      that.clickName = ''
      that.viewRadio = '常规视图'
      that.urlOther = false
      that.isData = true
      that.gettreeViewBySortID(that.treeValue)
    },
    dateChange() {
      let that = this
      that.treeId = JSON.parse(JSON.stringify(that.treePid))
      that.getThisMonthDate()
      that.isData = true
      that.clickName = ''
      if (this.viewRadio === '常规视图') {
        that.gettreeViewBySortID(this.treePid)
      } else if (this.viewRadio === '情绪视图') {
        that.sentimentView(this.treePid)
      } else {
        that.getTrendView(this.treePid)
      }
    },
    /*
     * 子组件通知父组件放大视图了
     * 设置相关样式改变
     * */
    bigViewShow(item) {
      if (item === 'small') {
        document.getElementById('rightview').style.flex = 4
        $('#leftview').show()
        document.getElementById('leftview').style.flex = 6
        this.isShowTop = true
      } else if (item === 'sunItem') {
        this.isShowTop = false
        document.getElementById('rightview').style.flex = 0
        $('#rightview').hide()
        document.getElementById('leftview').style.flex = 10
        $('#homeShow').show()
        document.getElementById('viewRadio').style.width = 100 + '%'
        let that = this
        that.isBigSmall = false
        sunEcharts = that.$echarts.init(document.getElementById('sunEchart'))
        sunEcharts.on('contextmenu', function() {
          let menu = document.getElementById('exportTitle3')
          menu.style.display = 'none'
        })
        if (that.isBigSmall === false) {
          sunEcharts.setOption({
            toolbox: {
              show: false,
            },
          })
        }
        sunEcharts.resize()
      } else {
        document.getElementById('rightview').style.flex = 10
        $('#leftview').hide()
        document.getElementById('leftview').style.flex = 0
        this.itemName = item
        this.isBigShow = true
        this.isShowTop = false
      }
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.statisticalReports {
  position: relative;
  overflow: hidden;
  width: 100%;
  height: 100%;
  #exportTitle3 {
    width: 100px;
    height: 40px;
    background-color: rgba(0, 0, 0, 0.5);
    position: absolute;
    text-align: center;
    .el-button.btn {
      color: #fff;
    }
  }
  #homeShow {
    cursor: pointer;
    position: absolute;
    top: 10px;
    right: 20px;
    display: none;
    img {
      font-size: 26px;
      width: 20px;
      height: 20px;
      margin: 20px;
    }
  }
  .top {
    height: 60px;
    .box {
      padding: 10px;
    }
    .ml10 {
      margin-left: 10px;
    }
    .refresh {
      padding-right: 10px;
      cursor: pointer;
      float: right;
      i {
        font-size: 30px;
      }
    }
  }
  .content {
    padding-top: 0px;
    padding-bottom: 80px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    .flexContent {
      height: 100%;
      display: flex;
      flex: 1;
      flex-direction: row;
      flex-wrap: nowrap;
      #leftview {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        flex: 6;
        #viewRadio {
          position: absolute;
          bottom: 10px;
          text-align: center;
        }
        #legend,
        #emotion {
          position: absolute;
          bottom: 60px;
          right: 10px;
          margin: 40px 20px 20px 20px;
          text-align: right;
          display: none;
          ul {
            list-style: none;
            li {
              line-height: 24px;
              .span1 {
                background: #52b4fc;
              }
              .span2 {
                background: #cccccc;
              }
              .span3 {
                background: #ffcc00;
              }
              .span4 {
                background: #12a037;
              }
              .span5 {
                background: #ff0000;
              }
              span {
                display: inline-block;
                margin-right: 10px;
                width: 10px;
                height: 10px;
              }
            }
          }
        }
      }
      #rightview {
        flex: 4;
      }
    }
  }
}
</style>
<style lang="less">
#statisticalReports {
  .el-radio-button__inner {
    border: 0px !important;
    color: #999;
  }
  .el-radio-button:first-child .el-radio-button__inner {
    border-left: 0px !important;
    border-right-color: #fff !important;
  }
  .el-radio-button__orig-radio:checked + .el-radio-button__inner {
    background-color: #fff !important;
    color: #000;
    box-shadow: 0px 0px 0px !important;
  }
}
</style>
