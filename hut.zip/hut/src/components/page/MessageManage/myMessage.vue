<template>
  <div class="myMessageContainer" id="myMessageContainer">
    <div class="operation">
      <div class="msg_header">全部公告</div>
      <div class="searchForm">
        <el-form :inline="true">
          <el-form-item>
            <el-input v-model="contentInbox" placeholder="公告标题"></el-input>
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="createTimeInbox"
              type="datetimerange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :default-time="['00:00:00', '23:59:59']"
            >
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="searchInbox">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="tableContent">
      <el-table
        ref="multipleTable"
        :data="messagesInbox"
        border
        tooltip-effect="dark"
        style="width: 100%"
      >
        <el-table-column prop="content" label="公告标题" sortable>
          <template scope="scope">
            <el-button
              type="text"
              style="padding: 10px 0;"
              @click="showDetail(scope.row.detailId)"
            >
              {{ scope.row.content }}
            </el-button>
          </template>
        </el-table-column>
        <el-table-column
          prop="createTime"
          width="300"
          :formatter="createTimeFilter"
          sortable
          label="创建时间"
        >
        </el-table-column>
        <el-table-column prop="createUserName" width="300" sortable label="创建人">
        </el-table-column>
      </el-table>
    </div>
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="pageSizes"
      :page-size="pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
    >
    </el-pagination>
    <!-- 查看消息 -->
    <el-dialog
      title="公告"
      :visible.sync="messageDetailVisible"
      :close-on-click-modal="false"
      :before-close="handleClosemessageDetail"
    >
      <div class="messageContent">
        <div class="massage_header">
          <h2>
            {{ detailMessage.content }}
          </h2>
        </div>
        <p>
          {{ detailMessage.messageContent }}
        </p>
        <div class="btns">
          <el-button @click="handleClosemessageDetail">取消</el-button>
          <el-button type="primary" @click="handleClosemessageDetail">确定</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import qs from 'qs'
import moment from 'moment'
import global from '../../../global.js'
import formatdate from '../../../utils/formatdate.js'
let qualityUrl = global.qualityUrl
export default {
  data() {
    return {
      searchForm: {},
      messagesInbox: [],
      currentPage: 1,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      createTimeInbox: [],
      contentInbox: '',
      messageDetailVisible: false,
      detailMessage: {},
    }
  },
  methods: {
    searchInbox() {
      this.getMessageInBox()
    },
    createTimeFilter(row, column, cellValue) {
      return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
    },
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    getMessageInBox() {
      let _this = this
      let params = {}
      params.pagesize = this.pageSize
      params.pageindex = this.currentPage
      params.begin = 1
      params.end = 1
      params.content = this.contentInbox
      params.createTimeMin =
        this.createTimeInbox != null && this.createTimeInbox.length > 0
          ? formatdate.formatDate(this.createTimeInbox[0])
          : ''
      params.createTimeMax =
        this.createTimeInbox != null && this.createTimeInbox.length > 0
          ? formatdate.formatDate(this.createTimeInbox[1])
          : ''
      this.axios
        .post(qualityUrl + '/AbcByLogin/queryInbox.do', qs.stringify(params))
        .then(function(response) {
          _this.messagesInbox = response.data.Data
          _this.total = response.data.Count
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取公告列表出现问题',
          })
        })
    },
    showDetail(id) {
      let _this = this
      let params = {}
      let url = qualityUrl + '/AbcByLogin/getMessageManageViewById.do'
      params.id = id
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.messageDetailVisible = true
          _this.detailMessage = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '公告详情获取失败',
          })
        })
    },
    handleClosemessageDetail() {
      this.messageDetailVisible = false
      this.getMessageInBox()
    },
  },
  created() {
    this.getMessageInBox()
  },
  watch: {
    pageSize() {
      this.getMessageInBox()
    },
    currentPage() {
      this.getMessageInBox()
    },
  },
}
</script>
<style lang="less">
@border-color: #d1dbe5;
// 修改组件样式
.myMessageContainer {
  .operation .el-form-item {
    margin-bottom: 0px;
    .el-form-item__content {
      line-height: 36px;
    }
    &:last-child {
      margin-right: 0px;
    }
  }
  .el-dialog__body {
    padding: 10px 20px;
  }
  .tableContent .el-table__header th {
    background-color: #e0e6ed;
    color: #475669;
    padding: 10px 0;
  }
}
</style>
<style lang="less" scoped>
@border-color: #d1dbe5;
// 页面样式
.myMessageContainer {
  height: 100%;
  width: 100%;
  position: relative;
  box-sizing: border-box;
  .line {
    text-align: center;
  }
  .operation {
    display: flex;
    flex-direction: row;
    justify-content: center;
    padding: 16px 18px;
    .msg_header {
      font-size: 14px;
      width: 100px;
      line-height: 36px;
    }
    .searchForm {
      flex: 1;
      display: flex;
      flex-direction: row;
      justify-content: flex-end;
      button {
        width: 88px;
        height: 36px;
      }
    }
  }
  .tableContent {
    padding: 0px 18px 0px;
    position: absolute;
    top: 68px;
    left: 0;
    right: 0px;
    bottom: 50px;
    overflow-y: auto;
  }
  .el-pagination {
    position: absolute;
    bottom: 0;
    left: 18px;
    right: 18px;
    text-align: right;
    height: 40px;
    padding: 5px 0;
  }
  .btns {
    text-align: right;
  }
  .messageContent {
    .massage_header {
      h2 {
        text-align: center;
      }
    }
    p {
      padding: 10px 0px;
    }
  }
}
</style>
