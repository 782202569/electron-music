<template>
  <div class="sendMessageContainer" id="sendMessageContainer">
    <div class="msg_header">公告发件箱</div>
    <div class="searchForm">
      <el-button class="header_btn" @click="newNoticebtn">新建公告</el-button>
      <div class="header_form">
        <el-form :inline="true" class="my_form">
          <el-form-item>
            <el-input v-model="content" placeholder="公告标题"></el-input>
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="createTime"
              type="datetimerange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :default-time="['00:00:00', '23:59:59']"
            >
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="search">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="tableContent">
      <el-table
        ref="multipleTable"
        :data="messages"
        border
        tooltip-effect="dark"
        style="width: 100%"
      >
        <el-table-column prop="content" label="公告标题" sortable>
          <template scope="scope">
            <el-button
              type="text"
              style="padding: 10px 0;"
              @click="showDetail(scope.row.messageId)"
            >
              {{ scope.row.content }}
            </el-button>
          </template>
        </el-table-column>
        <el-table-column
          prop="createTime"
          width="400"
          :formatter="createTimeFilter"
          sortable
          label="创建时间"
        >
        </el-table-column>
        <el-table-column label="操作" width="190">
          <template scope="scope">
            <el-button
              @click="copyDetail(scope.row.messageId)"
              type="text"
              size="small"
              icon="document"
              >复制</el-button
            >
            <el-button
              @click="delMsg(scope.row.messageId)"
              type="text"
              size="small"
              icon="document"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="pageSizes"
      :page-size="pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
    >
    </el-pagination>
    <!-- 新建公告 -->
    <el-dialog
      :title="msgTitle"
      :visible.sync="newNoticeVisible"
      :close-on-click-modal="false"
      :before-close="handleClosenewNotice"
    >
      <el-form
        label-width="80px"
        :model="newNoticeModel"
        ref="newNoticeModel"
        :rules="addMessageRules"
      >
        <el-form-item label="公告标题" prop="content">
          <el-input v-model="newNoticeModel.content"></el-input>
        </el-form-item>
        <el-form-item label="公告内容" prop="messageContent">
          <el-input
            type="textarea"
            v-model="newNoticeModel.messageContent"
            :rows="6"
          ></el-input>
        </el-form-item>
        <el-form-item label="发送给" prop="recipients">
          <div class="contentLeft">
            <div class="operation">
              <el-input
                placeholder="输入关键字进行过滤"
                icon="search"
                v-model="filterText"
              >
              </el-input>
            </div>
            <div class="tree">
              <el-tree
                class="filter-tree"
                :data="selectPeople"
                show-checkbox
                :props="defaultProps"
                default-expand-all
                :filter-node-method="filterNode"
                ref="selectPeopleTree"
              >
              </el-tree>
            </div>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="btns">
            <el-button type="primary" @click="newNotice">确定</el-button>
            <el-button @click="handleClosenewNotice">取消</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 查看消息 -->
    <el-dialog
      title="公告"
      :visible.sync="messageDetailVisible"
      :close-on-click-modal="false"
      :before-close="handleClosemessageDetail"
    >
      <div class="messageContent">
        <div class="massage_header">
          <h2>
            {{ detailMessage.content }}
          </h2>
        </div>
        <p>
          {{ detailMessage.messageContent }}
        </p>
        <div class="btns">
          <el-button @click="handleClosemessageDetail">取消</el-button>
          <el-button type="primary" @click="handleClosemessageDetail">确定</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import qs from 'qs'
import moment from 'moment'
import global from '../../../global.js'
import formatdate from '../../../utils/formatdate.js'
let qualityUrl = global.qualityUrl
export default {
  data() {
    return {
      messages: [],
      currentPage: 1,
      msgTitle: '新建公告',
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      content: '',
      createTime: [],
      newNoticeVisible: false,
      filterText: '',
      newNoticeModel: {
        recipients: [],
        messageType: '2',
        content: '',
        messageContent: '',
      },
      defaultProps: {
        children: 'child',
        label: 'name',
      },
      selectPeople: [],
      messageDetailVisible: false,
      detailMessage: {},
      addMessageRules: {
        content: [
          { required: true, message: '公告标题不能为空', trigger: 'blur' },
          { min: 1, max: 30, message: '公告标题不能超过30个字', trigger: 'blur' },
        ],
        messageContent: [
          { required: true, message: '公告内容不能为空', trigger: 'blur' },
          { min: 1, max: 500, message: '公告内容不能超过500个字', trigger: 'blur' },
        ],
      },
    }
  },
  methods: {
    search() {
      this.getMessage()
    },
    newNoticebtn() {
      this.newNoticeVisible = true
      this.msgTitle = '新建公告'
      // 表单重置
      this.getDepartTree()
      this.filterText = ''
      this.newNoticeModel.content = ''
      this.newNoticeModel.messageContent = ''
      this.newNoticeModel.recipients = []
    },
    newNotice() {
      let _this = this
      let recipients = this.$refs.selectPeopleTree.getCheckedNodes()
      for (let i = 0; i < recipients.length; i++) {
        this.newNoticeModel.recipients.push(recipients[i].id)
      }
      if (!this.newNoticeModel.recipients || this.newNoticeModel.recipients.length < 1) {
        _this.$message({
          type: 'error',
          message: '收件人不能为空！',
        })
        return false
      }
      this.$refs.newNoticeModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          this.axios
            .post(
              qualityUrl + '/AbcByLogin/saveMessage.do',
              qs.stringify(_this.newNoticeModel)
            )
            .then(function(response) {
              _this.$message({
                type: 'success',
                message: '消息发送成功',
              })
              _this.handleClosenewNotice()
              _this.getMessage()
            })
            .catch(function() {
              _this.$message({
                type: 'error',
                message: '消息发送失败',
              })
            })
        }
      })
    },
    handleClosenewNotice() {
      this.newNoticeVisible = false
      this.newNoticeModel.content = ''
      this.newNoticeModel.messageContent = ''
      this.newNoticeModel.recipients = []
    },
    createTimeFilter(row, column, cellValue) {
      return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
    },
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    formateTime(time, flag) {
      let result = ''
      if (time && flag == 'start') {
        let temp = new Date(time)
        result =
          temp.getFullYear() +
          '-' +
          (temp.getMonth() + 1) +
          '-' +
          temp.getDate() +
          ' ' +
          '00' +
          ':' +
          '00' +
          ':' +
          '00'
      } else if (time && flag == 'end') {
        let temp = new Date(time)
        result =
          temp.getFullYear() +
          '-' +
          (temp.getMonth() + 1) +
          '-' +
          temp.getDate() +
          ' ' +
          '23' +
          ':' +
          '59' +
          ':' +
          '59'
      }
      return result
    },
    getMessage() {
      let _this = this
      let params = {}
      params.pagesize = this.pageSize
      params.pageindex = this.currentPage
      params.begin = 1
      params.end = 1
      params.content = this.content
      params.createTimeMin =
        this.createTime != null && this.createTime.length > 0
          ? formatdate.formatDate(this.createTime[0])
          : ''
      params.createTimeMax =
        this.createTime != null && this.createTime.length > 0
          ? formatdate.formatDate(this.createTime[1])
          : ''
      this.axios
        .post(qualityUrl + '/AbcByLogin/queryOutbox.do', qs.stringify(params))
        .then(function(response) {
          _this.messages = response.data.Data
          _this.total = response.data.Count
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取公告列表出现问题',
          })
        })
    },
    getDepartTree() {
      let _this = this
      this.axios
        .post(qualityUrl + '/BCDbyLogin/getDepartTree.do')
        .then(function(response) {
          _this.selectPeople = response.data.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取收件人列表出现问题',
          })
        })
    },
    filterNode(value, data) {
      if (!value) return true
      return data.name.indexOf(value) !== -1
    },
    showDetail(id) {
      let _this = this
      let url = ''
      let params = {}
      url = qualityUrl + '/AbcByLogin/getMessageById.do'
      params.id = id
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.messageDetailVisible = true
          _this.detailMessage = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '公告详情获取失败',
          })
        })
    },
    handleClosemessageDetail() {
      this.messageDetailVisible = false
    },
    delMsg(msgId) {
      let _this = this
      this.$confirm('确定要删除吗', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let params = {
            messageId: msgId,
          }
          _this.axios
            .post(qualityUrl + '/AbcByLogin/removeMessage.do', qs.stringify(params))
            .then((res) => {
              if (res.data) {
                _this.$message({
                  type: 'success',
                  message: '删除成功!',
                })
              } else {
                _this.$message({
                  type: 'error',
                  message: '删除失败',
                })
              }
              _this.getMessage()
            })
            .catch(function(error) {
              console.log(error)
            })
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
          _this.getMessage()
        })
    },
    copyDetail(id) {
      let _this = this
      let url = ''
      let params = {}
      url = qualityUrl + '/AbcByLogin/getMessageById.do'
      params.id = id
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.newNoticeVisible = true
          _this.msgTitle = '复制公告'
          _this.getDepartTree()
          _this.newNoticeModel.content = response.data.content
          _this.newNoticeModel.messageContent = response.data.messageContent
          _this.newNoticeModel.recipients = []
          _this.filterText = ''
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '公告详情获取失败',
          })
        })
    },
  },
  created() {
    this.getMessage()
  },
  watch: {
    filterText(val) {
      this.$refs.selectPeopleTree.filter(val)
    },
    pageSize() {
      this.getMessage()
    },
    currentPage() {
      this.getMessage()
    },
  },
}
</script>
<style lang="less">
@border-color: #d1dbe5;
// 修改组件样式
.sendMessageContainer {
  .searchForm {
    .el-form-item {
      margin-bottom: 0px;
      .el-form-item__content {
        line-height: 36px;
      }
      &:last-child {
        margin-right: 0px;
      }
    }
  }
  .el-tree {
    border: none;
  }

  .el-select {
    width: 100%;
  }
  .el-dialog__body {
    padding: 10px 20px;
  }
  .tableContent .el-table__header th {
    background-color: #e0e6ed;
    color: #475669;
    padding: 10px 0;
  }
}
</style>
<style lang="less" scoped>
@border-color: #d1dbe5;
// 页面样式
.sendMessageContainer {
  height: 100%;
  width: 100%;
  position: relative;
  box-sizing: border-box;
  .msg_header {
    padding: 16px 18px;
    font-size: 14px;
  }
  .searchForm {
    display: flex;
    flex-direction: row;
    justify-content: center;
    padding: 0 18px 19px;
    .header_btn {
      width: 88px;
      height: 36px;
      padding: 0;
    }
    .header_form {
      flex: 1;
      display: flex;
      flex-direction: row;
      justify-content: flex-end;
      .my_form {
        button {
          width: 88px;
          height: 36px;
        }
      }
    }
  }
  .tableContent {
    padding: 0px 18px;
    position: absolute;
    top: 112px;
    left: 0;
    right: 0px;
    bottom: 35px;
    overflow-y: auto;
  }
  .el-pagination {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    text-align: right;
    height: 34px;
    padding: 0 18px 0px 5px;
  }
  .line {
    text-align: center;
  }
  .contentLeft {
    position: relative;
    width: 100%;
    height: 300px;
    .operation {
      position: absolute;
      height: 55px;
      line-height: 55px;
      top: 0px;
      left: 0;
      right: 10px;
    }
    .tree {
      position: absolute;
      top: 60px;
      bottom: 0px;
      width: 100%;
      overflow-y: auto;
      border: 1px solid @border-color;
    }
  }

  .btns {
    text-align: right;
  }
  .messageContent {
    .massage_header {
      h2 {
        text-align: center;
      }
    }
    p {
      padding: 10px 0px;
    }
  }
}
</style>
