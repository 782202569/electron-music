<template>
  <div class="taskMonitorContainer" id="taskMonitorContainer">
    <el-tabs v-model="activeName" @tab-click="changeTab">
      <el-tab-pane label="任务监控(订单)" name="1">
        <div class="contents">
          <div class="operation part_1">
            <div class="searchForm">
              <el-form :inline="true">
                <el-form-item label="选择日期">
                  <el-date-picker
                    v-model="searchForm.time"
                    type="datetimerange"
                    placeholder="选择时间范围"
                  >
                  </el-date-picker>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="searchChart">查询</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
          <div class="charts-container">
            <div id="totalChart" class="chart_box" style="overflow:scroll;"></div>
            <div id="peopleChart" class="chart_box" style="overflow:scroll;"></div>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="任务列表" name="2">
        <div class="contents">
          <div class="operation list">
            <div class="searchForm">
              <el-form :model="searchModel" ref="searchModel" :inline="true">
                <div class="Row">
                  <el-form-item label="订单编号" prop="objectId">
                    <el-input
                      v-model="searchModel.objectId"
                      placeholder="订单编号"
                      style="width: 160px;"
                    ></el-input>
                  </el-form-item>
                  <el-form-item label="抽检类型" prop="taskType_list">
                    <el-select
                      v-model="searchModel.taskType_list"
                      placeholder="请选择"
                      style="width: 160px;"
                      clearable
                    >
                      <el-option value="1" label="人工抽样"></el-option>
                      <el-option value="2" label="系统抽样"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="任务状态" prop="type">
                    <el-select
                      v-model="searchModel.type"
                      placeholder="请选择"
                      style="width: 160px;"
                      clearable
                    >
                      <el-option :value="1" label="初检"></el-option>
                      <el-option :value="2" label="复检"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="质检状态" prop="taskStatus_list" class="type">
                    <el-select
                      v-model="searchModel.taskStatus_list"
                      placeholder="请选择"
                      style="width: 160px;"
                      clearable
                    >
                      <el-option :value="1" label="已质检"></el-option>
                      <el-option :value="2" label="未质检"></el-option>
                    </el-select>
                  </el-form-item>
                </div>
                <div class="Row">
                  <el-form-item label="分发时间" prop="time">
                    <el-date-picker
                      v-model="searchModel.time"
                      type="datetimerange"
                      placeholder="选择时间范围"
                    >
                    </el-date-picker>
                  </el-form-item>
                  <el-form-item label="质检员姓名" prop="qaUserName">
                    <el-input
                      v-model="searchModel.qaUserName"
                      placeholder="质检员姓名"
                      style="width: 160px;"
                    ></el-input>
                  </el-form-item>
                  <el-form-item label="质检员工号" prop="qaUserFake">
                    <el-input
                      v-model="searchModel.qaUserFake"
                      placeholder="质检员工号"
                      style="width: 160px;"
                    ></el-input>
                  </el-form-item>
                  <el-form-item class="btn">
                    <el-button @click="searchTapTask">查询</el-button>
                  </el-form-item>
                  <el-form-item class="btn">
                    <el-button @click="exportData">导出</el-button>
                  </el-form-item>
                  <el-form-item class="btn">
                    <el-button type="primary" @click="distribution"
                      >添加到校准会</el-button
                    >
                  </el-form-item>
                </div>
              </el-form>
            </div>
          </div>
          <div class="tableContent">
            <el-table
              ref="multipleTable"
              :data="taskList"
              border
              @selection-change="handleSelectionChange"
              tooltip-effect="dark"
              style="width: 100%"
            >
              <el-table-column type="selection"> </el-table-column>
              <el-table-column prop="objectId" label="订单编号" sortable>
                <template scope="scope">
                  <el-button
                    type="text"
                    @click="
                      showDetail(
                        scope.row.objectId,
                        scope.row.seatName,
                        scope.row.seatNo,
                        scope.row.qaScoreType,
                        scope.row.recordFileURL
                      )
                    "
                    >{{ scope.row.objectId }}</el-button
                  >
                </template>
              </el-table-column>
              <el-table-column prop="seatName" width="175" sortable label="提交人姓名">
              </el-table-column>
              <el-table-column prop="qaUser" width="175" sortable label="质检员工号">
              </el-table-column>
              <el-table-column
                prop="qaUserName"
                :formatter="convertQaUserName"
                width="130"
                sortable
                label="质检员"
              >
              </el-table-column>
              <el-table-column prop="score" width="120" sortable label="质检结果">
              </el-table-column>
              <el-table-column width="120" sortable label="质检状态">
                <template scope="scope">
                  <el-tag v-if="scope.row.taskStatus == 1" type="success">已质检</el-tag>
                  <el-tag v-else>未质检</el-tag>
                </template>
              </el-table-column>
              <el-table-column width="120" sortable label="任务状态">
                <template scope="scope">
                  <el-tag v-if="scope.row.type == 1" type="primary">初检</el-tag>
                  <el-tag v-else type="success">复检</el-tag>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </el-tab-pane>
    </el-tabs>
    <!-- 分配质检员 -->
    <el-dialog
      title="分配质检员"
      :visible.sync="distributeInspectorVisible"
      :close-on-click-modal="false"
      :before-close="handleCloseDistributeInspector"
    >
      <div class="distributeInspectorFiled">
        <el-form
          :model="distributeInspectorModel"
          ref="distributeInspectorModel"
          label-width="100px"
        >
          <el-form-item label="质检模板" prop="templeateId" clearable>
            <el-select
              v-model="distributeInspectorModel.templeateId"
              placeholder="请选择"
            >
              <el-option
                v-for="item in templeateIds"
                :label="item.modleTitle"
                :value="item.modleId"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="开始时间" prop="startTime">
            <el-date-picker
              v-model="distributeInspectorModel.startTime"
              type="datetime"
              placeholder="选择日期时间"
            >
            </el-date-picker>
          </el-form-item>
          <el-form-item label="持续时间" prop="duration">
            <el-select
              v-model="distributeInspectorModel.duration"
              placeholder="请选择"
              clearable
            >
              <el-option label="一天" value="1"></el-option>
              <el-option label="二天" value="2"></el-option>
              <el-option label="三天" value="3"></el-option>
              <el-option label="四天" value="4"></el-option>
              <el-option label="五天" value="5"></el-option>
              <el-option label="六天" value="6"></el-option>
              <el-option label="七天" value="7"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="选择质检员" prop="qaUserIdsStr">
            <el-checkbox-group v-model="distributeInspectorModel.qaUserIdsStr">
              <el-checkbox :label="item.account" v-for="item in people">{{
                item.realName
              }}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item>
            <div class="btns">
              <el-button @click="handleCloseDistributeInspector">取消</el-button>
              <el-button type="primary" @click="distributeInspector">确定</el-button>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </el-dialog>
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="recordingplay"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import qs from 'qs'
import formatDate from '../../../utils/formatdate.js'
import commonUtil from '../../../utils/commonUtil.js'
import moment from 'moment'
import global from '../../../global.js'
let currentBaseUrl = global.qualityUrl
import recordingplay from '../recordingPlayOrder/recordingPlayOrder.vue'
import vPlayer from '../../common/player.vue'
import bus from '../../common/bus.js'
export default {
  components: {
    vPlayer,
    recordingplay,
  },
  data() {
    return {
      recordDialogVisible: false,
      activeName: '1',
      searchForm: {
        time: [],
      },
      totalChartData: {}, // 质检任务总数统计
      qaChartData: {}, // 质检员统计
      searchModel: {
        objectId: '', // 录音编号
        qaUserName: '', // 质检人姓名
        taskStatus_list: '', // 任务状态
        type: '', // 质检状态
        time: '', // 分发时间
        taskType_list: '', // 抽样类型
        qaUserFake: '', // 质检人工号
      },
      currentPage: 1,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      taskList: [], // 质检任务列表
      checkedList: [], // 选中的任务列表
      templeateIds: [], // 模板列表
      distributeInspectorVisible: false,
      distributeInspectorModel: {
        templeateId: '',
        startTime: '',
        duration: '',
        qaUserIdsStr: [],
      }, // 分配质检员表单
      people: [], // 质检员列表
    }
  },
  methods: {
    reSetData() {
      this.recordDialogVisible = false
      this.activeName = '1'
      this.searchForm = {
        time: [],
      }
      this.totalChartData = {} // 质检任务总数统计
      this.qaChartData = {} // 质检员统计
      this.searchModel = {
        objectId: '', // 录音编号
        qaUserName: '', // 质检人姓名
        taskStatus_list: '', // 任务状态
        type: '', // 质检状态
        time: '', // 分发时间
        taskType_list: '', // 抽样类型
        qaUserFake: '', // 质检人工号
      }
      this.currentPage = 1
      this.total = 0
      this.pageSize = 20
      this.pageSizes = [10, 20, 30, 40]
      this.taskList = [] // 质检任务列表
      this.checkedList = [] // 选中的任务列表
      this.templeateIds = [] // 模板列表
      this.distributeInspectorVisible = false
      this.distributeInspectorModel = {
        templeateId: '',
        startTime: '',
        duration: '',
        qaUserIdsStr: [],
      } // 分配质检员表单
      this.people = [] // 质检员列表
    },
    convertQaUserName(row, column, cellValue) {
      if (row['qaUser'] == 'system') {
        return '系统质检'
      }
      return cellValue
    },
    showDetail(id, submiterName, submiter, qaScoreType, recordFileURL) {
      let obj = {}
      obj.pageId = 'taskOrderMonitor'
      obj.orderNo = id
      obj.recordFileURL = recordFileURL
      obj.submiterName = submiterName
      obj.submiter = submiter
      obj.qaScoreType = qaScoreType
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay', // 扩展样式
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 关闭录音弹窗
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    // 录音播放页面 点击最小化触发
    toMinDialog: function(playInfo) {
      if (playInfo.isMaximization === false) {
        this.showVplayer = false
        let play = {}
        play.isMaximization = false
        play.exist = true
        this.$store.commit('setPlayerInfo', play)
      }
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    changeTab(tab, event) {
      if (tab.name == 1) {
        this.searchChart()
        this.currentPage = 1
      } else {
        this.searchTapTask()
      }
    },
    searchChart() {
      this.getTaskMonitorDays()
      this.getTaskMonitorQaUsers()
    },
    checkNoTime() {
      return (
        this.searchForm.time.length == 0 ||
        (this.searchForm.time[0] == null && this.searchForm.time[0] == null)
      )
    },
    // 获取任务监控总数统计
    getTaskMonitorDays() {
      let _this = this
      let params = {}
      if (this.checkNoTime()) {
        let now = new Date()
        let month = now.getMonth()
        let preMonthDate = now.setMonth(month - 1)
        params.startAssignDate = formatDate.formatDate(preMonthDate)
        params.endAssignDate = formatDate.formatDate(new Date())
      } else {
        params.startAssignDate = formatDate.formatDate(this.searchForm.time[0])
        params.endAssignDate = formatDate.formatDate(this.searchForm.time[1])
      }
      let url = currentBaseUrl + '/taskOrderMonitor/getTaskMonitorDays.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.totalChartData = response.data.Data
          let x = []
          let todoData = []
          let doneData = []
          if (_this.totalChartData && Object.keys(_this.totalChartData).length > 0) {
            for (let key in _this.totalChartData) {
              x.push(key)
              doneData.push(_this.totalChartData[key].hasQaCount)
              todoData.push(_this.totalChartData[key].noQaCount)
            }
          }
          // if (_this.totalChartData && _this.totalChartData.length > 0) {
          //   _this.totalChartData.forEach(function (item) {
          //     x.push(moment(item.assignDate).format("YYYY-MM-DD HH:mm:ss"))
          //     doneData.push(item.hasQaCount)
          //     todoData.push(item.noQaCount)
          //   })
          // }
          _this.drawBarChart('总数统计', 'totalChart', x, todoData, doneData)
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取总数统计结果出现问题',
          })
        })
    },
    // 获取质检员统计
    getTaskMonitorQaUsers() {
      let _this = this
      let params = {}
      if (this.checkNoTime()) {
        let now = new Date()
        let month = now.getMonth()
        let preMonthDate = now.setMonth(month - 1)
        params.startAssignDate = formatDate.formatDate(preMonthDate)
        params.endAssignDate = formatDate.formatDate(new Date())
      } else {
        params.startAssignDate = formatDate.formatDate(this.searchForm.time[0])
        params.endAssignDate = formatDate.formatDate(this.searchForm.time[1])
      }
      let url = currentBaseUrl + '/taskOrderMonitor/getTaskMonitorQaUsers.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.qaChartData = response.data.Data || ''
          let x = []
          let todoData = []
          let doneData = []
          if (_this.qaChartData && Object.keys(_this.qaChartData).length > 0) {
            for (let key in _this.qaChartData) {
              x.push(key)
              doneData.push(_this.qaChartData[key].hasQaCount)
              todoData.push(_this.qaChartData[key].noQaCount)
            }
          }
          // if (_this.qaChartData && _this.qaChartData.length > 0) {
          //   _this.qaChartData.forEach(function (item) {
          //     x.push(item.qaUser)
          //     doneData.push(item.hasQaCount)
          //     todoData.push(item.noQaCount)
          //   })
          // }
          _this.drawBarChart('质检员统计', 'peopleChart', x, todoData, doneData)
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检员统计结果出现问题',
          })
        })
    },
    // 画条形图
    // title，标题
    // divID， div的ID值
    // dataObj
    drawBarChart(title, divID, x, todoData, doneData) {
      let str = '#' + divID
      this.$echarts.dispose(document.querySelector(str))
      let _this = this
      let option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        title: {
          text: title,
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        legend: {
          data: ['待质检录音', '完成录音'],
          right: 0,
          top: '45%',
          orient: 'vertical',
          textStyle: {
            padding: [2, 2, 2, 2],
            borderWidth: 1,
            borderColor: '#797979',
            borderRadius: 3,
          },
        },
        grid: {
          top: '50',
          left: '10',
          right: '120',
          bottom: '5',
          containLabel: true,
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        xAxis: {
          type: 'category',
          data: [],
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // },
          axisLine: {
            show: false,
          },
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // },
          axisLine: {
            show: false,
          },
        },
        series: [
          {
            name: '待质检录音',
            type: 'bar',
            stack: '数量',
            data: [],
          },
          {
            name: '完成录音',
            type: 'bar',
            stack: '数量',
            data: [],
          },
        ],
      }
      option.xAxis.data = x
      option.series[0].data = todoData
      option.series[1].data = doneData
      this.$nextTick(function() {
        let chart = _this.$echarts.init(document.querySelector(str))
        chart.setOption(option)
      })
    },
    // 查询任务列表
    searchTapTask() {
      let _this = this
      let params = {}
      params.qaUserFake = this.searchModel.qaUserFake
      params.qaUserName = this.searchModel.qaUserName
      params.qaUser = this.searchModel.qaUserFake
      params.assignTime_Min = !this.searchModel.time[0]
        ? ''
        : formatDate.formatDate(this.searchModel.time[0])
      params.assignTime_Max = !this.searchModel.time[1]
        ? ''
        : formatDate.formatDate(this.searchModel.time[1])
      params.taskStatus_list = this.searchModel.taskStatus_list
      params.taskType_list = this.searchModel.taskType_list
      params.orderByClause = 'END_TIME'
      params.objectId = this.searchModel.objectId
      params.type = this.searchModel.type
      params.pageindex = this.currentPage
      params.pagesize = this.pageSize

      let obj = {}
      obj.searchModel = {}
      obj.searchModel.model = this.searchModel
      obj.searchModel.currentPage = this.currentPage
      obj.searchModel.pageSize = this.pageSize
      this.$store.commit('setRecordingPlayPage', obj)

      let url = currentBaseUrl + '/taskOrderMonitor/searchTapTask.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          console.log(_this.currentPage + 'done')
          _this.taskList = response.data.TapInfo
          _this.total = response.data.Count
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取任务列表出现问题',
          })
        })
    },
    // 录音table中行的选中状态变化时触发(val为选中的object)
    handleSelectionChange(val) {
      this.checkedList = val
    },
    // 导出任务数据
    exportData() {
      if (this.checkedList.length == 0) {
        this.$message.warning('请选择一条记录进行导出!')
      } else {
        let arr = []
        this.checkedList.forEach(function(e) {
          arr.push(e['objectId'])
        })
        let params = {
          resultJsonStr: JSON.stringify(this.checkedList),
        }
        commonUtil.doExport(
          currentBaseUrl + '/taskOrderMonitor/exportTaskMonitorResult.do',
          params
        )
      }
    },
    // 分配质检员
    distribution() {
      if (this.checkedList.length < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择要分配的质检任务',
        })
        return false
      }
      if (this.checkedList.length > 1) {
        this.$message.warning('只能选择一条录音加入校准会!')
        return
      }
      this.distributeInspectorVisible = true
      this.resetForm('distributeInspectorModel')
      this.getModleInfoByCondition()
      this.distributeTask()
    },
    // 获取质检模板
    getModleInfoByCondition() {
      let _this = this
      let params = {}
      params.modleType = '7'
      params.bussinType = '12'
      let url = currentBaseUrl + '/manualOrderQualityAssurance/getModleInfoByCondition.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.templeateIds = response.data.Data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检模板出现问题',
          })
        })
    },
    // 获取质检员方法
    distributeTask() {
      let _this = this
      let url = currentBaseUrl + '/distributeTask.do'
      this.axios
        .post(url)
        .then(function(response) {
          _this.people = response.data.Data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检员列表出现问题',
          })
        })
    },
    // 关闭分配弹窗
    handleCloseDistributeInspector() {
      this.distributeInspectorVisible = false
    },
    // 给质检员分配任务
    distributeInspector() {
      let _this = this
      let params = {}
      let callIds = []
      if (this.distributeInspectorModel.qaUserIdsStr.length === 0) {
        this.$message.warning('请选择质检员进行分配!')
        return
      }

      this.checkedList.forEach(function(item) {
        callIds.push(item.objectId)
      })
      params.duration = this.distributeInspectorModel.duration
      params.startTime = formatDate.formatDate(this.distributeInspectorModel.startTime)
      params.qaUserIdsStr = this.distributeInspectorModel.qaUserIdsStr.join(',')
      params.modleId = this.distributeInspectorModel.templeateId
      params.callId = callIds.join(',')

      if (commonUtil.isBlank(params['modleId'])) {
        this.$message.warning('请选择质检模板!')
        return
      }

      if (commonUtil.isBlank(params['duration'])) {
        this.$message.warning('请选择持续时间!')
        return
      }

      if (commonUtil.isBlank(params['startTime'])) {
        this.$message.warning('请选择开始时间!')
        return
      }

      let nowStr = moment(Date.now()).format('YYYY-MM-DD HH:mm:ss')
      if (nowStr > params['startTime']) {
        this.$message.warning('开始时间必须大于当前时间!')
        return
      }

      let url = currentBaseUrl + '/taskOrderMonitor/insertToCalibrate.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '任务已成功分配',
            })
            _this.distributeInspectorVisible = false
            _this.searchTapTask()
          } else {
            return Promise.reject()
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '任务分配失败',
          })
        })
    },
    // 重置表单
    resetForm(formName) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[formName].resetFields()
      })
    },
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
  },
  // created () {
  // },
  created() {
    if (
      this.recordingPlayPage.fromPage == 'taskMonitor' &&
      this.recordingPlayPage.searchModel.currentPage
    ) {
      this.pageSize = this.recordingPlayPage.searchModel.pageSize
      this.searchModel = this.recordingPlayPage.searchModel.model
      this.activeName = '2'
      this.currentPage = this.recordingPlayPage.searchModel.currentPage
      this.searchTapTask()
    } else {
      this.searchChart()
    }
  },
  watch: {
    pageSize() {
      this.searchTapTask()
    },
    currentPage() {
      this.searchTapTask()
    },
    parentModel: {
      handler(newValue, oldValue) {
        console.info('监听到parentModel变化了')
        this.reSetData()
        this.qamodleScore()
      },
      deep: true,
    },
  },
  computed: {
    recordingPlayPage() {
      console.log(this.$store.state.recordingPlayPage)
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less">
@border-color: #d1dbe5;
@operationHeight: 120px;
// 修改组件样式
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
.taskMonitorContainer {
  .el-tabs__header {
    margin: 0px;
  }
  .operation {
    .el-form {
      .el-form-item {
        height: @operationHeight / 2;
        margin-bottom: 0px;
        padding-top: 10px;
        float: left;
        label,
        div {
          vertical-align: middle;
        }
        .el-date-editor.el-input.el-date-editor--datetimerange {
          width: 270px;
        }
      }
    }
  }
  .el-tabs {
    height: 100%;
    width: 100%;
    .el-tabs__content {
      width: 100%;
      position: absolute;
      top: 40px;
      left: 0;
      bottom: 0;
      right: 0;
      .el-tab-pane {
        width: 100%;
        height: 100%;
      }
    }
  }
  .el-tabs__header {
    background-color: #eef1f6;
  }
  .el-tabs__active-bar {
    display: none;
  }
  .el-tree {
    border: none;
  }
  .el-pagination {
    position: absolute;
    bottom: 0;
    left: 10px;
    right: 10px;
    text-align: right;
    border-top: 1px solid @border-color;
    height: 40px;
    padding-top: 6px;
  }
  .el-select {
    width: 100%;
  }
  .el-dialog__body {
    padding: 10px 20px;
  }
  .el-date-editor.el-input.el-date-editor--datetime {
    width: 100%;
  }
}
// 页面样式
.taskMonitorContainer {
  height: 100%;
  position: relative;
  box-sizing: border-box;
  div {
    box-sizing: border-box;
  }
  .line {
    text-align: center;
  }
  .operation {
    position: absolute;
    height: @operationHeight;
    top: 0px;
    left: 10px;
    right: 10px;
    border-bottom: 1px dashed @border-color;
  }
  .part_1 {
    height: 55px;
    text-align: right;
    margin-right: -10px;
  }
  .contents {
    position: absolute;
    width: 100%;
    height: 100%;
    padding: 0px 10px;
    .operation > div {
      display: inline-block;
      text-align: right;
      button {
        width: 90px;
      }
    }
    .tableContent {
      padding: 10px;
      position: absolute;
      top: @operationHeight;
      left: 0;
      right: 0;
      bottom: 40px;
      overflow-y: auto;
    }
  }
  .distributeInspectorFiled {
    padding-top: 10px;
    margin-bottom: 10px;
    .el-checkbox + .el-checkbox {
      margin-left: 0px;
    }
    .el-checkbox__label {
      display: inline-block;
      min-width: 100px;
    }
    .btns {
      text-align: right;
    }
  }
  .charts-container {
    position: absolute;
    left: 10px;
    right: 10px;
    bottom: 10px;
    top: 55px;
    padding: 10px;
    .chart_box {
      box-sizing: border-box;
      flex-grow: 1;
      width: 100%;
      border: 1px solid @border-color;
      border-radius: 3px;
      height: 50%;
      margin: 0 auto;
    }
    #totalChart {
      margin-bottom: 10px;
    }
  }
  .list {
    .Row {
      overflow: hidden;
      .el-form-item {
        label {
          width: 90px;
        }
        div.el-form-item__content {
          width: 160px;
          .el-date-editor.el-input.el-date-editor--datetimerange {
            width: 100%;
          }
        }
        &.btn {
          div.el-form-item__content {
            width: 100px;
          }
        }
        &.btn:last-child {
          margin-right: 0px;
          div.el-form-item__content {
            width: 120px;
          }
        }
        &.btn:last-child {
          button {
            width: 120px;
          }
        }
      }
    }
  }
}
</style>
<style>
#taskMonitorContainer .el-dialog--small {
  width: 65% !important;
}
#taskMonitorContainer .hidden {
  display: none;
}
</style>
<style lang="less">
.taskMonitorContainer {
  .operation {
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
  .recordingplay {
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
}
</style>
