<template>
  <div style="height: 100%;position: relative;overflow: hidden;">
    <div>
      <div class="titleLeft">质检校准会</div>
      <div class="titleRight">
        <el-form :inline="true">
          <el-form-item label="已制定标准成绩" v-if="roleCodeId.includes('qa_suvs')">
            <el-select v-model="queryParams.leaderSubmit" style="width:90px">
              <el-option
                v-for="item in leaderSubmits"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="任务状态">
            <el-select v-model="queryParams.taskState" placeholder="请选择" clearable>
              <el-option
                v-for="item in taskStatus"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="质检校准会开始日期">
            <el-date-picker
              type="datetimerange"
              :clearable="false"
              :editable="false"
              v-model="queryParams.dateRange"
            ></el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="queryCalibrateData">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="cablContent">
      <div class="cabliScroll" style="overflow-y:auto;">
        <div style="padding: 0px 19px;">
          <el-table
            border
            tooltip-effect="dark"
            @row-click="rowClick"
            :data="dataList"
            ref="calibrateDataTable"
          >
            <el-table-column prop="callId" label="录音编号">
              <template scope="scope">
                <el-button
                  type="text"
                  @click="
                    jumpToSound(
                      scope.row.calibrateId,
                      scope.row.callId,
                      scope.row.calibrateTaskId,
                      scope.row.calibrateState,
                      scope.row.isCreator,
                      scope.row.recordFileURL
                    )
                  "
                >
                  {{ scope.row.callId }}
                </el-button>
              </template>
            </el-table-column>
            <el-table-column
              prop="seatName"
              label="坐席姓名"
              width="80px"
            ></el-table-column>
            <el-table-column
              prop="callSTime"
              sortable
              :formatter="formatDate"
              label="录音时间"
              width="200"
            ></el-table-column>
            <el-table-column prop="timeSlot" sortable label="校准会时间段" width="330">
            </el-table-column>
            <el-table-column
              prop="calibrateState"
              label="任务状态"
              width="100px"
            ></el-table-column>
            <el-table-column prop="totalNum" label="进度" width="160" v-if="groupTim">
              <template scope="scope">
                <span v-if="scope.row.isCreator" type="text"
                  >共{{ scope.row.totalNum }}人({{ scope.row.nowNum }}人已提交)</span
                >
              </template>
            </el-table-column>
            <el-table-column label="操作" width="130px" prop="qaSubmit">
              <template scope="scope">
                <el-button
                  funcId="000348"
                  icon="document"
                  type="text"
                  size="small"
                  v-if="scope.row.isCreator == true && scope.row.leaderSubmit == false"
                  @click="
                    jumpToSound(
                      scope.row.calibrateId,
                      scope.row.callId,
                      scope.row.calibrateTaskId,
                      scope.row.calibrateState,
                      scope.row.isCreator,
                      scope.row.recordFileURL
                    )
                  "
                >
                  制定标准成绩
                </el-button>
                <el-button
                  funcId="000370"
                  icon="document"
                  type="text"
                  size="small"
                  v-if="
                    scope.row.isCreator == false &&
                      scope.row.qaSubmit == false &&
                      scope.row.calibrateState != '已结束'
                  "
                  @click="
                    jumpToSound(
                      scope.row.calibrateId,
                      scope.row.callId,
                      scope.row.calibrateTaskId,
                      scope.row.calibrateState,
                      scope.row.isCreator,
                      scope.row.recordFileURL
                    )
                  "
                >
                  打分
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div class="qaCalibration-page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="queryParams.currentPage"
          :page-sizes="queryParams.pageSizes"
          :page-size="queryParams.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="totalCount"
        >
        </el-pagination>
      </div>
    </div>
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="singleWrap"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Qs from 'qs'
import moment from 'moment'
import bus from '../../common/bus.js'
import global from '../../../global.js'
import cache from '../../../utils/cache'
const qualityUrl = global.qualityUrl + '/'
import formatdate from '../../../utils/formatdate.js'
import funcFilter from '@/utils/funcFilter.js'
import recordingplay from '../recordingPlay/recordingPlayCailbratMeet.vue'
const datePattern = 'YYYY-MM-DD HH:mm:ss'
let currentBaseUrl = global.qualityUrl
let requestUrls = {
  getPageConstantUrl: qualityUrl + 'pageConstant/getValue.do',
  getAllAlignUrl: qualityUrl + 'csc/getAllAlign.do',
}
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      queryParams: {
        taskState: '',
        dateRange: '',
        leaderSubmit: false,
        currentPage: 1,
        pageSize: 10,
      },
      leaderSubmits: [{ name: '否', id: false }, { name: '是', id: true }],
      taskStatus: [],
      dataList: [],
      pageSizes: [10, 20, 30],
      totalCount: 0,
      groupTim: false,
      recordDialogVisible: false,
      roleCodeId: [], // 角色编码
    }
  },
  methods: {
    // 关闭录音弹窗
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 获取角色编码
    initActRole() {
      let codes = cache.getItem('roleInfo')
      this.roleCodeId = codes.split(',')
      console.log(this.roleCodeId)
    },
    queryCalibrateData: function() {
      let fromData = ''
      let toform = ''
      if (this.queryParams.dateRange == null) {
        this.fromData = ''
        this.toform = ''
      } else {
        if (
          this.queryParams.dateRange[0] != undefined &&
          this.queryParams.dateRange[0] != ''
        ) {
          fromData = formatdate.formatDate(this.queryParams.dateRange[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromData = formatdate.formatDate(now)
        }
        if (
          this.queryParams.dateRange[1] != undefined &&
          this.queryParams.dateRange[1] != ''
        ) {
          toform = formatdate.formatDate(this.queryParams.dateRange[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toform = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.queryParams.dateRange = [fromData, toform]
      console.info('ssssssss = ' + this['queryParams']['taskState'])
      let params = {}
      params['status'] = this['queryParams']['taskState']
      params['startTimeStar'] = fromData
      params['startTimeStop'] = toform
      params['currentPage'] = this['queryParams']['currentPage']
      params['pageSize'] = this['queryParams']['pageSize']
      params['leaderSubmit'] = this['queryParams']['leaderSubmit']
      let obj = {}
      obj.searchModel = params
      this.$store.commit('setRecordingPlayPage', obj)
      let self = this
      this.axios
        .post(requestUrls['getAllAlignUrl'], Qs.stringify(params))
        .then(function(response) {
          self.dataList = response['data']['Data']
          self.filterButton() // 过滤权限按钮
          self.totalCount = response['data']['Count']
          for (let i; i < self.dataList.length; i++) {
            self.startTime = formatdate.formatDate(self.dataList[i].startTime)
            self.endTime = formatdate.formatDate(self.dataList[i].endTime)
          }
        })
        .catch(function() {
          self.$message.error('查询校准会信息发生错误!')
        })
    },
    initTime: function() {
      let fromData = ''
      let toform = ''
      if (
        this.queryParams.dateRange[0] != undefined &&
        this.queryParams.dateRange[0] != ''
      ) {
        fromData = formatdate.formatDate(this.queryParams.dateRange[0])
      } else {
        // 默认获取当前月的第一天
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromData = formatdate.formatDate(now)
      }
      if (
        this.queryParams.dateRange[1] != undefined &&
        this.queryParams.dateRange[1] != ''
      ) {
        toform = formatdate.formatDate(this.queryParams.dateRange[1])
      } else {
        // 默认获取当前月的最后一天
        let now = new Date()
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toform = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      }
      this.queryParams.dateRange = [fromData, toform]
    },
    rowClick: function(row) {
      this.callIdJump = row.callId
    },
    // 跳转到录音播放页面
    jumpToSound: function(
      calibrateId,
      callId,
      calibrateTaskId,
      calibrateTaskState,
      isCreator,
      recordFileURL
    ) {
      let obj = {}
      obj.from = 'qaCalibration'
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.calibrateId = calibrateId
      obj.calibrateTaskId = calibrateTaskId
      if (calibrateTaskState == '进行中') {
        obj.calibrateTaskState = '2'
      } else if (calibrateTaskState == '已结束') {
        obj.calibrateTaskState = '3'
      } else {
        obj.calibrateTaskState = '1'
      }
      obj.isCreator = isCreator === true ? '0' : '1'
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    formatDate: function(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format(datePattern)
      }
      return ''
    },
    handleSizeChange: function(val) {
      this['queryParams']['pageSize'] = val
      this['queryParams']['currentPage'] = 1
      this.queryCalibrateData()
    },
    handleCurrentChange: function(val) {
      this['queryParams']['currentPage'] = val
      this.queryCalibrateData()
    },
    isQa() {
      let _this = this
      let url = currentBaseUrl + '/csc/isQa.do'
      let params = {}
      _this.axios
        .post(url, Qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.groupTim = true
            _this.taskStatus = [
              { name: '请选择', id: '' },
              { name: '未开始', id: 1 },
              { name: '进行中', id: 2 },
              { name: '已结束', id: 3 },
            ]
          } else {
            _this.groupTim = false
            _this.taskStatus = [
              { name: '请选择', id: '' },
              { name: '进行中', id: 2 },
              { name: '已结束', id: 3 },
            ]
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '角色判断失败',
          })
        })
    },
    /*
  * 过滤权限按钮
  * */
    filterButton() {
        /*
       获取数据后dom节点更改了，
        需要再获取一遍dom节点对[funcID]按钮进行过滤
       * */
        let menuId = localStorage.getItem('menuId')
        let path = this.$route.path.replace('/', '')
        funcFilter(menuId, path)
    }
  },
  created() {
    this.recordPlayCloseHandler()
    this.isQa()
    this.initTime()
    this.initActRole()
    if (
      this.recordingPlayPage.fromPage == 'qaCalibration' &&
      this.recordingPlayPage.searchModel.currentPage
    ) {
      this.queryParams.pageSize = this.recordingPlayPage.searchModel.pageSize
      this.queryParams.currentPage = this.recordingPlayPage.searchModel.currentPage
      this.queryParams.taskState = this.recordingPlayPage.searchModel.status
      this.queryParams.dateRange = this.recordingPlayPage.searchModel.dateRangeArr
      this.queryCalibrateData()
    } else if (
      this.recordingPlayPage.fromPage == 'homepage' &&
      this.recordingPlayPage.calibrateTaskState
    ) {
      // 首页进来，质检主管默认是未开始的，质检员默认是进行中的
      if (!this.roleCodeId.includes('qa_suvs')) {
        this['queryParams']['taskState'] = this.recordingPlayPage.calibrateTaskState
      }
      // 用完后还原from，不然会影响下次点击跳转默认值显示
      let obj = {
        fromPage: 'router',
      }
      this.$store.commit('setRecordingPlayPage', obj)
      this.queryCalibrateData()
    } else {
      this.queryCalibrateData()
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
    accountId() {
      return this.$store.state.loginUserinfo.accountId
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.titleLeft {
  display: inline-block;
  padding: 20px 19px;
  font-size: 14px;
}
.titleRight {
  display: inline-block;
  float: right;
  padding: 10px 10px 0 0;
  form {
    height: 52px;
  }
}
.cablContent {
  padding-top: 12px;
  padding-bottom: 140px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
</style>
<style lang="less">
.cabliScroll {
  height: 100%;
  width: 100%;
  th {
    background-color: #e0e6ed;
    color: #475669;
    padding: 10px 0;
  }
  .el-table {
    td {
      padding: 6px 0;
    }
  }
}
.cablContent .qaCalibration-page {
  right: 10px;
  position: absolute;
  bottom: 10px;
  .el-pagination {
    white-space: nowrap;
    padding: 2px 5px;
    color: #303133;
    font-weight: 700;
  }
}
.el-dialog__wrapper.singleWrap {
  position: fixed;
  top: 106px;
  left: 20px;
  right: 20px;
  bottom: 12px;
  .el-dialog {
    width: 100%;
    height: 100%;
    margin: 0 !important;
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}
</style>
