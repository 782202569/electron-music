<template>
  <div class="qaCalibration" id="qaCalibration">
    <div class="taskSetting">
      <div class="qaCalibration-header">
        <div class="operation">
          <div class="searchForm">
            <el-form :inline="true">
              <el-form-item label="任务状态">
                <el-select v-model="queryParams.taskState" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in taskStatus"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  ></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="校准会日期">
                <el-date-picker
                  type="datetimerange"
                  :editable="false"
                  v-model="queryParams.dateRange"
                ></el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="queryCalibrateData">查询</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <div class="qaCalibration-content">
        <div class="qaCalibration-content-pos" style="overflow-y:auto;">
          <div style="width:100%;height:100%;">
            <el-table
              border
              tooltip-effect="dark"
              @row-click="rowClick"
              :data="dataList"
              ref="calibrateDataTable"
            >
              <el-table-column type="index" label="序号" width="80"></el-table-column>
              <el-table-column prop="orderNo" label="订单编号">
                <template scope="scope">
                  <el-button type="text" @click="showDetail(scope.row)">{{
                    scope.row.orderNo
                  }}</el-button>
                </template>
              </el-table-column>
              <el-table-column prop="submiterName" label="提交人姓名"></el-table-column>
              <el-table-column
                prop="orderTime"
                :formatter="formatDate"
                label="下单时间"
                sortable
              ></el-table-column>
              <el-table-column
                prop="createTime"
                :formatter="formatDate"
                label="分配时间"
                sortable
              ></el-table-column>
              <el-table-column
                prop="startTime"
                :formatter="formatDate"
                label="校准会开始时间"
                sortable
              ></el-table-column>
              <el-table-column prop="statusName" label="任务状态">
                <template scope="scope">
                  <el-tag
                    close-transition
                    type="gray"
                    v-if="scope.row.statusName == '未开始'"
                    >未开始</el-tag
                  >
                  <el-tag
                    close-transition
                    type="primary"
                    v-if="scope.row.statusName == '进行中'"
                    >进行中</el-tag
                  >
                  <el-tag
                    close-transition
                    type="success"
                    v-if="scope.row.statusName == '已结束'"
                    >已结束</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column label="操作" width="200px">
                <template scope="scope">
                  <el-button
                    icon="document"
                    type="text"
                    size="small"
                    @click="showDetail(scope.row)"
                    >查看</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="qaCalibration-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="queryParams.currentPage"
            :page-sizes="queryParams.pageSizes"
            :page-size="queryParams.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalCount"
          ></el-pagination>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Qs from 'qs'
import moment from 'moment'
import global from '../../../global.js'
const qualityUrl = global.qualityUrl + '/'
const datePattern = 'YYYY-MM-DD HH:mm:ss'

let requestUrls = {
  getPageConstantUrl: qualityUrl + 'pageConstant/getValue.do',
  getAllAlignUrl: qualityUrl + 'cscOrder/getAllAlign.do',
}

export default {
  data() {
    return {
      orderNoJump: '',
      queryParams: {
        taskState: '',
        dateRange: '',
        currentPage: 1,
        pageSize: 10,
      },
      taskStatus: [],
      dataList: [],
      taskStateMap: null,
      pageSizes: [10, 20, 30],
      totalCount: 0,
    }
  },
  methods: {
    rowClick: function(row) {
      this.orderNoJump = row.orderNo
    },
    formatDate: function(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format(datePattern)
      }
      return ''
    },
    getStatusName: function(row, column, cellValue) {
      if (cellValue) {
        for (let n of this.taskStatus) {
          console.log(n.id)
        }
      }
    },
    convertTaskState: function(row, column, state) {
      this.getTaskStateName(state)
    },
    getTaskStateName: function(state) {
      let self = this
      if (this['taskStateMap'] === null) {
        self['taskStateMap'] = {}
        this['taskStatus'].forEach(function(taskState) {
          self['taskStateMap'][taskState['id']] = taskState['name']
        })
      }
      return this['taskStateMap'][state]
    },
    getTaskStatus: function() {
      let self = this
      this.axios
        .post(
          requestUrls['getPageConstantUrl'],
          Qs.stringify({ keys: 'calibrateTaskState' })
        )
        .then(function(response) {
          self['taskStatus'] = response['data']['calibrateTaskState']
        })
    },
    queryCalibrateData: function() {
      let params = {}
      params['status'] = this['queryParams']['taskState']
      let dateRangeArr = this['queryParams']['dateRange']
      if (dateRangeArr[0] != null) {
        params['startTimeStar'] = moment(dateRangeArr[0]).format(datePattern)
      }
      if (dateRangeArr[1] != null) {
        params['startTimeStop'] = moment(dateRangeArr[1]).format(datePattern)
      }
      params['currentPage'] = this['queryParams']['currentPage']
      params['pageSize'] = this['queryParams']['pageSize']
      let obj = {}
      obj.searchModel = params
      obj.searchModel.dateRangeArr = dateRangeArr
      this.$store.commit('setRecordingPlayPage', obj)
      let self = this
      this.axios
        .post(requestUrls['getAllAlignUrl'], Qs.stringify(params))
        .then(function(response) {
          self.dataList = response['data']['Data']
          self.totalCount = response['data']['Count']
        })
        .catch(function() {
          self.$message.error('查询校准会信息发生错误!')
        })
    },
    handleSizeChange: function(val) {
      this['queryParams']['pageSize'] = val
      this['queryParams']['currentPage'] = 1
      this.queryCalibrateData()
    },
    handleCurrentChange: function(val) {
      this['queryParams']['currentPage'] = val
      this.queryCalibrateData()
    },
    // 跳转到订单录音播放页
    showDetail(scope) {
      let obj = {}
      obj.pageId = 'qaCalibrationOrder'
      let jsonData = {}
      jsonData.orderNo = scope.orderNo // 订单编号
      jsonData.recordFileURL = scope.recordFileURL // 订单录音地址
      jsonData.modleId = scope.modleId // 模板id
      jsonData.calibrateId = scope.calibrateId // 校准会id
      jsonData.calibrateScoreId = scope.calibrateScoreId // 校准会分数id
      jsonData.statusName = scope.statusName // 校准会任务状态
      obj.callId = JSON.stringify(jsonData)
      this.$store.commit('setRecordingPlayPage', obj)
      this.$router.push({ path: '/recordingPlayOrder', query: obj })
    },
  },
  mounted() {
    this.getTaskStatus()
    if (
      this.recordingPlayPage.fromPage == 'qaCalibration' &&
      this.recordingPlayPage.searchModel.currentPage
    ) {
      this.queryParams.pageSize = this.recordingPlayPage.searchModel.pageSize
      this.queryParams.currentPage = this.recordingPlayPage.searchModel.currentPage
      this.queryParams.taskState = this.recordingPlayPage.searchModel.status
      this.queryParams.dateRange = this.recordingPlayPage.searchModel.dateRangeArr
      this.queryCalibrateData()
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less">
.qaCalibration {
  .operation {
    .time {
      .el-date-editor.fr.el-input.el-date-editor--datetimerange,
      .el-select.fr {
        width: 175px;
      }
    }
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
}
</style>
<style scoped="scoped" lang="less">
@boder-color: #d1dbe5;
.qaCalibration {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;

  .operation {
    height: 55px;
    line-height: 55px;
    position: relative;
    border-bottom: 1px dashed @boder-color;
    text-align: right;
    margin-right: -10px;

    .el-form-item {
      margin-bottom: 0px;

      .el-form-item__content {
        line-height: 55px;
      }
    }
    & > div {
      display: inline-block;
      text-align: right;

      button {
        width: 90px;
      }

      & .searchForm {
        position: absolute;
        right: -10px;

        div.el-form-item__content {
          vertical-align: middle !important;
          border: 1px solid red;
        }
      }
    }
  }
  .taskResult {
    .operation {
      .tips {
        & > label {
          color: #9dadc2;
          font-size: 14px;
        }

        & > span {
          margin: 0px 10px 0px 5px;
        }
      }
      .btns {
        float: right;
        margin-right: -10px;
      }
    }
  }
  .qaCalibration-content {
    box-sizing: border-box;
    position: absolute;
    top: 65px;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 0px 10px;
    padding-bottom: 40px;
    overflow: hidden;
  }

  .qaCalibration-content .qaCalibration-content-pos {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }

  .qaCalibration-content .qaCalibration-page {
    width: 100%;
    height: 35px;
    position: absolute;
    left: 0;
    right: 0px;
    bottom: 0;
    text-align: right;
  }

  .qaCalibration-page .el-pagination {
    display: inline-block;
    height: 28px;
    line-height: 28px;
    padding: 0px 10px;
  }

  #newTaskdialog .el-dialog__body {
  }

  #qaCalibration .qaCalibration-content-pos .el-table__body-wrapper {
    overflow-x: hidden;
  }

  .btns {
    text-align: right;
  }

  table .cell > i {
    width: 35px;

    & > i {
      font-family: '微软雅黑';
      margin-left: 4px;
      font-size: 14px;
    }
  }
}
</style>
