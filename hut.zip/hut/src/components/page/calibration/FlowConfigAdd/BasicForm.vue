<template>
  <el-form
    label-width="120px"
    ref="$form"
    label-position="left"
    :model="formData"
    :validate-on-rule-change="false"
    :rules="rules"
  >
    <el-form-item
      label="流程名称"
      prop="flowName"
      :rules="[
        { required: true, message: '请填写流程名称', trigger: 'blur' },
        { max: 10, message: '流程名称不能超过10个字符', trigger: 'blur' },
        { validator: checkHasRepeat, trigger: 'blur' },
        { validator: validatorEmpty, trigger: 'change' },
      ]"
    >
      <el-input
        class="input-w-316"
        v-model="formData.flowName"
        placeholder="请填写流程名称"
        clearable
      ></el-input>
    </el-form-item>

    <!-- 新增进来时，取未被用过的客户业务意图，编辑时获取所有的客户业务意图，用来匹配已选中的客户业务意图-->
    <el-form-item label="客户业务意图" prop="intention" v-if="state === 'edit'">
      <el-select
        disabled
        class="input-w-316"
        placeholder="请选择客户业务意图"
        v-model="formData.intention"
      >
        <el-option
          v-for="purpose of purposeList"
          :key="purpose.id"
          :label="purpose.name"
          :value="purpose.id"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="客户业务意图" prop="intention" v-else>
      <el-select
        class="input-w-316"
        placeholder="请选择客户业务意图"
        v-model="formData.intention"
      >
        <el-option
          v-for="purpose of unusedPurposeList"
          :key="purpose.id"
          :label="purpose.name"
          :value="purpose.id"
        />
      </el-select>
    </el-form-item>

    <el-form-item label="知识库" prop="knowledge">
      <el-input
        type="textarea"
        class="input-w-316"
        :rows="5"
        :autosize="{ minRows: 2, maxRows: 6 }"
        placeholder="请输入知识库"
        maxlength="100"
        v-model="formData.knowledge"
      ></el-input>
    </el-form-item>
  </el-form>
</template>

<script>
import global from '@/global.js'
import Qs from 'qs'
let currentBaseUrl = global.qualityUrl
const validator = {
  empty(rule, value, callback) {
    const errors = []
    if (/^\s*(?:null|undefined)?\s*$/.test(value)) {
      errors.push('请输入非空字符')
    }
    callback(errors)
  },
}

export default {
  name: 'BasicForm',
  props: {
    // 回填数据
    data: Object,
    state: {
      type: String,
      default: 'new',
    },
    // 所有客户意图列表
    purposeList: {
      type: Array,
      default: () => [],
    },
    // 未被用过的客户意图列表
    unusedPurposeList: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    const { data } = this.$props
    const formData = Object.assign(
      {
        // 流程名称
        flowName: '',
        // 客户业务意图名称
        intention: '',
        // 知识库
        knowledge: '',
      },
      data
    )
    return {
      // 表单数据
      formData,
      // 表单校验规则
      rules: {
        // flowName: [
        //   { required: true, message: '请填写流程名称', trigger: 'blur' },
        //   { max:10, message: '流程名称不能超过10个字符' , trigger: 'blur' },
        //   { validator: validator.empty, trigger: 'change' },
        // ],
        // 意图
        intention: [
          //{ required: true, message: '请选择客户业务意图', trigger: 'blur' },
          //{ validator: validator.empty, trigger: 'blur' },
        ],
      },
    }
  },

  methods: {
    // 验证表单
    validate() {
      return new Promise((resolve, reject) => {
        this.$refs.$form.validate((valid) => {
          if (valid) {
            resolve(this.getData())
          } else {
            reject('流程基础信息不正确，请检查相应输入项')
          }
        })
      })
    },

    // 获取表单数据
    getData() {
      const { formData } = this
      return {
        ...formData,
      }
    },

    //流程名称重复判断
    checkHasRepeat(rule, value, callback) {
      const errors = []
      if (value) {
        let _this = this
        let params = {
          processName: _this.formData.flowName,
          processId: _this.formData.flowId,
        }
        _this.axios
          .post(
            `${currentBaseUrl}/customerIntentConfig/processNameIsExist.do`,
            Qs.stringify(params)
          )
          .then((res) => {
            if (res.data == true) {
              errors.push('流程名称重复，请重新输入！')
            }
          })
          .then(() => {
            callback(errors)
          })
      }
    },
    validatorEmpty(rule, value, callback) {
      const errors = []
      if (/^\s*(?:null|undefined)?\s*$/.test(value)) {
        errors.push('请输入非空字符')
      }
      callback(errors)
    },
  },
}
</script>

<style scoped lang="less">
.input-w-316 {
  width: 316px;
}

.icon-wrap {
  display: inline-block;
  position: relative;
  top: -2px;
  font-size: 18px;
  vertical-align: middle;
  line-height: 25px;
  color: #c0c4cc;

  i {
    cursor: pointer;
    margin-left: 6px;
  }
}
</style>
