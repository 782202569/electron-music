<template>
  <el-dialog
    width="500px"
    title="添加工单抓取"
    :visible.sync="dialogVisible"
    :close-on-click-modal="false"
    @closed="reset"
  >
    <el-form
      label-width="130px"
      ref="$form"
      label-position="left"
      :model="formData"
      :validate-on-rule-change="false"
      :rules="rules"
    >
      <el-form-item label="抓取工单字段名" prop="fieldName">
        <el-input class="input-w-316" maxlength="10" v-model="formData.fieldName" />
      </el-form-item>

      <el-form-item label="工单抓取规则" prop="ruleId">
        <el-select class="input-w-316" v-model="formData.ruleId">
          <el-option
            v-for="rule of filterRuleList(ruleList)"
            :key="rule.id"
            :label="rule.name"
            :value="rule.id"
          />
        </el-select>
      </el-form-item>
    </el-form>

    <div slot="footer">
      <el-button @click="dialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="setOrderField">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import deepClone from 'lodash/cloneDeep'
import global from '@/global.js'

const currentBaseUrl = global.qualityUrl

const defaultData = {
  // 弹框可见性
  dialogVisible: false,
  // 表单数据
  formData: {
    // 抓取工单字段名称
    fieldName: '',
    // 抓取规则ID
    ruleId: null,
  },
  // 工单抓取规则列表
  ruleList: [],
}

export default {
  name: 'WorkOrderDialog',
  props: {
    // 可见性
    visible: {
      type: Boolean,
      default: false,
    },
    // 当前已选的工单规则项
    selectedRules: {
      type: Array,
      default: () => [],
    },
    // 保存工单字段抓取规则
    onSaveOrderFieldRule: {
      type: Function,
      default: () => {},
    },
  },

  data() {
    const { visible } = this.$props
    return {
      ...deepClone(defaultData),
      // 校验规则配置
      rules: {
        fieldName: [
          {
            required: true,
            message: '请输入字段名称',
          },
          {
            validator: (rule, value, callback) => {
              const errors = []
              if (/^\s*(?:null|undefined)?\s*$/.test(value)) {
                errors.push('请输入非空字符')
              } else if (this.isNameDuplicated(value)) {
                errors.push('字段名重复')
              }
              callback(errors)
            },
          },
        ],
        ruleId: {
          required: true,
          message: '请选择抓取规则',
        },
      },
      dialogVisible: !!visible,
    }
  },

  watch: {
    dialogVisible(visible) {
      this.$emit('update:visible', !!visible)
      if (visible) {
        const {
          $refs: { $form },
        } = this
        if ($form) {
          $form.clearValidate()
        }
        this.fetchRuleList()
      }
    },
    visible(visible) {
      this.dialogVisible = !!visible
    },
  },

  methods: {
    // 获取工单规则列表
    fetchRuleList() {
      const { ruleList } = this
      if (!ruleList.length) {
        return this.axios
          .post(`${currentBaseUrl}/workorderCfg/getEnableCfg.do`)
          .then(({ data }) => {
            if (Array.isArray(data)) {
              this.ruleList = data.map((item) => ({
                ...item,
                id: item.workorderCfgId,
                name: item.workorderCfgName,
              }))
            }
          })
      }
    },

    // 过滤规则列表，去掉已选择的
    filterRuleList(list) {
      let { selectedRules } = this
      if (Array.isArray(selectedRules)) {
        return list.filter(
          (item) => !selectedRules.some((rule) => rule.ruleId === item.id)
        )
      }
      return list
    },

    // 检查字段名称是否重复
    isNameDuplicated(name) {
      const { selectedRules } = this
      if (Array.isArray(selectedRules)) {
        return selectedRules.some((item) => item.fieldName === name)
      }
      return false
    },

    // 重置
    reset() {
      this.$refs.$form.clearValidate()
      Object.assign(this, deepClone(defaultData), {
        ruleList: this.ruleList,
      })
    },

    // 根据规则ID获取规则对象
    getRuleById(id) {
      const ruleList = this.ruleList
      return Array.isArray(ruleList) ? ruleList.find((item) => item.id === id) : null
    },

    // 设置抓取规则
    setOrderField() {
      const {
        formData: { ruleId, fieldName },
        $refs: { $form },
      } = this
      // 校验表单
      $form.validate((valid) => {
        if (valid) {
          this.onSaveOrderFieldRule(
            Object.assign({}, this.getRuleById(ruleId), { ruleId }, { fieldName })
          )
          this.dialogVisible = false
        }
      })
    },
  },
}
</script>

<style scoped lang="less">
.input-w-316 {
  width: 316px;
}
</style>
