<template>
  <el-dialog
    width="560px"
    class="flow-config-purpose-dialog"
    :title="dialogTitle"
    :visible.sync="dialogVisible"
    :close-on-click-modal="false"
    @closed="reset"
  >
    <el-radio-group class="header" v-model="mode">
      <el-radio label="always">无条件跳转</el-radio>
      <el-radio label="logic">逻辑跳转</el-radio>
    </el-radio-group>

    <!--无条件-->
    <el-form
      v-if="mode === 'always'"
      label-width="120px"
      ref="$form"
      label-position="left"
      :model="formData.always"
      :validate-on-rule-change="false"
      :rules="rules.always"
    >
      <el-form-item label="跳转至" prop="purpose">
        <el-select
          class="input-w-316"
          v-model="formData.always.purpose"
          @change="clearValidateInfo('purpose')"
        >
          <el-option
            v-for="purpose of purposeList"
            :key="purpose.id"
            :label="purpose.text"
            :value="purpose.id"
          />
        </el-select>
      </el-form-item>
    </el-form>

    <!--逻辑-->
    <el-form
      v-if="mode === 'logic'"
      label-width="200px"
      ref="$form"
      label-position="left"
      :model="formData.logic"
      :validate-on-rule-change="false"
      :rules="rules.logic"
    >
      <el-form-item label="客户对应回答是(后置条件)" prop="condition">
        <el-select
          class="input-w-316"
          v-model="formData.logic.condition"
          @change="setConditionAnswers"
        >
          <el-option
            v-for="condition of conditionList"
            :key="condition.id"
            :label="condition.name"
            :value="condition.id"
          />
        </el-select>
      </el-form-item>

      <div v-if="formData.logic.condition" class="separate-line"></div>

      <template v-if="formData.logic.answers.length">
        <el-form-item
          v-for="(answer, index) of formData.logic.answers"
          :key="answer.id"
          :prop="'answers.' + index + '.purpose'"
          :rules="{ required: true, message: '请选择意图', trigger: 'blur' }"
        >
          <div class="custom-label-logic" slot="label">
            <div class="display-flex">
              <span>"{{ answer.name }}"</span>
              <span>流程跳转至</span>
            </div>
          </div>
          <el-select
            class="input-w-316"
            v-model="answer.purpose"
            @change="
              correctAnswerPurpose(
                answer,
                formData.logic.answers,
                'answers.' + index + '.purpose'
              )
            "
            :placeholder="answer.placeholder"
            clearable
          >
            <el-option
              v-for="purpose of filterPurposeList(
                purposeList,
                answer,
                formData.logic.answers
              )"
              :key="purpose.id"
              :label="purpose.text"
              :value="purpose.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </template>

      <template v-else-if="formData.logic.condition">
        <div class="condition-answer-hint" v-loading="selectedCondition.loading">
          <span v-show="!selectedCondition.loading">
            没有可用的回答配置
          </span>
        </div>
      </template>
    </el-form>

    <div slot="footer">
      <el-button @click="dialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="setPostPurpose">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import deepClone from 'lodash/cloneDeep'
import global from '@/global.js'

const currentBaseUrl = global.qualityUrl

// 默认的表单数据
const defaultFormData = {
  // 无条件跳转
  always: {
    purpose: '',
  },
  // 逻辑跳转
  logic: {
    answers: [],
  },
}
//  默认数据状态
const defaultData = {
  dialogVisible: false,
  // 模式
  mode: 'always', // always logic
  // 意图列表
  purposeList: [],
  // 表单数据
  formData: deepClone(defaultFormData),
  // 校验规则
  rules: {
    // 无条件跳转
    always: {
      purpose: {
        required: true,
        message: '请选择意图',
        trigger: 'blue',
      },
    },
    // 逻辑跳转
    logic: {
      condition: {
        required: true,
        message: '请选择后置条件',
        trigger: 'blur',
      },
    },
  },
}

export default {
  name: 'ConfigDialog',
  props: {
    // 可见性
    visible: {
      type: Boolean,
      default: false,
    },
    // 当前配置的坐席意图名称
    seatPurposeName: {
      type: String,
      default: '',
    },
    // 上一次选中的项
    lastConfigData: {
      type: Object,
      default: () => deepClone(defaultFormData),
    },
    // 后置前提条件列表
    conditionList: {
      type: Array,
      default: () => [],
    },
    // 流程ID
    flowId: String,
    // 获取意图列表
    onGetPurposeList: {
      type: Function,
      default: () => {},
    },
    // 获取本地意图列表
    onGetLocalPurposeList: {
      type: Function,
      default: () => {},
    },
    // 获取后置前提条件的回答列表
    onGetConditionAnswers: {
      type: Function,
      default: () => {},
    },
    // 保存后置意图
    onSavePostPurpose: {
      type: Function,
      default: () => {},
    },
  },
  data() {
    const { visible } = this.$props
    return {
      purposeList: [],
      ...deepClone(defaultData),
      dialogVisible: !!visible,
    }
  },
  watch: { 
    dialogVisible(visible) {
      this.$emit('update:visible', !!visible)
      if (visible) {
        // this.fetchPurposeList()
        // 改从前端读取流程意图配置项
        this.getLocalPurposeList()
        this.setDefaultFormData(deepClone(this.lastConfigData))
      }
    },
    visible(visible) {
      this.dialogVisible = !!visible
    },
    mode() {
      this.$nextTick(() => {
        const form = this.$refs.$form
        if (form) {
          form.clearValidate()
        }
      })
    },
  },

  computed: {
    // 当前选择的后置条件对象
    selectedCondition() {
      return this.getConditionById(this.formData.logic.condition) || {}
    },
    // 对话框标题
    dialogTitle() {
      const name = this.seatPurposeName
      return `配置后置条件${name ? `（${name}）` : ''}`
    },
  },

  methods: {
    // 加载已保存的流程意图列表
    fetchPurposeList() {
      this.axios
        .get(`${currentBaseUrl}/customerIntentConfig/getExistProcessOrder.do`, {
          params: {
            processId: this.flowId,
          },
        })
        .then(({ data }) => {
          if (Array.isArray(data)) {
            this.purposeList = this.onGetPurposeList(data)
          }
        })
    },

    // 获取本地意图列表
    getLocalPurposeList() {
      const list = this.onGetLocalPurposeList()
      if (Array.isArray(list)) {
        this.purposeList = [...list]
      }
    },

    // 设置默认的表单数据
    setDefaultFormData(data) {
      const { mode, ...formData } = Object.assign({}, data)
      const { logic, always } = formData || {}
      const purposeList = this.purposeList
      if (mode) {
        this.mode = mode
      }
      // 清除已经删除的意图项值
      if (always) {
        const { purpose } = always
        if (!purpose || !purposeList.some((item) => `${item.id}` === `${purpose}`)) {
          always.purpose = ''
        }
      }
      if (logic) {
        let { answers } = logic
        if (Array.isArray(answers)) {
          logic.answers = answers
          answers.forEach((answer) => {
            const { purpose } = answer
            if (!purposeList.some((item) => `${item.id}` === `${purpose}`)) {
              answer.purpose = ''
            }
          })
        }
      }
      this.formData = Object.assign(this.formData, formData)
    },

    // 过滤意图列表，排除其他回答已经选中的意图项
    filterPurposeList(purposeList, curr, answers) {
      answers = answers.filter((item) => item !== curr)
      const list = purposeList.filter(
        (item) => !answers.some((answer) => answer.purpose === item.id)
      )
      this.$set(curr, 'placeholder', list.length ? '请选择' : '请先配置更多的坐席意图')
      return list
    },

    // 修正流程依赖关系
    correctAnswerPurpose(curr, answers, prop) {
      const { purpose } = curr
      answers
        .filter((item) => item !== curr)
        .forEach((item) => {
          if (item.purpose === purpose) {
            // 清除相同的后置流程
            item.purpose = ''
          }
        })
      // 清除错误提示
      this.clearValidateInfo(prop)
    },

    // 根据ID获取条件对象
    getConditionById(id) {
      return id ? this.conditionList.find((item) => item.id === id) : {}
    },

    // 设置条件的回答列表
    setConditionAnswers(id) {
      this.$refs.$form.clearValidate()
      const condition = this.getConditionById(id)
      if (Object.keys(condition).length) {
        condition.loading = true
        this.onGetConditionAnswers(condition)
          .then((list) => {
            condition.loading = false
            this.formData.logic.answers = (Array.isArray(list) ? list : []).map(
              (item) => ({
                ...item,
              })
            )
          })
          .catch(() => {
            condition.loading = false
          })
      }
    },

    // 重置
    reset() {
      const {
        $refs: { $form },
      } = this
      $form.clearValidate()
      Object.assign(this, deepClone(defaultData))
    },

    // 设置后置意图
    setPostPurpose() {
      const {
        mode,
        formData,
        $refs: { $form },
      } = this
      // 校验表单
      $form.validate((valid) => {
        if (valid) {
          const postPurpose = formData[mode]
          const list = []
          if (mode === 'logic') {
            // 逻辑跳转
            let { answers, condition } = postPurpose
            if (!Array.isArray(answers)) {
              answers = []
            }
            answers.forEach((item) => {
              list.push({
                ...item,
                logic: true,
                toOrderNo: item.purpose,
                conditionId: condition,
                answerId: item.id,
              })
            })
          } else {
            const { purpose } = postPurpose
            // 无条件跳转
            list.push({
              id: Math.floor(Math.random() * 10e5) + Date.now(),
              logic: false,
              toOrderNo: purpose,
            })
          }
          const configData = deepClone(Object.assign({ mode }, formData))
          if (mode === 'logic') {
            configData.always = deepClone(defaultFormData.always)
          } else {
            configData.logic = deepClone(defaultFormData.logic)
          }
          this.onSavePostPurpose(list, configData)
          this.dialogVisible = false
        }
      })
    },

    // 记录转换为表单数据
    toFormData(data) {
      if (!Array.isArray(data)) {
        data = []
      }
      const { conditionList } = this
      const firstItem = data[0]
      const { logic, backSeatIntent, conditionId } = Object.assign({}, firstItem)
      let answers = logic
        ? (conditionList.find((item) => item.id === conditionId) || {}).answers
        : []
      if (!Array.isArray(answers)) {
        answers = []
      }
      return {
        mode: logic ? 'logic' : 'always',
        always: Object.assign(
          deepClone(defaultFormData.always),
          !logic && {
            purpose: backSeatIntent,
          }
        ),
        logic: Object.assign(
          deepClone(defaultFormData.logic),
          logic && {
            condition: conditionId || '',
            answers: answers.map((item) => ({
              ...item,
              purpose: (
                data.find(({ answerId }) => `${answerId}` === `${item.contentid}`) || {
                  backSeatIntent: '',
                }
              ).backSeatIntent,
            })),
          }
        ),
      }
    },

    // 清除校验信息
    clearValidateInfo(prop) {
      this.$refs.$form.clearValidate([prop])
    },
  },
}
</script>

<style lang="less">
.flow-config-purpose-dialog {
  .el-dialog__title {
    display: block;
    padding-right: 40px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
</style>

<style scoped lang="less">
.header {
  margin-bottom: 24px;
}

.input-w-316 {
  width: 316px;
}

.custom-label-logic {
  display: inline-block;
  width: 90%;

  .display-flex {
    display: flex;
    width: 100%;
    line-height: 1.25em;
    justify-content: space-around;
  }
}

.separate-line {
  margin: 0 4px 20px;
  height: 1px;
  background-color: #eee;
}

.condition-answer-hint {
  height: 50px;
  margin: 0 4px;
  text-align: center;
}
</style>
