<template>
  <el-dialog
    title="流程预览"
    width="900px"
    ref="$dialog"
    class="flow-config-previewer-dialog"
    :visible.sync="dialogVisible"
    :close-on-click-modal="false"
  >
    <slot></slot>
  </el-dialog>
</template>

<script>
export default {
  name: 'FlowPreviewerDialog',
  components: {},
  props: {
    // 可见性
    visible: {
      type: Boolean,
      default: false,
    },
  },

  data() {
    const { visible } = this.$props
    return {
      // 弹框可见性
      dialogVisible: !!visible,
    }
  },

  watch: {
    dialogVisible(visible) {
      this.$emit('update:visible', !!visible)
    },
    visible(visible) {
      this.dialogVisible = !!visible
    },
  },

  mounted() {
    // 这里是为了强制让对话框在未显示时渲染内容组件部分
    this.$refs.$dialog.rendered = true
  },
}
</script>

<style lang="less">
.flow-config-previewer-dialog {
  .el-dialog__body {
    padding: 10px 20px;
  }
}
</style>
