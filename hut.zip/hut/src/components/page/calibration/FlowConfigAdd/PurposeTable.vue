<template>
  <div class="flow-purpose-table-wrap">
    <el-table
      border
      row-key="uuid"
      :highlight-current-row="false"
      :cell-class-name="getCellClass"
      :row-class-name="getRowClass"
      :header-row-class-name="getHeaderRowClass"
      :data="flowPurposes"
      v-loading="loading.table"
      @cell-mouse-enter="handleCellHover(true, arguments[0], arguments[1])"
      @cell-mouse-leave="handleCellHover(false, arguments[0], arguments[1])"
    >
      <el-table-column
        label="编号"
        width="60"
        header-align="center"
        align="center"
        type="index"
        :index="1"
      />

      <el-table-column
        label="坐席意图"
        prop="purpose"
        align="center"
        width="225"
        header-align="left"
      >
        <template
          slot-scope="{ row, row: { ellipsisTitle, errorMessages, errorVisibility } }"
        >
          <el-tooltip
            placement="top"
            manual
            :open-delay="ellipsisTitle ? 1000 : 100"
            :content="ellipsisTitle || errorMessages.purpose"
            v-model="errorVisibility.purpose"
          >
            <div class="ellipsis-input-wrap" :ref="'$purpose-' + row.uuid">
              <el-select
                :disabled="row.submitted"
                :class="['input-w-200', { 'validate-error': errorMessages.purpose }]"
                v-model="row.purpose"
                @change="validateRow(row, true)"
                @visible-change="arguments[0] && (errorVisibility.purpose = false)"
                clearable
                size="small"
              >
                <el-option
                  v-for="purpose of filterSeatPurposeList(
                    seatPurposeList,
                    row,
                    flowPurposes
                  )"
                  :key="purpose.id"
                  :label="purpose.name"
                  :value="purpose.id"
                />
              </el-select>
            </div>
          </el-tooltip>
        </template>
      </el-table-column>

      <el-table-column label="后置" prop="postPurpose" width="225">
        <template
          slot-scope="{ row, row: { postPurpose, errorMessages, errorVisibility } }"
        >
          <template v-if="postPurpose && postPurpose.length">
            <div class="post-purpose-wrap">
              <a
                :class="[
                  'btn-anchor',
                  'btn-anchor-block',
                  {
                    disabled: row.submitted,
                    'validate-text-error': errorMessages.postPurpose,
                  },
                ]"
                v-for="purpose of postPurpose"
                :key="purpose.id"
                @click.prevent="showPostPurposeConfigDialog(row)"
              >
                <span v-if="purpose.logic" class="margin-r-4">{{
                  getAnswerTextById(purpose)
                }}</span>
                <span>跳转至 {{ getPurposeIndexByOrderNo(purpose.toOrderNo) }}</span>
              </a>
              <i
                class="el-icon-circle-close btn-clear"
                @click.stop="clearPostPurpose(row)"
              ></i>
            </div>
          </template>
          <div v-else>
            <el-tooltip
              placement="top"
              manual
              :content="errorMessages.postPurpose"
              v-model="errorVisibility.postPurpose"
            >
              <a
                :class="['btn-anchor', { disabled: isConfigDisabled(row) }]"
                @click.prevent="showPostPurposeConfigDialog(row)"
                >配置</a
              >
            </el-tooltip>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="前置" prop="prePurpose" width="150">
        <template slot-scope="{ row }">
          <div>{{ getPrePurposeIndex(row) }}</div>
        </template>
      </el-table-column>

      <el-table-column label="工单抓取" prop="workOrder" width="150">
        <template slot-scope="{ row, row: { workOrder, submitted } }">
          <div class="order-tag-wrap" v-if="workOrder && workOrder.length">
            <el-tag
              v-for="order of workOrder"
              :key="order.id"
              type="info"
              class="order-tag"
              @close="removeOrderTag(row, order)"
              :closable="!submitted"
              >{{ order.fieldName }}
            </el-tag>
          </div>
          <div>
            <a
              :class="['btn-anchor', { disabled: submitted }]"
              @click.prevent="showWorkOrderConfigDialog(row)"
              >添加</a
            >
          </div>
        </template>
      </el-table-column>

      <el-table-column label="质检评分">
        <el-table-column prop="qualityCheck.condition" width="100" align="right">
          <template
            slot-scope="{
              row,
              row: { qualityCheck, errorMessages, errorVisibility, submitted },
            }"
          >
            <div class="editor-wrap">
              <el-tooltip
                placement="top"
                manual
                :content="errorMessages.qualityCheck.condition"
                v-model="errorVisibility.qualityCheck.condition"
              >
                <el-select
                  :disabled="submitted"
                  :class="[
                    'input-w-80',
                    { 'validate-error': errorMessages.qualityCheck.condition },
                  ]"
                  v-model="qualityCheck.condition"
                  size="small"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="condition of qualityCheckCondition"
                    :key="condition.value"
                    :label="condition.label"
                    :value="condition.value"
                  />
                </el-select>
              </el-tooltip>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="qualityCheck.operation" width="70" align="center">
          <template
            slot-scope="{
              row,
              row: { qualityCheck, errorMessages, errorVisibility, submitted },
            }"
          >
            <div class="editor-wrap">
              <el-tooltip
                placement="top"
                manual
                :content="errorMessages.qualityCheck.operation"
                v-model="errorVisibility.qualityCheck.operation"
              >
                <el-select
                  :disabled="submitted"
                  :class="[
                    'input-w-60',
                    { 'validate-error': errorMessages.qualityCheck.operation },
                  ]"
                  v-model="qualityCheck.operation"
                  size="small"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="operation of qualityCheckOperation"
                    :key="operation.value"
                    :label="operation.label"
                    :value="operation.value"
                  />
                </el-select>
              </el-tooltip>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="qualityCheck.value" width="120" align="left">
          <template
            slot-scope="{
              row,
              row: { qualityCheck, errorMessages, errorVisibility, submitted },
            }"
          >
            <div class="editor-wrap">
              <div class="form-item">
                <el-tooltip
                  placement="top"
                  manual
                  :content="errorMessages.qualityCheck.value"
                  v-model="errorVisibility.qualityCheck.value"
                >
                  <el-input-number
                    :disabled="submitted"
                    controls-position="right"
                    :min="0"
                    :max="999"
                    :precision="0"
                    :class="[
                      'input-w-80',
                      { 'validate-error': errorMessages.qualityCheck.value },
                    ]"
                    v-model="qualityCheck.value"
                    @change="validateQualityCheckValue(row)"
                    size="small"
                  />
                </el-tooltip>
                <span class="input-suffix">分</span>
              </div>
            </div>
          </template>
        </el-table-column>
      </el-table-column>

      <el-table-column header-align="left" align="left">
        <template slot="header" slot-scope="{}">
          <div class="input-w-60 align-center">操作</div>
        </template>
        <template slot-scope="{ row }">
          <div class="anchor-bar input-w-60 align-center">
            <a v-if="row.submitted" class="btn-anchor" @click.prevent="enableRow(row)"
              >编辑</a
            >
            <!--<a v-else class="btn-anchor" @click.prevent="saveRow(row)">提交</a>-->
            <a class="btn-anchor" @click.prevent="deleteRow(row)">删除</a>
          </div>
        </template>
      </el-table-column>
    </el-table>

    <div class="button-bar">
      <el-button
        type="primary"
        class="button-normal"
        :disabled="seatPurposeList.length === flowPurposes.length"
        :loading="loading.seatPurposeList || loading.table"
        @click="addRow"
        >添加
      </el-button>
      <el-button class="button-normal" :disabled="previewDisabled" @click="onPreviewFlow"
        >流程预览
      </el-button>
    </div>

    <!--配置对话框-->
    <ConfigDialog
      ref="configDialog"
      :visible.sync="visibility.config"
      :flow-id="flowId"
      :condition-list="conditionList"
      :seat-purpose-name="activeSeatPurpose.name"
      :last-config-data="activeRecord.configFormData"
      :on-get-condition-answers="onGetConditionAnswers"
      :on-get-purpose-list="getPurposeListByOrderNo"
      :on-get-local-purpose-list="getLocalPurposeList"
      :on-save-post-purpose="setPostPurpose"
    />

    <!--工单规则对话框-->
    <WorkOrderDialog
      :visible.sync="visibility.order"
      :selected-rules="activeWorkOrderRules"
      :on-save-order-field-rule="addWorkOrder"
    />
  </div>
</template>

<script>
import cloneDeep from 'lodash/cloneDeep'
import global from '@/global.js'
import uuidUtil from '@/utils/uuid'
import ConfigDialog from './ConfigDialog'
import WorkOrderDialog from './WorkOrderDialog'

const currentBaseUrl = global.qualityUrl

// 默认行数据
const defaultRowData = {
  uuid: '',
  // 流程编号ID（用于关联意图）
  orderNo: '',
  // 当前意图
  purpose: '',
  // 前置意图
  prePurpose: '',
  // 后置意图
  postPurpose: null,
  // 工单提取
  workOrder: null,
  // 质检项
  qualityCheck: {
    // 检查条件
    condition: 0,
    // 执行操作
    operation: 2,
    // 分值
    value: 0,
  },
  // 内容过长时通过tooltip显示的内容
  ellipsisTitle: '',
  // 是否已提交
  submitted: false,
  // 校验消息
  errorMessages: {
    purpose: '',
    prePurpose: '',
    postPurpose: '',
    workOrder: '',
    qualityCheck: {
      condition: '',
      operation: '',
      value: '',
    },
  },
  // 错误消息提示的可见性
  errorVisibility: {
    purpose: false,
    prePurpose: false,
    postPurpose: false,
    workOrder: false,
    qualityCheck: {
      condition: false,
      operation: false,
      value: false,
    },
  },
}

export default {
  name: 'PurposeTable',
  components: { WorkOrderDialog, ConfigDialog },
  props: {
    // 回填数据
    data: Array,
    // 后置条件
    conditionList: Array,
    // 流程ID
    flowId: String,
    // 保存意图事件
    onSavePurpose: {
      type: Function,
      default: () => {},
    },
    // 删除意图
    onRemovePurpose: {
      type: Function,
      default: () => Promise.reject(),
    },
    // 获取后置前提条件的回答列表
    onGetConditionAnswers: {
      type: Function,
      default: () => {},
    },
    // 预览流程意图
    onPreviewFlow: {
      type: Function,
      default: () => {},
    },
  },
  data() {
    const { data } = this.$props
    return {
      // 流程意图列表
      flowPurposes: this.getTableData(data) || [],
      // 坐席意图列表
      seatPurposeList: [],
      // 质检条件
      qualityCheckCondition: [
        {
          label: '出现',
          value: 1,
        },
        {
          label: '未出现',
          value: 0,
        },
      ],
      // 质检条件对应操作
      qualityCheckOperation: [
        {
          label: '加',
          value: 1,
        },
        {
          label: '减',
          value: 2,
        },
      ],
      // 可见性
      visibility: {
        // 配置对话框
        config: false,
        // 工单规则设置对话框
        order: false,
      },
      // 加载状态
      loading: {
        // 坐席意图列表
        seatPurposeList: false,
        // 表格
        table: !Array.isArray(data),
      },
      // 当前操作中的行对象
      activeRecord: {},
    }
  },

  watch: {
    data(data) {
      data = this.getTableData(data)
      if (Array.isArray(data)) {
        this.loading.table = false
        this.flowPurposes = data
        // 校正连接关系
        this.correctFlowPurpose()
      }
    },
    conditionList(list) {
      const purposes = this.flowPurposes
      if (Array.isArray(list) && Array.isArray(purposes)) {
        // 刷新列表
        this.flowPurposes = [...purposes]
      }
    },
  },

  computed: {
    // 当前配置的坐席意图对象
    activeSeatPurpose() {
      const row = this.activeRecord
      const mock = { name: '' }
      if (row) {
        return this.getSeatPurposeObject(row) || mock
      }
      return mock
    },
    // 当前激活行已选的规则列表
    activeWorkOrderRules() {
      const row = this.activeRecord
      if (row) {
        const { workOrder } = row
        if (Array.isArray(workOrder)) {
          return [...workOrder]
        }
      }
      return []
    },
    // 是否禁用预览按钮
    previewDisabled() {
      return !this.flowPurposes.some((item) => !!item.purpose)
    },
  },

  created() {
    this.fetchSeatPurposeList()
  },

  methods: {
    // 是否禁用配置
    isConfigDisabled(row) {
      const purposes = this.flowPurposes
      const disabled =
        !row.purpose ||
        purposes.length < 2 ||
        purposes.filter((item) => !!item.purpose).length < 2
      row.errorMessages.postPurpose = disabled ? '请先添加并选择坐席意图' : ''
      return disabled
    },

    // 加载坐席意图
    fetchSeatPurposeList() {
      this.loading.seatPurposeList = true
      return this.axios
        .get(`${currentBaseUrl}/seatIntentConfig/getAllSeatIntentConfigs.do`, {
          params: {
            busiType: 1,
          },
        })
        .then(({ data }) => {
          this.loading.seatPurposeList = false
          this.seatPurposeList = (Array.isArray(data) ? data : []).map((item) => ({
            id: item.value,
            name: item.label,
          }))
        })
        .catch(() => {
          this.loading.seatPurposeList = false
          this.$message.error('坐席意图加载失败！')
        })
    },

    // 过滤坐席意图列表（排除已经选择了的坐席意图）
    filterSeatPurposeList(seatPurposeList, curr, flowPurposes) {
      flowPurposes = flowPurposes.filter((item) => item !== curr)
      return seatPurposeList.filter(
        (item) => !flowPurposes.some((flowPurpose) => flowPurpose.purpose === item.id)
      )
    },

    // 通过orderNos获取流程意图列表
    getPurposeListByOrderNo(ids) {
      if (Array.isArray(ids)) {
        const row = this.activeRecord
        if (row) {
          const orderNo = row.orderNo
          // 获取可选的意图列表
          return ids
            .map((id) => this.flowPurposes.find((item) => `${item.orderNo}` === `${id}`))
            .filter(
              (item) =>
                !!item &&
                // 排除自身
                `${item.orderNo}` !== `${orderNo}` &&
                // 排除前置节点
                !(item.postPurpose || []).some(
                  (purpose) => `${purpose.toOrderNo}` === `${orderNo}`
                )
            )
            .map((item) => {
              const { orderNo, purpose } = item
              const seatPurpose = this.getSeatPurposeObject(item)
              return {
                purpose,
                id: orderNo,
                text: `${this.getPurposeIndexByOrderNo(orderNo)}${
                  seatPurpose ? ` (${seatPurpose.name})` : ''
                }`,
              }
            })
        }
      }
      return []
    },

    // 获取本地所有流程意图配置项列表
    getLocalPurposeList() {
      return this.getPurposeListByOrderNo(
        this.flowPurposes.map(({ orderNo }) => orderNo)
        // 过滤出已经选择坐席意图的流程意图
      ).filter(({ purpose }) => !!purpose)
    },

    // 获取坐席意图对象
    getSeatPurposeObject(row) {
      const purpose = row.purpose
      if (purpose) {
        return this.seatPurposeList.find((item) => `${item.id}` === `${purpose}`)
      }
      return null
    },

    // 表格数据
    getTableData(data) {
      if (Array.isArray(data)) {
        return data.map((item) =>
          Object.assign({ uuid: uuidUtil.getUUid() }, cloneDeep(defaultRowData), item, {
            configFormData: this.$refs.configDialog.toFormData(item.postPurpose),
            // 不需要先进行提交，故此处不设置提交状态
            // submitted: true,
          })
        )
      }
    },

    // 单元格样式
    getCellClass({ column }) {
      const { property } = column
      let className = ''
      // 单元格合并
      if (`${property}`.startsWith('qualityCheck.')) {
        if (property === 'qualityCheck.condition') {
          // 条件
          className = 'table-cell-merge-left'
        } else if (property === 'qualityCheck.operation') {
          // 操作
          className = 'table-cell-merge-center'
        } else if (property === 'qualityCheck.value') {
          // 分值
          className = 'table-cell-merge-right'
        }
      } else if (property === 'postPurpose') {
        // 后置意图
        className = 'table-cell-hover-wrap'
      }
      return className
    },

    // 行样式
    getRowClass({ row }) {
      return row.submitted ? 'table-row-color-submitted' : ''
    },

    // 表头行样式
    getHeaderRowClass({ rowIndex }) {
      return rowIndex ? 'table-header-row-hidden' : ''
    },

    // 获取后置条件答案文本
    getAnswerTextById(purpose) {
      const { conditionId, answerId } = purpose
      const conditionList = this.conditionList
      if (Array.isArray(conditionList)) {
        const condition = conditionList.find((item) => item.id === conditionId)
        if (condition) {
          const answers = condition.answers
          if (Array.isArray(answers)) {
            const answer = answers.find((item) => item.id === answerId)
            if (answer) {
              const name = answer.name
              purpose.name = name
              return `"${name}" `
            }
          }
        }
      }
      return (purpose.name = '')
    },

    // 获取意图编号
    getPurposeIndexByOrderNo(orderNo) {
      orderNo = `${orderNo}`
      const index = this.flowPurposes.findIndex((item) => `${item.orderNo}` === orderNo)
      return index === -1 ? '' : index + 1
    },

    // 获取前置意图编号
    getPrePurposeIndex(row) {
      return this.getPrePurposeList(row)
        .map(({ index }) => index)
        .join(', ')
    },

    // 获取前置意图列表
    getPrePurposeList(row) {
      const prePurposes = []
      const fromOrderNo = `${row.orderNo}`
      this.flowPurposes.forEach((item, index) => {
        const { postPurpose } = item
        if (Array.isArray(postPurpose)) {
          for (const purpose of postPurpose) {
            if (`${purpose.toOrderNo}` === fromOrderNo) {
              prePurposes.push({
                data: item,
                index: index + 1,
              })
              break
            }
          }
        }
      })
      return prePurposes
    },

    // 新增意图行
    addRow() {
      const uuid = uuidUtil.getUUid()
      this.flowPurposes.push({
        ...cloneDeep(defaultRowData),
        // 意图配置ID
        uuid,
        // 意图编号ID
        orderNo: uuid,
        // 标记为新数据
        _new: true,
      })
    },

    // 处理单元格hover事件
    handleCellHover(enter, row, column) {
      this.toggleErrorMessage(enter, row, column)
    },

    // 切换错误提示消息的显示隐藏（校验信息）
    toggleErrorMessage(show, row, column) {
      let { property } = column
      if (property) {
        let visibility = row.errorVisibility
        let errors = row.errorMessages
        if (`${property}`.startsWith('qualityCheck.')) {
          property = property.replace('qualityCheck.', '')
          visibility = visibility.qualityCheck
          errors = errors.qualityCheck
        }
        // 如果是坐席意图列，则过长而不可见的内容需要借用tooltip显示
        const message =
          property === 'purpose' ? row.ellipsisTitle || errors.purpose : errors[property]
        visibility[property] = show ? !!message : false
      }
    },

    // 删除意图行
    deleteRow(row, preventAlert) {
      let confirmPromise = null
      if (!preventAlert) {
        // 进行删除提示
        const seatPurpose = this.getSeatPurposeObject(row)
        confirmPromise = this.$confirm(
          `确认要删除意图配置项${seatPurpose ? ` "${seatPurpose.name}" ` : ''}吗？`,
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
        )
      } else {
        confirmPromise = {
          then(callback) {
            return callback()
          },
        }
      }
      confirmPromise.then(() => {
        this.loading.table = true
        const promise = !row._new ? this.onRemovePurpose(row) : Promise.resolve()
        promise
          .then((message) => {
            this.$message.warning(message || '流程意图删除成功！')
            // 执行前端删除
            this.setFlowPurposes(
              this.flowPurposes.filter((item) => item.uuid !== row.uuid)
            )
          })
          .catch((message) => this.$message.error(message || '流程意图删除失败！'))
          .then(() => (this.loading.table = false))
      })
    },

    // 重新设置流程意图配置列表（校正后置配置项）
    setFlowPurposes(list) {
      this.flowPurposes = list
      this.correctFlowPurpose()
    },

    // 校正后置配置项
    correctFlowPurpose() {
      const flowPurposes = this.flowPurposes
      flowPurposes.forEach((item) => {
        const { postPurpose } = item
        if (Array.isArray(postPurpose)) {
          for (const purpose of postPurpose) {
            const orderNo = `${purpose.toOrderNo}`
            if (
              !flowPurposes.find((row) => row.purpose && `${row.orderNo}` === orderNo)
            ) {
              // 后置意图已经被删除
              // 清空该项的后置意图
              this.clearPostPurpose(item)
              break
            }
          }
        }
      })
    },

    // 超长内容处理
    setEllipsisTitle(row) {
      this.$nextTick(() => {
        // 处理坐席意图项
        const seatPurpose = this.getSeatPurposeObject(row)
        if (seatPurpose) {
          const elem = this.$refs[`$purpose-${row.uuid}`]
          if (elem) {
            const input = elem.querySelector('input')
            if (input && input.scrollWidth > input.clientWidth) {
              // 内容超出输入框长度
              row.ellipsisTitle = seatPurpose.name
              row.errorVisibility.purpose = false
              return
            }
          }
        }
        row.ellipsisTitle = ''
        row.errorVisibility.purpose = false
      })
    },

    // 移除工单抽取规则
    removeOrderTag(row, order) {
      const orders = row.workOrder
      if (orders) {
        orders.splice(orders.indexOf(order), 1)
        if (!orders.length) {
          row.workOrder = null
        }
      }
    },

    // 添加工单字段及其抓取规则
    addWorkOrder(order) {
      const row = this.activeRecord
      if (row) {
        const workOrder = Array.isArray(row.workOrder) ? row.workOrder : []
        workOrder.push(order)
        row.workOrder = workOrder
      }
    },

    // 保存意图行
    saveRow(row) {
      this.validateRow(row).then((valid) => {
        if (valid) {
          this.onSavePurpose(row).then(() => {
            // 不需要先提交细项，故此处不设置提交状态
            // row.submitted = true
          })
        }
      })
    },

    // 启用行
    enableRow(row) {
      row.submitted = false
    },

    // 清空后置意图
    clearPostPurpose(row) {
      row.postPurpose = []
      // 清空存储的表单数据
      row.configFormData = null
    },

    // 校验质检打分值，不能全部都为0
    validateQualityCheckValue() {
      const rows = this.flowPurposes
      const valid = rows.some((item) => !!item.qualityCheck.value)
      const message = valid ? '' : '必须至少有一项不为零分'
      rows.forEach((row) => {
        row.errorMessages.qualityCheck.value = message
        if (valid) {
          row.errorVisibility.qualityCheck.value = false
        }
      })
      return valid
    },

    // 校验行
    validateRow(row, correction, validateQualityValue) {
      if (correction) {
        // 修正流程意图配置项
        this.correctFlowPurpose()
        // 过长内容处理
        this.setEllipsisTitle(row)
      }
      const {
        purpose,
        qualityCheck: { condition, operation, value },
        errorMessages,
      } = row
      const qualityCheckErrors = errorMessages.qualityCheck
      errorMessages.purpose = !purpose ? '请选择意图' : ''
      if (!purpose) {
        errorMessages.postPurpose = '请选择坐席意图'
      } else {
        this.isConfigDisabled(row)
      }
      qualityCheckErrors.condition =
        condition === undefined || condition === '' ? '请选择条件' : ''
      qualityCheckErrors.operation =
        operation === undefined || operation === '' ? '请选择操作项' : ''
      qualityCheckErrors.value = isNaN(value) ? '请填写分值' : ''
      // 分值校验
      const qualityValueValid = validateQualityValue
        ? this.validateQualityCheckValue()
        : !isNaN(value)
      // 返回校验结果
      if (
        purpose &&
        (condition !== undefined && condition !== '') &&
        (operation !== undefined && operation !== '') &&
        qualityValueValid
      ) {
        return Promise.resolve()
      }
      return Promise.reject()
    },

    // 设置后置意图
    setPostPurpose(list, formData) {
      const row = this.activeRecord
      if (row) {
        row.postPurpose = [...list]
        row.configFormData = formData
      }
    },

    // 显示配置后置意图对话框
    showPostPurposeConfigDialog(row) {
      if (this.isConfigDisabled(row)) {
        return
      }
      this.activeRecord = row
      this.visibility.config = true
    },

    // 显示添加工单抓取规则对话框
    showWorkOrderConfigDialog(row) {
      if (row.submitted) {
        return
      }
      this.activeRecord = row
      this.visibility.order = true
    },

    // 校验表格
    validate() {
      return new Promise((resolve, reject) => {
        const purposes = this.flowPurposes
        if (!purposes.length) {
          reject('请添加流程坐席意图配置项')
        } else {
          // 校验所有意图项配置
          Promise.all(purposes.map((item) => this.validateRow(item, false, true)))
            .then(() =>
              resolve(
                purposes.map((purpose) => {
                  /* eslint-disable no-unused-vars */
                  const {
                    submitted,
                    errorMessages,
                    errorVisibility,
                    ellipsisTitle,
                    // 上面这些是交互状态相关数据，筛选出去
                    ...rowData
                  } = purpose
                  return {
                    ...rowData,
                    prePurpose: this.getPrePurposeList(purpose).map(({ data }) => data),
                  }
                })
              )
            )
            .catch(() => reject('坐席意图配置不正确，请检查意图配置项'))
        }
      })
    },

    // 获取数据
    getData() {
      return this.flowPurposes.map((item) => ({
        ...item,
        seatPurposeName: (this.getSeatPurposeObject(item) || {}).name || '',
      }))
    },
  },
}
</script>

<style lang="less">
.flow-purpose-table-wrap {
  padding-bottom: 60px;

  .table-row-color-submitted {
    /*background-color: #e5f3f8 !important;*/
  }

  .table-header-row-hidden {
    display: none;
  }

  /*合并单元格*/

  .table-cell-merge-left,
  .table-cell-merge-center {
    border-right: 0;
  }

  .table-cell-merge-left {
    .cell {
      padding: 0 5px 0 16px;
    }
  }

  .table-cell-merge-center {
    .cell {
      padding: 0 5px;
    }
  }

  .table-cell-merge-right {
    .cell {
      padding: 0 16px 0 5px;
    }
  }

  .table-cell-hover-wrap {
    .btn-clear {
      display: none;
    }

    &:hover,
    :hover {
      .btn-clear {
        display: block;
      }
    }
  }

  .el-table__fixed,
  .el-table__fixed-right {
    z-index: 1;

    td {
      background-color: #fff;
    }

    &:before {
      display: none;
    }

    .el-tooltip__popper {
      display: none !important;
    }
  }

  .editor-wrap {
    .el-select {
      input {
        padding-left: 6px;
        text-align: center;
      }
    }

    .el-input-number {
      input {
        padding-left: 6px;
        padding-right: 40px;
      }
    }

    .form-item {
      white-space: nowrap;
    }
  }

  .validate-error {
    input {
      border-color: #f56c6c !important;
    }
  }

  .validate-text-error {
    color: #f56c6c !important;
  }

  .order-tag-wrap {
    .order-tag {
      position: relative;
      left: 0;
      top: 0;
      float: left;
      clear: both;
      overflow: hidden;
      max-width: 100%;
      box-sizing: border-box;
      text-overflow: ellipsis;
      padding-right: 24px;
      margin-bottom: 4px;

      i {
        width: 14px;
        height: 14px;
        position: absolute;
        right: 4px;
        top: 8px;
      }
    }

    &:after {
      content: '';
      width: 0;
      height: 0;
      display: block;
      clear: both;
    }
  }

  .ellipsis-input-wrap {
    input {
      overflow: hidden;
      text-overflow: ellipsis;
    }
  }

  .el-loading-mask {
    background-color: rgba(255, 255, 255, 0.5);
  }
}
</style>

<style scoped lang="less">
.input-w-200 {
  width: 200px;
}

.input-w-80 {
  width: 80px;
}

.input-w-60 {
  width: 60px;
}

.margin-r-4 {
  margin-right: 4px;
}

.align-center {
  text-align: center;
  padding: 0 !important;
  line-height: normal;
}

.anchor-bar {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
}

.btn-anchor {
  margin: 0 4px;
  cursor: pointer;
  color: #409eff;

  &.disabled {
    color: #c0c4cc;
    cursor: not-allowed;
  }
}

.btn-anchor-block {
  float: left;
  clear: both;
  line-height: 1.25em;
  margin-bottom: 6px;
}

.button-bar {
  margin-top: 20px;
}

.button-normal {
  padding: 10px 20px;
  min-width: 88px;
}

.editor-wrap {
  display: flex;
  justify-content: space-around;
}

.input-suffix {
  margin-left: 4px;
}

.post-purpose-wrap {
  position: relative;

  &:after {
    content: '';
    display: block;
    width: 0;
    height: 0;
    clear: both;
  }

  .btn-clear {
    position: absolute;
    z-index: 10;
    padding: 2px;
    color: #c0c4cc;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
  }

  .btn-anchor:last-of-type {
    margin-bottom: 0;
  }
}
</style>
