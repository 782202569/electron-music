<template>
  <div class="flow-graph-dagre-d3-previewer" :key="timestamp">
    <svg ref="$svg" width="100%" height="100%"></svg>
    <div ref="$tooltipContainer"></div>
  </div>
</template>

<script>
import {
  select as d3Select,
  zoom as d3Zoom,
  event as d3Event,
  curveMonotoneY as d3Curve,
} from 'd3'
import dagreD3 from 'dagre-d3'
import Tooltip from 'tooltip.js'

export default {
  name: 'FlowPreviewer',
  props: {
    // 节点数据
    data: {
      type: Array,
      default: () => [],
    },
  },

  data() {
    return {
      // 渲染时间戳，用于强制更新svg
      timestamp: Date.now(),
    }
  },

  mounted() {
    this.drawFlowGraph()
  },

  watch: {
    data() {
      this.timestamp = Date.now()
      this.$nextTick(() => {
        this.drawFlowGraph()
      })
    },
  },

  methods: {
    // 校验数据
    validate(data) {
      let beginPoints = []
      if (Array.isArray(data) && data.length) {
        let beginPoint
        let flowPoints = []
        let valid = true
        this.setNodes(data)
        this.setEdges(data)
        // 取得起始节点列表
        beginPoints = this.getBeginPointNodes()
        if (beginPoints.length !== 1) {
          // 需满足有且仅有一个起点
          valid = false
        } else {
          beginPoint = beginPoints[0]
          flowPoints = this.getDescendants(beginPoint)
          if (flowPoints.length !== Object.keys(this.nodesMap).length) {
            // 需满足所有节点都在图中可遍历到
            valid = false
          }
        }
        if (valid) {
          // 校验连接关系的正确性
          const { invalid: invalidPaths } = this.analyzeRelations(beginPoint)
          if (invalidPaths.length) {
            // 需满足不存在非有效的节点
            valid = false
          }
        }
        if (valid) {
          return Promise.resolve({
            beginPoint,
            flowPoints,
          })
        }
      }
      return Promise.reject(
        beginPoints.length !== 1
          ? `流程坐席意图有且仅有一个为起始项，当前数量为 ${beginPoints.length}`
          : '流程坐席意图关联有误，请通过流程预览检查并修正'
      )
    },

    // 绘制流程图
    drawFlowGraph() {
      const data = this.data
      if (Array.isArray(data) && data.length) {
        const graph = this.initGraph()
        this.setNodes(data, graph)
        this.setEdges(data, graph)
        this.attachEvent(graph, this.renderGraph(graph))
        const beginPoints = this.getBeginPointNodes()
        let focused = false
        if (beginPoints.length === 1) {
          const beginPoint = beginPoints[0]
          if (this.getDescendants(beginPoint).length === graph.nodes().length) {
            // 聚焦起始节点
            graph.node(beginPoint).elem.focus()
            focused = true
          }
        }
        if (!focused) {
          // 标记所有起始节点
          beginPoints.forEach((value) =>
            d3Select(graph.node(value).elem).classed('node-state-hover', true)
          )
        }
      }
    },

    // 绑定事件
    attachEvent(graph, { nodes /*, edges*/ }) {
      // 节点事件
      nodes
        .on('focus', (value) => this.markNodesAccordingTo(graph, value))
        .on('blur', () =>
          this.clearStateClass({ dims: true, valid: true, invalid: true })
        )
        .on('mouseover', (value) => this.markHoveredNode(graph, value))
        .on('mouseout', () => this.clearStateClass({ hover: true }))
      // 关系线的事件
      /*edges
          .on('mouseover', (value) => this.markHoveredEdge(graph, value))
          .on('mouseout', () => this.clearStateClass({ hover: true }))*/
    },

    // 取得根节点选区对象
    getRootSelection() {
      return d3Select(this.$refs.$svg)
    },

    // 取得起始节点列表
    getBeginPointNodes(graph) {
      const nodesMap = this.nodesMap
      const fromPoints = Object.keys(nodesMap)
      const toPoints = fromPoints.reduce((list, val) => {
        list.push(...nodesMap[val])
        return list
      }, [])
      const beginPoints = fromPoints.filter((val) => toPoints.indexOf(val) === -1)
      if (graph) {
        return beginPoints.map((val) => graph.node(val).elem)
      }
      return beginPoints
    },

    // 清除状态样式
    clearStateClass({ dims, valid, invalid, hover }) {
      const dimsClass = 'node-state-dims'
      const validClass = 'edge-state-valid'
      const invalidClass = 'edge-state-invalid'
      const edgeHoverClass = 'edge-state-hover'
      const nodeHoverClass = 'node-state-hover'
      const root = this.getRootSelection()
      if (dims) {
        root.selectAll(`.${dimsClass}`).classed(dimsClass, false)
      }
      if (valid) {
        root.selectAll(`.${validClass}`).classed(validClass, false)
      }
      if (invalid) {
        root.selectAll(`.${invalidClass}`).classed(invalidClass, false)
      }
      if (hover) {
        root
          .selectAll(`.${edgeHoverClass},.${nodeHoverClass}`)
          .classed(edgeHoverClass, false)
          .classed(nodeHoverClass, false)
      }
    },

    // 标记hovered中的节点（进出线）
    markHoveredNode(graph, value) {
      d3Select(graph.node(value).elem).classed('node-state-hover', true)
      graph
        .edges()
        .filter(({ v, w }) => v === value || w === value)
        .map(({ v, w }) => graph.edge(v, w).elem)
        .forEach((elem) => d3Select(elem).classed('edge-state-hover', true))
    },

    // 标记hovered中的连接线
    markHoveredEdge(graph, value) {
      d3Select(graph.edge(value).elem).classed('edge-state-hover', true)
    },

    // 标记节点
    markNodesAccordingTo(graph, value) {
      // 将除当前选中的子孙节点外的节点调暗
      this.dimNodesExclude(graph, this.getDescendants(value))
      // 分析连接关系
      const { valid, invalid } = this.analyzeRelations(value)
      const list = [valid, invalid]
      list.forEach((paths) => {
        const className = `edge-state-${paths === valid ? 'valid' : 'invalid'}`
        for (const path of paths) {
          path.reduce((v, w) => {
            const edge = graph.edge(v, w)
            if (edge && edge.elem) {
              // 对路径进行有效性标记
              d3Select(edge.elem).classed(className, true)
            }
            return w
          })
        }
      })
    },

    // 分析节点连接关系的有效性
    analyzeRelations(value) {
      const validPaths = []
      const invalidPaths = []
      // 寻找可用路径
      this.nodesMap[value].forEach((child) => {
        this.traceNodePath(child, [value], (valid, path) => {
          if (valid) {
            // 有效路径
            validPaths.push(path)
          } else {
            // 非有效路径
            invalidPaths.push(path)
          }
        })
      })
      return { valid: validPaths, invalid: invalidPaths }
    },

    // 分析节点路径（深度优先遍历图）
    traceNodePath(value, path, callback) {
      const nodesMap = this.nodesMap
      path = [].concat(path)
      if (path.indexOf(value) === -1) {
        // 未遍历到的节点
        path.push(value)
        const children = nodesMap[value]
        if (children.length) {
          // 继续寻径
          children.forEach((child) => {
            this.traceNodePath(child, path, callback)
          })
        } else {
          // 有效路径
          callback(true, path)
        }
      } else {
        // 非有效路径
        callback(false, path.concat(value))
      }
    },

    // 调暗指定列表以外的所有节点
    dimNodesExclude(graph, excluded) {
      const dimsClassName = 'node-state-dims'
      const root = this.getRootSelection()
      const nodes = graph.nodes()
      const edges = graph.edges()
      // 将未选中的节点调暗
      const dimNodes = nodes.filter((value) => excluded.indexOf(value) === -1)
      const dimEdges = edges.filter((edge) => dimNodes.indexOf(edge.v) !== -1)
      dimNodes
        .map((value) => graph.node(value).elem)
        .forEach((node) => {
          d3Select(node).classed(dimsClassName, true)
        })
      dimEdges
        .map((value) => graph.edge(value))
        .forEach((edge) => {
          const {
            elem,
            value: { v, w },
          } = edge
          d3Select(elem).classed(dimsClassName, true)
          root.select(`#label-${v}-${w}`).classed(dimsClassName, true)
        })
    },

    // 获取后代节点（包含自身）（深度优先遍历图）
    getDescendants(value, descendants = []) {
      const nodesMap = this.nodesMap
      if (descendants.indexOf(value) === -1) {
        descendants.push(value)
        nodesMap[value].forEach((child) => {
          this.getDescendants(child, descendants).forEach((node) => {
            if (descendants.indexOf(node) === -1) {
              descendants.push(node)
            }
          })
        })
        return descendants
      }
      return []
    },

    // 渲染图形至DOM
    renderGraph(graph) {
      const renderConstructor = dagreD3.render
      const render = new renderConstructor()
      const svg = this.getRootSelection()
      const inner = svg.append('g')
      const zoom = d3Zoom()
      const graphic = graph.graph()
      const svgNode = svg.node()
      render(inner, graph)
      svg.attr('height', Math.max(graphic.height + 40, window.innerHeight - 200))
      svg.call(
        zoom.on('zoom', () => {
          inner.attr('transform', d3Event.transform)
        })
      )
      // 平移居中
      zoom.translateBy(
        svg,
        (svgNode.clientWidth - graphic.width) / 2,
        Math.max((svgNode.clientHeight - graphic.height) / 2, 20)
      )
      const nodes = inner.selectAll('.flow-previewer-graph-node')
      const edges = inner.selectAll('.flow-previewer-graph-edge')
      this.renderNodeTitle(graph, nodes)
      return { nodes, edges }
    },

    // 渲染标签提示
    renderNodeTitle(graph, nodes) {
      const container = this.$refs.$tooltipContainer
      const template = this.getTitleTemplate()
      nodes.each(function(value) {
        new Tooltip(this, {
          container,
          template,
          title: graph.node(value).title,
          html: true,
          placement: 'right',
        })
      })
    },

    // 获取提示标题模板
    getTitleTemplate() {
      return '<div class="tooltip el-tooltip__popper is-dark" role="tooltip"><div class="tooltip-inner"></div><div class="popper__arrow tooltip-arrow"></div></div>'
    },

    // 设置节点关联关系
    setEdges(data, graph) {
      const nodesMap = this.nodesMap
      data.forEach((node) => {
        const { value, relations } = node
        if (Array.isArray(relations)) {
          relations.forEach((item) => {
            const { toValue, condition, logic } = item
            // 构建子节点列表
            const children = nodesMap[value]
            if (children.indexOf(toValue) === -1) {
              children.push(toValue)
            }
            if (graph) {
              const id = `${value}-${toValue}`
              graph.setEdge(value, toValue, {
                // 连接线使用弧线
                curve: d3Curve,
                id: `edge-${id}`,
                value: { v: value, w: toValue },
                labelType: condition ? 'html' : '',
                label: condition ? this.getLabelContent(condition, id) : '',
                class: `flow-previewer-graph-edge${
                  !logic ? ' flow-previewer-graph-edge-dashed' : ''
                }`,
              })
            }
          })
        }
      })
    },

    // 获取标签内容格式
    getLabelContent(label, id) {
      return `<span id="label-${id}" class="flow-previewer-graph-label">${label}</span>`
    },

    // 设置节点
    setNodes(data, graph) {
      const nodesMap = {}
      data.forEach((node) => {
        const { index, label, value, logic, title } = node
        nodesMap[value] = nodesMap[value] || []
        if (graph) {
          graph.setNode(value, {
            value,
            // 节点框的圆角半径值
            rx: 5,
            ry: 5,
            // 标题
            label: `意图${index}：${label}`,
            class: `flow-previewer-graph-node${
              logic ? ' flow-previewer-graph-node-logic' : ''
            }`,
            title,
          })
        }
      })
      // 节点->子节点的映射
      this.nodesMap = nodesMap
    },

    // 初始化图形绘制器
    initGraph() {
      const graph = new dagreD3.graphlib.Graph()
      graph.setGraph({})
      return graph
    },
  },
}
</script>

<style lang="less">
.flow-graph-dagre-d3-previewer {
  @flow-node-dims-state-opacity: 0.15;
  @flow-node-dims-transition: opacity 0.2s;
  @flow-edge-state-colors-hover: #409eff;
  @flow-edge-state-colors-valid: #67c23a;
  @flow-edge-state-colors-invalid: #f56c6c;

  > svg {
    min-height: 400px;
  }

  .flow-previewer-graph-node {
    cursor: pointer;

    &.node-state-hover {
      outline: @flow-edge-state-colors-hover auto 2px;
    }

    &:focus {
      outline: @flow-edge-state-colors-hover auto 5px;
    }

    > rect {
      fill: #e5e9f2;
      transition: @flow-node-dims-transition;
    }

    text {
      fill: #475669;
      font-size: 14px;
      transition: @flow-node-dims-transition;
    }

    &.node-state-dims {
      > rect {
        opacity: @flow-node-dims-state-opacity;
      }

      text {
        opacity: @flow-node-dims-state-opacity;
      }
    }
  }

  .flow-previewer-graph-edge {
    > path {
      stroke: #333;
      stroke-width: 1.5px;
      transition: @flow-node-dims-transition;
    }

    &.node-state-dims {
      > path {
        opacity: @flow-node-dims-state-opacity;
      }
    }

    &.edge-state-hover {
      > path {
        stroke: @flow-edge-state-colors-hover;
      }

      defs {
        marker {
          fill: @flow-edge-state-colors-hover;
        }
      }
    }

    &.edge-state-invalid {
      > path {
        stroke: @flow-edge-state-colors-invalid;
      }

      defs {
        marker {
          fill: @flow-edge-state-colors-invalid;
        }
      }
    }

    &.edge-state-valid {
      > path {
        stroke: @flow-edge-state-colors-valid;
      }

      defs {
        marker {
          fill: @flow-edge-state-colors-valid;
        }
      }
    }
  }

  .flow-previewer-graph-edge-dashed {
    > path {
      /*虚线*/
      stroke-dasharray: 3, 3;
    }
  }

  .flow-previewer-graph-label {
    font-size: 12px;

    &.node-state-dims {
      opacity: @flow-node-dims-state-opacity;
    }
  }

  .tooltip {
    box-shadow: 0 0 2px rgba(0, 0, 0, 0.3);
  }
}
</style>
