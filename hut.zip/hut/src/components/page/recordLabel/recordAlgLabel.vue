<template>
  <div id="record-alg-label">
    <div class="caseRight">
      <div class="container" id="container">
        <div class="act-head">
          <el-form ref="searchForm" :model="searchForm" label-width="80px">
            <el-form-item prop="name">
              <el-input
                v-model="searchForm.labelName"
                placeholder="请输入标签名称"
                style="width: 160px"
              ></el-input>
              <el-button type="primary" style="margin-left: 10px" @click="initData"
                >查询</el-button
              >
              <el-button style="margin-left: 10px" @click="showStartLabelModal"
                >开始</el-button
              >
            </el-form-item>
          </el-form>
        </div>
        <div class="content">
          <div class="table">
            <div style="padding-left: 10px">
              <el-table border :data="data">
                <el-table-column prop="labelName" label="标签名称"></el-table-column>
                <el-table-column
                  prop="lastExecuteTime"
                  :formatter="convertDate"
                  label="上次执行时间"
                ></el-table-column>
                <el-table-column prop="count" label="录音数量"></el-table-column>
              </el-table>
            </div>
          </div>
          <div class="autoGrading-page">
            <el-pagination
              :page-sizes="[10, 20, 30, 40]"
              :current-page.sync="pageNumber"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              @current-change="handleCurrentChange"
              @size-change="handleSizeChange"
              :total="count"
            >
            </el-pagination>
          </div>
        </div>
      </div>
    </div>

    <el-dialog
      title="启动录音标签"
      :close-on-click-modal="false"
      :visible.sync="startLabelDialogVisible"
      @close="closeStartLabelModal"
    >
      <el-form ref="startLabelRef" label-width="100px" label-position="top">
        <el-form-item label="首次执行时间范围" prop="startLabelDateRange">
          <el-date-picker
            type="datetimerange"
            v-model="startLabelDateRange"
            placeholder="选择首次执行时间范围"
          ></el-date-picker>
        </el-form-item>
        <el-form-item>
          <div class="btns">
            <el-button type="primary" @click="startLabel">启动</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import formatdate from '@/utils/formatdate.js'
import global from '@/global.js'
import Qs from 'qs'

export default {
  methods: {
    showStartLabelModal() {
      this.startLabelDialogVisible = true
      this.$nextTick(() => {
        this.$refs['startLabelRef'].resetFields()
      })
    },
    startLabel() {
      let params = {}
      if (this.startLabelDateRange[0]) {
        params['firstRecordTimeMin'] = formatdate.formatDate(this.startLabelDateRange[0])
      }
      if (this.startLabelDateRange[1]) {
        params['firstRecordTimeMax'] = formatdate.formatDate(this.startLabelDateRange[1])
      }
      this.axios
        .post(
          `${global.analyticSystemUrl}/recordAlgLabel/startTask`,
          Qs.stringify(params)
        )
        .then(() => {
          this.$message.info('启用成功!')
          this.closeStartLabelModal()
        })
        .catch(() => {
          this.$message.error('启用失败!')
        })
    },
    closeStartLabelModal() {
      this.startLabelDialogVisible = false
      this.startLabelDateRange = []
    },
    convertDate(row) {
      if (row.lastExecuteTime) {
        return formatdate.formatDate(row.lastExecuteTime)
      }
      return ''
    },
    initData() {
      let params = {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        queryLabelName: this.searchForm.labelName,
      }
      this.axios
        .get(`${global.analyticSystemUrl}/recordAlgLabel/page`, { params })
        .then((res) => {
          let data = res.data
          this.count = data.count
          this.data = data.results
        })
        .catch(() => {
          this.$message.error('查询标签出现异常!')
        })
    },
    handleCurrentChange(val) {
      this.pageNumber = val
      this.initData()
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.pageNumber = 1
      this.initData()
    },
  },
  data() {
    return {
      startLabelDateRange: [],
      startLabelDialogVisible: false,
      searchForm: {
        labelName: '',
      },
      data: [],
      count: 0,
      pageNumber: 1,
      pageSize: 10,
    }
  },
  mounted() {
    this.initData()
  },
}
</script>
<style lang="less" scoped>
#record-alg-label {
  padding-top: 10px;
  .caseRight {
    height: calc(~'100% - 10px');
    position: relative;
    .container {
      overflow: hidden;
      height: 100%;
      position: relative;
      .content {
        padding-top: 58px;
        padding-bottom: 80px;
        box-sizing: border-box;
        width: 100%;
        height: 100%;
      }
      .autoGrading-page {
        right: 10px;
        position: absolute;
        bottom: 10px;
      }
      .table {
        width: 100%;
        height: 100%;
        overflow: auto;
        /*position: absolute;
          top: 55px;
          bottom: 80px;
          cursor: pointer;*/
      }
      .act-head {
        border-bottom: 1px dashed #d1dbe7;
        right: 0;
        top: 0;
        width: 100%;
        position: absolute;
        text-align: right;
        height: 44px;
      }
    }
  }
}
</style>
