<template>
  <div class="newTemplate">
    <div class="newTemplate-header clearfix fl">
      <el-form :inline="true">
        <span style="color: red;float: left">*</span>
        <el-form-item
          class="fl"
          style="margin-top: 10px"
          label="标签名称"
          prop="labelName"
        >
          <el-input placeholder="标签名称" v-model="addForm.labelName"></el-input>
        </el-form-item>
        <el-form-item class="fl" style="margin-top: 10px" label="首次执行范围">
          <el-date-picker
            v-model="addForm.firstRecordTimeRange"
            type="datetimerange"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item class="fl" style="margin-top: 10px" label="模板选择">
          <el-select
            v-model="templateId"
            clearable
            placeholder="请选择"
            @change="handleTemplateSelectChange"
          >
            <el-option
              v-for="item in templates"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item class="fr">
          <el-button @click="goBacktem">返回</el-button>
        </el-form-item>
        <el-form-item class="fr">
          <el-button class="fr" type="primary" @click="saveLabel">保存标签</el-button>
        </el-form-item>
        <el-form-item class="fr">
          <el-button class="fr" @click="showCopyTemplateModal">模板另存</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div style="border-bottom: 1px dashed #d1dbe7;height: 140px">
      <span>特征</span>
      <div>
        <el-form :inline="true">
          <el-form-item class="fl" style="margin-top: 10px" label="重叠次数">
            <el-input style="width: 40px" v-model="addForm.overlapMin"></el-input>
            <span>-</span>
            <el-input style="width: 40px" v-model="addForm.overlapMax"></el-input>
          </el-form-item>
          <el-form-item
            class="fl"
            style="margin-top: 10px;margin-left: 10px"
            label="平均语速"
          >
            <el-input style="width: 40px" v-model="addForm.avgSpeedMin"></el-input>
            <span>-</span>
            <el-input style="width: 40px" v-model="addForm.avgSpeedMax"></el-input>
          </el-form-item>
          <el-form-item
            class="fl"
            style="margin-top: 10px;margin-left: 10px"
            label="情绪分值"
            v-show="false"
          >
            <el-input style="width: 40px" v-model="addForm.moodScoreMin"></el-input>
            <span>-</span>
            <el-input style="width: 40px" v-model="addForm.moodScoreMax"></el-input>
          </el-form-item>
          <el-form-item
            class="fl"
            style="margin-top: 10px;margin-left: 10px"
            label="静默类型"
          >
            <el-select
              v-model="addForm.silenceType"
              clearable
              placeholder="请选择"
              style="width: 100px"
            >
              <el-option
                v-for="item in silenceTypeList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item
            class="fl"
            v-if="addForm.silenceType === '1'"
            style="margin-top: 10px;margin-left: 10px"
          >
            <el-input style="width: 40px" v-model="addForm.silenceLongMin"></el-input>
            <span>-</span>
            <el-input style="width: 40px" v-model="addForm.silenceLongMax"></el-input>
            <span>秒</span>
          </el-form-item>
          <el-form-item
            class="fl"
            v-if="addForm.silenceType === '2'"
            style="margin-top: 10px;margin-left: 10px"
          >
            <el-input style="width: 40px" v-model="addForm.silenceTimeMin"></el-input>
            <span>-</span>
            <el-input style="width: 40px" v-model="addForm.silenceTimeMax"></el-input>
            <span>次</span>
          </el-form-item>
          <el-form-item
            class="fl"
            v-if="addForm.silenceType === '3'"
            style="margin-top: 10px;margin-left: 10px"
          >
            <el-input style="width: 40px" v-model="addForm.silencePerMin"></el-input>
            <span>-</span>
            <el-input style="width: 40px" v-model="addForm.silencePerMax"></el-input>
            <span>%</span>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="newTemplate-keyWord-pos" style="width:100%;;box-sizing:border-box;">
      <div class="newTemplate-keyWord" style="width:100%;height:100%;position: relative;">
        <div class="newTemplate-keyWord-header fl">
          <span>关键字</span>
          <el-button class="fr" @click="batchRemoveSelectedKeywords">批量删除</el-button>
          <el-button class="fr" @click="openKeywordModal('new')">添加关键词</el-button>
        </div>
        <div
          class="newTemplate-keyWord-content-pos"
          style="width:100%;height:100%;padding-bottom:80px;padding-top:54px;box-sizing:border-box;"
        >
          <div style="width:100%;height:100%;overflow: auto;">
            <el-table
              border
              style="width: 100%"
              :data="pageableKeywords"
              @select="handleSelectKeyword"
              @select-all="handleSelectKeyword"
            >
              <el-table-column type="selection"></el-table-column>
              <el-table-column prop="keywordContext" label="关键词"></el-table-column>
              <el-table-column
                prop="fullScriptRole"
                label="角色"
                :formatter="getRoleStr"
              ></el-table-column>
              <el-table-column prop="note" label="备注"></el-table-column>
              <el-table-column label="操作" show-overflow-tooltip>
                <template scope="scope">
                  <div style="cursor: pointer;">
                    <i class="el-icon-edit" style="cursor:pointer;margin-right:10px;">
                      <i
                        style="font-family: '微软雅黑';margin-left:4px;"
                        @click="openKeywordModal('edit', scope.row)"
                        >编辑</i
                      >
                    </i>
                    <i class="el-icon-close" style="font-size: 12px; margin-right: 10px;">
                      <i
                        style="font-size: 14px; padding-left: 3px"
                        @click="
                          batchRemoveKeywords(
                            scope.row.scriptKeywordId,
                            scope.row.keywordContext
                          )
                        "
                        >删除</i
                      >
                    </i>
                    <i class="el-icon-search" style="cursor:pointer;margin-right:8px;">
                      <i
                        style="font-size: 14px; padding-left: 3px"
                        @click="openKeywordModal('watch', scope.row)"
                        >查看</i
                      >
                    </i>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
      </div>
      <div
        class="newTemplate-keyWord-page"
        style="position: absolute;bottom:0px;width:100%;height:60px;right: 0px"
      >
        <div class="block fr" style="margin-top: 15px;">
          <el-pagination
            class="fr"
            :page-sizes="[10, 20, 30, 40]"
            layout="total, sizes, prev, pager, next, jumper"
            :total="allKeywords.length"
            :page-size="pageSize"
            :current-page.sync="pageNumber"
            @current-change="handleCurrentChange"
          >
          </el-pagination>
        </div>
      </div>
      <el-dialog
        :title="addKeywordTitle"
        :visible.sync="showKeywordDialog"
        @close="closeKeywordModal"
      >
        <el-form
          :model="screeningConditionsForm"
          ref="screeningConditionsForm"
          class="demo-ruleForm"
        >
          <div>
            <el-form-item class="w-240" label="筛选类型" prop="type">
              <el-select class="w-160" v-model="screeningConditionsForm.type">
                <el-option
                  v-for="item in keywordTypes"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item
              class="w-240"
              label="静默类型"
              prop="silenceType"
              v-show="screeningConditionsForm.type == 2"
            >
              <el-select
                class="w-160"
                v-model="screeningConditionsForm.silenceType"
                placeholder="请选择"
              >
                <el-option
                  v-for="item in keywordSilenceTypeList"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item
              class="w-218"
              label="数量"
              prop="silenceTimeMin"
              v-show="
                screeningConditionsForm.type == 2 &&
                  screeningConditionsForm.silenceType == 1
              "
            >
              <el-input
                type="number"
                class="w-78"
                v-model="screeningConditionsForm.silenceTimeMin"
              ></el-input>
              --
              <el-input
                type="number"
                class="w-78"
                v-model="screeningConditionsForm.silenceTimeMax"
              ></el-input>
            </el-form-item>
          </div>
          <div>
            <el-form-item
              class="w-138"
              label="场景"
              prop="sceneTime"
              v-show="screeningConditionsForm.type == 2"
            >
              <el-input
                type="number"
                class="w-67"
                v-model="screeningConditionsForm.sceneTime"
              ></el-input>
              次
            </el-form-item>
            <el-form-item prop="sceneType">
              <el-select
                class="w-97"
                v-model="screeningConditionsForm.sceneType"
                v-show="screeningConditionsForm.type == 2"
              >
                <el-option
                  v-for="item in sceneTypes"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item
              class="w-240"
              label="场景数值"
              prop="sceneValue"
              v-show="screeningConditionsForm.type == 2"
            >
              <el-input
                class="w-160"
                type="number"
                v-model="screeningConditionsForm.sceneValue"
                placeholder="请输入数值"
              ></el-input>
            </el-form-item>
            <el-form-item
              class="w-138"
              prop="sceneValueType"
              v-show="screeningConditionsForm.type == 2"
            >
              <el-select class="w-65" v-model="screeningConditionsForm.sceneValueType">
                <el-option
                  v-for="item in sceneNumTimes"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </div>
        </el-form>
        <div id="addKey" style="position:relative">
          <div class="keyWorld">
            <span class="xingDot">*</span>
            <span style="height:260px;" class="keyzuhe">关键词组合</span>
            <div style="margin-left:95px;height:260px;">
              <textarea
                id="keywordZuhe"
                style="width:100%;height:260px;border:1px solid #ddd;border-radius:4px;padding-left:10px;padding-top:10px;box-sizing:border-box;padding-bottom:50px"
                v-model="screeningConditionsForm.keywordContext"
              ></textarea>
              <div
                style="height:25px;position:absolute;bottom:1px;left:96px;right:6px;padding-top:3px;background:#fff;border-radio:3px"
                id="keyWorldpos"
              >
                <span class="spanStyle" @click="insertAtCursor('OR')">OR</span>
                <span class="spanStyle" @click="insertAtCursor('AND')">AND</span>
                <span class="spanStyle" @click="insertAtCursor('NOT')">NOT</span>
                <span class="spanStyle" @click="insertAtCursor('NEAR')">NEAR</span>
                <span class="spanStyle" @click="insertAtCursor('BEFORE')">BEFORE</span>
                <span class="spanStyle" @click="insertAtCursor('AFTER')">AFTER</span>
                <span class="spanStyle" @click="insertAtCursor('()')">()</span>
                <el-radio-group
                  v-model="screeningConditionsForm.fullScriptRole"
                  style="display:inline-block;margin-left:5px;"
                >
                  <el-radio :label="'0'">全部</el-radio>
                  <el-radio :label="'1'">客服</el-radio>
                  <el-radio :label="'2'">客户</el-radio>
                </el-radio-group>
              </div>
            </div>
          </div>
          <span
            style="display: block;height: 50px;width:100%;text-align: right;line-height: 50px;"
            ><span
              style="color:#505962;border-bottom: 1px solid #505962;font-size:14px;cursor: pointer;"
              @click="showRule = !showRule"
              >术语规则</span
            ></span
          >
          <div class="keyBeizhu">
            <span style="height:174px;" class="keyzuhe">备注</span>
            <div style="margin-left:85px;height:174px;">
              <textarea
                style="width:100%;height:174px; border:1px solid #ddd;border-radius:4px;box-sizing:border-box;padding-left:10px;padding-top:10px;"
                id="getNote"
                v-model="screeningConditionsForm.note"
              ></textarea>
            </div>
          </div>
          <div style="height:36px;" class="addkeyFooter">
            <el-button
              type="primary"
              class="fr"
              @click="addKeyWords"
              v-show="editKeywordType !== 'watch'"
              >确 定
            </el-button>
            <el-button class="fr" @click="closeKeywordModal">取 消</el-button>
          </div>
          <div
            id="keyRules"
            style="position: absolute;background: #fff"
            v-show="showRule"
          >
            1."AND"关键字表示"与"的关系，可以匹配到同时存在关键字左右两个关键词<br />
            2."OR"关键字表示"或"的关系，可以匹配到存在关键字左右其中至少一个关键词<br />
            3."NOT"关键字表示"非"的关系，可以匹配到存在不存在关键字右侧的关键词<br />
            4."BEFORE"关键字表示有先后顺序"临近"的关系，可以匹配到存在关键字右侧的关键词且之前的n个词内会存在关键字左侧的关键词<br />
            5."AFTER"关键字表示有先后顺序"临近"的关系，可以匹配到存在关键字右侧的关键词且之前的n个词内会存在关键字左侧的关键词<br />
            6."NEAR"关键词表示有临近关系<br />
            7."()"可以在括号中使用以上关键字并提高关键字的匹配优先级<br />
          </div>
        </div>
      </el-dialog>
      <el-dialog
        title="模板另存"
        :visible.sync="showCopyTemplateVisible"
        @close="closeKeywordModal"
      >
        <el-form :inline="true">
          <span style="color: red">*</span>
          <el-form-item label="模板名称:">
            <el-input v-model="scriptKeywordName"></el-input>
          </el-form-item>
        </el-form>
        <el-button type="primary" style="margin-top: 10px" @click="copyTemplate"
          >保存</el-button
        >
      </el-dialog>
    </div>
  </div>
</template>
<script>
import formatdate from '../../../utils/formatdate.js'
import global from '../../../global.js'
import Qs from 'qs'
import commonUtil from '../../../utils/commonUtil'

let requestUrls = {
  getAllDataByLabelIdUrl: global.currentBaseUrl + '/recordLabel/findByLabelId.do',
  getAllDataByTemplateId: global.currentBaseUrl + '/recordLabel/findByTemplateId.do',
  getTemplatesUrl: global.currentBaseUrl + '/pageConstant/getValue.do?keys=fullModel',
  saveLabelUrl: global.currentBaseUrl + '/recordLabel/addRecordLabel.do',
  copyTemplateUrl: global.currentBaseUrl + '/recordLabel/copyTemplate.do',
}

export default {
  props: ['editLabelId', 'editType', 'classId'],
  data() {
    return {
      message: '条件页面',
      silenceTypeList: [
        { value: '1', label: '时长' },
        { value: '2', label: '次数' },
        { value: '3', label: '占比' },
      ],
      keywordSilenceTypeList: [
        { value: '1', label: '时长' },
        { value: '2', label: '次数' },
      ],
      addForm: {
        silenceType: '',
        overlapMin: '',
        overlapMax: '',
        avgSpeedMin: '',
        avgSpeedMax: '',
        moodScoreMin: '',
        moodScoreMax: '',
        silenceTimeMin: '',
        silenceTimeMax: '',
        silencePerMin: '',
        silencePerMax: '',
        silenceLongMin: '',
        silenceLongMax: '',
        labelName: '',
        firstRecordTimeMin: '',
        firstRecordTimeMax: '',
        firstRecordTimeRange: [],
        selectedKeywords: [],
      },
      pageableKeywords: [],
      allKeywords: [],
      pageNumber: 1,
      pageSize: 10,
      labelId: null,
      pageType: 'new',
      templateId: '',
      templates: [],
      oldTemplateId: '',
      showKeywordDialog: false,
      screeningConditionsForm: {
        type: 1,
        silenceType: '',
        fullScriptRole: '0',
        keywordContext: '',
        silenceTimeMin: '',
        silenceTimeMax: '',
        sceneType: 1,
        sceneTime: '',
        sceneValue: 1,
        sceneValueType: 1,
        note: '',
        scriptKeywordId: '',
      },
      keywordTypes: [{ value: 1, label: '关键词' }, { value: 2, label: '静默关键词' }],
      sceneTypes: [{ value: 1, label: '之前' }, { value: 2, label: '之后' }],
      sceneNumTimes: [{ value: 1, label: '秒' }, { value: 2, label: '句' }],
      showRule: false,
      selectedKeywords: [],
      editKeywordType: 'new',
      showCopyTemplateVisible: false,
      scriptKeywordName: '',
      addKeywordTitle: '添加关键词',
      isSelectTemplate: false, // 是否点击了选模板
    }
  },
  methods: {
    goBacktem() {
      this.$emit('send')
    },
    getPageableKeywords() {
      let startIndex = (this.pageNumber - 1) * this.pageSize
      let endIndex = startIndex + this.pageSize
      return this.allKeywords.slice(startIndex, endIndex)
    },
    fillKeywords() {
      this.pageableKeywords = this.getPageableKeywords()
    },
    isSilenceType(val) {
      for (let i = 0; i < this.silenceTypeList.length; i++) {
        if (this.silenceTypeList[i]['value'] === val) {
          return true
        }
      }
      return false
    },
    fillAddForm(data) {
      if (this.isSelectTemplate) {
        this.copyProperties(data, this.addForm, [
          'firstRecordTimeMin',
          'firstRecordTimeMax',
          'labelName',
        ])
      } else {
        this.copyProperties(data, this.addForm, [
          'firstRecordTimeMin',
          'firstRecordTimeMax',
        ])
      }
      if (!this.isSilenceType(this.addForm['silenceType'])) {
        this.addForm['silenceType'] = ''
      }
      let startStr = ''
      if (data['firstRecordTimeMin']) {
        this.addForm.firstRecordTimeRange[0] = new Date(data['firstRecordTimeMin'])
        startStr = formatdate.formatDate(this.addForm.firstRecordTimeRange[0])
      }
      let endStr = ''
      if (data['firstRecordTimeMax']) {
        this.addForm.firstRecordTimeRange[1] = new Date(data['firstRecordTimeMax'])
        endStr = formatdate.formatDate(this.addForm.firstRecordTimeRange[1])
      }
      this.addForm.firstRecordTimeRange = [startStr, endStr]
      /* if (startStr) {
          let dateRangeStr = startStr + ' - ' + endStr
          // document.getElementById('firstRecordTimeRangeInput').getElementsByTagName('input')[0].value = dateRangeStr
          this.$refs.firstRecordTimeRangeInput = dateRangeStr
        } */
    },
    handleCurrentChange(val) {
      this.pageNumber = val
      this.fillKeywords()
    },
    getAllDataByLabelId() {
      this.isSelectTemplate = false
      if (this.pageType === 'edit') {
        let params = {
          labelId: this.labelId,
        }
        this.axios
          .post(requestUrls['getAllDataByLabelIdUrl'], Qs.stringify(params))
          .then((response) => {
            if (response.data['state'] === '1') {
              let data = response['data']['results'][0] || []
              this.allKeywords = data['keyWords'] || []
              this.fillAddForm(data)
              this.pageNumber = 1
              this.fillKeywords()
            }
          })
      }
    },
    getAllDataByTemplateId() {
      let params = {
        templateId: this.templateId,
      }
      this.axios
        .post(requestUrls['getAllDataByTemplateId'], Qs.stringify(params))
        .then((response) => {
          if (response['data']['state'] === '1') {
            let data = response['data']['results'][0] || {}
            this.allKeywords = data['keyWords'] || []
            this.fillAddForm(data)
            this.pageNumber = 1
            this.fillKeywords()
          }
        })
    },
    handleTemplateSelectChange() {
      this.$confirm('此操作将会覆盖页面上的条件和关键词，是否继续?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error',
      }).then(() => {
        this.isSelectTemplate = true
        this.getAllDataByTemplateId()
      })
    },
    getTemplates() {
      this.axios.post(requestUrls['getTemplatesUrl']).then((response) => {
        this.templates = response['data']['fullModel']
      })
    },
    copyProperties(src, target, notCopyProps) {
      let notCopyPropSet = new Set(notCopyProps || [])
      for (let prop in target) {
        if (
          target.hasOwnProperty(prop) &&
          src.hasOwnProperty(prop) &&
          !notCopyPropSet.has(prop)
        ) {
          target[prop] = src[prop]
        }
      }
    },
    insertAtCursor(signature) {
      if (signature !== '()') {
        this.screeningConditionsForm.keywordContext += ' ' + signature + ' '
      } else {
        this.screeningConditionsForm.keywordContext =
          '(' + this.screeningConditionsForm.keywordContext + ')'
      }
    },
    openKeywordModal(type) {
      this.showKeywordDialog = true
      this.editKeywordType = type
      if (type === 'new') {
        for (let prop in this.screeningConditionsForm) {
          this.screeningConditionsForm[prop] = ''
        }
        this.screeningConditionsForm['type'] = 1
        this.screeningConditionsForm['silenceType'] = '1'
        this.screeningConditionsForm['fullScriptRole'] = '0'
        this.addKeywordTitle = '添加关键词'
      }
      if (type === 'edit' || type === 'watch') {
        let editKeyword = arguments[1]
        editKeyword['silenceType'] = editKeyword['silenceType'] + ''
        this.copyProperties(editKeyword, this.screeningConditionsForm)
      }
      if (type === 'edit') {
        this.addKeywordTitle = '编辑关键词'
      }
      if (type === 'watch') {
        this.addKeywordTitle = '查看关键词'
      }
    },
    closeKeywordModal() {
      this.editKeywordType = 'new'
      this.showKeywordDialog = false
    },
    replaceKeyword(newObj) {
      let scriptKeywordId = newObj['scriptKeywordId']
      let hitIndex = -1
      this.allKeywords.forEach((e, i) => {
        if (e['scriptKeywordId'] === scriptKeywordId) {
          hitIndex = i
          return false
        }
      })
      this.allKeywords.splice(hitIndex, 1, newObj)
      this.fillKeywords()
    },
    addKeyWords() {
      let obj = {}
      for (let prop in this.screeningConditionsForm) {
        if (this.screeningConditionsForm.hasOwnProperty(prop)) {
          obj[prop] = this.screeningConditionsForm[prop]
        }
      }
      obj['createTime'] = new Date().getTime()
      if (this.editKeywordType === 'new') {
        obj['scriptKeywordId'] = this.getUUID()
        this.allKeywords.unshift(obj)
      } else {
        this.replaceKeyword(obj)
      }
      this.showKeywordDialog = false
      this.fillKeywords()
    },
    validateParams(params) {
      if (commonUtil.isBlank(params['labelName'])) {
        return { msg: '标签名称不能为空!', flag: false }
      }
      if (
        commonUtil.isNotBlank(params['overlapMin']) &&
        commonUtil.isNotBlank(params['overlapMax'])
      ) {
        if (parseFloat(params['overlapMin']) > parseFloat(params['overlapMax'])) {
          return { msg: '重叠次数低值不能大于重叠次数高值!', flag: false }
        }
      }
      if (
        commonUtil.isNotBlank(params['moodScoreMin']) &&
        commonUtil.isNotBlank(params['moodScoreMax'])
      ) {
        if (parseFloat(params['moodScoreMin']) > parseFloat(params['moodScoreMax'])) {
          return { msg: '情绪分值低值不能大于情绪分值高值!', flag: false }
        }
      }
      if (
        commonUtil.isNotBlank(params['avgSpeedMin']) &&
        commonUtil.isNotBlank(params['avgSpeedMax'])
      ) {
        if (parseFloat(params['avgSpeedMin']) > parseFloat(params['avgSpeedMax'])) {
          return { msg: '平均语速低值不能大于平均语速高值!', flag: false }
        }
      }
      if (commonUtil.isNotBlank(params['silenceType'])) {
        if (
          commonUtil.isNotBlank(params['silenceLongMin']) &&
          commonUtil.isNotBlank(params['silenceLongMax'])
        ) {
          if (
            parseFloat(params['silenceLongMin']) > parseFloat(params['silenceLongMax'])
          ) {
            return { msg: '静默时长低值不能大于平均语速高值!', flag: false }
          }
        }
        if (
          commonUtil.isNotBlank(params['silenceTimeMin']) &&
          commonUtil.isNotBlank(params['silenceTimeMax'])
        ) {
          if (
            parseFloat(params['silenceTimeMin']) > parseFloat(params['silenceTimeMax'])
          ) {
            return { msg: '静默次数低值不能大于静默次数高值!', flag: false }
          }
        }
        if (
          commonUtil.isNotBlank(params['silencePerMin']) &&
          commonUtil.isNotBlank(params['silencePerMax'])
        ) {
          if (parseFloat(params['silencePerMin']) > parseFloat(params['silencePerMax'])) {
            return { msg: '静默占比低值不能大于静默占比高值!', flag: false }
          }
        }
      }
      return { msg: '', flag: true }
    },
    saveLabel() {
      let params = {}
      for (let prop in this.addForm) {
        params[prop] = this.addForm[prop]
      }
      let validateResult = this.validateParams(params)
      if (!validateResult['flag']) {
        this.$message.error(validateResult['msg'])
        return
      }
      if (this.addForm.firstRecordTimeRange[0]) {
        params['firstRecordTimeMin'] = formatdate.formatDate(
          this.addForm.firstRecordTimeRange[0]
        )
      }
      if (this.addForm.firstRecordTimeRange[1]) {
        params['firstRecordTimeMax'] = formatdate.formatDate(
          this.addForm.firstRecordTimeRange[1]
        )
      }
      params['labelId'] = this.labelId
      params['keyWordJsonStr'] = JSON.stringify(this.allKeywords)
      params['classId'] = this.classId
      this.axios
        .post(requestUrls['saveLabelUrl'], Qs.stringify(params))
        .then((response) => {
          let data = response['data']
          if (data['state'] === '1') {
            this.$message.info('保存成功!')
            this.labelId = data['other']['recordLabelId']
            this.pageType = 'edit'
            this.getAllDataByLabelId()
          } else {
            this.$message.error(data['message'])
          }
        })
        .catch(() => {
          this.$message.error('保存标签发生异常!')
        })
    },
    batchRemoveKeywords(keywordIds, keywordContent) {
      const self = this
      let confirmMsg = ''
      if (keywordIds instanceof Array) {
        confirmMsg = '是否删除这些关键词？'
      } else {
        confirmMsg = '是否删除关键词【' + keywordContent + '】？'
      }
      this.$confirm(confirmMsg, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let ids = !(keywordIds instanceof Array) ? [keywordIds] : keywordIds
          let idSet = new Set(ids)
          let keywords = []
          for (let i = 0; i < self.allKeywords.length; i++) {
            let keyword = self.allKeywords[i]
            if (!idSet.has(keyword['scriptKeywordId'])) {
              keywords.push(keyword)
            }
          }
          self.allKeywords = keywords
          self.selectedKeywords = []
          self.fillKeywords()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    getUUID() {
      return formatdate.formatDate(new Date()) + Math.random()
    },
    handleSelectKeyword(selection) {
      this.selectedKeywords = selection
    },
    batchRemoveSelectedKeywords() {
      if (this.selectedKeywords.length === 0) {
        this.$message.error('请至少选择一条记录进行删除!')
        return
      }
      let keywordIds = []
      this.selectedKeywords.forEach((e) => {
        keywordIds.push(e['scriptKeywordId'])
      })
      this.batchRemoveKeywords(keywordIds)
    },
    getRoleStr(row) {
      let val = row['fullScriptRole']
      if (val == '0' || !val) {
        return '全部'
      }

      if (val == '1') {
        return '客服'
      }

      if (val == '2') {
        return '客户'
      }
      return ''
    },
    showCopyTemplateModal() {
      this.showCopyTemplateVisible = true
      this.scriptKeywordName = ''
    },
    copyTemplate() {
      if (commonUtil.isBlank(this.scriptKeywordName)) {
        this.$message.error('请填写模板名称')
        return
      }
      let params = {}
      for (let prop in this.addForm) {
        params[prop] = this.addForm[prop]
      }
      let validateResult = this.validateCopyParams(params)
      if (!validateResult['flag']) {
        this.$message.error(validateResult['msg'])
        return
      }
      if (this.addForm.firstRecordTimeRange[0]) {
        params['firstRecordTimeMin'] = formatdate.formatDate(
          this.addForm.firstRecordTimeRange[0]
        )
      }
      if (this.addForm.firstRecordTimeRange[1]) {
        params['firstRecordTimeMax'] = formatdate.formatDate(
          this.addForm.firstRecordTimeRange[1]
        )
      }
      params['labelId'] = this.labelId
      params['keyWordJsonStr'] = JSON.stringify(this.allKeywords)
      params['classId'] = this.classId
      params['scriptName'] = this.scriptKeywordName
      this.axios
        .post(requestUrls['copyTemplateUrl'], Qs.stringify(params))
        .then((response) => {
          let data = response.data
          if (data.state === '1') {
            this.$message.info('保存成功!')
            this.showCopyTemplateVisible = false
          } else {
            this.$message.error(data['message'])
          }
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('另存模板发生错误!')
        })
    },
    validateCopyParams(params) {
      if (
        commonUtil.isNotBlank(params['overlapMin']) &&
        commonUtil.isNotBlank(params['overlapMax'])
      ) {
        if (parseFloat(params['overlapMin']) > parseFloat(params['overlapMax'])) {
          return { msg: '重叠次数低值不能大于重叠次数高值!', flag: false }
        }
      }
      if (
        commonUtil.isNotBlank(params['moodScoreMin']) &&
        commonUtil.isNotBlank(params['moodScoreMax'])
      ) {
        if (parseFloat(params['moodScoreMin']) > parseFloat(params['moodScoreMax'])) {
          return { msg: '情绪分值低值不能大于情绪分值高值!', flag: false }
        }
      }
      if (
        commonUtil.isNotBlank(params['avgSpeedMin']) &&
        commonUtil.isNotBlank(params['avgSpeedMax'])
      ) {
        if (parseFloat(params['avgSpeedMin']) > parseFloat(params['avgSpeedMax'])) {
          return { msg: '平均语速低值不能大于平均语速高值!', flag: false }
        }
      }
      if (commonUtil.isNotBlank(params['silenceType'])) {
        if (
          commonUtil.isNotBlank(params['silenceLongMin']) &&
          commonUtil.isNotBlank(params['silenceLongMax'])
        ) {
          if (
            parseFloat(params['silenceLongMin']) > parseFloat(params['silenceLongMax'])
          ) {
            return { msg: '静默时长低值不能大于平均语速高值!', flag: false }
          }
        }
        if (
          commonUtil.isNotBlank(params['silenceTimeMin']) &&
          commonUtil.isNotBlank(params['silenceTimeMax'])
        ) {
          if (
            parseFloat(params['silenceTimeMin']) > parseFloat(params['silenceTimeMax'])
          ) {
            return { msg: '静默次数低值不能大于静默次数高值!', flag: false }
          }
        }
        if (
          commonUtil.isNotBlank(params['silencePerMin']) &&
          commonUtil.isNotBlank(params['silencePerMax'])
        ) {
          if (parseFloat(params['silencePerMin']) > parseFloat(params['silencePerMax'])) {
            return { msg: '静默占比低值不能大于静默占比高值!', flag: false }
          }
        }
      }
      return { msg: '', flag: true }
    },
  },
  mounted() {
    this.pageType = this.editType
    this.labelId = this.editLabelId
    this.getAllDataByLabelId()
    this.getTemplates()
  },
}
</script>

<style scoped lang="less">
.newTemplate {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .newTemplate-header {
    box-sizing: border-box;
    top: 0px;
    width: 100%;
    height: 58px;
    border-bottom: 1px dashed #d1dbe7;
  }
  .newTemplate-header .el-button,
  .newTemplate-keyWord .newTemplate-keyWord-header .el-button {
    margin-top: 10px;
    width: 100px;
    margin-left: 10px;
    font-family: '微软雅黑';
  }
  .newTemplate-header span {
    display: inline-block;
    height: 58px;
    line-height: 58px;
    font-size: 14px;
    color: #6e798b;
  }
  .newTemplate-name {
    width: 100%;
    height: 72px;
    border-bottom: 1px dashed #d1dbe7;
  }
  .newTemplate-name span {
    display: inline-block;
    height: 72px;
    line-height: 72px;
    font-size: 14px;
    padding: 0 13px;
    box-sizing: border-box;
  }
  .newTemplate-special span {
    display: block;
    padding: 18px 0px;
    box-sizing: border-box;
    font-size: 14px;
  }
  .newTemplate-keyWord .newTemplate-keyWord-header {
    width: 100%;
    height: 54px;
  }
  .newTemplate-keyWord .newTemplate-keyWord-header span {
    display: inline-block;
    height: 54px;
    line-height: 54px;
    font-size: 14px;
  }
  #addKey .keyBeizhu span,
  #addKey .keyWorld span.xingDot {
    width: 8px;
    text-align: right;
    float: left;
    font-size: 14px;
    color: #ff4949;
  }
  #addKey .keyBeizhu span,
  #addKey .keyWorld span.keyzuhe {
    width: 80px;
    text-align: right;
    float: left;
    font-size: 14px;
    color: #8691a3;
  }
  .keyWorld {
    position: relative;
  }
  .addkeyFooter .el-button {
    margin-top: 10px;
    width: 100px;
    margin-left: 10px;
    font-family: '微软雅黑';
  }
  #addKey #keyRules {
    padding: 20px 25px 30px 18px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 1500px) {
    #addKey #keyRules {
      width: 400px;
      height: 380px;
      border: 1px solid #bfcbd9;
      box-shadow: 2px 2px 2px 2px #f4f4f4;
      top: 43%;
      right: 90px;
      transform: translateY(-50%);
    }

    #addKey #keyRules::before {
      content: '';
      height: 15px;
      position: absolute;
      width: 15px;
      background: #fff;
      top: 62%;
      right: -7px;
      transform: rotate(45deg);
      border-top: 1px solid #bfcbd9;
      border-right: 1px solid #bfcbd9;
    }
  }
  @media screen and (max-width: 2000px) and (min-width: 1500px) {
    #addKey #keyRules {
      width: 466px;
      height: 400px;
      border: 1px solid #bfcbd9;
      box-shadow: 2px 2px 2px 2px #f4f4f4;
      top: 43%;
      left: 39%;
      transform: translateY(-50%);
    }

    #addKey #keyRules::before {
      content: '';
      height: 15px;
      position: absolute;
      width: 15px;
      background: #fff;
      top: 43%;
      right: -7px;
      transform: rotate(45deg);
      border-top: 1px solid #bfcbd9;
      border-right: 1px solid #bfcbd9;
    }
  }
  .spanStyle {
    display: inline-block;
    border: 1px solid #ddd;
    text-align: center !important;
    width: 55px !important;
    margin-left: 3px;
    border-radius: 4px;
    cursor: pointer;
  }
  .el-input.w-65 {
    width: 65px;
  }
  .el-input.w-67 {
    width: 67px;
  }
  .el-input.w-78 {
    width: 78px;
  }
  .el-input.w-160 {
    width: 160px;
  }
  .el-select.w-65 {
    width: 65px;
  }
  .el-select.w-97 {
    width: 97px;
  }
  .el-select.w-160 {
    width: 160px;
  }
  .el-form-item {
    display: inline-block;
  }
  .el-form-item.w-240 {
    width: 240px;
  }
  .el-form-item.w-218 {
    width: 218px;
  }
  .el-form-item.w-138 {
    width: 138px;
  }
}
</style>
<style>
.newTemplate {
  #newTemmodelself,
  #newTemmodel {
    background: #fff;
    border: none;
  }

  #newTemmodelself table,
  #newTemmodel table {
    border-left: 1px solid #dfe6ec;
  }

  #newTemmodelself .el-table__body-wrapper,
  #newTemmodel .el-table__body-wrapper {
    overflow-x: hidden;
  }

  @media screen and (min-height: 769px) {
    #newTemmodelself .el-table__body-wrapper,
    #newTemmodel .el-table__body-wrapper {
      height: 400px;
    }
  }

  @media screen and (max-height: 768px) and (min-height: 650px) {
    #newTemmodelself .el-table__body-wrapper,
    #newTemmodel .el-table__body-wrapper {
      height: 200px;
    }
  }

  @media screen and (max-height: 649px) {
    #newTemmodelself .el-table__body-wrapper,
    #newTemmodel .el-table__body-wrapper {
      height: 90px;
    }
  }
}
</style>
