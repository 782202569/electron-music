<template>
  <div class="caseManage" id="caseManage">
    <div class="caseContent" v-show="!templateShow">
      <div class="caseLeft" id="caseLeft">
        <div class="caseLeftType">
          <el-tabs :tab-position="tabPosition" @tab-click="tabClick" value="guanjianci">
            <el-tab-pane label="关键词标签" name="guanjianci"></el-tab-pane>
            <!-- <el-tab-pane label="算法标签" name="suanfa"></el-tab-pane> -->
            <el-tab-pane label="情绪标签" name="qingxu"></el-tab-pane>
          </el-tabs>
        </div>
        <div class="caseLeftTree" id="caseLeftTree">
          <div class="item">
            <el-button
              funcId="000034"
              class="icon-button"
              title="新增分类"
              icon="el-icon-plus"
              @click="showAddTreeNodeModal"
            ></el-button>
            <el-button
              funcId="000035"
              class="icon-button"
              title="编辑分类"
              icon="iconfont icon-bianjishu"
              @click="showEditTreeNodeModal"
            ></el-button>
            <el-button
              funcId="000036"
              class="icon-button"
              title="删除分类"
              icon="iconfont icon-shanchu"
              @click="deleteTreeNode"
            ></el-button>
          </div>
          <div class="tree">
            <el-tree
              :data="treeData"
              :props="defaultProps"
              :check-strictly="strictly"
              @current-change="currentChange"
              highlight-current
              :expand-on-click-node="false"
              node-key="recordLabelClassId"
              @node-click="handleTreeNodeClick"
              :default-checked-keys="defaultCheckedKeys"
              default-expand-all
            >
              <span class="custom-tree-node" slot-scope="{ node, data }">
                <span>{{ node.label }}</span>
              </span>
            </el-tree>
          </div>
        </div>
        <el-dialog
          title="添加分类"
          :close-on-click-modal="false"
          :visible.sync="addTreeModalVisible"
          width="380px"
          @open="openAddFormModal"
          @close="closeAddFormModal"
        >
          <el-form
            :model="addTreeNodeForm"
            ref="addTreeNodeFormRef"
            :rules="addTreeNodeFormRules"
            label-width="100px"
          >
            <el-form-item label="类别名称" prop="nodeName">
              <el-input style="width:220px" v-model="addTreeNodeForm.nodeName"></el-input>
            </el-form-item>
            <!--<el-form-item label="所属分类">
              <el-cascader
                :options="options"
                :change-on-select="true"
                :show-all-levels="false"
                @change="casCaderChange"
                v-model="selectedOptions3"
              ></el-cascader>
            </el-form-item>-->
            <!--分类名称从页面选择的节点传入-->
            <el-form-item label="所属分类" prop="parentNodeName">
              <el-input
                disabled
                style="width:220px"
                v-model="addTreeNodeForm.parentNodeName"
              ></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="closeAddFormModal">取 消</el-button>
            <el-button type="primary" @click="saveTreeNode">保存</el-button>
          </div>
        </el-dialog>
        <el-dialog
          title="编辑分类"
          :close-on-click-modal="false"
          :visible.sync="editTreeModalVisible"
          width="30%"
          @close="closeEditFormModal"
        >
          <el-form
            ref="editTreeNodeFormRef"
            :model="editTreeNodeForm"
            :rules="rules"
            label-width="100px"
          >
            <el-form-item label="原分类名称">
              <el-input
                style="width:220px"
                :disabled="true"
                v-model="editTreeNodeForm.oldNodeName"
              ></el-input>
            </el-form-item>
            <el-form-item label="新分类名称" prop="newNodeName">
              <el-input
                style="width:220px"
                v-model="editTreeNodeForm.newNodeName"
              ></el-input>
            </el-form-item>
            <!--<el-form-item label="所属分类">
              <el-cascader
                :options="options"
                :change-on-select="true"
                :show-all-levels="false"
                @change="casCaderChange"
                v-model="selectedOptions3"
              ></el-cascader>
            </el-form-item>-->
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="closeEditFormModal">取 消</el-button>
            <el-button type="primary" @click="updateTreeNodeName">更 新</el-button>
          </div>
        </el-dialog>
      </div>
      <div class="caseRight" id="caseRight">
        <div class="container" id="container">
          <div id="guanjianci" style="height: 100%">
            <div class="act-head">
              <el-form ref="namesForm" :model="namesForm">
                <el-form-item prop="name">
                  <el-input
                    v-model="namesForm.queryLabelName"
                    placeholder="请输入标签名称"
                    style="width: 160px"
                  ></el-input>
                  <el-button
                    type="primary"
                    style="margin-left: 10px"
                    @click="clickButtonQueryLabels"
                    >查询</el-button
                  >
                  <el-button
                    funcId="000380"
                    v-show="selectedTreeNode"
                    style="margin-left: 10px;float: left;"
                    @click="gotoTemplatePage"
                    >新建</el-button
                  >
                  <el-button
                    funcId="000037"
                    style="margin-left: 10px;float: left"
                    @click="batchPauseLabels"
                    >批量暂停</el-button
                  >
                </el-form-item>
              </el-form>
            </div>
            <div class="content">
              <div class="table urty-ui">
                <div style="padding-left: 10px">
                  <el-table
                    border
                    ref="multipleTable"
                    :data="tableData"
                    @select="selectLabel"
                    @select-all="selectLabel"
                    :default-sort="{ prop: 'createTime', order: 'descending' }"
                  >
                    <el-table-column type="selection" width="45"></el-table-column>
                    <el-table-column prop="labelName" label="标签名称"> </el-table-column>
                    <el-table-column label="所属分类" width="160">
                      <template scope="scope">
                        {{ scope.row.classId | classIdToClassName(treeData) }}
                      </template>
                    </el-table-column>
                    <el-table-column
                      prop="createTime"
                      width="155"
                      sortable
                      :formatter="convertDate"
                      label="标签建立时间"
                    ></el-table-column>
                    <el-table-column
                      prop="recordCount"
                      label="录音数量"
                    ></el-table-column>
                    <el-table-column
                      prop="executeState"
                      :formatter="convertExecuteState"
                      label="状态"
                    ></el-table-column>
                    <el-table-column label="操作" width="200">
                      <template scope="scope">
                        <div class="name-wrapper biaoqian">
                          <i
                            funcId="000386"
                            style="margin-right:8px;"
                            v-if="scope.row.executeState == '1'"
                            @click="pauseLabel(scope.row.labelId)"
                          >
                            <i style="padding-left: 3px">暂停</i>
                          </i>
                          <i
                            style="margin-right:8px;"
                            funcId="000386"
                            v-if="scope.row.executeState == '0'"
                            @click="showStartLabelModal(scope.row.labelId)"
                          >
                            <i
                              style="padding-left: 3px"
                              @click="showStartLabelModal(scope.row.labelId)"
                              >启用</i
                            >
                          </i>
                          <i
                            funcId="000378"
                            style="margin-right:10px;"
                            @click="editLabel(scope.row, false)"
                            v-if="scope.row.executeState == '0'"
                          >
                            <i style=";margin-left:4px;">编辑</i>
                          </i>
                          <i
                            funcId="000379"
                            style="font-size: 13px; margin-right: 10px;"
                            @click="deleteLabel(scope.row.labelId)"
                          >
                            <i style="padding-left: 3px">删除</i>
                          </i>
                          <i
                            style="font-size: 13px; margin-right: 10px;"
                            v-if="scope.row.executeState == '1'"
                            @click="editLabel(scope.row, true)"
                          >
                            <i style="padding-left: 3px">查看</i>
                          </i>
                        </div>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
              </div>
              <div class="autoGrading-page">
                <el-pagination
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page="pageNumber"
                  :page-sizes="[10, 20, 30, 40]"
                  :page-size="100"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="totalCount"
                >
                </el-pagination>
              </div>
            </div>
          </div>
          <div id="suanfa" style="height: 100%">
            <div class="container">
              <div class="act-head">
                <div style="float: left;">
                  <el-button v-if="!algLabelTaskRunning" @click="enable(0)"
                    >启用</el-button
                  >
                  <el-button v-else @click="disable(0)">暂停</el-button>
                </div>
                <div style="float: right;">
                  <el-input
                    v-model="biaoQianName"
                    placeholder="请输入标签名"
                    class="biaoQianName"
                  ></el-input>
                  <el-button type="primary" class="biaoQianSearch" @click="biaoQianSearch"
                    >查询</el-button
                  >
                </div>
              </div>
              <div class="content">
                <div class="table">
                  <el-table :data="suanFaTableData" style="width: 100%">
                    <el-table-column prop="labelName" label="标签名称"> </el-table-column>
                    <el-table-column
                      prop="lastExecuteTime"
                      :formatter="exeTimeFilter"
                      sortable
                      label="上次执行时间"
                    >
                    </el-table-column>
                    <el-table-column prop="count" label="录音数量"> </el-table-column>
                  </el-table>
                </div>
                <div class="autoGrading-page">
                  <el-pagination
                    @size-change="suanFahandleSizeChange"
                    @current-change="suanFahandleCurrentChange"
                    :current-page="suanFapageNumber"
                    :page-sizes="[10, 20, 30, 40]"
                    :page-size="100"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="suanFaTotalCount"
                  >
                  </el-pagination>
                </div>
              </div>
            </div>
          </div>
          <div id="qingxu" style="height: 100%">
            <div class="container">
              <div class="act-head">
                <div style="float: left;">
                  <el-button
                    funcId="000387"
                    v-if="!sentimentLabelTaskRunning"
                    @click="enable(1)"
                    >启用</el-button
                  >
                  <el-button funcId="000387" v-else @click="disable(1)">暂停</el-button>
                </div>
              </div>
              <div class="content">
                <div class="f1">坐席侧</div>
                <div>
                  <el-table :data="sentimentTableData.seat" style="width: 100%">
                    <el-table-column prop="name" label="标签名称"> </el-table-column>
                    <el-table-column prop="date" sortable label="上次执行时间">
                    </el-table-column>
                    <el-table-column prop="address" label="录音数量"> </el-table-column>
                  </el-table>
                </div>
                <div class="f1">客户侧</div>
                <div>
                  <el-table :data="sentimentTableData.custom" style="width: 100%">
                    <el-table-column prop="name" label="标签名称"> </el-table-column>
                    <el-table-column prop="date" sortable label="上次执行时间">
                    </el-table-column>
                    <el-table-column prop="address" label="录音数量"> </el-table-column>
                  </el-table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <vAddRecordLabelComponent
      @submitted="submitted"
      @close="close"
      ref="addRecordLabelComponent"
      :typeHide="typeHide"
      :classIdsTwo="classIdsTwo"
      :treeSelectName="treeSelectName"
      :editType="editType"
      :classID="classID"
      :labelID="labelID"
      :isLook="isLook"
    ></vAddRecordLabelComponent>
    <router-view></router-view>
    <v-template
      v-if="templateShow"
      v-on:send="gotoQueryPage"
      :editType="editType"
      :editLabelId="editLabelId"
      :classId="selectedTreeNode != null ? selectedTreeNode.recordLabelClassId : null"
    ></v-template>
    <el-dialog
      title="启用"
      :close-on-click-modal="false"
      width="40%"
      :visible.sync="startLabelDialogVisible"
      @close="closeStartLabelModal"
    >
      <el-form
        :model="startLabelForm"
        :rules="startLabelRules"
        ref="startLabelRef"
        label-width="120px"
        label-position="left"
      >
        <el-form-item label="首次执行时间" prop="startLabelDateRange">
          <!--<el-date-picker type="datetimerange" v-model="startLabelForm.startLabelDateRange" placeholder="选择首次执行时间范围"></el-date-picker>-->
          <el-date-picker
            v-model="startLabelForm.startLabelDateRange"
            type="datetime"
            placeholder="请选择时间"
          >
          </el-date-picker>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="startLabelDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="startLabel">确定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="启用"
      :visible.sync="enableModal"
      @close="closeEnableModal"
      width="30%"
    >
      <el-form
        :model="enableForm"
        :rules="startAlgOrSentimentLabelRules"
        ref="startAlgOrSentimentLabelRef"
      >
        <el-form-item label="首次执行时间" label-width="100" prop="times">
          <el-date-picker
            v-model="enableForm.times"
            type="datetime"
            placeholder="选择日期"
          >
          </el-date-picker>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeEnableModal">取消</el-button>
        <el-button type="primary" @click="enableYes">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Vue from 'vue'
import $ from 'jquery'
import moment from 'moment'
import vAddRecordLabelComponent from './addRecordLabelComponent'
import Qs from 'qs'
import { validModelTrim } from '@/utry-sdk/common/constants'
import { requestUrls } from '@/utry-sdk/http/url.conf'
import formatdate from '../../../utils/formatdate.js'
import vTemplate from './recordLabelTemplate'
import funcFilter from '@/utils/funcFilter.js'

const deleteEmptyChildren = function deleteEmptyChildren(treeArr) {
  if (!treeArr) {
    return
  }
  treeArr.forEach((item) => {
    if (item.children && item.children instanceof Array && item.children.length > 0) {
      deleteEmptyChildren(item.children)
    } else {
      delete item.children
    }
  })
}

export default {
  components: {
    vTemplate,
    vAddRecordLabelComponent,
  },
  data() {
    return {
      classId: '',
      options: [],
      optionsList: [],
      resultOptions: [],
      selectedOptions3: [],
      defaultCheckedKeys: ['08634575a6a811e8b3ad000c29de6cf3'],
      defaultPropsTree: {
        value: 'id',
        children: 'child',
        label: 'name',
      },
      cascaderProps: {
        value: 'recordLabelClassId',
        children: 'children',
        label: 'recordLabelClassName',
      },
      strictly: true,
      suanFaTableData: [],
      enableForm: {
        type: 0,
        times: '',
      },
      biaoQianName: '',
      tabPosition: 'left',
      classIds: [],
      allLevels: false,
      isOnSelect: true,
      treeData: [],
      treeDataTwo: [],
      tableData: [],
      totalCount: 0,
      suanFaTotalCount: 0,
      pageNumber: 1,
      suanFapageNumber: 1,
      pageNumberSuan: 1,
      pageSizeSuan: 10,
      suanFaTotal: 0,
      pageSize: 10,
      addTreeModalVisible: false,
      editTreeModalVisible: false,
      addTreeNodeForm: {
        nodeName: '',
        parentNodeId: '',
        parentNodeName: '',
      },
      addTreeNodeFormRules: {
        nodeName: [{ validator: validModelTrim, required: true, trigger: 'blur' }],
      },
      rules: {
        nodeName: [{ validator: validModelTrim, trigger: 'blur' }],
        newNodeName: [{ validator: validModelTrim, trigger: 'blur' }],
      },
      startLabelRules: {
        startLabelDateRange: [
          {
            required: true,
            message: '首次执行时间不能为空',
            trigger: ['blur', 'change'],
          },
        ],
      },
      editTreeNodeForm: {
        newNodeName: '',
        nodeId: '',
        oldNodeName: '',
      },
      namesForm: {
        queryLabelName: '',
      },
      startLabelForm: {
        startLabelDateRange: '',
      },
      defaultProps: {
        children: 'children',
        label: 'recordLabelClassName',
      },
      selectedTreeNode: null,
      selectedLabels: [],
      templateShow: false,
      editType: 'new',
      editLabelId: null,
      startLabelDialogVisible: false,
      startLabelId: null,
      classIdRecord: '',
      classID: '',
      parentLabelClassId: '',
      treeSelectName: '',
      labelID: '',
      classIdsTwo: '',
      typeHide: true,
      isLook: false, // 原本是可编辑状态，既不可查看
      parentNodeId: '',
      enableModal: false,
      showTreeList: false,
      treeName: '',
      algLabelTaskRunning: false,
      sentimentLabelTaskRunning: false,
      startAlgOrSentimentLabelRules: {
        times: [
          {
            required: true,
            message: '首次执行时间不能为空',
            trigger: ['blur', 'change'],
          },
        ],
      },
      sentimentTableData: {
        seat: [],
        custom: [],
      },
    }
  },
  directives: {
    'click-outside': {
      bind: function(el, binding, vNode) {
        // Provided expression must evaluate to a function.
        if (typeof binding.value !== 'function') {
          const compName = vNode.context.name
          let warn = `[Vue-click-outside:] provided expression '${binding.expression}' is not a function, but has to be`
          if (compName) {
            warn += `Found in component '${compName}'`
          }

          console.warn(warn)
        }
        // Define Handler and cache it on the element
        const bubble = binding.modifiers.bubble
        const handler = (e) => {
          if (bubble || (!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },
      unbind: function(el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      },
    },
  },
  methods: {
    casCaderChange(item) {
      console.info(item)
      if (item.length === 1) {
        this.classId = item[0]
      }
      if (item.length > 1) {
        for (let p = 0; p < item.length; p++) {
          if (p === item.length - 1) {
            this.classId = item[p]
          }
        }
      }
      console.info(this.classId)
    },
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    // 点击自己 还是除了自己以外的元素
    outside: function(e) {
      this.showTreeList = false
    },
    inside: function(e) {
      this.showTreeList = true
      $('.is-focusable .el-checkbox__input span').removeClass('el-checkbox__inner')
      $('.is-focusable .el-checkbox__input span').addClass('el-radio__inner')
    },
    // 标签名称查询
    biaoQianSearch() {
      this.getAlgorithmLabel()
    },
    closeEnableModal() {
      let that = this
      that.enableModal = false
      that.enableForm.times = ''
    },
    enableYes() {
      this.$refs['startAlgOrSentimentLabelRef'].validate((valid) => {
        if (valid) {
          let that = this
          that.enableModal = false
          let params = {}
          if (this.enableForm.times !== '') {
            params['firstRecordTimeMin'] = formatdate.formatDate(this.enableForm.times)
          }
          let url
          if (that.enableForm.type == 0) {
            url = requestUrls['startAlgLabelUrl']
          } else {
            url = requestUrls['startSentimentLabelUrl']
          }
          this.axios
            .post(url, Qs.stringify(params))
            .then(function(response) {
              if (response.status == 200) {
                that.$message.success('启用成功!')
                if (that.enableForm.type == 0) {
                  that.algLabelTaskRunning = true
                } else {
                  that.sentimentLabelTaskRunning = true
                }
              }
            })
            .catch(function() {})
        }
      })
    },
    // 启用
    enable(type) {
      let that = this
      let startAlgOrSentimentLabelRef = that.$refs['startAlgOrSentimentLabelRef']
      if (startAlgOrSentimentLabelRef) {
        startAlgOrSentimentLabelRef.resetFields()
      }
      that.enableModal = true
      that.enableForm.type = type
    },
    disable(type) {
      this.$confirm('确认暂停？')
        .then(() => {
          let url
          if (type == 0) {
            url = requestUrls['stopAlgLabelUrl']
          } else {
            url = requestUrls['stopSentimentLabelUrl']
          }
          let params = {}
          let configss = {
            headers: {
              'Content-Type': 'application/json',
              Accept: 'application/json',
              'prefer-service-zone': 'fangjunhao',
            },
          }
          let that = this
          this.axios
            .post(url, Qs.stringify(params), configss)
            .then(function(response) {
              if (response.status == 200) {
                that.$message.success('暂停成功!')
                if (type == 0) {
                  that.algLabelTaskRunning = false
                } else {
                  that.sentimentLabelTaskRunning = false
                }
              }
            })
            .catch(function() {})
        })
        .catch(() => {})
    },
    // 左侧导航切换
    tabClick(tab) {
      if (tab.name === 'guanjianci') {
        document.getElementById('guanjianci').style.display = 'block'
        document.getElementById('suanfa').style.display = 'none'
        document.getElementById('qingxu').style.display = 'none'
        document.getElementById('caseLeftTree').style.display = 'block'
        document.getElementById('caseLeftTree').style.width = '260' + 'px'
        document.getElementById('caseRight').style.marginLeft = '380' + 'px'
        document.getElementById('caseLeft').style.width = '380' + 'px'
      } else if (tab.name === 'suanfa') {
        document.getElementById('guanjianci').style.display = 'none'
        document.getElementById('suanfa').style.display = 'block'
        document.getElementById('qingxu').style.display = 'none'
        document.getElementById('caseLeftTree').style.display = 'none'
        document.getElementById('caseLeftTree').style.width = '0' + 'px'
        document.getElementById('caseRight').style.marginLeft = '100' + 'px'
        document.getElementById('caseLeft').style.width = '120' + 'px'
        this.getAlgorithmLabel()
        this.getAlgTaskState()
      } else {
        document.getElementById('guanjianci').style.display = 'none'
        document.getElementById('suanfa').style.display = 'none'
        document.getElementById('qingxu').style.display = 'block'
        document.getElementById('caseLeftTree').style.display = 'none'
        document.getElementById('caseLeftTree').style.width = '0' + 'px'
        document.getElementById('caseRight').style.marginLeft = '100' + 'px'
        document.getElementById('caseLeft').style.width = '120' + 'px'
        this.getSentimentLabel()
        this.getSentimentTaskState()
      }
    },
    handleChange(event) {
      console.log(event)
      // 获取数组最后一个id
      let args = event
      console.log(args[args.length - 1])
      this.parentNodeId = args[args.length - 1]
    },
    // 点击编辑
    edit() {},
    // 关闭标签弹框
    close() {
      let that = this
      that.$refs.addRecordLabelComponent.showDialog = false
    },
    submitted(data) {
      console.log(data)
      let that = this
      that.$refs.addRecordLabelComponent.showDialog = false
      that.refreshTree()
      that.refreshTreeTwo()
      that.queryLabels()
    },
    convertExecuteState(row) {
      let executeState = row['executeState']
      if (executeState === '1') {
        return '启用中'
      }
      return '暂停中'
    },
    convertDate(row) {
      return formatdate.formatDate(row['createTime'])
    },
    // 给级联选择器重新赋值
    regroupTree: function(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        if (value[i].children === null) {
          treeList[i] = {
            label: value[i].recordLabelClassName,
            value: value[i].recordLabelClassId,
          }
        } else {
          treeList[i] = {
            label: value[i].recordLabelClassName,
            value: value[i].recordLabelClassId,
            children: this.regroupTree(value[i].children, []),
          }
        }
      }
      return treeList
    },
    refreshTree() {
      this.selectedTreeNode = null
      this.axios.post(requestUrls['getTreeDataUrl']).then((response) => {
        this.treeData = response.data
        this.options = response.data
        this.optionsList = JSON.parse(JSON.stringify(this.options))
        let cascaderList = []
        for (let l = 0; l < response.data.length; l++) {
          if (
            response.data[l].children === [] ||
            response.data[l].children === undefined
          ) {
            cascaderList[l] = {
              label: response.data[l].recordLabelClassName,
              value: response.data[l].recordLabelClassId,
              children: [],
            }
          } else {
            cascaderList[l] = {
              label: response.data[l].recordLabelClassName,
              value: response.data[l].recordLabelClassId,
              children: this.regroupTree(response.data[l].children, []),
            }
          }
        }
        this.options = cascaderList
        deleteEmptyChildren(this.options)
        console.info(cascaderList)
        this.queryLabels()
      })
    },
    refreshTreeTwo() {
      this.axios
        .post(requestUrls.getTreeDataUrl)
        .then((response) => {
          this.treeDataTwo = response.data
          deleteEmptyChildren(this.treeDataTwo)
        })
        .catch(() => {})
        .then(() => {})
    },
    currentChange(node) {
      console.log(node)
    },
    handleTreeNodeClick(node, data) {
      this.selectedTreeNode = node
      this.pageNumber = 1
      this.queryLabels()
      this.classID = node.recordLabelClassId
      this.treeSelectName = node.recordLabelClassName
      this.addTreeNodeForm.parentNodeId = node.recordLabelClassId
      this.addTreeNodeForm.parentNodeName = node.recordLabelClassName
      this.treeName = node.recordLabelClassName
    },
    renderContent(h, { node, data, store }) {
      return ''
    },
    showAddTreeNodeModal() {
      let selectedNode = this.selectedTreeNode
      this.addTreeModalVisible = true
      this.$nextTick(() => {
        this.$refs['addTreeNodeFormRef'].resetFields()
        if (selectedNode) {
          this.addTreeNodeForm.parentNodeName = selectedNode.recordLabelClassName
          this.addTreeNodeForm.parentNodeId = selectedNode.recordLabelClassId
          this.classId = selectedNode.recordLabelClassId
        } else {
          this.addTreeNodeForm.parentNodeName = '无'
          this.addTreeNodeForm.parentNodeId = '0'
        }
      })
      this.classIds = []
    },
    openAddFormModal() {
      /* if (!this.selectedTreeNode) {
          this.$nextTick(() => {
            this.$message.error('没有选中节点，添加的节点将视为根节点')
          })
        } */
      this.refreshTreeTwo()
    },
    closeAddFormModal() {
      this.addTreeModalVisible = false
      this.addTreeNodeForm.parentNodeName = ''
      this.addTreeNodeForm.parentNodeId = ''
      this.treeName = ''
      this.selectedOptions3 = []
      this.refreshTreeTwo()
    },
    closeEditFormModal() {
      this.editTreeModalVisible = false
      this.editTreeNodeForm.newNodeName = ''
      this.editTreeNodeForm.oldNodeName = ''
    },
    showEditTreeNodeModal() {
      let data = this.selectedTreeNode
      if (!data) {
        this.$message.error('请先选择一个待编辑的分类节点')
        return
      }
      if (data.recordLabelClassId === '02851820c16311e89c762a565a13608') {
        this.$message.error('默认分类不能编辑')
        return
      }
      // this.refreshTree()
      this.editTreeNodeForm.oldNodeName = data.recordLabelClassName
      this.editTreeNodeForm.newNodeName = ''
      this.editTreeNodeForm.nodeId = data.recordLabelClassId
      this.editTreeModalVisible = true
      this.$nextTick(() => {
        this.$refs['editTreeNodeFormRef'].resetFields()
      })
      this.classID = data.recordLabelClassId
      this.parentLabelClassId = data.parentLabelClassId
      this.digui(this.optionsList, this.parentLabelClassId)
      this.selectedOptions3 = this.resultOptions
    },
    digui(array, cid) {
      if (typeof array != 'undefined') {
        for (let i = 0; i < array.length; i++) {
          if (cid == array[i].recordLabelClassId) {
            console.log(
              array[i].recordLabelClassId + '####' + array[i].parentLabelClassId
            )
            this.resultOptions.splice(0, 0, cid)
            this.digui(this.optionsList, array[i].parentLabelClassId)
          } else {
            this.digui(array[i].children, cid)
          }
        }
      }
    },
    saveTreeNode() {
      this.$refs['addTreeNodeFormRef'].validate((valid) => {
        if (valid) {
          let formData = Object.assign({}, this.addTreeNodeForm)
          if (!this.classId) {
            formData.parentNodeId = 0
            formData.parentNodeName = ''
          } else {
            formData.parentNodeId = this.classId
          }
          this.axios
            .post(requestUrls['saveTreeNodeUrl'], Qs.stringify(formData))
            .then((response) => {
              let data = response['data']
              if (data['state'] === '1') {
                this.$message.success('添加成功')
                this.refreshTree()
                this.closeAddFormModal()
                this.selectedTreeNode = null
                this.selectedOptions3 = []
                this.classId = ''
                this.refreshTreeTwo()
                this.classIds = []
              } else {
                this.$message.error(data['message'])
              }

              // this.$refs.addTreeNodeForm.resetFields()
            })
        }
      })
    },
    updateTreeNodeName() {
      this.$refs['editTreeNodeFormRef'].validate((valid) => {
        /* if (!this.classId) {
            this.editTreeNodeForm.parentNodeId = 0
          } else {
            this.editTreeNodeForm.parentNodeId = this.classId
          } */
        if (valid) {
          this.axios
            .post(
              requestUrls['updateTreeNodeNameUrl'],
              Qs.stringify(this.editTreeNodeForm)
            )
            .then((response) => {
              let data = response['data']
              if (data.state === '1') {
                this.$message.success('更新分类名称成功!')
                this.refreshTree()
                this.closeEditFormModal()
              } else {
                this.$message.error(data['message'])
              }
              this.refreshTreeTwo()
              this.selectedTreeNode = null
              this.classIds = []
            })
            .catch(() => {
              this.$message.error('更新分类节点发生异常')
            })
        }
      })
    },
    deleteTreeNode() {
      let data = this.selectedTreeNode
      if (!data) {
        this.$message.error('请先选择一个待删除的分类节点')
        return
      }
      if (data.recordLabelClassId === '02851820c16311e89c762a565a13608') {
        this.$message.error('默认分类不能删除')
        return
      }
      this.$confirm(
        `此操作将会删除节点“${data.recordLabelClassName}”下所有的分类节点以及对应的标签，是否继续?`,
        '警告',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'error',
        }
      ).then(() => {
        let params = {
          nodeId: data.recordLabelClassId,
        }
        this.axios
          .post(requestUrls['deleteTreeNodeUrl'], Qs.stringify(params))
          .then((response) => {
            let data = response['data']
            if (data['state'] === '1') {
              this.$message({
                message: '删除成功',
                type: 'success',
              })
              this.refreshTree()
              this.selectedTreeNode = null
            } else {
              this.$message.error('删除失败!')
            }
            this.refreshTreeTwo()
          })
          .catch(() => {
            this.$message.error('删除节点发生异常')
          })
      })
    },
    queryLabels() {
      let params = {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        queryLabelName: this.namesForm.queryLabelName,
      }
      console.info(this.selectedTreeNode)
      if (this.selectedTreeNode) {
        params['classId'] = this.selectedTreeNode['recordLabelClassId']
      } else {
        params['classId'] = ''
      }
      this.axios
        .post(requestUrls['queryLabelUrl'], Qs.stringify(params))
        .then((response) => {
          let data = response.data
          this.totalCount = data['count']
          this.tableData = data['results']
          this.filterButton() // 过滤权限按钮
        })
        .catch(() => {
          this.$message.error('查询标签出现异常!')
        })
    },
    clickButtonQueryLabels() {
      this.pageNumber = 1
      this.queryLabels()
    },
    handleCurrentChange(val) {
      this.pageNumber = val
      this.queryLabels()
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.pageNumber = 1
      this.queryLabels()
    },
    suanFahandleCurrentChange(val) {
      this.pageNumberSuan = val
      this.getAlgorithmLabel()
    },
    suanFahandleSizeChange(val) {
      this.pageSizeSuan = val
      this.pageNumberSuan = 1
      this.getAlgorithmLabel()
    },
    selectLabel(selection) {
      this.selectedLabels = selection
    },
    batchPauseLabels() {
      if (this.selectedLabels && this.selectedLabels.length === 0) {
        this.$message.warning('请至少选中一个标签暂停!')
        return
      }
      let classIds = []
      this.selectedLabels.forEach((e) => {
        classIds.push(e['labelId'])
      })
      let params = {
        labelIdList: classIds.join(','),
      }
      this.axios
        .post(requestUrls['batchPauseUrl'], Qs.stringify(params))
        .then((response) => {
          let data = response['data']
          if (data) {
            this.$message.success('暂停成功!')
            this.queryLabels()
          } else {
            this.$message.error('暂停失败!')
          }
        })
        .catch(() => {
          this.$message.error('暂停标签出现异常!')
        })
      this.selectedLabels = [] // 最终操作后，将选中的标签置为空
    },
    pauseLabel(id) {
      if (!id) {
        return
      }
      this.axios
        .post(requestUrls['batchPauseUrl'], Qs.stringify({ labelIdList: id }))
        .then((response) => {
          let data = response['data']
          if (data) {
            this.$message.success('暂停成功!')
            this.queryLabels()
          } else {
            this.$message.error('暂停失败!')
          }
        })
    },
    deleteLabel(id) {
      if (!id) {
        return
      }
      this.$confirm('你确定要删除这个标签吗?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error',
      }).then(() => {
        let params = {
          labelId: id,
        }
        this.axios
          .post(requestUrls['isCallQaModel'], Qs.stringify(params))
          .then((response) => {
            let data = response['data']
            if (!data) {
              this.axios
                .post(requestUrls['deleteLabelUrl'], Qs.stringify(params))
                .then((response) => {
                  let data = response['data']
                  if (data) {
                    this.$message.success('删除成功!')
                    this.queryLabels()
                  } else {
                    this.$message.error('删除失败!')
                  }
                })
            } else {
              this.$message.error('标签被模板或业务分类调用!')
            }
          })
      })
    },
    gotoTemplatePage() {
      // this.templateShow = true
      this.$refs.addRecordLabelComponent.showDialog = true
      this.$refs.addRecordLabelComponent.handleResetKey()
      // this.classID = this.classIdRecord
      this.editType = 'new'
      this.typeHide = true
      this.isLook = false
      // this.editLabelId = null
    },
    editLabel(label, isLook) {
      let that = this
      console.log(label)
      that.templateShow = false
      that.editType = 'edit'
      that.editLabelId = label.labelId
      that.treeId = label.classId
      that.labelID = label.labelId
      that.classIdsTwo = label.labelId
      this.treeSelectName = Vue.filter('classIdToClassName')(
        label.classId,
        this.treeData || []
      )
      that.isLook = isLook
      that.$refs.addRecordLabelComponent.showDialog = true
      that.typeHide = true // 录音标签修改的时候不需要所属分类
    },
    gotoQueryPage() {
      this.templateShow = false
      this.queryLabels()
    },
    showStartLabelModal(labelId) {
      this.startLabelDialogVisible = true
      this.startLabelId = labelId
      this.$nextTick(() => {
        this.$refs['startLabelRef'].resetFields()
      })
    },
    startLabel() {
      this.$refs['startLabelRef'].validate((valid) => {
        if (valid) {
          let params = {
            labelId: this.startLabelId,
            firstRecordTimeMin: formatdate.formatDate(
              this.startLabelForm.startLabelDateRange
            ),
          }
          /* if (this.startLabelForm.startLabelDateRange[0]) {
              params['firstRecordTimeMin'] = formatdate.formatDate(this.startLabelForm.startLabelDateRange[0])
            }
            if (this.startLabelForm.startLabelDateRange[1]) {
              params['firstRecordTimeMax'] = formatdate.formatDate(this.startLabelForm.startLabelDateRange[1])
            } */
          this.axios
            .post(requestUrls['startLabelUrl'], Qs.stringify(params))
            .then((response) => {
              let data = response['data']
              if (data) {
                this.$message.success('启用成功!')
                this.queryLabels()
                this.closeStartLabelModal()
              } else {
                this.$message.error('启用失败!')
              }
            })
        }
      })
    },
    closeStartLabelModal() {
      this.startLabelDialogVisible = false
      this.startLabelId = ''
      this.startLabelDateRange = []
    },
    getAlgorithmLabel() {
      this.axios
        .get(
          requestUrls['getAlgorithmLabel'] +
            '/page?pageNumber=' +
            this.pageNumberSuan +
            '&pageSize=' +
            this.pageSizeSuan +
            '&queryLabelName=' +
            this.biaoQianName
        )
        .then((response) => {
          let data = response['data']
          if (data) {
            this.suanFaTableData = data.results
            this.suanFaTotalCount = data.results.length
          }
        })
    },
    getSentimentLabel: function() {
      let that = this
      this.axios.get(requestUrls['getSentimentLabel']).then((response) => {
        let data = response['data']
        if (data) {
          let seat = []
          let custom = []
          let date = data.lastTime
          if (date != null) {
            date = formatdate.formatDate(date)
          }
          for (let i = 0; i < 3; i++) {
            let tag = '' + i
            let tagName = tag
            switch (tag) {
              case '0':
                tagName = '积极情绪'
                break
              case '1':
                tagName = '正常情绪'
                break
              case '2':
                tagName = '消极情绪'
                break
            }
            seat.push({ name: tagName, date: date, address: data.data.seat[tag] })
            custom.push({ name: tagName, date: date, address: data.data.custom[tag] })
          }
          that.sentimentTableData.seat = seat
          that.sentimentTableData.custom = custom
        }
      })
    },
    getAlgTaskState: function() {
      this.axios.get(requestUrls['getAlgLabelTaskState']).then((response) => {
        let data = response['data']
        if (data) {
          this.algLabelTaskRunning = data.running
        }
      })
    },
    getSentimentTaskState: function() {
      this.axios.get(requestUrls['getSentimentLabelTaskState']).then((response) => {
        let data = response['data']
        if (data) {
          this.sentimentLabelTaskRunning = data.running
        }
      })
    },
    /*
     * 过滤权限按钮
     * */
    filterButton() {
      /*
       获取数据后dom节点更改了，
        需要再获取一遍dom节点对[funcID]按钮进行过滤
       * */
      let menuId = localStorage.getItem('menuId')
      let path = this.$route.path.replace('/', '')
      funcFilter(menuId, path)
    },
  },
  mounted() {
    this.refreshTree()
    // this.refreshTreeTwo()
  },
}
</script>
<style lang="less" scoped="scoped">
.utry-select-tree-class {
  width: 220px;
}
.caseManage {
  width: 100%;
  /*top:1px;*/
  box-sizing: border-box;
  height: 100%;
  position: relative;
  #refuse {
    width: 100%;
    margin: 0 auto;
    overflow: hidden;
    label {
      color: #000;
      font-weight: bold;
    }
  }
  .caseContent {
    padding: 10px 10px 10px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    .caseRight {
      height: 100%;
      margin-left: 380px;
      overflow: hidden;
      position: relative;
      /*border-left: 1px solid #d1dbe5;*/
      .container {
        overflow: hidden;
        height: 100%;
        position: relative;
        .content {
          padding-top: 58px;
          padding-bottom: 80px;
          box-sizing: border-box;
          width: 100%;
          height: 100%;
        }
        .autoGrading-page {
          right: 10px;
          position: absolute;
          bottom: 10px;
        }
        .table {
          width: 100%;
          height: 100%;
          overflow: auto;
          /*position: absolute;
            top: 55px;
            bottom: 80px;
            cursor: pointer;*/
        }
        .act-head {
          right: 0;
          top: 0;
          width: 100%;
          position: absolute;
          text-align: right;
          height: 44px;
          .biaoQianName {
            float: left;
            width: 240px;
          }
          .biaoQianSearch {
            float: left;
            margin-left: 10px;
          }
        }
      }
    }
    .caseLeft {
      width: 380px;
      height: 100%;
      float: left;
      /*position: relative;*/
      .caseLeftType {
        position: relative;
        height: 100%;
        width: 120px;
        left: 0px;
        float: left;
      }
      .caseLeftTree {
        position: relative;
        left: 120px;
        height: 100%;
        width: 260px;
        border-right: 1px solid #d1dbe5;
      }
      .tree {
        position: absolute;
        top: 55px;
        left: 0px;
        bottom: 0px;
        overflow: auto;
        width: 100%;
        cursor: pointer;
      }
      .item {
        position: absolute;
        top: 0px;
        text-align: right;
        right: 10px;
        width: 100%;

        .icon-button {
          opacity: 0.7;
          width: 25px;
          height: 25px;
          padding: 0;
        }

        a {
          float: right;
          margin: 10px 10px 10px 0px;
          i {
            cursor: pointer;
            margin-right: 10px;
            border: 1px solid #d1dbe7;
            padding: 5px;
            border-radius: 3px;
          }
        }
      }
    }
  }
  .caseHeader {
    float: left;
    box-sizing: border-box;
    top: 0px;
    width: 100%;
    height: 42px;
    border-bottom: 1px solid #d1dbe5;
    background-color: #eef1f6;
    ul {
      cursor: pointer;
      width: 200px;
      li {
        display: inline-block;
        text-align: center;
        width: 80px;
        line-height: 42px;
        font-size: 14px;
      }
      .active {
        color: #20a0ff;
      }
    }
  }
}
</style>
<style lang="less" scoped>
.contentLeft {
  width: 220px;
  top: 0px;
  right: 0;
  position: relative;
  z-index: 3000;
  .treeMenu {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    .el-tree {
      max-height: 200px;
      min-height: 80px;
      overflow-y: auto;
      border: 1px solid #ccc;
    }
    .btns {
      width: 99%;
      height: 36px;
      border: 1px solid #ccc;
      border-top: 0;
      background: #fff;
      .el-button {
        float: right;
        width: 52px;
        height: 30px;
        margin-top: 2px;
        font-size: 12px;
        margin-right: 10px;
      }
    }
  }
}
#caseManage .select-width {
  width: 220px;
  margin-top: 3px;
}
#caseManage .biaoqian {
  font-size: 13px;
  color: #409eff;
  cursor: pointer;
}
#caseManage .f1 {
  font-size: 14px;
  color: #222;
  font-weight: bold;
  padding-left: 8px;
}
#caseManage .el-tabs--left,
.el-tabs--right {
  height: 100%;
}
#caseManage .custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
#caseManage {
  .caseContent {
    ul {
      cursor: pointer;
      /*border-bottom: 1px solid #d1dbe5;*/
      background-color: #eef1f6;
      li {
        /*display: inline-block;*/
        text-align: center;
        /*width: 80px;*/
        /*line-height: 42px;*/
        font-size: 14px;
      }
      .active {
        color: #20a0ff;
      }
    }
  }

  .el-tree {
    /*border: none;*/
  }
  .el-table .cell,
  .el-table th > div {
    padding-left: 8px;
    padding-right: 8px;
    box-sizing: border-box;
    text-overflow: ellipsis;
    color: #222;
  }
}
</style>
