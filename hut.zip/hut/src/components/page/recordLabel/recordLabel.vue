<template>
  <div id="record-label">
    <div class="record-label-pos">
      <!--<div class="record-label-pos-nav">
        <ul>
          <li data-id="0" @click="toggleSound" class="record-labelActive">算法分类标签</li>
          <li data-id="1" @click="toggleSound">关键词分类标签</li>
        </ul>
      </div>-->
      <div class="record-label-pos-content">
        <!-- <recordAlgLabel style="width:100%;height:100%; position: relative;" v-if="index==='0'"/>-->
        <recordKeywordLabel style="width:100%;height:100%; position: relative;" />
      </div>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import recordAlgLabel from './recordAlgLabel.vue' // 算法分类标签
import recordKeywordLabel from './recordKeywordLabel.vue' // 关键词标签
export default {
  components: {
    recordAlgLabel,
    recordKeywordLabel,
  },
  data() {
    return {
      index: '0', // 默认显示页签
    }
  },
  methods: {
    toggleSound(event) {
      // 首页头部切换
      let currentIndex = $(event.target).attr('data-id')
      this.index = currentIndex
      $('.record-label-pos-nav ul li').removeClass('record-labelActive')
      $(event.target).addClass('record-labelActive')
    },
  },
}
</script>
<style lang="less">
#record-label {
  box-sizing: border-box;
  height: 100%;
  overflow: hidden;
  width: 100%;
  .record-label-pos {
    width: 100%;
    height: 100%;
    position: relative;
  }
  .record-label-pos .record-label-pos-nav {
    width: 100%;
    height: 40px;
    line-height: 40px;
    background: #eef1f6;
    border-bottom: 1px solid #d1dbe4;
    position: absolute;
  }
  .record-label-pos-nav ul {
    width: 100%;
    box-sizing: border-box;
  }
  .record-label-pos-nav ul li {
    float: left;
    padding: 0 12.5px;
    box-sizing: border-box;
    font-size: 14px;
    color: #96a2b2;
    cursor: pointer;
  }
  .record-labelActive {
    color: #21a2ff !important;
  }
  .record-label-pos .record-label-pos-content {
    /*padding:42px 10px 0;*/
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}
</style>
