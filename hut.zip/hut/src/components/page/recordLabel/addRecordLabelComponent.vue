<!--
 - 用于添加关键词录音标签的通用组件
 - 使用说明
 - 需要的props请看props
 - close、open、closed事件对应dialog的事件
 - submited事件为用户成功提交数据后的事件
 -->
<template>
  <el-dialog
    :visible="showDialog"
    :title="dialogTitle"
    :width="'700px'"
    :close-on-click-modal="false"
    @close="$emit('close')"
    @open="onOpen"
    @closed="reset"
  >
    <div class="container" style="height: 500px; overflow-y: auto;">
      <div class="container" v-loading="loadingCount > 0">
        <el-form
          :rules="rules"
          :disabled="isLook"
          ref="form"
          label-position="left"
          :model="form"
        >
          <div style="height: 20px"></div>
          <div class="form-row">
            <el-form-item>
              <el-row>
                <el-col :span="12">
                  <el-form-item label="标签名称" prop="labelName">
                    <el-input style="width: 180px" v-model="form.labelName"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="所属分类">
                    <el-input
                      style="width: 180px"
                      :value="treeSelectName"
                      disabled
                    ></el-input>
                  </el-form-item>
                  <!--
                <el-form-item  label="所属分类" prop="typeClassId" label-position='right' label-width='100px'>
                  <el-cascader
                    :options="options"
                    :change-on-select="true"
                    :show-all-levels="false"
                    @change="casCaderChange"
                    v-model="form.selectedOptions3"
                  ></el-cascader>
                  <template>
                    <el-input class="select-width"
                              ref="regionInput"
                              v-click-outside="outside"
                              @focus="inside"
                              v-model="form.treeName">
                    </el-input>
                    <div class="contentLeft" v-show="this.showTreeList == true">
                      <div class="treeMenu">
                        <el-tree
                          :data="treeData"
                          :render-after-expand=false
                          :props="defaultPropsTree"
                          @node-click="handleNodeClickTree"
                          :expand-on-click-node="false"
                          ref="keyWordsMenu"
                          node-key="id"
                          :check-strictly=true>
                        </el-tree>
                      </div>
                    </div>
                  </template>
                </el-form-item>-->
                </el-col>
              </el-row>
            </el-form-item>
          </div>
          <div class="line"></div>

          <div class="section-title">
            周期（天）
          </div>
          <el-form-item label="首次执行时间" prop="startLabelDateRange">
            <!--<el-date-picker style="width: 186px" type="datetimerange" v-model="form.startLabelDateRange"
                          placeholder="选择首次执行时间范围"></el-date-picker>-->
            <!--<el-date-picker
            v-model="form.startLabelDateRange"
            type="date"
            placeholder="选择首次执行时间范围">
          </el-date-picker>-->
            <el-date-picker
              type="datetime"
              v-model="form.startLabelDateRange"
              placeholder="选择首次执行时间范围"
            >
            </el-date-picker>
          </el-form-item>
        </el-form>
        <div class="line"></div>

        <div class="section-title">
          语音特征
        </div>
        <el-form :inline="true" :disabled="isLook">
          <el-row>
            <el-col :span="12">
              <el-form-item label="重叠次数">
                <el-input
                  style="width: 70px"
                  v-model="form.overlapMin"
                  placeholder="次"
                ></el-input>
                <span>-</span>
                <el-input
                  style="width: 70px"
                  v-model="form.overlapMax"
                  placeholder="次"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                label="坐席平均语速"
                label-width="100px"
                label-position="left"
              >
                <el-input
                  style="width: 70px"
                  v-model="form.avgSpeedMin"
                  placeholder="字/秒"
                ></el-input>
                <span>-</span>
                <el-input
                  style="width: 70px"
                  v-model="form.avgSpeedMax"
                  placeholder="字/秒"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <!-- <el-form-item  label="情绪分值" v-show="false">
              <el-input style="width: 70px" v-model="form.moodScoreMin"></el-input>
              <span>-</span>
              <el-input style="width: 70px" v-model="form.moodScoreMax"></el-input>
            </el-form-item> -->
              <el-form-item label="静默特征">
                <el-select
                  v-model="form.silenceType"
                  clearable
                  placeholder="请选择"
                  style="width: 160px"
                >
                  <el-option
                    v-for="item in silenceTypeList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                label="时长"
                v-if="form.silenceType === '1'"
                label-width="100px"
              >
                <el-input
                  style="width: 70px"
                  v-model="form.silenceLongMin"
                  placeholder="秒"
                ></el-input>
                <span>-</span>
                <el-input
                  style="width: 70px"
                  v-model="form.silenceLongMax"
                  placeholder="秒"
                ></el-input>
              </el-form-item>
              <el-form-item
                label="次数"
                v-if="form.silenceType === '2'"
                label-width="100px"
              >
                <el-input-number
                  style="width: 70px"
                  controls-position="right"
                  class="urty-ui__number"
                  v-model="form.silenceTimeMin"
                  :min="1"
                  :max="999"
                ></el-input-number>
                <span>-</span>
                <el-input-number
                  style="width: 70px"
                  controls-position="right"
                  class="urty-ui__number"
                  v-model="form.silenceTimeMax"
                  :min="1"
                  :max="999"
                ></el-input-number>
                <span>次</span>
              </el-form-item>
              <el-form-item
                label="占比"
                v-if="form.silenceType === '3'"
                label-width="100px"
              >
                <el-input style="width: 70px" v-model="form.silencePerMin"></el-input>
                <span>-</span>
                <el-input style="width: 70px" v-model="form.silencePerMax"></el-input>
                <span>%</span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div class="line"></div>

        <div class="section-title">
          关键词 &nbsp; &nbsp;

          <el-popover placement="right" width="400" trigger="click">
            <div class="rules" style="background: #fff">
              1."AND"关键字表示"与"的关系，可以匹配到同时存在关键字左右两个关键词<br />
              2."OR"关键字表示"或"的关系，可以匹配到存在关键字左右其中至少一个关键词<br />
              3."NOT"关键字表示"非"的关系，可以匹配到存在不存在关键字右侧的关键词<br />
              4."BEFORE"关键字表示有先后顺序"临近"的关系，可以匹配到存在关键字右侧的关键词且之前的n个词内会存在关键字左侧的关键词<br />
              5."AFTER"关键字表示有先后顺序"临近"的关系，可以匹配到存在关键字右侧的关键词且之前的n个词内会存在关键字左侧的关键词<br />
              6."NEAR"关键词表示有临近关系<br />
              7."()"可以在括号中使用以上关键字并提高关键字的匹配优先级<br />
            </div>
            <a
              slot="reference"
              href="javascript: void(0);"
              style="text-decoration: underline"
            >
              术语规则
            </a>
          </el-popover>
        </div>
        <br />
        <el-form
          size="small"
          :disabled="isLook"
          ref="addTag"
          :model="formData"
          :rules="formDataRules"
        >
          <el-form-item
            class="key-words"
            v-for="(item, index) in items"
            :model="item"
            :key="item.id"
            prop="keyWords"
          >
            <el-form
              :disabled="isLook"
              class="key-word"
              size="small"
              ref="addKeyWord"
              :model="item.keyWordData"
              :validate-on-rule-change="false"
              :rules="getFormItemValidateRule(item.keyWordData)"
            >
              <!-- 关键词配置规则 -->
              <el-form-item class="key-words-range" prop="sentencesNumber">
                <el-select
                  size="small"
                  class="size-select"
                  v-model="item.keyWordData.fullScriptRole"
                >
                  <el-option label="全部角色" :value="0"></el-option>
                  <el-option label="客服" :value="1"></el-option>
                  <el-option label="客户" :value="2"></el-option>
                </el-select>
                <span class="zai">在</span>
                <el-select
                  size="small"
                  class="size-select"
                  v-model="item.keyWordData.position"
                >
                  <el-option label="全文" :value="0"></el-option>
                  <el-option label="开头" :value="1"></el-option>
                  <el-option label="结束" :value="2"></el-option>
                </el-select>
                <template
                  v-if="
                    item.keyWordData.position == 1 || item.keyWordData.position == 2
                      ? true
                      : false
                  "
                >
                  <el-input
                    v-model.number="item.keyWordData.sentencesNumber"
                    size="small"
                    class="gap size-ju"
                    maxLength="3"
                  ></el-input
                  >句
                </template>
                <el-select
                  size="small"
                  class="gap size-select"
                  v-model="item.keyWordData.appear"
                >
                  <el-option label="出现" :value="1"></el-option>
                  <el-option label="未出现" :value="0"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item class="key-words-content" prop="expression">
                <el-input
                  class="textarea-input-width"
                  ref="textInput"
                  type="textarea"
                  v-model="item.keyWordData.expression"
                  placeholder="请输入关键词"
                  maxlength="4000"
                  size="small"
                ></el-input>
                <div class="logical-words">
                  <el-button
                    size="small"
                    :disabled="item.keyWordData.expression ? false : true"
                    @click="AND(index)"
                    >AND</el-button
                  >
                  <el-button
                    size="small"
                    :disabled="item.keyWordData.expression ? false : true"
                    @click="OR(index)"
                    >OR</el-button
                  >
                  <el-button
                    size="small"
                    :disabled="item.keyWordData.expression ? false : true"
                    @click="AFTER(index)"
                    >AFTER</el-button
                  >
                  <el-button
                    size="small"
                    :disabled="item.keyWordData.expression ? false : true"
                    @click="BEFORE(index)"
                    >BEFORE</el-button
                  >
                  <el-button
                    size="small"
                    :disabled="item.keyWordData.expression ? false : true"
                    @click="NEAR(index)"
                    >NEAR</el-button
                  >
                  <el-button size="small" @click="CIRCLE(index)">( )</el-button>
                  <template>
                    <el-popover
                      placement="bottom"
                      title="使用说明"
                      width="400"
                      trigger="hover"
                    >
                      <div v-html="html"></div>
                      <el-button slot="reference" class="instructions" size="small"
                        >?</el-button
                      >
                    </el-popover>
                  </template>
                </div>
              </el-form-item>
            </el-form>
            <div class="plus-minus-button">
              <el-button
                class="icon"
                @click="itemMinus(item)"
                v-if="index == 0 && items.length == 1 ? false : true"
              >
                <i class="el-icon-minus"></i>
              </el-button>
              <el-button
                class="icon"
                @click="itemPlus"
                :disabled="index == 4 ? true : false"
                v-if="index == items.length - 1 ? true : false"
              >
                <i class="el-icon-plus"></i>
              </el-button>
            </div>
          </el-form-item>
          <el-form-item label-width="100px" label="满足任意" prop="satisfyNumber">
            <el-input
              v-model.number="formData.satisfyNumber"
              class="correct-number"
              maxLength="3"
            ></el-input
            >个
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer" style="float: right; margin-top: 10px;">
        <el-button @click="cancelAddRecordLabel">取消</el-button>
        <el-button type="primary" :disabled="isLook" @click="submitRecordLabel"
          >确定</el-button
        >
      </span>
    </div>
  </el-dialog>
</template>
<script>
import global from '@/global'
import $ from 'jquery'
import Qs from 'qs'
import commonUtil from '@/utils/commonUtil.js'
import formatdate from '../../../utils/formatdate.js'
const deleteEmptyChildren = function deleteEmptyChildren(treeArr) {
  if (!treeArr) {
    return
  }
  treeArr.forEach((item) => {
    if (item.children && item.children instanceof Array && item.children.length > 0) {
      deleteEmptyChildren(item.children)
    } else {
      delete item.children
    }
  })
}

const requestUrls = {
  getAllDataByLabelIdUrl: global.currentBaseUrl + '/recordLabel/findByLabelId.do',
  getAllDataByTemplateId: global.currentBaseUrl + '/recordLabel/findByTemplateId.do',
  getTemplatesUrl: global.currentBaseUrl + '/pageConstant/getValue.do?keys=fullModel',
  saveLabelUrl: global.currentBaseUrl + '/recordLabel/addRecordLabel.do',
  copyTemplateUrl: global.currentBaseUrl + '/recordLabel/copyTemplate.do',
  getTreeDataUrl: global.currentBaseUrl + '/recordLabelClass/getRecordLabelClassTree.do',
}

const sceneTimeRule = (rule, value, callback) => {
  if (ruleThis.addKeyWordShow) {
    let errorMsg = '请填写完整此行信息或删除条件'
    if (ruleThis.keyWordForm.sceneTime == null || ruleThis.keyWordForm.sceneTime == '') {
      callback(new Error(errorMsg))
    }
    if (ruleThis.keyWordForm.sceneType == null) {
      callback(new Error(errorMsg))
    }
    if (
      ruleThis.keyWordForm.sceneValue == null ||
      ruleThis.keyWordForm.sceneValue == ''
    ) {
      callback(new Error(errorMsg))
    }
    if (ruleThis.keyWordForm.sceneValueType == null) {
      callback(new Error(errorMsg))
    }
  }
  callback()
}
const silenceTimeRule = (rule, value, callback) => {
  if (ruleThis.addKeyWordShow && ruleThis.selectVaule === false) {
    if (
      ruleThis.keyWordForm.silenceTimeMin == null ||
      ruleThis.keyWordForm.silenceTimeMax == ''
    ) {
      callback(new Error('目标静默时长不能为空'))
    }
  }
  callback()
}

let ruleThis

export default {
  computed: {
    // loadData() {},
  },
  watch: {
    loadData(val, oldval) {},
    showDialog(visible) {
      if (visible) {
        this.$nextTick(() => {
          this.$refs.form.resetFields()
        })
        this.currentClassifyTopic = ''
        this.typeClassId = this.classID
        // 加载主题特征词分类列表
        this.loadClassifyList()
      }
    },
  },
  directives: {
    'click-outside': {
      bind: function(el, binding, vNode) {
        // Provided expression must evaluate to a function.
        if (typeof binding.value !== 'function') {
          const compName = vNode.context.name
          let warn = `[Vue-click-outside:] provided expression '${binding.expression}' is not a function, but has to be`
          if (compName) {
            warn += `Found in component '${compName}'`
          }

          console.warn(warn)
        }
        // Define Handler and cache it on the element
        const bubble = binding.modifiers.bubble
        const handler = (e) => {
          if (bubble || (!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },
      unbind: function(el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      },
    },
  },
  data() {
    let checkCorrectNumber = (rule, value, callback) => {
      if (value !== '') {
        if (value <= 0 || value > this.$data.items.length) {
          callback('个数必须大于0且小于等于当前配置的规则数')
        } else {
          callback()
        }
      }
      callback()
    }
    return {
      defaultPropsTree: {
        children: 'children',
        value: 'recordLabelClassId',
        label: 'recordLabelClassName',
      },
      defaultProps: {
        value: 'id',
        children: 'child',
        label: 'name',
      },
      treeMenu: [], // 树菜单
      typeName: '',
      allLevels: false,
      cID: [],
      dialogTitle: '',
      showDialog: false,
      isOnSelect: true,
      classIds: [],
      treeData: [],
      loadingCount: 0,
      showRule: false,
      sceneTypes: [
        { value: 1, label: '之前' },
        { value: 2, label: '之后' },
      ],
      sceneNumTimes: [
        { value: 1, label: '秒' },
        { value: 2, label: '句' },
      ],
      addKeyWordShow: false,
      // 未完成的编辑历史栈
      keyWordEditStack: [],
      keyWordForm: {
        edit: false,
        keywordContext: '',
        fullScriptRole: '0',
        type: 1,
        silenceType: '',
        silenceList: [
          { value: '1', label: '时长' },
          { value: '2', label: '次数' },
        ],
      },
      silenceTypeList: [
        { value: '1', label: '时长' },
        { value: '2', label: '次数' },
        { value: '3', label: '占比' },
      ],
      fullScriptRoleList: [
        { value: '0', label: '全部角色' },
        { value: '1', label: '客服' },
        { value: '2', label: '客户' },
      ],
      form: {
        silenceType: '',
        labelName: '',
        startLabelDateRange: '',
        keyWords: [],
        treeName: '',
        typeClassId: '',
        selectedOptions3: [],
      },
      options: [],
      optionsList: [],
      resultOptions: [],
      selectedOptions3: [],
      rules: {
        labelName: [
          { required: true, message: '名称不能为空', trigger: 'blur' },
          { max: 10, message: '长度不能超过10字符', trigger: 'blur' },
        ],
        typeClassId: [{ required: true, message: '所属分类不能为空', trigger: 'blur' }],
        startLabelDateRange: [
          {
            required: true,
            message: '首次执行时间不能为空',
            trigger: ['blur', 'change'],
          },
        ],
      },
      typeClassId: '',
      keyWordFormRules: {
        fullScriptRole: [{ required: true, message: '不能为空', trigger: 'blur' }],
        keywordContext: [{ required: true, message: '关键词不能为空', trigger: 'blur' }],
        sceneTime: [{ validator: sceneTimeRule }],
        silenceTime: [{ validator: silenceTimeRule }],
      },
      showTree: false,
      selectVaule: false,
      showTreeList: false,
      // 主题分类列表（已解读）
      classifyTopicList: [],
      classifyTopicWords: [],
      clusterWordsLoading: false,
      currentClassifyTopic: '',
      currentClassifyTopicWord: '',
      // 关键词
      //逻辑词的使用说明
      html:
        '<h4>1、AND</h4><p>与："腾讯 AND 网站"，同时包含"腾讯"和"网站"的录音是目标录音。</p><h4>2、OR</h4><p>或："腾讯 OR 网站"，包含"腾讯" 或者"网站" 的录音，是目标录音。</p><h4>3、NEAR</h4><p>近："腾讯 NEAR 网站"，同时包含"腾讯"，"网站"，并且二者相隔的词不超过5个词的录音，是目标录音。</p><h4>4、BEFORE</h4><p>前："腾讯 BEFORE 网站"，同时包含"腾讯"，"网站"，并且"腾讯"在"网站" 之前，二者相隔的词不超过5个词的录音，是目标录音。</p><h4>5、AFTER</h4><p>后："腾讯 AFTER 网站"，同时包含"腾讯"，"网站"，并且"腾讯" 在"网站" 之后，二者相隔的词不超过5个词的录音，是目标录音。"</p>',
      formData: {
        satisfyNumber: '',
      },
      formDataRules: {
        satisfyNumber: [
          { required: true, message: '请输入满足规则个数', trigger: 'blur' },
          {
            type: 'number',
            message: '满足规则个数必须为正整数',
            trigger: 'blur',
          },
          { validator: checkCorrectNumber, trigger: 'blur' },
        ],
      },
      //配置规则
      items: [
        {
          id: Date.now(),
          keyWordData: {
            fullScriptRole: 0,
            sentencesNumber: '',
            position: 0,
            appear: 1,
            expression: '',
          },
        },
      ],
      tagId: '', //新增标签的id
    }
  },
  methods: {
    // 获取静默单位类型名称
    getSilentUnitType(val) {
      const types = this.sceneNumTimes || []
      return (types.filter((type) => type.value === val)[0] || {}).label || ''
    },
    // 获取静默类型名称
    getSilentPositionType(val) {
      const types = this.sceneTypes || []
      return (types.filter((type) => type.value === val)[0] || {}).label || ''
    },
    // 加载主题聚类名称列表（已解读）
    loadClassifyList() {
      this.axios
        .post(`${global.currentBaseUrl}/ivsClusterRule/getExistTopic`)
        .then((res) => {
          this.classifyTopicList = Array.isArray(res.data) ? res.data : []
        })
        .catch(() => {
          this.classifyTopicList = []
        })
    },
    // 加载主题特征词
    fetchClassifyWords(clusterId) {
      const cluster = this.classifyTopicList.filter(
        (item) => item.topicClusterId === clusterId
      )[0]
      this.classifyTopicWords = []
      this.currentClassifyTopicWord = ''
      if (cluster) {
        this.clusterWordsLoading = true
        this.axios
          .post(
            `${global.currentBaseUrl}/ivsClusterRule/getTopicReadWords.do`,
            Qs.stringify({
              topicClusterId: clusterId,
            })
          )
          .then((res) => {
            if (res.data.length > 0) {
              this.classifyTopicWords = res.data
            } else {
              this.classifyTopicWords = []
            }
            this.clusterWordsLoading = false
          })
          .catch(() => {
            this.clusterWordsLoading = false
          })
      }
    },
    chooseClusterWord(wordId) {
      const word = this.classifyTopicWords.filter((item) => item === wordId)[0]
      if (word) {
        this.insertAtCursor(word)
      }
    },
    handleNodeClickTree(data) {
      console.log(data)
      this.form.treeName = data.recordLabelClassName
      this.classId = data.recordLabelClassId
      this.showTreeList = false
    },
    // 点击自己 还是除了自己以外的元素
    outside: function(e) {
      this.showTreeList = false
    },
    inside: function() {
      this.showTreeList = true
      $('.is-focusable .el-checkbox__input span').removeClass('el-checkbox__inner')
      $('.is-focusable .el-checkbox__input span').addClass('el-radio__inner')
    },
    // 静默类型 时长/次数
    selectChange(value) {
      if (value === '1') {
        this.selectVaule = false
      } else {
        this.selectVaule = true
      }
    },
    // 树节点点击
    handleNodeClick(data) {
      // this.currentNode = data
      // this.classId = data.classId
      // this.getKeyWords()
    },
    clickDin: function() {
      let fouyt = this.$refs.keyWordsMenu.getCheckedNodes()
      console.log(fouyt.length)
      if (fouyt.length != 0) {
        this.typeName = fouyt[0].name
        console.log(fouyt[0].name)
      } else {
        this.typeName = ''
      }
      this.handleChange()
      this.showTree = false
    },
    fillAddForm(data) {
      this.form = Object.assign({ startLabelDateRange: '' }, data)
      if (data['firstRecordTimeMin']) {
        this.form.startLabelDateRange = new Date(data['firstRecordTimeMin'])
      }
    },
    getLabelData(labelID) {
      this.loadingCount++
      this.isSelectTemplate = false
      const params = {
        labelId: labelID,
      }
      this.axios
        .post(requestUrls.getAllDataByLabelIdUrl, Qs.stringify(params))
        .then((response) => {
          if (response.data['state'] === '1') {
            const data = response['data']['results'][0] || []
            this.fillAddForm(data)
          }
        })
        .catch((err) => {
          console.error(err)
          this.$message.error('获取标签数据时出现异常')
        })
        .then(() => {
          this.loadingCount--
        })
    },
    digui(array, cid) {
      if (typeof array != 'undefined') {
        for (let i = 0; i < array.length; i++) {
          if (cid == array[i].recordLabelClassId) {
            console.log(
              array[i].recordLabelClassId + '####' + array[i].parentLabelClassId
            )
            this.resultOptions.splice(0, 0, cid)
            this.digui(this.optionsList, array[i].parentLabelClassId)
          } else {
            this.digui(array[i].children, cid)
          }
        }
      }
    },
    casCaderChange(item) {
      if (item.length === 1) {
        this.typeClassId = item[0]
        this.form.typeClassId = item[0]
      }
      if (item.length > 1) {
        for (let p = 0; p < item.length; p++) {
          if (p === item.length - 1) {
            this.typeClassId = item[p]
            this.form.typeClassId = item[p]
          }
        }
      }
    },
    reset() {
      this.keyWordEditStack = []
      this.keyWordForm = {
        edit: false,
        keywordContext: '',
        fullScriptRole: '0',
        type: 1,
        silenceType: '',
        silenceList: [
          { value: '1', label: '时长' },
          { value: '2', label: '次数' },
        ],
      }
      this.form = {
        silenceType: '',
        labelName: '',
        startLabelDateRange: '',
        keyWords: [],
        treeName: '',
        typeClassId: '',
        selectedOptions3: [],
      }
      if (this.$refs.keyWordForm) {
        this.$refs.keyWordForm.clearValidate()
      }
      this.$emit('closed')
    },
    onOpen() {
      let _this = this
      this.form.treeName = this.treeSelectName
      this.classID = this.classID
      if (this.editType === 'edit') {
        this.dialogTitle = '编辑'
        if (this.isLook === true) {
          this.dialogTitle = '查看'
        }
        let params = {
          labelId: this.labelID,
        }
        this.axios
          .post(requestUrls['getAllDataByLabelIdUrl'], Qs.stringify(params))
          .then((response) => {
            let shuzu = []
            shuzu[0] = this.classIdsTwo
            if (response.data['state'] === '1') {
              let data = response['data']['results'][0] || {}
              /*关键词处理*/
              let responseData = data['scriptKeyWordList'] || []
              this.formData.satisfyNumber = data.ivsRecordLabel.satisfyNumber
              if (Array.isArray(responseData)) {
                this.items = responseData.map((item) => ({
                  ...item,
                  keyWordData: item,
                }))
                for (var i = 0; i < _this.items.length; i++) {
                  let item = _this.items[i].keyWordData
                  _this.$set(item, 'expression', item.keywordContext)
                  _this.$set(item, 'sentencesNumber', item.sentencesNum)
                  _this.$set(item, 'fullScriptRole', parseInt(item.fullScriptRole))
                }
              }
              this.fillAddForm(data.ivsRecordLabel)
              this.pageNumber = 1
              // this.fillKeywords()
              // this.refreshTree()
              this.typeClassId = response['data']['results'][0].ivsRecordLabel.classId
              console.log(this.typeClassId)
              // this.digui(this.optionsList, response['data']['results'][0].classId)
              // this.form.selectedOptions3 = this.resultOptions
            }
          })
      } else {
        this.dialogTitle = '新建'
        this.selectedOptions3 = []
        this.form = {
          silenceType: '',
          labelName: '',
          startLabelDateRange: '',
          keyWords: [],
          treeName: '',
          typeClassId: '',
          selectedOptions3: [],
        }
        this.addKeyWordShow = false
        this.keyWordForm.type = 2
      }
      /* if (this.labelID) {
          this.getLabelData(this.labelID)
        } */
      this.loadingCount = 0
      /* if (!this.classID) {
          this.refreshTree()
        } */
      this.refreshTree()
      // this.$emit('open')
    },
    validateParams(params) {
      if (commonUtil.isBlank(params['labelName'])) {
        return { msg: '标签名称不能为空!', flag: false }
      }
      if (
        commonUtil.isNotBlank(params['overlapMin']) &&
        commonUtil.isNotBlank(params['overlapMax'])
      ) {
        if (parseFloat(params['overlapMin']) > parseFloat(params['overlapMax'])) {
          return { msg: '重叠次数低值不能大于重叠次数高值!', flag: false }
        }
      }
      if (
        commonUtil.isNotBlank(params['moodScoreMin']) &&
        commonUtil.isNotBlank(params['moodScoreMax'])
      ) {
        if (parseFloat(params['moodScoreMin']) > parseFloat(params['moodScoreMax'])) {
          return { msg: '情绪分值低值不能大于情绪分值高值!', flag: false }
        }
      }
      if (
        commonUtil.isNotBlank(params['avgSpeedMin']) &&
        commonUtil.isNotBlank(params['avgSpeedMax'])
      ) {
        if (parseFloat(params['avgSpeedMin']) > parseFloat(params['avgSpeedMax'])) {
          return { msg: '平均语速低值不能大于平均语速高值!', flag: false }
        }
      }
      if (commonUtil.isNotBlank(params['silenceType'])) {
        if (
          commonUtil.isNotBlank(params['silenceLongMin']) &&
          commonUtil.isNotBlank(params['silenceLongMax'])
        ) {
          if (
            parseFloat(params['silenceLongMin']) > parseFloat(params['silenceLongMax'])
          ) {
            return { msg: '静默时长低值不能大于平均语速高值!', flag: false }
          }
        }
        if (
          commonUtil.isNotBlank(params['silenceTimeMin']) &&
          commonUtil.isNotBlank(params['silenceTimeMax'])
        ) {
          if (
            parseFloat(params['silenceTimeMin']) > parseFloat(params['silenceTimeMax'])
          ) {
            return { msg: '静默次数低值不能大于静默次数高值!', flag: false }
          }
        }
        if (
          commonUtil.isNotBlank(params['silencePerMin']) &&
          commonUtil.isNotBlank(params['silencePerMax'])
        ) {
          if (parseFloat(params['silencePerMin']) > parseFloat(params['silencePerMax'])) {
            return { msg: '静默占比低值不能大于静默占比高值!', flag: false }
          }
        }
      }
      return { msg: '', flag: true }
    },
    submitRecordLabel() {
      let audio = {}
      let that = this
      that.$refs.form.validate().then((result) => {
        if (!result) {
          return
        }
        /*关键词表单*/
        that.$refs.addTag.validate((valid) => {
          if (!valid) {
            return
          } else {
            if (this.items.some((item) => item.keyWordData.expression.length > 4000)) {
              this.$message.error('关键词规则长度超过限制')
              return
            }
            let addKeyWordForm = that.$refs.addKeyWord
            if (!Array.isArray(addKeyWordForm)) {
              addKeyWordForm = [addKeyWordForm]
            } else {
              addKeyWordForm = [...addKeyWordForm]
            }
            let count = 0
            for (const formkey of addKeyWordForm) {
              formkey.validate((valid) => {
                if (!valid) {
                  return
                }
                /*关键词表单数据*/
                count++
                if (count === addKeyWordForm.length) {
                  let keywordRules = []
                  that.items.forEach((item) => {
                    keywordRules.push(item.keyWordData)
                  })
                  /*除关键词的数据*/
                  let params = Object.assign({}, that.form)
                  let validateResult = this.validateParams(params)
                  if (!validateResult['flag']) {
                    that.$message.error(validateResult['msg'])
                    return
                  }
                  if (this.form.startLabelDateRange) {
                    params['firstRecordTimeMin'] = formatdate.formatDate(
                      that.form.startLabelDateRange
                    )
                  }
                  // params['keyWordJsonStr'] = JSON.stringify(that.form.keyWords)
                  params['classId'] = that.typeClassId // 判断
                  params['keyWordJsonStr'] = JSON.stringify(keywordRules)
                  params['satisfyNumber'] = this.formData.satisfyNumber
                  delete params.firstRecordTimeMax
                  delete params.startLabelDateRange
                  delete params.keyWords
                  delete params.createTime
                  audio = params
                  if (this.pageName === 'audio') {
                    that.$emit('formData', audio)
                  } else {
                    that.loadingCount++
                    that.axios
                      .post(requestUrls['saveLabelUrl'], Qs.stringify(params))
                      .then((response) => {
                        let data = response['data']
                        if (data['state'] === '1') {
                          that.$message.success('保存成功!')
                          that.$emit('submitted', response.data.other.recordLabelId)
                        } else {
                          this.$message.error(data['message'])
                        }
                        this.handleResetKey()
                        this.refreshTree()
                        // this.classIds = []
                      })
                      .catch((error) => {
                        console.error(error)
                        // 隐藏错误，axios中已经做了拦截
                        // that.$message.error('保存标签发生异常!')
                      })
                      .then(() => {
                        that.loadingCount--
                      })
                  }
                }
              })
            }
          }
        })
      })
      // this.$refs['form'].resetFields()
      // this.form.keyWords = []
    },
    close() {
      this.$emit('refreshTree')
      this.$refs['form'].resetFields()
      this.handleResetKey()
    },
    // 重置关键词
    handleResetKey() {
      this.items = [
        {
          keyWordData: {
            fullScriptRole: 0,
            sentencesNumber: '',
            position: 0,
            appear: 1,
            expression: '',
          },
        },
      ]
      this.$refs.addTag.resetFields()
      let addKeyWordForm = this.$refs.addKeyWord
      if (!Array.isArray(addKeyWordForm)) {
        addKeyWordForm = [addKeyWordForm]
      }
      for (const form of addKeyWordForm) {
        form.resetFields()
      }
    },
    cancelAddRecordLabel() {
      // this.$emit('close')
      this.showDialog = false
      this.handleResetKey()
      // this.classIds = []
    },
    resetKeywordForm(stackFlag) {
      if (!stackFlag || this.keyWordEditStack.length === 0) {
        this.keyWordForm = {
          edit: false,
          keywordContext: '',
          fullScriptRole: '0',
          type: 1,
          silenceType: '',
          silenceList: [
            { value: '1', label: '时长' },
            { value: '2', label: '次数' },
          ],
        }
        if (this.$refs.keyWordForm) {
          this.$refs.keyWordForm.clearValidate()
        }
        this.addKeyWordShow = false
        this.selectVaule = false
        return false
      }

      this.keyWordForm = this.keyWordEditStack.pop()
      if (this.$refs.keyWordForm) {
        this.$refs.keyWordForm.validate()
      }
      return true
    },
    deleteKeyWordOption() {
      this.addKeyWordShow = false
      this.keyWordForm.type = 2
    },
    insertAtCursor(signature) {
      if (signature !== '()') {
        this.keyWordForm.keywordContext += ' ' + signature + ' '
      } else {
        this.keyWordForm.keywordContext = '(' + this.keyWordForm.keywordContext + ')'
      }
      // focus到 textarea 上，方便继续输入
      this.$refs.keywordContextTextarea.focus()
    },
    showAddKeyWordForm() {
      if (!this.addKeyWordShow) {
        this.addKeyWordShow = true
        this.keyWordForm.type = 1
      }
      this.keyWordForm.silenceType === ''
        ? (this.selectVaule = false)
        : (this.selectVaule = true) // false代表的是目标静默时长展示
    },
    getUUID() {
      return formatdate.formatDate(new Date()) + Math.random()
    },
    handleChange(event) {
      console.log(event)
    },
    // 给级联选择器重新赋值
    regroupTree: function(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        if (value[i].children === null) {
          treeList[i] = {
            label: value[i].recordLabelClassName,
            value: value[i].recordLabelClassId,
          }
        } else {
          treeList[i] = {
            label: value[i].recordLabelClassName,
            value: value[i].recordLabelClassId,
            children: this.regroupTree(value[i].children, []),
          }
        }
      }
      return treeList
    },
    refreshTree() {
      this.loadingCount++
      this.axios
        .post(requestUrls.getTreeDataUrl)
        .then((response) => {
          if (response.data) {
            if (this.editType === 'edit') {
              let optionsList = JSON.parse(JSON.stringify(response.data))
              this.digui(optionsList, this.typeClassId)
              this.form.selectedOptions3 = this.resultOptions
            }
            let cascaderList = []
            for (let l = 0; l < response.data.length; l++) {
              if (
                response.data[l].children === [] ||
                response.data[l].children === undefined
              ) {
                cascaderList[l] = {
                  label: response.data[l].recordLabelClassName,
                  value: response.data[l].recordLabelClassId,
                  children: [],
                }
              } else {
                cascaderList[l] = {
                  label: response.data[l].recordLabelClassName,
                  value: response.data[l].recordLabelClassId,
                  children: this.regroupTree(response.data[l].children, []),
                }
              }
            }
            this.options = cascaderList
            deleteEmptyChildren(this.options)
          }
        })
        .catch(() => {})
        .then(() => {
          this.loadingCount--
        })
    },
    // 关键词模块
    //新增标签弹窗内关键词必填项检查
    getFormItemValidateRule(data) {
      return {
        sentencesNumber: [
          {
            validator: (rule, value, callback) => {
              const range = data.position
              let error = []
              if (/^(?:1|2)$/.test(range)) {
                if (value == '') {
                  error.push('请输入话术范围')
                } else if (value < 0 || !/[1-9]\d*/.test(value)) {
                  error.push('话术范围必须为正整数')
                }
              }
              callback(error)
            },
            trigger: 'blur',
          },
        ],
        expression: [
          {
            validator: (rule, value, callback) => {
              if (!value || !value.trim()) {
                callback(new Error('请输入关键词信息'))
              } else {
                callback()
              }
            },
            trigger: 'blur',
          },
        ],
      }
    },
    // ‘+’ 按钮
    itemPlus() {
      this.items.push({
        id: Date.now(),
        keyWordData: {
          fullScriptRole: 0,
          sentencesNumber: '',
          position: 0,
          appear: 1,
          expression: '',
        },
      })
    },
    // ‘-’ 按钮
    itemMinus(item) {
      let index = this.items.indexOf(item)
      if (index !== -1) {
        this.items.splice(index, 1)
      }
    },
    //在光标处插入逻辑词
    insertContent(ref, text, index) {
      let _this = this
      const textInputs = ref
      let input = textInputs
      if (Array.isArray(textInputs)) {
        input = textInputs[index]
      }

      const textArea = input.$el.querySelector('textarea')

      if (document.selection) {
        textArea.focus() //光标聚焦
        let sel = document.selection.createRange()
        sel.text = text
        sel.select()
      } else if (textArea.selectionStart || textArea.selectionStart == '0') {
        let startPos = textArea.selectionStart //得到光标前的位置
        let endPos = textArea.selectionEnd //得到光标后的位置

        input.$emit(
          'input',
          textArea.value.substring(0, startPos) + text + textArea.value.substring(endPos)
        )

        // //插入内容
        // input.value =
        //   input.value.substring(0, startPos) +
        //   text +
        //   input.value.substring(endPos, input.value.length)
        // _this.items[0].keyWordData.expression = input.value
        // input.focus()
        // input.selectionStart = startPos + text.length
        // input.selectionEnd = startPos + text.length
      } else {
        input.$emit('input', textArea.value + text)

        // input.value += text
        // _this.items[0].keyWordData.expression = input.value
        // input.focus()
      }
    },
    //逻辑词
    AND(index) {
      let text = ' AND '
      const ref = this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    OR(index) {
      let text = ' OR '
      const ref = this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    AFTER(index) {
      let text = ' AFTER#5 '
      const ref = this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    BEFORE(index) {
      let text = ' BEFORE#5 '
      const ref = this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    NEAR(index) {
      let text = ' NEAR#5 '
      const ref = this.$refs.textInput
      this.insertContent(ref, text, index)
    },
    CIRCLE(index) {
      let text = ' () '
      const ref = this.$refs.textInput
      this.insertContent(ref, text, index)
    },
  },
  props: {
    treeSelectName: {
      type: String,
    },
    newBiaoData: {
      type: Array,
    },
    editNewBiaoIndex: {
      type: Number,
    },
    treeId: {
      type: String,
    },
    classID: {
      type: String,
    },
    labelID: {
      type: String,
    },
    editType: {
      type: String,
    },
    classIdsTwo: {
      type: String,
    },
    typeHide: {
      type: Boolean,
    },
    pageName: {
      type: String,
    },
    isLook: {
      type: Boolean,
    },
  },
  created() {
    ruleThis = this
  },
  // props: ['classID', 'labelID', 'editType', 'classIdsTwo', 'typeHide', 'pageName']
  /* props: {
      // 对应dialog中的visible组件
      /!* showDialog: {
        type: Boolean,
        required: true,
        default: false
      }, *!/
      classID: {
        type: String,
        required: true
      },
      // 需要编辑哪个分类
      labelID: {
        type: String
      }
    } */
}
</script>
<style lang="less" scoped>
.contentLeft {
  width: 220px;
  top: 0px;
  left: 80px;
  position: relative;
  z-index: 3000;
  .treeMenu {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    .el-tree {
      max-height: 200px;
      min-height: 80px;
      overflow-y: auto;
      border: 1px solid #ccc;
    }
    .btns {
      width: 99%;
      height: 36px;
      border: 1px solid #ccc;
      border-top: 0;
      background: #fff;
      .el-button {
        float: right;
        width: 52px;
        height: 30px;
        margin-top: 2px;
        font-size: 12px;
        margin-right: 10px;
      }
    }
  }
}
.container {
  padding: 0 15px;
  overflow: hidden;
  .hide {
    display: none;
  }
  .select-width {
    width: 200px;
    margin-top: 3px;
  }
  .disabled {
    color: #999;
    margin-bottom: 10px;
    display: block;
  }
  .contentLeft {
    left: 0;
    width: 220px;
    top: 45px;
    /* right: 0; */
    position: absolute;
    z-index: 3000;
    .treeMenu {
      position: absolute;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      .el-tree {
        max-height: 200px;
        min-height: 80px;
        overflow-y: auto;
        border: 1px solid #ccc;
      }
      .btns {
        width: 99%;
        height: 36px;
        border: 1px solid #ccc;
        border-top: 0;
        background: #fff;
        .el-button {
          float: right;
          width: 52px;
          height: 30px;
          margin-top: 2px;
          font-size: 12px;
          margin-right: 10px;
        }
      }
    }
  }
  .form-row {
    & > * {
      /*display: inline-block;*/
      &:not(:last-child) {
        margin-right: 10px;
      }
    }
  }

  a {
    line-height: 24px;
    color: rgba(32, 160, 255, 1);
    font-size: 14px;
    text-align: left;
    font-family: MicrosoftYaHei;
  }

  .line {
    height: 1px;
    width: 100%;
    background-color: rgba(209, 217, 226, 1);
  }

  .section-title {
    display: inline-block;
    line-height: 60px;
    color: #666666;
    font-size: 14px;
    font-family: 'MicrosoftYaHei-Bold', 'Microsoft YaHei Bold', 'Microsoft YaHei';
    font-weight: 700;

    .keyRules {
      position: relative;
      .rules {
        padding: 20px 25px 30px 18px;
        box-sizing: border-box;
      }
    }
  }

  .mark-color-blue {
    color: #20a0ff;
    margin: 0 4px;
  }

  .mark-condition {
    margin-left: 24px;
  }
  /*关键词*/
  .key-words {
    .key-word {
      position: relative;
      width: 100%;
      border: 1px solid #dedede;
      box-sizing: border-box;
      border-radius: 5px;
      padding: 20px 20px 0;
      float: left;
      .key-words-range {
        .zai {
          padding: 0 10px 0 5px;
        }
        .gap {
          margin-left: 10px;
        }
        .size-ju {
          width: 15%;
          margin-right: 5px;
        }
        .size-select {
          width: 20%;
        }
      }
      .instructions {
        margin-top: 5px;
        float: right;
      }
      .logical-words {
        margin-top: 5px;
      }
    }
    .plus-minus-button {
      float: left;
      position: absolute;
      top: 45%;
      left: 78%;
      .icon {
        margin-left: 10px;
        padding: 5px 16px;
        background-color: #fff;
        width: 48px;
        height: 30px;
      }
    }
    .textarea-input-width {
      width: 80%;
    }
  }
  .correct-number {
    width: 10%;
    margin-right: 10px;
  }
}
</style>
