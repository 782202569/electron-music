<template>
  <div class="SeatHome">
    <div class="header">
      <el-date-picker
        type="datetimerange"
        @change="this.handleChangeDate"
        :clearable="false"
        :editable="false"
        v-model="dateRange"
        :default-time="['00:00:00', '23:59:59']"
      ></el-date-picker>
    </div>
    <div class="content">
      <div class="content-line content-line-top">
        <!--<div class="item item1">
          <div class="title">违禁语(次)</div>
          <div class="countRate">
            <div class="count">
              {{ realEleData.contrabandWord }}
              <div class="rate">{{ realEleData.contrabandWordRatio }}</div>
            </div>
          </div>
        </div>-->
        <div class="item item2">
          <div class="title">打断客户(次)</div>
          <div class="countRate">
            <div class="count">
              {{ realEleData.interruptCustomer }}
              <div class="rate">{{ realEleData.interruptCustomerRatio }}</div>
            </div>
          </div>
        </div>
        <div class="item item3">
          <div class="title">申诉量(次)</div>
          <div class="countRate">
            <div class="count">
              {{ realEleData.appealCount }}
              <div class="rate">{{ realEleData.appealCountRatio }}</div>
            </div>
          </div>
        </div>
        <div class="item item4">
          <div class="title title_sp">
            <div class="title_item">平均语速</div>
            <div class="title_item">平均静默时长</div>
          </div>
          <div class="countRate countRate_sp">
            <div class="countRate_item countRate_item_sp">{{ realEleData.avgSpeed }}</div>
            <div class="countRate_item">{{ realEleData.silenceLong }}</div>
          </div>
        </div>
      </div>
      <div class="content-line content-line-bottom">
        <div class="item item5">
          <div class="echartWrap" id="appRateQA">
            此处环形图
          </div>
          <!--模版选择-->
          <div class="tableDealog tableDealog3" v-show="sustomShow1">
            <el-tabs v-model="selectActive1">
              <el-tab-pane label="评分模版" name="first">
                <div style="margin:10px;">
                  <span style="margin-right:10px;font-size:14px;">评分模版</span>
                  <el-select v-model="templateModel1">
                    <el-option
                      v-for="item in templateModels"
                      :label="item.modleTitle"
                      :key="item.modleId"
                      :value="item.modleId"
                    >
                    </el-option>
                  </el-select>
                </div>
                <div class="aloneFooter">
                  <el-button @click="cancelNot(1)">取 消</el-button>
                  <el-button
                    type="primary"
                    style="margin-right: 18px;"
                    @click="sureTemplate(1)"
                    >确 定
                  </el-button>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
        <div class="item item6">
          <div class="toolBar">
            <span class="title">成绩统计</span>
            <img
              v-popover:beishensulvSet
              class="icon"
              src="../../../assets/img/setIng.png"
              @click="
                sustomShow2 = true
                templateModelCopy2 = templateModel2
              "
            />
            <el-popover
              ref="beishensulvSet"
              popper-class="popperHover popperBeishensulv"
              placement="bottom"
              :visible-arrow="false"
              width="50"
              trigger="hover"
              content="自定义"
            >
            </el-popover>
          </div>
          <div class="subTitle">表现超过{{ tableDataRadio }}坐席</div>
          <div class="tableDealog tableDealog3" v-show="sustomShow2">
            <el-tabs v-model="selectActive1">
              <el-tab-pane label="评分模版" name="first">
                <div style="margin:10px;">
                  <span style="margin-right:10px;font-size:14px;">评分模版</span>
                  <el-select v-model="templateModel2">
                    <el-option
                      v-for="item in templateModels"
                      :label="item.modleTitle"
                      :key="item.modleId"
                      :value="item.modleId"
                    >
                    </el-option>
                  </el-select>
                </div>
                <div class="aloneFooter">
                  <el-button @click="cancelNot(2)">取 消</el-button>
                  <el-button
                    type="primary"
                    style="margin-right: 18px;"
                    @click="sureTemplate(2)"
                    >确 定
                  </el-button>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
          <el-table border tooltip-effect="dark" :data="tableData">
            <el-table-column prop="type" label="评分" width="150px"></el-table-column>
            <el-table-column prop="personScore" label="你"></el-table-column>
            <el-table-column prop="teamScore" label="团队"></el-table-column>
          </el-table>
        </div>
        <div class="item item7">
          <div id="scoreResult" class="echartWrap"></div>
          <!--模版选择-->
          <div class="tableDealog tableDealog3" v-show="sustomShow3">
            <el-tabs v-model="selectActive1">
              <el-tab-pane label="评分模版" name="first">
                <div style="margin:10px;">
                  <span style="margin-right:10px;font-size:14px;">评分模版</span>
                  <el-select v-model="templateModel3">
                    <el-option
                      v-for="item in templateModels"
                      :label="item.modleTitle"
                      :key="item.modleId"
                      :value="item.modleId"
                    >
                    </el-option>
                  </el-select>
                </div>
                <div class="aloneFooter">
                  <el-button @click="cancelNot(3)">取 消</el-button>
                  <el-button
                    type="primary"
                    style="margin-right: 18px;"
                    @click="sureTemplate(3)"
                    >确 定
                  </el-button>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import formatdate from '../../../utils/formatdate.js'
import global from '../../../global.js'
import Qs from 'qs'

let qualityUrl = global.qualityUrl
const colorList = [
  '#1890FF',
  '#41D9C7',
  '#2FC25B',
  '#FACC14',
  '#E6965C',
  '#223273',
  '#7564CC',
  '#8543E0',
  '#5C8EE6',
  '#13C2C2',
  '#5CA3E6',
  '#3436C7',
  '#B381E6',
  '#F04864',
  '#D598D9',
]
export default {
  components: {},
  data() {
    return {
      initTime: [],
      dateRange: [],
      templateModel1: '',
      selectActive1: 'first',
      templateModel2: '',
      selectActive2: 'first',
      templateModel3: '',
      selectActive3: 'first',
      templateModels: [],
      templateModel: '', //默认模版存储
      templateModelCopy1: '',
      templateModelCopy2: '',
      templateModelCopy3: '',
      sustomShow1: false,
      sustomShow2: false,
      sustomShow3: false,
      tableData: [],
      tableDataRadio: 0,
      realEleData: {},
    }
  },
  methods: {
    // 默认时间一天
    initDayTime() {
      let fromData = ''
      let toform = ''
      let now = new Date()
      now.setDate(1)
      now.setHours(0)
      now.setMinutes(0)
      now.setSeconds(0)
      fromData = formatdate.formatDate(now)
      let currentMonth = now.getMonth()
      let nextMonth = ++currentMonth
      let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
      let oneDay = 1
      toform = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      this.initTime = [fromData, toform]
      this.dateRange = this.initTime
    },
    // 选择时间
    handleChangeDate(val) {
      if (val) {
        let startTime = formatdate.formatDate(val[0])
        let endTime = formatdate.formatDate(val[1])
        this.dateRange = [startTime, endTime]
      } else {
        this.dateRange = this.initTime
      }
      this.initData()
    },
    /*
     *数据初始化
     * */
    initChartData() {
      // 获取模板列表
      let _this = this
      let paramsModel = {
        modleType: '7',
        pageindex: '',
        pagesize: '',
      }
      let url = qualityUrl + '/manualQualityAssurance/getModleInfoByCondition.do'
      _this.axios
        .post(url, Qs.stringify(paramsModel))
        .then(function(response) {
          _this.axios
            .post(qualityUrl + '/manualQualityAssurance/getRealTimeModel.do')
            .then(function(res) {
              let modleId = res.data.modleId
              _this.templateModels = response.data.Data
              _this.templateModel = _this.templateModel ? _this.templateModel : modleId
              _this.templateModel1 = _this.templateModel1
                ? _this.templateModel1
                : _this.templateModels[0].modleId
              _this.templateModel2 = _this.templateModel2
                ? _this.templateModel2
                : _this.templateModels[0].modleId
              _this.templateModel3 = _this.templateModel3
                ? _this.templateModel3
                : _this.templateModels[0].modleId
              _this.drawAppRate()
              _this.initScoreData()
              _this.drawScoreChart()
            })
        })

        .catch(function(error) {
          console.log(error)
          _this.$message.error('模板获取失败')
        })
    },
    cancelNot(num) {
      if (num == 1) {
        this.sustomShow1 = false
        this.templateModel1 = this.templateModelCopy1
      }
      if (num == 2) {
        this.sustomShow2 = false
        this.templateModel2 = this.templateModelCopy2
      }
      if (num == 3) {
        this.sustomShow3 = false
        this.templateModel3 = this.templateModelCopy3
      }
    },
    sureTemplate(num) {
      if (num === 1) {
        this.sustomShow1 = false
        this.drawAppRate()
      }
      if (num === 2) {
        this.sustomShow2 = false
        this.initScoreData()
      }
      if (num === 3) {
        this.sustomShow3 = false
        this.drawScoreChart()
      }
    },
    /*
     * 初始化数据
     * */
    // 头部模块数据初始化
    initEleData() {
      let url = qualityUrl + '/seatIndexPage/getRealTimeResult.do'
      let _this = this
      let params = {
        beginTime_Min: this.dateRange[0],
        beginTime_Max: this.dateRange[1],
        modelId: this.templateModel,
      }
      this.axios
        .post(url, Qs.stringify(params))
        .then(function(resp) {
          let res = resp.data
          _this.realEleData = res
        })
        .catch(function(e) {
          console.log(e)
        })
    },
    // 成绩区间占比
    drawAppRate() {
      let params = {
        beginTime_Min: this.dateRange[0],
        beginTime_Max: this.dateRange[1],
        modelId: this.templateModel1,
      }
      let _this = this
      let appRateOption = {
        color: colorList,
        title: {
          text: '成绩区间占比',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} ({d}%)',
          position: function(pos, params, el, elRect, size) {
            let obj = { top: 10 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30
            return obj
          },
        },
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow1 = true
                this.templateModelCopy1 = this.templateModel1
              },
            },
          },
        },
        series: {
          name: '数据分类：',
          type: 'pie',
          center: ['50%', '55%'],
          avoidLabelOverlap: false,
          label: {
            normal: {
              show: false,
              position: 'center',
            },
            emphasis: {
              show: false,
              textStyle: {
                fontSize: '30',
                fontWeight: 'bold',
              },
            },
          },
          labelLine: {
            normal: {
              show: false,
            },
          },
          data: [
            { value: 0, name: '未申诉' },
            { value: 0, name: '一次申诉' },
            { value: 0, name: '二次申诉' },
          ],
        },
      }
      this.axios
        .post(qualityUrl + '/seatIndexPage/getScoreRangePercent.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            appRateOption.series.data = res.data
            _this.drawEcharts('appRateQA', appRateOption)
          }
        })
    },
    // 成绩统计接口
    initScoreData() {
      let params = {
        beginTime_Min: this.dateRange[0],
        beginTime_Max: this.dateRange[1],
        modelId: this.templateModel2,
      }
      let _this = this
      this.axios
        .post(qualityUrl + '/seatIndexPage/scoreCount.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            _this.tableData = res.data.dataList
            _this.tableDataRadio = res.data.radio
          } else {
            _this.tableData = []
          }
        })
    },
    // 得分雷达图
    drawScoreChart() {
      let params = {
        beginTime_Min: this.dateRange[0],
        beginTime_Max: this.dateRange[1],
        modelId: this.templateModel3,
      }
      let _this = this
      let scoreOption = {
        color: colorList,
        title: {
          text: '得分雷达图',
          left: 0,
          top: 10,
          textStyle: {
            fontSize: 12,
            color: '#555',
            fontWeight: 400,
          },
        },
        legend: {
          data: ['你的得分情况', '团队得分情况'],
          bottom: 20,
        },
        radar: {
          name: {
            textStyle: {
              color: '#000',
            },
            formatter: (text) => {
                text = text.replace(/\S{3}/g, function(match) {
                    return match + '\n'
                })
                return text
            },
          },
          nameGap: 0,
          indicator: [],
        },
        tooltip: {},
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            myTool: {
              show: true,
              title: '自定义',
              icon: 'image://static/img/setIng.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.sustomShow3 = true
                this.templateModelCopy3 = this.templateModel3
              },
            },
          },
        },
        series: {
          type: 'radar',
          // areaStyle: {normal: {}},
          data: [],
        },
      }
      this.$nextTick(function() {
        this.axios
          .post(qualityUrl + '/seatIndex/getRadarMapData.do', Qs.stringify(params))
          .then(function(res) {
            if (res.data) {
              let data = []
              let legendArr = []
              let resData = res.data
              if (resData.seat && resData.seat.value && resData.seat.value.length) {
                data.push(resData.seat)
                legendArr.push(resData.seat.name)
              }
              if (resData.team && resData.team.value && resData.team.value.length) {
                data.push(resData.team)
                legendArr.push(resData.team.name)
              }
              scoreOption.series.data = data
              scoreOption.legend.data = legendArr
              scoreOption.radar.indicator = resData.normalData
              _this.drawEcharts('scoreResult', scoreOption)
            }
          })
      })
    },
    // 绘制echart
    drawEcharts(id, option) {
      document.getElementById(id).setAttribute('_echarts_instance_', '')
      let myChart = this.$echarts.init(document.getElementById(id))
      myChart.setOption(option)
    },
    initData() {
      this.initEleData()
      this.initChartData()
    },
  },
  mounted: function() {},
  created() {
    this.initDayTime()
    this.initData()
  },
}
</script>
<style lang="less">
.SeatHome {
  position: relative;
  border-top: 1px solid #dcdfe6;
  th {
    background-color: #e0e6ed;
    color: #475669;
    padding: 10px 0;
  }
  .echartWrap {
    div {
      overflow-x: auto !important;
    }
  }
}

.el-popover.el-popper.popperHover {
  border: none;
  background: none;
  box-shadow: none;
  color: #3b90bf;
  font-size: 12px;
  top: 385px !important;
  padding: 0;
  margin: 0;
  min-width: 50px;
  text-align: center;
  &.popperBeishensulv {
    text-align: right;
    margin-right: 13px;
  }
}

.tableDealog {
  .el-tabs__nav {
    margin-left: 10px;
  }
}

.tableDealog3 {
  .el-tabs__item {
    padding: 0 10px;
  }
  .el-radio + .el-radio {
    margin-left: 20px;
  }
}
</style>
<style lang="less" scoped>
.SeatHome {
  width: 100%;
  height: 100%;
  background: #fff;
  padding: 0 18px;
  box-sizing: border-box;
  .header {
    height: 80px;
    display: flex;
    flex-direction: row-reverse;
    align-items: center;
  }
  .content {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: calc(~'100% - 80px');
    .content-line {
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      justify-content: space-between;
      margin-bottom: 10px;
      &.content-line-top {
        height: 200px;
      }
      &.content-line-bottom {
        flex: 1;
      }
      .item {
        display: flex;
        flex-direction: column;
        box-sizing: border-box;
        border: 1px solid #ccc;
        overflow: auto;
        position: relative;
        .echartWrap {
          display: flex;
          flex: 1;
          justify-content: center;
          align-items: center;
          overflow: auto;
        }
        &.item1 {
          flex: 2;
        }
        &.item2 {
          margin: 0 10px;
          flex: 2;
        }
        &.item3 {
          flex: 2;
          margin-right: 10px;
        }
        &.item4 {
          flex: 3;
        }
        &.item5 {
          flex: 2;
        }
        &.item6 {
          flex: 3;
          margin: 0 10px;
          padding: 0 10px;
          .subTitle {
            margin: 20px 0 10px;
            font-size: 20px;
          }
          .toolBar {
            display: flex;
            height: 50px;
            flex-direction: row;
            justify-content: flex-start;
            align-items: center;
            .title {
              flex: 1;
              background: none;
              text-align: left;
            }
            .icon {
              width: 18px;
              height: 18px;
              cursor: pointer;
              margin-left: 5px;
            }
          }
        }
        &.item7 {
          flex: 3;
        }
        .title {
          height: 40px;
          line-height: 40px;
          text-align: center;
          background-color: #e8e8e8;
          &.title_sp {
            display: flex;
            .title_item {
              flex: 1;
              display: flex;
              align-items: center;
              justify-content: center;
            }
          }
        }
        .countRate {
          flex: 1;
          display: flex;
          flex-direction: row;
          justify-content: center;
          align-items: center;
          &.countRate_sp {
            display: flex;
            padding: 10px;
            .countRate_item {
              flex: 1;
              display: flex;
              justify-content: center;
              align-items: center;
              height: 100%;
              font-size: 18px;
              &.countRate_item_sp {
                border-right: 1px solid #555555;
              }
            }
          }
          .count {
            font-size: 48px;
            position: relative;
          }
          .rate {
            font-size: 18px;
            position: absolute;
            top: 0;
            left: 20px;
          }
        }
      }
    }
  }
}

.tableDealog {
  width: 98%;
  height: 240px;
  border: 1px solid #d1d9e2;
  border-radius: 4px;
  position: absolute;
  left: 1%;
  top: 2%;
  background: #fff;
  z-index: 1999;
  .aloneTitle {
    height: 45px;
    font-size: 14px;
    line-height: 45px;
    width: 100%;
    border-bottom: 1px solid #d1d9e2;
  }
  .aloneFooter {
    text-align: right;
    height: 45px;
    margin-top: 20px;
    padding-top: 5px;
    border-top: 1px solid #d1d9e2;
    line-height: 45px;
    &.aloneFooterS {
      margin-top: 10px;
    }
  }
}
</style>
