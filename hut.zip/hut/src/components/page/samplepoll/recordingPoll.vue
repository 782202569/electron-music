<template>
  <div class="recordingpollContainer">
    <el-row>
      <el-col :span="12" :class="hidden ? 'hidden' : ''">
        <div class="contentLeft">
          <div class="operation border_bottom">
            <div class="btns">
              <el-button class="btn_top" type="primary" @click="searchSampleButton"
                >筛选</el-button
              >
              <el-button class="btn_top" @click="resetFormEngine">重置</el-button>
            </div>
          </div>
          <div class="attrs customSample">
            <!--查询条件-->
            <h3>录音标签</h3>
            <el-form :model="modelPositive" ref="modelPositive" label-width="84px">
              <el-form-item label="情绪标签" prop="namePositiveId" clearable>
                <el-cascader
                  :options="optionss"
                  :clearable="true"
                  v-model="selectedOptions"
                  @change="handleChange"
                >
                </el-cascader>
              </el-form-item>
              <el-form-item label="关键词标签" prop="duration">
                <el-select
                  v-model="modelPositive.insertValue"
                  filterable
                  clearable
                  placeholder="请输入"
                  remote
                  :loading="loading"
                  :remote-method="remoteMethod"
                >
                  <el-option
                    v-for="item in positiveValue"
                    :key="item.value"
                    :label="item.label"
                    :value="item"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-form>
            <div style="border-top: 1px solid rgb(209, 219, 229);"></div>
            <!--查询标签条件-->
            <my-comp ref="myComp"></my-comp>
            <!--查询条件-->
          </div>
        </div>
      </el-col>
      <el-col :span="rightSpan">
        <div class="contentRight">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="operation">
            <div class="btns">
              <el-select
                v-model="displayType"
                @change="onDisplayTypeChange"
                class="btn_select"
              >
                <el-option
                  v-for="option in displayOptions"
                  :key="option.value"
                  :value="option.value"
                  :label="option.label"
                ></el-option>
              </el-select>

              <el-popover
                v-if="displayType != 1"
                placement="top"
                width="360"
                v-model="visible2"
                popper-class="my_popover"
              >
                <el-checkbox-group v-model="checkFieldList">
                  <el-checkbox
                    v-for="item in fieldList"
                    style="width: 30%"
                    :label="item.field"
                    :key="item.field"
                    :disabled="
                      item.field == 'callId' || item.field == 'callSTime' ? true : false
                    "
                    >{{ item.fieldName }}</el-checkbox
                  >
                </el-checkbox-group>
                <div style="text-align: right; margin: 0">
                  <el-button size="mini" type="text" @click="visible2 = false"
                    >取消</el-button
                  >
                  <el-button type="primary" size="mini" @click="checkFields"
                    >确定</el-button
                  >
                </div>
                <span class="show_fields" slot="reference">显示字段</span>
              </el-popover>
              <div style="display:inline-block;text-align:right;float:right;">
                <el-button funcId="000116" @click="distribution" class="btn"
                  >加入质检校准会</el-button
                >
                <el-button @click="exportOut" class="btn">导出</el-button>
              </div>
            </div>
          </div>
          <div class="attrs recordsList" v-if="displayType == 1">
            <el-checkbox-group v-model="checkedRecordList" v-if="recordsList.length > 0">
              <div
                :class="
                  hidden
                    ? 'recordDisplayBoxContainer_hidden'
                    : 'recordDisplayBoxContainer'
                "
                v-for="(item, index) in recordsList"
                :key="item.id"
              >
                <div class="recordDisplayBox">
                  <div class="recordDisplay_header">
                    <el-checkbox size="small" :label="item.callId"></el-checkbox>
                    <label
                      >录音编号：<span
                        @click="
                          showDetail(
                            item.callId,
                            item.isSampled,
                            item.callSTime,
                            item.callNo,
                            item.mblNo,
                            item.recordFileURL
                          )
                        "
                        class="callId"
                        >{{ item.callId }}</span
                      ></label
                    >
                    <label
                      >坐席姓名：<span>{{ item.seatName }}</span></label
                    >
                    <label
                      >录音时长：<span>{{ item.callTime | timeTransform }}</span></label
                    >
                    <label
                      >录音时间：<span :title="item.callSTime | createTimeFilter">{{
                        item.callSTime | createTimeFilter
                      }}</span></label
                    >
                    <div class="borderLeft">
                      <span v-if="item.labelContent != '' && item.labelContent != null">
                        <span
                          class="borderBlue"
                          v-for="(list, indexOne) in recordsList[
                            index
                          ].labelContent.split(',')"
                          :key="indexOne"
                          >{{ list }}</span
                        >
                      </span>
                      <!-- <span v-if="item.algLabelContent != ''" class="borderGreen" v-for='(list,indexTwo) in recordsList[index].algLabelContent.split(",")'>{{list}}</span> -->
                    </div>
                    <div class="borderRight">
                      <span
                        v-if="
                          item.emotionLabel != '' &&
                            item.emotionLabel != null &&
                            item.emotionLabel.indexOf('积极') != -1
                        "
                        class="borderPositive"
                        >{{ item.emotionLabel }}</span
                      >
                      <span
                        v-if="
                          item.emotionLabel != '' &&
                            item.emotionLabel != null &&
                            item.emotionLabel.indexOf('消极') != -1
                        "
                        class="borderNegative"
                        >{{ item.emotionLabel }}</span
                      >
                    </div>
                  </div>
                  <div
                    class="recordDisplay_content"
                    @mouseenter="showPlay(index)"
                    @mouseleave="hidePlay(index)"
                  >
                    {{ item.wholeContentAll }}
                    <div
                      class="play"
                      v-show="item.display"
                      @click="
                        showDetail(
                          item.callId,
                          item.isSampled,
                          item.callSTime,
                          item.callNo,
                          item.mblNo,
                          item.recordFileURL
                        )
                      "
                    >
                      <img src="../../../assets/img/u493.png" />
                    </div>
                  </div>
                </div>
              </div>
            </el-checkbox-group>
            <p v-else style="text-align: center;">暂无数据</p>
          </div>
          <div class="attrs recordsList recordsList_table" v-else>
            <el-table
              ref="recordsListTable"
              :data="recordsList"
              border
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column
                v-for="(field, index) in currentSelectFields"
                :key="index"
                :label="currentSelectFieldsName[index]"
                :prop="field"
                :width="
                  field == 'labelContent' ||
                  field == 'algLabelContent' ||
                  field == 'wholeContent' ||
                  field == 'keywordMark' ||
                  field == 'contentTime' ||
                  field == 'autoSummary' ||
                  field == 'personName' ||
                  field == 'placeName' ||
                  field == 'organization'
                    ? 150
                    : ''
                "
              >
                <template scope="scope">
                  <el-button
                    v-if="field == 'callId'"
                    type="text"
                    class="callId"
                    @click="
                      showDetail(
                        scope.row.callId,
                        scope.row.isSampled,
                        scope.row.callSTime,
                        scope.row.callNo,
                        scope.row.mblNo,
                        scope.row.recordFileURL
                      )
                    "
                    >{{ scope.row.callId }}
                  </el-button>
                  <AutoTooltip
                    effect="dark"
                    :content="formatFun(field, scope.row[field])"
                    v-else
                  >
                    {{ formatFun(field, scope.row[field]) }}
                  </AutoTooltip>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="page">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="pageSizes"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
      </el-col>
    </el-row>
    <!-- 分配质检员 -->
    <el-dialog
      title="分配质检员"
      :visible.sync="distributeInspectorVisible"
      :close-on-click-modal="false"
      :before-close="handleCloseDistributeInspector"
    >
      <div class="distributeInspectorFiled">
        <el-form
          :model="distributeInspectorModel"
          ref="distributeInspectorModel"
          label-width="100px"
        >
          <el-form-item label="质检模板" prop="templeateId" clearable>
            <el-select
              v-model="distributeInspectorModel.templeateId"
              placeholder="请选择"
            >
              <el-option
                v-for="item in templeateIds"
                :key="item.id"
                :label="item.modleTitle"
                :value="item.modleId"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="开始时间" prop="startTime">
            <el-date-picker
              v-model="distributeInspectorModel.startTime"
              type="datetime"
              :clearable="false"
              placeholder="选择日期时间"
            >
            </el-date-picker>
          </el-form-item>
          <el-form-item label="持续时间" prop="duration">
            <el-select
              v-model="distributeInspectorModel.duration"
              placeholder="请选择"
              clearable
            >
              <el-option label="一天" value="1"></el-option>
              <el-option label="二天" value="2"></el-option>
              <el-option label="三天" value="3"></el-option>
              <el-option label="四天" value="4"></el-option>
              <el-option label="五天" value="5"></el-option>
              <el-option label="六天" value="6"></el-option>
              <el-option label="七天" value="7"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="选择质检员" prop="qaUserIdsStr">
            <el-checkbox-group v-model="distributeInspectorModel.qaUserIdsStr">
              <el-checkbox :label="item.account" v-for="item in people" :key="item.id">{{
                item.realName
              }}</el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item>
            <div class="btns">
              <el-button @click="handleCloseDistributeInspector">取消</el-button>
              <el-button type="primary" @click="distributeInspector">确定</el-button>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </el-dialog>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import vue from 'vue'
import $ from 'jquery'
import qs from 'qs'
import moment from 'moment'
import formatDate from '../../../utils/formatdate.js'
import global from '../../../global.js'
import commonUtil from '../../../utils/commonUtil.js'
import nativeaxios from 'axios'
import cache from '../../../utils/cache.js'
import bus from '../../common/bus.js'
import recordingplay from '../recordingPlay/recordingPlayResultScore.vue'
import AutoTooltip from '../../common/AutoTooltip'
import myCompVue from './myComp.vue'
let formEngineUrl = global.formEngineUrl
let qualityUrl = global.qualityUrl
export default {
  components: {
    AutoTooltip,
    // 局部注册
    recordingplay,
    'my-comp': myCompVue,
  },
  data() {
    return {
      sList: [], // 录音列表
      displayType: '1',
      displayOptions: [
        {
          value: '1',
          label: '按详情展示',
        },
        {
          value: '2',
          label: '按数据展示',
        },
      ],
      currentPage: 1, // 当前页码
      total: 0, // 记录总条数
      pageSize: 20, // 每页显示的记录条数
      pageSizes: [10, 15, 20, 25],
      recordsList: [], // 录音列表
      checkedRecordList: [], // 选中的录音列表
      hidden: false, // 左侧部分是否隐藏
      currentSelectFields: [
        'callId',
        'callSTime',
        'callTime',
        'callNo',
        'seatName',
        'seatGroup',
        'keywordMark',
        'customerSex',
      ], // 当前用户选择的显示字段组,默认展示录音编号, 录音时间, 通话时长, 主叫号码, 坐席姓名, 坐席组
      currentSelectFieldsName: [
        '录音编号',
        '录音时间',
        '通话时长',
        '主叫号码',
        '坐席姓名',
        '坐席组',
        '关键词摘要',
        '客户性别',
      ], // 当前用户选择的显示字段组,默认展示录音编号, 录音时间, 通话时长, 主叫号码, 坐席姓名, 坐席组
      currentSelectFieldId: '', // 当前用户选择的显示字段id
      distributeInspectorVisible: false,
      distributeInspectorModel: {
        templeateId: '',
        startTime: '',
        duration: '',
        qaUserIdsStr: [],
      }, // 分配质检员表单
      people: [], // 质检员列表
      templeateIds: [], // 模板列表
      visible2: false,
      loading: false,
      checkFieldList: [
        'callId',
        'callSTime',
        'callTime',
        'callNo',
        'seatName',
        'seatGroup',
      ],
      modelPositive: {
        namePositiveId: '', // 情绪标签
        duration: '', // 业务标签
        insertValue: '', // 业务标签输入值
      },
      selectedOptions: [],
      emotionList: '', // 情绪标签ID
      optionss: [
        {
          value: '0',
          label: '全部',
          children: [
            {
              value: '0',
              label: '积极',
            },
            {
              value: '2',
              label: '消极',
            },
          ],
        },
        {
          value: '2',
          label: '坐席',
          children: [
            {
              value: '0',
              label: '积极',
            },
            {
              value: '2',
              label: '消极',
            },
          ],
        },
        {
          value: '1',
          label: '客户',
          children: [
            {
              value: '0',
              label: '积极',
            },
            {
              value: '2',
              label: '消极',
            },
          ],
        },
      ],
      groupData: [
        {
          id: 1,
          label: '全部',
          children: [
            {
              label: '积极',
              id: 11,
            },
            {
              label: '消极',
              id: 12,
            },
          ],
        },
        {
          label: '坐席',
          id: 3,
          children: [
            {
              label: '积极',
              id: 31,
            },
            {
              label: '消极',
              id: 32,
            },
          ],
        },
        {
          label: '客户',
          id: 5,
          children: [
            {
              label: '积极',
              id: 51,
            },
            {
              label: '消极',
              id: 52,
            },
          ],
        },
      ],
      groupProps: {
        children: 'children',
        label: 'label',
      },
      positiveChange: [
        {
          value: '0',
          label: '全部',
        },
        {
          value: '1',
          label: '关键词标签',
        },
        // {
        //   value: '2',
        //   label: '算法标签',
        // },
      ],
      positiveValue: [],
      list: [],
      states: [],
      fieldList: [
        {
          field: 'callId',
          fieldName: '录音编号',
        },
        {
          field: 'callSTime',
          fieldName: '录音时间',
        },
        {
          field: 'callTime',
          fieldName: '通话时长',
        },
        {
          field: 'labelContent',
          fieldName: '关键词标签',
        },
        {
          field: 'emotionLabel',
          fieldName: '情绪标签',
        },
        {
          field: 'callNo',
          fieldName: '主叫号码',
        },
        {
          field: 'seatName',
          fieldName: '坐席姓名',
        },
        {
          field: 'seatGroup',
          fieldName: '坐席组',
        },
        {
          field: 'calledNo',
          fieldName: '被叫号码',
        },
        {
          field: 'dataState',
          fieldName: '数据状态',
        },
        {
          field: 'seatNo',
          fieldName: '坐席工号',
        },
        {
          field: 'avgSpeed',
          fieldName: '平均语速',
        },
        {
          field: 'silencePer',
          fieldName: '静默占比',
        },
        {
          field: 'silenceLong',
          fieldName: '静默时长',
        },
        {
          field: 'silenceCount',
          fieldName: '静默次数',
        },
        {
          field: 'overLap',
          fieldName: '重叠次数',
        },
        {
          field: 'wholeContent',
          fieldName: '录音内容',
        },
        {
          field: 'customerSex',
          fieldName: '客户性别',
        },
        // {
        //   field: 'recordFileURL',
        //   fieldName: '录音播放地址',
        // },
      ],
      recordDialogVisible: false,
    }
  },
  filters: {
    timeTransform(val) {
      if (typeof val === 'undefined') {
        return '--'
      }
      let hours = parseInt((val % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      let minutes = parseInt((val % (1000 * 60 * 60)) / (1000 * 60))
      let seconds = ((val % (1000 * 60)) / 1000).toFixed(0)
      return (
        (hours > 0 ? hours + '时' : '') +
        (minutes > 0 ? minutes + '分' : '') +
        seconds +
        '秒'
      )
    },
    createTimeFilter(cellValue) {
      return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
    },
  },
  watch: {
    visible2(val) {
      if (!val) {
        this.checkFieldList = this.currentSelectFields
      }
    },
  },
  computed: {
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
  },
  created() {
    let _this = this
    bus.$on('searchData', function() {
      _this.searchSample()
    })
    this.recordPlayCloseHandler()
  },
  mounted() {
    this.searchSample()
    this.getLabel()
  },
  methods: {
    handleChange(value) {
      this.emotionList = value + ''
    },
    searchSample() {
      if (this.$refs.myComp) {
        this.getRecordsList()
      }
    },
    searchSampleButton() {
      this.currentPage = 1
      if (this.$refs.myComp) {
        this.getRecordsList()
      }
    },
    resetFormEngine() {
      this.$refs['modelPositive'].resetFields()
      this.modelPositive.insertValue = ''
      this.positiveValue = []
      this.selectedOptions = []
      this.emotionList = ''
      let form = this.$refs['myComp'].$refs[
        'recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Ref'
      ]
      form.resetFields()
      this.$refs[
        'myComp'
      ].recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.wholeContent_firstKey =
        ''
      this.$refs[
        'myComp'
      ].recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.wholeContent_firstLogic =
        ''
      this.$refs[
        'myComp'
      ].recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.wholeContent_secondKey =
        ''
      this.$refs[
        'myComp'
      ].recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.wholeContent_MidLogic =
        ''
      this.$refs[
        'myComp'
      ].recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.wholeContent_thirdKey =
        ''
      this.$refs[
        'myComp'
      ].recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.wholeContent_LastLogic =
        ''
      this.$refs[
        'myComp'
      ].recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.wholeContent_LastKey =
        ''
      this.getRecordsList()
    },
    handleParam(searchParam) {
      if (searchParam['silenceLong_Min']) {
        searchParam['silenceLong_Min'] = searchParam['silenceLong_Min'] * 1000
      }
      if (searchParam['silenceLong_Max']) {
        searchParam['silenceLong_Max'] = searchParam['silenceLong_Max'] * 1000
      }

      if (searchParam['silencePer_Min']) {
        searchParam['silencePer_Min'] = searchParam['silencePer_Min'] / 100
      }
      if (searchParam['silencePer_Max']) {
        searchParam['silencePer_Max'] = searchParam['silencePer_Max'] / 100
      }
      if (searchParam['timeType'] == 2) {
        if (searchParam['callTime_Min'] && searchParam['callTime_Max']) {
          searchParam['callTime_Min'] = searchParam['callTime_Min'] * 1000
          searchParam['callTime_Max'] = searchParam['callTime_Max'] * 1000
        }
      } else if (searchParam['timeType'] == 1) {
        if (searchParam['callTime_Min'] && searchParam['callTime_Max']) {
          searchParam['callTime_Min'] = searchParam['callTime_Min'] * 60 * 1000
          searchParam['callTime_Max'] = searchParam['callTime_Max'] * 60 * 1000
        }
      } else if (searchParam['timeType'] == 0) {
        if (searchParam['callTime_Min'] && searchParam['callTime_Max']) {
          searchParam['callTime_Min'] = searchParam['callTime_Min'] * 60 * 60 * 1000
          searchParam['callTime_Max'] = searchParam['callTime_Max'] * 60 * 60 * 1000
        }
      }
      if (searchParam['seatGroup']) {
        searchParam['deptId'] = searchParam['seatGroup']
        searchParam['seatGroup'] = ''
      }
    },
    getRecordsList() {
      // 查询之前先把选中的录音置空，防止干扰导出功能
      this.checkedRecordList.length = 0
      let _this = this
      let myComp = this.$refs.myComp
      let searchParam = {}
      searchParam.pageSize = this.pageSize
      searchParam.currentPage = this.currentPage
      searchParam.objectType = this.objectType
      searchParam.emotionType = this.emotionList
      searchParam.businessLabelType = 1
      searchParam.businessLabelId = this.modelPositive.insertValue.value
      searchParam.labelFrom = 1
      let obj = {}
      obj.searchModel = searchParam
      obj.searchModel.searchObj = myComp
        ? myComp.recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model
        : ''
      this.$store.commit('setRecordingPlayPage', obj)
      _this.getParams(
        searchParam,
        myComp.recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model
      )
      // 查询关键词要在播放器页高亮
      let keywordHighLight = [
        searchParam.wholeContent_firstKey,
        searchParam.wholeContent_secondKey,
        searchParam.wholeContent_thirdKey,
        searchParam.wholeContent_LastKey,
      ].join(' ')
      if (keywordHighLight.trim() != '' && keywordHighLight != null) {
        this.$store.commit('setKeywordsHigh', {
          keywords: keywordHighLight,
        })
      } else {
        this.$store.commit('setKeywordsHigh', null)
      }
      let keyword = ''
      keyword = _this.getKeyword(
        myComp.recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model
      )
      searchParam['wholeContent'] = keyword
      if (searchParam['callSTime_Min']) {
        searchParam['callSTime_Min'] = moment(searchParam['callSTime_Min']).format(
          'YYYY-MM-DD HH:mm:ss'
        )
      }
      if (searchParam['callSTime_Max']) {
        searchParam['callSTime_Max'] = moment(searchParam['callSTime_Max']).format(
          'YYYY-MM-DD HH:mm:ss'
        )
      }
      if (
        searchParam['callSTime_Min'] != undefined &&
        searchParam['callSTime_Min'] != ''
      ) {
        searchParam['callSTime_Min'] = formatDate.formatDate(searchParam['callSTime_Min'])
      } else {
        // 默认获取当前月的第一天
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        searchParam['callSTime_Min'] = formatDate.formatDate(now)
      }
      if (
        searchParam['callSTime_Max'] != undefined &&
        searchParam['callSTime_Max'] != ''
      ) {
        searchParam['callSTime_Max'] = formatDate.formatDate(searchParam['callSTime_Max'])
      } else {
        // 默认获取当前月的最后一天
        let now = new Date()
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        searchParam['callSTime_Max'] = formatDate.formatDate(
          new Date(nextMonthFirstDay - oneDay)
        )
      }
      this.handleParam(searchParam) // 处理查询参数
      if (searchParam['dataState'] == '' || searchParam['dataState'] == null) {
        // 数据状态默认值
        myComp.recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.dataState =
          '10'
      }
      myComp.recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.callSTime = [
        searchParam['callSTime_Min'],
        searchParam['callSTime_Max'],
      ]
      let url = qualityUrl + '/recordingPool/getAllRecord.do'
      this.axios
        .post(url, qs.stringify(searchParam))
        .then(function(response) {
          _this.recordsList = response.data.Data
          _this.currentSelectFields = response.data.fields || _this.currentSelectFields
          _this.currentSelectFieldsName =
            response.data.fieldsName || _this.currentSelectFieldsName
          _this.currentSelectFieldId = response.data.id
          _this.checkFieldList = response.data.fields || _this.checkFieldList
          _this.rightContent = 'records'
          _this.total = response.data.Count
          // 处理关键词展示，若用户在筛选条件里填写有关键词，table的column有关键词展示，则只显示命中的关键词
          _this.recordsList.forEach((item) => {
            item.wholeContentAll = item.wholeContent // 按详情展示时需要用到
            if (item.keywordMatching) {
              item.wholeContent = item.keywordMatching
            }
            item.display = false
          })
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '抽取样本出现问题',
          })
        })
    },
    getParams(param, formId) {
      for (let item in formId) {
        if (typeof formId[item] == 'string') {
          param[item] = formId[item]
        } else if (formId[item] instanceof Array) {
          if (formId[item].length == 2) {
            param[item + '_Min'] = formId[item][0]
            param[item + '_Max'] = formId[item][1]
          } else {
            param[item + '_Min'] = ''
            param[item + '_Max'] = ''
          }
        } else if (typeof formId[item] == 'object') {
          for (let jtm in formId[item]) {
            param[jtm] = formId[item][jtm]
          }
        }
      }
      return param
    },
    getKeyword(params) {
      let str = ''
      if (params['wholeContent_firstKey']) {
        if (params['wholeContent_firstLogic'] && params['wholeContent_secondKey']) {
          str += '('
        }
        str += params['wholeContent_firstKey'] + ' '
        if (params['wholeContent_firstLogic'] && params['wholeContent_secondKey']) {
          str +=
            params['wholeContent_firstLogic'] +
            ' ' +
            params['wholeContent_secondKey'] +
            ')'
          if (params['wholeContent_MidLogic']) {
            if (params['wholeContent_thirdKey']) {
              str += ' ' + params['wholeContent_MidLogic'] + ' '
              if (params['wholeContent_LastLogic'] && params['wholeContent_LastKey']) {
                str += '('
              }
              str += params['wholeContent_thirdKey'] + ' '
              if (params['wholeContent_LastLogic'] && params['wholeContent_LastKey']) {
                str +=
                  params['wholeContent_LastLogic'] +
                  ' ' +
                  params['wholeContent_LastKey'] +
                  ')'
              }
            }
          }
        }
      }
      if (str != '') {
        let Str = {}
        Str.keywords = str
        this.$store.commit('setKeywordsHigh', Str)
      } else {
        this.$store.commit('setKeywordsHigh', null)
      }
      return str
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.searchSample()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.searchSample()
    },
    exportOut() {
      if (this.checkedRecordList.length == 0) {
        // this.$message.warning('请至少选择一条录音进行导出!')
        // 未选中录音时，按照查询条件全部导出
        let myComp = this.$refs.myComp
        let searchParam = {}
        if (this.objectType) {
          searchParam.objectType = this.objectType
        }
        if (this.emotionList) {
          searchParam.emotionType = this.emotionList
        }
        searchParam.businessLabelType = 1
        if (this.modelPositive.insertValue.value) {
          searchParam.businessLabelId = this.modelPositive.insertValue.value
        }
        searchParam.labelFrom = 1
        this.getParams(
          searchParam,
          myComp.recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model
        )
        let keyword = this.getKeyword(
          myComp.recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model
        )
        searchParam['wholeContent'] = keyword
        if (searchParam['callSTime_Min']) {
          searchParam['callSTime_Min'] = moment(searchParam['callSTime_Min']).format(
            'YYYY-MM-DD HH:mm:ss'
          )
        }
        if (searchParam['callSTime_Max']) {
          searchParam['callSTime_Max'] = moment(searchParam['callSTime_Max']).format(
            'YYYY-MM-DD HH:mm:ss'
          )
        }
        if (
          searchParam['callSTime_Min'] != undefined &&
          searchParam['callSTime_Min'] != ''
        ) {
          searchParam['callSTime_Min'] = formatDate.formatDate(
            searchParam['callSTime_Min']
          )
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          searchParam['callSTime_Min'] = formatDate.formatDate(now)
        }
        if (
          searchParam['callSTime_Max'] != undefined &&
          searchParam['callSTime_Max'] != ''
        ) {
          searchParam['callSTime_Max'] = formatDate.formatDate(
            searchParam['callSTime_Max']
          )
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          searchParam['callSTime_Max'] = formatDate.formatDate(
            new Date(nextMonthFirstDay - oneDay)
          )
        }
        this.handleParam(searchParam) // 处理查询参数
        if (searchParam['dataState'] == '' || searchParam['dataState'] == null) {
          // 数据状态默认值
          myComp.recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.dataState =
            '10'
        }
        myComp.recordingPoolLuyin_recordingPoolYuangong_recordingPoolYuyin_recordingContent_Model.callSTime = [
          searchParam['callSTime_Min'],
          searchParam['callSTime_Max'],
        ]
        commonUtil.doExport(qualityUrl + '/recordingPool/exportRecords.do', searchParam)
      } else {
        let params = {
          callIds: this.checkedRecordList.join(','),
        }
        commonUtil.doExport(qualityUrl + '/recordingPool/exportRecords.do', params)
      }
    },
    onDisplayTypeChange(val) {
      this.checkedRecordList.length = 0
      this.currentPage = 1
    },
    toggleContainer() {
      this.hidden = !this.hidden
    },
    // 录音table中行的选中状态变化时触发(val为选中的object)
    handleSelectionChange(val) {
      this.checkedRecordList.length = 0
      let _this = this
      val.forEach(function(item) {
        _this.checkedRecordList.push(item.callId)
      })
    },
    formatFun(field, val) {
      if (field == 'callSTime') {
        return this.createTimeFilter(val)
      } else if (field == 'callTime' || field === 'silenceLong') {
        return this.convertCallTime(val)
      } else {
        return val
      }
    },
    // 转换表格中的时间
    createTimeFilter(cellValue) {
      return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
    },
    // 转换录音时长格式
    convertCallTime(callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '0') + '秒'
    },
    // 分配质检员
    distribution() {
      if (this.checkedRecordList.length < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择要分配的录音',
        })
        return false
      }
      if (this.checkedRecordList.length > 1) {
        this.$message.warning('只能选择一条录音加入校准会!')
        return
      }

      // 查询选择的录音是否加入质检校准会
      let url = qualityUrl + '/manualSampling/quryIsCommit.do'
      let params = {}
      let _this = this
      params.callId = this.checkedRecordList[0]
      this.axios.post(url, qs.stringify(params)).then(function(response) {
        if (response.data) {
          _this.$message.warning('此条录音已经加入校准会!')
        } else {
          _this.distributeInspectorVisible = true
          _this.resetForm('distributeInspectorModel')
          _this.getModleInfoByCondition()
          _this.distributeTask()
        }
      })
    },
    // 重置表单
    resetForm(formName) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[formName].resetFields()
      })
    },
    // 获取质检模板
    getModleInfoByCondition() {
      let _this = this
      let params = {}
      params.modleType = '7'
      params.bussinType = '12'
      let url = qualityUrl + '/manualQualityAssurance/getModleInfoByCondition.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.templeateIds = response.data.Data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检模板出现问题',
          })
        })
    },
    // 获取质检员方法
    distributeTask() {
      let _this = this
      let url = qualityUrl + '/distributeTask2.do'
      this.axios
        .post(url)
        .then(function(response) {
          _this.people = response.data.Data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检员列表出现问题',
          })
        })
    },
    // 关闭分配弹窗
    handleCloseDistributeInspector() {
      this.distributeInspectorVisible = false
    },
    checkFaq(){
      return new Promise((resolve,reject)=>{
        let idx = this.templeateIds.findIndex((item)=>{return item.modleId === this.distributeInspectorModel.templeateId})
        let updateTime = ''
        if(idx !== -1){
          updateTime = this.templeateIds[idx].updateTime
        }
        let params = {
          modleId:this.distributeInspectorModel.templeateId,
          updateTime:updateTime
        }
        this.axios
          .post(qualityUrl+'/manualQualityAssurance/getFaqCheckModel.do', qs.stringify(params))
          .then(function(response) {
            let {flag,data} =  response.data
            if (flag) {
              resolve('')
            } else {
              resolve(data)
            }
          })
          .catch((err)=>{reject(err)})
      })
    },
    // 给质检员分配任务
    distributeInspector() {
      let _this = this
      let params = {}
      if (this.distributeInspectorModel.qaUserIdsStr.length === 0) {
        this.$message.warning('请选择质检员进行分配!')
        return
      }
      params.duration = this.distributeInspectorModel.duration
      params.startTime = formatDate.formatDate(this.distributeInspectorModel.startTime)
      params.qaUserIdsStr = this.distributeInspectorModel.qaUserIdsStr.join(',')
      params.modleId = this.distributeInspectorModel.templeateId
      params.callId = this.checkedRecordList.join(',')

      if (commonUtil.isBlank(params['modleId'])) {
        this.$message.warning('请选择质检模板!')
        return
      }

      if (commonUtil.isBlank(params['duration'])) {
        this.$message.warning('请选择持续时间!')
        return
      }

      if (commonUtil.isBlank(params['startTime'])) {
        this.$message.warning('请选择开始时间!')
        return
      }

      let nowStr = moment(Date.now()).format('YYYY-MM-DD HH:mm:ss')
      if (nowStr > params['startTime']) {
        this.$message.warning('开始时间必须大于当前时间!')
        return
      }
      this.checkFaq().then((val)=>{
        if(val){
          this.$message.error(val)
          return
        }
        let url = qualityUrl + '/manualSampling/insertToCalibrate.do'
        this.axios
          .post(url, qs.stringify(params))
          .then(function(response) {
            if (response.data) {
              _this.$message({
                type: 'success',
                message: '任务已成功分配',
              })
              _this.distributeInspectorVisible = false
              _this.searchSample()
            } else {
              return Promise.reject()
            }
          })
          .catch(function() {
            _this.$message({
              type: 'error',
              message: '任务分配失败',
            })
          })
      })
    },
    // 点击确定保存选择字段
    checkFields(val) {
      let _this = this
      let fieldNames = []
      _this.checkFieldList.forEach(function(key) {
        _this.fieldList.forEach(function(item) {
          if (item.field == key) {
            fieldNames.push(item.fieldName)
          }
        })
      })
      let params = {}
      if (_this.currentSelectFieldId != undefined) {
        params.id = _this.currentSelectFieldId[0]
      }
      params.field = _this.checkFieldList.join(',')
      params.fieldName = fieldNames.join(',')
      _this.axios
        .post(qualityUrl + '/recordingPool/saveDisplayField.do', qs.stringify(params))
        .then(function(response) {
          _this.visible2 = false
          _this.searchSample()
        })
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    remoteMethod(query) {
      if (query !== '') {
        this.loading = true
        setTimeout(() => {
          this.loading = false
          const res = new Map()
          this.positiveValue = this.list.filter((item) => {
            return (
              !res.has(item.label) &&
              res.set(item.label, 1) &&
              item.label.toLowerCase().indexOf(query.toLowerCase()) > -1
            )
          })
        }, 200)
      } else {
        this.positiveValue = []
      }
    },
    getLabel: function() {
      let _this = this
      let params = {}
      params.businessLabelType = 1
      _this.axios
        .post(qualityUrl + '/recordingPool/getLabel.do', qs.stringify(params))
        .then(function(response) {
          _this.states = response.data
          _this.list = _this.states.map((item) => {
            return { value: item.key, label: item.name, from: item.from }
          })
        })
    },
    // 调到录音播放页
    showDetail(id, isSampled, callSTime, callNo, mblNo, recordFileURL) {
      let obj = {}
      obj.from = 'recordingpoll'
      obj.callId = id
      obj.isSampled = isSampled
      obj.callSTime = callSTime
      obj.mblNo = mblNo ? mblNo : ''
      obj.callNo = callNo ? callNo : ''
      obj.recordFileURL = recordFileURL ? recordFileURL : ''
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 鼠标放到录音内容上时展示播放按钮
    showPlay(index) {
      this.recordsList[index].display = true
      this.$forceUpdate()
    },
    // 鼠标移出录音内容上时展示播放按钮
    hidePlay(index) {
      this.recordsList[index].display = false
      this.$forceUpdate()
    },
  },
}
</script>
<style lang="less" scoped>
@border-color: #d1dbe5;
.recordingpollContainer {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
  overflow-x: hidden;
  .operation {
    box-sizing: border-box;
    height: 60px;
    line-height: 60px;
    position: absolute;
    top: 0px;
    left: 0px;
    right: 0px;
    padding: 0 23px;
    .btn_top {
      height: 36px;
      width: 88px;
    }
    .btn {
      height: 36px;
    }
    .btn_select {
      height: 36px;
      width: 130px;
    }
  }
  .border_bottom {
    border-bottom: 1px solid @border-color;
  }
  .contentLeft,
  .contentRight {
    border-right: 1px solid @border-color;
    height: 100%;
    width: 100%;
    position: relative;
    .attrs {
      position: absolute;
      top: 60px;
      right: 0px;
      left: 0px;
      bottom: 0px;
      overflow-y: auto;
    }
  }
  .contentLeft {
    .customSample {
      padding: 0 23px;
    }
  }
  .contentRight {
    .toggleBtn {
      cursor: pointer;
      width: 20px;
      height: 30px;
      background-image: url('../../../assets/img/close.png');
      position: absolute;
      left: -20px;
      top: 45%;
      bottom: 0px;
      z-index: 999;
    }
    .toggle-hidden {
      left: 0px;
      transform: rotate(180deg);
    }
    .show_fields {
      color: #20a0ff;
      cursor: pointer;
      margin: 0 20px;
    }
    .recordsList {
      margin: 0 23px 50px;
    }
    .page {
      position: absolute;
      left: 23px;
      right: 23px;
      bottom: 0px;
      text-align: right;
      height: 50px;
      box-sizing: border-box;
      padding-top: 10px;
      .el-pagination {
        display: inline-block;
        height: 30px;
        overflow: hidden;
      }
    }
  }
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
}
</style>
<style lang="less">
@border-color: #d1dbe5;
.recordingpollContainer {
  .el-row {
    height: 100%;
    .el-col {
      height: 100%;
    }
    .hidden {
      display: none;
    }
    .btn_select {
      .el-input__inner {
        height: 36px;
        line-height: 36px;
      }
    }
  }
  .attrs {
    h3 {
      line-height: 30px;
      font-size: 14px;
      color: #9dadc2;
      font-weight: normal;
    }
    .el-form {
      .el-row:last-child {
        border: none !important;
      }
    }
  }
  .contentRight {
    .recordsList {
      table th {
        background-color: #e0e6ed;
        color: #475669;
        padding: 10px 0;
      }
      .el-checkbox-group {
        display: flex;
        flex-wrap: wrap;
        padding-top: 10px;
        font-size: 12px;
      }
      .recordDisplayBoxContainer {
        box-sizing: border-box;
        width: 100%;
        // padding: 0px 10px;
      }
      .recordDisplayBox {
        position: relative;
        border: 1px solid @border-color;
        width: 100%;
        margin-bottom: 10px;
        height: 180px;
        box-sizing: border-box;
        & > div {
          padding: 0px 10px;
        }
        .recordDisplay_header {
          height: 85px;
          line-height: 45px;
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          font-weight: bold;
          background: #eff2f7;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          .borderLeft {
            height: 30px;
            line-height: 30px;
            float: left;
            width: 80%;
            overflow: hidden;
            .borderBlue {
              margin-left: 10px;
              display: inline-block;
              color: #1791ec;
              text-align: center;
              line-height: 12px;
              border-radius: 4px;
              border: 1px solid #9ed9f3;
              padding: 4px 10px;
              color: #1791ec;
              height: 12px;
              background: #d7eeff;
              font-size: 12px;
            }
            .borderGreen {
              margin-left: 10px;
              display: inline-block;
              color: #1791ec;
              text-align: center;
              line-height: 12px;
              border-radius: 4px;
              border: 1px solid #6bdec4;
              padding: 4px 10px;
              color: #12a080;
              height: 12px;
              background: #caf7ed;
              font-size: 12px;
            }
          }
          .borderRight {
            width: 20%;
            float: right;
            text-align: right;
            display: inline-block;
            height: 30px;
            line-height: 30px;
            .borderPositive {
              display: inline-block;
              font-size: 12px;
              margin-right: 10px;
              color: #12a080;
              text-align: center;
              line-height: 12px;
              border-radius: 4px;
              border: 1px solid #12a037;
              padding: 4px 10px;
              height: 12px;
              padding: 4px 10px;
              color: #12a037;
            }
            .borderNegative {
              display: inline-block;
              font-size: 12px;
              margin-right: 10px;
              color: #12a080;
              text-align: center;
              line-height: 12px;
              border-radius: 4px;
              border: 1px solid #ff0000;
              padding: 4px 10px;
              height: 12px;
              padding: 4px 10px;
              color: #ff0000;
            }
          }
          & > span {
            margin-left: 10px;
            vertical-align: middle;
            font-size: 12px;
            color: #475669;
          }
          & > label {
            vertical-align: middle;
            margin-right: 10px;
            span.el-checkbox__label {
              display: none;
            }
          }
        }
        .recordDisplay_content {
          position: absolute;
          top: 85px;
          left: 0;
          right: 0;
          bottom: 0;
          overflow: hidden;
          font-size: 12px;
          padding: 5px;
          &:hover {
            cursor: pointer;
          }
          .play {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 10;
            background: rgba(00, 00, 00, 0.4);
            text-align: center;
            line-height: 145px;
            img {
              display: inline;
              width: 51px;
              height: 51px;
            }
          }
        }
      }
      .recordDisplayBoxContainer_hidden {
        width: 50%;
        margin: 0px;
        box-sizing: border-box;
        padding-bottom: 10px;
        &:nth-child(2n + 1) {
          padding-left: 10px;
          padding-right: 5px;
        }
        &:nth-child(2n) {
          padding-right: 10px;
          padding-left: 5px;
        }
        .recordDisplayBox {
          margin: 0px;
        }
      }
    }
  }
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 0px 0px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
}
.my_popover {
  .el-checkbox {
    margin-left: 30px;
  }
}
#treePtionabc {
  min-height: 200px;
  .el-select-dropdown__item {
    padding: 0;
    overflow: visible;
  }
}
</style>
