<template>
  <div id="reconsiderTask" class="reconsiderTask">
    <div class="header">
      <div class="title">复议任务</div>
    </div>
    <div class="rightContent">
      <div class="tableBox">
        <div class="table">
          <el-tabs v-model="activeName" @tab-click="handleChangeTab">
            <el-tab-pane label="未完成" name="1">
              <el-table
                :data="tableData"
                border
                highlight-current-row
                style="width: 100%"
              >
                <el-table-column fixed="left" prop="callId" label="录音编号">
                  <template scope="scope">
                    <el-button
                      type="text"
                      @click="
                        showDetail(
                          scope.row.callId,
                          scope.row.taskId,
                          scope.row.finalTime,
                          scope.row.apType,
                          scope.row.isQaScore,
                          scope.row.isCreator,
                          scope.row.ifReviewProcess,
                          scope.row.recordFileURL
                        )
                      "
                    >
                      {{ scope.row.callId }}
                    </el-button>
                  </template>
                </el-table-column>
                <el-table-column prop="seatNo" label="坐席姓名"> </el-table-column>
                <el-table-column prop="createUser" label="分配人"> </el-table-column>
                <el-table-column
                  prop="assignTime"
                  :formatter="dateFormat"
                  label="分配时间"
                >
                </el-table-column>
                <el-table-column
                  prop="finalTime"
                  :formatter="dateFormat"
                  label="任务截止时间"
                >
                </el-table-column>
                <el-table-column prop="score" label="质检结果"> </el-table-column>
                <el-table-column prop="assignType" label="复议状态">
                  <template scope="scope">
                    <div v-if="scope.row.apType === 1">
                      <el-tag type="success">一次复议</el-tag>
                    </div>
                    <div v-if="scope.row.apType === 2">
                      <el-tag type="primary">二次复议</el-tag>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column prop="score" label="操作">
                  <template scope="scope">
                    <div v-if="scope.row.isQaScore == false">
                      <el-button
                        type="text"
                        @click="
                          showDetail(
                            scope.row.callId,
                            scope.row.taskId,
                            scope.row.finalTime,
                            scope.row.apType,
                            scope.row.isQaScore,
                            scope.row.isCreator,
                            scope.row.ifReviewProcess,
                            scope.row.recordFileURL
                          )
                        "
                        >打分</el-button
                      >
                    </div>
                  </template>
                </el-table-column>
              </el-table>
            </el-tab-pane>
            <el-tab-pane label="已完成" name="2">
              <el-table
                :data="tableData"
                border
                highlight-current-row
                style="width: 100%"
              >
                <el-table-column fixed="left" prop="callId" label="录音编号">
                  <template scope="scope">
                    <el-button
                      type="text"
                      @click="
                        showDetail(
                          scope.row.callId,
                          scope.row.taskId,
                          scope.row.finalTime,
                          scope.row.apType,
                          scope.row.isQaScore,
                          scope.row.isCreator,
                          scope.row.ifReviewProcess,
                          scope.row.assignType,
                          scope.row.recordFileURL
                        )
                      "
                    >
                      {{ scope.row.callId }}
                    </el-button>
                  </template>
                </el-table-column>
                <el-table-column prop="seatNo" label="坐席姓名"> </el-table-column>
                <el-table-column prop="createUser" label="分配人"> </el-table-column>
                <el-table-column
                  prop="assignTime"
                  :formatter="dateFormat"
                  label="分配时间"
                >
                </el-table-column>
                <el-table-column
                  prop="finalTime"
                  :formatter="dateFormat"
                  label="任务截止时间"
                >
                </el-table-column>
                <el-table-column prop="score" label="质检结果"> </el-table-column>
                <el-table-column prop="apType" label="申诉状态">
                  <template scope="scope">
                    <div v-if="scope.row.apType === 1">
                      <el-tag type="success">一次申诉</el-tag>
                    </div>
                    <div v-if="scope.row.apType === 2">
                      <el-tag type="primary">二次申诉</el-tag>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column prop="score" label="操作">
                  <template scope="scope">
                    <el-button
                      funcId="000344"
                      type="text"
                      @click="
                        showDetail(
                          scope.row.callId,
                          scope.row.taskId,
                          scope.row.finalTime,
                          scope.row.apType,
                          scope.row.isQaScore,
                          scope.row.isCreator,
                          scope.row.ifReviewProcess,
                          scope.row.assignType,
                          scope.row.recordFileURL
                        )
                      "
                      >查看</el-button
                    >
                  </template>
                </el-table-column>
              </el-table>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
      <div class="autoGrading-page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageindex"
          :page-sizes="[20, 30, 40]"
          :page-size="pagesize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="totalCount"
        >
        </el-pagination>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import axios from 'axios'
import Qs from 'qs'
import global from '../../../global.js'
axios.defaults.withCredentials = true
axios.defaults.headers = {
  'Content-Type': 'application/x-www-form-urlencoded ;charset=UTF-8',
}
let qualityUrl = global.qualityUrl
import formatdate from '../../../utils/formatdate.js'
import vPlayer from '../../common/player.vue'
import recordingplay from '../recordingPlay/recordingPlayMultiple.vue'
import bus from '../../common/bus.js'
export default {
  components: {
    vPlayer,
    recordingplay,
  },
  data() {
    return {
      recordDialogVisible: false,
      labelPosition: 'right',
      tableData: [],
      pageindex: 1,
      pagesize: 10,
      totalCount: 0,
      activeName: '1',
      reconStatus: 2,
    }
  },
  created() {
    this.recordPlayCloseHandler()
    this.initData()
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
  methods: {
    initList: function() {
      this.initData()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
      this.initData()
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 录音播放页面 点击最小化触发
    toMinDialog: function(playInfo) {
      if (playInfo.isMaximization === false) {
        this.showVplayer = false
        let play = {}
        play.isMaximization = false
        play.exist = true
        this.$store.commit('setPlayerInfo', play)
      }
    },
    showDetail(id, taskId, finalTime, apType, isQaScore, isCreator, ifReviewProcess, assignType, recordFileURL) {
      let obj = {}
      obj.from = 'myQaTasks_reconsider'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      obj.taskId = taskId
      obj.playType = ifReviewProcess // 判断是否有复检流程 0表示没有，1表示有
      if (apType == 1) {
        obj.qaScoreType = 3
      } else if (apType == 2) {
        obj.qaScoreType = 4
      }
      // activeName =1，未完成，apType复议（1：一次复议，2：二次复议）
      // activeName = 2，已完成时，apType 申诉状态（1：一次申诉，2：二次申诉），assignType：复议（1：一次复议，2：二次复议），故在已完成时若复议状态和申诉状态不一致要把复议状态传过去
      if (this.activeName == 2 && apType != assignType) {
        apType = assignType
      }
      if (this.activeName == 2) {
        // 已完成，都表示已复议打分
        isQaScore = true
      }
      obj.FuyiTask_EndTime = finalTime
      obj.assignType = apType
      obj.isQaScore = isQaScore
      obj.isCreator = isCreator
      console.info(
        '111111111111isQaScore =' + isQaScore + '   activeName=' + this.activeName
      )
      console.info(obj)
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlay')
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    initData: function() {
      let self = this
      let params = {
        reconStatus: this.reconStatus,
      }
      this.axios
        .post(
          qualityUrl +
            '/taskManage/searchReTask.do?pagesize=' +
            this.pagesize +
            '&pageindex=' +
            this.pageindex,
          Qs.stringify(params)
        )
        .then(function(response) {
          self.totalCount = response.data.Count
          self.tableData = response.data.TapInfo
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '任务获取失败',
          })
        })
      this.moreChance = false
    },
    handleChangeTab(tab) {
      let val = tab.name
      if (val === '1') {
        this.reconStatus = 2
        this.initData()
      } else {
        this.reconStatus = 1
        this.initData()
      }
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
    },
  },
}
</script>
<style lang="less">
.reconsiderTask {
  .operation {
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
  .el-dialog__wrapper.single {
    position: fixed;
    top: 106px;
    left: 20px;
    right: 20px;
    bottom: 12px;
    .el-dialog {
      width: 100%;
      height: 100%;
      margin: 0 !important;
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
  .table {
    .el-tabs__item {
      padding: 0;
      margin: 0 20px;
      &.is-active {
        border-bottom: 4px solid #409eff;
      }
    }
  }
}
</style>
<style scoped="scoped" lang="less">
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}

.reconsiderTask {
  overflow: hidden;
  height: 100%;
  position: relative;
  .header {
    display: flex;
    height: 50px;
    align-items: center;
    padding: 0 20px;
    box-sizing: border-box;
    .title {
      display: flex;
      flex: 1;
      font-size: 14px;
    }
  }
  .rightContent {
    padding: 0 0 97px;
    box-sizing: border-box;
    height: 100%;
    width: 100%;
    .tableBox {
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      overflow-y: auto;
      .table {
        padding: 0 20px;
        box-sizing: border-box;
        width: 100%;
        height: 100%;
      }
    }
    .autoGrading-page {
      right: 10px;
      position: absolute;
      bottom: 10px;
    }
  }
  .toggle-show {
    position: absolute;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggleBtn {
    cursor: pointer;
    width: 20px;
    height: 30px;
    background-image: url('../../../assets/img/close.png');
    position: absolute;
    left: -20px;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggle-hidden {
    left: 0px;
    transform: rotate(180deg);
  }
}

#reconsiderTask div {
  box-sizing: border-box;
}

#reconsiderTask {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
}
</style>
