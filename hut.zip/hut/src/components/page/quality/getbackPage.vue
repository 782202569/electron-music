<template>
  <div class="goBackmessage">
    <div class="backPage"><span @click="getbackNow">< 返回</span></div>
    <div class="cellLeft cellValue">{{ message }}</div>
    <div class="cellRight">
      <el-form ref="namesForm" label-width="30px" :inline="true">
        <el-form-item prop="name" style="margin-right: 0px;">
          <el-button @click="exportData">导出</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="content">
      <div class="table">
        <div class="tableCell">
          <el-table
            ref="loopTaskTable"
            :data="sysAutoScoringList"
            border
            tooltip-effect="dark"
          >
            <el-table-column prop="objectId" label="录音编号">
              <template scope="scope">
                <span
                  style="color:#20a0ff;cursor: pointer"
                  type="text"
                  @click="showDetail(scope.row.objectId, scope.row.recordFileURL)"
                  >{{ scope.row.objectId }}</span
                >
              </template>
            </el-table-column>
            <el-table-column prop="seatName" label="坐席姓名" width="160">
            </el-table-column>
            <el-table-column
              prop="callTime"
              label="通话时长"
              :formatter="convertCallTime"
            >
            </el-table-column>
            <el-table-column prop="score" label="自动评分分数" :formatter="convertScore">
            </el-table-column>
            <el-table-column prop="createTime" label="质检时间"> </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <div class="sysAutoScoringInCallResult-page">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="singleWrap"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import global from '../../../global.js'
import Qs from 'qs'
import bus from '../../common/bus.js'
import recordingplay from '../recordingPlay/recordingPlayResultScore.vue'
let currentBaseUrl = global.qualityUrl
export default {
  components: {
    recordingplay,
  },
  props: ['message'],
  data() {
    return {
      valye: true,
      sysAutoScoringList: [], // 循环任务查询结果
      currentPage: 1,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
      tableData: [],
      recordDialogVisible: false,
      vauleSize: this.setStrategy,
      cc: '',
    }
  },
  methods: {
    getbackNow: function() {
      // this.$router.push('/qaTask')
      this.$emit('sendTill', true)
    },
    convertCallTime(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    convertScore(x, y, score) {
      let needConvert = score && score != 'null'
      return needConvert ? parseFloat(score).toFixed(0) : ''
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.selectRobertProjectDetail()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.selectRobertProjectDetail()
    },
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.pageId = 'sysAutoScoringInCallResult'
      obj.from = 'sysAutoScoringInCallResult'
      obj.objectId = id
      obj.callId = id
      obj.recordFileURL = recordFileURL
      obj.taskId = this.recordingPlayPage.taskId
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 关闭录音弹窗
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 查询循环任务
    selectRobertProjectDetail() {
      let params = {
        robertProjectId: this.robertProjectId,
        pageNumber: this.currentPage,
        pageSize: this.pageSize,
      }
      let self = this
      this.axios
        .post(
          currentBaseUrl + '/ascorec/selectRobertProjectDetail.do',
          Qs.stringify(params)
        )
        .then(function(response) {
          self.total = response.data.Count
          self.sysAutoScoringList = response.data.List
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 导出
    exportData() {
      let params = {}
      params.robertProjectId = this.robertProjectId
      params.accessToken = localStorage.getItem('tgt_id')
      params.pageSize = this.pageSize
      params.pageNumber = this.currentPage
      let form = document.createElement('form')
      form.method = 'post'
      form.target = '_blank'
      for (let key in params) {
        let input = document.createElement('input')
        input.name = key
        input.value = params[key]
        form.appendChild(input)
      }
      form.action =
        currentBaseUrl +
        '/ascorec/exportAutoScoreResult.do?accessToken=' +
        localStorage.getItem('tgt_id')
      document.querySelector('body').appendChild(form)
      form.submit()
      document.querySelector('body').removeChild(form)
    },
  },
  mounted() {
    this.selectRobertProjectDetail()
  },
  computed: {
    robertProjectId() {
      return this.$store.state.Strategy.strategyId
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
  watch: {
    currentPage() {
      this.selectRobertProjectDetail()
    },
    pageSize() {
      this.selectRobertProjectDetail()
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.goBackmessage {
  overflow: hidden;
  height: 100%;
  position: relative;
  .backPage {
    color: #20a0ff;
    padding: 19px 0 10px 18px;
    span {
      cursor: pointer;
    }
  }
  .content {
    padding-bottom: 150px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .sysAutoScoringInCallResult-page {
    right: 10px;
    position: absolute;
    bottom: 10px;
  }
  .table {
    width: 100%;
    height: 100%;
    overflow: auto;
  }
  .cellLeft {
    display: inline-block;
    padding: 10px 0 30px 19px;
    font-size: 14px;
    color: #1f2d3d;
  }
  .cellRight {
    display: inline-block;
    float: right;
    padding-right: 31px;
    .el-button {
      color: #475669;
      width: 88px;
      padding: 10px 16px 10px 16px;
    }
  }
}
.autoGrading-page {
  right: 10px;
  position: absolute;
  bottom: 10px;
}
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
</style>
<style lang="less">
.tableCell {
  padding-left: 19px;
  padding-right: 30px;
  table th {
    background-color: #e0e6ed;
    color: #475669;
    padding: 10px 0;
  }
}
.el-dialog__wrapper.singleWrap {
  position: fixed;
  top: 106px;
  left: 20px;
  right: 20px;
  bottom: 12px;
  .el-dialog {
    width: 100%;
    height: 100%;
    margin: 0 !important;
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}

.el-button.goback-btn {
  padding: 0;
  margin: 0;
  border: none;
  font-size: 14px;
  color: #20a0ff;
}
</style>
