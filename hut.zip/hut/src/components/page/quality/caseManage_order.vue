<template>
  <div class="caseManage" id="caseManage">
    <div class="caseHeader">
      <ul>
        <li class="active" id="audited" @click="changeTab">已审核</li>
        <li id="notAudited" @click="changeTabNot">未审核</li>
      </ul>
    </div>
    <div class="caseContent">
      <div class="caseLeft">
        <div class="item">
          <a>
            <el-button
              v-show="isShowplus"
              icon="el-icon-plus"
              @click="addTreeNode"
            ></el-button>
            <el-button
              v-show="isShowedit"
              icon="el-icon-edit"
              @click="editTreeNode"
            ></el-button>
            <el-button
              v-show="isShowclose"
              icon="el-icon-close"
              @click="deleteTreeNode"
            ></el-button>
          </a>
        </div>
        <el-dialog title="新增分类" :visible.sync="addTreeNodeModel">
          <el-form
            :model="addTreeNodeForm"
            ref="addTreeNodeForm"
            :rules="addTreeNodeRules"
            label-width="100px"
          >
            <el-form-item label="当前类别" prop="typeid">
              <el-input
                style="width:220px"
                :disabled="true"
                v-model="addTreeNodeForm.typeid"
              ></el-input>
            </el-form-item>
            <el-form-item label="类别名称" prop="className">
              <el-input
                style="width:220px"
                v-model="addTreeNodeForm.className"
              ></el-input>
            </el-form-item>
            <el-form-item label="备注" prop="remark">
              <el-input style="width:220px" v-model="addTreeNodeForm.remark"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelAddTreeNode">取 消</el-button>
            <el-button type="primary" @click="saveTreeNodeThrottle">确 定</el-button>
          </div>
        </el-dialog>
        <el-dialog title="编辑分类" :visible.sync="editTreeNodeModel">
          <el-form
            :model="editTreeNodeForm"
            ref="editTreeNodeForm"
            :rules="addTreeNodeRules"
            label-width="100px"
          >
            <el-form-item label="当前类别" prop="typeid">
              <el-input
                style="width:220px"
                :disabled="true"
                v-model="editTreeNodeForm.typeid"
              ></el-input>
            </el-form-item>
            <el-form-item label="类别名称" prop="className">
              <el-input
                style="width:220px"
                v-model="editTreeNodeForm.className"
              ></el-input>
            </el-form-item>
            <el-form-item label="备注" prop="remark">
              <el-input style="width:220px" v-model="editTreeNodeForm.remark"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="cancelEdit">取 消</el-button>
            <el-button type="primary" @click="editTreeNodeYesThrottle">确 定</el-button>
          </div>
        </el-dialog>
        <div class="tree">
          <el-tree
            :current-node-key="nodeKeyName"
            :data="treedata"
            :props="defaultProps"
            highlight-current
            :expand-on-click-node="false"
            @node-click="clickOneNode"
            node-key="id"
            default-expand-all
          >
          </el-tree>
        </div>
      </div>
      <div class="caseRight">
        <div class="container" id="container">
          <div class="act-head">
            <el-form ref="namesForm" :model="namesForm" label-width="80px">
              <el-form-item prop="name">
                <el-input
                  v-model="namesForm.name"
                  placeholder="请输入订单编号"
                  style="width: 160px"
                ></el-input>
                <el-button type="primary" style="margin-left: 10px" @click="searchById"
                  >查询</el-button
                >
                <el-button
                  v-show="isShowdelby"
                  style="margin-left: 10px"
                  @click="deleteCaseMore"
                  >批量删除</el-button
                >
              </el-form-item>
            </el-form>
          </div>
          <div class="content">
            <div class="table">
              <div style="padding-left: 10px">
                <el-table
                  border
                  ref="multipleTable"
                  :data="tableData"
                  @select-all="selectAll"
                  @select="selectAll"
                  @row-click="rowClickTable"
                  style=""
                >
                  <el-table-column type="selection" width="50"> </el-table-column>
                  <el-table-column type="index" label="序号" width="60">
                  </el-table-column>
                  <el-table-column prop="orderNo" label="订单编号">
                    <template scope="scope">
                      <el-button type="text" @click="jumpToSound(scope.row.orderNo, scope.row.recordFileURL)">{{
                        scope.row.orderNo
                      }}</el-button>
                    </template>
                  </el-table-column>
                  <!-- <el-table-column
                    prop="seatName"
                    label="坐席姓名">
                  </el-table-column> -->
                  <el-table-column
                    prop="createTime"
                    :formatter="dateFormat"
                    label="订单时间"
                    sortable
                  >
                  </el-table-column>
                  <el-table-column prop="caseRemark" label="案例理由"> </el-table-column>
                  <el-table-column prop="reReason" label="拒绝理由"> </el-table-column>
                  <el-table-column prop="caseFlag" label="状态">
                    <template scope="scope">
                      <div v-if="scope.row.caseFlag === 2">
                        <el-tag type="success">已审核</el-tag>
                      </div>
                      <div v-else>
                        <el-tag type="danger">已拒绝</el-tag>
                      </div>
                    </template>
                  </el-table-column>

                  <el-table-column prop="applyPersonName" label="申请人">
                  </el-table-column>
                  <el-table-column label="操作" width="200">
                    <template scope="scope">
                      <div style="cursor: pointer;">
                        <i
                          v-show="isShowdelete"
                          class="el-icon-close"
                          @click="deleteCase(scope.row.caseId, scope.row.orderNo)"
                          style="font-size: 12px; margin-right: 10px;"
                          ><i style="font-size: 14px; padding-left: 3px">删除</i></i
                        >
                        <i
                          v-show="isShoweditCase"
                          class="el-icon-edit"
                          @click="editCase"
                          style="font-size: 12px;"
                          ><i style="font-size: 14px; padding-left: 3px">编辑</i></i
                        >
                        <i
                          v-show="isShowLook"
                          class="iconfont icon-chakan"
                          @click="jumpToSound(scope.row.orderNo, scope.row.recordFileURL)"
                          style=" margin-left: 10px;"
                          ><i style="font-size: 14px; padding-left: 3px">查看</i></i
                        >
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
                <el-dialog title="编辑案例" :visible.sync="editCaseModel">
                  <div class="editcase" style="width:100%;overflow: hidden;">
                    <div
                      style="float: left;width: 30%; height:320px;border: 1px solid #d1dbe5"
                    >
                      <el-tree
                        :current-node-key="nodeKeyNameEdit"
                        check-strictly
                        :data="treedataNot"
                        node-key="id"
                        :props="defaultProps"
                        @check-change="checkChange"
                        highlight-current
                        :expand-on-click-node="false"
                        @node-click="clickOneNodeModel"
                        ref="edittree"
                        default-expand-all
                      >
                      </el-tree>
                    </div>
                    <div
                      style="float: right;width: 68%;height:320px;border: 1px solid #d1dbe5"
                    >
                      <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">
                        申请理由
                      </div>
                      <el-input
                        type="textarea"
                        v-model="remark"
                        :rows="10"
                        style="width: 90%; margin: 10px 0px 0px 10px;"
                      ></el-input>
                    </div>
                    <div slot="footer" style="float: right; margin-top: 10px">
                      <el-button @click="editCancel">取 消</el-button>
                      <el-button type="primary" @click="editCaseYes">确 定</el-button>
                    </div>
                  </div>
                  <!--<el-form ref="editCaseForm" :model="editCaseForm">
                  </el-form>-->
                </el-dialog>
              </div>
            </div>
            <div class="autoGrading-page">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageindex"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount"
              >
              </el-pagination>
            </div>
          </div>
        </div>
        <div class="container" id="containerNot" style="display: none">
          <div class="act-head">
            <el-form ref="namesFormNot" :model="namesFormNot" label-width="80px">
              <el-form-item>
                <el-input
                  v-model="namesFormNot.name"
                  placeholder="请输入订单编号"
                  style="width: 160px"
                ></el-input>
                <el-button type="primary" style="margin-left: 10px" @click="searchByIdNot"
                  >查询</el-button
                >
                <el-button
                  v-show="isShowdelby"
                  style="margin-left: 10px"
                  @click="batchDeleteNot"
                  >批量删除</el-button
                >
              </el-form-item>
            </el-form>
          </div>
          <div class="content">
            <div class="table">
              <div style="padding-left: 10px">
                <el-table
                  border
                  ref="multipleTableNot"
                  :data="tableDataNot"
                  @select-all="selectAllNot"
                  @select="selectAllNot"
                  @row-click="rowClickTableNot"
                  style=""
                >
                  <el-table-column type="selection" width="50"> </el-table-column>
                  <el-table-column type="index" label="序号" width="60">
                  </el-table-column>
                  <el-table-column prop="orderNo" label="订单编号">
                    <template scope="scope">
                      <el-button type="text" @click="jumpToSound(scope.row.orderNo, scope.row.recordFileURL)">{{
                        scope.row.orderNo
                      }}</el-button>
                    </template>
                  </el-table-column>
                  <!-- <el-table-column
                    prop="seatName"
                    label="坐席姓名">
                  </el-table-column> -->
                  <el-table-column
                    prop="createTime"
                    :formatter="dateFormat"
                    label="提交审核时间"
                  >
                  </el-table-column>
                  <el-table-column prop="applyPersonName" label="申请人">
                  </el-table-column>
                  <el-table-column
                    prop="orderTime"
                    :formatter="dateFormat"
                    label="订单时间"
                    sortable
                  >
                  </el-table-column>
                  <el-table-column prop="caseRemark" label="案例理由"> </el-table-column>
                  <el-table-column label="操作" width="140">
                    <template scope="scope">
                      <div style="cursor: pointer">
                        <i
                          v-show="isShowadopt"
                          class="el-icon-circle-check"
                          @click="adopt"
                          style="margin-right:10px"
                          ><i style="padding-left: 3px">通过</i></i
                        >
                        <i
                          v-show="isShowrefuse"
                          class="el-icon-circle-close"
                          @click="refuse"
                          ><i style="padding-left: 3px">拒绝</i></i
                        >
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <el-dialog title="拒绝通过" :visible.sync="refuseModel">
                <div id="refuse">
                  <div style="float: left; width: 45%;">
                    <label>申请理由</label>
                    <el-input
                      type="textarea"
                      v-model="remarkTwo"
                      :disabled="true"
                      :rows="12"
                      style="margin-top: 10px;"
                    >
                    </el-input>
                  </div>
                  <div style="float: right; width: 45%;">
                    <label>拒绝理由</label>
                    <el-input
                      type="textarea"
                      v-model="reReason"
                      :rows="12"
                      style="margin-top: 10px;"
                    >
                    </el-input>
                  </div>
                  <div slot="footer" style="float: right; margin-top: 10px">
                    <el-button @click="refuseCancel">取 消</el-button>
                    <el-button type="primary" @click="refuseCaseYes">确 定</el-button>
                  </div>
                </div>
              </el-dialog>
              <el-dialog title="通过审核" :visible.sync="adoptCaseModel">
                <div class="editcase" style="width:100%;overflow: hidden;">
                  <div
                    style="float: left;width: 30%; height:320px;border: 1px solid #d1dbe5"
                  >
                    <el-tree
                      :data="treedata"
                      :props="defaultProps"
                      highlight-current
                      :expand-on-click-node="false"
                      @node-click="clickOneNodeModelTwo"
                      default-expand-all
                    >
                    </el-tree>
                  </div>
                  <div
                    style="float: right;width: 68%;height:320px;border: 1px solid #d1dbe5"
                  >
                    <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">
                      申请理由
                    </div>
                    <el-input
                      type="textarea"
                      v-model="remarkContent"
                      :rows="10"
                      style="width: 90%; margin: 10px 0px 0px 10px;"
                    ></el-input>
                  </div>
                  <div slot="footer" style="float: right; margin-top: 10px">
                    <el-button @click="adoptCaseModel = false">取 消</el-button>
                    <el-button type="primary" @click="adoptCaseYes">确 定</el-button>
                  </div>
                </div>
                <!--<el-form ref="editCaseForm" :model="editCaseForm">
                </el-form>-->
              </el-dialog>
            </div>
            <div class="autoGrading-page">
              <el-pagination
                @size-change="handleSizeChangeNot"
                @current-change="handleCurrentChangeNot"
                :current-page="pageindexNot"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="pagesizeNot"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCountNot"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import Qs from 'qs'
import global from '../../../global.js'
let qualityUrl = global.qualityUrl
import formatdate from '../../../utils/formatdate.js'
import recordingplay from '../recordingPlayOrder/recordingPlayOrder.vue'
import bus from '../../common/bus.js'
export default {
  components: {
    // 局部注册
    recordingplay,
  },
  data() {
    return {
      recordDialogVisible: false,
      isShowrefuse: false,
      isShowadopt: false,
      isShoweditCase: false,
      isShowLook: false,
      isShowdelby: false,
      isShowdelete: false,
      isShowclose: false,
      isShowedit: false,
      isShowplus: false,
      nodeKeyName: '',
      nodeKeyNameEdit: '',
      reReason: '',
      isExamine: true,
      namesForm: { name: '' },
      namesFormNot: { name: '' },
      tableData: [],
      tableDataNot: [],
      editTreeNodeModel: false,
      treeid: '',
      parentId: '',
      addTreeNodeRules: {
        className: [{ required: true, message: '请输入分类名称！', trigger: 'blur' }],
      },
      editTreeNodeForm: {
        parentClassId: '',
        caseClassId: '',
        className: '',
        remark: '',
        typeid: '',
      },
      addTreeNodeForm: {
        caseClassId: '',
        parentClassId: '',
        className: '',
        remark: '',
        typeid: '',
      },
      addTreeNodeModel: false,
      activeName: '1',
      treedata: [],
      treedataNot: [],
      defaultProps: {
        children: 'children',
        label: 'label',
      },
      clist: [],
      selectTitle: '',
      totalCount: 0,
      pageindex: 1,
      pagesize: 20,
      current: 1,
      totalCountNot: 0,
      pageindexNot: 1,
      pagesizeNot: 20,
      caseIds: '',
      isBatch: false,
      editCaseModel: false,
      caseClassId: '',
      remark: '',
      objectId: '',
      objectIdNot: '',
      remarkTwo: '',
      isBatchShow: false,
      caseIdsAdopt: '',
      refuseModel: false,
      adoptCaseModel: false,
      caseClassIdTwo: '',
      remarkContent: '',
      rows: {},
      selectedRemovedCaseIds: [],
    }
  },
  methods: {
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    // 跳转到录音播放页面
    jumpToSound: function(orderNo, recordFileURL) {
      let obj = {}
      obj.orderNo = orderNo
      obj.recordFileURL = recordFileURL
      obj.pageId = 'caseManage_order'
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push({path: '/recordingPlayOrder', query: obj})

      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 通过 确定
    adoptCaseYes: function() {
      if (this.caseClassIdTwo == null || this.caseClassIdTwo == '') {
        this.$message({
          type: 'warning',
          message: '请选择一个分类!',
        })
      } else {
        let params = {
          caseId: this.caseIdsAdopt,
          caseClassId: this.caseClassIdTwo,
          remark: this.remarkContent,
        }
        this.axios
          .post(
            qualityUrl + 'qualityInspectionSystem/caseManageOrder/passCaseDetail.do',
            Qs.stringify(params)
          )
          .then((res) => {
            if (res.data) {
              this.$message({
                type: 'success',
                message: '数据提交成功!',
              })
            } else {
              this.$message({
                type: 'error',
                message: '数据提交失败!',
              })
            }
            this.adoptCaseModel = false
            this.queryCaseDetailNot()
            this.caseIdsAdopt = ''
            this.caseClassIdTwo = ''
            this.remarkContent = ''
            this.getCaseClassTreeData()
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    // 确认拒绝
    refuseCaseYes: function() {
      let params = {
        caseIdsArray: this.caseIdsAdopt,
        passFlag: false,
        reReason: this.reReason,
        casClassId: this.treeid,
        caseId: this.caseIdsAdopt,
      }
      this.axios
        .post(
          qualityUrl + 'qualityInspectionSystem/caseManageOrder/rejectCaseDetail.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '提交成功',
            })
            this.queryCaseDetailNot()
          } else {
            this.$message({
              type: 'error',
              message: '提交失败!',
            })
          }
          this.refuseModel = false
          this.reReason = ''
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 取消拒绝
    refuseCancel: function() {
      this.refuseModel = false
      this.reReason = ''
    },
    // 通过
    adopt: function() {
      this.adoptCaseModel = true
    },
    // 拒绝
    refuse: function() {
      this.refuseModel = true
    },
    // 确定修改已审核的table
    editCaseYes: function() {
      let params = {
        caseId: this.caseIds,
        caseClassId: this.caseClassId,
        remark: this.remark,
      }
      //  if(this.caseClassId==null || this.caseClassId==""){
      // this.$message({
      // //   type: 'warning',
      // message: '请选择一个分类!'
      //  });
      //  }else{
      this.axios
        .post(
          qualityUrl + 'qualityInspectionSystem/caseManageOrder/updateCaseContent.do',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data) {
            this.$message({
              type: 'success',
              message: '数据提交成功!',
            })
            this.editCaseModel = false
            this.queryCaseDetail()
            this.caseIds = ''
            this.caseClassId = ''
            this.remark = ''
          } else {
            this.$message({
              type: 'error',
              message: '数据提交失败!',
            })
            this.editCaseModel = false
            this.queryCaseDetail()
            this.caseIds = ''
            this.caseClassId = ''
            this.remark = ''
          }
        })
        .catch(function(error) {
          console.log(error)
        })
      //  }
    },
    editCancel: function() {
      this.editCaseModel = false
    },
    // 选择node
    checkChange(node, ischecked, childs) {
      console.log(node)
      if (this.$refs['edittree'].getCheckedNodes().length > 1) {
        if (node.caseClassId == this.$refs['edittree'].getCheckedNodes()[0].caseClassId) {
          this.$refs['edittree'].setChecked(
            this.$refs['edittree'].getCheckedNodes()[1],
            false,
            false
          )
          this.caseClassId = node.caseClassId
        } else if (
          node.caseClassId == this.$refs['edittree'].getCheckedNodes()[1].caseClassId
        ) {
          this.$refs['edittree'].setChecked(
            this.$refs['edittree'].getCheckedNodes()[0],
            false,
            false
          )
          this.caseClassId = node.caseClassId
        }
      }
    },
    // 编辑案例
    editCase: function() {
      // this.$refs.edittree.setCheckedKeys([this.treeid]);
      // console.log("caseid"+this.caseIds);
      let that = this
      // if(this.caseIds==undefined || this.caseIds==""){
      //  this.editCaseModel=false;
      //  }else{
      this.editCaseModel = true
      // console.log("aaaa"+that.$refs['edittree']);
      // console.log(that.$refs['edittree']);
      if (that.$refs['edittree'] == undefined) {
        this.getCaseClassTreeData()
      } else {
        that.$refs['edittree'].setCheckedKeys([this.treeid])
      }
      // this.$refs["edittree"].getCheckedNodes(this.rows,true,false);

      // this.$refs["edittree"].setCheckedKeys(this.rows,true,false)
      // }
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // table点击一行
    rowClickTable: function(row) {
      this.caseIds = row.caseId
      this.objectId = row.calledNo
      this.remark = row.caseRemark
    },
    // 表格多选,获取批量删除需要的ids
    selectAll: function(selection) {
      if (selection) {
        this.selectedRemovedCaseIds = []
        let self = this
        selection.forEach(function(e) {
          self.selectedRemovedCaseIds.push(e['caseId'])
        })
      }
    },
    // 未审核table点击一行
    rowClickTableNot: function(row) {
      this.objectIdNot = row.calledNo
      this.caseIdsAdopt = row.caseId
      this.remarkTwo = row.caseRemark
    },
    // 未审核表格多选,获取批量删除需要的ids
    selectAllNot: function(selection) {
      if (selection) {
        this.selectedRemovedCaseIds = []
        let self = this
        selection.forEach(function(e) {
          self.selectedRemovedCaseIds.push(e['caseId'])
        })
      }
    },
    // 批量删除
    deleteCaseMore: function() {
      if (this.selectedRemovedCaseIds.length == 0) {
        this.$message({
          type: 'warning',
          message: '请至少选择一条数据删除！',
        })
      } else {
        this.$confirm('确定要删除吗? 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
          .then(() => {
            let params = {
              caseIds: this.selectedRemovedCaseIds.join(','),
            }
            this.axios
              .post(
                qualityUrl +
                  'qualityInspectionSystem/caseManageOrder/removeCaseDetails.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data) {
                  this.$message({
                    type: 'success',
                    message: '删除成功!',
                  })
                } else {
                  this.$message({
                    type: 'error',
                    message: '删除失败',
                  })
                }
                this.$refs.multipleTable.clearSelection()
                this.queryCaseDetail()
                this.isBatch = false
                this.caseIds = ''
                this.selectedRemovedCaseIds = []
              })
              .catch(function(error) {
                console.log(error)
              })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除',
            })
            this.$refs.multipleTable.clearSelection()
            this.queryCaseDetail()
            this.isBatch = false
            this.caseIds = ''
            this.selectedRemovedCaseIds = []
          })
      }
    },
    // 删除案例
    deleteCase: function(caseId, orderNo) {
      this.$confirm('确定要删除【 ' + orderNo + '】吗', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let params = {
            caseIds: caseId,
          }
          this.axios
            .post(
              qualityUrl + 'qualityInspectionSystem/caseManageOrder/removeCaseDetails.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data) {
                this.$message({
                  type: 'success',
                  message: '删除成功!',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '删除失败',
                })
              }
              this.$refs.multipleTable.clearSelection()
              this.isBatch = false
              this.queryCaseDetail()
            })
            .catch(function(error) {
              console.log(error)
            })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
          this.$refs.multipleTable.clearSelection()
          this.isBatch = false
          this.queryCaseDetail()
        })
    },
    searchById: function() {
      let params = {
        caseClassId: '',
        casesFlag: '2,3',
        objectId: this.namesForm.name,
        pageSize: this.pagesize,
        pageNumber: this.pageindex,
      }
      let obj = {}
      obj.searchModel = {}
      obj.searchModel.activeTab = '1'
      obj.searchModel.queryString = params
      this.$store.commit('setRecordingPlayPage', obj)
      console.log(obj)

      this.axios
        .post(
          qualityUrl + 'qualityInspectionSystem/caseManageOrder/queryCaseDetail.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.tableData = res.data.Data
          this.totalCount = res.data.Count
          this.getCaseClassTreeData()
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    searchByIdNot: function() {
      let params = {
        caseClassId: '',
        caseFlag: 1,
        objectId: this.namesFormNot.name,
        pageSize: this.pagesize,
        pageNumber: this.pageindex,
      }
      let obj = {}
      obj.searchModel = {}
      obj.searchModel.activeTab = '2'
      obj.searchModel.queryString = params
      this.$store.commit('setRecordingPlayPage', obj)
      this.axios
        .post(
          qualityUrl + 'qualityInspectionSystem/caseManageOrder/queryCaseDetail.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.tableDataNot = res.data.Data
          this.totalCountNot = res.data.Count
          this.getCaseClassTreeData()
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.queryCaseDetail()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.queryCaseDetail()
    },
    /**
     * 每页条数
     * **/
    handleSizeChangeNot(val) {
      this.pagesizeNot = val
      this.pageindexNot = 1
      this.queryCaseDetailNot()
    },
    /**
     *当前页数
     * */
    handleCurrentChangeNot(val) {
      this.pageindexNot = val
      this.queryCaseDetailNot()
    },
    // 案例列表
    queryCaseDetailNot: function() {
      let params = {
        caseClassId: this.treeid,
        caseFlag: 1,
        objectId: this.namesFormNot.name,
        pageSize: this.pagesize,
        pageNumber: this.pageindex,
      }
      let obj = {}
      obj.searchModel = {}
      obj.searchModel.activeTab = '1'
      obj.searchModel.queryString = params
      this.$store.commit('setRecordingPlayPage', obj)
      this.axios
        .post(
          qualityUrl + 'qualityInspectionSystem/caseManageOrder/queryCaseDetail.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.tableDataNot = res.data.Data
          this.totalCountNot = res.data.Count
          // this.treeid=""
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 案例列表
    queryCaseDetail: function() {
      let params = {
        caseClassId: this.treeid,
        casesFlag: '2,3',
        objectId: this.namesForm.name,
        pageSize: this.pagesize,
        pageNumber: this.pageindex,
      }
      let obj = {}
      obj.searchModel = {}
      obj.searchModel.activeTab = '1'
      obj.searchModel.queryString = params
      this.$store.commit('setRecordingPlayPage', obj)
      this.axios
        .post(
          qualityUrl + 'qualityInspectionSystem/caseManageOrder/queryCaseDetail.do',
          Qs.stringify(params)
        )
        .then((res) => {
          this.tableData = res.data.Data
          this.totalCount = res.data.Count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 批量删除
    batchDelete: function() {
      this.deleteCase()
    },
    // 批量删除,未审核
    batchDeleteNot: function() {
      this.deleteCaseNot()
    },
    // 删除案例
    deleteCaseNot: function() {
      if (this.selectedRemovedCaseIds.length === 0) {
        this.$message({
          type: 'warning',
          message: '请至少选择一个条数据删除！',
        })
      } else {
        this.$confirm('你真的要删除这些数据吗? 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
          .then(() => {
            let params = {
              caseIds: this.selectedRemovedCaseIds.join(','),
            }
            this.axios
              .post(
                qualityUrl +
                  'qualityInspectionSystem/caseManageOrder/removeCaseDetails.do',
                Qs.stringify(params)
              )
              .then((res) => {
                if (res.data) {
                  this.$message({
                    type: 'success',
                    message: '删除成功!',
                  })
                } else {
                  this.$message({
                    type: 'error',
                    message: '删除失败',
                  })
                }
                this.$refs.multipleTableNot.clearSelection()
                this.queryCaseDetailNot()
                this.caseIdsAdopt = ''
                this.selectedRemovedCaseIds = []
              })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除',
            })
            this.$refs.multipleTableNot.clearSelection()
            this.queryCaseDetailNot()
            this.caseIdsAdopt = ''
            this.selectedRemovedCaseIds = []
          })
      }
    },
    // 删除一个tree
    deleteTreeNode: function() {
      if (this.treeid == null || this.treeid == '') {
        this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        this.$confirm(
          '你真的要删除 "' + this.selectTitle + '" 及其下的子节点吗?',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
        )
          .then(() => {
            this.axios
              .post(
                qualityUrl +
                  'qualityInspectionSystem/caseClassOrder/removeCaseClass.do?caseClassOrderId=' +
                  this.treeid
              )
              .then((res) => {
                if (res.data.count == 0) {
                  this.$message({
                    type: 'success',
                    message: res.data.message,
                  })
                } else {
                  this.$message({
                    type: 'error',
                    message: '删除失败!',
                  })
                }
                this.getCaseClassTreeData()
                this.treeid = ''
              })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除',
            })
            this.getCaseClassTreeData()
            this.treeid = ''
          })
      }
    },
    // 确认修改tree
    editTreeNodeYesThrottle() {
      this.lodashThrottle.throttle(this.editTreeNodeYes, this)
    },
    editTreeNodeYes: function() {
      let params = {
        className: this.editTreeNodeForm.className,
        remark: this.editTreeNodeForm.remark,
        caseClassId: this.treeid,
      }
      this.$refs.editTreeNodeForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(
              qualityUrl + 'qualityInspectionSystem/caseClassOrder/updateCaseClass.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data == true) {
                this.$message({
                  type: 'success',
                  message: '修改成功',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '修改失败',
                })
              }
              this.$refs.editTreeNodeForm.resetFields()
              this.getCaseClassTreeData()
              this.treeid = ''
              this.editTreeNodeForm.typeid = ''
              this.editTreeNodeModel = false
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    // tree编辑取消
    cancelEdit: function() {
      this.editTreeNodeModel = false
      this.getCaseClassTreeData()
      this.treeid = ''
      this.editTreeNodeForm.typeid = ''
    },
    // 编辑弹框里面的tree
    clickOneNodeModel: function(row) {
      this.caseClassId = row.caseClassId
    },
    // 通过弹框里面的tree
    clickOneNodeModelTwo: function(row) {
      this.caseClassIdTwo = row.caseClassId
    },
    // 点击一行tree节点
    clickOneNode: function(row) {
      this.rows = row
      this.treeid = row.caseClassId
      this.selectTitle = row.label
      this.addTreeNodeForm.typeid = row.label
      this.editTreeNodeForm.typeid = row.label
      this.editTreeNodeForm.className = row.label
      this.editTreeNodeForm.remark = row.remark
      this.clist = row.children
      this.caseClassId = row.caseClassId
      // this.caseIds=row.caseClassId;
      this.queryCaseDetail() // 案例列表
      // this.queryCaseDetailNot();
    },
    // 编辑节点
    editTreeNode: function() {
      if (this.treeid == '') {
        this.$message({
          type: 'warning',
          message: '请选择一个分类',
        })
      } else {
        this.editTreeNodeModel = true
      }
    },
    // 保存节点
    saveTreeNodeThrottle() {
      this.lodashThrottle.throttle(this.saveTreeNode, this)
    },
    saveTreeNode: function() {
      let params = {
        className: this.addTreeNodeForm.className,
        remark: this.addTreeNodeForm.remark,
        parentClassId: this.treeid,
      }
      this.$refs.addTreeNodeForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(
              qualityUrl + 'qualityInspectionSystem/caseClassOrder/saveCaseClass.do',
              Qs.stringify(params)
            )
            .then((res) => {
              if (res.data == true) {
                this.$message({
                  type: 'success',
                  message: '添加成功',
                })
                this.addTreeNodeModel = false
              } else {
                this.$message({
                  type: 'error',
                  message: '已存在相同的分类名称',
                })
              }
              this.$refs.addTreeNodeForm.resetFields()
              this.getCaseClassTreeData()
              this.addTreeNodeForm.typeid = ''
              this.treeid = ''
              this.parentId = 1
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    // 取消
    cancelAddTreeNode: function() {
      this.addTreeNodeModel = false
      this.getCaseClassTreeData()
      this.$refs.addTreeNodeForm.resetFields()
      this.addTreeNodeForm.typeid = ''
      this.treeid = ''
    },
    changeTabNot: function() {
      $('#audited').removeClass('active')
      $('#notAudited').addClass('active')
      $('#container').hide()
      $('#containerNot').show()
      this.isExamine = false
    },
    changeTab: function() {
      $('#audited').addClass('active')
      $('#notAudited').removeClass('active')
      $('#container').show()
      $('#containerNot').hide()
      this.isExamine = true
    },
    // 获取tree
    getCaseClassTreeData: function() {
      this.axios
        .post(
          qualityUrl + 'qualityInspectionSystem/caseClassOrder/getCaseClassTreeData.do'
        )
        .then((res) => {
          let listenDataTwo = res.data
          let treesTwo = []
          this.getOneTree(listenDataTwo, treesTwo)
          this.treedata = treesTwo
          this.treedataNot = treesTwo
          if (treesTwo != null || treesTwo != '') {
            this.parentId = '1'
          } else {
            this.parentId = ''
          }
          this.$refs['edittree'].setCheckedKeys([this.treeid])
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 给tree重新赋值
    getOneTree: function(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        if (value.length == 0) {
          this.treedata = []
        } else {
          if (value[i].children == null) {
            treeList[i] = {
              id: value[i].value.caseClassId,
              caseClassId: value[i].value.caseClassId,
              parentClassId: value[i].value.parentClassId,
              remark: value[i].value.remark,
              label: value[i].name,
              children: null,
            }
          } else {
            treeList[i] = {
              id: value[i].value.caseClassId,
              caseClassId: value[i].value.caseClassId,
              label: value[i].name,
              remark: value[i].value.remark,
              parentClassId: value[i].value.parentClassId,
              children: this.getOneTree(value[i].children, []),
            }
          }
        }
      }
      return treeList
    },
    // 添加一个tree节点
    addTreeNode: function() {
      if (this.parentId == '') {
        this.addTreeNodeModel = true
      } else {
        // this.addTreeNodeModel = true;
        let that = this
        if (that.treeid == null || that.treeid == '') {
          this.$message({
            type: 'warning',
            message: '请选择一个分类',
          })
        } else {
          this.parentId = this.treeid
          this.addTreeNodeModel = true
        }
      }
    },
    // 获取权限按钮
    getFuncId: function() {
      this.axios
        .post(global.hrmApi + '/accountApi/accessible/getFuncIdByAccountId.do')
        .then((res) => {
          for (let i = 0; i < res.data.length; i++) {
            if (res.data[i] == 'alor11') {
              this.isShowedit = true
            }
            if (res.data[i] == 'alor00') {
              this.isShowplus = true
            }
            if (res.data[i] == 'alor22') {
              this.isShowclose = true
            }
            // 删除
            if (res.data[i] == 'alor33') {
              this.isShowdelete = true
            }
            // 编辑
            if (res.data[i] == 'alor44') {
              this.isShoweditCase = true
            }
            // 查看
            if (res.data[i] == 'alor55') {
              this.isShowLook = true
            }
            // 批量删除
            if (res.data[i] == 'alor66') {
              this.isShowdelby = true
            }
            // 通过
            if (res.data[i] == 'sssssdy') {
              this.isShowadopt = true
            }
            // 拒绝
            if (res.data[i] == 'hhhxsjg') {
              this.isShowrefuse = true
            }
          }
        })
    },
  },
  created() {
    this.getFuncId()
    if (
      this.recordingPlayPage.fromPage == 'caseManage_new' &&
      this.recordingPlayPage.searchModel.activeTab
    ) {
      if (this.recordingPlayPage.searchModel.activeTab == '1') {
        this.nodeKeyName = this.recordingPlayPage.searchModel.queryString.caseClassId
      } else if (this.recordingPlayPage.searchModel.activeTab == '2') {
        this.nodeKeyName = this.recordingPlayPage.searchModel.queryString.caseClassId
      }
    }
  },
  mounted() {
    this.getCaseClassTreeData()
    if (
      this.recordingPlayPage.fromPage == 'caseManage_new' &&
      this.recordingPlayPage.searchModel.activeTab
    ) {
      if (this.recordingPlayPage.searchModel.activeTab == '1') {
        let classid = this.recordingPlayPage.searchModel.queryString.caseClassId
        let objectId = this.recordingPlayPage.searchModel.queryString.objectId
        $('#audited').addClass('active')
        $('#notAudited').removeClass('active')
        $('#container').show()
        $('#containerNot').hide()
        this.pageindex = this.recordingPlayPage.searchModel.queryString.pageNumber
        this.pagesize = this.recordingPlayPage.searchModel.queryString.pageSize
        this.namesForm.name = this.recordingPlayPage.searchModel.queryString.objectId
        this.nodeKeyName = this.recordingPlayPage.searchModel.queryString.caseClassId
        if (classid == '' && objectId != '') {
          this.searchById()
        }
        if (classid != '' && objectId == '') {
          this.queryCaseDetail(classid)
        }
        if (objectId == '' && classid == '') {
          this.searchById()
        }
      } else if (this.recordingPlayPage.searchModel.activeTab == '2') {
        // 给tree设置默认值
        $('#audited').removeClass('active')
        $('#notAudited').addClass('active')
        $('#containerNot').show()
        $('#container').hide()
        let classid = this.recordingPlayPage.searchModel.queryString.caseClassId
        let objectId = this.recordingPlayPage.searchModel.queryString.objectId
        this.pageindexNot = this.recordingPlayPage.searchModel.queryString.pageNumber
        this.pagesizeNot = this.recordingPlayPage.searchModel.queryString.pageSize
        this.namesFormNot.name = this.recordingPlayPage.searchModel.queryString.objectId
        this.nodeKeyName = this.recordingPlayPage.searchModel.queryString.caseClassId
        if (classid == '' && objectId != '') {
          this.searchByIdNot()
        }
        if (classid != '' && objectId == '') {
          this.queryCaseDetailNot(classid)
        }
        if (objectId == '' && classid == '') {
          this.searchByIdNot()
        }
      }
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.caseManage {
  width: 100%;
  /*top:1px;*/
  box-sizing: border-box;
  height: 100%;
  position: relative;
  #refuse {
    width: 100%;
    margin: 0 auto;
    overflow: hidden;
    label {
      color: #000;
      font-weight: bold;
    }
  }
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .caseContent {
    padding: 52px 10px 10px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    .caseRight {
      height: 100%;
      margin-left: 220px;
      position: relative;
      border-left: 1px solid #d1dbe5;
      .container {
        overflow: hidden;
        height: 100%;
        position: relative;
        .content {
          padding-top: 58px;
          padding-bottom: 80px;
          box-sizing: border-box;
          width: 100%;
          height: 100%;
        }
        .autoGrading-page {
          right: 10px;
          position: absolute;
          bottom: 10px;
        }
        .table {
          width: 100%;
          height: 100%;
          overflow: auto;
          /*position: absolute;
            top: 55px;
            bottom: 80px;
            cursor: pointer;*/
        }
        .act-head {
          border-bottom: 1px dashed #d1dbe7;
          right: 0;
          top: 0;
          width: 100%;
          position: absolute;
          text-align: right;
          height: 44px;
        }
      }
    }
    .caseLeft {
      width: 220px;
      height: 100%;
      float: left;
      position: relative;
      .tree {
        position: absolute;
        top: 55px;
        left: 0px;
        bottom: 0px;
        overflow: auto;
        width: 100%;
        cursor: pointer;
      }
      .item {
        position: absolute;
        top: 0px;
        left: 0px;
        width: 100%;
        border-bottom: 1px dashed #d1dbe7;
        button {
          opacity: 0.7;
          width: 25px;
          height: 25px;
          padding: 0px;
        }
        a {
          float: right;
          margin: 10px 10px 10px 0px;
          i {
            cursor: pointer;
            margin-right: 10px;
            border: 1px solid #d1dbe7;
            padding: 5px;
            border-radius: 3px;
          }
        }
      }
    }
  }
  .caseHeader {
    float: left;
    box-sizing: border-box;
    top: 0px;
    width: 100%;
    height: 42px;
    border-bottom: 1px solid #d1dbe5;
    background-color: #eef1f6;
    ul {
      cursor: pointer;
      width: 200px;
      li {
        display: inline-block;
        text-align: center;
        width: 80px;
        line-height: 42px;
        font-size: 14px;
      }
      .active {
        color: #20a0ff;
      }
    }
  }
}
</style>
<style lang="less">
#caseManage {
  .el-tree {
    border: none;
  }
  .el-table .cell,
  .el-table th > div {
    padding-left: 8px;
    padding-right: 8px;
    box-sizing: border-box;
    text-overflow: ellipsis;
  }
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
}
</style>
