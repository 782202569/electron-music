<template>
  <div class="dialogHeader">
    <el-form label-width="84px" :model="TaskAttr" ref="TaskAttr" :rules="taskAttrRules">
      <div class="titleHeader" style="border-top: 1px solid #E0E6ED;">
        <el-form-item label="任务名称" prop="projectName">
          <el-input
            style="width:316px"
            v-model="TaskAttr.projectName"
            placeholder="请输入任务名称"
          ></el-input>
        </el-form-item>

        <el-form-item label="模板选择" prop="modleId">
          <el-select
            clearable
            v-model="TaskAttr.modleId"
            placeholder="请选择状态"
            style="width: 316px;"
          >
            <el-option
              v-for="item in modelList"
              :key="item.modleId"
              :label="item.modleTitle"
              :value="item.modleId"
            >
            </el-option>
          </el-select>
        </el-form-item>

        <!-- 关联流程 -->
        <el-form-item label="评分流程" prop="processList">
          <el-select v-model="TaskAttr.processList" multiple placeholder="请选择流程">
            <el-option
              v-for="item in processList"
              :key="item.processId"
              :label="item.processName"
              :value="item.processId"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </div>
      <div style="margin-left: 20px;margin-right: 20px;border-bottom: 1px solid #E0E6ED;">
        <div style="display: inline-block; padding: 18px 16px 12px 0px;">
          <h3>周期(天)</h3>
        </div>
        <div class="audioAttrsInputs" style="height: 60px;">
          <el-col :span="12">
            <el-form-item label="运行周期" prop="operationperiod">
              <el-input v-model="TaskAttr.operationperiod"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="采集周期" prop="collectionperiod">
              <el-input v-model="TaskAttr.collectionperiod"></el-input>
            </el-form-item>
          </el-col>
        </div>
      </div>
    </el-form>
    <el-form label-width="84px" :model="Task" ref="Task">
      <div style="margin-left: 20px;margin-right: 20px;">
        <div style="display: inline-block; padding: 12px 16px 12px 0px;">
          <h3>录音属性</h3>
        </div>
        <div class="audioAttrsInputs">
          <el-col :span="12">
            <el-form-item label="录音编号" prop="callId">
              <el-col :span="24">
                <el-input v-model="Task.callId"></el-input>
              </el-col>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="通话时长">
              <el-col :span="6">
                <el-form-item prop="callTime_Min" style="margin-right: 0;">
                  <el-input v-model="Task.callTime_Min"></el-input>
                </el-form-item>
              </el-col>
              <el-col class="line" :span="2" style="text-align: center;">-</el-col>
              <el-col :span="6">
                <el-form-item prop="callTime_Max" style="margin-right: 0;">
                  <el-input v-model="Task.callTime_Max"></el-input>
                </el-form-item>
              </el-col>
              <el-col class="line" :span="1">&nbsp;</el-col>
              <el-col :span="8">
                <el-form-item prop="timeType" style="margin-right: 0;">
                  <el-select v-model="Task.timeType">
                    <el-option
                      v-for="item in timecellAttrs"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-form-item>
          </el-col>
        </div>
      </div>
      <div
        style="margin-top: 20px;margin-left: 20px;margin-right: 20px;border-top: 1px solid #E0E6ED;"
      >
        <div style="display: inline-block; padding: 18px 16px 12px 0px;">
          <h3>坐席属性</h3>
        </div>
        <div class="audioAttrsInputs" style="height: 60px;">
          <el-col :span="12">
            <el-form-item label="坐席工号" prop="seatNo">
              <el-input v-model="Task.seatNo"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="坐席姓名" prop="seatName">
              <el-input v-model="Task.seatName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12" class="mySelect">
            <el-form-item label="坐席组" prop="deptId">
              <el-select
                clearable
                v-model="Task.deptId"
                :popper-append-to-body="false"
                style="width: 186px;"
                placeholder="请选择"
              >
                <optionNode
                  v-for="(item, index) in seatGroupOptions"
                  :key="index"
                  :node="item"
                />
                <!-- <el-option
                  v-for="item in seatGroupOptions"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id"
                >
                </el-option> -->
              </el-select>
            </el-form-item>
          </el-col>
        </div>
      </div>
      <div
        style="margin-top: 55px;margin-left: 20px;margin-right: 20px;border-top: 1px solid #E0E6ED;"
      >
        <div style="display: inline-block; padding: 18px 16px 12px 0px;">
          <h3>语音特征</h3>
        </div>
        <div class="audioAttrsInputs">
          <el-col :span="12">
            <el-form-item label="重叠次数">
              <el-col :span="10">
                <el-form-item prop="overlap_Min">
                  <el-input v-model="Task.overlap_Min" placeholder="次"></el-input>
                </el-form-item>
              </el-col>
              <el-col class="line" :span="3">-</el-col>
              <el-col :span="10">
                <el-form-item prop="overlap_Max">
                  <el-input v-model="Task.overlap_Max" placeholder="次"></el-input>
                </el-form-item>
              </el-col>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="平均语速">
              <el-col :span="10">
                <el-form-item prop="avgSpeed_Min">
                  <el-input v-model="Task.avgSpeed_Min" placeholder="字/秒"></el-input>
                </el-form-item>
              </el-col>
              <el-col class="line" :span="3">-</el-col>
              <el-col :span="10">
                <el-form-item prop="avgSpeed_Max">
                  <el-input v-model="Task.avgSpeed_Max" placeholder="字/秒"></el-input>
                </el-form-item>
              </el-col>
            </el-form-item>
          </el-col>
        </div>
        <div class="audioAttrsInputs" style="float: left;height: 60px;">
          <el-col :span="20">
            <el-form-item label="静默特征" prop="silenceAttrType">
              <el-col :span="6">
                <el-select clearable v-model="Task.silenceAttrType" placeholder="请选择">
                  <el-option
                    v-for="item in silenceAttrs"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-col>
              <el-col class="line" :span="1">&nbsp;</el-col>
              <el-col
                :span="5"
                v-if="Task.silenceAttrType == 'silenceLong' || Task.silenceAttrType == ''"
              >
                <el-form-item prop="silenceCount_Min">
                  <el-input
                    style="width:80px;"
                    v-model="Task.silenceCount_Min"
                    placeholder="秒"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="5" v-if="Task.silenceAttrType == 'silenceCount'">
                <el-form-item prop="silenceLong_Min">
                  <el-input
                    style="width:80px;"
                    v-model="Task.silenceLong_Min"
                    placeholder="次"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="5" v-if="Task.silenceAttrType == 'silencePer'">
                <el-form-item prop="silencePer_Min">
                  <el-input
                    style="width:80px;"
                    v-model="Task.silencePer_Min"
                    placeholder="%"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col class="line" :span="1" style="text-align: center;">-</el-col>
              <el-col
                :span="5"
                v-if="Task.silenceAttrType == 'silenceLong' || Task.silenceAttrType == ''"
              >
                <el-form-item prop="silenceLong_Max">
                  <el-input
                    style="width:80px;"
                    v-model="Task.silenceLong_Max"
                    placeholder="秒"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="5" v-if="Task.silenceAttrType == 'silenceCount'">
                <el-form-item prop="silenceCount_Max">
                  <el-input
                    style="width:80px;"
                    v-model="Task.silenceCount_Max"
                    placeholder="次"
                  ></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="5" v-if="Task.silenceAttrType == 'silencePer'">
                <el-form-item prop="silencePer_Max">
                  <el-input
                    style="width:80px;"
                    v-model="Task.silencePer_Max"
                    placeholder="%"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-form-item>
          </el-col>
        </div>
      </div>
    </el-form>
    <div style="width: 100%;clear: both;border-bottom: 1px solid #E0E6ED;">
      <div slot="footer" style="float: right; height: 53px;padding-top: 15px">
        <el-button @click="taskGoback">取 消</el-button>
        <el-button @click="taskCreateThrottle" type="primary" style="margin-right: 18px;"
          >确 定</el-button
        >
      </div>
    </div>
  </div>
</template>
<style lang="less">
.audioAttrsInputs .el-col-12 {
  height: 55px;
}
</style>
<style scoped="scoped" lang="less">
.audioAttrsInputs {
  width: 100%;
  height: 50px;
}
.mySelect /deep/ .el-scrollbar__wrap {
  height: 260px;
}
</style>
<script>
import Qs from 'qs'
import global from '../../../global.js'
import optionNode from '@/components/common/nestedSelection/optionNode'
import constructTree from '@/components/common/nestedSelection/constructTree'
let currentBaseUrl = global.qualityUrl
let qualityUrl = global.qualityUrl
export default {
  props: ['projectModel'],
  components: {
    optionNode,
  },
  data() {
    let checkNumber = (rule, value, callback) => {
      if (value == '') {
        callback(new Error('请输入数字'))
      } else if (isNaN(value)) {
        callback(new Error('请输入数字'))
      } else {
        callback()
      }
    }
    let checkName = (rule, value, callback) => {
      console.log(value)
      if (value.indexOf(' ') >= 0) {
        callback(new Error('请勿输入特殊字符'))
      }
      this.axios
        .post(
          currentBaseUrl + '/ascorec/checkRonertExist.do',
          Qs.stringify({ projectName: value })
        )
        .then(function(response) {
          if (response.data == false) {
            callback(new Error('任务名称已存在'))
          } else {
            callback()
          }
        })
    }
    return {
      silenceAttrType: '', // 静默特征类型
      projectId: '',
      TaskAttr: {
        projectName: '',
        modleId: '',
        processList: [],
        operationperiod: '', // 运行周期
        collectionperiod: '', // 采集周期
      }, // 任务属性
      taskAttrRules: {
        // 任务属性验证
        projectName: [
          { required: true, message: '任务名称不能为空', trigger: 'blur' },
          { required: true, validator: checkName, trigger: 'blur' },
        ],
        modleId: [{ required: true, message: '请选择一个模板', trigger: 'change' }],
        operationperiod: [{ required: true, validator: checkNumber, trigger: 'blur' }],
        collectionperiod: [{ required: true, validator: checkNumber, trigger: 'blur' }],
      },
      Task: {
        callId: '',
        sysAutoScore: '',
        overLap: '',
        avgSpeed: '',
        moodScore: '',
        speechSlient: '',
        taskTypes: '',
        overlap_Min: '', // 重叠次数
        overlap_Max: '', // 重叠次数
        avgSpeed_Min: '', // 坐席平均语速
        avgSpeed_Max: '', // 坐席平均语速
        mood_Min: '', // 情绪分值
        mood_Max: '', // 情绪分值
        silenceAttrType: '', // 静默特征类型
        silenceLong_Min: '', // 静默时长
        silenceLong_Max: '', // 静默时长
        silenceCount_Min: '', // 静默次数
        silenceCount_Max: '', // 静默次数
        silencePer_Min: '', // 静默占比
        silencePer_Max: '', // 静默占比
        callTime_Min: '', // 通话时长小
        callTime_Max: '', // 通话时长大
        timeType: '0', // 时分秒
        seatNo: '', // 坐席工号
        seatName: '', // 坐席姓名
        deptId: '', // 坐席组
      },
      seatGroupOptions: [],
      props: { value: 'id', label: 'name', children: 'child' },
      taskTypes: [
        {
          value: '1',
          label: '即时任务',
        },
        {
          value: '2',
          label: '循环任务',
        },
      ],
      silenceAttrs: [
        {
          value: 'silenceLong',
          label: '时长',
        },
        {
          value: 'silenceCount',
          label: '次数',
        },
        {
          value: 'silencePer',
          label: '占比',
        },
      ],
      timecellAttrs: [
        {
          value: '0',
          label: '秒',
        },
        {
          value: '1',
          label: '分',
        },
        {
          value: '2',
          label: '时',
        },
      ],
      modelList: [], // 模板id
      processList: [], // 流程字典
      state: 'add', // 添加还是复制
    }
  },
  methods: {
    taskCreateThrottle() {
      this.lodashThrottle.throttle(this.taskCreate, this)
    },
    taskCreate() {
      this.saveSearchConfigure()
    },
    // 保存配置
    saveSettingConfigure(id) {
      let _this = this
      if (
        _this.projectModel &&
        _this.TaskAttr.projectName == _this.projectModel.strategyName.toString()
      ) {
        _this.$message({
          type: 'warning',
          message: '请修改任务名称',
        })
        return false
      }
      let params = {
        projectName: _this.TaskAttr.projectName,
        modleId: _this.TaskAttr.modleId,
        processList: _this.TaskAttr.processList,
        operationperiod: _this.TaskAttr.operationperiod,
        collectionperiod: _this.TaskAttr.collectionperiod,
        robertProjectId: id,
      }
      let url = currentBaseUrl + '/ascorec/insertRonertProject.do'
      _this.axios
        .post(url, Qs.stringify(params))
        .then(function(response) {
          let msg = '任务保存成功'
          if (_this.state == 'copy') {
            msg = '任务复制成功'
          }
          _this.$message({
            type: 'success',
            message: msg,
          })
          _this.$emit('send', false, 'success')
        })
        .catch(function(error) {
          console.log(error)
          return Promise.reject()
        })
    },
    // 保存查询条件
    saveSearchConfigure() {
      let _this = this
      this.$refs.TaskAttr.validate((valid) => {
        if (!valid) {
          return false
        } else {
          this.checkFaq().then((val) => {
            if (val) {
              this.$message.error(val)
              return
            }
            let params = {}
            params.status = '9'
            params.strategyBelong = '系统自动评分'
            params.strategyName = _this.TaskAttr.projectName
            params.strategyId = ''
            params.processList = _this.TaskAttr.processList.toString()
            //console.log(_this.Task.timeType)
            //if (
            //  _this.Task.timeType == '1' &&
            //  _this.Task.callTime_Min != '' &&
            //  _this.Task.callTime_Max != ''
            //) {
            //  _this.Task.callTime_Min = _this.Task.callTime_Min * 60
            //   _this.Task.callTime_Max = _this.Task.callTime_Max * 60
            // } else if (
            //   _this.Task.timeType == '2' &&
            //   _this.Task.callTime_Min != '' &&
            //   _this.Task.callTime_Max != ''
            //  ) {
            //    _this.Task.callTime_Min = _this.Task.callTime_Min * 60 * 60 * 1000
            //   _this.Task.callTime_Max = _this.Task.callTime_Max * 60 * 60 * 1000
            //  } else if (
            //   _this.Task.timeType == 0 &&
            //   _this.Task.callTime_Min != '' &&
            //   _this.Task.callTime_Max != ''
            // ) {
            //   _this.Task.callTime_Min = _this.Task.callTime_Min * 1000
            //   _this.Task.callTime_Max = _this.Task.callTime_Max * 1000
            // } else {
            //   _this.Task.callTime_Min = ''
            //   _this.Task.callTime_Max = ''
            // }
            //console.log('+++++++++++++++++task 值')
            //console.log(_this.Task.callTime_Min)
            //console.log(_this.Task.callTime_Max)
            //console.log(_this.Task)
            params.strategyObject = JSON.stringify(_this.Task)
            console.log(params)
            let url = currentBaseUrl + '/ivsStrategy/insertIvsStrategy.do'
            _this.axios
              .post(url, Qs.stringify(params))
              .then(function(response) {
                _this.saveSettingConfigure(response.data.streategyId)
              })
              .catch(function(error) {
                console.log(error)
                _this.$message({
                  type: 'error',
                  message: '策略保存失败',
                })
              })
          })
        }
      })
    },
    getSeatGroup() {
      let _this = this
      let url = qualityUrl + '/pageConstant/getValue.do'
      let searchParam = {}
      searchParam.keys = 'seatGroup'
      this.axios
        .post(url, Qs.stringify(searchParam))
        .then(function(response) {
          // _this.seatGroupOptions = response.data.seatGroup
          _this.seatGroupOptions = constructTree(response.data.seatGroup)
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取常量值出现问题',
          })
        })
    },
    // 点击返回按钮callingTime
    taskGoback() {
      this.$emit('send', false)
    },
    // 获取模板列表
    getModleInfoByCondition() {
      let _this = this
      let params = {
        modleType: '7',
        pageindex: '',
        pagesize: '',
      }
      let url = currentBaseUrl + '/manualQualityAssurance/getModleInfoByCondition.do'
      _this.axios
        .post(url, Qs.stringify(params))
        .then(function(response) {
          _this.modelList = response.data.Data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '模板获取失败',
          })
        })
    },
    checkFaq() {
      return new Promise((resolve, reject) => {
        let idx = this.modelList.findIndex((item) => {
          return item.modleId === this.TaskAttr.modleId
        })
        let updateTime = ''
        if (idx !== -1) {
          updateTime = this.modelList[idx].updateTime
        }
        let params = {
          modleId: this.TaskAttr.modleId,
          updateTime: updateTime,
        }
        this.axios
          .post(
            qualityUrl + '/manualQualityAssurance/getFaqCheckModel.do',
            Qs.stringify(params)
          )
          .then(function(response) {
            let { flag, data } = response.data
            if (flag) {
              resolve('')
            } else {
              resolve(data)
            }
          })
          .catch((err) => {
            reject(err)
          })
      })
    },
    // 获取模板列表
    getProcessList() {
      let _this = this
      let url = currentBaseUrl + '/process/getAllProcess.do'
      _this.axios
        .post(url, Qs.stringify())
        .then(function(response) {
          _this.processList = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '流程获取失败',
          })
        })
    },
  },
  mounted: function() {
    this.getSeatGroup()
  },
  created() {
    this.getModleInfoByCondition()
    this.getProcessList()
    if (this.projectModel) {
      this.state = 'copy'
      this.TaskAttr.projectName = this.projectModel.strategyName.toString()
      this.TaskAttr.modleId = this.projectModel.modleId.toString()
      this.TaskAttr.processList = this.projectModel.processList
      this.TaskAttr.operationperiod = parseInt(
        this.projectModel.operationperiod.toString()
      )
      this.TaskAttr.collectionperiod = parseInt(
        this.projectModel.collectionperiod.toString()
      )
      this.strategyId = this.projectModel.strategyId.toString()
      this.changeValue = JSON.parse(this.projectModel.strategyObject)
      this.Task = this.changeValue
    }
  },
}
</script>
