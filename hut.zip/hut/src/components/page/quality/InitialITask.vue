<template>
  <div>
    <div class="containerWrap" v-if="showInitailTask">
      <div class="header">
        <div class="containTitle">初检任务</div>
        <div class="act-head searchForm">
          <el-form ref="searchForm" :model="searchForm" label-width="30px" :inline="true">
            <el-form-item>
              <el-date-picker
                v-model="searchForm.searchTime"
                type="datetimerange"
                align="right"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
              >
              </el-date-picker>
              <el-button @click="searchTask" type="primary" style="margin-left: 7px;"
                >查询</el-button
              >
              <a class="moreChoice" @click="moreCondition">更多条件搜索</a>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div class="content">
        <div class="table">
          <div class="tableCell">
            <el-table border ref="multipleTable" tootip-effect="dark" :data="projects">
              <el-table-column width="154" prop="projectName" label="任务名称">
                <template scope="scope">
                  <el-button
                    type="text"
                    style="padding: 10px 0;"
                    @click="showTaskList(scope.row.taskId,scope.row.persent)"
                  >
                    {{ scope.row.projectName }}
                  </el-button>
                </template>
              </el-table-column>
              <el-table-column prop="createUser" label="创建者" width="120">
              </el-table-column>
              <el-table-column width="207" label="任务时间">
                <template scope="scope">
                  <p>{{ scope.row.firstQaStartTime | exeTimeFilter }} -</p>
                  <p>{{ scope.row.firstQaEndTime | exeTimeFilter }}</p>
                </template>
              </el-table-column>
              <el-table-column prop="taskType" label="任务类型">
                <template scope="scope">
                  <el-tag close-transition v-if="scope.row.taskType == 1"
                    >系统抽样</el-tag
                  >
                  <el-tag close-transition v-if="scope.row.taskType == 2"
                    >人工抽样</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column prop="projectType" label="任务状态">
                <template scope="scope">
                  <el-tag
                    close-transition
                    type="gray"
                    v-if="scope.row.projectType == '已完成'"
                    >{{ scope.row.projectType }}</el-tag
                  >
                  <el-tag
                    close-transition
                    type="primary"
                    v-if="scope.row.projectType == '进行中'"
                    >{{ scope.row.projectType }}</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column prop="count" label="任务量"> </el-table-column>
              <el-table-column prop="persent" label="已完成">
                <template scope="scope">
                  <div>
                    <span v-if="scope.row.persent === '100%'">{{
                      scope.row.persent
                    }}</span>
                    <span v-else>{{
                      scope.row.finish + ' (' + scope.row.persent + ')'
                    }}</span>
                  </div>
                </template>
              </el-table-column>
            </el-table>
            <el-dialog
              class="myQaSearchModel"
              :visible.sync="moreChance"
              width="320px"
              :close-on-click-modal="false"
            >
              <div class="myQaSearch">
                <el-form
                  label-width="70px"
                  ref="moreSearch"
                  :model="moreSearch"
                  :rules="moreSearchRules"
                  label-position="left"
                >
                  <el-form-item label="创建者" prop="projectNameCreate">
                    <el-select v-model="moreSearch.projectNameCreate">
                      <el-option
                        v-for="val in projectCreates"
                        :key="val"
                        :label="val"
                        :value="val"
                      >
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="任务类型" prop="deaolType">
                    <el-select v-model="moreSearch.deaolType">
                      <el-option
                        v-for="item in taskType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="任务状态" prop="wedType">
                    <el-select v-model="moreSearch.wedType">
                      <el-option
                        v-for="item in workType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <div
                    class="footerAll"
                    style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
                  >
                    <div
                      class="footInside"
                      style="float: right;height: 53px;padding-top: 15px"
                    >
                      <el-button @click="dispearNot" style="margin-right: 18px;"
                        >取 消</el-button
                      >
                      <el-button type="primary" @click="moreSearchTaskBtn"
                        >查 询</el-button
                      >
                    </div>
                  </div>
                </el-form>
              </div>
            </el-dialog>
          </div>
        </div>
      </div>
      <div class="autoGrading-page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="pageSizes"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        >
        </el-pagination>
      </div>
    </div>
    <div v-if="!showInitailTask">
      <myQaTaskList
        :parentModel="this.parentModel"
        v-on:toInitalTask="changeshow"
      ></myQaTaskList>
    </div>
  </div>
</template>
<script>
import myQaTaskList from './myQaTaskList.vue'
import global from '../../../global.js'
import moment from 'moment'
import formatdate from '../../../utils/formatdate.js'
import Qs from 'qs'
let qualityUrl = global.qualityUrl
export default {
  components: {
    myQaTaskList,
  },
  data() {
    return {
      currentPage: 1,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
      showInitailTask: true,
      tableData: [],
      projects: [],
      moreSearch: {
        // 更多搜索
        wedType: '',
        deaolType: '',
        projectNameCreate: '',
      },
      moreSearchRules: {},
      searchForm: {
        searchTime: [], // 搜索的时间
      }, // 普通搜索
      moreChance: false,
      projectCreates: [],
      taskType: [
        {
          label: '全部',
          value: 0,
        },
        {
          label: '系统抽样',
          value: 1,
        },
        {
          label: '人工抽样',
          value: 2,
        },
      ],
      workType: [
        {
          label: '进行中',
          value: 2,
        },
        {
          label: '已完成',
          value: 1,
        },
      ],
      parentModel: {},
      isSampleSearch: true,
    }
  },
  methods: {
    initList: function() {
      this.initTime()
      this.getCreater()
      this.searchTask()
    },
    initTime: function() {
      let fromData = ''
      let toform = ''
      if (this.searchForm.searchTime == null) {
        fromData = ''
        toform = ''
      } else {
        if (
          this.searchForm.searchTime[0] != undefined &&
          this.searchForm.searchTime[0] != ''
        ) {
          fromData = formatdate.formatDate(this.searchForm.searchTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromData = formatdate.formatDate(now)
        }
        if (
          this.searchForm.searchTime[1] != undefined &&
          this.searchForm.searchTime[1] != ''
        ) {
          toform = formatdate.formatDate(this.searchForm.searchTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toform = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.searchTime = [fromData, toform]
    },
    // 获取创建者列表
    getCreater: function() {
      let params = {
        type: 1,
      }
      let self = this
      this.axios
        .post(
          qualityUrl +
            '/myTask/queryCreateUser.do?pagesize=' +
            this.pageSize +
            '&pageindex=' +
            this.currentPage,
          Qs.stringify(params)
        )
        .then(function(response) {
          self.projectCreates = response.data.createUsers
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '获取创建者失败',
          })
        })
    },
    setMoreSearch: function() {
      this.moreSearch.wedType = 2
      this.moreSearch.deaolType = 0
      this.moreSearch.projectNameCreate = ''
    },
    dispearNot: function() {
      this.moreChance = false
      this.setMoreSearch()
    },
    moreCondition: function() {
      this.setMoreSearch()
      this.moreChance = true
    },
    // 点击任务名称
    showTaskList: function(id,persent) {
      this.showInitailTask = false
      this.parentModel = {
        taskId: id,
        qaScoreType: 1,
        from: 'myQaTasks',
        persent:persent,
      }
    },
    changeshow: function() {
      this.showInitailTask = true
      this.searchTask()
    },
    handleSizeChange(val) {
      this.currentPage = 1
      this.pageSize = val
      if (this.isSampleSearch) {
        this.searchTask()
      } else {
        this.moreSearchTask()
      }
    },
    handleCurrentChange(val) {
      this.currentPage = val
      if (this.isSampleSearch) {
        this.searchTask()
      } else {
        this.moreSearchTask()
      }
    },
    // 更多查询条件
    moreSearchTaskBtn() {
      this.currentPage = 1
      this.isSampleSearch = false
      this.moreSearchTask()
    },
    moreSearchTask() {
      let params = {
        startTime:
          this.searchForm.searchTime === null
            ? ''
            : formatdate.formatDate(this.searchForm.searchTime[0]),
        endTime:
          this.searchForm.searchTime === null
            ? ''
            : formatdate.formatDate(this.searchForm.searchTime[1]),
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        assignUsr: this.moreSearch.projectNameCreate,
        // 'TaskType': (this.moreSearch.deaolType == 0) ? '' : this.moreSearch.deaolType,
        type: 1,
        status: this.moreSearch.wedType,
      }
      if (this.moreSearch.deaolType != 0) {
        params.taskType = this.moreSearch.deaolType
      }
      let self = this
      this.axios
        .post(qualityUrl + '/myTask/queryMytask.do', Qs.stringify(params))
        .then(function(response) {
          self.total = response.data.count
          self.projects = response.data.data
          self.moreChance = false
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '任务获取失败',
          })
        })
    },
    searchTask() {
      let params = {
        startTime:
          this.searchForm.searchTime === null
            ? ''
            : formatdate.formatDate(this.searchForm.searchTime[0]),
        endTime:
          this.searchForm.searchTime === null
            ? ''
            : formatdate.formatDate(this.searchForm.searchTime[1]),
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        type: 1,
      }
      let self = this
      this.axios
        .post(qualityUrl + '/myTask/queryMytask.do', Qs.stringify(params))
        .then(function(response) {
          self.total = response.data.count
          self.projects = response.data.data
          self.moreChance = false
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '任务获取失败',
          })
        })
    },
  },
  filters: {
    exeTimeFilter(cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
  },
  created() {
    this.initTime()
    this.getCreater()
    this.searchTask()
  },
}
</script>
<style lang="less" scoped="scoped">
.containerWrap {
  overflow: hidden;
  height: 100%;
  position: relative;
  .header {
    height: 104px;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: center;
    padding: 0 20px;
    box-sizing: border-box;
    .containTitle {
      display: flex;
      flex: 1;
      font-size: 14px;
    }
    .act-head {
      display: flex;
      height: 100%;
      align-items: center;
    }
  }
  .copyCell {
    width: 100%;
    height: 200px;
  }
  .content {
    padding: 0 20px 150px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .autoGrading-page {
    right: 10px;
    position: absolute;
    bottom: 10px;
  }
  .table {
    width: 100%;
    height: 100%;
    overflow: auto;
  }
  .backPage {
    color: #20a0ff;
    padding: 19px 0 10px 18px;
    span {
      cursor: pointer;
    }
  }
  .el-button {
    width: 88px;
    padding: 10px 16px 10px 16px;
  }
}

.contentAlltitle {
  border-top: 1px solid #e0e6ed;
  padding: 20px 20px 0 20px;
}

#cc .el-form-item__label {
  width: 100px;
}
</style>
<style lang="less">
.copyCell {
  .el-input__inner {
    height: 36px;
    line-height: 36px;
    width: 316px;
  }
}

.searchForm {
  .el-form-item {
    margin: 0;
  }
  .el-button {
    width: 88px;
    padding: 10px 16px 10px 16px;
  }
  .el-range-separator {
    line-height: 36px;
  }
  .el-range-editor.el-input__inner {
    width: 365px;
    margin-left: 20px;
    padding: 0px 5px;
    height: 36px;
    line-height: 36px;
  }
  .el-select .el-input__inner {
    color: #475669;
    width: 108px;
    padding: 10px 16px 10px 16px;
    height: 36px;
    line-height: 36px;
  }
  .changIput {
    width: 180px;
    margin-left: 6px;
    .el-input__inner {
      height: 36px;
      line-height: 36px;
    }
  }
  .moreChoice {
    line-height: 36px;
    text-decoration: underline;
    color: #20a0ff;
    cursor: pointer;
    font-size: 13px;
    margin-left: 4px;
  }
}

.tableCell {
  padding: 0;
  table th {
    background-color: #e0e6ed;
    color: #475669;
    padding: 10px 0;
  }
  .operation {
    cursor: pointer;
    .opeatLeft {
      margin-right: 10px;
      i {
        font-size: 13px;
        padding-left: 3px;
        color: #20a0ff;
      }
    }
    .opeatCenter {
      i {
        font-size: 13px;
        padding-left: 3px;
        color: #20a0ff;
      }
    }
    .opeatRight {
      margin-left: 10px;
      i {
        font-size: 13px;
        padding-left: 3px;
        color: #20a0ff;
      }
    }
  }
}

.myQaSearch {
  h3 {
    padding: 12px 16px 12px 20px;
  }
  .el-row {
    margin: 0 20px;
  }
}
.myQaSearchModel .el-dialog .el-dialog__header {
  border-bottom: 0px solid #e0e6ed;
}

.myQaSearchModel .el-dialog__body .myQaSearch {
  border-top: 0px solid #e0e6ed;
}
</style>
