<template>
  <div class="recordingListWrap">
    <div class="header">
      <div class="left">
        <el-button class="goback-btn" @click="goBack">< 返回</el-button>
      </div>
      <div class="right">
        <el-button v-if="parentModel.persent !== '100%'" @click="showMultipleDetail" type="primary">批量打分</el-button>
      </div>
    </div>
    <div class="content">
      <div class="tableCell">
        <el-table
          border
          @select="changeSelectBox"
          ref="multipleTable"
          tootip-effect="dark"
          :data="tableData"
        >
          <el-table-column type="selection" width="55"></el-table-column>
          <el-table-column prop="callId" label="录音编号" width="200">
            <template scope="scope">
              <el-button
                type="text"
                @click="showDetail(scope.row.callId, scope.row.taskId, scope.row.recordFileURL)"
                >{{ scope.row.callId }}
              </el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="callSTime"
            :formatter="exeTimeFilter"
            label="录音时间"
          ></el-table-column>
          <el-table-column prop="callTime" label="通话时长（秒）"></el-table-column>
          <el-table-column prop="seatName" label="坐席姓名"></el-table-column>
          <el-table-column prop="score" label="质检结果">
            <template scope="scope">
              <div v-if="scope.row.taskStatus === 2">无</div>
              <div v-if="scope.row.secondTaskStatus === 1">
                {{ scope.row.secondQaScore }}
              </div>
              <div v-if="scope.row.firstTaskStatus === 1">
                {{ scope.row.firstQaScore }}
              </div>
            </template>
          </el-table-column>
          <el-table-column label="操作">
            <template scope="scope">
              <el-button
                v-if="scope.row.taskStatus === 2"
                type="text"
                @click="showDetail(scope.row.callId, scope.row.taskId, scope.row.recordFileURL)"
                >打分
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="autoGrading-page">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="singleWrap"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          :notScordList="this.notScordList"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import moment from 'moment'
import recordingplay from '../recordingPlay/recordingPlayMultiple.vue'
import bus from '../../common/bus.js'
// import formatdate from '../../../utils/formatdate.js'
import global from '../../../global.js'
let qualityUrl = global.qualityUrl
import Qs from 'qs'
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      currentPage: 1,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
      tableData: [],
      notScordList: [],
      tableNotScordList: [],
      istableBox: false,
      recordDialogVisible: false,
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
  methods: {
    handleSizeChange(val) {
      this.pageSize = val
      this.getList()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.getList()
    },
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    getList() {
      let params = {
        taskId: this.parentModel.taskId,
        type: this.parentModel.qaScoreType,
      }
      let self = this
      this.axios
        .post(
          qualityUrl +
            '/myTask/queryByTaskId.do?pagesize=' +
            this.pageSize +
            '&pageindex=' +
            this.currentPage,
          Qs.stringify(params)
        )
        .then(function(response) {
          self.total = response.data.count
          self.tableData = response.data.data
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '任务列表获取失败',
          })
        })
    },
    // 勾选传table选择数据
    changeSelectBox: function(val) {
      if (val != []) {
        console.log('1111')
        this.tableNotScordList = val
        this.istableBox = true
      } else {
        console.log('2222')
        this.istableBox = false
      }
    },
    // 批量打分
    showMultipleDetail() {
      this.getList()
      let _this = this
      let qaScoreType = this.parentModel.qaScoreType
      if (this.istableBox == false) {
        this.tableData.forEach(function(item) {
          if ((qaScoreType==1 && item.firstTaskStatus==2)||(qaScoreType==2 && item.secondTaskStatus==2)) {
            _this.notScordList.push(item)
          }
        })
      } else {
        this.tableNotScordList.forEach(function(item) {
          if ((qaScoreType==1 && item.firstTaskStatus==2)||(qaScoreType==2 && item.secondTaskStatus==2)) {
            _this.notScordList.push(item)
          }
        })
      }
      let notScoreList = {
        scoreList: this.notScordList,
        formPosition: 'multiple',
      }
      console.log('55555555')
      console.log(this.notScordList)
      console.log('55555555')
      this.$store.commit('setNotScoreList', notScoreList)
      let obj = {}
      obj.from = this.parentModel.from
      obj.callId = this.notScordList != 0 && this.notScordList[0].callId
      obj.recordFileURL = this.notScordList != 0 && this.notScordList[0].recordFileURL
      obj.taskId = this.notScordList != 0 && this.notScordList[0].taskId
      obj.qaScoreType = this.parentModel.qaScoreType
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
      this.notScordList = []
      this.istableBox = false
    },
    // 普通打分
    showDetail(id, taskId, recordFileURL) {
      let notScoreList = {
        formPosition: 'normal',
      }
      this.$store.commit('setNotScoreList', notScoreList)
      let obj = {}
      obj.from = this.parentModel.from
      obj.callId = id
      obj.recordFileURL = recordFileURL
      obj.taskId = taskId
      obj.qaScoreType = this.parentModel.qaScoreType
      this.$store.commit('setRecordingPlayPage', obj)
      //  this.$router.push('/recordingPlay')
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 关闭录音弹窗
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
      this.getList()
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    goBack() {
      this.$emit('toInitalTask')
    },
  },
  mounted() {},
  props: ['parentModel'],
  created() {
    this.getList()
    let that = this
    bus.$on('nextcall', function() {
      let callId = that.recordingPlayPage.callId
      let taskId = that.recordingPlayPage.taskId
      let recordFileURL = that.recordingPlayPage.recordFileURL
      that.showDetail(callId, taskId, recordFileURL)
    })
  },
}
</script>
<style lang="less" scoped="scoped">
.recordingListWrap {
  .header {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: center;
    padding: 10px 20px;
    box-sizing: border-box;
    .left {
      display: flex;
      flex: 1;
    }
    .right {
      display: flex;
      height: 100%;
      align-items: center;
    }
  }
  .content {
    padding: 0 20px;
    box-sizing: border-box;
    width: 100%;
    position: absolute;
    top: 60px;
    bottom: 60px;
    left: 0;
    right: 0;
    box-sizing: border-box;
    overflow: hidden;
    .tableCell {
      width: 100%;
      height: 100%;
      overflow: auto;
    }
  }
  .autoGrading-page {
    right: 10px;
    position: absolute;
    bottom: 10px;
  }
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
}
</style>
<style lang="less">
.el-dialog__wrapper.singleWrap {
  position: fixed;
  top: 106px;
  left: 20px;
  right: 20px;
  bottom: 12px;
  .el-dialog {
    width: 100%;
    height: 100%;
    margin: 0 !important;
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}

.el-button.goback-btn {
  padding: 0;
  margin: 0;
  border: none;
  font-size: 14px;
  color: #20a0ff;
}
</style>
