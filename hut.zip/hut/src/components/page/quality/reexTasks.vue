<template>
  <div style="height: 100%;width: 100%;">
    <div class="goBackmessage" v-if="peoTime">
      <div class="containTitle">复检任务</div>
      <div class="act-head searchForm toalSide">
        <el-form label-width="30px" :inline="true">
          <el-form-item>
            <div style="display: inline-block;">
              <el-select
                v-model="deaolTwotype"
                @change="contentChange"
                placeholder="请选择状态"
                style="margin-left: 19px;"
              >
                <el-option
                  v-for="item in taskType"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
              <el-button
                funcId="000411"
                style="margin-left: 6px;"
                @click="batchDeleteConfirm"
                >批量删除</el-button
              >
            </div>
            <div style="float:right;display: inline-block;">
              <div style="float:right;width: 100%">
                <el-date-picker
                  :clearable="true"
                  :editable="false"
                  v-model="searchTime"
                  type="datetimerange"
                  align="right"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  :default-time="['00:00:00', '23:59:59']"
                >
                </el-date-picker>
                <el-input
                  class="changIput"
                  v-model="projectName"
                  placeholder="任务名称"
                ></el-input>
                <el-button
                  @click="selectRobertProject"
                  type="primary"
                  style="margin-left: 7px;"
                  >查询</el-button
                >
                <a class="moreChoice" @click="moreCondition" style="margin-right: 15px;"
                  >更多条件搜索</a
                >
              </div>
            </div>
          </el-form-item>
        </el-form>
      </div>
      <div class="content">
        <div class="table">
          <div class="tableCell">
            <el-table
              border
              ref="multipleTable"
              tootip-effect="dark"
              @selection-change="handleSelectionChange"
              :data="projects"
            >
              <el-table-column type="selection" width="50"> </el-table-column>
              <el-table-column
                prop="projectName"
                :show-overflow-tooltip="true"
                label="任务名称"
                width="120"
              >
                <template scope="scope">
                  <el-button
                    type="text"
                    style="padding: 10px 0;"
                    @click="
                      showDetail(
                        scope.row.configId,
                        scope.row.projectName,
                        scope.row.taskType
                      )
                    "
                    >{{ scope.row.projectName }}
                  </el-button>
                </template>
              </el-table-column>
              <el-table-column prop="createUser" label="创建者" width="120">
              </el-table-column>
              <el-table-column
                prop="createTime"
                :formatter="exeTimeFilter"
                label="创建时间"
                width="180"
              >
              </el-table-column>
              <el-table-column prop="taskType" label="任务方式" width="150">
                <template scope="scope">
                  <el-tag close-transition v-if="scope.row.taskType == 1"
                    >系统抽样</el-tag
                  >
                  <el-tag close-transition v-if="scope.row.taskType == 2"
                    >人工抽样</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column prop="taskStatus" label="任务状态" width="120">
                <template scope="scope">
                  <el-tag close-transition type="gray" v-if="scope.row.taskStatus == null"
                    >未开始</el-tag
                  >
                  <el-tag
                    close-transition
                    type="primary"
                    v-if="scope.row.taskStatus == 'running'"
                    >运行中</el-tag
                  >
                  <el-tag
                    close-transition
                    type="primary"
                    v-if="scope.row.taskStatus == 'finished'"
                    >已完成</el-tag
                  >
                  <el-tag
                    close-transition
                    type="success"
                    v-if="scope.row.taskStatus == 'hanguping'"
                    >暂停</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column label="操作">
                <template scope="scope">
                  <div class="operation">
                    <i
                      class="opeatLeft"
                      v-if="scope.row.taskType == 1 && scope.row.taskStatus == 'running'"
                      ><i
                        funcId="000410"
                        @click="diableLoopTask(scope.row.configId)"
                        style="padding-left: 12px;"
                        >暂停</i
                      ></i
                    >
                    <i
                      funcId="000410"
                      class="opeatLeft"
                      v-if="
                        (scope.row.taskType == 1 &&
                          scope.row.taskStatus == 'hanguping') ||
                          scope.row.taskStatus == null
                      "
                      ><i
                        @click="tapeStart(scope.row.configId)"
                        style="padding-left: 12px;"
                        >开始</i
                      ></i
                    >
                    <i funcId="000409" class="opeatCenter" v-if="scope.row.taskType == 1"
                      ><i @click="copyProjectDialog(scope.row.configId)">复制</i></i
                    >
                    <i
                      funcId="000408"
                      class="opeatRight"
                      @click="
                        deleteProjectConfirm(scope.row.projectName, scope.row.configId)
                      "
                      ><i>删除</i></i
                    >
                  </div>
                </template>
              </el-table-column>
            </el-table>
            <el-dialog
              class="smellmodel speshow"
              :title="changeTitle"
              :visible.sync="exitSecond"
              width="740px"
              :before-close="closeAll"
              :close-on-click-modal="false"
            >
              <div class="dialogHeader" style="height: 150px;">
                <div style="width: 100%;">
                  <el-form
                    label-width="84px"
                    ref="oneForm"
                    :model="taskModel"
                    :rules="oneRules"
                  >
                    <div class="contentAlltitle">
                      <el-col :span="12">
                        <el-form-item label="任务名称" prop="projectNameCreate">
                          <el-input
                            v-model="taskModel.projectNameCreate"
                            placeholder="请输入任务名称"
                            style="width: 200px;"
                          ></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="12">
                        <el-form-item label="完成天数" prop="day">
                          <el-select v-model="taskModel.day">
                            <el-option
                              v-for="item in days"
                              :value="item.id"
                              :label="item.name"
                              :key="item.id"
                            >
                            </el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>
                      <el-col :span="12">
                        <el-form-item label="初检成绩" prop="firstQaScore_Min">
                          <el-col :span="8">
                            <el-input
                              v-model="taskModel.firstQaScore_Min"
                              placeholder="请输入"
                            ></el-input>
                          </el-col>
                          <el-col :span="2" style="text-align: center;"
                            ><span>-</span></el-col
                          >
                          <el-col :span="8">
                            <el-input
                              v-model="taskModel.firstQaScore_Max"
                              placeholder="请输入"
                            ></el-input>
                          </el-col>
                        </el-form-item>
                      </el-col>
                    </div>
                  </el-form>
                  <el-form label-width="84px">
                    <div style="padding: 0 20px 0 20px;">
                      <el-col :span="12">
                        <el-form-item label="致命项" prop="deadItem">
                          <el-select v-model="taskModel.deadItem" placeholder="请选择">
                            <el-option
                              v-for="item in deadAttrs"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value"
                            >
                            </el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>
                    </div>
                  </el-form>
                </div>
              </div>
              <div class="dealCenter" style="border-top: 1px solid #E0E6ED;">
                <el-form label-width="84px" style="margin-left: 20px">
                  <el-col :span="24">
                    <h3 style="padding: 12px 16px 12px 0px;">录音属性</h3>
                    <el-col :span="12">
                      <el-form-item label="通话时长">
                        <el-col :span="6">
                          <el-form-item prop="callTime_Min" style="margin-right: 0;">
                            <el-input v-model="taskModel.callTime_Min"></el-input>
                          </el-form-item>
                        </el-col>
                        <el-col class="line" :span="2" style="text-align: center;"
                          >-</el-col
                        >
                        <el-col :span="6">
                          <el-form-item prop="callTime_Max" style="margin-right: 0;">
                            <el-input v-model="taskModel.callTime_Max"></el-input>
                          </el-form-item>
                        </el-col>
                        <el-col class="line" :span="1">&nbsp;</el-col>
                        <el-col :span="8">
                          <el-form-item prop="timeType" style="margin-right: 0;">
                            <el-select v-model="taskModel.timeType">
                              <el-option
                                v-for="item in timecellAttrs"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value"
                              >
                              </el-option>
                            </el-select>
                          </el-form-item>
                        </el-col>
                      </el-form-item>
                    </el-col>
                  </el-col>
                </el-form>
                <my-comp ref="myComp" :fromFModel="fromFModel"></my-comp>
                <el-form
                  label-width="100px"
                  ref="threeForm"
                  :model="task2Form"
                  :rules="threeRules"
                >
                  <div class="audioTitle">
                    <h3>周期(天)</h3>
                  </div>
                  <div class="audioAttrsInputs" style="margin:0 20px;height: 55px;">
                    <el-col :span="12">
                      <el-form-item label="运行周期" prop="cycType">
                        <el-input v-model="task2Form.cycType"></el-input>
                      </el-form-item>
                    </el-col>
                    <el-col :span="12">
                      <el-form-item label="采集周期" prop="time">
                        <el-input v-model="task2Form.time"></el-input>
                      </el-form-item>
                    </el-col>
                  </div>
                  <div class="copyCell">
                    <div class="contentAlltitle">
                      <el-col :span="24">
                        <el-form-item label="请选择质检员" prop="checkQaUserList">
                          <el-select
                            v-model="task2Form.checkQaUserList"
                            @change="confirmAdd"
                            multiple
                          >
                            <el-option
                              v-for="item in qaUsers"
                              :value="item.account"
                              :label="item.realName"
                              :key="item.realName"
                            >
                            </el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>
                      <el-col :span="24">
                        <el-form-item label="抽样方式" prop="sampleMode">
                          <el-select
                            v-model="task2Form.sampleMode"
                            placeholder="随机抽样"
                          >
                            <el-option label="随机抽样" value="1">随机抽样</el-option>
                            <el-option label="平均抽样" value="0">平均抽样</el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>
                      <el-col :span="24">
                        <el-form-item label="抽取数" prop="techno">
                          <el-input
                            v-model="task2Form.techno"
                            placeholder="请填写抽取数"
                          ></el-input>
                        </el-form-item>
                      </el-col>
                    </div>
                  </div>
                </el-form>
                <div
                  class="footerAll"
                  style="width: 100%;border-top: 1px solid #E0E6ED;height: 68px;"
                >
                  <div
                    class="footInside"
                    style="float: right;height: 53px;padding-top: 15px"
                  >
                    <el-button @click="dispearNot">取 消</el-button>
                    <el-button
                      @click="taskCreateThrottle"
                      type="primary"
                      style="margin-right: 18px;"
                      >确 定</el-button
                    >
                  </div>
                </div>
              </div>
            </el-dialog>
            <el-dialog
              id="otherCss"
              class="smellmodel speshow"
              :visible.sync="moreChance"
              width="420px"
              :close-on-click-modal="false"
            >
              <div class="dealCenter" style="margin-top: 20px;">
                <el-form label-width="84px" ref="fourForm">
                  <el-form-item
                    label="任务状态"
                    style="padding-top: 20px;padding-left: 20px;margin-bottom: 0px;"
                  >
                    <el-select v-model="wedType" placeholder="任务状态">
                      <el-option
                        v-for="item in workType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                    label="任务方式"
                    style="padding-top: 20px;padding-left: 20px;margin-bottom: 0px;"
                  >
                    <el-select v-model="deaolType" placeholder="任务方式">
                      <el-option
                        v-for="item in taskType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-form>
              </div>
              <div
                class="footerAll"
                style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
              >
                <div
                  class="footInside"
                  style="float: right;height: 53px;padding-top: 15px"
                >
                  <el-button @click="dispearNot">取 消</el-button>
                  <el-button
                    @click="moreSearchTaskBtn"
                    type="primary"
                    style="margin-right: 18px;"
                    >查 询</el-button
                  >
                </div>
              </div>
            </el-dialog>
            <el-dialog
              class="smellmodel"
              :before-close="closeAll"
              title="新建复检任务-人工抽样"
              :visible.sync="artifSample"
              width="740px"
              :close-on-click-modal="false"
            >
              <pTasks
                v-on:send="sameShow"
                v-on:sendNext="sameSave"
                v-if="artifSample"
              ></pTasks>
            </el-dialog>
          </div>
        </div>
      </div>
      <div class="autoGrading-page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="pageSizes"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        >
        </el-pagination>
      </div>
    </div>
    <!-- 系统抽样详情页 -->
    <syTasks
      :message="this.parentModel.taskId"
      v-if="sysCell"
      v-on:sysAltill="sysTill"
    ></syTasks>
    <!-- 人工抽样详情页 -->
    <peoTasks
      :message="this.parentModel.taskId"
      v-if="peoCell"
      v-on:peoAltill="peoTill"
    ></peoTasks>
  </div>
</template>
<script>
import $ from 'jquery'
import pTasks from './peopleTwopling.vue'
import global from '../../../global.js'

import syTasks from './sysTack.vue'
import peoTasks from './peopleTack.vue'
import moment from 'moment'
import cache from '../../../utils/cache.js'
import Qs from 'qs'
import formatdate from '../../../utils/formatdate.js'
import mycompVue from './formEngine/mycomp.vue'
let currentBaseUrl = global.qualityUrl
let qinspectionUrl = global.currentBaseUrl
let qualityUrl = global.qualityUrl
export default {
  name: 'reexTasks',
  components: {
    pTasks,
    syTasks,
    peoTasks,
    myComp: mycompVue,
    // myComp: function(resolve, reject) {
    //   // 从表单引擎获取界面元素
    //   nativeaxios
    //     .post(
    //       global.formEngineUrl +
    //         '/creating.do?formIds=intellSampleYuangong,intellSampleYuyin&accessToken=' +
    //         cache.getItem('tgt_id')
    //     )
    //     .then(function(response) {
    //       $('body').append(response.data.Validate)
    //       let myHtml = response.data.Html
    //       resolve({
    //         template: myHtml,
    //         data() {
    //           return {
    //             seatGroupOptions: [], // 坐席组
    //             /* eslint-disable */
    //             intellSampleYuangong_intellSampleYuyin_Model: intellSampleYuangong_intellSampleYuyin_,
    //             intellSampleYuangong_intellSampleYuyin_Rules: intellSampleYuangong_intellSampleYuyin_Rules,
    //             /* eslint-enable */
    //           }
    //         },
    //         props: ['fromFModel'], // 父组件的
    //         watch: {
    //           // 监控父亲数据的变化 如果有个变化则更新表单的内容
    //           fromFModel: function() {
    //             // alert(this.fromFModel)
    //             this.intellSampleYuangong_intellSampleYuyin_Model = this.fromFModel
    //             // 删除表单的验证
    //           },
    //         },
    //         mounted() {
    //           this.getSeatGroupValue()
    //         },
    //         methods: {
    //           getSeatGroupValue() {
    //             let _this = this
    //             let url = qualityUrl + '/pageConstant/getValue.do'
    //             let searchParam = {}
    //             searchParam.keys = 'seatGroup'
    //             this.axios
    //               .post(url, Qs.stringify(searchParam))
    //               .then(function(response) {
    //                 _this.seatGroupOptions = response.data.seatGroup
    //               })
    //               .catch(function() {
    //                 _this.$message({
    //                   type: 'error',
    //                   message: '获取常量值出现问题',
    //                 })
    //               })
    //           },
    //         },
    //       })
    //     })
    // },
  },
  mounted: function() {
    let _this = this
    this.selectRobertProject() // 查询
    // 初始化模板和质检员
    this.axios
      .post(
        qualityUrl + '/manualQualityAssurance/getModleInfoByCondition.do',
        Qs.stringify({
          modleType: 7,
          pageindex: 1,
          pagesize: 20,
        })
      )
      .then(function(response) {
        let models = response.data.Data
        _this.modleS = models
      })
    // 获取当前登录的主管下的质检员
    this.axios.post(qualityUrl + '/distributeTask.do').then(function(response) {
      _this.qaUsers = response.data.Data
    })
  },
  data() {
    let checkName = (rule, value, callback) => {
      console.log(value)
      if (value.indexOf(' ') >= 0) {
        callback(new Error('请勿输入特殊字符'))
      }
      this.axios
        .post(
          currentBaseUrl + '/spc/sampleTaskNameIsExist.do',
          Qs.stringify({ projectName: value, sampleType: '2' })
        )
        .then(function(response) {
          if (response.data.Data == false) {
            callback(new Error('任务名称已存在'))
          } else {
            callback()
          }
        })
    }
    return {
      valye: true,
      changeTitle: '新建复检任务-系统抽样',
      currentPage: 1,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
      tableData: [],
      parentModel: {},
      modelList: [], // 模板id
      projects: [],
      modleId: '',
      wedType: '',
      deaolType: '',
      sysCell: false,
      peoCell: false,
      deaolTwotype: '',
      searchTime: [], // 搜索的时间
      projectName: '',
      templeateIds: [], // 质检模板列表
      currentDistribute: [], // 当前分配列表
      moreChance: false,
      peoTime: true,
      fromFModel: {},
      configs: [],
      exitSecond: false,
      artifSample: false,
      taskAttrRules: {
        // 任务属性验证
        projectName: [
          { required: true, message: '任务名称不能为空', trigger: 'blur' },
          { validator: checkName, trigger: 'blur' },
        ],
      },
      artifNextsample: false,
      taskType: [
        {
          label: '任务方式',
          value: '',
        },
        {
          label: '系统抽样',
          value: '1',
        },
        {
          label: '人工抽样',
          value: '2',
        },
      ],
      workType: [
        {
          label: '任务状态',
          value: '',
        },
        {
          label: '运行中',
          value: 'running',
        },
        {
          label: '已完成',
          value: 'finished',
        },
        {
          label: '暂停',
          value: 'hanguping',
        },
      ],
      deadAttrs: [
        {
          label: '是',
          value: '1',
        },
        {
          label: '否',
          value: '2',
        },
      ],
      taskModel: {
        projectNameCreate: '',
        day: '',
        taskType: '',
        sampleType: '',
        isShow: '',
        selectModel: '',
        deadItem: '',
        firstQaScore_Min: '',
        firstQaScore_Max: '',
        callTime_Min: '',
        callTime_Max: '',
        timeType: '0',
      },
      timecellAttrs: [
        {
          value: '0',
          label: '秒',
        },
        {
          value: '1',
          label: '分',
        },
        {
          value: '2',
          label: '时',
        },
      ],
      oneRules: {
        projectNameCreate: [
          {
            required: true,
            message: '请输入任务名称',
            trigger: 'blur',
          },
          { validator: checkName, trigger: 'blur' },
        ],
        firstQaScore_Min: [
          {
            required: true,
            message: '请输入初检成绩 ',
            trigger: 'blur',
          },
        ],
        day: [
          {
            required: true,
            message: '请选择完成天数！',
            trigger: 'change',
          },
        ],
        sampleType: [
          {
            required: true,
            message: '请选择抽样类型！',
            trigger: 'change',
          },
        ],
      },
      task2Form: {
        cycType: '',
        time: '',
        techno: '', // 日均抽样量
        checkQaUserList: [],
        sampleMode: '1',
      },
      threeRules: {
        sampleMode: [{ required: true, message: '请选择抽样方式', trigger: 'change' }],
        techno: [{ required: true, message: '请输入抽取数', trigger: 'blur' }],
        cycType: [{ required: true, message: '请输入运行周期', trigger: 'blur' }],
        time: [{ required: true, message: '请输入采集周期', trigger: 'blur' }],
        checkQaUserList: [
          { type: 'array', required: true, message: '请选择质检员', trigger: 'change' },
        ],
      },
      days: [
        { id: '1', name: '一天' },
        { id: '2', name: '二天' },
        { id: '3', name: '三天' },
        { id: '4', name: '四天' },
        { id: '5', name: '五天' },
        { id: '6', name: '六天' },
        { id: '7', name: '七天' },
      ],
      qaUsers: [],
      modleS: [{ a: 1, b: 2 }],
      TaskAttr: {
        projectName: '',
        deaolName: '',
        deaolType: '',
      },
      isSampleSearch: true,
    }
  },
  methods: {
    confirmAdd() {
      $('.el-select__tags')
        .children('span')
        .remove()
      if (this.task2Form.checkQaUserList.length >= 1) {
        $('.el-select__tags').append(
          '<span class="playuer">已选择' +
            this.task2Form.checkQaUserList.length +
            '人</span>'
        )
      }
      console.log(this.task2Form.checkQaUserList.length)
    },
    sameShow(input) {
      // 关闭新建任务的弹窗
      this.artifSample = input
      this.deaolTwotype = ''
      this.selectRobertProject()
    },
    sameSave(input) {
      // 关闭新建任务的弹窗
      this.artifNextsample = true
      setTimeout(() => {
        this.artifSample = input
      }, 200)
    },
    getbackNow: function() {
      this.$emit('send', true)
    },
    contentChange: function() {
      if (this.deaolTwotype == '1') {
        this.changeTitle = '新建复检任务-系统抽样'
        this.exitSecond = true
        this.$nextTick(() => {
          this.resetForm()
        })
      } else if (this.deaolTwotype == '2') {
        this.artifSample = true
      }
    },
    closeAll: function(done) {
      this.deaolTwotype = ''
      done()
    },
    sysTill(input) {
      this.peoTime = true
      this.sysCell = false
    },
    peoTill(input) {
      this.peoTime = true
      this.peoCell = false
    },
    resetForm() {
      let _this = this
      let myEnForm = this.$refs.myComp // 获取表单引擎组件引用
      let clusterClient = myEnForm.intellSampleYuangong_intellSampleYuyin_Model
      _this.searchAttr(clusterClient) // 清空数据
      this.$refs.oneForm.resetFields()
      this.$refs.threeForm.resetFields()
    },
    searchAttr(formId) {
      for (let item in formId) {
        if (typeof formId[item] == 'string') {
          formId[item] = ''
        } else if (formId[item] instanceof Array) {
          formId[item] = []
        } else if (typeof formId[item] == 'object') {
          for (let jtm in formId[item]) {
            formId[item][jtm] = ''
          }
        }
      }
    },
    dispearNot: function() {
      this.exitSecond = false
      this.artifSample = false
      this.artifNextsample = false
      this.moreChance = false
      this.deaolType = ''
      this.deaolTwotype = ''
    },
    taskCreateThrottle: function() {
      this.lodashThrottle.throttle(this.taskCreate, this)
    },
    clearCondition: function() {
      for (var prop in this['taskModel']) {
        if (this['taskModel'].hasOwnProperty(prop)) {
          this['taskModel'][prop] = ''
        }
      }
    },
    getParams(param, formId) {
      for (let item in formId) {
        if (item.indexOf('$CName') > -1) {
          continue
        }
        if (typeof formId[item] == 'string') {
          param[item] = formId[item]
        } else if (formId[item] instanceof Array) {
          if (formId[item].length == 2) {
            param[item + '_Min'] = formId[item][0]
            param[item + '_Max'] = formId[item][1]
          } else {
            param[item + '_Min'] = ''
            param[item + '_Max'] = ''
          }
        } else if (typeof formId[item] == 'object') {
          for (let jtm in formId[item]) {
            param[jtm] = formId[item][jtm]
          }
        }
      }
      return param
    },
    taskCreate() {
      let _this = this
      let myEnForm = this.$refs.myComp // 获取表单引擎组件引用
      let clusterClient = myEnForm.intellSampleYuangong_intellSampleYuyin_Model
      const params = {
        templeateId: this.taskModel.selectModel, // 模板id
        people: this.task2Form.checkQaUserList.join(','),
        day: this.taskModel.day,
        cycType: this.task2Form.cycType,
        time: this.task2Form.time,
        techno: this.task2Form.techno,
        sampleMode: this.task2Form.sampleMode,
        projectName: this.taskModel.projectNameCreate,
        firstQaScore_Min: this.taskModel.firstQaScore_Min,
        firstQaScore_Max: this.taskModel.firstQaScore_Max,
        deadItem: this.taskModel.deadItem,
        sampleType: '2',
        taskType: this.deaolTwotype,
        callTime_Min: this.taskModel.callTime_Min,
        callTime_Max: this.taskModel.callTime_Max,
        timeType: this.taskModel.timeType,
      }
      this.getParams(params, clusterClient)
      if (clusterClient['callSTime'] && clusterClient['callSTime'].length > 0) {
        if (clusterClient['callSTime'][0]) {
          clusterClient['callSTime_Min'] = moment(clusterClient['callSTime'][0]).format(
            'YYYY-MM-DD HH:mm:ss'
          )
        }

        if (clusterClient['callSTime'][1]) {
          clusterClient['callSTime_Max'] = moment(clusterClient['callSTime'][1]).format(
            'YYYY-MM-DD HH:mm:ss'
          )
        }
      }

      clusterClient.callTime_Max = this.taskModel.callTime_Max
      clusterClient.callTime_Min = this.taskModel.callTime_Min
      clusterClient.timeType = this.taskModel.timeType

      clusterClient['callSTime'] = null
      if (
        params.sampleType == '2' &&
        this.taskModel.firstQaScore_Min &&
        this.taskModel.firstQaScore_Max
      ) {
        clusterClient['score_Min'] = this.taskModel.firstQaScore_Min
        clusterClient['score_Max'] = this.taskModel.firstQaScore_Max
      }
      params.strategyObject = JSON.stringify(clusterClient)
      this.$refs.oneForm.validate(function(validate) {
        if (validate) {
          _this.$refs.threeForm.validate(function(validate) {
            if (validate) {
              _this.axios
                .post(qualityUrl + '/asc/addSysSampleConfig.do', Qs.stringify(params))
                .then(function(response) {
                  if (response.data) {
                    _this.selectRobertProject()
                    _this.exitSecond = false
                    _this.$message({
                      type: 'success',
                      message: '任务新建成功',
                    })
                    _this.deaolTwotype = ''
                    _this.task2Form.checkQaUserList = []
                    _this.confirmAdd()
                    _this.clearCondition()
                  } else {
                    _this.$message({
                      type: 'error',
                      message: '已存在相同名称的任务，请重新输入',
                    })
                  }
                })
                .catch(function() {
                  _this.$message({
                    type: 'error',
                    message: '任务新建失败',
                  })
                })
            }
          })
        }
      })
    },
    dealogNext: function() {
      this.exitSecond = true
    },
    /**
     * 开始任务
     * @param configId
     */
    tapeStart(configId) {
      let _this = this
      _this.updateStatus(configId, 'running', null)
      // this.startDialogVisible = false;
    },
    diableLoopTask(configId) {
      // alert(configId);
      let _this = this

      _this.updateStatus(configId, 'hanguping')
    },
    updateStatus(configId, status, taskTime) {
      let _this = this
      this.axios
        .post(
          qualityUrl + '/asc/updateStatus.do',
          Qs.stringify({
            configId: configId,
            status: status,
            taskTime: taskTime,
          })
        )
        .then(function(response) {
          if (response.data) {
            _this.selectRobertProject()
          }
        })
    },
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    /**
     * 删除任务确认框
     */
    deleteProjectConfirm(projectName, configId) {
      let _this = this
      _this
        .$confirm('确定要删除任务[' + projectName + ']', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
        })
        .then(() => {
          _this.deleteByConfigId(configId)
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    moreCondition: function() {
      this.moreChance = true
      this.wedType = ''
      this.deaolType = ''
    },
    // 删除任务
    deleteByConfigId(configId) {
      let _this = this
      let param = {}
      param.configId = configId
      this.axios
        .post(qualityUrl + '/asc/toDeal.do', Qs.stringify(param))
        .then(function(response) {
          if (response.data.Data) {
            _this.selectRobertProject()
            _this.$message({
              type: 'success',
              message: '任务删除成功',
            })
          }
        }) // 回调函数
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '任务删除失败',
          })
        })
    },

    /**
     * 选中的记录发生变化后
     * @param val
     */
    handleSelectionChange(val) {
      this.configs = val
    },
    handleSizeChange(val) {
      this.currentPage = 1
      this.pageSize = val
      if (this.isSampleSearch) {
        this.selectRobertProject()
      } else {
        this.moreChanceLittle()
      }
    },
    handleCurrentChange(val) {
      this.currentPage = val
      if (this.isSampleSearch) {
        this.selectRobertProject()
      } else {
        this.moreChanceLittle()
      }
    },
    showDetail(configId, flag, moatad) {
      let obj = { configId: configId }
      console.log(this.$router)
      console.log(moatad)
      this.$store.commit('setAssignView', obj)
      if (moatad == 1) {
        // this.$router.push({name: 'sysTaskdetail', params: {value: flag}})   // 获取路由并导到目标页面
        this.peoTime = false
        this.parentModel = {
          taskId: flag,
        }
        this.sysCell = true
      } else if (moatad == 2) {
        // this.$router.push({name: 'peTaskdetail', params: {value: flag}})   // 获取路由并导到目标页面
        this.peoTime = false
        this.parentModel = {
          taskId: flag,
        }
        this.peoCell = true
      }
    },
    copyProjectDialog(configId) {
      // 方案  异步组件引用父组件prop 子组件监视这个数据的变化
      let _this = this
      this.changeTitle = '复制复检任务-系统抽样'
      this.dialogButtonText = '复制'
      this.exitSecond = true

      // 异步组件  引用未能及时创建成功
      //  this.resetForm()
      this.axios
        .post(qualityUrl + '/asc/getConfigStrate.do?configId=' + configId)
        .then((response) => {
          let strate = response.data.strt // 策略
          let config = response.data.config
          // 回显
          // 固定表单
          let task2Form = {}
          let users = config.teamId
          if (users) {
            task2Form.checkQaUserList = users.split(',')
          }
          // 质检人员数组 teamId
          task2Form.cycType = config.cycType + ''
          task2Form.time = config.time + ''
          task2Form.techno = config.techno + ''
          task2Form.sampleMode = config.sampleMode
          _this.task2Form = task2Form

          // 重新赋值已选择质检员
          this.confirmAdd()

          let taskModel = {}
          taskModel.projectNameCreate = ''
          taskModel.day = config.afterwordsRes + ''
          taskModel.selectModel = config.qaModel + '' // 模板
          // taskModel.projectNameCreate = config.projectName
          taskModel.firstQaScore_Min = config.scoreMin
          taskModel.firstQaScore_Max = config.scoreMax
          taskModel.deadItem = config.deadItem
          taskModel.sampleType = config.sampleType
          _this.taskModel = taskModel

          // 表单引擎的表单
          if (strate) {
            let stratObj = JSON.parse(strate.strategyObject)

            taskModel.callTime_Min = stratObj.callTime_Min || ''
            taskModel.callTime_Max = stratObj.callTime_Max || ''
            taskModel.timeType = stratObj.timeType || ''

            _this.fromFModel = stratObj
            let arr = []
            if (_this.fromFModel['callSTime_Min']) {
              arr[0] = new Date(_this.fromFModel['callSTime_Min'])
            }
            if (_this.fromFModel['callSTime_Max']) {
              arr[1] = new Date(_this.fromFModel['callSTime_Max'])
            }
            _this.fromFModel.callSTime = arr
          }
        })
    },
    // 更多查询条件
    moreSearchTaskBtn() {
      this.currentPage = 1
      this.isSampleSearch = false
      this.moreChanceLittle()
    },
    moreChanceLittle: function() {
      // 查询更多条件
      let fromData = ''
      let toform = ''
      if (this.searchTime[0] != undefined && this.searchTime[0] != '') {
        fromData = formatdate.formatDate(this.searchTime[0])
      } else {
        // 默认获取当前月的第一天
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromData = formatdate.formatDate(now)
      }
      if (this.searchTime[1] != undefined && this.searchTime[1] != '') {
        toform = formatdate.formatDate(this.searchTime[1])
      } else {
        // 默认获取当前月的最后一天
        let now = new Date()
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toform = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      }
      this.searchTime = [fromData, toform]
      let params = {
        taskBeginTime: this.searchTime[0],
        taskEndTime: this.searchTime[1],
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        projectName: '%' + this.projectName + '%',
        sampleType: '2',
        taskType: this.deaolType,
        taskStatus: this.wedType,
      }
      console.log(params)
      let self = this
      this.axios
        .post(currentBaseUrl + '/asc/getAllSysSampleConfig.do', Qs.stringify(params))
        .then(function(response) {
          self.total = response.data.Count
          self.projects = response.data.Data
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '任务获取失败',
          })
        })
      this.moreChance = false
    },
    batchDelete(ids) {
      let _this = this

      this.axios
        .post(qualityUrl + '/asc/toDeal.do', Qs.stringify({ configId: ids }))
        .then(function(response) {
          if (response.data.Data) {
            _this.$message({
              type: 'info',
              message: '删除成功',
            })
            _this.selectRobertProject()
          }
        })
    },
    batchDeleteConfirm() {
      // 批量删除
      //
      let _this = this

      if (_this.configs.length < 1) {
        _this.$message({
          type: 'warning',
          message: '请选择要删除的任务',
        })
        return false
      }
      let names = []
      let ids = []
      _this.configs.forEach(function(item) {
        names.push(item.projectName)
        ids.push(item.configId)
      })
      let message = ''
      if (names.length <= 3) {
        message = names.join(',')
      } else {
        message = names.splice(0, 3).join(',') + '等' + names.length + '个配置！！'
      }
      _this
        .$confirm('确定要删除[' + message + ']?', '提示', {
          cancelButtonText: '取消',
          confirmButtonText: '确定',
          type: 'warning',
        })
        .then(function() {
          _this.batchDelete(ids.join(','))
        })
        .catch(function() {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    selectRobertProject() {
      let fromData = ''
      let toform = ''
      if (this.searchTime == null) {
        this.fromData = ''
        this.toform = ''
      } else {
        if (this.searchTime[0] != undefined && this.searchTime[0] != '') {
          fromData = formatdate.formatDate(this.searchTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromData = formatdate.formatDate(now)
        }
        if (this.searchTime[1] != undefined && this.searchTime[1] != '') {
          toform = formatdate.formatDate(this.searchTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toform = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchTime = [fromData, toform]
      let params = {
        taskBeginTime: this.searchTime[0],
        taskEndTime: this.searchTime[1],
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        projectName: '%' + this.projectName + '%',
        sampleType: '2',
      }
      console.log(params)
      let self = this
      this.axios
        .post(currentBaseUrl + '/asc/getAllSysSampleConfig.do', Qs.stringify(params))
        .then(function(response) {
          self.total = response.data.Count
          self.projects = response.data.Data
          self.filter()
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '任务获取失败',
          })
        })
      self.filter() // 过滤权限按钮
    },
    filter() {
      this.$emit('filterButton')
    },
  },
  created() {
    this.selectRobertProject()
  },
}
</script>
<style lang="less" scoped="scoped">
.goBackmessage {
  overflow: hidden;
  height: 100%;
  position: relative;
  .copyCell {
    width: 100%;
    height: 200px;
  }
  .containTitle {
    padding: 16px 0 13px 19px;
    font-size: 14px;
  }
  .content {
    padding-bottom: 150px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .autoGrading-page {
    right: 10px;
    position: absolute;
    bottom: 10px;
  }
  .table {
    width: 100%;
    height: 100%;
    overflow: auto;
  }
  .backPage {
    color: #20a0ff;
    padding: 19px 0 10px 18px;
    span {
      cursor: pointer;
    }
  }
  .el-button {
    width: 88px;
    padding: 10px 16px 10px 16px;
  }
}
.contentAlltitle {
  border-top: 1px solid #e0e6ed;
  padding: 20px 20px 0 20px;
}
.smellmodel {
  .contTitle {
    display: inline-block;
    padding: 12px 16px 12px 16px;
  }
  .titleLeftsmell {
    display: inline-block;
    padding: 12px 16px 12px 20px;
  }
  .dealCenter {
    width: 100%;
    border-top: 1px solid #e0e6ed;
    .audioTitle {
      display: inline-block;
    }
    .recordingCon {
      margin: 0 20px;
      height: 110px;
      border-bottom: 1px solid #e0e6ed;
    }
    .recordingLine {
      margin: 0 20px;
      height: 55px;
      border-bottom: 1px solid #e0e6ed;
    }
    .daigFial {
      padding: 12px 16px 12px 20px;
    }
  }
}
#cc .el-form-item__label {
  width: 100px;
}
</style>
<style lang="less">
.goBackmessage #otherCss .el-dialog__header {
  border-bottom: 0px solid #eee;
}
.playuer {
  padding-left: 15px;
  color: #1f2d3d;
}
.copyCell {
  .el-input__inner {
    height: 36px;
    line-height: 36px;
    width: 316px;
  }
}
.smellmodel .dealCenter .el-form-item {
  margin-right: 0px;
}
.searchForm {
  .el-form-item {
    margin-bottom: 16px;
  }
  .el-button {
    width: 88px;
    padding: 10px 16px 10px 16px;
  }
  .el-range-separator {
    line-height: 36px;
  }
  .el-range-editor.el-input__inner {
    width: 365px;
    margin-left: 20px;
    padding: 0px 5px;
    height: 36px;
    line-height: 36px;
  }
  .el-select .el-input__inner {
    color: #475669;
    width: 108px;
    padding: 10px 16px 10px 16px;
    height: 36px;
    line-height: 36px;
  }
  .changIput {
    width: 180px;
    margin-left: 6px;
    .el-input__inner {
      height: 36px;
      line-height: 36px;
    }
  }
  .moreChoice {
    line-height: 36px;
    text-decoration: underline;
    color: #20a0ff;
    cursor: pointer;
    font-size: 13px;
    margin-left: 4px;
  }
}
.tableCell {
  padding-left: 19px;
  padding-right: 30px;
  padding: 0 26px 0 19px;
  table th {
    background-color: #e0e6ed;
    color: #475669;
    padding: 10px 0;
  }
  .operation {
    cursor: pointer;
    .opeatLeft {
      margin-right: 10px;
      i {
        font-size: 13px;
        padding-left: 3px;
        color: #20a0ff;
      }
    }
    .opeatCenter {
      i {
        font-size: 13px;
        padding-left: 3px;
        color: #20a0ff;
      }
    }
    .opeatRight {
      margin-left: 10px;
      i {
        font-size: 13px;
        padding-left: 3px;
        color: #20a0ff;
      }
    }
  }
}
.difInput {
  width: 265px;
  height: 40px;
  margin-left: 20px;
  .el-input__inner {
    height: 36px;
    line-height: 36px;
  }
}
.dealCenter {
  h3 {
    padding: 12px 16px 12px 20px;
  }
  .el-row {
    margin: 0 20px;
  }
}
.finalyNext {
  border-top: 1px solid #e0e6ed;
  .el-form-item {
    margin: 10px 0 10px 20px;
    height: 40px;
    .el-input__inner {
      height: 36px;
      line-height: 36px;
    }
  }
}
.tableFindset {
  margin: 10px 20px;
}
</style>
