<template>
  <div>
    <div class="content">
      <el-form :model="paramForm" ref="paramForm" label-width="160px">
        <el-form-item label="二次申诉流程" prop="ReAppealFlag">
          <el-select placeholder="-请选择-" clearable v-model="paramForm.ReAppealFlag">
            <el-option label="启用" value="1">启用</el-option>
            <el-option label="停用" value="0">停用</el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="一次申诉组长审批" prop="FirstLeaderAprovFlag">
          <el-select
            placeholder="-请选择-"
            clearable
            v-model="paramForm.FirstLeaderAprovFlag"
          >
            <el-option label="启用" value="1">启用</el-option>
            <el-option label="停用" value="0">停用</el-option>
          </el-select>
        </el-form-item>
        <!-- <el-form-item label="二次申诉组长审批" prop="SecLeaderAprovFlag">
                <el-select placeholder="-请选择-"  :disabled="true" clearable v-model="paramForm.SecLeaderAprovFlag">
                <el-option label="启用" value="1">启用</el-option>
                <el-option label="停用" value="0">停用</el-option>
                </el-select>
            </el-form-item> -->
        <el-form-item label="组长驳回二次申诉" prop="LeaderRefuReAppealFlag">
          <el-select
            placeholder="-请选择-"
            :disabled="paramForm.ReAppealFlag == '0'"
            clearable
            v-model="paramForm.LeaderRefuReAppealFlag"
          >
            <el-option label="启用" value="1">启用</el-option>
            <el-option label="停用" value="0">停用</el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="footer">
        <el-button funcId="000076" type="primary" @click="saveEdit">确 定</el-button>
        <el-button funcId="000077" @click="reset">重 置</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import Qs from 'qs'
import global from '../../../global.js'
let qualityUrl = global.qualityUrl
export default {
  data() {
    return {
      paramForm: {
        ReAppealFlag: '',
        FirstLeaderAprovFlag: '',
        SecLeaderAprovFlag: '0',
        LeaderRefuReAppealFlag: '',
      },
    }
  },
  methods: {
    // 保存
    saveEdit: function() {
      this.lodashThrottle.throttle(this.saveParams, this)
    },
    saveParams: function() {
      let _this = this
      let params = {
        ReAppealFlag: _this.paramForm.ReAppealFlag,
        FirstLeaderAprovFlag: _this.paramForm.FirstLeaderAprovFlag,
        SecLeaderAprovFlag: _this.paramForm.SecLeaderAprovFlag,
        LeaderRefuReAppealFlag: _this.paramForm.LeaderRefuReAppealFlag,
      }
      if (
        params.ReAppealFlag.toString()
          .split(' ')
          .join('').length == 0
      ) {
        _this.$message({
          type: 'error',
          message: '参数不能为空！',
        })
        return
      }
      if (
        params.FirstLeaderAprovFlag.toString()
          .split(' ')
          .join('').length == 0
      ) {
        _this.$message({
          type: 'error',
          message: '参数不能为空！',
        })
        return
      }
      if (
        params.SecLeaderAprovFlag.toString()
          .split(' ')
          .join('').length == 0
      ) {
        _this.$message({
          type: 'error',
          message: '参数不能为空！',
        })
        return
      }
      if (
        params.LeaderRefuReAppealFlag.toString()
          .split(' ')
          .join('').length == 0
      ) {
        _this.$message({
          type: 'error',
          message: '参数不能为空！',
        })
        return
      }
      this.axios
        .post(qualityUrl + '/qualityParams/editParam.do', Qs.stringify(params))
        .then((res) => {
          if (res.data == true) {
            _this.$message({
              type: 'success',
              message: '修改参数成功！',
            })
          } else {
            _this.$message({
              type: 'error',
              message: '修改参数失败！',
            })
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    reset: function() {
      let _this = this
      _this.paramForm.ReAppealFlag = '1'
      _this.paramForm.FirstLeaderAprovFlag = '1'
      _this.paramForm.SecLeaderAprovFlag = '0'
      _this.paramForm.LeaderRefuReAppealFlag = '0'
      _this.saveEdit()
    },
    getParams: function() {
      let _this = this
      let params = {
        paramCodes:
          'ReAppealFlag,FirstLeaderAprovFlag,SecLeaderAprovFlag,LeaderRefuReAppealFlag',
      }
      this.axios
        .post(qualityUrl + '/qualityParams/getParamsVal.do', Qs.stringify(params))
        .then((res) => {
          _this.paramForm.ReAppealFlag = res.data.ReAppealFlag
          _this.paramForm.FirstLeaderAprovFlag = res.data.FirstLeaderAprovFlag
          _this.paramForm.SecLeaderAprovFlag = res.data.SecLeaderAprovFlag
          _this.paramForm.LeaderRefuReAppealFlag = res.data.LeaderRefuReAppealFlag
        })
        .catch(function(error) {
          console.log(error)
        })
    },
  },
  created() {
    this.getParams()
  },
  watch: {
    loadData(val, oldval) {},
  },
}
</script>
<style lang="less" scoped>
.content {
  overflow: auto;
  //position: absolute;
  left: 20;
  right: 0;
  bottom: 20px;
  padding: 40px 60px;
}
.footer {
  position: absolute;
  padding: 0px 80px;
}
input {
  ::-webkit-input-placeholder {
    text-align: right;
  }
}
</style>
