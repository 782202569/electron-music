<template>
  <div id="reviewTask" class="reviewTask">
    <el-row>
      <el-col :span="12" :class="hidden ? 'hidden' : ''">
        <div class="leftContent">
          <div class="searchHeader">
            <div style="float: right; margin-right: 10px">
              <el-button @click="resetForm('formInline')" style="width: 90px;"
                >清空</el-button
              >
              <el-button @click="statistics" style="width: 90px;">质检统计</el-button>
              <el-button type="primary" @click="searchTask" style="width: 90px;"
                >查询</el-button
              >
            </div>
          </div>
          <div class="searchForm">
            <el-form
              :label-position="labelPosition"
              :inline="true"
              :model="formInline"
              ref="formInline"
              label-width="80px"
            >
              <p>订单属性</p>
              <div style="padding: 10px;">
                <el-form-item label="订单编号" prop="orderNo_Like">
                  <el-input
                    v-model="formInline.orderNo_Like"
                    placeholder="请输入内容"
                  ></el-input>
                </el-form-item>
                <el-form-item label="订单状态" prop="orderState">
                  <el-select
                    clearable
                    @change="changeStatus"
                    v-model="formInline.orderState"
                    placeholder="请选择"
                    style="width: 175px;"
                  >
                    <el-option
                      v-for="item in options5"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="下单时间" prop="orderTime">
                  <el-date-picker
                    @change="orderChange"
                    v-model="formInline.orderTime"
                    type="datetimerange"
                    placeholder="选择时间范围"
                    align="right"
                  >
                  </el-date-picker>
                </el-form-item>
              </div>

              <p>坐席属性</p>
              <div style="padding: 10px;">
                <el-form-item label="提交人工号" prop="submiter">
                  <el-input
                    v-model="formInline.submiter"
                    placeholder="请输入内容"
                  ></el-input>
                </el-form-item>
                <el-form-item label="提交人姓名" prop="submiterName">
                  <el-input
                    v-model="formInline.submiterName"
                    placeholder="请输入内容"
                  ></el-input>
                </el-form-item>
                <el-form-item label="坐席组" prop="seatGroup">
                  <el-select
                    v-model="formInline.seatGroup"
                    placeholder="请选择"
                    clearable
                  >
                    <el-option
                      v-for="item in seatGroupList"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </div>

              <p>任务属性</p>
              <div style="padding: "></div>
              <el-form-item label="分发起始时间" prop="fenfaTime">
                <el-date-picker
                  @change="fenfaChange"
                  v-model="formInline.fenfaTime"
                  type="datetimerange"
                  :picker-options="fenfaOptions"
                  placeholder="选择时间范围"
                  align="right"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item label="计划完成起始时间" prop="planTime">
                <el-date-picker
                  @change="planChange"
                  v-model="formInline.planTime"
                  type="datetimerange"
                  :picker-options="planOptions"
                  placeholder="选择时间范围"
                  align="right"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item label="抽样类型" prop="taskType">
                <el-select
                  clearable
                  @change="changeType"
                  v-model="formInline.taskType_list"
                  placeholder="请选择"
                  style="width: 175px;"
                >
                  <el-option
                    v-for="item in options2"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="任务状态" prop="taskDetailStatus">
                <el-select
                  clearable
                  @change="change"
                  v-model="formInline.taskDetailStatus"
                  placeholder="请选择"
                  style="width: 175px;"
                >
                  <el-option
                    v-for="item in options3"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="是否逾期" prop="overDue">
                <el-select
                  clearable
                  v-model="formInline.overDue"
                  placeholder="请选择"
                  style="width: 175px;"
                >
                  <el-option
                    v-for="item in options4"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </el-col>
      <el-col :span="rightSpan">
        <div class="rightContent">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="tableBox">
            <div class="table" style="overflow: auto;padding:0px 10px;">
              <el-table
                :data="tableData"
                border
                highlight-current-row
                style="width: 100%"
              >
                <el-table-column fixed="left" prop="orderNo" label="订单编号">
                  <template scope="scope">
                    <el-button
                      type="text"
                      @click="
                        showDetail(
                          scope.row.orderNo,
                          scope.row.submiterName,
                          scope.row.submiter,
                          scope.row.recordFileURL
                        )
                      "
                      >{{ scope.row.orderNo }}</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="orderTime"
                  :formatter="dateFormat"
                  label="下单时间"
                >
                </el-table-column>
                <el-table-column
                  prop="endTime"
                  :formatter="dateFormat"
                  label="质检结束时间"
                >
                </el-table-column>
                <el-table-column prop="orderState" label="订单状态">
                  <template scope="scope">
                    <div v-if="scope.row.orderState === '1'">
                      <el-tag type="success">成功单</el-tag>
                    </div>
                    <div v-else="">
                      <el-tag type="primary">取消单</el-tag>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column prop="submiterName" label="提交人姓名">
                </el-table-column>
                <el-table-column prop="taskType" label="抽样类型">
                  <template scope="scope">
                    <div v-if="scope.row.taskType === '1'">
                      <el-tag type="success">人工抽样</el-tag>
                    </div>
                    <div v-else="">
                      <el-tag type="primary">系统抽样</el-tag>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column prop="taskDetailStatus" label="质检状态">
                  <template scope="scope">
                    <div v-if="scope.row.taskDetailStatus === '1'">
                      <el-tag type="success">已质检</el-tag>
                    </div>
                    <div v-else="">
                      <el-tag type="primary">未质检</el-tag>
                    </div>
                  </template>
                </el-table-column>
                <!--<el-table-column
                  prop="endTime"
                  sortable
                  :formatter="dateFormat"
                  label="截止时间">
                </el-table-column>-->
                <el-table-column prop="overDue" label="是否逾期">
                  <template scope="scope">
                    <i v-if="scope.row.overDue == '1'">是</i>
                    <i v-else="">否</i>
                  </template>
                </el-table-column>
                <el-table-column prop="score" label="质检分数"> </el-table-column>
                <el-table-column label="操作">
                  <template scope="scope">
                    <div style="cursor: pointer">
                      <i
                        v-if="scope.row.taskDetailStatus === '2'"
                        @click="
                          showDetail(
                            scope.row.orderNo,
                            scope.row.submiterName,
                            scope.row.submiter,
                            scope.row.recordFileURL
                          )
                        "
                        class="iconfont icon-jiancha"
                        style="font-size:14px"
                        ><i style="padding-left: 3px;">开始质检</i></i
                      >
                      <i
                        v-else=""
                        @click="lookDetail(scope.row.objectId, scope.row.recordFileURL)"
                        class="iconfont icon-jiancha"
                        style="font-size:14px"
                        ><i style="padding-left: 3px;">查看成绩</i></i
                      >
                    </div>
                  </template>
                </el-table-column>
              </el-table>
              <el-dialog
                title="质检任务统计"
                :visible.sync="statisticsModel"
              >
                <div style="margin-bottom:20px">
                  <el-form
                    style="width: 100%; overflow: hidden"
                    ref="formItem"
                    :model="formItem"
                    label-width="100px"
                  >
                    <el-form-item label="时间" style="float: right" prop="value1">
                      <el-date-picker
                        @change="changeTime2"
                        :picker-options="pickerOptions2"
                        v-model="formItem.value1"
                        type="daterange"
                        placeholder="选择日期范围"
                      >
                      </el-date-picker>
                      <el-button @click="search">查询</el-button>
                    </el-form-item>
                  </el-form>
                  <div id="echartImgBox" style="width: 100%; height:400px;">
                    <div id="echartImg" style="width: 100%; height:400px;"></div>
                  </div>
                </div>
              </el-dialog>
            </div>
            <div class="page">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageindex"
                :page-sizes="[20, 30, 40]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="recordingplay"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import axios from 'axios'
import Qs from 'qs'
axios.defaults.withCredentials = true
axios.defaults.headers = {
  'Content-Type': 'application/x-www-form-urlencoded ;charset=UTF-8',
}
import global from '../../../global.js'
let qualityUrl = global.qualityUrl
import formatdate from '../../../utils/formatdate.js'
import vPlayer from '../../common/player.vue'
import recordingplay from '../recordingPlayOrder/recordingPlayOrder.vue'
import bus from '../../common/bus.js'
const baseUrl = qualityUrl + '/'
let pageConstantUrl = baseUrl + 'pageConstant/getValue.do?keys=seatGroup'
export default {
  components: {
    vPlayer,
    recordingplay,
  },
  data() {
    return {
      labelPosition: 'right',
      recordDialogVisible: false,
      hidden: false, // 左侧部分是否隐藏
      options5: [
        {
          value: 1,
          label: '成功单',
        },
        {
          value: 2,
          label: '取消单',
        },
      ],
      options4: [
        {
          value: 1,
          label: '是',
        },
        {
          value: 0,
          label: '否',
        },
      ],
      options2: [
        {
          value: 1,
          label: '人工抽样',
        },
        {
          value: 2,
          label: '系统抽样',
        },
      ],
      options3: [
        {
          value: 1,
          label: '已质检',
        },
        {
          value: 2,
          label: '未质检',
        },
      ],
      value4: '',
      callOptions: {
        disabledDate(time) {},
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      planOptions: {
        disabledDate(time) {},
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      fenfaOptions: {
        disabledDate(time) {},
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      pickerOptions2: {
        disabledDate(time) {
          // return time.getTime() < Date.now() - 8.64e7;
        },
        /* shortcuts: [ {
              onClick(picker) {
               // const end = new Date();
                //const start = new Date();
                //start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
               // picker.$emit('pick', [start, end]);
              }
            }] */
      },
      option2Rate: {
        title: {
          text: '总数统计',
        },
        tooltip: {},
        legend: {
          right: 10,
          top: '45%',
          orient: 'vertical',
          data: ['完成录音', '待质检录音'],
        },
        xAxis: [
          {
            data: [],
          },
        ],
        yAxis: {},
        series: [
          {
            name: '完成录音',
            type: 'bar',
            stack: '广告',
            data: [],
            itemStyle: {
              normal: {
                color: '#50b4ff',
              },
            },
          },
          {
            name: '待质检录音',
            type: 'bar',
            data: [],
            stack: '广告',
            itemStyle: {
              normal: {
                color: '#40e0b0',
              },
            },
          },
        ],
      },
      tableData: [],
      seatGroupList: [], // 坐席组
      formInline: {
        submiter: '', // 坐席编号
        orderTime: '', // 下单时间
        fenfaTime: '', // 分发时间
        planTime: '', // 计划时间
        overDue: '',
        endTime_Min: '',
        orderNo_Like: '',
        orderState: '',
        submiterName: '',
        seatGroup: '',
        taskDetailStatus: 2,
        taskType: '',
      },
      pageindex: 1,
      pagesize: 20,
      totalCount: 0,
      selection: '',
      statisticsModel: false,
      formItem: {
        value1: '',
      },
      qaUser: '',
      fromDate: '',
      toDate: '',
      fFSDate: '',
      fFEndDate: '',
      pStartDate: '',
      pEndDate: '',
      cStartDate: '',
      cEndDate: '',
    }
  },
  computed: {
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
    reviewTaskPagesize() {
      return this.$store.state.reviewTaskPagesize.pagesize
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
  methods: {
    toggleContainer() {
      this.hidden = !this.hidden
    },
    showDetail(id, submiterName, submiter, recordFileURL) {
      let obj = {}
      obj.from = 'myQaTasksOrder' // 从我的质检任务的第一个tab页来
      obj.orderNo = id
      obj.recordFileURL = recordFileURL
      obj.pageId = 'orderSecQualityScore'
      obj.qaScoreType = 2
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlay')
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 查看成绩
    lookDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'myQaTasks' // 从我的质检任务的第一个tab页来
      obj.callId = id
      obj.recordFileURL = recordFileURL
      obj.qaScoreType = 1
      this.$store.commit('setRecordingPlayPage', obj)
      this.$router.push('/recordingPlay')
    },
    resetForm() {
      this.$refs.formInline.resetFields()
      this.formInline.taskDetailStatus = ''
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.searchOrderReTask()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.searchOrderReTask()
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // 将数字转换为时分秒

    // 将录音时长转换为秒
    dateFormatTwo(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    searchTask: function() {
      this.searchOrderReTask()
    },
    change: function(val) {
      this.formInline.taskDetailStatus = val
    },
    changeType: function(val) {
      this.formInline.taskType = val
    },
    changeData: function(val) {
      this.formInline.callSDate = val
    },
    changeStatus: function(val) {
      this.formInline.orderState = val
    },
    getSeatGroupList: function() {
      let self = this
      this.axios.post(pageConstantUrl).then(function(response) {
        self['seatGroupList'] = response.data.seatGroup
      })
    },
    // 截取分发时间
    fenfaChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.fFSDate = fdata
      this.fFEndDate = edata
    },
    // 关闭录音弹窗
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    // 录音播放页面 点击最小化触发
    toMinDialog: function(playInfo) {
      if (playInfo.isMaximization === false) {
        this.showVplayer = false
        let play = {}
        play.isMaximization = false
        play.exist = true
        this.$store.commit('setPlayerInfo', play)
      }
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 截取计划时间
    planChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.pStartDate = fdata
      this.pEndDate = edata
    },
    // 下单时间
    orderChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.oStartDate = fdata
      this.oEndDate = edata
    },
    callChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.cStartDate = fdata
      this.cEndDate = edata
    },
    changeTime2: function(val) {
      let fdata = val.substring(0, 10)
      let edata = val.substring(13, 23)
      /* if(fdata==edata){
           fdata=fdata+" 00:00:00"
           edata=edata+" 23:59:59"
         } */
      this.fromDate = fdata
      this.toDate = edata
    },
    changeTime: function(val) {
      this.formInline.callETime = val
      if (this.formInline.callETime < this.formInline.callSDate) {
        this.$message({
          type: 'warning',
          message: '结束时间要大于开始时间',
        })
      }
    },
    search: function() {
      if (this.fromDate == '') {
      } else {
        $('#echartImg').show()
        const self = this
        let params = {
          qaUser: this.qaUser,
          type: '1',
          fromDate: this.fromDate,
          toDate: this.toDate,
        }
        this.axios
          .post(qualityUrl + '/orderTaskManager/staQa.do', Qs.stringify(params))
          .then((res) => {
            if (res.data) {
              // console.log(res.data.done);
              // 对象转换为数组
              let arr = []
              for (let i in res.data.done) {
                let str = i + ':' + res.data.done
                arr.push(str.substring(8, 10))
              }

              let todo = res.data.todo
              let todoArr = JSON.stringify(todo).split(',')
              let todoResult = []
              for (let a = 0; a < todoArr.length; a++) {
                todoResult.push(todoArr[a].replace('}', '').split(':')[1])
              }
              this.option2Rate.series[1].data = todoResult

              let done = res.data.done
              let testArr = JSON.stringify(done).split(',')
              let result = []
              for (let i = 0; i < testArr.length; i++) {
                result.push(testArr[i].replace('}', '').split(':')[1])
              }
              // console.log(testArr,result);
              this.option2Rate.series[0].data = result

              let options = null
              this.option2Rate.xAxis[0].data = arr
              options = self.option2Rate

              let myChart = self.$echarts.init(document.getElementById('echartImg'))
              myChart.setOption(options)
            } else {
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    // 质检统计
    statistics: function() {
      this.statisticsModel = true
    },
    statisticsSave: function() {
      this.statisticsModel = false
      this.formItem.value1 = ''
      this.fromDate = ''
      this.toDate = ''
      $('#echartImg').hide()
    },
    canel: function() {
      this.statisticsModel = false
      this.formItem.value1 = ''
      this.fromDate = ''
      this.toDate = ''
      $('#echartImg').hide()
    },
    // 复检任务
    searchOrderReTask: function() {
      let params = {
        assignTime_Min: this.fFSDate,
        assignTime_Max: this.fFEndDate,
        orderTime_Min: this.oStartDate,
        orderTime_Max: this.oEndDate,
        endTime_Min: this.pStartDate,
        endTime_Max: this.pEndDate,
        submiter: this.formInline.submiter,
        seatGroup: this.formInline.seatGroup,
        overDue: this.formInline.overDue,
        orderNo_Like: this.formInline.orderNo_Like,
        submiterName: this.formInline.submiterName,
        orderState: this.formInline.orderState,
        taskDetailStatus: this.formInline.taskDetailStatus,
        taskType: this.formInline.taskType,
        orderByClause: 'END_TIME asc',
      }

      let obj = {}
      obj.searchModel = {}
      obj.searchModel.queryString = this.formInline
      this.$store.commit('setRecordingPlayPage', obj)

      this.axios
        .post(
          qualityUrl +
            '/orderTaskManager/searchOrderReTask.do?pagesize=' +
            this.pagesize +
            '&pageindex=' +
            this.pageindex,
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data.Count > 0) {
            this.tableData = res.data.TapInfo
            this.totalCount = res.data.Count
          } else {
            this.tableData = []
            this.totalCount = 0
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
  },
  created() {
    this.getSeatGroupList()
    if (
      this.recordingPlayPage.fromPage == 'myQaTasks' &&
      this.recordingPlayPage.qaScoreType == '1' &&
      this.recordingPlayPage.searchModel.queryString
    ) {
      this.formInline = this.recordingPlayPage.searchModel.queryString
      this.searchOrderReTask()
    } else if (
      this.recordingPlayPage.fromPage == 'myQaTasks' &&
      this.recordingPlayPage.qaScoreType == '1'
    ) {
      this.searchOrderReTask()
    }
    let obj = {}
    obj.pagesize = 10
    this.$store.commit('setReviewTaskPagesize', obj)
  },
}
</script>
<style lang="less">
.reviewTask {
  .operation {
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
  .recordingplay {
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
}
</style>
<style scoped="scoped" lang="less">
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
.reviewTask {
  .rightContent {
    height: 100%;
    width: 100%;
    box-sizing: border-box;
    position: relative;
    .tableBox {
      padding-top: 8px;
      padding-bottom: 80px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      .table {
        width: 100%;
        height: 100%;
      }
      .page {
        right: 10px;
        position: absolute;
        bottom: 10px;
      }
    }
  }
  .toggle-show {
    position: absolute;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggleBtn {
    cursor: pointer;
    width: 20px;
    height: 30px;
    background-image: url('../../../assets/img/close.png');
    position: absolute;
    left: -20px;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggle-hidden {
    left: 0px;
    transform: rotate(180deg);
  }
  .leftContent {
    height: 100%;
    overflow: auto;
    left: 0px;
    top: 0px;
    position: relative;
    border-right: 1px solid #d1dbe5;
    .searchHeader {
      border-bottom: 1px dashed #d1dbe5;
      position: absolute;
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      position: absolute;
      top: 0px;
      left: 0px;
      width: 100%;
    }
    .searchForm {
      position: absolute;
      top: 65px;
      left: 0px;
      bottom: 0px;
      overflow: auto;
      width: 100%;
      cursor: pointer;
      p {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        font-weight: bold;
        color: #9dadc2;
      }
    }
  }
  .el-row {
    height: 100%;
    .el-col {
      height: 100%;
    }
  }
}
#reviewTask div {
  box-sizing: border-box;
}
#reviewTask {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
}
</style>
<style>
#reviewTask .el-dialog--small {
  width: 65% !important;
}
#reviewTask .hidden {
  display: none;
}
</style>
