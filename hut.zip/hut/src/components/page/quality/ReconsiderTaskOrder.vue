<template>
  <div id="reviewTask" class="reviewTask">
    <el-row>
      <el-col :span="12" :class="hidden ? 'hidden' : ''">
        <div class="leftContent">
          <div class="searchHeader">
            <div style="float: right; margin-right: 10px">
              <el-button @click="resetFormThree">清空</el-button>
              <el-button type="primary" @click="searchReconTask">查询</el-button>
            </div>
          </div>
          <div class="searchForm">
            <el-form
              :inline="true"
              :model="formInlineThree"
              ref="formInlineThree"
              label-width="80px"
            >
              <p>订单属性</p>
              <div style="padding: 10px;">
                <el-form-item label="订单编号" prop="orderNo_Like">
                  <el-input
                    v-model="formInlineThree.orderNo_Like"
                    placeholder="请输入内容"
                  ></el-input>
                </el-form-item>
                <el-form-item label="订单状态" prop="orderState">
                  <el-select
                    clearable
                    @change="changeStatus"
                    v-model="formInlineThree.orderState"
                    placeholder="请选择"
                    style="width: 175px;"
                  >
                    <el-option
                      v-for="item in options5"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="下单时间" prop="orderTime">
                  <el-date-picker
                    @change="orderChange"
                    v-model="formInlineThree.orderTime"
                    type="datetimerange"
                    placeholder="选择时间范围"
                    align="right"
                  >
                  </el-date-picker>
                </el-form-item>
              </div>
              <p>坐席属性</p>
              <div style="padding: 10px;">
                <el-form-item label="提交人工号" prop="submiter">
                  <el-input
                    v-model="formInlineThree.submiter"
                    placeholder="请输入内容"
                  ></el-input>
                </el-form-item>
                <el-form-item label="提交人姓名" prop="submiterName">
                  <el-input
                    v-model="formInlineThree.submiterName"
                    placeholder="请输入内容"
                  ></el-input>
                </el-form-item>
                <el-form-item label="坐席组" prop="seatGroup">
                  <el-select
                    v-model="formInlineThree.seatGroup"
                    placeholder="请选择"
                    clearable
                  >
                    <el-option
                      v-for="item in seatGroupList"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </div>
              <p>任务属性</p>
              <div style="padding: 10px">
                <el-form-item label="申诉起始时间" prop="apTime">
                  <el-date-picker
                    @change="fenfaChange"
                    v-model="formInlineThree.apTime"
                    :picker-options="fenfaOptions"
                    type="datetimerange"
                    placeholder="选择时间范围"
                    align="right"
                  >
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="复议起始时间" prop="beginTime">
                  <el-date-picker
                    @change="planChange"
                    v-model="formInlineThree.beginTime"
                    type="datetimerange"
                    placeholder="选择时间范围"
                    align="right"
                  >
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="申诉类型" prop="reconStatus">
                  <el-select
                    clearable
                    v-model="formInlineThree.reconStatus"
                    placeholder="请选择"
                    style="width: 175px;"
                  >
                    <el-option
                      v-for="item in options3"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="复议状态" prop="reconStatus">
                  <el-select
                    clearable
                    v-model="formInlineThree.reconStatus"
                    placeholder="请选择"
                    style="width: 175px;"
                  >
                    <el-option
                      v-for="item in options3"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </div>
      </el-col>
      <el-col :span="rightSpan">
        <div class="rightContent">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="tableBox">
            <div class="table" style="overflow: auto;padding:0px 10px;">
              <el-table
                :data="tableData"
                border
                highlight-current-row
                style="width: 100%"
              >
                <el-table-column fixed="left" prop="OrderNo" label="订单编号">
                  <template scope="scope">
                    <el-button type="text" @click="showDetail(scope.row.orderNo, scope.row.recordFileURL)">{{
                      scope.row.orderNo
                    }}</el-button>
                  </template>
                </el-table-column>
                <el-table-column
                  prop="orderTime"
                  :formatter="dateFormat"
                  label="下单时间"
                >
                </el-table-column>
                <el-table-column
                  prop="orderState"
                  :formatter="dateFormatTwo"
                  label="订单状态"
                >
                </el-table-column>
                <el-table-column prop="submiterName" label="提交人姓名">
                </el-table-column>
                <el-table-column prop="userName" label="质检员"> </el-table-column>
                <el-table-column
                  prop="appealTime"
                  :formatter="dateFormat"
                  label="申诉时间"
                >
                </el-table-column>
                <el-table-column prop="apealType" label="申诉类型">
                  <template scope="scope">
                    <div v-if="scope.row.apealType === 1">
                      <el-tag type="success">人工抽样</el-tag>
                    </div>
                    <div v-else="">
                      <el-tag type="primary">系统抽样</el-tag>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column prop="reTaskStatus" label="复议状态">
                  <template scope="scope">
                    <div v-if="scope.row.reTaskStatus === 1">
                      <el-tag type="success">已完成</el-tag>
                    </div>
                    <div v-else="">
                      <el-tag type="primary">未完成</el-tag>
                    </div>
                  </template>
                </el-table-column>
                <!--<el-table-column
                  prop="endTime"
                  sortable
                  :formatter="dateFormat"
                  label="截止时间">
                </el-table-column>-->
                <el-table-column prop="score" label="质检得分"> </el-table-column>
                <el-table-column label="操作">
                  <template scope="scope">
                    <div style="cursor: pointer">
                      <i
                        v-if="scope.row.taskStatus === 2"
                        @click="showDetail(scope.row.objectId, scope.row.recordFileURL)"
                        class="iconfont icon-jiancha"
                        style="font-size:14px"
                        ><i style="padding-left: 3px;">开始质检</i></i
                      >
                      <i
                        v-else=""
                        @click="lookDetail(scope.row.objectId)"
                        class="iconfont icon-jiancha"
                        style="font-size:14px"
                        ><i style="padding-left: 3px;">查看成绩</i></i
                      >
                    </div>
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="page">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageindex"
                :page-sizes="[20, 30, 40]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import axios from 'axios'
import Qs from 'qs'
import global from '../../../global.js'
axios.defaults.withCredentials = true
axios.defaults.headers = {
  'Content-Type': 'application/x-www-form-urlencoded ;charset=UTF-8',
}
let qualityUrl = global.qualityUrl
let pageConstantUrl = qualityUrl + '/pageConstant/getValue.do?keys=seatGroup'
import formatdate from '../../../utils/formatdate.js'
export default {
  data() {
    return {
      callOptions: {
        disabledDate(time) {},
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      planOptions: {
        disabledDate(time) {},
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      // 下单时间
      orderChange: function(val) {
        let fdata = val.substring(0, 19)
        let edata = val.substring(22, 41)
        this.oStartDate = fdata
        this.oEndDate = edata
      },
      // 将录音时长转换为秒
      dateFormatTwo(x, y, callTime) {
        let needConvert = callTime && callTime != 'null'
        return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
      },
      change: function(val) {
        this.formInline.taskStatus = val
      },
      fenfaOptions: {
        disabledDate(time) {},
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      labelPosition: 'right',
      hidden: false, // 左侧部分是否隐藏
      options5: [
        {
          value: 1,
          label: '成功单',
        },
        {
          value: 2,
          label: '取消单',
        },
      ],
      options3: [
        {
          value: 2,
          label: '未完成',
        },
        {
          value: 1,
          label: '已完成',
        },
      ],
      value4: '',
      tableData: [],
      formInlineThree: {
        reconStatus: '',
        callingNo: '',
        number: '',
        orderNo_Like: '',
        seatGroup: '',
        submiterName: '',
        calledNo: '',
        seatGroup_listtemp: '',
        seatGroup_list: '',
        twoQaUser_String: '',
        twoQaUser: '',
        apTime: '',
        callSTime: '',
        assignTime: '',
        beginTime: '',
      },
      pageindex: 1,
      pagesize: 10,
      totalCount: 0,
      selection: '',
      formItem: {
        value1: '',
      },
      qaUser: '',
      fromDate: '',
      toDate: '',
      seatGroupList: [], // 坐席组
      fFSDate: '',
      fFEndDate: '',
      pStartDate: '',
      pEndDate: '',
      cStartDate: '',
      cEndDate: '',
    }
  },
  created() {
    this.getSeatGroupList()
    if (
      this.recordingPlayPage.fromPage == 'myQaTasks' &&
      this.recordingPlayPage.qaScoreType == 3 &&
      this.recordingPlayPage.searchModel.queryString
    ) {
      // this.currentPage = this.recordingPlayPage.searchModel.pageNumber
      // this.pageSize = this.recordingPlayPage.searchModel.pageSize
      this.formInlineThree = this.recordingPlayPage.searchModel.queryString
      this.searchReconTask()
    } else {
      this.searchReconTask()
    }
  },
  computed: {
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
  methods: {
    // 截取分发时间
    fenfaChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.fFSDate = fdata
      this.fFEndDate = edata
    },
    // 截取计划时间
    planChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.pStartDate = fdata
      this.pEndDate = edata
    },
    callChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.cStartDate = fdata
      this.cEndDate = edata
    },
    changeStatus: function(val) {
      this.formInline.orderState = val
    },
    toggleContainer() {
      this.hidden = !this.hidden
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    showDetail(id, reTaskId, recordFileURL) {
      let obj = {}
      obj.from = 'myQaTasks'
      obj.callNo = id
      obj.recordFileURL = recordFileURL
      obj.reTaskId = reTaskId
      obj.qaScoreType = 3
      this.$store.commit('setRecordingPlayPage', obj)
      this.$router.push('/recordingPlay')
    },
    changeItem: function(val) {
      this.formInlineThree.seatGroup_list = val
    },
    resetFormThree: function() {
      this.$refs.formInlineThree.resetFields()
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.searchReconTask()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.searchReconTask()
    },
    searchTask: function() {
      this.searchReconTask()
    },
    changeMinTime: function(val) {
      this.formInlineThree.assignTime_Min = val
    },
    changeMaxTime: function(val) {
      this.formInlineThree.assignTime_Max = val
      if (this.formInlineThree.assignTime_Max < this.formInlineThree.assignTime_Min) {
        this.$message({
          type: 'warning',
          message: '结束时间要大于开始时间',
        })
      }
    },
    getSeatGroupList: function() {
      let self = this
      this.axios.post(pageConstantUrl).then(function(response) {
        self['seatGroupList'] = response.data.seatGroup
      })
    },
    changeBeginTime: function(val) {
      this.formInlineThree.beginTime_Min = val
    },
    changeEndTime: function(val) {
      this.formInlineThree.beginTime_Max = val
      if (this.formInlineThree.beginTime_Max < this.formInlineThree.beginTime_Min) {
        this.$message({
          type: 'warning',
          message: '结束时间要大于开始时间',
        })
      }
    },
    changeAptime_Max: function(val) {
      this.formInlineThree.apTime_Max = val
      if (this.formInlineThree.apTime_Max < this.formInlineThree.apTime_Min) {
        this.$message({
          type: 'warning',
          message: '结束时间要大于开始时间',
        })
      }
    },
    changeAptime_Min: function(val) {
      this.formInlineThree.apTime_Min = val
    },
    // 复议任务
    searchReconTask: function() {
      let params = {
        reconStatus: this.formInlineThree.reconStatus, // 复议状态
        orderNo_Like: this.formInlineThree.orderNo_Like,
        submiterName: this.formInlineThree.submiterName,
        seatGroup_listtemp: '',
        seatGroup: this.formInlineThree.seatGroup,
        seatGroup_list: this.formInlineThree.seatGroup_list,
        twoQaUser_String: this.formInlineThree.twoQaUser_String,
        twoQaUser: this.formInlineThree.twoQaUser,
        apTime_Min: this.fFSDate,
        apTime_Max: this.fFEndDate,
        callSTime_Min: this.cStartDate,
        callSTime_Max: this.cEndDate,
        // assignTime_Min:this.formInlineThree.assignTime_Min,
        // assignTime_Max:this.formInlineThree.assignTime_Max,
        beginTime_Min: this.pStartDate,
        beginTime_Max: this.pEndDate,
        // orderByClause:'END_TIME asc'
      }
      let obj = {}
      obj.searchModel = {}
      obj.searchModel.queryString = this.formInlineThree
      this.$store.commit('setRecordingPlayPage', obj)
      this.axios
        .post(
          qualityUrl +
            '/taskManage/searchReconsiderTask.do?pagesize=' +
            this.pagesize +
            '&pageindex=' +
            this.pageindex,
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data.Count > 0) {
            this.tableData = res.data.TapInfo
            this.totalCount = res.data.Count
          } else {
            this.tableData = []
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
  },
}
</script>
<style scoped="scoped" lang="less">
.reviewTask {
  .rightContent {
    height: 100%;
    width: 100%;
    box-sizing: border-box;
    position: relative;
    .tableBox {
      padding-top: 8px;
      padding-bottom: 80px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      .table {
        width: 100%;
        height: 100%;
      }
      .page {
        right: 10px;
        position: absolute;
        bottom: 10px;
      }
    }
  }
  .toggle-show {
    position: absolute;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggleBtn {
    cursor: pointer;
    width: 20px;
    height: 30px;
    background-image: url('../../../assets/img/close.png');
    position: absolute;
    left: -20px;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggle-hidden {
    left: 0px;
    transform: rotate(180deg);
  }
  .leftContent {
    height: 100%;
    overflow: auto;
    left: 0px;
    top: 0px;
    position: relative;
    border-right: 1px solid #d1dbe5;
    .searchHeader {
      border-bottom: 1px dashed #d1dbe5;
      position: absolute;
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      position: absolute;
      top: 0px;
      left: 0px;
      width: 100%;
    }
    .searchForm {
      position: absolute;
      top: 65px;
      left: 0px;
      bottom: 0px;
      overflow: auto;
      width: 100%;
      cursor: pointer;
      p {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        font-weight: bold;
        color: #9dadc2;
      }
    }
  }
  .el-row {
    height: 100%;
    .el-col {
      height: 100%;
    }
  }
}
#reviewTask div {
  box-sizing: border-box;
}
#reviewTask {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
}
</style>
<style>
#reviewTask .el-dialog--small {
  width: 65% !important;
}
#reviewTask .hidden {
  display: none;
}
</style>
