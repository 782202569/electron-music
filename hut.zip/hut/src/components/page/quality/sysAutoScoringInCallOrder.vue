<template>
  <div style="width: 100%; height: 100%">
    <div class="sysAutoScoringInCall">
      <div class="sysAutoHeader">
        <div class="operation">
          <div class="searchForm">
            <el-form :inline="true">
              <el-form-item>
                <el-input v-model="projectName" placeholder="请输入配置名称"></el-input>
              </el-form-item>
              <el-form-item>
                <el-date-picker
                  v-model="searchTime"
                  type="datetimerange"
                  placeholder="选择时间范围"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="selectRobertProject">查询</el-button>
              </el-form-item>
              <el-form-item v-if="false">
                <el-button @click="showScoreChart">自动打分统计</el-button>
              </el-form-item>
              <el-form-item>
                <el-button @click="newTask">新建</el-button>
              </el-form-item>
              <el-form-item>
                <el-button @click="batchDeleteConfirm">批量删除</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <div class="sysAutoContent">
        <div class="sysAutoContent-table" style="overflow: auto;">
          <el-table
            rel="qualityTable"
            border
            highlight-current-row
            :data="projects"
            @selection-change="handleSelectionChange"
            style="width: 100%"
          >
            <el-table-column type="selection" width="55"> </el-table-column>
            <el-table-column prop="projectName" label="配置名称"> </el-table-column>
            <el-table-column prop="createUser" sortable label="创建人"> </el-table-column>
            <el-table-column
              prop="createTime"
              :formatter="createTimeFilter"
              sortable
              label="创建时间"
            >
            </el-table-column>
            <el-table-column prop="status" width="100" label="启动状态">
              <template scope="scope">
                <el-tag close-transition type="success" v-if="scope.row.status == 1"
                  >运行中</el-tag
                >
                <el-tag close-transition type="gray" v-if="scope.row.status == 3"
                  >已完成</el-tag
                >
                <el-tag close-transition type="danger" v-if="scope.row.status == 2"
                  >停止</el-tag
                >
              </template>
            </el-table-column>
            <el-table-column prop="finshCount" width="110" label="已质检数量">
            </el-table-column>
            <el-table-column prop="satisfyStatus" width="120" label="上次质检数量">
            </el-table-column>
            <el-table-column label="操作" width="280">
              <template scope="scope">
                <i
                  class="iconfont icon-222"
                  style="cursor:pointer;margin-right:8px;"
                  @click="diableTask(scope.row.robertProjectId, scope.row.projectName)"
                  v-if="scope.row.status == 1"
                  ><i style="font-family:'微软雅黑';margin-left:4px;font-size:14px"
                    >暂停</i
                  ></i
                >
                <i
                  class="el-icon-caret-right"
                  style="cursor:pointer;margin-right:10px;"
                  @click="startTask(scope.row.robertProjectId, scope.row.projectName)"
                  v-if="scope.row.status == 2"
                  ><i style="font-family:'微软雅黑';margin-left:4px;">开始</i></i
                >
                <i
                  class="el-icon-caret-right"
                  style="cursor:pointer;margin-right:10px;color:#bfcbd9"
                  v-if="scope.row.status == 3"
                  ><i style="font-family:'微软雅黑';margin-left:4px;color:#bfcbd9"
                    >开始</i
                  ></i
                >
                <i
                  class="el-icon-document"
                  style="cursor:pointer;margin-right:10px;"
                  @click="copyProject(scope.row)"
                  ><i style="font-family: '微软雅黑';margin-left:4px;">复制</i></i
                >
                <i
                  class="el-icon-close"
                  style="cursor:pointer;margin-right:10px;font-size:12px;"
                  @click="
                    deleteProjectConfirm(scope.row.projectName, scope.row.robertProjectId)
                  "
                  ><i style="font-family: '微软雅黑';margin-left:5px;font-size:14px;"
                    >删除</i
                  ></i
                >
                <i
                  class="iconfont icon-chakan"
                  style="cursor:pointer;margin-right:10px;"
                  @click="showDetail(scope.row.robertProjectId)"
                  ><i style="font-family: '微软雅黑';margin-left:4px;font-size:14px"
                    >查看</i
                  ></i
                >
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="sysAutoContent-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <!--新建任务弹出层-->
    <el-dialog
      id="newTaskdialog"
      title="新建任务"
      :close-on-click-modal="false"
      :visible.sync="dialogVisible"
    >
      <vTask v-on:send="closenewTask" v-if="dialogVisible"></vTask>
    </el-dialog>
    <!--复制任务、编辑任务弹出层-->
    <el-dialog
      id="editTaskdialog"
      title="复制任务"
      :close-on-click-modal="false"
      :visible.sync="copyDialogVisible"
    >
      <vTask
        v-on:send="closeCopyTask"
        v-if="copyDialogVisible"
        :projectModel="projectModel"
      ></vTask>
    </el-dialog>
    <!--自动打分统计弹出层-->
    <el-dialog
      id="chart"
      title="自动打分统计"
      :close-on-click-modal="false"
      :visible.sync="chartDialogVisible"
    >
      <div class="chartCondition">
        <el-form :inline="true">
          <el-form-item>
            <el-col :span="11">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                v-model="startTime"
                style="width: 100%;"
              ></el-date-picker>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                v-model="endTime"
                style="width: 100%;"
              ></el-date-picker>
            </el-col>
          </el-form-item>
          <el-form-item>
            <el-button type="success" @click="getTaskStats">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
      <div id="chart_container">
        <p>
          暂无数据
        </p>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import vTask from './OrderNewTask.vue'
import Qs from 'qs'
import moment from 'moment'
import global from '../../../global.js'
let currentBaseUrl = global.qualityUrl
let taskBaseUrl = global.taskBaseUrl
export default {
  components: {
    vTask,
  },
  data() {
    return {
      currentPage: 1,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      projects: [],
      searchTime: [], // 搜索的时间
      projectName: '',
      projectsSelected: [], // 选中的任务
      dialogVisible: false,
      copyDialogVisible: false,
      chartDialogVisible: false, // 自动打分统计
      startTime: '', // 自动打分统计
      endTime: '', // 自动打分统计
    }
  },
  methods: {
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    // 表格中选中项变化时执行的方法
    handleSelectionChange(val) {
      this.projectsSelected = val
    },
    // 查询系统自动评分
    selectRobertProject() {
      let statrDate = this.gettimeform(this.searchTime[0])
      let stopDate = this.gettimeform(this.searchTime[1])
      let params = {
        statrDate: statrDate,
        stopDate: stopDate,
        currentPage: this.currentPage,
        pageSize: this.pageSize,
        projectName: this.projectName,
      }
      let self = this
      this.axios
        .post(
          currentBaseUrl + '/autoorderscore/selectRobertProject.do',
          Qs.stringify(params)
        )
        .then(function(response) {
          self.total = response.data.Count
          self.projects = response.data.Data
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '任务获取失败',
          })
        })
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let hours = date.getHours()
      if (hours < 10) {
        hours = '0' + hours
      }
      let minute = date.getMinutes()
      if (minute < 10) {
        minute = '0' + minute
      }
      let second = date.getSeconds()
      if (second < 10) {
        second = '0' + second
      }
      let str = year + '-' + month + '-' + day + ' ' + hours + ':' + minute + ':' + second
      return str
    },
    createTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    // 新建按钮时间
    newTask() {
      this.dialogVisible = true
      this.projectModel = null
    },
    // 删除一个智能项目
    deleteProject(id) {
      let _this = this
      let params = {}
      params.robertProjectId = id
      this.axios
        .post(
          currentBaseUrl + '/autoorderscore/removeRobertProject.do',
          Qs.stringify(params)
        )
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '任务删除成功',
            })
            _this.selectRobertProject()
          } else {
            return Promise.reject(response)
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '任务删除失败',
          })
        })
    },
    // 删除确认
    deleteProjectConfirm(name, id) {
      let _this = this
      _this
        .$confirm('确定要任务[' + name + ']?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
        .then(() => {
          _this.deleteProject(id)
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 批量删除确认
    batchDeleteConfirm() {
      let _this = this
      if (_this.projectsSelected.length < 1) {
        _this.$message({
          type: 'warning',
          message: '请选择要删除的任务',
        })
        return false
      }
      let names = []
      let ids = []
      _this.projectsSelected.forEach(function(item) {
        names.push(item.projectName)
        ids.push(item.robertProjectId)
      })
      let msg = ''
      if (names.length <= 3) {
        msg = names.join(',')
      } else {
        msg = names.slice(0, 3).join(',') + '等' + names.length + '个项目'
      }
      _this
        .$confirm('确定要删除[' + msg + ']?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
        .then(() => {
          _this.deleteProject(ids.join(','))
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // input=>是否关闭弹窗（true or false，flag=> 有任务执行时是否成功('success' or 'failed')
    closenewTask(input, flag) {
      // 关闭新建任务的弹窗
      this.dialogVisible = input
      if (flag === 'success') {
        this.selectRobertProject()
      }
    },
    // 复制一个任务
    copyProject(row) {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/ivsStrategy/getStrategyById.do',
          Qs.stringify({
            strategyId: row.robertProjectId,
          })
        )
        .then(function(response) {
          _this.projectModel = response.data
          _this.projectModel.modleId = row.modleId
          _this.projectModel.operationperiod = row.operationperiod
          _this.projectModel.collectionperiod = row.collectionperiod
          _this.copyDialogVisible = true
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取任务详情失败',
          })
        })
    },
    // 查看策略详情
    showDetail(strategyId) {
      let Strategy = {}
      Strategy.strategyId = strategyId
      this.$store.commit('setStrategy', Strategy)
      this.$router.push('/sysAutoScoringInCallOrderResult')
    },
    // 关闭复制任务弹窗
    closeCopyTask(input, flag) {
      // 关闭新建任务的弹窗
      this.copyDialogVisible = input
      if (flag === 'success') {
        this.selectRobertProject()
      }
    },
    // 暂停任务
    diableTask(id, name) {
      let _this = this
      let params = {}
      params = JSON.stringify({
        pauseId: id,
        pauseTaskName: name,
      })
      let config = {
        headers: {
          'Content-Type': 'application/json;charset=UTF-8',
        },
      }
      this.axios
        .post(taskBaseUrl + '/taskInfo/taskPause.do', params, config)
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '任务暂停成功',
            })
            _this.selectRobertProject()
          } else {
            return Promise.reject(response)
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '任务暂停失败',
          })
        })
    },
    // 开始任务任务
    startTask(id, name) {
      let _this = this
      let params = {}
      params = JSON.stringify({
        startTaskId: id,
        startTaskName: name,
      })
      let config = {
        headers: { 'Content-Type': 'application/json;charset=UTF-8' },
      }
      this.axios
        .post(taskBaseUrl + '/taskInfo/startTask.do', params, config)
        .then(function(response) {
          if (response.data.status) {
            _this.$message({
              type: 'success',
              message: '任务开始成功',
            })
            _this.selectRobertProject()
          } else if (response.data.msg) {
            _this.$message({
              type: 'error',
              message: '任务开始失败',
            })
          }
        })
    },
    // 显示自动打分统计弹出层
    showScoreChart() {
      this.chartDialogVisible = true
      // this.getTaskStats()
    },
    // 查看图表
    lookChart(chartObj) {
      let _this = this
      let option = {
        tooltip: {
          trigger: 'axis',
        },
        grid: {
          top: '3%',
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: [],
          splitLine: {
            show: true,
          },
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // }
        },
        series: [
          {
            name: '样本数量',
            type: 'line',
            stack: '总量',
            data: [],
            itemStyle: {
              normal: {
                color: '#50b4ff',
              },
            },
          },
        ],
      }
      let xAxis = []
      let yAxis = []
      if (chartObj && chartObj.length > 0) {
        chartObj.forEach(function(item) {
          xAxis.push(item.TIME)
          yAxis.push(item.COUNT)
        })
      }
      option.xAxis.data = xAxis
      option.series[0].data = yAxis
      this.$nextTick(function() {
        let chart = _this.$echarts.init(document.querySelector('#chart_container'))
        chart.setOption(option)
      })
    },
    // 获取图标数据
    getTaskStats() {
      let startTime = this.gettimeform(this.startTime, 'todata')
      let endTime = this.gettimeform(this.endTime, 'todata')
      let params = {
        startTime: startTime,
        endTime: endTime,
        projectId: this.projectId,
      }
      let self = this
      this.axios
        .post(global.baseUrl + '/itFilter/getTaskStats.do', Qs.stringify(params))
        .then(function(response) {
          if (response.data && response.data.length > 0) {
            self.lookChart(response.data)
          }
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '图标数据获取失败',
          })
        })
    },
  },
  created() {
    this.selectRobertProject()
  },
  watch: {
    currentPage() {
      this.selectRobertProject()
    },
    pageSize() {
      this.selectRobertProject()
    },
  },
}
</script>
<style lang="less">
.operation {
  .el-form-item {
    div.el-form-item__content {
      vertical-align: middle;
    }
  }
}
</style>
<style scoped="scoped" lang="less">
@boder-color: #d1dbe5;
.sysAutoScoringInCall {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .operation {
    height: 55px;
    line-height: 55px;
    position: relative;
    border-bottom: 1px dashed @boder-color;
    padding-right: 10px;
    .el-form-item {
      margin-bottom: 0px;
      .el-form-item__content {
        line-height: 55px;
      }
    }
    & > div {
      display: inline-block;
      text-align: right;
      button {
        width: 115px;
      }
      &.searchForm {
        position: absolute;
        right: -10px;
        div.el-form-item__content {
          vertical-align: middle !important;
          border: 1px solid red;
        }
      }
    }
  }
}

.sysAutoScoringInCall .sysAutoHeader {
  float: left;
  box-sizing: border-box;
  top: 0px;
  width: 100%;
  height: 58px;
}

.sysAutoScoringInCall .sysAutoContent {
  padding-top: 68px;
  padding-bottom: 50px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}

.sysAutoScoringInCall .sysAutoContent .sysAutoContent-table {
  width: 100%;
  height: 100%;
}

.sysAutoScoringInCall .sysAutoContent .sysAutoContent-page {
  right: 10px;
  position: absolute;
  bottom: 10px;
}

.chartCondition {
  text-align: center;
}

#chart_container {
  width: 600px;
  height: 400px;
  margin: 0 auto;
}
</style>
