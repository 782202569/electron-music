<template>
  <div class="myQCTask" id="myQCTask">
    <div class="myQCTask-box">
      <div class="myQCTask-box-nav">
        <ul>
          <li data-id="1" @click="taskActive" class="active">初检任务</li>
          <li data-id="2" @click="taskActive">复检任务</li>
          <li data-id="3" @click="taskActive">复议任务</li>
        </ul>
      </div>
      <div class="myQCTask-box-content">
        <vInitialITaskOrder
          style="width:100%;height:100%;"
          v-show="index == 1"
        ></vInitialITaskOrder>
        <vReviewTaskOrder style="width:100%;height:100%;" v-show="index == 2">
        </vReviewTaskOrder>
        <vReconsiderTaskOrder
          style="width:100%;height:100%;"
          v-show="index == 3"
        ></vReconsiderTaskOrder>
      </div>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import vInitialITaskOrder from './InitialITaskOrder.vue' // 初检任务
import vReviewTaskOrder from './ReviewTaskOrder.vue' // 复检任务
import vReconsiderTaskOrder from './ReconsiderTaskOrder.vue' // 复议任务
export default {
  components: {
    vInitialITaskOrder,
    vReviewTaskOrder,
    vReconsiderTaskOrder,
  },
  data() {
    return {
      index: '1',
    }
  },
  methods: {
    taskActive: function() {
      let currentIndex = $(event.target).attr('data-id')
      this.index = currentIndex
      $('.myQCTask-box-nav ul li').removeClass('active')
      $(event.target).addClass('active')
    },
  },
  mounted() {
    if (
      this.recordingPlayPage.fromPage == 'myQaTasks' &&
      this.recordingPlayPage.qaScoreType
    ) {
      let index = this.recordingPlayPage.qaScoreType - 1
      // 控制三个tab页的展示1=》初检任务，2=》复检任务，3=》复议任务
      $('.myQCTask-box-nav > ul> li')[index].click()
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.myQCTask {
  width: 100%;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .myQCTask-box {
    width: 100%;
    height: 100%;
    position: relative;
    ul {
      width: 100%;
      padding: 0 12.5px;
      box-sizing: border-box;
      .active {
        color: #21a2ff !important;
      }
      li {
        float: left;
        padding: 0 12.5px;
        box-sizing: border-box;
        font-size: 14px;
        color: #96a2b2;
        cursor: pointer;
      }
    }
    .myQCTask-box-content {
      padding-top: 42px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .myQCTask-box-nav {
      width: 100%;
      height: 40px;
      line-height: 40px;
      background: #eef1f6;
      border-bottom: 1px solid #d1dbe4;
      position: absolute;
    }
  }
}
</style>
<style>
#myQCTask .el-tabs__active-bar {
  background: none;
}
</style>
