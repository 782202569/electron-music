<template>
  <div id="soundfeature" style="overflow: hidden;">
    <div style="overflow-y: auto;height: 100%">
      <div style="width: 100%;">
        <div style="padding: 10px 20px 0 50px;height: 50px;line-height: 50px;">
          <div style="font-size: 14px;font-weight: bold;display: inline-block;">
            任务完成情况统计
          </div>
          <div style="display: inline-block;float: right;">
            <el-form :inline="true" class="fr">
              <el-form-item style="margin-top: 5px;">
                <el-select
                  @change="clickDin"
                  v-model="formRight.regions"
                  clearable
                  placeholder="请选择质检员"
                >
                  <el-option
                    v-for="item in treeMenu"
                    :value="item.value"
                    :label="item.label"
                    :key="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-date-picker
                v-model="searchForm.findTimer"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                align="right"
                @change="clickDin"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 375px;"
              >
              </el-date-picker>
              <el-button
                plain
                style="position: relative;margin-left: 10px;"
                @click="exportTask(formRight.regions)"
                >导出</el-button
              >
            </el-form>
          </div>
        </div>
        <div
          id="mainAminte"
          class="soundfeature-pos-content"
          style="width: 100%;height:320px;"
        ></div>
      </div>
      <div id="setSanjiao" class="content contentButt">
        <div class="table">
          <div
            style="padding: 20px 20px 0 20px;font-size: 14px;color: #1F2D3D;font-weight: 700;"
          >
            {{ detail }}详情
            <el-button
              plain
              style="padding: 10px 20px;float: right;position: relative;top: -5px;"
              @click="exportQaUser(formRight.regions)"
              >导出</el-button
            >
          </div>
          <div style="padding: 20px;">
            <el-table
              :data="tableData"
              border
              ref="multipleTable"
              tootip-effect="dark"
              @selection-change="handleSelectionChange"
            >
              <el-table-column prop="name" label="质检员姓名"></el-table-column>
              <el-table-column prop="count" label="已完成录音">
                <template scope="scope">
                  <el-button type="text" @click="taskDetail(scope.row.name)">{{
                    scope.row.count
                  }}</el-button>
                </template>
              </el-table-column>
              <el-table-column prop="nocount" label="未完成录音"></el-table-column>
            </el-table>
          </div>
        </div>
        <div style="height: 40px;text-align: right;" class="speshow">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
        <div
          style="height: 40px;line-height: 40px;font-size: 14px;color: #1F2D3D;margin-top: 10px;border-top: 1px solid #d1dbe4;padding: 0 20px;"
        >
          共完成{{ count }}通录音评分 : {{ firstCount }}条初检评分,
          {{ secondCount }}条复检评分
        </div>
        <div class="soundfeature-pos edealcell">
          <div class="soundfeature-pos-nav">
            <ul>
              <li
                data-id="1"
                @click="toggleSound"
                class="soundfeatureActive"
                style="margin-left:34px;"
              >
                初检
              </li>
              <li data-id="2" @click="toggleSoundTable">复检</li>
            </ul>
            <el-button
              plain
              style="padding: 10px 20px;float: right;margin-right: 20px;"
              @click="exportTaskDetail(formRight.regions)"
              >导出</el-button
            >
          </div>
          <div class="table" v-show="primaTable" style="margin: 10px 20px;">
            <div>
              <el-table
                :data="detailfirstData"
                border
                ref="multipleTable"
                tootip-effect="dark"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"></el-table-column>
                <el-table-column prop="callId" label="录音编号">
                  <template scope="scope">
                    <el-button
                      type="text"
                      @click="jumpToSound(scope.row.callId, scope.row.firstTaskId, 1)"
                      >{{ scope.row.callId }}</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="callSTime"
                  :formatter="dateFormat"
                  label="录音时间"
                  width="180"
                >
                </el-table-column>
                <el-table-column prop="callTime" label="通话时长"> </el-table-column>
                <el-table-column prop="firstQaUserName" label="质检员"></el-table-column>
                <el-table-column prop="seatName" label="坐席姓名"></el-table-column>
                <el-table-column prop="seatGroup" label="坐席组"></el-table-column>
                <el-table-column prop="firstQaScore" label="初检成绩"> </el-table-column>
                <el-table-column prop="firstDeadItem" label="是否致命">
                  <template scope="scope">
                    <i v-if="scope.row.firstDeadItem == 1">是</i>
                    <i v-else>否</i>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div
            v-show="primaTable"
            style="height: 40px;text-align: right;"
            class="speshow"
          >
            <el-pagination
              @size-change="handleSizeChange1"
              @current-change="handleCurrentChange1"
              :current-page="currentPage1"
              :page-sizes="pageSizes1"
              :page-size="pageSize1"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total1"
            >
            </el-pagination>
          </div>

          <div class="table" v-show="!primaTable" style="margin: 10px 20px;">
            <div>
              <el-table
                :data="detailsecondData"
                border
                ref="multipleTable"
                tootip-effect="dark"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"></el-table-column>
                <el-table-column prop="callId" label="录音编号">
                  <template scope="scope">
                    <el-button
                      type="text"
                      @click="jumpToSound(scope.row.callId, scope.row.secondTaskId, 2)"
                      >{{ scope.row.callId }}</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="callSTime"
                  :formatter="dateFormat"
                  label="录音时间"
                  width="180"
                >
                </el-table-column>
                <el-table-column prop="callTime" label="录音时长"> </el-table-column>
                <el-table-column prop="secondQaUserName" label="质检员"></el-table-column>
                <el-table-column prop="seatName" label="坐席姓名"></el-table-column>
                <el-table-column prop="seatGroup" label="坐席组"></el-table-column>
                <el-table-column prop="secondQaScore" label="复检成绩"> </el-table-column>
                <el-table-column prop="firstDeadItem" label="是否致命">
                  <template scope="scope">
                    <i v-if="scope.row.secondDeadItem == 1">是</i>
                    <i v-else>否</i>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div
            v-show="!primaTable"
            style="height: 40px;text-align: right;"
            class="speshow"
          >
            <el-pagination
              @size-change="handleSizeChange2"
              @current-change="handleCurrentChange2"
              :current-page="currentPage2"
              :page-sizes="pageSizes2"
              :page-size="pageSize2"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total2"
            >
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="single"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        >
        </recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import global from '@/global'
import $ from 'jquery'
import formatdate from '../../../utils/formatdate.js'
import Qs from 'qs'
import bus from '../../common/bus.js'
import recordingplay from '../recordingPlay/recordingPlayMultiple.vue'
import commonUtil from '../../../utils/commonUtil.js'
let qualityUrl = global.qualityUrl
// let obj = ''
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      props: { value: 'id', label: 'name', children: 'child' },
      nav: { value: 'id', label: 'name', children: 'child' },
      showTree: false, // 树的显示隐藏
      mateLate: false,
      index: 0,
      primaTable: true,
      month: '',
      day: '',
      detailArray: [],
      treeMenu: [], // 树菜单
      defaultProps: {
        value: 'id',
        children: 'child',
        label: 'name',
      },
      formRight: {
        region: '',
        regions: '',
        name: '',
        times: [],
      },
      searchForm: {
        callSTime: [],
        findTimer: [],
        lastTimer: [],
        score_Min: '',
        score_Max: '',
        deadItem: '2',
        objectId: '',
        seatName: '',
        seatGroup: [],
        drapingRow: [],
      },
      option: {
        color: ['#3398DB'],
        grid: {
          show: true,
          left: '5%',
          top: '15%',
          containLabel: true,
          borderWidth: 0,
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
        },
        legend: {},
        dataZoom: [
          {
            type: 'slider',
            show: true,
            xAxisIndex: [0],
            start: 1,
            end: 30,
            height: '5%',
            showDetail: false,
            bottom: 30,
          },
          {
            type: 'inside',
            xAxisIndex: [0],
            start: 1,
            end: 30,
            height: '5%',
          },
        ],
        xAxis: {
          splitLine: {
            show: false,
            lineStyle: '#3398DB',
          },
          type: 'category',
          data: [],
          axisTick: {
            alignWithLabel: true,
          },
          name: '日期',
          nameTextStyle: {
            color: '#1F2D3D',
            fontSize: 14,
            borderColor: '#3398DB',
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#C0CCDA',
              width: 1.5,
            },
          },
          axisLabel: {
            textStyle: {
              color: '#1F2D3D',
            },
          },
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: false,
          },
          name: '录音数',
          nameTextStyle: {
            color: '#1F2D3D',
            fontSize: 14,
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#C0CCDA',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#1F2D3D',
            },
          },
        },
        series: [
          {
            name: '已完成',
            type: 'bar',
            barGap: 0,
            label: {
              normal: {
                show: true,
                position: 'top',
                color: '#a3a3a3',
              },
            },
            itemStyle: {
              normal: {
                color: '#0092ff',
                /* color: function (param) {
                    let fromTime = ''
                    let toTime = ''
                    if (obj.searchForm.findTimer != null && obj.searchForm.findTimer != '') {
                      fromTime = obj.searchForm.findTimer[0]
                      toTime = obj.searchForm.findTimer[1]
                    }
                    let nd = new Date()
                    let fm = new Date(fromTime).getMonth()
                    let nm = new Date().getMonth()
                    let fd = new Date(fromTime)
                    let d = ''
                    let m = ''
                    let flag = Date.parse(fromTime) < Date.parse(nd) && Date.parse(nd) < Date.parse(toTime)
                    if (flag) {
                      m = nm + 1
                      if (fd.getDate() == nd.getDate()) {
                        d = nd.getDate()
                      } else {
                        d = nd.getDate() - 1
                      }
                    } else {
                      m = fm + 1
                      d = fd.getDate()
                    }
                    let name = m + '-' + d
                    return (param.name == name) ? '#0092ff' : '#a3a3a3'
                  } */
              },
            },
            data: [],
          },
          {
            name: '未完成',
            type: 'bar',
            color: '#dedede',
            label: {
              normal: {
                show: true,
                position: 'top',
                color: '#a3a3a3',
              },
            },
            itemStyle: {
              normal: {
                color: '#87c4ff',
                /* color: function (param) {
                    let fromTime = ''
                    let toTime = ''
                    if (obj.searchForm.findTimer != null && obj.searchForm.findTimer != '') {
                      fromTime = obj.searchForm.findTimer[0]
                      toTime = obj.searchForm.findTimer[1]
                    }
                    let nd = new Date()
                    let fm = new Date(fromTime).getMonth()
                    let nm = new Date().getMonth()
                    let fd = new Date(fromTime)
                    let d = ''
                    let m = ''
                    let flag = Date.parse(fromTime) <= Date.parse(nd) && Date.parse(nd) <= Date.parse(toTime)
                    if (flag) {
                      m = nm + 1
                      if (fd.getDate() == nd.getDate()) {
                        d = nd.getDate()
                      } else {
                        d = nd.getDate() - 1
                      }
                    } else {
                      m = fm + 1
                      d = fd.getDate()
                    }
                    let name = m + '-' + d
                    return (param.name == name) ? '#87c4ff' : '#dedede'
                  } */
              },
            },
            data: [],
          },
        ],
      },
      seatGroupList: [],
      selectedArr: [],
      tableData: [],
      detailfirstData: [],
      detailsecondData: [],
      currentPage: 1,
      currentPage1: 1,
      currentPage2: 1,
      moreChance: false,
      recordDialogVisible: false,
      pageSizes: [10, 20, 30, 40],
      pageSize: 10,
      pageSizes1: [10, 20, 30, 40],
      pageSize1: 10,
      pageSizes2: [10, 20, 30, 40],
      pageSize2: 10,
      total: 0,
      total1: 0,
      total2: 0,
      count: 0,
      firstCount: 0,
      secondCount: 0,
      detail: '',
    }
  },
  computed: {
    /* 专题ID */
    getThenaticAnalysisId() {
      return this.$store.state.thenaticAnalysisId.subjectId
    },
  },
  methods: {
    toggleSound(event) {
      // 首页头部切换
      this.primaTable = true
      $('.soundfeature-pos-nav ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
    },
    toggleSoundTable: function() {
      this.primaTable = false
      $('.soundfeature-pos-nav ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
    },
    moreCondition: function() {
      this.searchForm.objectId = ''
      this.searchForm.seatName = ''
      this.searchForm.seatGroup = []
      this.moreChance = true
    },
    cancelNot: function() {
      this.moreChance = false
      this.searchForm.objectId = ''
      this.searchForm.seatName = ''
      this.searchForm.seatGroup = []
    },
    findSomething: function() {
      this.scoreInquery()
      this.moreChance = false
    },
    closeAll: function(done) {
      done()
      this.searchForm.objectId = ''
      this.searchForm.seatName = ''
      this.searchForm.seatGroup = []
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 点击自己 还是除了自己以外的元素
    outside: function(e) {
      this.showTree = false
    },
    inside: function(e) {
      this.showTree = true
      $('.is-focusable .el-checkbox__input span').removeClass('el-checkbox__inner')
      $('.is-focusable .el-checkbox__input span').addClass('el-radio__inner')
      this.resetChecked()
    },
    // 树节点点击
    handleNodeClick(data) {
      // this.currentNode = data
      // this.classId = data.classId
      // this.getKeyWords()
    },
    clickDin: function() {
      console.log(this.formRight.regions)
      this.handleChange()
      this.showTree = false
    },
    // 清空树
    resetChecked() {
      this.$refs.keyWordsMenu.setCheckedKeys([])
      this.formRight.regionName = ''
      this.formRight.region = ''
    },
    // 获取得到分类树
    getTreeMenu() {
      let _this = this
      this.axios
        .post(qualityUrl + '/taskManage/qaUsers.do')
        .then(function(response) {
          _this.treeMenu = response.data.options
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取菜单出现问题',
          })
        })
    },
    handleChange: function() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.findTimer == null) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        if (
          this.searchForm.findTimer[0] != undefined &&
          this.searchForm.findTimer[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.findTimer[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.findTimer[1] != undefined &&
          this.searchForm.findTimer[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.findTimer[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
        this.searchForm.findTimer = [fromTime, toTime]
      }
      let fd = new Date(fromTime)
      let nd = new Date()
      let flag =
        Date.parse(fromTime) <= Date.parse(nd) && Date.parse(nd) <= Date.parse(toTime)
      let fm = fd.getMonth()
      let nm = nd.getMonth()
      let d = ''
      let m = ''
      if (flag) {
        m = nm + 1
        if (fd.getDate() == nd.getDate()) {
          d = nd.getDate()
        } else {
          d = nd.getDate() - 1
        }
        let s1 = fromTime
        s1 = new Date(s1.replace(/-/g, '/'))
        let s2 = new Date()
        let days = s2.getTime() - s1.getTime()
        let time = parseInt(days / (1000 * 60 * 60 * 24))
        if (time == 0) {
          time = 1
        }
        this.index = time - 1
      } else {
        m = fm + 1
        d = fd.getDate()
        this.index = 0
      }

      this.month = m
      this.day = d
      let qaUser = this.formRight.regions
      let params = {
        qaUser: qaUser,
        begin: fromTime,
        end: toTime,
      }
      let _this = this
      this.axios
        .post(qualityUrl + '/taskManage/taskStatistic.do', Qs.stringify(params))
        .then((resp) => {
          _this.option.series[0].data = resp.data.finish
          _this.option.series[1].data = resp.data.todo
          _this.detailArray = resp.data.detail
          _this.detail = resp.data.detail[this.index]
          _this.option.xAxis.data = resp.data.xAxis
          document.getElementById('mainAminte').setAttribute('_echarts_instance_', '')
          let myChart = this.$echarts.init(document.getElementById('mainAminte'))
          myChart.setOption(this.option)
          myChart.getZr().on('click', function(param) {
            let pointInPixel = [param.offsetX, param.offsetY]
            if (myChart.containPixel('grid', pointInPixel)) {
              let xIndex = myChart.convertFromPixel({ seriesIndex: 0 }, [
                param.offsetX,
                param.offsetY,
              ])[0]
              let finishCount = resp.data.finish[xIndex]
              let todoCount = resp.data.todo[xIndex]
              if (finishCount == 0 && todoCount == 0) {
                _this.$message({
                  type: 'warning',
                  message: '所选日期无数据',
                })
              } else {
                _this.detail = _this.detailArray[xIndex]
                _this.month = resp.data.xAxis[xIndex].split('-')[0]
                _this.day = resp.data.xAxis[xIndex].split('-')[1]
                _this.scoreInquery()
                _this.taskDetail(qaUser)
              }
            }
          })
          // myChart.on('click', function (param) {
          //   console.log(22222222222222)
          //   obj.detail = obj.detailArray[param.dataIndex]
          //   obj.month = param.name.split('-')[0]
          //   obj.day = param.name.split('-')[1]
          //   detail.scoreInquery()
          //   detail.taskDetail(qaUser)
          // })
        })
      this.scoreInquery()
      this.taskDetail(qaUser)
    },
    // 录音列表信息
    taskDetail: function(name) {
      console.log(name)
      this.managePeople = name
      this.currentPage1 = 1
      let pagesize = this.pageSize1
      let pageindex = this.currentPage1
      if (!this.primaTable) {
        this.currentPage2 = 1
        pagesize = this.pageSize2
        pageindex = this.currentPage2
      }
      let params = {
        username: this.managePeople,
        month: this.month,
        day: this.day,
        pagesize: pagesize,
        pageindex: pageindex,
      }
      this.axios
        .post(qualityUrl + '/taskManage/taskDetail.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.firstCount) {
            this.detailfirstData = resp.data.first.map((item) => {
              item.firstQaScore = parseInt(Number(item.firstQaScore))
              return item
            })
          } else {
            this.detailfirstData = []
          }
          if (resp.data.secondCount) {
            this.detailsecondData = resp.data.second.map((item) => {
              item.secondQaScore = parseInt(Number(item.secondQaScore))
              return item
            })
          } else {
            this.detailsecondData = []
          }
          this.total1 = resp.data.firstCount
          this.total2 = resp.data.secondCount
          this.count = resp.data.total
          this.firstCount = resp.data.firstCount
          this.secondCount = resp.data.secondCount
          this.searchForm.objectId = ''
          this.searchForm.seatName = ''
          this.searchForm.seatGroup = []
        })
    },
    // 初检录音列表信息
    firstDetail: function(name) {
      let pagesize = this.pageSize1
      let pageindex = this.currentPage1
      if (!this.primaTable) {
        pagesize = this.pageSize2
        pageindex = this.currentPage2
      }
      let params = {
        username: this.managePeople,
        month: this.month,
        day: this.day,
        pagesize: pagesize,
        pageindex: pageindex,
      }
      this.axios
        .post(qualityUrl + '/taskManage/taskDetail.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.firstCount) {
            this.detailfirstData = resp.data.first
          } else {
            this.detailfirstData = []
          }
          this.total1 = resp.data.firstCount
          this.count = resp.data.total
          this.firstCount = resp.data.firstCount
          this.secondCount = resp.data.secondCount
          this.searchForm.objectId = ''
          this.searchForm.seatName = ''
          this.searchForm.seatGroup = []
        })
    },
    // 复检录音列表信息
    secondDetail: function(name) {
      console.log(name)
      let pagesize = this.pageSize1
      let pageindex = this.currentPage1
      if (!this.primaTable) {
        pagesize = this.pageSize2
        pageindex = this.currentPage2
      }
      let params = {
        username: this.managePeople,
        month: this.month,
        day: this.day,
        pagesize: pagesize,
        pageindex: pageindex,
      }
      this.axios
        .post(qualityUrl + '/taskManage/taskDetail.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.secondCount) {
            this.detailsecondData = resp.data.second
          } else {
            this.detailsecondData = []
          }
          this.total2 = resp.data.secondCount
          this.count = resp.data.total
          this.firstCount = resp.data.firstCount
          this.secondCount = resp.data.secondCount
          this.searchForm.objectId = ''
          this.searchForm.seatName = ''
          this.searchForm.seatGroup = []
        })
    },
    // 跳转到录音播放页面
    jumpToSound: function(id, taskId, qaScoreType) {
      let notScoreList = {
        formPosition: 'normal',
      }
      this.$store.commit('setNotScoreList', notScoreList)
      let tempobj = {}
      tempobj.callId = id
      tempobj.taskId = taskId
      tempobj.qaScoreType = qaScoreType
      this.$store.commit('setRecordingPlayPage', tempobj)
      //  this.$router.push('/recordingPlay')
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // 将录音时长转换为秒
    dateFormatTwo(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.scoreInquery()
    },
    handleSizeChange1(val) {
      this.pageSize1 = val
      let qaUser = this.formRight.regions
      this.firstDetail(qaUser)
    },
    handleSizeChange2(val) {
      this.pageSize2 = val
      let qaUser = this.formRight.regions
      this.secondDetail(qaUser)
    },
    scoreInquery() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      let qaUser = this.formRight.regions
      let params = {
        qaUser: qaUser,
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        month: this.month,
        day: this.day,
      }
      this.axios
        .post(qualityUrl + '/taskManage/qaUserDetail.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            let data = resp.data.Data
            data.unshift({
              nocount: resp.data.uncomplete,
              count: resp.data.complete,
              name: '总计',
            })
            this.tableData = data
          } else {
            this.tableData = []
          }
          this.total = resp.data.Count
          this.searchForm.objectId = ''
          this.searchForm.seatName = ''
          this.searchForm.seatGroup = []
        })
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.scoreInquery()
    },
    handleCurrentChange1(val) {
      this.currentPage1 = val
      let qaUser = this.fvalue
      this.firstDetail(qaUser)
    },
    handleCurrentChange2(val) {
      this.currentPage2 = val
      console.log(123)
      let qaUser = this.formRight.regions
      this.secondDetail(qaUser)
    },
    handleSelectionChange(val) {
      this.selectedArr = val
    },
    // 导出任务完成情况报表
    exportTask(qaUser) {
      if (this.searchForm.findTimer == null) {
        // 设置起始时间
        let fromTime = ''
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        // 设置结束时间
        let toTime = ''
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        this.searchForm.findTimer = [fromTime, toTime]
      }
      this.searchForm.findTimer
      let params = {
        qaUser: qaUser,
        begin: this.searchForm.findTimer[0],
        end: this.searchForm.findTimer[1],
      }
      commonUtil.doExport(
        qualityUrl + '/taskManage/exportTask.do',
        params,
        global.jsonHeader
      )
      // window.location.href = qualityUrl + '/taskManage/exportTask.do?qaUser=' + qaUser + '&begin=' + this.searchForm.findTimer[0] + '&end=' + this.searchForm.findTimer[1] + '&accessToken=' + cache.getItem('tgt_id')
    },
    // 导出质检员完成情况统计报表
    exportQaUser(qaUser) {
      let params = {
        qaUser: qaUser,
        month: this.month,
        day: this.day,
      }
      commonUtil.doExport(
        qualityUrl + '/taskManage/exportQaUser.do',
        params,
        global.jsonHeader
      )
    },
    // 导出已质检录音明细报表
    exportTaskDetail(qaUser) {
      let taskType = null
      if (this.primaTable) {
        // 初检
        taskType = 1
      } else {
        // 复检
        taskType = 2
      }
      let params = {
        qaUser: qaUser,
        month: this.month,
        day: this.day,
        taskType: taskType,
      }
      commonUtil.doExport(
        qualityUrl + '/taskManage/exportTaskDetail.do',
        params,
        global.jsonHeader
      )
    },
  },
  directives: {
    'click-outside': {
      bind: function(el, binding, vNode) {
        // Provided expression must evaluate to a function.
        if (typeof binding.value !== 'function') {
          const compName = vNode.context.name
          let warn = `[Vue-click-outside:] provided expression '${
            binding.expression
          }' is not a function, but has to be`
          if (compName) {
            warn += `Found in component '${compName}'`
          }

          console.warn(warn)
        }
        // Define Handler and cache it on the element
        const bubble = binding.modifiers.bubble
        const handler = (e) => {
          if (bubble || (!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },
      unbind: function(el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      },
    },
  },
  mounted: function() {
    let nd = new Date()
    this.month = nd.getMonth() + 1
    this.day = nd.getDate() - 1
    this.scoreInquery()
    this.handleChange()
    this.getTreeMenu()
    this.taskDetail(null)
  },
  created() {
    this.recordPlayCloseHandler()
    // obj = this
  },
}
</script>
<style lang="less" scoped="scoped">
.table {
  height: 100%;
}
.content {
  box-sizing: border-box;
  margin: 20px 25px 10px 25px;
  border: 1px solid #d3dce6;
}
#soundfeature {
  box-sizing: border-box;
  height: 100%;
  width: 100%;
  .soundfeature-pos {
    width: 100%;
    height: 100%;
    position: relative;
  }
  .soundfeature-pos .soundfeature-pos-nav {
    width: 100%;
    height: 48px;
    line-height: 48px;
    background: #eef1f6;
    border-bottom: 1px solid #d1dbe4;
    background: #ffffff;
  }
  .soundfeature-pos-nav ul {
    width: 100%;
    box-sizing: border-box;
  }
  .soundfeature-pos-nav ul li {
    float: left;
    padding: 0 16px;
    box-sizing: border-box;
    font-size: 14px;
    color: #96a2b2;
    cursor: pointer;
  }
  .soundfeatureActive {
    color: #21a2ff !important;
    border-bottom: 2px solid #21a2ff;
  }
  .soundfeature-pos .soundfeature-pos-content {
    padding: 20px 20px 0;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    overflow: hidden;
  }
  .moreChoice {
    line-height: 36px;
    text-decoration: underline;
    color: #20a0ff;
    cursor: pointer;
    font-size: 13px;
    margin-left: 4px;
  }
  .scoreinfo-page {
    width: 100%;
    height: 35px;
    position: absolute;
    background: white;
    left: 0;
    right: 0px;
    bottom: 0px;
    text-align: right;
    .el-pagination {
      display: inline-block;
      height: 28px;
      line-height: 28px;
      padding: 0px 10px;
    }
  }
}
.autoGrading-page {
  right: 10px;
  position: absolute;
  bottom: 10px;
}
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
.select-width {
  width: 200px;
  margin-top: 3px;
  &.hide {
    display: none;
  }
}
.contentLeft {
  width: 200px;
  top: 38px;
  right: 0;
  position: absolute;
  z-index: 3000;
  .treeMenu {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    .el-tree {
      max-height: 200px;
      min-height: 80px;
      overflow-y: auto;
      border: 1px solid #ccc;
    }
    .btns {
      width: 99%;
      height: 36px;
      border: 1px solid #ccc;
      border-top: 0;
      background: #fff;
      .el-button {
        float: right;
        width: 52px;
        height: 30px;
        margin-top: 2px;
        font-size: 12px;
        margin-right: 10px;
      }
    }
  }
}
</style>
<style lang="less">
#soundfeature {
  .contentButt .el-button {
    padding: 10px 0px;
  }
  .el-table--border th {
    background: #e5e9f2;
    padding: 10px 0;
  }
  .el-table thead {
    color: #475669;
  }
  .edealcell {
    .el-dialog__body {
      padding: 0;
    }
    .el-dialog__header {
      padding: 25px;
    }
    .speshow .dealCenter .el-input__inner {
      width: 240px;
    }
  }
}
.el-dialog__wrapper.single {
  position: fixed;
  top: 106px;
  left: 20px;
  right: 20px;
  bottom: 12px;
  .el-dialog {
    width: 100%;
    height: 100%;
    margin: 0 !important;
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}

.el-button.goback-btn {
  padding: 0;
  margin: 0;
  border: none;
  font-size: 14px;
  color: #20a0ff;
}
.cerall .el-form-item__content {
  margin-top: 3px;
}
#setSanjiao {
  background-color: #fff;
  position: relative;
}
#setSanjiao:before,
#setSanjiao:after {
  border: solid transparent;
  content: ' ';
  height: 0px;
  width: 0px;
  left: 100%;
  top: -40px;
  position: absolute;
}
#setSanjiao:before {
  border-width: 22px;
  border-bottom-color: #d3dce6;
  top: -44px;
  left: 49.9%;
}
#setSanjiao:after {
  left: 50%;
  border-width: 20px;
  border-bottom-color: #fff;
}
</style>
