<template>
  <div id="newtask">
    <div class="attrs">
      <el-form
        label-width="100px"
        :model="TaskAttr"
        ref="TaskAttr"
        :rules="taskAttrRules"
      >
        <div class="audioAttrs_part taskAttrs">
          <h3>
            任务属性
          </h3>
          <div class="audioAttrsInputs">
            <el-col :span="6">
              <el-form-item label="任务名称" prop="projectName">
                <el-input v-model="TaskAttr.projectName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="18">
              <el-form-item label="模板选择" prop="modleId">
                <el-select
                  v-model="TaskAttr.modleId"
                  clearable
                  placeholder="请选择"
                  class=""
                >
                  <el-option
                    v-for="item in modelList"
                    :key="item.modleId"
                    :label="item.modleTitle"
                    :value="item.modleId"
                  >
                  </el-option>
                </el-select>
                <i class="el-icon-setting setting" @click="gotoSetting"></i>
              </el-form-item>
            </el-col>
          </div>
        </div>
        <div class="audioAttrs_part taskAttrs">
          <h3>
            周期（天）
          </h3>
          <div class="audioAttrsInputs">
            <el-col :span="6">
              <el-form-item label="运行周期" prop="operationperiod">
                <el-input v-model="TaskAttr.operationperiod"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="采集周期" prop="collectionperiod">
                <el-input v-model="TaskAttr.collectionperiod"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6"> </el-col>
            <el-col :span="6"> </el-col>
          </div>
        </div>
      </el-form>
      <el-form label-width="100px" :model="Task" ref="Task">
        <div class="audioAttrs_part audioAttrs">
          <h3>
            订单属性
          </h3>
          <div class="audioAttrsInputs">
            <el-col :span="6">
              <el-form-item label="订单编号" prop="orderNo">
                <el-input v-model="Task.orderNo"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="订单状态" prop="orderState">
                <el-select v-model="Task.orderState" clearable class="fr">
                  <el-option
                    v-for="item in orderTypes"
                    :value="item.value"
                    :label="item.label"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="订单内容" prop="recordContext">
                <el-select v-model="Task.recordContext" clearable class="fr">
                  <el-option
                    v-for="item in recordContext"
                    :value="item.value"
                    :label="item.label"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </div>
        </div>
        <div class="audioAttrs_part audioAttrs">
          <h3>
            员工属性
          </h3>
          <div class="audioAttrsInputs">
            <el-col :span="6">
              <el-form-item label="提交人工号" prop="qaedWordId">
                <el-input v-model="Task.qaedWordId"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="提交人姓名" prop="qaedName">
                <el-input v-model="Task.qaedName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="坐席组" prop="searGroup">
                <el-input v-model="Task.searGroup"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="坐席星级" prop="seatStar">
                <el-input v-model="Task.seatStar"></el-input>
              </el-form-item>
            </el-col>
          </div>
        </div>
        <div class="audioAttrs_part audioAttrs">
          <h3>
            客户属性
          </h3>
          <div class="audioAttrsInputs">
            <el-col :span="6">
              <el-form-item label="客户姓名" prop="customerName">
                <el-input v-model="Task.customerName"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="证件号码" prop="cardNo">
                <el-input v-model="Task.cardNo"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="客户账号" prop="customerNo">
                <el-input v-model="Task.customerNo"></el-input>
              </el-form-item>
            </el-col>
          </div>
        </div>
        <div class="btns">
          <el-button type="primary" @click="taskCreateThrottle">保存</el-button>
          <el-button @click="taskReset">清空</el-button>
          <el-button @click="taskGoback">返回</el-button>
        </div>
      </el-form>
    </div>
  </div>
</template>
<style lang="less">
#newtask {
  .attrs .audioAttrs_part .audioAttrsInputs .el-form-item label {
    color: #8691a5;
  }
}
</style>
<style scoped="scoped" lang="less">
@border-color: #d1dbe5;
.attrs {
  .audioAttrs_part {
    border-bottom: 1px dashed @border-color;
    overflow: hidden;
    .audioAttrsInputs {
      padding: 10px;
    }
  }
  h3 {
    padding-left: 10px;
    line-height: 30px;
    color: #9dadc2;
    font-weight: normal;
  }
  .btns {
    text-align: right;
    margin-top: 10px;
  }
}
.line {
  text-align: center;
}
.unit {
  margin: 0 5px;
}
.setting {
  font-size: 16px;
  color: #8691a5;
  margin: 8px 0px 10px 10px;
  cursor: pointer;
}
</style>
<script>
import Qs from 'qs'
import global from '../../../global.js'
let currentBaseUrl = global.qualityUrl
export default {
  props: ['projectModel'],
  data() {
    let checkNumber = (rule, value, callback) => {
      if (value == '') {
        callback(new Error('请输入数字'))
      } else if (isNaN(value)) {
        callback(new Error('请输入数字'))
      } else {
        callback()
      }
    }
    let checkName = (rule, value, callback) => {
      this.axios
        .post(
          currentBaseUrl + '/autoorderscore/checkRonertExist.do',
          Qs.stringify({ projectName: value })
        )
        .then(function(response) {
          if (response.data == false) {
            callback(new Error('任务名称已存在'))
          } else {
            callback()
          }
        })
    }
    return {
      silenceAttrType: '', // 静默特征类型
      projectId: '',
      TaskAttr: {
        projectName: '',
        modleId: '',
        operationperiod: '', // 运行周期
        collectionperiod: '', // 采集周期
      }, // 任务属性
      taskAttrRules: {
        // 任务属性验证
        projectName: [
          { required: true, message: '任务名称不能为空', trigger: 'blur' },
          { validator: checkName, trigger: 'blur' },
        ],
        modleId: [{ required: true, message: '请选择一个模板', trigger: 'blur' }],
        operationperiod: [{ validator: checkNumber, trigger: 'blur' }],
        collectionperiod: [{ validator: checkNumber, trigger: 'blur' }],
      },
      Task: {
        orderNo: '', // 订单编号
        sysAutoScore: '',
        overLap: '',
        avgSpeed: '',
        moodScore: '',
        speechSlient: '',
        taskTypes: '',
        overlap_Min: '', // 重叠次数
        overlap_Max: '', // 重叠次数
        avgSpeed_Min: '', // 坐席平均语速
        avgSpeed_Max: '', // 坐席平均语速
        mood_Min: '', // 情绪分值
        mood_Max: '', // 情绪分值
        silenceAttrType: '', // 静默特征类型
        silenceLong_Min: '', // 静默时长
        silenceLong_Max: '', // 静默时长
        silenceCount_Min: '', // 静默次数
        silenceCount_Max: '', // 静默次数
        silencePer_Min: '', // 静默占比
        qaedName: '', // 提交人姓名
        customerName: '', // 客户姓名
        customerNo: '', // 客户账号
        cardNo: '', // 证件编号
        qaedWordId: '', // 提交人工号
      },
      taskTypes: [
        {
          value: '1',
          label: '即时任务',
        },
        {
          value: '2',
          label: '循环任务',
        },
      ],
      orderTypes: [
        {
          value: '1',
          label: '完成',
        },
        {
          value: '2',
          label: '取消',
        },
      ],
      silenceAttrs: [
        {
          value: 'silenceLong',
          label: '时长',
        },
        {
          value: 'silenceCount',
          label: '次数',
        },
        {
          value: 'silencePer',
          label: '占比',
        },
      ],
      modelList: [], // 模板id
      seatGroup: [],
      seatStar: [],
      state: 'add', // 添加还是复制
    }
  },
  methods: {
    taskCreateThrottle() {
      this.lodashThrottle.throttle(this.taskCreate, this)
    },
    taskCreate() {
      this.saveSearchConfigure()
    },
    /*
     * 清空按钮
     * */
    taskReset: function() {
      for (let prop in this['Task']) {
        if (this['Task'].hasOwnProperty(prop)) {
          this['Task'][prop] = ''
        }
      }
      for (let prop in this['TaskAttr']) {
        if (this['TaskAttr'].hasOwnProperty(prop)) {
          this['TaskAttr'][prop] = ''
        }
      }
    },
    // 保存配置
    saveSettingConfigure(id) {
      let _this = this
      if (
        _this.projectModel &&
        _this.TaskAttr.projectName == _this.projectModel.strategyName.toString()
      ) {
        _this.$message({
          type: 'warning',
          message: '请修改任务名称',
        })
        return false
      }
      let params = {
        projectName: _this.TaskAttr.projectName,
        modleId: _this.TaskAttr.modleId,
        operationperiod: _this.TaskAttr.operationperiod,
        collectionperiod: _this.TaskAttr.collectionperiod,
        robertProjectId: id,
      }
      let url = currentBaseUrl + '/autoorderscore/insertRonertProject.do'
      _this.axios
        .post(url, Qs.stringify(params))
        .then(function(response) {
          let msg = '任务保存成功'
          if (_this.state == 'copy') {
            msg = '任务复制成功'
          }
          _this.$message({
            type: 'success',
            message: msg,
          })
          _this.$emit('send', false, 'success')
        })
        .catch(function(error) {
          console.log(error)
          return Promise.reject()
        })
    },
    // 保存查询条件
    saveSearchConfigure() {
      this.$refs.TaskAttr.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let _this = this
          let params = {}
          params.status = '9'
          params.strategyBelong = '系统自动评分'
          params.strategyName = this.TaskAttr.projectName
          params.strategyId = ''
          params.strategyObject = JSON.stringify(this.Task)
          let url = currentBaseUrl + '/ivsStrategy/insertIvsStrategy.do'
          _this.axios
            .post(url, Qs.stringify(params))
            .then(function(response) {
              _this.saveSettingConfigure(response.data.streategyId)
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '策略保存失败',
              })
            })
        }
      })
    },
    // 点击返回按钮callingTime
    taskGoback() {
      this.$emit('send', false)
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.$refs.TaskAttr.resetFields()
    },
    // 点击配置进入到质检评分模板
    gotoSetting() {
      this.$router.push('/manalScoreModel_new')
    },
    // 获取模板列表
    getModleInfoByCondition() {
      let _this = this
      let params = {
        modleType: '7',
        pageindex: '',
        pagesize: '',
      }
      let url = currentBaseUrl + '/manualOrderQualityAssurance/getModleInfoByCondition.do'
      _this.axios
        .post(url, Qs.stringify(params))
        .then(function(response) {
          _this.modelList = response.data.Data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '模板获取失败',
          })
        })
    },
  },
  created() {
    this.getModleInfoByCondition()
    if (this.projectModel) {
      this.state = 'copy'
      this.TaskAttr.projectName = this.projectModel.strategyName.toString()
      this.TaskAttr.modleId = this.projectModel.modleId.toString()
      this.TaskAttr.operationperiod = parseInt(
        this.projectModel.operationperiod.toString()
      )
      this.TaskAttr.collectionperiod = parseInt(
        this.projectModel.collectionperiod.toString()
      )
      this.strategyId = this.projectModel.strategyId.toString()
      this.Task = JSON.parse(this.projectModel.strategyObject)
    }
  },
}
</script>
