<template>
  <div>
    <div class="content">
      <el-form
        :model="qualityParamsForm"
        ref="qualityParamsForm"
        :rules="editParamsRule"
        label-width="120px"
      >
        <el-form-item label="自动复检时间" prop="recheckDay">
          <el-input
            style="width:220px"
            :maxlength="2"
            v-model="qualityParamsForm.recheckDay"
            placeholder=""
          ></el-input>
          <span>天</span>
        </el-form-item>
        <el-form-item label="复议有效时间" prop="fuyiDays">
          <el-input
            style="width:220px"
            :maxlength="2"
            :disabled="false"
            v-model="qualityParamsForm.fuyiDays"
          ></el-input>
          <span>天</span>
        </el-form-item>
        <el-form-item label="申诉有效时间" prop="appealDays">
          <el-input
            style="width:220px"
            :maxlength="2"
            :disabled="false"
            v-model="qualityParamsForm.appealDays"
          ></el-input>
          <span>天</span>
        </el-form-item>
        <el-form-item label="可申诉范围" prop="scoreMin">
          <el-input
            style="width:100px"
            :maxlength="5"
            :disabled="false"
            v-model="qualityParamsForm.scoreMin"
          ></el-input>
          <label>--</label>
          <el-input
            style="width:100px"
            :maxlength="5"
            :disabled="false"
            v-model="qualityParamsForm.scoreMax"
          ></el-input>
          <span>分</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="footer">
        <el-button funcId="000074" type="primary" @click="saveEdit">确 定</el-button>
        <el-button funcId="000075" @click="reset">重 置</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import Qs from 'qs'
import global from '../../../global.js'
let qualityUrl = global.qualityUrl
export default {
  data() {
    const isBlank = (rule, value, callback) => {
      if (value.trim().length <= 0) {
        callback(new Error('不能为空'))
      } else if (value < 0) {
        callback(new Error('请填写大于0的参数'))
      } else if (value == 0) {
        callback(new Error('时间参数不可为0'))
      } else {
        callback()
      }
    }
    return {
      qualityParamsForm: {
        recheckDay: '',
        fuyiDays: '',
        appealDays: '',
        scoreMin: '',
        scoreMax: '',
      },
      editParamsRule: {
        recheckDay: [
          {
            validator: isBlank,
            trigger: 'blur',
          },
          {
            type: 'number',
            message: '请输入数字格式',
            trigger: 'blur',
            transform(value) {
              return Number(value)
            },
          },
        ],
        fuyiDays: [
          {
            validator: isBlank,
            trigger: 'blur',
          },
          {
            type: 'number',
            message: '请输入数字格式',
            trigger: 'blur',
            transform(value) {
              return Number(value)
            },
          },
        ],
        appealDays: [
          {
            validator: isBlank,
            trigger: 'blur',
          },
          {
            type: 'number',
            message: '请输入数字格式',
            trigger: 'blur',
            transform(value) {
              return Number(value)
            },
          },
        ],
      },
    }
  },
  methods: {
    // 保存
    saveEdit: function() {
      this.lodashThrottle.throttle(this.saveParams, this)
    },
    saveParams: function() {
      let _this = this
      let params = {
        recheckDay: _this.qualityParamsForm.recheckDay,
      }
      let params0 = {
        configId: '',
        fuyiDays: _this.qualityParamsForm.fuyiDays,
        appealDays: _this.qualityParamsForm.appealDays,
        scoreMin: _this.qualityParamsForm.scoreMin,
        scoreMax: _this.qualityParamsForm.scoreMax,
      }
      if (
        params.recheckDay
          .toString()
          .split(' ')
          .join('').length == 0
      ) {
        _this.$message({
          type: 'error',
          message: '自动复检时间不能为空！',
        })
        return
      } else if (params.recheckDay * 1 == 0) {
        _this.$message({
          type: 'error',
          message: '自动复检时间不能为0！',
        })
        return
      } else if (params.recheckDay * 1 < 1) {
        _this.$message({
          type: 'error',
          message: '自动复检时间不能为负数！',
        })
        return
      } else if (
        params0.fuyiDays
          .toString()
          .split(' ')
          .join('').length == 0
      ) {
        _this.$message({
          type: 'error',
          message: '复议有效时间不能为空！',
        })
        return
      } else if (params0.fuyiDays * 1 == 0) {
        _this.$message({
          type: 'error',
          message: '复议有效时间不能为0！',
        })
        return
      } else if (params0.fuyiDays * 1 < 1) {
        _this.$message({
          type: 'error',
          message: '复议有效时间不能为负数！',
        })
        return
      } else if (
        params0.appealDays
          .toString()
          .split(' ')
          .join('').length == 0
      ) {
        _this.$message({
          type: 'error',
          message: '申诉有效时间不能为空！',
        })
        return
      } else if (params0.appealDays * 1 == 0) {
        _this.$message({
          type: 'error',
          message: '申诉有效时间不能为0！',
        })
        return
      } else if (params0.appealDays * 1 < 0) {
        _this.$message({
          type: 'error',
          message: '申诉有效时间不能为负数！',
        })
        return
      } else if (
        params0.scoreMin
          .toString()
          .split(' ')
          .join('').length == 0 ||
        params0.scoreMax
          .toString()
          .split(' ')
          .join('').length == 0
      ) {
        _this.$message({
          type: 'error',
          message: '可申诉范围不能为空！',
        })
        return
      } else if (params0.scoreMin * 1 < 0 || params0.scoreMax * 1 < 0) {
        _this.$message({
          type: 'error',
          message: '可申诉范围不能为负数！',
        })
        return
      } else if (params0.scoreMin * 1 > params0.scoreMax * 1) {
        _this.$message({
          type: 'error',
          message: '请填写正确的可申诉范围！',
        })
        return
      }
      if (isNaN(params0.scoreMin) || isNaN(params0.scoreMax)) {
        _this.$message({
          type: 'error',
          message: '可申诉范围不是数字！',
        })
        return
      }
      this.axios
        .post(qualityUrl + '/qualityParams/editParam.do', Qs.stringify(params))
        .then((res) => {
          if (res.data == true) {
            _this.$message({
              type: 'success',
              message: '修改成功！',
            })
          } else {
            _this.$message({
              type: 'error',
              message: '修改失败！',
            })
          }
        })
        .catch(function(error) {
          console.log(error)
        })
      this.axios
        .post(qualityUrl + '/ivsAppealConfig/editaddConfig.do', Qs.stringify(params0))
        .then((res) => {
          if (res.data.flag == true) {
            _this.$message({
              type: 'success',
              message: '修改成功！',
            })
          } else {
            _this.$message({
              type: 'error',
              message: '修改失败！',
            })
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    reset: function() {
      let _this = this
      _this.qualityParamsForm.recheckDay = '3'
      _this.qualityParamsForm.fuyiDays = '3'
      _this.qualityParamsForm.appealDays = '3'
      _this.qualityParamsForm.scoreMin = '0'
      _this.qualityParamsForm.scoreMax = '60'
      _this.saveEdit()
    },
    getParams: function() {
      let _this = this
      let params = {
        paramCodes: 'recheckDay',
      }
      this.axios
        .post(qualityUrl + '/qualityParams/getParamsVal.do', Qs.stringify(params))
        .then((res) => {
          _this.qualityParamsForm.recheckDay = res.data.recheckDay
        })
        .catch(function(error) {
          console.log(error)
        })
      let params0 = {
        configId: '',
      }
      this.axios
        .post(qualityUrl + '/ivsAppealConfig/queryByUser.do', Qs.stringify(params0))
        .then((res) => {
          _this.qualityParamsForm.fuyiDays = res.data.fuyiDays
          _this.qualityParamsForm.appealDays = res.data.appealDays
          _this.qualityParamsForm.scoreMin = res.data.scoreMin
          _this.qualityParamsForm.scoreMax = res.data.scoreMax
        })
        .catch(function(error) {
          console.log(error)
        })
    },
  },
  created() {
    this.getParams()
  },
  computed: {
    loadData() {
      this.qualityParamsForm.recheckDay = ''
      this.qualityParamsForm.fuyiDays = ''
      this.qualityParamsForm.appealDays = ''
      this.qualityParamsForm.scoreMin = ''
      this.qualityParamsForm.scoreMax = ''
      return this.qualityParamsForm
    },
  },
  watch: {
    loadData(val, oldval) {},
  },
}
</script>
<style lang="less" scoped>
.content {
  overflow: auto;
  //position: absolute;
  left: 20;
  right: 0;
  bottom: 20px;
  padding: 20px 40px;
}

.footer {
  position: absolute;
  padding: 0px 80px;
}

input {
  ::-webkit-input-placeholder {
    text-align: right;
  }
}
</style>
