<template>
  <el-form
    ref="intellSampleYuangong_intellSampleYuyin_Ref"
    :inline="true"
    :rules="intellSampleYuangong_intellSampleYuyin_Rules"
    :model="intellSampleYuangong_intellSampleYuyin_Model"
    label-width="84px"
  >
    <h3>员工属性</h3>
    <el-row>
      <el-col :span="12">
        <el-form-item prop="seatNo" style="color:#8691a5" label="坐席工号">
          <el-input
            v-model="intellSampleYuangong_intellSampleYuyin_Model.seatNo"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="seatName" style="color:#8691a5" label="坐席姓名">
          <el-input
            v-model="intellSampleYuangong_intellSampleYuyin_Model.seatName"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12" class="mySelect">
        <el-form-item prop="deptId" style="color:#8691a5" label="坐席组">
          <el-select
            style="width:160px"
            :popper-append-to-body="false"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.deptId"
            filterable
            placeholder="请选择"
            id="seatGroup"
          >
            <optionNode
              v-for="(item, index) in seatGroupOptions"
              :key="index"
              :node="item"
            />
            <!-- <el-option
              v-for="item in seatGroupOptions.original"
              :key="'ori' + item.id"
              style="display:none"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
            <el-option
              v-for="item in seatGroupOptions"
              style="height: auto"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
              <el-tree
                :data="seatGroupOptions"
                :node-key="'id'"
                show-checkbox
                default-expand-all
                @check-change="handleCheckChange"
                :props="{ children: 'children', label: 'name' }"
              ></el-tree>
            </el-option> -->
          </el-select>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row style="border-top:1px solid #d1dbe5;">
      <el-col :span="24"></el-col>
    </el-row>
    <h3>语音特征</h3>
    <el-row>
      <el-col :span="12">
        <el-form-item prop="avgSpeed_Min" style="color:#8691a5" label="平均语速">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.avgSpeed_Min"
            placeholder
          ></el-input>
        </el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="avgSpeed_Max">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.avgSpeed_Max"
            placeholder
          ></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="silencePer_Min" style="color:#8691a5" label="静默占比">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.silencePer_Min"
            placeholder
          ></el-input>
        </el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="silencePer_Max">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.silencePer_Max"
            placeholder
          ></el-input>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item prop="silenceCount_Min" style="color:#8691a5" label="静默次数">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.silenceCount_Min"
            placeholder
          ></el-input>
        </el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="silenceCount_Max">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.silenceCount_Max"
            placeholder
          ></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item prop="overLap_Min" style="color:#8691a5" label="重叠次数">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.overLap_Min"
            placeholder
          ></el-input>
        </el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="overLap_Max">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.overLap_Max"
            placeholder
          ></el-input>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item prop="silenceLong_Min" style="color:#8691a5" label="静默时长">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.silenceLong_Min"
            placeholder
          ></el-input>
        </el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="silenceLong_Max">
          <el-input
            style="width:55px"
            v-model="intellSampleYuangong_intellSampleYuyin_Model.silenceLong_Max"
            placeholder
          ></el-input>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row style="border-top:1px solid #d1dbe5;">
      <el-col :span="24"></el-col>
    </el-row>
  </el-form>
</template>

<script>
import global from '@/global.js'
import Qs from 'qs'
import constructTree from '@/components/common/nestedSelection/constructTree'
import optionNode from '@/components/common/nestedSelection/optionNode'
let qualityUrl = global.qualityUrl

export default {
  components: {
    optionNode,
  },
  data() {
    return {
      seatGroupOptions: [], // 坐席组
      intellSampleYuangong_intellSampleYuyin_Model: {
        // deptIds: [],
        seatNo: '',
        seatNo$CName: '坐席工号',
        seatName: '',
        seatName$CName: '坐席姓名',
        deptId: '',
        deptId$CName: '坐席组',
        avgSpeed_Min: '',
        avgSpeed_Min$CName: '平均语速(最小值)',
        avgSpeed_Max: '',
        avgSpeed_Max$CName: '平均语速(最大值)',
        silencePer_Min: '',
        silencePer_Min$CName: '静默占比(最小值)',
        silencePer_Max: '',
        silencePer_Max$CName: '静默占比(最大值)',
        silenceCount_Min: '',
        silenceCount_Min$CName: '静默次数(最小值)',
        silenceCount_Max: '',
        silenceCount_Max$CName: '静默次数(最大值)',
        overLap_Min: '',
        overLap_Min$CName: '重叠次数(最小值)',
        overLap_Max: '',
        overLap_Max$CName: '重叠次数(最大值)',
        silenceLong_Min: '',
        silenceLong_Min$CName: '静默时长(最小值)',
        silenceLong_Max: '',
        silenceLong_Max$CName: '静默时长(最大值)',
      },
      intellSampleYuangong_intellSampleYuyin_Rules: {},
    }
  },
  props: ['fromFModel'], // 父组件的
  watch: {
    // 监控父亲数据的变化 如果有个变化则更新表单的内容
    fromFModel: function() {
      // alert(this.fromFModel)
      this.intellSampleYuangong_intellSampleYuyin_Model = this.fromFModel
      // 删除表单的验证
    },
  },
  mounted() {
    this.getSeatGroupValue()
  },
  methods: {
    handleCheckChange(selection, isAdded) {
      console.log(arguments)

      if (isAdded) {
        this.intellSampleYuangong_intellSampleYuyin_Model.deptIds.push(selection.id)
      } else {
        this.intellSampleYuangong_intellSampleYuyin_Model.deptIds = this.intellSampleYuangong_intellSampleYuyin_Model.deptIds.filter(
          (id) => id !== selection.id
        )
      }
    },
    getSeatGroupValue() {
      let _this = this
      let url = qualityUrl + '/pageConstant/getValue.do'
      let searchParam = {}
      searchParam.keys = 'seatGroup'
      console.log('aaaattt')
      this.axios
        .post(url, Qs.stringify(searchParam))
        .then(function(response) {
          _this.seatGroupOptions = constructTree(response.data.seatGroup)
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取常量值出现问题',
          })
        })
    },
  },
}
</script>

<style scoped>
.mySelect /deep/ .el-scrollbar__wrap {
  height: 260px;
}
</style>
