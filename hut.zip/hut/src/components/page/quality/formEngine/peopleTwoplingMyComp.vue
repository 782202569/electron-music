<template>
  <el-form
    ref="reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Ref"
    :inline="true"
    :rules="reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Rules"
    :model="reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model"
    label-width="84px"
  >
    <h3>任务属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="firstQaUserName" style="color:#8691a5" label="质检员姓名"
          ><el-input
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.firstQaUserName
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="firstAssignTime" style="color:#8691a5" label="分发时间"
          ><el-date-picker
            style="width:160px"
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.firstAssignTime
            "
            type="datetimerange"
            placeholder="选择时间范围"
            v-bind:default-time="['00:00:00', '23:59:59']"
          ></el-date-picker></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12"
        ><el-form-item prop="score_Min" style="color:#8691a5" label="质检得分"
          ><el-input
            style="width:55px"
            v-model="reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.score_Min"
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="score_Max"
          ><el-input
            style="width:55px"
            v-model="reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.score_Max"
            placeholder=""
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="firstQaUserNameNo" style="color:#8691a5" label="质检员工号"
          ><el-input
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.firstQaUserNameNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>坐席属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="seatNo" style="color:#8691a5" label="坐席工号"
          ><el-input
            v-model="reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.seatNo"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="seatName" style="color:#8691a5" label="坐席姓名"
          ><el-input
            v-model="reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.seatName"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12" class="mySelect"
        ><el-form-item prop="deptId" style="color:#8691a5" label="坐席组"
          ><el-select
            style="width:160px"
            :popper-append-to-body="false"
            v-model="reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.deptId"
            placeholder="请选择"
            id="seatGroup"
          >
            <optionNode
              v-for="(item, index) in seatGroupOptions"
              :key="index"
              :node="item"
            /> </el-select></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>关键词</h3>
    <el-row
      ><el-col :span="24"
        ><el-form-item prop="wholeContent" style="color:#8691a5" label="关键词"
          >（<el-input
            style="width:80px; padding: 1px"
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.wholeContent_firstKey
            "
          ></el-input
          ><el-select
            style="width:90px; padding: 1px"
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.wholeContent_firstLogic
            "
            ><el-option label="与" value="AND"></el-option
            ><el-option label="或" value="OR"></el-option></el-select
          ><el-input
            style="width:80px; padding: 1px"
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.wholeContent_secondKey
            "
          ></el-input
          >）<el-select
            style="width:90px; padding: 1px"
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.wholeContent_MidLogic
            "
            ><el-option label="与" value="AND"></el-option
            ><el-option label="或" value="OR"></el-option></el-select
          >（<el-input
            style="width:80px; padding: 1px"
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.wholeContent_thirdKey
            "
          ></el-input
          ><el-select
            style="width:90px; padding: 1px"
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.wholeContent_LastLogic
            "
            ><el-option label="与" value="AND"></el-option
            ><el-option label="或" value="OR"></el-option></el-select
          ><el-input
            style="width:80px; padding: 1px"
            v-model="
              reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model.wholeContent_LastKey
            "
          ></el-input
          >）</el-form-item
        ></el-col
      ></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row
  ></el-form>
</template>

<script>
import qs from 'qs'
import global from '@/global.js'
import constructTree from '@/components/common/nestedSelection/constructTree'
import optionNode from '@/components/common/nestedSelection/optionNode'
let qualityUrl = global.qualityUrl

var validateFunc = function() {}
export default {
  components: {
    optionNode,
  },
  data() {
    let checkIntegerNumber = (rule, value, callback) => {
      //if (value.indexOf('.') != -1) {
      //   callback(new Error('请输入整数'))
      // } else {
      //   callback()
      // }
    }
    return {
      seatGroupOptions: [], // 坐席组
      /* eslint-disable */
      reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Model: {
        firstQaUserName: '',
        firstQaUserName$CName: '质检员姓名',
        firstAssignTime: [],
        firstAssignTime$CName: '分发时间',
        score_Min: '',
        score_Min$CName: '质检得分(最小值)',
        score_Max: '',
        score_Max$CName: '质检得分(最大值)',
        firstQaUserNameNo: '',
        firstQaUserNameNo$CName: '质检员工号',
        seatNo: '',
        seatNo$CName: '坐席工号',
        seatName: '',
        seatName$CName: '坐席姓名',
        deptId: '',
        deptId$CName: '坐席组',
        wholeContent_firstKey: '',
        wholeContent_firstLogic: '',
        wholeContent_secondKey: '',
        wholeContent_MidLogic: '',
        wholeContent_thirdKey: '',
        wholeContent_LastLogic: '',
        wholeContent_LastKey: '',
      },
      reQaSampoolRenwu_reQaSampoolSeat_recordingContent_Rules: {
        callTime_Min: [
          {
            validator: checkIntegerNumber,
            trigger: 'blur',
          },
        ],
        callTime_Max: [
          {
            validator: checkIntegerNumber,
            trigger: 'blur',
          },
        ],
      },
    }
  },
  mounted() {
    this.getSeatGroupValue()
  },
  methods: {
    getSeatGroupValue() {
      let _this = this
      let url = qualityUrl + '/pageConstant/getValue.do'
      let searchParam = {}
      searchParam.keys = 'seatGroup'
      this.axios
        .post(url, qs.stringify(searchParam))
        .then(function(response) {
          // _this.seatGroupOptions = response.data.seatGroup

          _this.seatGroupOptions = constructTree(response.data.seatGroup)
          // _this.seatGroupOptions = constructTree([
          //   { id: 1, pdptid: 2, name: '1' },
          //   { id: 2, pdptid: null, name: '2' },
          //   { id: 3, pdptid: 2, name: '3' },
          //   { id: 4, pdptid: 1, name: '4' },
          // ])

          console.log(
            constructTree([
              { id: 1, pdptid: 2, name: '1' },
              { id: 2, pdptid: null, name: '2' },
              { id: 3, pdptid: 2, name: '3' },
              { id: 4, pdptid: 1, name: '4' },
            ])
          )
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取常量值出现问题',
          })
        })
    },
  },
}
</script>

<style scoped>
.mySelect /deep/ .el-scrollbar__wrap {
  height: 260px;
}
</style>
