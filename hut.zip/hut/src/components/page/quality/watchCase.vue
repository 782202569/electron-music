<template>
  <div id="watchCase" class="watchCase">
    <div class="watchCase-header">
      <el-form ref="form" :model="form" :inline="true" style="margin-top: 10px;">
        <el-form-item>
          <el-input style="width:180px;" v-model="form.name"></el-input>
          <el-button type="primary" style="margin-left: 10px;" @click="searchById"
            >查询</el-button
          >
        </el-form-item>
      </el-form>
    </div>
    <div class="watchCase-content">
      <div class="watchCase-left">
        <div class="tree">
          <el-tree
            @node-click="clickOneNode"
            :data="treedata"
            :props="defaultProps"
            highlight-current
            node-key="caseClassId"
            :current-node-key="nodeKey"
            ref="tree"
            :expand-on-click-node="false"
            default-expand-all
          >
          </el-tree>
        </div>
      </div>
      <div class="watchCase-right">
        <div class="container">
          <div class="table">
            <div style="padding-left: 10px;">
              <el-table border ref="multipleTable" :data="tableData" style="">
                <el-table-column type="index" label="序号" width="100"> </el-table-column>
                <el-table-column prop="callId" label="录音编号">
                  <template scope="scope">
                    <el-button type="text" @click="showDetail(scope.row.callId, scope.row.recordFileURL)">{{
                      scope.row.callId
                    }}</el-button>
                  </template>
                </el-table-column>
                <el-table-column prop="seatName" label="坐席姓名"> </el-table-column>
                <el-table-column
                  prop="callSTime"
                  :formatter="dateFormat"
                  label="录音时间"
                >
                </el-table-column>
                <el-table-column prop="caseRemark" label="案例理由"> </el-table-column>
                <el-table-column label="操作" width="300">
                  <template scope="scope">
                    <i
                      class="iconfont icon-chakan"
                      style="cursor:pointer;margin-right:10px;"
                      @click="showDetail(scope.row.callId, scope.row.recordFileURL)"
                    >
                      <i style="font-family: '微软雅黑';margin-left:4px;font-size:14px"
                        >查看</i
                      >
                    </i>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="autoGrading-page">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="pageindex"
              :page-sizes="[10, 20, 30, 40]"
              :page-size="pagesize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="totalCount"
            >
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<style lang="less" scoped="scoped">
.watchCase {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .watchCase-content {
    padding-top: 58px;
    padding-bottom: 10px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    .watchCase-left {
      width: 220px;
      height: 100%;
      float: left;
      position: relative;
      .tree {
        position: absolute;
        top: 10px;
        left: 0px;
        bottom: 0px;
        overflow: auto;
        width: 100%;
        cursor: pointer;
      }
    }
    .watchCase-right {
      height: 100%;
      margin-left: 220px;
      position: relative;
      border-left: 1px solid #d1dbe5;
      .container {
        overflow: hidden;
        height: 100%;
        position: relative;
        .autoGrading-page {
          right: 10px;
          position: absolute;
          bottom: 10px;
        }
        .table {
          width: 100%;
          position: absolute;
          top: 0px;
          bottom: 60px;
          cursor: pointer;
          overflow-y: auto;
        }
      }
    }
  }
  .watchCase-header {
    border-bottom: 1px dashed #d1dbe7;
    right: 0;
    top: 0;
    width: 100%;
    position: absolute;
    text-align: right;
    height: 54px;
  }
}
</style>
<style lang="less">
#watchCase {
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
  .el-tree {
    border: none;
  }
}
</style>
<script>
import Qs from 'qs'
import global from '../../../global.js'
let qualityUrl = global.qualityUrl
import formatdate from '../../../utils/formatdate.js'
import recordingplay from '../recordingPlay/recordingPlayNew.vue'
import bus from '../../common/bus.js'
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      recordDialogVisible: false,
      form: {
        name: '',
      },
      treedata: [],
      defaultProps: {
        children: 'children',
        label: 'label',
      },
      treeid: '',
      clist: [],
      totalCount: 0,
      pageindex: 1,
      pagesize: 20,
      current: 1,
      tableData: [],
      nodeKey: '',
    }
  },
  methods: {
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'watchCase'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlay')
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    searchById: function() {
      this.queryCaseDetail()
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.queryCaseDetail()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.queryCaseDetail()
    },
    // 获取tree
    getCaseClassTreeData: function() {
      this.axios
        .post(qualityUrl + '/ivsCaseClass/getCaseClassTreeData.do')
        .then((res) => {
          let listenDataTwo = res.data
          let treesTwo = []
          this.getOneTree(listenDataTwo, treesTwo)
          this.treedata = treesTwo
          if (treesTwo != null || treesTwo != '') {
            this.ppid = '1'
          } else {
            this.ppid = ''
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 点击一行tree节点
    clickOneNode: function(row) {
      console.log(row)
      this.rows = row
      this.treeid = row.caseClassId
      this.clist = row.children
      this.queryCaseDetail() // 案例列表
    },
    // 案例列表
    queryCaseDetail: function() {
      let params = {
        caseClassId: this.treeid,
        casesFlag: '2',
        objectId: this.form.name,
        pageSize: this.pagesize,
        pageNumber: this.pageindex,
      }
      let obj = {}
      obj.searchModel = params
      this.$store.commit('setRecordingPlayPage', obj)
      this.axios
        .post(qualityUrl + '/caseManage/queryCaseDetail.do', Qs.stringify(params))
        .then((res) => {
          this.tableData = res.data.Data
          this.totalCount = res.data.Count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 给tree重新赋值
    getOneTree: function(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        if (value.length == 0) {
          this.treedata = []
        } else {
          if (value[i].children == null) {
            treeList[i] = {
              id: value[i].value.caseClassId,
              caseClassId: value[i].value.caseClassId,
              parentClassId: value[i].value.parentClassId,
              remark: value[i].value.remark,
              label: value[i].name,
              children: null,
            }
          } else {
            treeList[i] = {
              id: value[i].value.caseClassId,
              caseClassId: value[i].value.caseClassId,
              label: value[i].name,
              remark: value[i].value.remark,
              parentClassId: value[i].value.parentClassId,
              children: this.getOneTree(value[i].children, []),
            }
          }
        }
      }
      return treeList
    },
  },
  created() {
    this.getCaseClassTreeData()
    if (
      this.recordingPlayPage.fromPage == 'watchCase' &&
      this.recordingPlayPage.searchModel.pageNumber
    ) {
      this.pageindex = this.recordingPlayPage.searchModel.pageNumber
      this.pagesize = this.recordingPlayPage.searchModel.pageSize
      this.form.name = this.recordingPlayPage.searchModel.objectId
      this.treeid = this.recordingPlayPage.searchModel.caseClassId
      this.nodeKey = this.treeid
      this.queryCaseDetail()
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
