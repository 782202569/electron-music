<template>
  <div>
    <div v-show="titleLeftsmell">
      <div style="width: 100%;border-top: 1px solid #E0E6ED;">
        <div class="titleLeftsmell" style="color: #20A0FF;">
          筛选策略
        </div>
        <i class="angle-right">></i>
        <div class="contTitle">
          选择录音
        </div>
        <i class="angle-right">></i>
        <div class="contTitle">
          分配
        </div>
      </div>
      <div class="dealCenter" style="width: 100%;float: left;background: white;">
        <el-form label-width="100px" :rules="oneRules" :model="taskModel" ref="oneForm">
          <div class="contentAlltitle" style="padding: 20px;">
            <el-col :span="24">
              <el-form-item label="任务名称" prop="projectNameCreate">
                <el-input
                  v-model="taskModel.projectNameCreate"
                  placeholder="请输入任务名称"
                  style="width: 316px;"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <h3 style="padding: 12px 16px 12px 0px;">录音属性</h3>
              <el-col :span="24">
                <el-col :span="12">
                  <el-form-item label="录音编号" style="margin-right: 0;">
                    <el-input v-model="taskModel.callId"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="主叫号码" style="margin-right: 0;">
                    <el-input v-model="taskModel.callNo"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
              <el-col :span="24">
                <el-col :span="12">
                  <el-form-item label="录音时间" prop="callSTime" clearable>
                    <el-date-picker
                      v-model="taskModel.callSTime"
                      type="datetimerange"
                      align="right"
                      style="max-width:194px;"
                      :default-time="['00:00:00', '23:59:59']"
                    >
                    </el-date-picker>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="被叫号码" style="margin-right: 0;">
                    <el-input v-model="taskModel.calledNo"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
              <el-col :span="13">
                <el-form-item label="通话时长">
                  <el-col :span="6">
                    <el-form-item prop="callTime_Min" style="margin-right: 0;">
                      <el-input v-model="taskModel.callTime_Min"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col class="line" :span="2" style="text-align: center;">-</el-col>
                  <el-col :span="6">
                    <el-form-item prop="callTime_Max" style="margin-right: 0;">
                      <el-input v-model="taskModel.callTime_Max"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col class="line" :span="1">&nbsp;</el-col>
                  <el-col :span="8">
                    <el-form-item prop="timeType" style="margin-right: 0;">
                      <el-select v-model="taskModel.timeType">
                        <el-option
                          v-for="item in timecellAttrs"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"
                        >
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-form-item>
              </el-col>
            </el-col>
          </div>
          <my-comp ref="myComp"></my-comp>
          <div class="footerAll" style="width: 100%;height: 68px;">
            <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
              <el-button @click="editCancel">取 消</el-button>
              <el-button
                @click="editNextcancel"
                type="primary"
                style="margin-right: 18px;"
                >筛 选</el-button
              >
            </div>
          </div>
        </el-form>
      </div>
    </div>
    <div v-show="asd">
      <div style="width: 100%;border-top: 1px solid #E0E6ED;">
        <div class="titleLeftsmell">
          筛选策略
        </div>
        <i class="angle-right">></i>
        <div class="contTitle" style="color: #20A0FF;">
          选择录音
        </div>
        <i class="angle-right">></i>
        <div class="contTitle">
          分配
        </div>
      </div>
      <div class="content">
        <div class="table">
          <div
            class="attrs recordsList recordsList_table"
            style="padding: 0 26px 0 19px;"
          >
            <el-table
              ref="recordsListTable"
              :data="recordsList"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" fixed width="55"> </el-table-column>
              <el-table-column label="录音编号" fixed prop="callId" width="100">
                <template scope="scope">
                  <el-button type="text" class="callId">{{ scope.row.callId }}</el-button>
                </template>
              </el-table-column>
              <el-table-column
                label="录音时间"
                prop="callSTime"
                :formatter="createTimeFilter"
                width="100"
              >
              </el-table-column>
              <el-table-column
                prop="callTime"
                label="通话时长"
                :formatter="convertCallTime"
                width="100"
              >
              </el-table-column>
              <el-table-column prop="mblNo" label="客户电话" show-overflow-tooltip>
              </el-table-column>
              <el-table-column prop="seatName" label="坐席姓名" show-overflow-tooltip>
              </el-table-column>
            </el-table>
          </div>
          <div class="page">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="pageSizes"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <div
        class="footerAll"
        style="width: 100%;height: 68px;border-top: 1px solid #E0E6ED;"
      >
        <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
          <el-button @click="editCancel">取 消</el-button>
          <el-button @click="dealogSecondnext" type="primary" style="margin-right: 18px;"
            >分 配</el-button
          >
        </div>
      </div>
    </div>
    <div v-show="threeDeal">
      <div class="titleLeftsmell">
        筛选策略
      </div>
      <i class="angle-right">></i>
      <div class="contTitle">
        选择录音
      </div>
      <i class="angle-right">></i>
      <div class="contTitle" style="color: #20A0FF;">
        分配
      </div>
      <div class="finalyNext">
        <el-form
          label-width="84px"
          :model="distributeInspectorModel"
          ref="distributeInspectorModel"
          :rules="oneRules"
        >
          <el-form-item label="质检模板" prop="templeateId">
            <el-select
              v-model="distributeInspectorModel.templeateId"
              placeholder="请选择"
              style="width: 316px;margin-bottom: 44px;"
            >
              <el-option
                v-for="item in templeateIds"
                :label="item.modleTitle"
                :value="item.modleId"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="完成时间" prop="day">
            <el-select
              clearable
              v-model="distributeInspectorModel.day"
              placeholder="请选择"
              style="width: 316px;margin-bottom: 44px;"
            >
              <el-option label="一天" value="1"></el-option>
              <el-option label="二天" value="2"></el-option>
              <el-option label="三天" value="3"></el-option>
              <el-option label="四天" value="4"></el-option>
              <el-option label="五天" value="5"></el-option>
              <el-option label="六天" value="6"></el-option>
              <el-option label="七天" value="7"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="选择质检员" prop="people">
            <el-select
              @change="confirmAdd"
              v-model="distributeInspectorModel.people"
              multiple
              placeholder="请选择质检员"
              style="width: 316px;margin-bottom: 44px;"
            >
              <el-option
                v-for="item in people"
                :value="item.account"
                :label="item.realName"
                :key="item.account"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div style="width: 100%;line-height: 40px;">
        <div style="margin-left: 20px;height: 40px;display: inline-block;">
          剩余未分配：{{ rest }}
        </div>
        <div class="averger" style="margin-left: 20px;display: inline-block;">
          <el-form label-width="30px" :inline="true">
            <el-form-item>
              <el-button @click="confirmAdd" style="padding: 10px 20px;"
                >平均分配</el-button
              >
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div class="tableFindset">
        <el-table :data="tableData" style="width: 100%">
          <el-table-column prop="realName" label="质检员姓名" width="180">
          </el-table-column>
          <el-table-column prop="month" label="当月分配" width="180"> </el-table-column>
          <el-table-column label="当前分配">
            <template scope="scope">
              <el-input
                v-if="checkShow(scope.$index, 'edit')"
                class="currentDistributeCount"
                v-model="currentDistribute[scope.$index]"
              ></el-input>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div
        class="footerAll"
        style="width: 100%;height: 68px;border-top: 1px solid #E0E6ED;"
      >
        <div class="footInside" style="float: right; height: 53px;padding-top: 15px">
          <el-button @click="editCancel">取 消</el-button>
          <el-button
            @click="distributeInspector"
            type="primary"
            style="margin-right: 18px;"
            >确 定</el-button
          >
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import nativeaxios from 'axios'
import cache from '../../../utils/cache.js'
import global from '../../../global.js'
import formatdate from '../../../utils/formatdate.js'
import qs from 'qs'
import moment from 'moment'
import commonUtil from '../../../utils/commonUtil.js'
import myComp from './formEngine/peopleSamplingMyComp'
import bus from '../../common/bus.js'
let qualityUrl = global.qualityUrl
export default {
  components: {
    'my-comp': myComp,
    // 'my-comp': (resolve, reject) => {
    //   nativeaxios
    //     .post(
    //       global.formEngineUrl +
    //         '/creating.do?formIds=fastSampoolYuangong,fastSampoolYuyin,recordingContent&accessToken=' +
    //         cache.getItem('tgt_id')
    //     )
    //     .then(function(response) {
    //       $('body').append(response.data.Validate)
    //       let myHtml = response.data.Html
    //       resolve({
    //         template: myHtml,
    //         watch: {
    //           // 监听
    //         },
    //         data() {
    //           let checkIntegerNumber = (rule, value, callback) => {
    //             //if (value.indexOf('.') != -1) {
    //             // callback(new Error('请输入整数'))
    //             //} else {
    //             //   callback()
    //             // }
    //           }
    //           return {
    //             seatGroupOptions: [], // 坐席组
    //             /* eslint-disable */
    //             fastSampoolYuangong_fastSampoolYuyin_recordingContent_Model: JSON.parse(
    //               JSON.stringify(
    //                 fastSampoolYuangong_fastSampoolYuyin_recordingContent_
    //               )
    //             ),
    //             fastSampoolYuangong_fastSampoolYuyin_recordingContent_Rules: {
    //               callTime_Min: [
    //                 {
    //                   validator: checkIntegerNumber,
    //                   trigger: 'blur',
    //                 },
    //               ],
    //               callTime_Max: [
    //                 {
    //                   validator: checkIntegerNumber,
    //                   trigger: 'blur',
    //                 },
    //               ],
    //             },

    //             /* eslint-enable */
    //           }
    //         },
    //         mounted() {
    //           this.getSeatGroupValue()
    //         },
    //         methods: {
    //           getSeatGroupValue() {
    //             let _this = this
    //             let url = qualityUrl + '/pageConstant/getValue.do'
    //             let searchParam = {}
    //             searchParam.keys = 'seatGroup'
    //             this.axios
    //               .post(url, qs.stringify(searchParam))
    //               .then(function(response) {
    //                 _this.seatGroupOptions = response.data.seatGroup
    //               })
    //               .catch(function() {
    //                 _this.$message({
    //                   type: 'error',
    //                   message: '获取常量值出现问题',
    //                 })
    //               })
    //           },
    //         },
    //       })
    //     })
    // },
  },
  data() {
    let checkName = (rule, value, callback) => {
      console.log(value)
      if (value.indexOf(' ') >= 0) {
        callback(new Error('请勿输入特殊字符'))
      }
    }
    return {
      cc: '',
      titleLeftsmell: true,
      threeDeal: false,
      recordsList: [], // 录音列表
      checkedRecordList: [], // 选中的录音列表
      callId: '',
      valDeas: '',
      sampleType: 'custom',
      templeateIds: [], // 质检模板列表
      timecellAttrs: [
        {
          value: '2',
          label: '秒',
        },
        {
          value: '1',
          label: '分',
        },

        {
          value: '0',
          label: '时',
        },
      ],
      taskModel: {
        projectNameCreate: '',
        callId: '', // 录音编号
        callNo: '', // 主叫号码
        calledNo: '', // 被叫号码
        callSTime: '', // 录音时间
        callTime_Min: '',
        callTime_Max: '',
        timeType: '2', // 秒分时
      },
      asd: false, // 录音编号
      currentPage: 1, // 当前页码
      displayType: 1,
      currentDistribute: [], // 当前分配列表
      tableData: [],
      people: [],
      oneRules: {
        people: [
          {
            required: true,
            message: '请选择质检员',
            trigger: 'blur',
          },
        ],
        templeateId: [
          {
            required: true,
            message: '请选择模板 ',
            trigger: 'blur',
          },
        ],
        day: [
          {
            required: true,
            message: '请选择完成天数！',
            trigger: 'blur',
          },
        ],
        projectNameCreate: [
          {
            required: true,
            message: '请输入任务名称！',
            trigger: 'blur',
          },
          { required: true, validator: checkName, trigger: 'blur' },
        ],
      },
      distributeInspectorModel: {
        templeateId: '',
        day: '',
        people: [],
      }, // 分配质检员表单
      taskType: [
        {
          label: '任务方式',
          value: '',
        },
        {
          label: '系统抽样',
          value: '1',
        },
        {
          label: '人工抽样',
          value: '2',
        },
      ],
      modleType: '7',
      currentStrategy: {},
      tempNum: '', // 临时变量
      pageSizes: [10, 15, 20, 25],
      total: 0, // 记录总条数
      pageSize: 20, // 每页显示的记录条数
      TaskAttr: {
        projectName: '',
        deaolName: '',
        deaolType: '',
      },
    }
  },
  methods: {
    handleCurrentChange(val) {
      this.checkedRecordList = []
      this.currentPage = val
    },
    handleSizeChange(val) {
      this.checkedRecordList = []
      this.pageSize = val
    },
    dealogSecondnext: function() {
      if (this.checkedRecordList.length < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择样本',
        })
        return false
      }
      this.asd = false
      this.threeDeal = true
      this.resetForm('distributeInspectorModel')
      this.getModleInfoByCondition()
      this.distributeTask()
      this.tableData = []
    },
    // 重置表单
    resetForm(formName) {
      if (formName == 'distributeInspectorModel') {
        this.tableData = []
        this.currentDistribute = []
        this.tempNum = 0
      }
    },
    // 给质检员分配任务
    distributeInspector() {
      if (this.tempNum < 0 || this.tempNum > 0) {
        this.$message({
          type: 'error',
          message: '任务分配总数量和录音总数量不匹配，请重新分配',
        })
        return false
      }
      let _this = this
      let params = {}
      params.people = this.distributeInspectorModel.people
      params.callId = this.checkedRecordList
      params.directFenPei = '1' // 1代表直接分配，2代表样本池分配
      params.assignWay = '4'
      params.templeateId = this.distributeInspectorModel.templeateId
      params.day = this.distributeInspectorModel.day
      params.type = '1'
      params.currentCount = this.currentDistribute
      params.callClass = '1'
      params.projectName = this.taskModel.projectNameCreate
      params.strategyObject = JSON.stringify(this.valDeas)
      if (commonUtil.isBlank(params['templeateId'])) {
        this.$message.warning('请选择质检模板!')
        return
      }

      if (commonUtil.isBlank(params['day'])) {
        this.$message.warning('请选择天数')
        return
      }
      this.checkFaq().then((val)=>{
        if(val){
          this.$message.error(val)
          return
        }
        let url = global.qualityUrl + '/spc/dqinsert.do'
        this.axios
          .post(url, qs.stringify(params))
          .then(function(response) {
            _this.$message({
              type: 'success',
              message: '任务已成功分配',
            })
            _this.$emit('send', false)
            _this.searchSample()
          })
          .catch(function() {
            _this.$message({
              type: 'error',
              message: '任务分配失败',
            })
          })
      })
    },
    // 确认添加（质检员）
    confirmAdd() {
      this.tableData = []
      $('.el-select__tags')
        .children('span')
        .remove()
      if (this.distributeInspectorModel.people.length >= 1) {
        $('.el-select__tags').append(
          '<span class="playuer">已选择' +
            this.distributeInspectorModel.people.length +
            '人</span>'
        )
      }
      console.log(this.distributeInspectorModel.people.length)
      this.getDistributes()
    },
    // 获取质检员任务分配情况
    getDistributes() {
      let _this = this
      if (this.distributeInspectorModel.people.length < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择质检员',
        })
        return false
      }
      let url = global.qualityUrl + '/spc/getAssignWay.do'
      let params = {}
      params.way = '4'
      params.callIDCount = this.checkedRecordList.length
      params.people = this.distributeInspectorModel.people.join(',')
      params.callClass = '1'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.tableData = response.data.Data
          _this.currentDistribute = []
          _this.tableData.forEach(function(item) {
            _this.currentDistribute.push(item.current)
          })
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检员任务分配情况失败',
          })
        })
    },
    // 获取质检员方法
    distributeTask() {
      let _this = this
      let url = global.qualityUrl + '/distributeTask.do'
      this.axios
        .post(url)
        .then(function(response) {
          _this.people = response.data.Data
          console.log(_this.people[0])
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检员列表出现问题',
          })
        })
    },
    // 检查当前分配输入的是否是数字
    checkNumber(index) {
      this.countHasError = false
      if (isNaN(this.currentDistribute[index])) {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
        this.countHasError = true
        return false
      } else {
        if (parseInt(this.currentDistribute[index]) == 0) {
          // 如果是0，删除改行数据，同时该人员的选中状态去掉
          let _this = this
          this.distributeInspectorModel.people.forEach(function(i, n) {
            if (n.account == _this.tableData[index].account) {
              _this.distributeInspectorModel.people.splice(i, 1)
            }
          })
          this.tableData.splice(index, 1)
          this.currentDistribute.splice(index, 1)
        }
      }
    },
    // 控制table中编辑和保存状态时表格内容的展示
    checkShow(index, flag) {
      if (flag == 'edit' && this.editCountIndex !== index) {
        return true
      } else if (flag == 'save' && this.editCountIndex !== index) {
        return false
      } else if (flag == 'save' && this.editCountIndex === index) {
        return true
      } else {
        return false
      }
    },
    // 点击table中编辑和保存按钮时数据状态的变化
    editTableCell(index, flag) {
      if (this.countHasError) {
        return false
      }
      if (flag == 'edit') {
        this.editCountIndex = index
      } else {
        if (isNaN(this.currentDistribute[index])) {
          this.countHasError = true
          return false
        }
        this.editCountIndex = ''
      }
    },
    // 获取质检模板
    getModleInfoByCondition() {
      let _this = this
      let params = {}
      params.modleType = this.modleType
      params.pageindex = this.currentPage
      params.pagesize = this.pageSize
      let url = global.qualityUrl + '/manualQualityAssurance/getModleInfoByCondition.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.templeateIds = response.data.Data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检模板出现问题',
          })
        })
    },
    checkFaq(){
      return new Promise((resolve,reject)=>{
        let idx = this.templeateIds.findIndex((item)=>{return item.modleId === this.distributeInspectorModel.templeateId})
        let updateTime = ''
        if(idx !== -1){
          updateTime = this.templeateIds[idx].updateTime
        }
        let params = {
          modleId:this.distributeInspectorModel.templeateId,
          updateTime:updateTime
        }
        this.axios
          .post(qualityUrl+'/manualQualityAssurance/getFaqCheckModel.do', qs.stringify(params))
          .then(function(response) {
            let {flag,data} =  response.data
            if (flag) {
              resolve('')
            } else {
              resolve(data)
            }
          })
          .catch((err)=>{reject(err)})
      })
    },
    getParams(param, formId) {
      for (let item in formId) {
        if (typeof formId[item] == 'string') {
          param[item] = formId[item]
        } else if (formId[item] instanceof Array) {
          if (formId[item].length == 2) {
            param[item + '_Min'] = formId[item][0]
            param[item + '_Max'] = formId[item][1]
          } else {
            param[item + '_Min'] = ''
            param[item + '_Max'] = ''
          }
        } else if (typeof formId[item] == 'object') {
          for (let jtm in formId[item]) {
            param[jtm] = formId[item][jtm]
          }
        }
      }
      return param
    },
    // 获取抽样结果（录音列表）
    getRecordsList(strateObject) {
      console.log(strateObject)
      this.checkedRecordList = []
      let _this = this
      let myComp = this.$refs.myComp
      let searchModel = {}
      searchModel.pageNumber = this.currentPage
      searchModel.pageSize = this.pageSize
      searchModel.callSTime_Min = this.taskModel.callSTime[0] || ''
      searchModel.callSTime_Max = this.taskModel.callSTime[1] || ''
      searchModel.callId = this.taskModel.callId
      searchModel.callNo = this.taskModel.callNo
      searchModel.calledNo = this.taskModel.calledNo
      searchModel.callTime_Min = this.taskModel.callTime_Min
      searchModel.callTime_Max = this.taskModel.callTime_Max
      searchModel.timeType = this.taskModel.timeType
      searchModel.sortType = 'callSTime'
      let obj = {}
      obj.searchModel = searchModel
      obj.searchModel.strateObject = myComp
        ? myComp.fastSampoolYuangong_fastSampoolYuyin_recordingContent_Model
        : ''
      obj.searchModel.sampleType = this.sampleType
      obj.searchModel.displayType = this.displayType
      obj.searchModel.currentStrategy = this.currentStrategy
      this.$store.commit('setRecordingPlayPage', obj)
      if (strateObject) {
        _this.getParams(searchModel, strateObject)
      } else {
        _this.getParams(
          searchModel,
          myComp.fastSampoolYuangong_fastSampoolYuyin_recordingContent_Model
        )
      }
      // TODO
      let keyworld = [
        searchModel.wholeContent_firstKey,
        searchModel.wholeContent_secondKey,
        searchModel.wholeContent_thirdKey,
        searchModel.wholeContent_LastKey,
      ].join(' ')
      console.log(keyworld)
      if (keyworld.trim() != '' && keyworld != null) {
        this.$store.commit('setKeywordsHigh', {
          keywords: keyworld,
        })
      } else {
        this.$store.commit('setKeywordsHigh', null)
      }
      // TODO End

      // 关键词组合逻辑处理
      let keyword = ''
      if (strateObject) {
        keyword = _this.getKeyword(strateObject)
      } else {
        keyword = _this.getKeyword(
          myComp.fastSampoolYuangong_fastSampoolYuyin_recordingContent_Model
        )
      }
      searchModel['wholeContent'] = keyword
      if (searchModel['callSTime_Min']) {
        searchModel['callSTime_Min'] = formatdate.formatDate(searchModel['callSTime_Min'])
      }
      if (searchModel['callSTime_Max']) {
        searchModel['callSTime_Max'] = formatdate.formatDate(searchModel['callSTime_Max'])
      }
      console.log(searchModel)
      this.valDeas = obj.searchModel.strateObject
      let url = global.qualityUrl + '/manualSampling/startSampleIncoming.do'
      this.axios
        .post(url, qs.stringify(searchModel))
        .then(function(response) {
          _this.recordsList = response.data.Data
          _this.rightContent = 'records'
          _this.total = response.data.Count
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '抽取样本出现问题',
          })
        })
    },
    // 查询样本
    searchSample() {
      this.checkedRecordList = []
      this.getRecordsList()
    },
    // 转换录音时长格式
    convertCallTime(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    // 转换表格中的时间
    createTimeFilter(row, column, cellValue) {
      return moment(cellValue).format('YYYY-MM-DD hh:mm:ss')
    },
    // 调到录音播放页
    showDetail(id) {
      let obj = {}
      obj.from = 'artificialSample'
      obj.callId = id
      obj.callStatus = true
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 录音table中行的选中状态变化时触发(val为选中的object)
    handleSelectionChange(val) {
      this.checkedRecordList.length = 0
      let _this = this
      val.forEach(function(item) {
        _this.checkedRecordList.push(item.callId)
      })
    },
    editCancel: function() {
      let _this = this
      this.$nextTick(function() {
        _this.$refs['myComp']['$refs'][
          'fastSampoolYuangong_fastSampoolYuyin_recordingContent_Ref'
        ].resetFields()
      })
      this.asd = false
      this.threeDeal = false
      this.titleLeftsmell = true
      this.$emit('send', false)
    },
    editNextcancel: function() {
      let _this = this
      this.$refs.oneForm.validate(function(validate) {
        if (!validate) {
          throw new Error('填写必填项')
        }
      })
      let params = {
        projectName: this.taskModel.projectNameCreate,
        sampleType: '1',
      }
      this.axios
        .post(qualityUrl + '/spc/sampleTaskNameIsExist.do', qs.stringify(params))
        .then(function(response) {
          if (response.data.Data) {
            _this.asd = true
            _this.titleLeftsmell = false
            _this.searchSample()
          } else {
            _this.$message({
              type: 'error',
              message: '已存在相同名称的任务，请重新输入',
            })
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '任务筛选失败',
          })
        })
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    // 通过策略抽样
    searchSampleByStrategy(strategy) {
      this.currentStrategy = strategy
      let stratObject = JSON.parse(strategy.strategyObject)
      this.getRecordsList(stratObject)
    },
    // 编辑策略按钮
    editStrategy(strategy) {
      this.rightContent = 'editStrategy'
      this.strategyId = strategy.strategyId
      // 获取引用
      let upComp = this.$refs.updateMyComp
      let stratObj = JSON.parse(strategy.strategyObject)
      upComp.fastSampoolYuangong_fastSampoolYuyin_recordingContent_Model = stratObj
      this.modifyConditionsModel =
        upComp.fastSampoolYuangong_fastSampoolYuyin_recordingContent_Model
      // this.getStrategyForms()
    },
    // 保存编辑好的策略
    saveEditStrategy() {
      let _this = this
      let url = global.qualityUrl + '/ivsStrategy/updateStrategyObject.do'
      let params = {}
      params.strategyId = this.strategyId
      // 不需要做时间处理
      // if (this.modifyConditionsModel['callSTime']) {
      //   if (this.modifyConditionsModel['callSTime'][0]) {
      //     this.modifyConditionsModel['callSTime'][0] = this.modifyConditionsModel['callSTime'][0].getTime()
      //   }
      //   if (this.modifyConditionsModel['callSTime'][1]) {
      //     this.modifyConditionsModel['callSTime'][1] = this.modifyConditionsModel['callSTime'][1].getTime()
      //   }
      // }
      params.strategyObject = JSON.stringify(this.modifyConditionsModel)
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.getStrategyList()
          _this.$message({
            type: 'success',
            message: '策略编辑成功',
          })
          _this.cancleEditStrategy()
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '策略保存出现问题',
          })
        })
    },
    // 获取策略列表
    getStrategyList() {
      let _this = this
      let url = global.qualityUrl + '/ivsStrategy/getStrategyList.do'
      this.axios
        .post(
          url,
          qs.stringify({
            status: this.status,
          })
        )
        .then(function(response) {
          _this.strategyList = []
          _this.strategyList = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取策略列表出现问题',
          })
        })
    },
    getKeyword(params) {
      let str = ''
      if (params['wholeContent_firstKey']) {
        str += params['wholeContent_firstKey'] + ' '
        if (params['wholeContent_firstLogic'] && params['wholeContent_secondKey']) {
          str +=
            params['wholeContent_firstLogic'] + ' ' + params['wholeContent_secondKey']
          if (params['wholeContent_MidLogic']) {
            if (params['wholeContent_thirdKey']) {
              str += ' ' + params['wholeContent_MidLogic'] + ' '
              str += params['wholeContent_thirdKey'] + ' '
              if (params['wholeContent_LastLogic'] && params['wholeContent_LastKey']) {
                str +=
                  params['wholeContent_LastLogic'] + ' ' + params['wholeContent_LastKey']
              }
            }
          }
        }
      }
      return str
    },
  },
  created() {
    this.recordPlayCloseHandler()
    if (
      this.recordingPlayPage.fromPage === 'artificialSample' &&
      this.recordingPlayPage.searchModel.pageNumber
    ) {
      this.currentPage = this.recordingPlayPage.searchModel.pageNumber
      this.pageSize = this.recordingPlayPage.searchModel.pageSize
    }
  },
  mounted() {
    if (
      this.recordingPlayPage.fromPage === 'artificialSample' &&
      this.recordingPlayPage.searchModel.pageNumber
    ) {
      this.sampleType = this.recordingPlayPage.searchModel.sampleType
      this.displayType = this.recordingPlayPage.searchModel.displayType
      if (this.recordingPlayPage.searchModel.sampleType == 'strategy') {
        this.currentStrategy = this.recordingPlayPage.searchModel.currentStrategy
        this.getRecordsList(JSON.parse(this.currentStrategy.strategyObject))
      } else {
        this.$refs.myComp.fastSampoolYuangong_fastSampoolYuyin_recordingContent_Model = this.recordingPlayPage.searchModel.strateObject
        this.getRecordsList()
      }
    }
  },
  filters: {
    timeTransform(val) {
      return val / 1000
    },
  },
  watch: {
    sampleType(val) {
      if (val == 'custom') {
        // this.getRapidSampleForms()
      } else if (val == 'strategy') {
        this.getStrategyList()
      }
    },
    pageSize() {
      if (this.sampleType === 'custom') {
        this.getRecordsList()
      } else {
        this.getRecordsList(JSON.parse(this.currentStrategy.strategyObject))
      }
    },
    currentPage() {
      if (this.sampleType === 'custom') {
        this.getRecordsList()
      } else {
        this.getRecordsList(JSON.parse(this.currentStrategy.strategyObject))
      }
    },
  },
  computed: {
    rest() {
      let sum = 0
      this.currentDistribute.forEach(function(item) {
        if (!isNaN(parseInt(item))) {
          sum += parseInt(item)
        }
      })
      this.tempNum = this.checkedRecordList.length - sum
      return this.checkedRecordList.length - sum > 0
        ? this.checkedRecordList.length - sum
        : 0
    },
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.titleLeftsmell {
  display: inline-block;
  padding: 12px 16px 12px 20px;
}
.contTitle {
  display: inline-block;
  padding: 12px 16px 12px 16px;
}
</style>
<style lang="less">
.dealCenter {
  h3 {
    padding: 12px 16px 12px 20px;
  }
}
</style>
<style type="text/css">
.averger .el-form-item {
  margin-bottom: 0;
}
.playuer {
  padding-left: 15px;
  color: #1f2d3d;
}
</style>
