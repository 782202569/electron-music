<template>
  <div class="caseManage" id="caseManage">
    <div class="caseHeader">
      案例管理
    </div>
    <div class="caseContent">
      <div class="caseLeft">
        <!-- 左侧列表的顶部操作按钮 -->
        <div class="item" v-if="isShowadopt">
          <el-button funcId="alca00" icon="el-icon-plus" @click="eadItiem"></el-button>
          <el-button funcId="alca11" icon="el-icon-edit" @click="caseEdit"></el-button>
          <el-button
            funcId="alca22"
            icon="el-icon-delete"
            @click="deleteTreeNode"
          ></el-button>
        </div>
        <!-- 新增案例弹窗 -->
        <el-dialog
          class="newCase"
          :visible.sync="setInput"
          width="420px"
          title="案例类别名"
          :close-on-click-modal="false"
        >
          <div class="dealCenter">
            <el-form
              label-width="100px"
              :model="addTreeNodeForm"
              ref="addTreeNodeForm"
              :rules="addTreeNodeRules"
            >
              <el-form-item label="案例类别名" class="caseItem" prop="className">
                <el-input
                  v-model="addTreeNodeForm.className"
                  style="width: 80%;"
                ></el-input>
              </el-form-item>
              <!-- <el-form-item label="备注" class="caseItem" prop="remark">
                <el-input v-model="addTreeNodeForm.remark" type="textarea" placeholder="请输入内容" style="width: 80%;"></el-input>
              </el-form-item> -->
            </el-form>
          </div>
          <div
            class="footerAll"
            style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
          >
            <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
              <el-button @click="eadCancel">取 消</el-button>
              <el-button @click="eadGet" type="primary" style="margin-right: 18px;"
                >提 交</el-button
              >
            </div>
          </div>
        </el-dialog>
        <!-- 左侧导航菜单编辑案例弹窗 -->
        <el-dialog
          class="newCase"
          :visible.sync="efitInput"
          width="420px"
          title="案例类别名"
          :close-on-click-modal="false"
        >
          <div class="dealCenter">
            <el-form
              label-width="100px"
              :model="editForm"
              ref="editForm"
              :rules="editTreeNodeRules"
            >
              <el-form-item label="案例类别名" class="caseItem" prop="editName">
                <el-input
                  v-model="editForm.editName"
                  placeholder=""
                  style="width: 80%;"
                ></el-input>
              </el-form-item>
              <!-- <el-form-item label="备注" class="caseItem" prop="editReson">
                <el-input v-model="editForm.editReson" type="textarea" placeholder="请输入内容" style="width: 80%;"></el-input>
              </el-form-item> -->
            </el-form>
          </div>
          <div
            class="footerAll"
            style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
          >
            <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
              <el-button @click="eadCancel">取 消</el-button>
              <el-button @click="edimSubmit" type="primary" style="margin-right: 18px;"
                >提 交</el-button
              >
            </div>
          </div>
        </el-dialog>
        <!-- 表格内编辑弹窗 -->
        <el-dialog
          class="newCase"
          :visible.sync="caseInput"
          width="420px"
          title="案例编辑"
          :close-on-click-modal="false"
        >
          <div class="dealCenter">
            <el-form
              label-width="100px"
              :model="cellForm"
              ref="cellForm"
              :rules="cellRules"
            >
              <el-form-item label="移动到" class="caseItem" prop="caseClassId">
                <el-select
                  v-model="cellForm.caseClassId"
                  placeholder="请选择状态"
                  style="width: 80%;"
                  @change="changeMount(cellForm.caseClassId)"
                >
                  <el-option
                    v-for="item in taskStatusS"
                    :key="item.caseClassId"
                    :label="item.className"
                    :value="item.caseClassId"
                    :disabled="item.disabled"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="理由" class="caseItem" prop="resonRemark">
                <el-input
                  v-model="cellForm.resonRemark"
                  maxlength="255"
                  show-word-limit
                  type="textarea"
                  placeholder="请输入内容"
                  style="width: 80%;"
                ></el-input>
              </el-form-item>
            </el-form>
          </div>
          <div
            class="footerAll"
            style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
          >
            <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
              <el-button @click="eadCancel">取 消</el-button>
              <el-button @click="edimCell" type="primary" style="margin-right: 18px;"
                >提 交</el-button
              >
            </div>
          </div>
        </el-dialog>
        <!-- 审核弹窗 -->
        <el-dialog
          class="newCase"
          :visible.sync="casethrow"
          width="420px"
          title="审批通过"
          :close-on-click-modal="false"
        >
          <div class="dealCenter">
            <el-form
              label-width="100px"
              :model="cellthrowForm"
              ref="cellthrowForm"
              :rules="cellthrowRules"
            >
              <el-form-item label="添加到" class="caseItem" prop="caseClassId">
                <el-select
                  v-model="cellthrowForm.caseClassId"
                  placeholder="请选择状态"
                  style="width: 80%;"
                  @change="changeMount(cellthrowForm.caseClassId)"
                >
                  <el-option
                    v-for="item in taskStatusS"
                    :key="item.caseClassId"
                    :label="item.className"
                    :value="item.caseClassId"
                    :disabled="item.disabled"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="理由" class="caseItem" prop="resonRemark">
                <el-input
                  v-model="cellthrowForm.resonRemark"
                  maxlength="255"
                  show-word-limit
                  type="textarea"
                  placeholder="请输入内容"
                  style="width: 80%;"
                ></el-input>
              </el-form-item>
            </el-form>
          </div>
          <div
            class="footerAll"
            style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
          >
            <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
              <el-button @click="eadCancel">取 消</el-button>
              <el-button @click="edimthrow" type="primary" style="margin-right: 18px;"
                >确 定</el-button
              >
            </div>
          </div>
        </el-dialog>
        <!-- 审批驳回 -->
        <el-dialog
          class="newCase"
          :visible.sync="stopBack"
          width="420px"
          title="审批驳回"
          :close-on-click-modal="false"
        >
          <div class="dealCenter">
            <el-form
              label-width="70px"
              :model="stopbackForm"
              ref="stopbackForm"
              :rules="stopbackRules"
            >
              <el-form-item label="理由" class="caseItem" prop="resonRemark">
                <el-input
                  v-model="stopbackForm.resonRemark"
                  maxlength="255"
                  show-word-limit
                  type="textarea"
                  placeholder="请输入内容"
                  style="width: 80%;"
                ></el-input>
              </el-form-item>
            </el-form>
          </div>
          <div
            class="footerAll"
            style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
          >
            <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
              <el-button @click="eadCancel">取 消</el-button>
              <el-button @click="edimreject" type="primary" style="margin-right: 18px;"
                >确 定</el-button
              >
            </div>
          </div>
        </el-dialog>
        <!-- 左侧导航菜单 -->
        <div class="tree">
          <div
            class="fixDiv active"
            id="caseGood"
            @click="searchById('d2a30ac73bc011e8bb70acd1b8a5627c', 'aa')"
          >
            优秀案例
          </div>
          <div
            class="fixDiv"
            id="caseNot"
            @click="searchById('7600c91e3bc111e8bb70acd1b8a5627c', 'bb')"
          >
            差评案例
          </div>
          <div
            class="fixDiv"
            v-for="(g, index) in caseList"
            :key="g.id"
            @click="clickList(index, g.name, g.value.remark, g.value.caseClassId)"
            :class="caseIopd == g.value.caseClassId ? 'active' : ''"
          >
            <el-tooltip
              :disabled="disabled"
              :content="g.name"
              placement="top-start"
              effect="light"
              width="140"
            >
              <span
                @mouseenter="qwe(g.name)"
                class="fixDivspan"
                @click="searchById(g.value.caseClassId, index)"
                v-bind:class="{ active: index == currentOne }"
                >{{ g.name }}</span
              >
            </el-tooltip>
          </div>
        </div>
        <!-- 当角色为质检主管时显示 -->
        <div @click="clickCase('check')" class="myCase" v-if="isShowadopt">我的审核</div>
        <!-- 当角色不是质检主管和质检员时显示 -->
        <div @click="clickCase('apply')" class="myCase" v-if="isShowPlace">我的申请</div>
      </div>
      <!-- 右侧内容栏 -->
      <div class="caseRight">
        <div class="container" id="container">
          <div class="content" v-show="caseShow">
            <!-- 案例内容表格 -->
            <div class="table" v-loading="tableLoading">
              <div style="padding-left: 10px">
                <el-table
                  border
                  ref="multipleTable"
                  :data="tableData"
                  @select-all="selectAll"
                  @select="selectAll"
                  @row-click="rowClickTable"
                  style=""
                >
                  <el-table-column prop="callId" label="录音编号">
                    <template scope="scope">
                      <el-button
                        type="text"
                        @click="jumpToSound(scope.row.callId, scope.row.calibrateId, scope.row.recordFileURL)"
                        >{{ scope.row.callId }}</el-button
                      >
                    </template>
                  </el-table-column>
                  <el-table-column prop="seatName" label="坐席姓名"> </el-table-column>
                  <el-table-column
                    prop="callSTime"
                    :formatter="dateFormat"
                    label="录音时间"
                    width="160"
                  >
                  </el-table-column>
                  <el-table-column
                    prop="createTime"
                    :formatter="dateFormat"
                    label="添加时间"
                    width="160"
                  >
                  </el-table-column>
                  <el-table-column
                    prop="caseRemark"
                    :show-overflow-tooltip="true"
                    width="150"
                    label="理由"
                  >
                  </el-table-column>
                  <el-table-column label="操作" width="200" v-if="isShowadopt">
                    <template scope="scope">
                      <div style="cursor: pointer;">
                        <i
                          funcId="alca44"
                          @click="
                            editCase(
                              scope.row.callId,
                              scope.row.caseRemark,
                              scope.row.caseId,
                              scope.row.casClassId
                            )
                          "
                          style="font-size: 12px;"
                          ><i style="font-size: 14px; padding-left: 3px;color: #20a0ff;"
                            >编辑</i
                          ></i
                        >
                        <i
                          funcId="alca33"
                          @click="
                            deleteCase(
                              scope.row.caseId,
                              scope.row.callId,
                              scope.row.casClassId
                            )
                          "
                          style="font-size: 12px; margin-right: 10px;"
                          ><i style="font-size: 14px; padding-left: 3px;color: #20a0ff;"
                            >删除</i
                          ></i
                        >
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </div>
            <div class="autoGrading-page">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageindex"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount"
              >
              </el-pagination>
            </div>
          </div>
          <!-- 审核页面 -->
          <div class="content" v-show="!caseShow">
            <div class="mycaseHead">
              <ul>
                <li class="active" id="audited" @click="changeTab">待审核</li>
                <li id="notAudited" @click="changeTabNot">已审核</li>
              </ul>
            </div>
            <!-- 审核表格 -->
            <div class="table" v-show="auditedSet" v-loading="tableLoading">
              <div style="padding-left: 10px">
                <el-table
                  border
                  ref="multipleTableNot"
                  :data="tableDataNot"
                  @select-all="selectAllNot"
                  @select="selectAllNot"
                  @row-click="rowClickTableNot"
                >
                  <el-table-column prop="callId" label="录音编号">
                    <template scope="scope">
                      <el-button
                        type="text"
                        @click="jumpToSound(scope.row.callId, scope.row.calibrateId, scope.row.recordFileURL)"
                        >{{ scope.row.callId }}</el-button
                      >
                    </template>
                  </el-table-column>
                  <el-table-column prop="seatName" label="坐席姓名"> </el-table-column>
                  <el-table-column
                    prop="callSTime"
                    :formatter="dateFormat"
                    label="录音时间"
                    width="160"
                  >
                  </el-table-column>
                  <el-table-column prop="className" label="添加到"> </el-table-column>
                  <el-table-column prop="createUser" v-if="isShowadopt" label="申请人">
                  </el-table-column>
                  <el-table-column
                    prop="createTime"
                    :formatter="dateFormat"
                    label="申请时间"
                    width="160"
                  >
                  </el-table-column>
                  <el-table-column
                    prop="apReaSon"
                    label="申请理由"
                    :show-overflow-tooltip="true"
                    width="100"
                  >
                  </el-table-column>
                  <el-table-column prop="caseFlag" label="审核状态"> </el-table-column>
                  <el-table-column label="操作" width="100" v-if="isShowadopt">
                    <template scope="scope">
                      <div style="cursor: pointer">
                        <i
                          funcId="alca77"
                          @click="
                            adopt(
                              scope.row.callId,
                              scope.row.apReaSon,
                              scope.row.caseId,
                              scope.row.casClassId,
                              scope.row.className,
                              scope.row.objectId
                            )
                          "
                          style="margin-right:10px"
                          ><i style="padding-left: 3px;color: #20a0ff;">通过</i></i
                        >
                        <i
                          funcId="alca88"
                          @click="
                            refuse(
                              scope.row.caseId,
                              scope.row.casClassId,
                              scope.row.objectId
                            )
                          "
                          ><i style="padding-left: 3px;color: #20a0ff;">驳回</i></i
                        >
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </div>
            <!-- 我的申请表格 -->
            <div class="table" v-show="!auditedSet" v-loading="tableLoading">
              <div style="padding-left: 10px">
                <el-table
                  border
                  ref="multipleTableNot"
                  :data="tableDataNotsell"
                  @select-all="selectAllNot"
                  @select="selectAllNot"
                  @row-click="rowClickTableNot"
                >
                  <el-table-column prop="callId" label="录音编号">
                    <template scope="scope">
                      <el-button
                        type="text"
                        @click="jumpToSound(scope.row.callId, scope.row.calibrateId, scope.row.recordFileURL)"
                        >{{ scope.row.callId }}</el-button
                      >
                    </template>
                  </el-table-column>
                  <el-table-column prop="seatName" label="坐席姓名"> </el-table-column>
                  <el-table-column
                    prop="callSTime"
                    :formatter="dateFormat"
                    label="录音时间"
                    width="160"
                  >
                  </el-table-column>
                  <el-table-column prop="className" label="添加到"> </el-table-column>
                  <el-table-column prop="createUser" label="申请人" v-if="isShowadopt">
                  </el-table-column>
                  <el-table-column
                    prop="createTime"
                    :formatter="dateFormat"
                    label="申请时间"
                    width="160"
                  >
                  </el-table-column>
                  <el-table-column label="理由" :show-overflow-tooltip="true" width="150">
                    <template scope="scope">
                      <span
                        v-if="
                          scope.row.caseFlag == '已通过' || scope.row.caseFlag == '已删除'
                        "
                        >{{ scope.row.caseRemark }}</span
                      >
                      <span v-if="scope.row.caseFlag == '已驳回'">{{
                        scope.row.reReason
                      }}</span>
                    </template>
                  </el-table-column>
                  <el-table-column prop="caseFlag" label="审核状态"> </el-table-column>
                </el-table>
              </div>
            </div>
            <!-- 我的审核页码 -->
            <div class="autoGrading-page" v-show="auditedSet">
              <el-pagination
                @size-change="handleSizeChangeNot"
                @current-change="handleCurrentChangeNot"
                :current-page="pageindexNot"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="pagesizeNot"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCountNot"
              >
              </el-pagination>
            </div>
            <!-- 我的申请页码 -->
            <div class="autoGrading-page" v-show="!auditedSet">
              <el-pagination
                @size-change="handleSizeChangeNotSell"
                @current-change="handleCurrentChangeNotSell"
                :current-page="pageindexNotsell"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="pagesizeNotsell"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCountNotsell"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </div>
      <el-dialog
        class="single"
        title="录音播放页面"
        :visible.sync="recordDialogVisible"
        :close-on-click-modal="false"
        :close-on-press-escape="false"
      >
        <div class="recordingplayWrap">
          <recordingplay
            ref="recordPlay"
            @onclose="recordPlayCloseHandler"
            @onminimize="recordPlayMinimizeHandler"
          ></recordingplay>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import Qs from 'qs'
import bus from '../../common/bus.js'
import global from '../../../global.js'
import cache from '../../../utils/cache'
import funcFilter from '@/utils/funcFilter.js'
let qualityUrl = global.qualityUrl
import formatdate from '../../../utils/formatdate.js'
import recordingplay from '../recordingPlay/recordingPlayMultiple.vue'
export default {
  components: {
    // 局部注册
    recordingplay,
  },
  data() {
    return {
      setInput: false,
      efitInput: false,
      caseList: [],
      cellIndex: '',
      caseShow: true,
      auditedSet: true,
      caseIopd: '',
      caseInput: false,
      taskStatus: '',
      taskStatusS: [],
      caseCellid: '',
      rowId: '',
      newClassid: '',
      casethrow: false,
      stopBack: false,
      rejectId: '',
      currentOne: 0,
      isShowPlace: false,
      // isShowdeal: false,
      disabled: true,
      recordDialogVisible: false,
      isShowadopt: true,
      isShoweditCase: false,
      reReason: '',
      namesForm: { name: '' },
      namesFormNot: { name: '' },
      tableData: [],
      tableDataNot: [],
      tableDataNotsell: [],
      treeid: '',
      parentId: '',
      addTreeNodeRules: {
        className: [{ required: true, message: '请输入分类名称！', trigger: 'blur' }],
      },
      editTreeNodeRules: {
        editName: [{ required: true, message: '请输入分类名称！', trigger: 'blur' }],
      },
      cellRules: {
        caseClassId: [{ required: true, message: '请输入分类名称！', trigger: 'blur' }],
      },
      cellthrowRules: {
        caseClassId: [{ required: true, message: '请输入分类名称！', trigger: 'blur' }],
      },
      stopbackRules: {
        resonRemark: [{ required: true, message: '请输入理由！', trigger: 'blur' }],
      },
      editTreeNodeForm: {
        parentClassId: '',
        caseClassId: '',
        className: '',
        remark: '',
        typeid: '',
      },
      addTreeNodeForm: {
        caseClassId: '',
        parentClassId: '',
        className: '',
        remark: '',
        typeid: '',
      },
      editForm: {
        editReson: '',
        editName: '',
      },
      cellForm: {
        resonRemark: '',
        caseClassId: '',
      },
      cellthrowForm: {
        resonRemark: '',
        caseClassId: '',
      },
      stopbackForm: {
        resonRemark: '',
      },
      treedata: [],
      totalCount: 0,
      pageindex: 1,
      pagesize: 20,
      current: 1,
      totalCountNot: 0,
      pageindexNot: 1,
      pagesizeNot: 20,
      totalCountNotsell: 0,
      pageindexNotsell: 1,
      pagesizeNotsell: 20,
      caseIds: '',
      caseClassId: '',
      classId: '',
      remark: '',
      objectId: '',
      objectIdNot: '',
      remarkTwo: '',
      caseIdsAdopt: '',
      refuseModel: false,
      selectedRemovedCaseIds: [],
      role: '',
      roleId: '',
      roleCodeId: [],
      tableLoading: false,
      currentNodeFlag: '',
    }
  },
  methods: {
    qwe: function(text) {
      let re = /[\u4E00-\u9FA5\0-9a-zA-Z]/g
      // console.log(text.match(re).length)
      if (text.match(re).length > 7) {
        this.disabled = false
      } else {
        this.disabled = true
      }
    },
    eadItiem: function() {
      this.setInput = true
      this.addTreeNodeForm.className = ''
      this.addTreeNodeForm.remark = ''
    },
    eadCancel: function() {
      this.setInput = false
      this.efitInput = false
      this.caseInput = false
      this.casethrow = false
      this.stopBack = false
    },
    eadGet: function() {
      this.lodashThrottle.throttle(this.saveTreeNode, this)
    },
    edimSubmit: function() {
      this.lodashThrottle.throttle(this.saveEditNode, this)
    },
    edimCell: function() {
      this.lodashThrottle.throttle(this.saveEditcase, this)
    },
    edimthrow: function() {
      this.lodashThrottle.throttle(this.saveEditcell, this)
    },
    edimreject: function() {
      this.lodashThrottle.throttle(this.saveEditreject, this)
    },
    // 左侧案例导航栏的编辑
    caseEdit() {
      const flag = this.currentNodeFlag
      if (/^(aa|bb|check)$/.test(flag)) {
        this.$message({
          type: 'error',
          message:
            {
              aa: '优秀案例',
              bb: '差评案例',
              check: '我的审核',
            }[flag] + `不能编辑`,
        })
        return
      }
      if (this.caseIopd == '') {
        this.$message({
          message: '请先选择一个案例',
          type: 'warning',
        })
        return
      } else {
        this.efitInput = true
      }
    },
    clickList: function(index, flag, remark, caseIopd) {
      $('.myCase').removeClass('active')
      $('#caseGood').removeClass('active')
      $('#caseNot').removeClass('active')
      this.caseIopd = caseIopd
      this.cellIndex = index
      this.editForm.editName = flag
      this.editForm.editReson = remark
    },
    clickCase(flag) {
      this.currentNodeFlag = flag
      this.myCase()
    },
    // 我的审核点击事件
    myCase: function() {
      $('.fixDiv').removeClass('active')
      $('.fixDivspan').removeClass('active')
      $('.myCase').addClass('active')
      this.caseShow = false
      this.tableLoading = true
      let params = {
        casesFlag: 1,
        pageNumber: this.pageindexNot,
        pageSize: this.pagesizeNot,
      }
      this.axios
        .post(qualityUrl + '/caseManage/queryCaseFlagDetail.do', Qs.stringify(params))
        .then((res) => {
          this.tableDataNot = res.data.Data
          this.filterButton() // 过滤权限按钮
          this.totalCountNot = res.data.Count
          this.tableLoading = false
        })
        .catch(function(error) {
          console.log(error)
        })
      let paramsell = {
        casesFlag: '2,3,4',
        pageNumber: this.pageindexNotsell,
        pageSize: this.pagesizeNotsell,
      }
      this.axios
        .post(qualityUrl + '/caseManage/queryCaseFlagDetail.do', Qs.stringify(paramsell))
        .then((res) => {
          this.tableDataNotsell = res.data.Data
          this.totalCountNotsell = res.data.Count
          this.tableLoading = false
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    changeMount: function(index) {
      this.caseCellid = index
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    // 跳转到录音播放页面
    jumpToSound: function(callId, calibrateId, recordFileURL) {
      let obj = {}
      obj.from = 'caseManage_new'
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.calibrateId = calibrateId
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 通过
    adopt: function(index, flag, cell, final, addName, objectIdfind) {
      // console.log(addName)
      this.cellthrowForm.resonRemark = flag
      this.rowId = cell
      this.newClassid = final
      this.caseCellid = final
      this.cellthrowForm.caseClassId = addName
      this.findId = objectIdfind
      this.casethrow = true
      let params = {
        objectId: index,
      }
      this.axios
        .post(qualityUrl + '/caseManage/getEffectiveTreeData.do', Qs.stringify(params))
        .then((res) => {
          this.taskStatusS = res.data
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 拒绝
    refuse: function(index, final, objectIdfind) {
      this.rejectId = index
      this.caseCellid = final
      this.findId = objectIdfind
      this.refuseModel = true
      this.stopBack = true
    },
    // 编辑案例
    editCase: function(index, flag, cell, final) {
      this.cellForm.resonRemark = flag
      this.rowId = cell
      this.newClassid = final
      this.caseInput = true
      let params = {
        objectId: index,
      }
      this.axios
        .post(qualityUrl + '/caseManage/getEffectiveTreeData.do', Qs.stringify(params))
        .then((res) => {
          this.taskStatusS = res.data
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // table点击一行
    rowClickTable: function(row) {
      this.caseIds = row.caseId
      this.objectId = row.calledNo
      this.remark = row.caseRemark
    },
    // 表格多选,获取批量删除需要的ids
    selectAll: function(selection) {
      if (selection) {
        this.selectedRemovedCaseIds = []
        let self = this
        selection.forEach(function(e) {
          self.selectedRemovedCaseIds.push(e['caseId'])
        })
      }
    },
    // 未审核table点击一行
    rowClickTableNot: function(row) {
      this.objectIdNot = row.calledNo
      this.caseIdsAdopt = row.caseId
      this.remarkTwo = row.caseRemark
    },
    // 未审核表格多选,获取批量删除需要的ids
    selectAllNot: function(selection) {
      if (selection) {
        this.selectedRemovedCaseIds = []
        let self = this
        selection.forEach(function(e) {
          self.selectedRemovedCaseIds.push(e['caseId'])
        })
      }
    },
    // 删除案例
    deleteCase: function(caseId, callId, fincel) {
      this.$confirm('确定要删除【 ' + callId + '】吗', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let params = {
            caseIds: caseId,
          }
          this.axios
            .post(qualityUrl + '/caseManage/removeCaseDetails.do', Qs.stringify(params))
            .then((res) => {
              if (res.data) {
                this.$message({
                  type: 'success',
                  message: '删除成功!',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: '删除失败',
                })
              }
              this.searchById(fincel)
            })
            .catch(function(error) {
              console.log(error)
            })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 左侧案例导航栏剪辑事件
    searchById: function(index, flag) {
      this.caseIopd = ''
      this.currentNodeFlag = flag
      $('.myCase').removeClass('active')
      if (flag != 'aa' && flag != 'bb') {
        $('#caseGood').removeClass('active')
        $('#caseNot').removeClass('active')
      } else if (flag == 'aa') {
        $('#caseGood').addClass('active')
        this.caseGoodFlag = true
        $('#caseNot').removeClass('active')
      } else if (flag == 'bb') {
        $('#caseNot').addClass('active')
        this.caseNotFlag = true
        $('#caseGood').removeClass('active')
      }
      this.currentOne = flag
      this.caseShow = true
      this.tableLoading = true
      let params = {
        caseClassId: '',
        casesFlag: '2',
        pageSize: this.pagesize,
        pageNumber: this.pageindex,
      }
      params.caseClassId = index
      this.classId = index
      this.axios
        .post(qualityUrl + '/caseManage/queryCaseDetail.do', Qs.stringify(params))
        .then((res) => {
          // console.log(res)
          this.tableData = res.data.Data
          this.filterButton() // 过滤权限按钮
          this.totalCount = res.data.Count
          this.tableLoading = false
        })
        .catch(function(error) {
          console.log(error)
        })
      if (index != 'd2a30ac73bc011e8bb70acd1b8a5627c') {
        this.pageindex = 1
        this.pagesize = this.pagesize
      }
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.queryCaseDetail()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.queryCaseDetail()
    },
    /**
     * 每页条数
     * **/
    handleSizeChangeNot(val) {
      this.pagesizeNot = val
      this.pageindexNot = 1
      this.myCase()
    },
    /**
     *当前页数
     * */
    handleCurrentChangeNot(val) {
      this.pageindexNot = val
      this.myCase()
    },
    handleSizeChangeNotSell(val) {
      this.pagesizeNotsell = val
      this.pageindexNotsell = 1
      this.myCase()
    },
    handleCurrentChangeNotSell(val) {
      this.pageindexNotsell = val
      this.myCase()
    },
    // 案例列表
    queryCaseDetail: function() {
      let params = {
        caseClassId: this.classId,
        casesFlag: '2',
        objectId: this.namesForm.name,
        pageSize: this.pagesize,
        pageNumber: this.pageindex,
      }
      let obj = {}
      obj.searchModel = {}
      obj.searchModel.activeTab = '1'
      obj.searchModel.queryString = params
      this.$store.commit('setRecordingPlayPage', obj)
      this.axios
        .post(qualityUrl + '/caseManage/queryCaseDetail.do', Qs.stringify(params))
        .then((res) => {
          this.tableData = res.data.Data
          this.totalCount = res.data.Count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 删除左侧案例导航栏的一个tree
    deleteTreeNode() {
      const flag = this.currentNodeFlag
      if (/^(aa|bb|check)$/.test(flag)) {
        this.$message({
          type: 'error',
          message:
            {
              aa: '优秀案例',
              bb: '差评案例',
              check: '我的审核',
            }[flag] + `不能删除`,
        })
        return
      }
      if (this.caseIopd == '') {
        this.$message({
          message: '请先选择一个案例',
          type: 'warning',
        })
        return
      } else {
        let params = {
          caseClassId: this.caseIopd,
        }
        this.axios
          .post(qualityUrl + '/caseManage/queryCaseClassCall.do', Qs.stringify(params))
          .then((res) => {
            if (res.data == true) {
              this.$confirm('你真的要删除吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
              })
                .then(() => {
                  this.axios
                    .post(
                      qualityUrl +
                        '/ivsCaseClass/removeCaseClass.do?caseClassId=' +
                        this.caseIopd
                    )
                    .then((res) => {
                      if (res.data.count == 0) {
                        this.$message({
                          type: 'success',
                          message: res.data.message,
                        })
                        this.caseList.splice(this.cellIndex, 1)
                        this.searchById('d2a30ac73bc011e8bb70acd1b8a5627c')
                      } else {
                        this.$message({
                          type: 'error',
                          message: '删除失败!',
                        })
                      }
                      this.getCaseClassTreeData()
                      this.treeid = ''
                    })
                })
                .catch(() => {
                  this.$message({
                    type: 'info',
                    message: '已取消删除',
                  })
                  this.getCaseClassTreeData()
                  this.treeid = ''
                })
            } else {
              // this.caseIopd = caseIopd
              this.$confirm('该分类下有录音你确定要删除吗?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning',
              })
                .then(() => {
                  this.axios
                    .post(
                      qualityUrl +
                        '/ivsCaseClass/removeCaseClass.do?caseClassId=' +
                        this.caseIopd
                    )
                    .then((res) => {
                      if (res.data.count == 0) {
                        this.$message({
                          type: 'success',
                          message: res.data.message,
                        })
                        this.caseList.splice(index, 1)
                        this.searchById('d2a30ac73bc011e8bb70acd1b8a5627c')
                      } else {
                        this.$message({
                          type: 'error',
                          message: '删除失败!',
                        })
                      }
                      this.getCaseClassTreeData()
                      this.treeid = ''
                    })
                })
                .catch(() => {
                  this.$message({
                    type: 'info',
                    message: '已取消删除',
                  })
                  this.getCaseClassTreeData()
                  this.treeid = ''
                })
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    saveTreeNode: function() {
      let params = {
        className: this.addTreeNodeForm.className,
        remark: this.addTreeNodeForm.remark,
      }
      if (this.addTreeNodeForm.className.length > 50) {
        this.$message({
          type: 'error',
          message: '请填写小于50字符的名称',
        })
        return
      }
      this.$refs.addTreeNodeForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(qualityUrl + '/ivsCaseClass/saveCaseClass.do', Qs.stringify(params))
            .then((res) => {
              if (res.data == true) {
                this.$message({
                  type: 'success',
                  message: '添加成功',
                })
                this.caseList.push({
                  name: this.addTreeNodeForm.className,
                })
                this.setInput = false
              } else {
                this.$message({
                  type: 'error',
                  message: '已存在相同的分类名称',
                })
              }
              this.getCaseClassTreeData()
              this.addTreeNodeForm.typeid = ''
              this.treeid = ''
              this.parentId = 1
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    saveEditNode: function() {
      let params = {
        className: this.editForm.editName,
        remark: this.editForm.editReson,
        caseClassId: this.caseIopd,
      }
      if (this.editForm.editName.length > 50) {
        this.$message({
          type: 'error',
          message: '请填写小于50字符的名称',
        })
        return
      }
      this.$refs.editForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(qualityUrl + '/ivsCaseClass/updateCaseClass.do', Qs.stringify(params))
            .then((res) => {
              if (res.data == true) {
                this.$message({
                  type: 'success',
                  message: '修改成功',
                })
                this.caseList[this.cellIndex].name = this.editForm.editName
                this.efitInput = false
              } else {
                this.$message({
                  type: 'error',
                  message: '已存在相同的分类名称',
                })
              }
              this.getCaseClassTreeData()
              this.addTreeNodeForm.typeid = ''
              this.treeid = ''
              this.parentId = 1
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    saveEditcase: function() {
      let params = {
        caseId: this.rowId,
        remark: this.cellForm.resonRemark,
        caseClassId: this.caseCellid,
      }
      this.$refs.cellForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(qualityUrl + '/caseManage/updateCaseContent.do', Qs.stringify(params))
            .then((res) => {
              if (res.data == true) {
                this.$message({
                  type: 'success',
                  message: '修改成功',
                })
                this.caseInput = false
              } else {
                this.$message({
                  type: 'error',
                  message: '修改失败',
                })
              }
              this.searchById(this.newClassid)
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    saveEditcell: function() {
      let params = {
        casClassId: this.caseCellid,
        reReason: this.cellthrowForm.resonRemark,
        caseIdsArray: this.rowId,
        passFlag: true,
        objectId: this.findId,
      }
      this.$refs.cellthrowForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(qualityUrl + '/caseManage/approveCase.do', Qs.stringify(params))
            .then((res) => {
              if (res.data == 1) {
                this.$message({
                  type: 'success',
                  message: '通过成功',
                })
                this.casethrow = false
              } else {
                this.$message({
                  type: 'error',
                  message: '在该分类下存在相同录音',
                })
              }
              this.myCase()
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    saveEditreject: function() {
      let params = {
        reReason: this.stopbackForm.resonRemark,
        caseIdsArray: this.rejectId,
        passFlag: false,
        casClassId: this.caseCellid,
        objectId: this.findId,
      }
      this.$refs.stopbackForm.validate((valid) => {
        if (valid) {
          this.axios
            .post(qualityUrl + '/caseManage/approveCase.do', Qs.stringify(params))
            .then((res) => {
              if (res.data == 1) {
                this.$message({
                  type: 'success',
                  message: '驳回成功',
                })
                this.stopBack = false
              } else {
                this.$message({
                  type: 'error',
                  message: '驳回失败',
                })
              }
              this.myCase()
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    changeTabNot: function() {
      $('#audited').removeClass('active')
      $('#notAudited').addClass('active')
      this.auditedSet = false
    },
    changeTab: function() {
      $('#audited').addClass('active')
      $('#notAudited').removeClass('active')
      this.auditedSet = true
    },
    // 获取tree
    getCaseClassTreeData: function() {
      this.axios
        .post(qualityUrl + '/ivsCaseClass/getCaseClassTreeData.do')
        .then((res) => {
          this.caseList = res.data
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 获取权限按钮
    getFuncId: function() {
      let codes = cache.getItem('roleInfo')
      this.roleCodeId = codes.split(',')
      console.log(this.roleCodeId)
      // 通过
      // 'seatman', // 坐席人员
      // 'headman', // 组长
      // 'qa', // 质检员
      // 'qa_suvs' // 质检主管
      if (
        this.roleCodeId.includes('qa') &&
        this.roleCodeId.includes('qa_suvs') === false
      ) {
        this.isShowadopt = false
        this.isShowPlace = true
      } else if (this.roleCodeId.includes('qa_suvs')) {
        this.isShowadopt = true
        this.isShowdeal = true
      } else if (this.roleCodeId.includes('qa')) {
        this.isShowadopt = false
        this.isShowdeal = true
      } else {
        this.isShowadopt = false
        this.isShowPlace = false
      }
    },
    /*
 * 过滤权限按钮
 * */
    filterButton() {
        /*
       获取数据后dom节点更改了，
        需要再获取一遍dom节点对[funcID]按钮进行过滤
       * */
        let menuId = localStorage.getItem('menuId')
        let path = this.$route.path.replace('/', '')
        funcFilter(menuId, path)
    }
  },
  created() {
    this.recordPlayCloseHandler()
    this.getFuncId()
  },
  mounted() {
    this.getCaseClassTreeData()
    this.classId = 'd2a30ac73bc011e8bb70acd1b8a5627c'
    this.searchById('d2a30ac73bc011e8bb70acd1b8a5627c', 'aa')
    if (this.recordingPlayPage.fromPage == 'homepage') {
      let obj = {
        fromPage: 'router',
      }
      this.$store.commit('setRecordingPlayPage', obj)
      this.myCase()
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
    accountId() {
      return this.$store.state.loginUserinfo.accountId
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.caseManage {
  width: 100%;
  /*top:1px;*/
  box-sizing: border-box;
  height: 100%;
  position: relative;
  #refuse {
    width: 100%;
    margin: 0 auto;
    overflow: hidden;
    label {
      color: #000;
      font-weight: bold;
    }
  }
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .caseContent {
    padding: 58px 10px 0px 0px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    .caseRight {
      height: 100%;
      margin-left: 200px;
      position: relative;
      border-left: 1px solid #d1dbe5;
      .container {
        overflow: hidden;
        height: 100%;
        position: relative;
        .content {
          padding-top: 11px;
          padding-bottom: 80px;
          box-sizing: border-box;
          width: 100%;
          height: 100%;
        }
        .autoGrading-page {
          right: 10px;
          position: absolute;
          bottom: 0px;
        }
        .table {
          width: 100%;
          height: 100%;
          overflow: auto;
          /*position: absolute;
            top: 55px;
            bottom: 80px;
            cursor: pointer;*/
        }
        .act-head {
          right: 0;
          top: 0;
          width: 100%;
          position: absolute;
          text-align: right;
          height: 44px;
        }
      }
    }
    .caseLeft {
      background: #eff2f7;
      width: 200px;
      height: 100%;
      float: left;
      position: relative;
      .item {
        padding: 15px 19px 5px;
        text-align: right;
        button {
          opacity: 0.7;
          width: 30px;
          height: 30px;
          padding: 0;
        }
      }
      .tree {
        width: 100%;
        cursor: pointer;
        .fixDiv {
          font-size: 14px;
          padding: 5px 0px 5px 15px;
        }
        .sepalColor {
          color: #20a0ff;
          cursor: pointer;
          display: inline-block;
          margin-left: 8px;
          float: right;
        }
      }
    }
  }
  .caseHeader {
    float: left;
    box-sizing: border-box;
    top: 0px;
    width: 100%;
    padding: 18px;
    font-size: 14px;
    border-bottom: 1px solid #d1dbe5;
    ul {
      cursor: pointer;
      width: 200px;
      li {
        display: inline-block;
        text-align: center;
        width: 80px;
        line-height: 42px;
        font-size: 14px;
      }
      .active {
        color: #20a0ff;
      }
    }
  }
  .mycaseHead {
    float: left;
    box-sizing: border-box;
    top: 0px;
    margin-left: 10px;
    margin-bottom: 5px;
    width: 100%;
    padding: 0 10px;
    font-size: 14px;
    border-bottom: 1px solid #d1dbe5;
    ul {
      cursor: pointer;
      width: 200px;
      li {
        display: inline-block;
        text-align: center;
        width: 80px;
        line-height: 42px;
        font-size: 14px;
      }
      .active {
        color: #20a0ff;
      }
    }
  }
}
.active {
  color: #20a0ff;
}
.myCase {
  padding: 10px 15px;
  border-top: 1px solid #d1dbe5;
  font-size: 14px;
  cursor: pointer;
}
.fixDivspan {
  display: inline-block;
  width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
<style lang="less">
#caseManage {
  .el-tree {
    border: none;
  }
  .el-table .cell,
  .el-table th > div {
    padding-left: 8px;
    padding-right: 8px;
    box-sizing: border-box;
    text-overflow: ellipsis;
  }
  .el-dialog__wrapper.single {
    position: fixed;
    top: 106px;
    left: 20px;
    right: 20px;
    bottom: 12px;
    .el-dialog {
      width: 100%;
      height: 100%;
      margin: 0 !important;
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
}
.el-table--border th {
  background: #e5e9f2;
  padding: 10px 0;
}
.newCase {
  .el-dialog__body {
    padding: 0;
    border-top: 1px solid #d1dbe5;
    .el-textarea__inner {
      min-height: 100px !important;
    }
    .caseItem {
      margin-top: 15px;
      margin-left: 20px;
    }
  }
  .el-dialog__title {
    font-size: 16px;
    font-weight: bolder;
  }
}
.el-tooltip__popper.is-dark {
  width: 30%;
  letter-spacing: 3px;
}
</style>
