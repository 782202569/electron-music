<template>
  <div class="myQCTask" id="myQCTask">
    <div class="myQCTask-box">
      <div class="myQCTask-box-nav">
        <div class="tree">
          <ul>
            <li data-id="1" @click="taskActive(1)" class="active">初检任务</li>
            <li data-id="2" @click="taskActive(2)">复检任务</li>
            <li data-id="3" @click="taskActive(3)">复议任务</li>
          </ul>
        </div>
      </div>
      <div class="myQCTask-box-content">
        <vInitialITask
          ref="initialTast"
          style="width:100%;height:100%;"
          v-if="index == 1"
        ></vInitialITask>
        <vReviewTask ref="reviewTask" style="width:100%;height:100%;" v-if="index == 2">
        </vReviewTask>
        <vReconsiderTask
          ref="reconsiderTask"
          style="width:100%;height:100%;"
          v-if="index == 3"
        ></vReconsiderTask>
      </div>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import vInitialITask from './InitialITask.vue' // 初检任务
import vReviewTask from './ReviewTask.vue' // 复检任务
import vReconsiderTask from './ReconsiderTask.vue' // 复议任务
export default {
  components: {
    vInitialITask,
    vReviewTask,
    vReconsiderTask,
  },
  data() {
    return {
      index: '1',
    }
  },
  methods: {
    taskActive: function(index) {
      this.index = index
      $('.myQCTask-box-nav ul li').removeClass('active')
      $('.myQCTask-box-nav ul li[data-id=' + index + ']').addClass('active')
      if (index === '1') {
        this.$refs.initialTast.initList()
      } else if (index === '2') {
        this.$refs.reviewTask.initList()
      } else if (index === '3') {
        this.$refs.reconsiderTask.initList()
      }
    },
  },
  mounted() {
    if (
      this.recordingPlayPage.fromPage == 'myQaTasks' &&
      this.recordingPlayPage.qaScoreType
    ) {
      // 控制三个tab页的展示1=》初检任务，2=》复检任务，3=》复议任务
      this.taskActive(this.recordingPlayPage.qaScoreType)
    } else if (
      this.recordingPlayPage.fromPage == 'homepage' &&
      this.recordingPlayPage.qaScoreType
    ) {
      // 控制三个tab页的展示1=》初检任务，2=》复检任务，3=》复议任务
      this.taskActive(this.recordingPlayPage.qaScoreType)
      let obj = {
        fromPage: 'router',
      }
      this.$store.commit('setRecordingPlayPage', obj)
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.myQCTask {
  width: 100%;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .myQCTask-box {
    width: 100%;
    height: 100%;
    position: relative;
    ul {
      cursor: pointer;
      li {
        padding-left: 23px;
        line-height: 56px;
        font-size: 14px;
      }
      .active {
        color: #20a0ff;
      }
    }
    .myQCTask-box-content {
      height: 100%;
      margin-left: 140px;
      position: relative;
    }
    .myQCTask-box-nav {
      width: 140px;
      height: 99.9%;
      float: left;
      background-color: #eff2f7;
      position: relative;
      margin-top: 1px;
      .tree {
        position: absolute;
        top: 0px;
        left: 0px;
        bottom: 0px;
        width: 100%;
        cursor: pointer;
      }
    }
  }
}
</style>
<style>
#myQCTask .el-tabs__active-bar {
  background: none;
}
</style>
