<template>
  <div class="sysAutoScoringInCallResult" id="sysAutoScoringInCallResult">
    <div class="loopTaskResult">
      <div class="sysAutoScoringInCallResult-header">
        <div class="operation">
          <div class="searchForm">
            <el-form :inline="true">
              <el-form-item>
                <el-button @click="showChartDialog">查看图表</el-button>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="exportData">导出</el-button>
              </el-form-item>
              <el-form-item>
                <el-button @click="turnToPrePage">返回</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <div class="sysAutoScoringInCallResult-content">
        <div class="sysAutoScoringInCallResult-content-pos" style="overflow-y:auto;">
          <div style="width:100%;height:100%;">
            <el-table
              ref="loopTaskTable"
              :data="sysAutoScoringList"
              border
              tooltip-effect="dark"
            >
              <el-table-column prop="objectId" sortable label="订单编号">
                <template scope="scope">
                  <span
                    style="color:#20a0ff;cursor: pointer"
                    type="text"
                    @click="showDetail(scope.row.objectId, scope.row.recordFileURL)"
                    >{{ scope.row.objectId }}</span
                  >
                </template>
              </el-table-column>

              <el-table-column prop="submiterName" sortable label="坐席姓名">
              </el-table-column>
              <el-table-column
                prop="callTime"
                sortable
                label="通话时长"
                :formatter="convertCallTime"
              >
              </el-table-column>
              <el-table-column
                prop="score"
                sortable
                label="自动评分分数"
                :formatter="convertScore"
              >
              </el-table-column>
              <el-table-column prop="createTime" label="质检时间"> </el-table-column>
              <el-table-column label="操作" width="300">
                <template scope="scope">
                  <i
                    class="iconfont icon-chakan"
                    style="cursor:pointer;margin-right:10px;"
                    @click="showDetail(scope.row.objectId, scope.row.recordFileURL)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;font-size:14px"
                      >查看</i
                    ></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="sysAutoScoringInCallResult-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <!--查看图表弹出框-->
    <el-dialog
      id="lookChartDialog"
      title="查看图表"
      :close-on-click-modal="false"
      :visible.sync="lookChartDialogVisible"
    >
      <div id="chart_container">
        <p>
          暂无数据
        </p>
      </div>
    </el-dialog>
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="recordingplay"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Qs from 'qs'
import bus from '../../common/bus.js'
import recordingplay from '../recordingPlayOrder/recordingPlayOrder.vue'
import vPlayer from '../../common/player.vue'
import global from '../../../global.js'
let currentBaseUrl = global.qualityUrl
export default {
  components: {
    vPlayer,
    recordingplay,
  },
  data() {
    return {
      recordDialogVisible: false,
      currentPage: 1,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      sysAutoScoringInCallResultTotal: 0, // 任务获取的总条数
      sysAutoScoringList: [], // 循环任务查询结果
      lookChartDialogVisible: false, // 循环任务图表
    }
  },
  methods: {
    reSetData() {
      this.recordDialogVisible = false
      this.currentPage = 1
      this.total = 0
      this.pageSize = 20
      this.pageSizes = [10, 20, 30, 40]
      this.sysAutoScoringInCallResultTotal = 0 // 任务获取的总条数
      this.sysAutoScoringList = [] // 循环任务查询结果
      this.lookChartDialogVisible = false // 循环任务图表
    },
    convertCallTime(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    convertScore(x, y, score) {
      let needConvert = score && score != 'null'
      return needConvert ? parseFloat(score).toFixed(0) : ''
    },
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    // 表格中选中项变化时执行的方法
    handleSelectionChange(val) {
      this.projects = val
    },
    // 查询循环任务
    selectRobertProjectDetail() {
      let params = {
        robertProjectId: this.robertProjectId,
        objectType: 2,
        pageNumber: this.currentPage,
        pageSize: this.pageSize,
      }
      let self = this
      this.axios
        .post(
          currentBaseUrl + '/autoorderscore/selectRobertProjectDetail.do',
          Qs.stringify(params)
        )
        .then(function(response) {
          self.total = response.data.Count
          self.sysAutoScoringList = response.data.List
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    showChartDialog() {
      this.lookChartDialogVisible = true
      this.getTaskStats()
    },
    // 查看图表
    lookChart(chartObj) {
      let _this = this
      let option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        grid: {
          top: '3%',
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        color: ['#666666'],
        xAxis: {
          type: 'category',
          data: ['0-20', '20-40', '40-60', '60-80', '80-100'],
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // },
          axisLine: {
            show: false,
          },
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // },
          axisLine: {
            show: false,
          },
        },
        series: [
          {
            name: '样本数量',
            type: 'bar',
            stack: '总量',
            data: [0, 0, 0, 0, 0],
          },
        ],
      }
      let yAxis = [0, 0, 0, 0, 0]
      if (chartObj && chartObj.length > 0) {
        chartObj.forEach(function(item) {
          if (item >= 0 && item < 20) {
            yAxis[0]++
          } else if (item >= 20 && item < 40) {
            yAxis[1]++
          } else if (item >= 40 && item < 60) {
            yAxis[2]++
          } else if (item >= 60 && item < 80) {
            yAxis[3]++
          } else if (item >= 80 && item < 100) {
            yAxis[4]++
          }
        })
      }
      option.series[0].data = yAxis
      this.$nextTick(function() {
        let chart = _this.$echarts.init(document.querySelector('#chart_container'))
        chart.setOption(option)
      })
    },
    // 获取图表数据
    getTaskStats() {
      let params = {
        robertProjectId: this.robertProjectId,
      }
      let self = this
      this.axios
        .post(currentBaseUrl + '/autoorderscore/viewIcon.do', Qs.stringify(params))
        .then(function(response) {
          if (response.data && response.data.Data && response.data.Data.length > 0) {
            self.lookChart(response.data.Data)
          }
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '图标数据获取失败',
          })
        })
    },
    // 导出
    exportData() {
      let params = {}
      params.robertProjectId = this.robertProjectId
      params.CASTGC = localStorage.getItem('tgt_id')
      let form = document.createElement('form')
      form.method = 'post'
      form.target = '_blank'
      for (let key in params) {
        let input = document.createElement('input')
        input.name = key
        input.value = params[key]
        form.appendChild(input)
      }
      form.action = currentBaseUrl + '/autoorderscore/exportAutoScoreResult.do'
      document.querySelector('body').appendChild(form)
      form.submit()
      document.querySelector('body').removeChild(form)
    },
    //  结果页的返回按钮
    turnToPrePage() {
      this.$router.push('/sysAutoScoringInCallOrder')
    },
    // 调到录音播放页
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.pageId = 'sysAutoScoringInCallOrderResult'
      obj.orderNo = id
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay', // 扩展样式
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 关闭录音弹窗
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    // 录音播放页面 点击最小化触发
    toMinDialog: function(playInfo) {
      if (playInfo.isMaximization === false) {
        this.showVplayer = false
        let play = {}
        play.isMaximization = false
        play.exist = true
        this.$store.commit('setPlayerInfo', play)
      }
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
  },
  mounted() {
    if (!this.robertProjectId) {
      this.$router.push('/sysAutoScoringInCallOrder')
    } else {
      this.selectRobertProjectDetail()
    }
  },
  computed: {
    robertProjectId() {
      return this.$store.state.Strategy.strategyId
    },
  },
  watch: {
    currentPage() {
      this.selectRobertProjectDetail()
    },
    pageSize() {
      this.selectRobertProjectDetail()
    },
    parentModel: {
      handler(newValue, oldValue) {
        console.info('监听到parentModel变化了')
        this.reSetData()
        this.qamodleScore()
      },
      deep: true,
    },
  },
}
</script>
<style lang="less">
.sysAutoScoringInCallResult {
  .operation {
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
}
</style>
<style scoped="scoped" lang="less">
@boder-color: #d1dbe5;
.sysAutoScoringInCallResult {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .operation {
    height: 55px;
    line-height: 55px;
    position: relative;
    border-bottom: 1px dashed @boder-color;
    padding-right: 10px;
    .el-form-item {
      margin-bottom: 0px;
      .el-form-item__content {
        line-height: 55px;
      }
    }
    & > div {
      display: inline-block;
      text-align: right;
      button {
        width: 90px;
      }
      &.searchForm {
        position: absolute;
        right: -10px;
        div.el-form-item__content {
          vertical-align: middle !important;
          border: 1px solid red;
        }
      }
    }
  }
  .taskResult {
    .operation {
      .tips {
        & > label {
          color: #9dadc2;
          font-size: 14px;
        }
        & > span {
          margin: 0px 10px 0px 5px;
        }
      }
      .btns {
        float: right;
        margin-right: -10px;
      }
    }
  }
  .sysAutoScoringInCallResult-content {
    box-sizing: border-box;
    position: absolute;
    top: 65px;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 0px 10px;
    padding-bottom: 40px;
    overflow: hidden;
  }
  .sysAutoScoringInCallResult-content .sysAutoScoringInCallResult-content-pos {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .sysAutoScoringInCallResult-content .sysAutoScoringInCallResult-page {
    width: 100%;
    height: 35px;
    position: absolute;
    left: 0;
    right: 0px;
    bottom: 0;
    text-align: right;
  }
  .sysAutoScoringInCallResult-page .el-pagination {
    display: inline-block;
    height: 28px;
    line-height: 28px;
    padding: 0px 10px;
  }
  #newTaskdialog .el-dialog__body {
  }
  #sysAutoScoringInCallResult
    .sysAutoScoringInCallResult-content-pos
    .el-table__body-wrapper {
    overflow-x: hidden;
  }
  .btns {
    text-align: right;
  }
  table .cell > i {
    width: 35px;
    & > i {
      font-family: '微软雅黑';
      margin-left: 4px;
      font-size: 14px;
    }
  }
}
.chartCondition {
  text-align: center;
}
#chart_container {
  width: 600px;
  height: 400px;
  margin: 0 auto;
}
</style>
<style scoped="scoped" lang="less">
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
.sysAutoScoringInCallResult {
  .rightContent {
    height: 100%;
    width: 100%;
    box-sizing: border-box;
    position: relative;
    .tableBox {
      padding-top: 8px;
      padding-bottom: 80px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      .table {
        width: 100%;
        height: 100%;
      }
      .page {
        right: 10px;
        position: absolute;
        bottom: 10px;
      }
    }
  }
  .toggle-show {
    position: absolute;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggleBtn {
    cursor: pointer;
    width: 20px;
    height: 30px;
    background-image: url('../../../assets/img/close.png');
    position: absolute;
    left: -20px;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggle-hidden {
    left: 0px;
    transform: rotate(180deg);
  }
  .leftContent {
    height: 100%;
    overflow: auto;
    left: 0px;
    top: 0px;
    position: relative;
    border-right: 1px solid #d1dbe5;
    .searchHeader {
      border-bottom: 1px dashed #d1dbe5;
      position: absolute;
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      position: absolute;
      top: 0px;
      left: 0px;
      width: 100%;
    }
    .searchForm {
      position: absolute;
      top: 65px;
      left: 0px;
      bottom: 0px;
      overflow: auto;
      width: 100%;
      cursor: pointer;
      p {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        font-weight: bold;
        color: #9dadc2;
      }
    }
  }
  .el-row {
    height: 100%;
    .el-col {
      height: 100%;
    }
  }
}
#sysAutoScoringInCallResult div {
  box-sizing: border-box;
}
#sysAutoScoringInCallResult {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
}
</style>
<style>
#sysAutoScoringInCallResult .el-dialog--small {
  width: 65% !important;
}
#sysAutoScoringInCallResult .hidden {
  display: none;
}
</style>
<style lang="less">
.sysAutoScoringInCallResult {
  .operation {
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
  .recordingplay {
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
}
</style>
