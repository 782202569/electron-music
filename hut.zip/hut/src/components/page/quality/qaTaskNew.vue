<template>
  <div class="caseManage" id="fullManage">
    <div class="caseContent">
      <div class="caseLeft">
        <div class="tree">
          <ul>
            <el-button class="active" id="audited" @click="changeTab"
              >系统自动评分</el-button
            >
            <el-button id="notAudited" @click="changeTabNot">初检任务</el-button>
            <el-button id="rexxCal" @click="changeRexx">复检任务</el-button>
          </ul>
        </div>
      </div>
      <div id="sysToem" class="caseRight" v-show="getbackShow">
        <div class="containBody" id="container">
          <div class="containTitle">系统自动评分</div>
          <div id="search-form" class="act-head toalSide">
            <el-form :inline="true">
              <el-form-item>
                <div style="display: inline-block;">
                  <el-button funcId="000386" style="margin-left: 19px;" @click="editCase"
                    >新建任务</el-button
                  >
                  <el-button
                    funcId="000058"
                    style="margin-left: 6px;"
                    @click="batchDeleteConfirm"
                    >批量删除</el-button
                  >
                </div>
                <div style="float:right;display: inline-block;">
                  <div style="float:right;width: 100%">
                    <el-date-picker
                      :clearable="false"
                      :editable="false"
                      v-model="searchTime"
                      type="datetimerange"
                      align="right"
                      range-separator="至"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期"
                      :default-time="['00:00:00', '23:59:59']"
                    >
                    </el-date-picker>
                    <el-input
                      class="changIput"
                      v-model="projectName"
                      placeholder="任务名称"
                      style="width: 150px;"
                    >
                    </el-input>
                    <el-select
                      clearable
                      v-model="taskStatus"
                      placeholder="请选择状态"
                      style="width: 100px;height:36px;line-height:36px;"
                    >
                      <el-option
                        v-for="item in taskStatusS"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                    <el-button
                      type="primary"
                      style="margin-left: 10px;margin-right: 20px;"
                      @click="selectRobertProject"
                      >查询</el-button
                    >
                  </div>
                </div>
              </el-form-item>
            </el-form>
          </div>
          <div class="content">
            <div class="table">
              <div style="padding: 0 26px 0 19px;">
                <el-table
                  border
                  rel="qualityTable"
                  highlight-current-row
                  :data="projects"
                  @selection-change="handleSelectionChange"
                >
                  <el-table-column type="selection" width="50"> </el-table-column>
                  <el-table-column
                    prop="projectName"
                    :show-overflow-tooltip="true"
                    label="任务名称"
                    width="100"
                  >
                    <template scope="scope">
                      <el-button
                        type="text"
                        style="padding: 10px 0;"
                        @click="
                          showDetail(scope.row.robertProjectId, scope.row.projectName)
                        "
                        >{{ scope.row.projectName }}</el-button
                      >
                    </template>
                  </el-table-column>
                  <el-table-column prop="createUser" label="创建者" width="80">
                  </el-table-column>
                  <el-table-column
                    prop="createTime"
                    :formatter="createTimeFilter"
                    label="创建时间"
                    width="180"
                  >
                  </el-table-column>
                  <el-table-column prop="status" label="任务状态" width="100">
                    <template scope="scope">
                      <el-tag close-transition type="success" v-if="scope.row.status == 1"
                        >进行中</el-tag
                      >
                      <el-tag close-transition type="gray" v-if="scope.row.status == 3"
                        >已完成</el-tag
                      >
                      <el-tag close-transition type="danger" v-if="scope.row.status == 2"
                        >停止</el-tag
                      >
                    </template>
                  </el-table-column>
                  <el-table-column prop="lastFinishCount" label="最近一次质检数量">
                  </el-table-column>
                  <el-table-column prop="finishCount" label="已质检数量">
                  </el-table-column>
                  <el-table-column label="操作" width="160">
                    <template scope="scope">
                      <div style="cursor: pointer;">
                        <i
                          v-if="scope.row.status == 1"
                          style="font-size: 12px; margin-right: 10px;"
                          ><i
                            funcId="000055"
                            @click="
                              diableTask(scope.row.robertProjectId, scope.row.projectName)
                            "
                            style="font-size: 14px; padding-left: 3px; color: #20A0FF;"
                            >暂停</i
                          ></i
                        >
                        <i
                          funcId="000055"
                          v-if="scope.row.status == 2"
                          style="font-size: 12px; margin-right: 10px;"
                          @click="
                            startTask(scope.row.robertProjectId, scope.row.projectName)
                          "
                          ><i style="font-size: 14px; padding-left: 3px; color: #20A0FF;"
                            >开始</i
                          ></i
                        >
                        <i style="font-size: 12px;"
                          ><i
                            funcId="000056"
                            @click="copyProject(scope.row)"
                            style="font-size: 14px; padding-left: 3px; color: #20A0FF;"
                            >复制</i
                          ></i
                        >
                        <i
                          funcId="000057"
                          @click="
                            deleteProjectConfirm(
                              scope.row.projectName,
                              scope.row.robertProjectId
                            )
                          "
                          style=" margin-left: 10px;"
                          ><i style="font-size: 14px; padding-left: 3px; color: #20A0FF;"
                            >删除</i
                          ></i
                        >
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
                <el-dialog
                  class="smellmodel"
                  title="新建系统自动评分"
                  :visible.sync="editNextModel"
                  width="640px"
                  :close-on-click-modal="false"
                >
                  <cellTask v-on:send="sellTask" v-if="editNextModel"></cellTask>
                </el-dialog>
                <!--复制任务、编辑任务弹出层-->
                <el-dialog
                  class="smellmodel"
                  title="复制任务"
                  :close-on-click-modal="false"
                  :visible.sync="copyDialogVisible"
                  width="640px"
                >
                  <cellTask
                    v-on:send="closeCopyTask"
                    v-if="copyDialogVisible"
                    :projectModel="projectModel"
                  ></cellTask>
                </el-dialog>
              </div>
            </div>
            <div class="autoGrading-page">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="pageSizes"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="total"
              >
              </el-pagination>
            </div>
          </div>
        </div>
        <!-- 进入初检任务页面 -->
        <pTasks v-if="paryTasks" @filterButton="filterButton"></pTasks>
        <!-- 进入复检任务页面 -->
        <rTasks v-if="reexTasks" @filterButton="filterButton"></rTasks>
        <!-- 系统自动评分结果详情页 -->
        <gbTasks
          :message="this.parentModel.taskId"
          v-if="detailCell"
          v-on:sendTill="sellTill"
        ></gbTasks>
      </div>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import pTasks from './parmaryTasks.vue'
import rTasks from './reexTasks.vue'
import cellTask from './sellTask.vue'
import gbTasks from './getbackPage.vue'
import funcFilter from '@/utils/funcFilter.js'
import Qs from 'qs'
import moment from 'moment'
import global from '../../../global.js'
let currentBaseUrl = global.qualityUrl
let taskBaseUrl = global.taskBaseUrl
import formatdate from '../../../utils/formatdate.js'
export default {
  components: {
    pTasks,
    rTasks,
    cellTask,
    gbTasks,
  },
  data() {
    return {
      paryTasks: false,
      reexTasks: false,
      detailCell: false,
      parentModel: {},
      countList: '',
      textTitle: '',
      modleId: '',
      currentPage: 1,
      editCaseModel: false,
      editNextModel: false,
      getbackShow: true,
      copyDealModel: false,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      projects: [],
      taskStatus: '',
      taskStatusS: [
        {
          label: '请选择',
          value: '',
        },
        {
          label: '进行中',
          value: '1',
        },
        {
          label: '暂停',
          value: '2',
        },
      ],
      searchTime: [], // 搜索的时间
      projectName: '',
      projectsSelected: [], // 选中的任务
      dialogVisible: false,
      copyDialogVisible: false,
      chartDialogVisible: false, // 自动打分统计
      startTime: '', // 自动打分统计
      endTime: '', // 自动打分统计
    }
  },
  methods: {
    changeshow: function(input) {
      this.getbackShow = input
    },
    // 查看策略详情
    showDetail(strategyId, flag) {
      let Strategy = {}
      Strategy.strategyId = strategyId
      let obj = {}
      obj.taskId = strategyId
      obj.qaScoreType = 1
      this.$store.commit('setRecordingPlayPage', obj)
      this.$store.commit('setStrategy', Strategy)
      // this.$router.push({name: 'detailCell', params: {value: flag}})
      // this.$router.push({name: 'detailCell', params: {value: flag, taskId: strategyId}})
      $('#container').hide()
      this.parentModel = {
        taskId: flag,
      }
      this.detailCell = true
    },
    // 进行下一步操作
    editNext: function() {
      this.editNextModel = true
      setTimeout(() => {
        this.editCaseModel = false
      }, 200)
    },
    editCancel: function() {
      this.editCaseModel = false
      this.editNextModel = false
    },
    // input=>是否关闭弹窗（true or false，flag=> 有任务执行时是否成功('success' or 'failed')
    sellTask(input, flag) {
      // 关闭新建任务的弹窗
      this.editNextModel = input
      if (flag === 'success') {
        this.selectRobertProject()
      }
    },
    sellTill(input) {
      // 关闭新建任务的弹窗
      $('#container').show()
      this.detailCell = false
    },
    // 编辑案例
    editCase: function() {
      this.editNextModel = true
      this.projectModel = null
    },
    changeTabNot: function() {
      $('#audited').removeClass('active')
      $('#notAudited').addClass('active')
      $('#rexxCal').removeClass('active')
      $('#container').hide()
      this.paryTasks = true
      this.detailCell = false
      this.reexTasks = false
    },
    changeRexx: function() {
      $('#audited').removeClass('active')
      $('#notAudited').removeClass('active')
      $('#rexxCal').addClass('active')
      $('#container').hide()
      this.paryTasks = false
      this.detailCell = false
      this.reexTasks = true
    },
    changeTab: function() {
      $('#audited').addClass('active')
      $('#notAudited').removeClass('active')
      $('#rexxCal').removeClass('active')
      $('#container').show()
      this.paryTasks = false
      this.detailCell = false
      this.reexTasks = false
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.selectRobertProject()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.selectRobertProject()
    },
    // 表格中选中项变化时执行的方法
    handleSelectionChange(val) {
      this.projectsSelected = val
    },
    // 关闭复制任务弹窗
    closeCopyTask(input, flag) {
      // 关闭新建任务的弹窗
      this.copyDialogVisible = input
      if (flag === 'success') {
        this.selectRobertProject()
      }
    },
    // 开始任务任务
    startTask(id, name) {
      let _this = this
      let params = {}
      params = JSON.stringify({
        startTaskId: id,
        startTaskName: name,
      })
      let config = {
        headers: {
          'Content-Type': 'application/json;charset=UTF-8',
        },
      }
      this.axios
        .post(taskBaseUrl + '/taskInfo/startTask.do', params, config)
        .then(function(response) {
          if (response.data.status) {
            _this.$message({
              type: 'success',
              message: '任务开始成功',
            })
            _this.selectRobertProject()
          } else if (response.data.msg) {
            _this.$message({
              type: 'error',
              message: '任务开始失败',
            })
          }
        })
    },
    // 查询系统自动评分
    selectRobertProject() {
      let fromData = ''
      let toform = ''
      if (this.searchTime == null) {
        this.fromData = ''
        this.toform = ''
      } else {
        if (this.searchTime[0] != undefined && this.searchTime[0] != '') {
          fromData = formatdate.formatDate(this.searchTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromData = formatdate.formatDate(now)
        }
        if (this.searchTime[1] != undefined && this.searchTime[1] != '') {
          toform = formatdate.formatDate(this.searchTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toform = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchTime = [fromData, toform]
      let params = {
        startDate: this.searchTime[0],
        stopDate: this.searchTime[1],
        currentPage: this.currentPage,
        pageSize: this.pageSize,
        projectName: this.projectName,
        status: this.taskStatus,
      }
      console.log(Qs.stringify(params))
      let self = this
      this.axios
        .post(currentBaseUrl + '/ascorec/selectRobertProject.do', Qs.stringify(params))
        .then(function(response) {
          self.total = response.data.data.count
          self.projects = response.data.data.ivsRobertProjectResponseBeanList
          self.filterButton() // 过滤权限按钮
        })
        .catch(function() {
          self.$message({
            type: 'error',
            message: '任务获取失败',
          })
        })
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let hours = date.getHours()
      if (hours < 10) {
        hours = '0' + hours
      }
      let minute = date.getMinutes()
      if (minute < 10) {
        minute = '0' + minute
      }
      let second = date.getSeconds()
      if (second < 10) {
        second = '0' + second
      }
      let str = year + '-' + month + '-' + day + ' ' + hours + ':' + minute + ':' + second
      return str
    },
    createTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    // 删除一个智能项目
    deleteProject(id) {
      let _this = this
      let params = {}
      params.robertProjectId = id
      this.axios
        .post(currentBaseUrl + '/ascorec/removeRobertProject.do', Qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '任务删除成功',
            })
            _this.selectRobertProject()
          } else {
            return Promise.reject(response)
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '任务删除失败',
          })
        })
    },
    // 删除确认
    deleteProjectConfirm(name, id) {
      let _this = this
      _this
        .$confirm('确定要任务[' + name + ']?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
        .then(() => {
          _this.deleteProject(id)
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 批量删除确认
    batchDeleteConfirm() {
      let _this = this
      if (_this.projectsSelected.length < 1) {
        _this.$message({
          type: 'warning',
          message: '请选择要删除的任务',
        })
        return false
      }
      let names = []
      let ids = []
      _this.projectsSelected.forEach(function(item) {
        names.push(item.projectName)
        ids.push(item.robertProjectId)
      })
      let msg = ''
      if (names.length <= 3) {
        msg = names.join(',')
      } else {
        msg = names.slice(0, 3).join(',') + '等' + names.length + '个项目'
      }
      _this
        .$confirm('确定要删除[' + msg + ']?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
        .then(() => {
          _this.deleteProject(ids.join(','))
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 复制一个任务
    copyProject(row) {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/ivsStrategy/getStrategyById.do',
          Qs.stringify({
            strategyId: row.robertProjectId,
          })
        )
        .then(function(response) {
          _this.projectModel = response.data
          _this.projectModel.strategyName = ''
          _this.projectModel.modleId = row.modleId
          _this.projectModel.operationperiod = row.operationperiod
          _this.projectModel.collectionperiod = row.collectionperiod
          _this.copyDialogVisible = true
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取任务详情失败',
          })
        })
    },
    // 暂停任务
    diableTask(id, name) {
      let _this = this
      let params = {}
      params = JSON.stringify({
        pauseId: id,
        pauseTaskName: name,
      })
      let config = {
        headers: {
          'Content-Type': 'application/json;charset=UTF-8',
        },
      }
      this.axios
        .post(taskBaseUrl + '/taskInfo/taskPause.do', params, config)
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '任务暂停成功',
            })
            _this.selectRobertProject()
          } else {
            return Promise.reject(response)
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '任务暂停失败',
          })
        })
    },
    /*
     * 过滤权限按钮
     * */
    filterButton() {
      /*
       获取数据后dom节点更改了，
        需要再获取一遍dom节点对[funcID]按钮进行过滤
       * */
      let menuId = localStorage.getItem('menuId')
      let path = this.$route.path.replace('/', '')
      funcFilter(menuId, path)
    },
  },
  created() {
    this.selectRobertProject()
  },
  watch: {
    currentPage() {
      this.selectRobertProject()
    },
    pageSize() {
      this.selectRobertProject()
    },
  },
  mounted() {},
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.dialogHeader {
  width: 100%;
  overflow: hidden;

  .dialogCell {
    width: 100%;
    border-bottom: 1px solid #e0e6ed;

    .dialogCellfir {
      display: inline-block;
      padding: 12px 16px 12px 20px;
      color: #20a0ff;
    }

    .dialogCellfsed {
      display: inline-block;
      padding: 12px 16px 12px 16px;
    }
  }

  .dealCont {
    width: 100%;
    padding-top: 21px;
    margin-left: 20px;
  }
}

.caseManage {
  width: 100%;
  /*top:1px;*/
  box-sizing: border-box;
  height: 100%;
  position: relative;

  #refuse {
    width: 100%;
    margin: 0 auto;
    overflow: hidden;

    label {
      color: #000;
      font-weight: bold;
    }
  }

  .caseContent {
    box-sizing: border-box;
    width: 100%;
    height: 100%;

    .caseRight {
      height: 100%;
      margin-left: 140px;
      position: relative;

      .containBody {
        overflow: hidden;
        height: 100%;
        position: relative;

        .containTitle {
          padding: 16px 0 13px 19px;
          font-size: 14px;
        }

        .content {
          padding-top: 12px;
          padding-bottom: 140px;
          box-sizing: border-box;
          width: 100%;
          height: 100%;
        }

        .autoGrading-page {
          right: 10px;
          position: absolute;
          bottom: 10px;
        }

        .table {
          width: 100%;
          height: 100%;
          overflow: auto;
        }

        .act-head {
          width: 100%;
          height: 44px;

          .moreChoice {
            line-height: 36px;
            text-decoration: underline;
            color: #20a0ff;
            cursor: pointer;
            font-size: 13px;
            margin-left: 7px;
          }
        }
      }
    }

    .caseLeft {
      width: 140px;
      height: 99.9%;
      float: left;
      background-color: #eff2f7;
      position: relative;
      margin-top: 1px;

      .tree {
        position: absolute;
        top: 0px;
        left: 0px;
        bottom: 0px;
        width: 100%;
        cursor: pointer;
      }
    }
  }

  ul {
    cursor: pointer;

    .el-button {
      width: 100%;
      border: 0;
      background: transparent;
      font-size: 14px;
      margin: 0;
    }

    .active {
      color: #20a0ff;
    }
  }
}
</style>
<style lang="less">
.containBody {
  .el-button {
    padding: 10px 15px;
  }

  .el-range-editor.el-input__inner {
    width: 365px;
    margin-left: 30px;
    padding: 0px 5px;
    height: 36px;
    line-height: 36px;
  }

  .changIput {
    width: 180px;
    margin-left: 6px;
  }
}

.content .table th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}

.containBody .changIput .el-input__inner {
  height: 36px;
  line-height: 36px;
}

.audioAttrsInputs .el-input__inner {
  height: 36px;
  line-height: 36px;
}

.containBody .el-date-editor .el-range-separator {
  line-height: 36px;
}

.smellmodel {
  .el-dialog__body {
    padding: 0px;
  }

  .el-form-item__label {
    text-align: left;
    padding: 0px;
  }

  .el-form-item {
    margin-right: 16px;
    display: inline-block;
  }
}

#fullManage {
  .el-tree {
    border: none;
  }

  .el-table .cell,
  .el-table th > div {
    padding-left: 8px;
    padding-right: 8px;
    box-sizing: border-box;
    text-overflow: ellipsis;
  }

  .single {
    .el-dialog__header {
      display: none;
    }

    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }

    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
}

.el-dialog__header {
  .el-dialog__title {
    font-size: 16px;
    font-weight: bolder;
  }
}

.titleHeader {
  padding: 20px 20px;
  height: 155px;
  border-bottom: 1px solid #e0e6ed;

  .el-input__inner {
    height: 36px;
    line-height: 36px;
  }
}

.toalSide .el-form-item {
  width: 100%;

  .el-form-item__content {
    width: 100%;
  }
}

#search-form .el-select .el-input__inner {
  // padding: 0 !important;
  height: 36px;
  line-height: 36px;
}
</style>
