<template>
  <div class="goBackmessage">
    <div class="backPage"><span @click="getbackNow">&lt; 返回</span></div>
    <div class="cellLeft">{{ message }}</div>
    <div class="content">
      <div class="table">
        <div class="tableCell">
          <el-table ref="resultTable" :data="tableData" border tooltip-effect="dark">
            <el-table-column prop="condition" label="筛选条件" width="220">
              <template slot-scope="scope">
                <el-popover ref="popover" placement="right" trigger="hover">
                  <slot name="reference">
                    <div class="detailContainernew">
                      <div class="detailsNew">
                        <div
                          class="contentNew"
                          v-if="
                            key.indexOf('$CName') < 0 && key.indexOf('wholeContent') < 0
                          "
                          v-for="(value, key) in strategyObject"
                        >
                          <span v-if="value != ''"
                            >{{ strategyObject[key + '$CName'] || '' }}：<i>{{
                              value
                            }}</i></span
                          >
                        </div>
                        <div class="contentNew">
                          <span v-if="strategyObject.wholeContent_firstKey != ''"
                            >关键词：<i>
                              {{
                                '( ' +
                                  (strategyObject.wholeContent_firstKey || '') +
                                  ' ' +
                                  (strategyObject.wholeContent_firstLogic || '') +
                                  ' ' +
                                  (strategyObject.wholeContent_secondKey || '') +
                                  ' ) ' +
                                  (strategyObject.wholeContent_MidLogic || '') +
                                  ' (' +
                                  (strategyObject.wholeContent_thirdKey || '') +
                                  ' ' +
                                  (strategyObject.wholeContent_LastLogic || '') +
                                  ' ' +
                                  (strategyObject.wholeContent_LastKey || '') +
                                  ' )'
                              }}
                            </i></span
                          >
                        </div>
                      </div>
                    </div>
                  </slot>
                </el-popover>
                <span v-popover:popover style="color: #20A0FF;cursor: pointer;">{{
                  scope.row.condition
                }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="recordCount" label="录音数" width="180">
            </el-table-column>
            <el-table-column
              prop="assignTime"
              label="分配时间"
              :formatter="exeTimeFilter"
              width="180"
            >
            </el-table-column>
            <el-table-column prop="qaUserCount" label="质检人数" width="160">
            </el-table-column>
            <el-table-column label="操作" show-overflow-tooltip>
              <template scope="scope">
                <div style="cursor: pointer;">
                  <i style="font-size: 12px; margin-right: 10px;"
                    ><i
                      @click="viewAssign(scope.row.taskId)"
                      style="font-size: 14px; padding-left: 3px; color: #20A0FF;"
                      >查看分配</i
                    ></i
                  >
                </div>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <el-dialog
          class="spelShow"
          title="查看分配"
          :close-on-click-modal="false"
          :visible.sync="dialogVisible"
          width="740px"
        >
          <div class="spelDiv">
            <el-table border tootip-effect="dark" :data="assignTableData">
              <el-table-column prop="qaUser" label="质检员姓名"> </el-table-column>
              <el-table-column prop="qaMounthCount" label="当月分配"> </el-table-column>
              <el-table-column prop="qaCount" label="当前分配"> </el-table-column>
              <el-table-column
                prop="assignTime"
                :formatter="exeTimeFilter"
                label="分配时间"
              >
              </el-table-column>
            </el-table>
            <div class="intelligent-page fr">
              <el-pagination
                @size-change="handleSizeChangeAssign"
                @current-change="handleCurrentChangeAssign"
                :current-page="currentPageAssign"
                :page-sizes="pageSizesAssign"
                :page-size="pageSizeAssign"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalAssign"
              >
              </el-pagination>
            </div>
          </div>
          <div
            class="footerAll"
            style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 15px;height: 68px;"
          >
            <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
              <el-button @click="sameNot">取 消</el-button>
              <el-button @click="sameNot" type="primary" style="margin-right: 18px;"
                >确 定</el-button
              >
            </div>
          </div>
        </el-dialog>
      </div>
    </div>
    <div class="sysAutoScoringInCallResult-page">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import global from '../../../global.js'
import Qs from 'qs'
import moment from 'moment'
import formatdate from '../../../utils/formatdate.js'
let qualityUrl = global.qualityUrl
export default {
  props: ['message'],
  data() {
    return {
      formChartDate: [],
      valye: true,
      sysAutoScoringList: [], // 循环任务查询结果
      currentPage: 1,
      pageSizes: [10, 20, 30, 40],
      pageSizesAssign: [10, 20, 30, 40],
      pageSize: 20,
      pageSizeAssign: 20,
      total: 1,
      currentStrategy: {}, // 当前选择策略
      totalAssign: 1,
      currentPageAssign: 1,
      dialogVisible: false,
      tableData: [],
      aa: [],
      strategyList: [], // 策略列表
      assignTableData: [],
      vauleSize: this.setStrategy,
      cc: '',
      option2Rate: {
        title: {
          text: '录音数',
        },
        tooltip: {},
        legend: {
          data: ['录音'],
        },
        xAxis: [
          {
            data: [],
          },
        ],
        yAxis: {},
        series: [
          {
            name: '录音',
            type: 'line',
            data: [],
            itemStyle: {
              normal: {
                color: '#50b4ff',
              },
            },
          },
        ],
      },
    }
  },
  methods: {
    getbackNow: function() {
      // this.$router.push('/qaTask')
      this.$emit('peoAltill', true)
    },
    convertCallTime(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    convertScore(x, y, score) {
      let needConvert = score && score != 'null'
      return needConvert ? parseFloat(score).toFixed(0) : ''
    },
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    handleSizeChangeAssign(val) {
      this.pageSizeAssign = val
    },
    handleCurrentChangeAssign(val) {
      this.currentPageAssign = val
    },
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return this.gettimeform(cellValue)
      }
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let hours = date.getHours()
      if (hours < 10) {
        hours = '0' + hours
      }
      let minute = date.getMinutes()
      if (minute < 10) {
        minute = '0' + minute
      }
      let second = date.getSeconds()
      if (second < 10) {
        second = '0' + second
      }
      let str = year + '-' + month + '-' + day + ' ' + hours + ':' + minute + ':' + second
      return str
    },
    toFixed(x, y, cellVal) {
      let val = parseFloat(cellVal)
      return (val * 100).toFixed(2) + '%'
    },
    viewAssign(logId) {
      let configId = this.$store.state.assigView.configId
      console.log(configId)
      let _this = this

      // 访问后台获取数据
      this.axios
        .post(qualityUrl + '/manualSampling/getManualTaskDisDeatil.do?taskId=' + logId)
        .then(function(response) {
          _this.assignTableData = response.data.Data
        })
      this.dialogVisible = true
    },
    search: function() {
      $('#echartImg').show()
      const self = this
      let configId = this.$store.state.assigView.configId
      let params = {
        configId: configId,
        fromDate: this.fromDate,
        toDate: this.toDate,
      }
      if (!params['fromDate'] || !params['toDate']) {
        this.$message.error('请选择时间范围!')
        return
      }
      this.axios
        .post(qualityUrl + '/asc/viewChart.do', Qs.stringify(params))
        .then((res) => {
          if (res.data) {
            console.log(res.data.stsMap)
            // 对象转换为数组
            let arr = []
            for (let i in res.data.stsMap) {
              let str = i + ':' + res.data.done
              arr.push(str.substring(8, 10))
            }

            let done = res.data.stsMap
            let testArr = JSON.stringify(done).split(',')
            let result = []
            for (let i = 0; i < testArr.length; i++) {
              result.push(testArr[i].replace('}', '').split(':')[1])
            }
            // console.log(testArr,result);
            this.option2Rate.series[0].data = result

            let options = null
            this.option2Rate.xAxis[0].data = arr
            options = self.option2Rate

            let myChart = self.$echarts.init(document.getElementById('echartImg'))
            console.log(options)
            myChart.setOption(options)
          } else {
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    sameNot: function() {
      this.dialogVisible = false
    },
    changeTime2: function(val) {
      let fdata = formatdate.formatDate(this.formChartDate[0])
      let edata = formatdate.formatDate(this.formChartDate[1])
      // console.log(fdata2,edata2);
      /* if(edata2!=fdata2){
         this.$message({
         type: 'warning',
         message: '时间范围不可超过一个月'
         });
         } */
      this.fromDate = fdata
      this.toDate = edata
    },
  },
  mounted() {
    // 挂载后执行
    let _this = this
    let storage = window.localStorage // 解决网页刷新存储数据丢失
    let configId = this.$store.state.assigView.configId
    if (window.localStorage) {
      if (configId != '' && configId != null) {
        storage.setItem('configId', configId)
      }
    }
    if (configId == '' || configId == null) {
      configId = storage.getItem('configId')
    }
    let params = {
      sysSampleConfigId: configId,
      currentPage: 1,
      pageSize: 10,
    }
    this.axios
      .post(qualityUrl + '/manualSampling/getManualTaskDetail.do', Qs.stringify(params))
      .then(function(response) {
        _this.tableData = response.data
        _this.aa = response.data[0].strategyObject
        _this.total = response.data.Count
      })
      .catch()
  },
  computed: {
    strategyObject() {
      let obj = JSON.parse(this.aa)
      console.log(obj)
      if (obj['callSTime'] && obj['callSTime'].length === 2) {
        obj['callSTime'] =
          moment(obj['callSTime'][0]).format('YYYY-MM-DD HH:mm:ss') +
          ' - ' +
          moment(obj['callSTime'][1]).format('YYYY-MM-DD HH:mm:ss')
        obj['callSTime$CName'] = '录音时间范围'
      }
      if (obj['callTime_Min'] && obj['callTime_Max']) {
        if (obj['timeType'] == '0') {
          obj['callTime_Min'] = obj['callTime_Min'] + '秒'
          obj['callTime_Max'] = obj['callTime_Max'] + '秒'
        } else if (obj['timeType'] == '1') {
          obj['callTime_Min'] = obj['callTime_Min'] + '分'
          obj['callTime_Max'] = obj['callTime_Max'] + '分'
        } else if (obj['timeType'] == '2') {
          obj['callTime_Min'] = obj['callTime_Min'] + '时'
          obj['callTime_Max'] = obj['callTime_Max'] + '时'
        }
      }
      if (obj['timeType']) {
        obj['timeType'] = ''
      }
      return obj
    },
  },
  watch: {
    currentPage() {
      this.search()
    },
    pageSize() {
      this.search()
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.goBackmessage {
  overflow: hidden;
  height: 100%;
  position: relative;
  .backPage {
    color: #20a0ff;
    padding: 19px 0 10px 18px;
    span {
      cursor: pointer;
    }
  }
  .content {
    padding-bottom: 150px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .sysAutoScoringInCallResult-page {
    right: 10px;
    position: absolute;
    bottom: 10px;
  }
  .table {
    width: 100%;
    height: 100%;
    overflow: auto;
  }
  .cellLeft {
    display: inline-block;
    padding: 10px 0 30px 19px;
    font-size: 14px;
    color: #1f2d3d;
  }
  .cellRight {
    display: inline-block;
    float: right;
    padding-right: 31px;
    .el-button {
      color: #475669;
      width: 88px;
      padding: 10px 16px 10px 16px;
    }
  }
}
</style>
<style lang="less">
.spelShow {
  .el-dialog__body {
    padding: 0;
  }
  .spelDiv {
    padding: 20px;
  }
}
.tableCell {
  padding-left: 19px;
  padding-right: 30px;
}
.content .table th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}
.detailContainernew {
  width: 100%;
  display: inline-block;
  margin: 15px 6px 0px;
  overflow: hidden;
  white-space: nowrap;
  text-align: left;
  padding: 0;
  position: relative;
  color: #1f2d3d;
  border-radius: 4px;
  vertical-align: middle;
  & > span {
    .strategybtn {
      cursor: pointer;
      overflow: hidden;
      padding-left: 10px;
      padding-right: 10px;
      .settingStrategyName {
        width: 100%;
        overflow: hidden;
        display: inline-block;
        text-overflow: ellipsis;
        float: left;
      }
    }
    .settingStrategybtns {
      float: right;
      width: 50px;
      i {
        margin-right: 5px;
        width: 18px;
        height: 18px;
        line-height: 18px;
        font-size: 10px;
        color: #20a0ff;
        &:hover {
          background: #20a0ff;
          color: #fff;
          border-radius: 50%;
        }
      }
    }
  }
  &.hovered {
    border-color: #20a0ff;
    span .strategybtn {
      padding-right: 0px;
      .settingStrategyName {
        width: 100px;
        color: #20a0ff;
      }
    }
    &.active span .strategybtn {
      .settingStrategyName {
        color: #fff;
      }
      .settingStrategybtns {
        i {
          color: #fff;
          &:hover {
            background: #fff;
            color: #20a0ff;
          }
        }
      }
    }
  }
  &.active {
    background: #20a0ff;
    color: #fff;
    border-color: #20a0ff;
    .settingStrategybtns {
      i {
        &:hover {
          background: #fff;
          color: #20a0ff;
        }
      }
    }
  }
  .detailsNew {
    display: flex;
    flex-wrap: wrap;
  }
  .contentNew {
    line-height: 30px;
    width: 100%;
    span {
      color: #9ca2b2;
      i {
        color: #1f2d3d;
      }
    }
  }
}
.detailContainernew {
  .el-popover {
    width: 10% !important;
  }
}
</style>
