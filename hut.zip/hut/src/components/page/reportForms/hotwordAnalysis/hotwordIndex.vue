<template>
  <div class="hotwordIndexWrap">
    <div v-show="!isShowDetail" class="hotwordIndex">
      <div class="header-title">
        <span style="flex:1;font-size: 14px;">智能分析 ——— 热词分析</span>
      </div>
      <div class="header-search">
        <div style="flex:1">
          <span style="margin-right:10px;">业务</span>
          <businessTree
            ref="businessTree"
            @saveSubjectClassId="saveSubjectClassId"
          ></businessTree>
          <dateComponent
            ref="dateComponent"
            @changeDate="getChildChangeDate"
          ></dateComponent>
        </div>
        <div class="right">
          <el-button @click="onSearch" style="margin-left: 10px" type="primary"
            >查询</el-button
          >
        </div>
      </div>
      <div class="header-operate">
        <el-radio-group style="flex:1" v-model="selectSortTab" @change="changeTab">
          <el-radio-button label="1">用户热词</el-radio-button>
          <el-radio-button label="2">客服热词</el-radio-button>
          <el-radio-button label="3">关注热词</el-radio-button>
        </el-radio-group>
      </div>
      <div class="content-reports">
        <div style="flex:1;">
          <div id="myChart" style="width: 100%;height: 100%;"></div>
        </div>
        <div style="flex:1;overflow-y: auto">
          <el-table
            class="xq-table"
            :data="tableData"
            border
            height="100%"
            style="width: 100%;"
          >
            <el-table-column type="index" width="50" show-overflow-tooltip label="序号">
            </el-table-column>
            <el-table-column prop="word" label="热词"> </el-table-column>
            <el-table-column
              sortable
              prop="recordWordTimesPer"
              :render-header="renderHeader"
              label="录音占比"
            >
              <template scope="scope">
                <div>
                  <span>{{ scope.row.recordWordTimesPer }}%</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="100">
              <template scope="scope">
                <el-button @click="showRecordList(scope.row)" type="text">详情</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <div class="hotwordDetailWrap" v-show="isShowDetail">
      <div class="wraper-hotword" v-show="isShowReportForm">
        <div class="header-back">
          <el-button @click="goback" type="text"><返回</el-button>
        </div>
        <div class="content-wrap">
          <div style="height:30px;line-height: 30px">
            <span style="font-size: 14px;float:left;">趋势分布</span>
          </div>
          <div style="flex:1;border:1px solid #ccc;" id="myChartHotDetailSub1"></div>
          <div style="height:45px;line-height: 45px">
            <span style="font-size: 14px;float:left;">来源</span>
            <el-button
              style="width:100px;float:right;margin-top: 3px;"
              @click="exportExcel('recordListHot')"
              >导出</el-button
            >
          </div>
          <div style="flex:1;overflow-y: auto">
            <el-table
              class="fh-table"
              :data="tableDataHot"
              border
              height="100%"
              style="width: 100%;"
            >
              <el-table-column type="index" width="50" show-overflow-tooltip label="序号">
              </el-table-column>
              <el-table-column prop="callId" label="录音编号"> </el-table-column>
              <el-table-column prop="callSTime" label="录音开始时间">
                <template scope="scope">
                  <div>{{ scope.row.callSTime | filterCreatTime }}</div>
                </template>
              </el-table-column>
              <el-table-column sortable prop="callTime" label="录音时长">
                <template scope="scope">
                  <div>{{ scope.row.callTime | filterCallTime }}</div>
                </template>
              </el-table-column>
              <el-table-column prop="sortName" label="业务小类"> </el-table-column>
              <el-table-column width="100" label="操作">
                <template scope="scope">
                  <el-button @click="showDetail(scope.row)" type="text">查看</el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="page">
            <el-pagination
              @size-change="handleSizeChangeHot"
              @current-change="handleCurrentChangeHot"
              :current-page="currentPageHot"
              :page-sizes="pageSizes"
              :page-size="pageSizeHot"
              layout="total,sizes, prev, pager, next, jumper"
              :total="totalHot"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <div class="wraper-hotword" v-show="isShowTable">
        <div class="header-back">
          <el-button @click="goback" type="text"><返回</el-button>
          <el-button style="width:100px;float:right;" @click="exportExcel('recordList')"
            >导出</el-button
          >
        </div>
        <div style="flex:1;overflow-y: auto">
          <el-table
            class="fh-table"
            :data="tableDataDetail"
            border
            height="100%"
            style="width: 100%;"
          >
            <el-table-column type="index" width="50" show-overflow-tooltip label="序号">
            </el-table-column>
            <el-table-column prop="callId" label="录音编号"> </el-table-column>
            <el-table-column prop="callSTime" label="录音开始时间">
              <template scope="scope">
                <div>{{ scope.row.callSTime | filterCreatTime }}</div>
              </template>
            </el-table-column>
            <el-table-column sortable prop="callTime" label="录音时长">
              <template scope="scope">
                <div>{{ scope.row.callTime | filterCallTime }}</div>
              </template>
            </el-table-column>
            <el-table-column prop="sortName" label="业务小类"> </el-table-column>
            <el-table-column label="操作" width="100">
              <template scope="scope">
                <el-button @click="showDetail(scope.row)" type="text">查看</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="page">
          <el-pagination
            @size-change="handleSizeChangeDetail"
            @current-change="handleCurrentChangeDetail"
            :current-page="currentPageDetail"
            :page-sizes="pageSizes"
            :page-size="pageSizeDetail"
            layout="total,sizes, prev, pager, next, jumper"
            :total="totalDetail"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import dateComponent from '../dateComponent'
import businessTree from '../businessTree'
import global from '../../../../global'
import qs from 'qs'
import bus from '../../../common/bus'
import formatdate from '../../../../utils/formatdate'
import commonUtil from '../../../../utils/commonUtil.js'
import recordingplay from '../../recordingPlay/recordingPlayResultScore'
const currentBaseUrl = global.currentBaseUrl
const colorList = [
  '#1890FF',
  '#41D9C7',
  '#2FC25B',
  '#FACC14',
  '#E6965C',
  '#223273',
  '#7564CC',
  '#8543E0',
  '#5C8EE6',
  '#13C2C2',
  '#5CA3E6',
  '#3436C7',
  '#B381E6',
  '#F04864',
  '#D598D9',
]
export default {
  name: 'hotwordIndex',
  components: {
    recordingplay: recordingplay,
    dateComponent: dateComponent,
    businessTree: businessTree,
  },
  data() {
    return {
      recordDialogVisible: false,
      selectSortTab: '1',
      isShowDetail: false,
      isShowReportForm: false,
      isShowTable: false,
      // 子组件获取time
      startTime: '',
      endTime: '',
      selectTimeType: '', // 时间粒度
      subjectClassId: '', // 业务分类
      subjectClassIdCopy: '', // 业务分类
      currentPage: 1, // 当前页码
      total: 0, // 记录总条数
      pageSize: 20, // 每页显示的记录条数
      pageSizes: [10, 15, 20, 25],
      tableData: [],
      // 热词detail
      keyword: '',
      currentPageHot: 1, // 当前页码
      totalHot: 0, // 记录总条数
      pageSizeHot: 20, // 每页显示的记录条数
      tableDataHot: [],
      // 录音列表
      currentPageDetail: 1, // 当前页码
      totalDetail: 0, // 记录总条数
      pageSizeDetail: 20, // 每页显示的记录条数
      tableDataDetail: [],
    }
  },
  mounted() {
    this.init()
  },
  filters: {
    filterCreatTime(val) {
      if (val) {
        return formatdate.formatDate(val)
      }
    },
    filterCallTime(val) {
      if (val) {
        let time = parseInt(val / 1000)
        return time
      }
    },
  },
  methods: {
    init() {
      this.onSearch()
    },
    goback() {
      this.keyword = ''
      this.isShowDetail = false
      this.isShowReportForm = false
      this.isShowTable = false
      this.currentPage = 1
      this.currentPageDetail = 1
      this.currentPageHot = 1
      this.pageSize = 20
      this.pageSizeDetail = 20
      this.pageSizeHot = 20
    },
    changeTab(val) {
      this.init()
    },
    // 获取树当前选中节点
    saveSubjectClassId(val) {
      if (!this.subjectClassId) {
        this.subjectClassId = val
        this.init()
      }
      this.subjectClassId = val
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val
      this.getRecordList()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.getRecordList()
    },
    // 录音详情页面分页
    handleSizeChangeDetail(val) {
      this.pageSizeDetail = val
      this.getHotCallData('xiangqing')
    },
    handleCurrentChangeDetail(val) {
      this.currentPageDetail = val
      this.getHotCallData('xiangqing')
    },
    renderHeader() {
      return (
        <div style="float:left;">
          <el-tooltip class="item" content="词出现的音频之和/录音总数" placement="top">
            <i style="color:#409EFF;" class="el-icon-warning" />
          </el-tooltip>
          <span>录音占比</span>
        </div>
      )
    },
    // 调到录音播放页
    showDetail(row) {
      let { callId, isSampled, callSTime, callNo, mblNo, recordFileURL } = row
      let obj = {}
      obj.from = 'hotWord'
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.isSampled = isSampled
      obj.callSTime = callSTime
      obj.mblNo = mblNo ? mblNo : ''
      obj.callNo = callNo ? callNo : ''
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    getChildChangeDate(val) {
      let arr = val.split(',')
      this.startTime = arr[1]
      this.endTime = arr[2]
      this.selectTimeType = arr[0]
    },
    //进入热词模块
    toHotWord() {
      console.log('11')
    },
    initBusinessTrafficAnalysisData() {
      let params = {
        businessType: this.subjectClassId,
        startTime: this.startTime,
        endTime: this.endTime,
        statisticsSize: this.selectTimeType,
        type: this.selectSortTab,
      }
      this.axios
        .get(`${currentBaseUrl}/hotWordAnalysis/categoryHotWord`, { params })
        .then((res) => {
          let { data, message, code } = res.data
          if (code == 0) {
            let dataval = data == null ? [] : data
            this.hotWordBarAnalysis(dataval)
          } else {
            this.$message.error(message)
          }
        })
        .catch((err) => console.log(err))
    },
    getRecordList() {
      let params = {
        businessType: this.subjectClassId,
        startTime: this.startTime,
        endTime: this.endTime,
        statisticsSize: this.selectTimeType,
        type: this.selectSortTab,
        currentPage: this.currentPage,
        pageSize: this.pageSize,
      }
      this.axios
        .get(`${currentBaseUrl}/hotWordAnalysis/categoryHotWordList`, { params })
        .then((res) => {
          let resp = res.data
          if (resp.success) {
            this.tableData = resp.results == null ? [] : resp.results
            this.total = resp.count
          } else {
            this.$message.error(resp.message)
          }
        })
        .catch((err) => console.log(err))
    },
    // 热词柱状
    hotWordBarAnalysis(data) {
      let _this = this
      let xAxisData = []
      let seriesData = []
      data.map((item) => {
        xAxisData.push(item.word)
        seriesData.push({
          value: item.times,
          id: item.sortName,
          word: item.word,
          pre: item.recordWordTimesPer,
        })
      })
      let option = {
        color: colorList,
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
          formatter: function(params) {
            let { id, pre, value, word } = params[0].data
            let res = ''
            res += '<p>热词：' + word + '</p>' + '<p>录音占比：' + pre + '%</p>'
            return res
          },
        },
        dataZoom: [{ type: 'inside' }],
        toolbox: {
          show: true,
          right: 10,
          top: 0,
          itemSize: 18,
          feature: {
            saveAsImage: {
              show: true,
              icon: 'image://static/img/downLoad.png',
              name: '热词分析',
            },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('hotWordBarAnalysis')
              },
            },
          },
        },
        grid: {
          left: '3%',
          right: '5%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            data: xAxisData,
            axisTick: {
              alignWithLabel: true,
            },
            axisLabel: {
              interval: 0,
              rotate: 40,
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: {
              show: false,
            },
          },
        ],
        series: [
          {
            type: 'bar',
            barWidth: '60%',
            label: {
              normal: {
                show: true,
                position: 'top',
              },
            },
            data: seriesData,
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.getElementById('myChart'))
        myChart.clear()
        myChart.setOption(option)
        // 查看详情
        myChart.on('click', function(param) {
          let { word } = param.data
          _this.keyword = word
          _this.isShowDetail = true
          _this.isShowReportForm = true
          _this.getHotCallData()
          _this.getHotTrendData()
        })
      })
    },
    /*
     * 热词detail
     * */
    // 分页
    handleSizeChangeHot(val) {
      this.pageSizeHot = val
      this.getHotCallData()
    },
    handleCurrentChangeHot(val) {
      this.currentPageHot = val
      this.getHotCallData()
    },
    getHotTrendData() {
      let params = {
        businessType: this.subjectClassId,
        startTime: this.startTime,
        endTime: this.endTime,
        statisticsSize: this.selectTimeType,
        type: this.selectSortTab,
        keyword: this.keyword,
      }
      this.axios
        .post(`${currentBaseUrl}/hotWordAnalysis/trend`, qs.stringify(params))
        .then((res) => {
          let { code, data, message } = res.data
          if (code == 0) {
            this.hotDetailTrend(data)
          } else {
            this.$message.error(message)
          }
        })
        .catch((err) => console.log(err))
    },
    // 热词趋势
    hotDetailTrend(data) {
      let _this = this
      let xAxisData = data.dates
      let seriesData = data.data
      let option = {
        color: colorList,
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        dataZoom: [{ type: 'inside' }],
        toolbox: {
          show: true,
          right: 0,
          top: 10,
          itemSize: 18,
          feature: {
            saveAsImage: {
              show: true,
              icon: 'image://static/img/downLoad.png',
              name: '热词趋势分析',
            },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('hotDetailTrend')
              },
            },
          },
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: {
          type: 'category',
          data: xAxisData,
        },
        yAxis: {
          type: 'value',
        },
        series: {
          type: 'line',
          data: seriesData,
        },
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.getElementById('myChartHotDetailSub1'))
        myChart.clear()
        myChart.setOption(option)
      })
    },
    // detail录音列表
    getHotCallData(data) {
      let params = {
        businessType: this.subjectClassId,
        startTime: this.startTime,
        endTime: this.endTime,
        statisticsSize: this.selectTimeType,
        type: this.selectSortTab,
        keyword: this.keyword,
        currentPage: data == 'xiangqing' ? this.currentPageDetail : this.currentPageHot,
        pageSize: data == 'xiangqing' ? this.pageSizeDetail : this.pageSizeHot,
      }
      this.axios
        .post(`${currentBaseUrl}/hotWordAnalysis/records`, qs.stringify(params))
        .then((res) => {
          let { success, results, count, message } = res.data
          if (success) {
            this.tableDataHot = results == null ? [] : results
            this.totalHot = count
            this.tableDataDetail = results == null ? [] : results
            this.totalDetail = count
          } else {
            this.$message.error(message)
          }
        })
        .catch((err) => console.log(err))
    },
    showRecordList(row) {
      let { word } = row
      this.isShowDetail = true
      this.isShowTable = true
      this.keyword = word
      this.getHotCallData('xiangqing')
    },
    // 导出
    exportExcel(val) {
      let url = ''
      let params = {
        businessType: this.subjectClassId,
        startTime: this.startTime,
        endTime: this.endTime,
        statisticsSize: this.selectTimeType,
        type: this.selectSortTab,
        keyword: this.keyword,
      }
      if (val == 'hotWordBarAnalysis') {
        url = `${currentBaseUrl}/hotWordAnalysis/categoryHotWord/excel`
      } else if (val == 'hotDetailTrend') {
        url = `${currentBaseUrl}/hotWordAnalysis/trend/excel`
      } else if (val == 'recordList') {
        url = `${currentBaseUrl}/hotWordAnalysis/records/excel`
      } else if (val == 'recordListHot') {
        url = currentBaseUrl + '/hotWordAnalysis/records/excel'
      }
      console.log(params)
      commonUtil.doExport(url, params, global.jsonHeader)
    },
    // 查询
    onSearch() {
      let start = this.getTime(this.startTime)
      let end = this.getTime(this.endTime)
      if (start > end) {
        this.$message.warning('请输入合理的时间范围')
        return
      }
      if (this.subjectClassId) {
        this.initBusinessTrafficAnalysisData()
        this.getRecordList()
      }
    },
    // 获取时间戳
    getTime(val) {
      let newdata = new Date(val)
      let time = newdata.getTime()
      return time
    },
  },
}
</script>
<style lang="less">
.hotwordIndexWrap {
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 0px 0px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
  .el-table td,
  .el-table th {
    padding: 0;
  }
  .el-table.xq-table {
    height: 100%!important;
    .caret-wrapper {
      margin-top: 3px;
    }
  }
}
</style>
<style scoped lang="less">
.hotwordIndexWrap {
  width: 100%;
  height: 100%;
  position: relative;
  .hotwordDetailWrap {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    position: relative;
    overflow-x: hidden;
    .wraper-hotword {
      width: 100%;
      height: 100%;
      position: relative;
      padding: 0 20px 10px;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      .el-table.fh-table {
        height: 100% !important;
      }
      .header-title {
        height: 50px;
        display: flex;
        align-items: center;
      }
      .header-back {
        height: 40px;
        margin: 10px 0;
      }
      .header-operate {
        height: 40px;
        margin-bottom: 10px;
        display: flex;
      }
      .content-wrap {
        flex: 1;
        display: flex;
        flex-direction: column;
        .el-table.fh-table {
          height: 100%!important;
        }
        .content-reports-block {
          flex: 1;
          display: flex;
          flex-direction: column;
          margin: 5px 0;
          .sub-block {
            flex: 1;
          }
        }
      }
      .page {
        height: 40px;
        display: flex;
        flex-direction: row-reverse;
        margin-top: 20px;
      }
    }
  }
  .hotwordIndex {
    width: 100%;
    height: 100%;
    position: relative;
    padding: 0 20px 10px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    .header-title {
      height: 50px;
      display: flex;
      align-items: center;
    }
    .header-search {
      height: 100px;
      display: flex;
      align-items: center;
      border: 1px solid #ccc;
      padding: 0 20px;
      font-size: 14px;
      box-sizing: border-box;
    }
    .header-operate {
      height: 40px;
      margin: 10px 0;
      display: flex;
    }
    .content-reports {
      flex: 1;
      display: flex;
      flex-direction: column;
      .content-reports-block {
        flex: 1;
        display: flex;
        flex-direction: column;
        .page {
          height: 40px;
          display: flex;
          flex-direction: row-reverse;
          margin-top: 20px;
        }
      }
    }
  }
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
}
</style>
