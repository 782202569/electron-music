<template>
  <div class="callDurationIndexWrap">
    <div v-show="!isShowDetail" class="callDurationIndex">
      <div>
        <span class="header-title">智能分析 ——— 通话时长分析</span>
      </div>
      <div class="header-search">
        <div style="height:40px; margin-bottom: 20px">
          <span style="margin-right:10px;">业务</span>
          <businessTree
            ref="businessTree"
            @saveSubjectClassId="saveSubjectClassId"
          ></businessTree>
          <dateComponent
            ref="dateComponent"
            @changeDate="getChildChangeDate"
          ></dateComponent>
        </div>
        <div style="height:40px;">
          <span>工号</span>
          <el-input style="width: 100px;margin:0 20px 0 10px;" v-model="jobNumber" />
          <span>通话时长</span>
          <el-input style="width: 100px;margin:0 10px" v-model="minSecond" /> 秒 ～
          <el-input style="width: 100px;" v-model="maxSecond" /> 秒
          <div style="float:right">
            <el-button @click="onSearch" style="margin-left: 10px" type="primary"
              >查询</el-button
            >
          </div>
        </div>
      </div>
      <div class="content-reports">
        <div class="callDurationDetail">
          <div class="wraper">
            <div class="header-operate">
              <el-radio-group style="flex:1" v-model="selectTab" @change="changeTab">
                <el-radio-button label="0">分析情况</el-radio-button>
                <el-radio-button label="1">录音列表</el-radio-button>
              </el-radio-group>
              <el-button @click="exportExcel('exportDetail')" v-if="selectTab == 1"
                >导出</el-button
              >
            </div>
            <div class="content-chart" v-if="selectTab == 0">
              <div
                class="content-chart-block"
                style="border:1px solid #ccc; flex-direction: column;"
              >
                <div class="header">
                  <span style="font-size: 16px;">通话时长分析</span>
                </div>
                <div style="flex:1;">
                  <div id="myChart" style="width: 100%;height: 100%;"></div>
                </div>
              </div>
              <div class="content-chart-block" style="flex-direction: row">
                <div class="content-reports-block-sub">
                  <div style="height:30px;line-height: 30px">
                    <span style="font-size: 14px;float:left;">录音时长分布占比分析</span>
                  </div>
                  <div class="sub-block">
                    <div style="width:100%;height:100%;" id="myChartSub1"></div>
                  </div>
                </div>
                <div class="content-reports-block-sub">
                  <div style="height:30px;line-height: 30px">
                    <span style="font-size: 14px;float:left;">通话时长趋势</span>
                  </div>
                  <div class="sub-block">
                    <div style="width:100%;height:100%;" id="myChartSub2"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="content-wrap" v-else>
              <div style="flex:1;overflow-y: auto">
                <el-table
                  class="fh-table"
                  :data="tableData"
                  border
                  height="100%"
                  style="width: 100%;">
                  <el-table-column
                    type="index"
                    width="50"
                    show-overflow-tooltip
                    label="序号"
                  ></el-table-column>
                  <el-table-column prop="sortName" label="业务" width="120">
                  </el-table-column>
                  <el-table-column sortable prop="countRank" label="话务量占比">
                    <template scope="scope">
                      <div>{{ scope.row.countRank }}%</div>
                    </template>
                  </el-table-column>
                  <el-table-column sortable prop="avgCallTime" label="平均时长(秒)">
                    <template scope="scope">
                      {{ scope.row.avgCallTime | filterTime }}
                    </template>
                  </el-table-column>
                  <el-table-column sortable prop="trend" label="趋势变化">
                    <template scope="scope">
                      <div v-if="scope.row.lastCount != 0">
                        {{ scope.row.trend | filterTrend }}%
                        <i
                          v-if="scope.row.trend < 0"
                          style="color:green;font-size: 14px;"
                          class="iconfont icon-jiantoudown"
                        ></i
                        ><i
                          v-else-if="scope.row.trend > 0"
                          style="color:red;font-size: 14px;"
                          class="iconfont icon-jiantouup"
                        ></i>
                      </div>
                      <div v-else>--</div>
                    </template>
                  </el-table-column>
                  <el-table-column label="操作" width="100">
                    <template scope="scope">
                      <el-button @click="showRecordList(scope.row)" type="text"
                        >详情</el-button
                      >
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="page">
                <el-pagination
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page="currentPage"
                  :page-sizes="pageSizes"
                  :page-size="pageSize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="total"
                >
                </el-pagination>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-show="isShowDetail" class="callDurationListDetail">
      <div class="header-back">
        <el-button @click="goback" type="text">返回</el-button>
        <el-button style="float:right;" @click="exportExcel('exportRecords')"
          >导出</el-button
        >
      </div>
      <div style="flex:1;overflow-y: auto">
        <el-table
          class="call-table"
          :data="tableDataDetail"
          border
          height="100%"
          style="width: 100%;"
        >
          <el-table-column type="index" width="50" show-overflow-tooltip label="序号">
          </el-table-column>
          <el-table-column prop="callId" label="录音编号" width="120"> </el-table-column>
          <el-table-column prop="callSTime" label="录音开始时间" width="160">
            <template scope="scope">
              <div>{{ scope.row.callSTime | filterCreatTime }}</div>
            </template>
          </el-table-column>
          <el-table-column sortable prop="callTime" label="录音时长"> </el-table-column>
          <el-table-column prop="sortName" label="业务小类"> </el-table-column>
          <el-table-column label="操作">
            <template scope="scope">
              <el-button @click="showDetail(scope.row)" type="text">查看</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="page">
        <el-pagination
          @size-change="handleSizeChangeDetail"
          @current-change="handleCurrentChangeDetail"
          :current-page="currentPageDetail"
          :page-sizes="pageSizes"
          :page-size="pageSizeDetail"
          layout="total,sizes, prev, pager, next, jumper"
          :total="totalDetail"
        >
        </el-pagination>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import dateComponent from '../dateComponent'
import businessTree from '../businessTree'
import recordingplay from '../../recordingPlay/recordingPlayResultScore'
import global from '../../../../global'
import bus from '../../../common/bus'
import commonUtil from '../../../../utils/commonUtil.js'
import formatdate from '../../../../utils/formatdate'
import qs from 'qs'
const currentBaseUrl = global.currentBaseUrl
const colorList = [
  '#1890FF',
  '#41D9C7',
  '#2FC25B',
  '#FACC14',
  '#E6965C',
  '#223273',
  '#7564CC',
  '#8543E0',
  '#5C8EE6',
  '#13C2C2',
  '#5CA3E6',
  '#3436C7',
  '#B381E6',
  '#F04864',
  '#D598D9',
]
export default {
  name: 'callDurationIndex',
  components: {
    dateComponent: dateComponent,
    businessTree: businessTree,
    recordingplay: recordingplay,
  },
  data() {
    return {
      isShowDetail: false,
      jobNumber: '',
      minSecond: '',
      maxSecond: '',
      copyMinSecond: '',
      copyMaxSecond: '',
      // 子组件获取time
      startTime: '',
      endTime: '',
      selectTimeType: '',
      subjectClassId: '',
      copySubjectClassId: '',
      // 分析情况 录音详情列表
      recordDialogVisible: false,
      selectTab: '0',
      currentPage: 1, // 当前页码
      total: 0, // 记录总条数
      pageSize: 10, // 每页显示的记录条数
      pageSizes: [10, 15, 20, 25],
      tableData: [],
      // 录音列表
      currentPageDetail: 1, // 当前页码
      totalDetail: 0, // 记录总条数
      pageSizeDetail: 10, // 每页显示的记录条数
      tableDataDetail: [],
      isCircleChart: '',
    }
  },
  mounted() {
    this.onSearch()
  },
  methods: {
    getChildChangeDate(val) {
      let arr = val.split(',')
      this.startTime = arr[1]
      this.endTime = arr[2]
      this.selectTimeType = arr[0]
    },
    // 获取树当前选中节点
    saveSubjectClassId(val) {
      if (!this.subjectClassId) {
        this.subjectClassId = val
        this.init()
      }
      this.subjectClassId = val
    },
    // 查询
    onSearch() {
      let start = this.getTime(this.startTime)
      let end = this.getTime(this.endTime)
      if (start > end) {
        this.$message.warning('请输入合理的时间范围')
        return
      }
      if (Number(this.minSecond) > Number(this.maxSecond)) {
        this.$message.warning('请输入合理的时间区间')
        return
      }
      if (this.selectTab == 0) {
        this.init()
      } else {
        this.getCallData()
      }
    },
    // 获取时间戳
    getTime(val) {
      let newdata = new Date(val)
      let time = newdata.getTime()
      return time
    },
    goback() {
      this.isShowDetail = false
      this.subjectClassId = this.copySubjectClassId
      this.copyMinSecond = ''
      this.copyMaxSecond = ''
      this.isCircleChart = ''
      this.currentPage = 1
      this.currentPageDetail = 1
      this.pageSize = 10
      this.pageSizeDetail = 10
    },
    showRecordList(data) {
      this.copySubjectClassId = this.subjectClassId
      this.subjectClassId = data.sortId
      this.isShowDetail = true
      this.getCallDetailData()
    },
    // 分析情况 录音列表模块
    init() {
      let params = {
        startDate: this.startTime,
        endDate: this.endTime,
        sortId: this.subjectClassId,
        seatNo: this.jobNumber,
        callTimeMin: this.minSecond,
        callTimeMax: this.maxSecond,
        timeGranularity: this.selectTimeType,
      }
      if (this.subjectClassId) {
        this.axios
          .post(currentBaseUrl + '/callTimeStatics/queryCount', qs.stringify(params))
          .then((res) => {
            let { statusText, data } = res
            let dataval = data == null ? [] : data
            if (statusText == 'OK') this.callDurationAnalysis(dataval)
            else this.$message.error('获取数据失败')
          })
          .catch((err) => console.log(err))
        this.axios
          .post(currentBaseUrl + '/callTimeStatics/queryPercent ', qs.stringify(params))
          .then((res) => {
            let { statusText, data } = res
            let dataval = data == null ? [] : data
            if (statusText == 'OK') this.callDistribution(dataval)
            else this.$message.error('获取数据失败')
          })
          .catch((err) => console.log(err))
        this.axios
          .post(currentBaseUrl + '/callTimeStatics/queryTrend', qs.stringify(params))
          .then((res) => {
            let { statusText, data } = res
            let dataval = data == null ? [] : data
            if (statusText == 'OK') this.callDurationTrend(dataval)
            else this.$message.error('获取数据失败')
          })
          .catch((err) => console.log(err))
      }
    },
    changeTab(val) {
      if (val == 0) {
        this.init()
      } else {
        this.getCallData()
      }
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val
      this.getCallData()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.getCallData()
    },
    handleSizeChangeDetail(val) {
      this.pageSizeDetail = val
      this.getCallDetailData()
    },
    handleCurrentChangeDetail(val) {
      this.currentPageDetail = val
      this.getCallDetailData()
    },
    // 调到录音播放页
    showDetail(row) {
      let { callId, isSampled, callSTime, callNo, mblNo, recordFileURL } = row
      let obj = {}
      obj.from = 'recordingpoll'
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.isSampled = isSampled
      obj.callSTime = callSTime
      obj.mblNo = mblNo ? mblNo : ''
      obj.callNo = callNo ? callNo : ''
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 通话时长分析
    callDurationAnalysis(data) {
      let xAxisData = []
      let seriesData = []
      if (Array.isArray(data)) {
        data.map((item) => {
          let { sortId, sortName, count } = item
          xAxisData.push(sortName)
          seriesData.push({
            value: count,
            sortId: sortId,
          })
        })
      }
      let _this = this
      let option = {
        color: colorList,
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        dataZoom: [{ type: 'inside' }],
        toolbox: {
          show: true,
          right: 10,
          top: 0,
          itemSize: 18,
          feature: {
            saveAsImage: {
              show: true,
              icon: 'image://static/img/downLoad.png',
              name: '通话时长分析',
            },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('callDurationAnalysis')
              },
            },
          },
        },
        grid: {
          left: '3%',
          right: '5%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            data: xAxisData,
            axisTick: {
              alignWithLabel: true,
            },
            axisLabel: {
              interval: 0,
              rotate: 40,
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
          },
        ],
        series: [
          {
            type: 'bar',
            barWidth: '60%',
            label: {
              normal: {
                show: true,
                position: 'top',
              },
            },
            data: seriesData,
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.getElementById('myChart'))
        myChart.clear()
        myChart.setOption(option)
        // 查看详情
        myChart.on('click', function(params) {
          if (!_this.isShowDetail) {
            _this.copySubjectClassId = _this.subjectClassId
            _this.subjectClassId = params.data.sortId
            _this.isShowDetail = true
            _this.getCallDetailData()
          } else {
            _this.getCallDetailData()
          }
        })
      })
    },
    // 通话时长趋势
    callDurationTrend(data) {
      let xAxisData = []
      let seriesData = []
      data.map((item) => {
        let { count, name } = item
        xAxisData.push(name)
        seriesData.push(count)
      })
      let _this = this
      let option = {
        color: colorList,
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        dataZoom: [{ type: 'inside' }],
        toolbox: {
          show: true,
          right: 10,
          top: 0,
          itemSize: 18,
          feature: {
            saveAsImage: {
              show: true,
              icon: 'image://static/img/downLoad.png',
              name: '通话时长趋势',
            },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('callDurationTrend')
              },
            },
          },
        },
        grid: {
          left: '3%',
          right: '5%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: {
          type: 'category',
          data: xAxisData,
        },
        yAxis: {
          type: 'value',
        },
        series: [
          {
            data: seriesData,
            type: 'line',
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.getElementById('myChartSub2'))
        myChart.clear()
        myChart.setOption(option)
      })
    },
    // 录音时长分布占比分析
    callDistribution(data) {
      let seriesData = []
      data.map((item) => {
        let { callTimeRange, count, callTimeMin, callTimeMax } = item
        seriesData.push({
          name: callTimeRange,
          value: count,
          min: callTimeMin,
          max: callTimeMax,
        })
      })

      let _this = this
      let option = {
        color: colorList,
        toolbox: {
          show: true,
          right: 10,
          top: 0,
          itemSize: 18,
          feature: {
            saveAsImage: {
              show: true,
              icon: 'image://static/img/downLoad.png',
              name: '录音时长分布占比分析',
            },
            myExcel: {
              show: true,
              title: '导出Excel',
              icon: 'image://static/img/excelReport.png',
              z: '999',
              left: 'center',
              onclick: () => {
                this.exportExcel('callDistribution')
              },
            },
          },
        },
        grid: {
          left: '3%',
          right: '5%',
          bottom: '3%',
          containLabel: true,
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b} : {c} ({d}%)',
        },
        series: [
          {
            name: '访问来源',
            type: 'pie',
            radius: '55%',
            center: ['50%', '60%'],
            data: seriesData,
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
              },
            },
          },
        ],
      }
      this.$nextTick(function() {
        document.oncontextmenu = function() {
          return false
        }
        let myChart = _this.$echarts.init(document.getElementById('myChartSub1'))
        myChart.clear()
        myChart.setOption(option)
        // 查看详情
        myChart.on('click', function(params) {
          _this.copySubjectClassId = _this.subjectClassId
          let { min, max } = params.data
          _this.copyMinSecond = min
          _this.copyMaxSecond = max
          _this.getCallDetailData('circleChart')
          _this.isShowDetail = true
          _this.isCircleChart = '2'
        })
      })
    },
    // 录音详情列表数据
    getCallData() {
      let params = {
        startDate: this.startTime,
        endDate: this.endTime,
        sortId: this.subjectClassId,
        seatNo: this.jobNumber,
        callTimeMin: this.minSecond,
        callTimeMax: this.maxSecond,
        timeGranularity: this.selectTimeType,
        pageNumber: this.currentPage,
        pageSize: this.pageSize,
      }
      this.axios
        .post(currentBaseUrl + '/callTimeStatics/getDetails', qs.stringify(params))
        .then((res) => {
          let { count, data } = res.data
          if (data) {
            this.tableData = data == null ? [] : data
            this.total = count
          } else {
            this.tableData = []
            this.total = 0
          }
        })
        .catch((err) => console.log(err))
    },
    getCallDetailData(data) {
      let min = this.copyMinSecond
      let max = this.copyMaxSecond
      let iscircle = false
      let type = ''
      if (data == 'circleChart') {
        iscircle = true
        type = '2'
      }
      let params = {
        startDate: this.startTime,
        endDate: this.endTime,
        sortId: this.subjectClassId,
        seatNo: this.jobNumber,
        callTimeMin: (iscircle && min === 0) || min ? min : this.minSecond,
        callTimeMax: max ? max : this.maxSecond,
        type: type || this.isCircleChart,
        timeGranularity: this.selectTimeType,
        pageNumber: this.currentPageDetail,
        pageSize: this.pageSizeDetail,
      }
      this.axios
        .post(
          currentBaseUrl + '/callTimeStatics/queryDetailRecords',
          qs.stringify(params)
        )
        .then((res) => {
          let { count, data } = res.data
          if (data) {
            this.tableDataDetail = data == null ? [] : data
            this.totalDetail = count
          } else {
            this.tableDataDetail = []
            this.totalDetail = 0
          }
        })
        .catch((err) => console.log(err))
    },
    // 导出
    exportExcel(val) {
      let min = this.copyMinSecond
      let max = this.copyMaxSecond
      let url = ''
      let iscircle = false
      if (val == 'callDistribution') {
        iscircle = true
      }
      let params = {
        startDate: this.startTime,
        endDate: this.endTime,
        sortId: this.subjectClassId,
        seatNo: this.jobNumber,
        callTimeMin: (iscircle && min === 0) || min ? min : this.minSecond,
        callTimeMax: max ? max : this.maxSecond,
        timeGranularity: this.selectTimeType,
        pageNumber: this.currentPageDetail,
        pageSize: this.pageSizeDetail,
        type: this.isCircleChart,
      }
      if (val == 'callDurationAnalysis') {
        url = currentBaseUrl + '/callTimeStatics/exportCount'
      } else if (val == 'callDurationTrend') {
        url = currentBaseUrl + '/callTimeStatics/exportTrend'
      } else if (val == 'callDistribution') {
        url = currentBaseUrl + '/callTimeStatics/exportPercent'
      } else if (val == 'exportDetail') {
        url = currentBaseUrl + '/callTimeStatics/exportDetail'
      } else if (val == 'exportRecords') {
        url = currentBaseUrl + '/callTimeStatics/exportRecords'
      }
      console.log(params)
      commonUtil.doExport(url, params, global.jsonHeader)
    },
  },
  filters: {
    filterCreatTime(val) {
      if (val) {
        return formatdate.formatDate(val)
      }
    },
    filterTrend(val) {
      if (val < 0) {
        let value = val.toString().slice(1)*1
        return value.toFixed(2)
      } else {
        return val.toFixed(2)
      }
    },
    filterTime(val) {
      if (val) {
        return val.toFixed(2)
      }
    },
  },
}
</script>

<style scoped lang="less">
.callDurationIndexWrap {
  width: 100%;
  height: 100%;
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .callDurationIndex {
    width: 100%;
    height: 100%;
    position: relative;
    padding: 0 20px 10px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    .header-title {
      font-size: 14px;
      height: 50px;
      display: flex;
      align-items: center;
    }
    .header-search {
      /*height: 120px;*/
      min-width: 1064px;
      display: flex;
      flex-direction: column;
      border: 1px solid #ccc;
      padding: 10px 20px;
      font-size: 14px;
      box-sizing: border-box;
    }
    .content-reports {
      flex: 1;
      display: flex;
      .callDurationDetail {
        width: 100%;
        height: 100%;
        position: relative;
        overflow: hidden;
        .wraper {
          width: 100%;
          height: 100%;
          position: relative;
          display: flex;
          flex-direction: column;
          .header-operate {
            display: flex;
            height: 40px;
            margin: 10px 0;
          }
          .content-chart {
            flex: 1;
            /*padding-right: 10px;*/
            overflow-y: auto;
            box-sizing: border-box;
            .content-chart-block {
              height: 450px;
              display: flex;
              .header {
                width: 100%;
                height: 40px;
                line-height: 40px;
                text-align: center;
              }
              .content-reports-block-sub {
                flex: 1;
                display: flex;
                flex-direction: column;
                .sub-block {
                  flex: 1;
                }
              }
            }
          }
          .content-wrap {
            flex: 1;
            display: flex;
            overflow-y: auto;
            flex-direction: column;
            .el-table.fh-table {
              height: 100% !important;
            }
            .content-reports-block {
              flex: 1;
              display: flex;
              margin: 10px 0 0;
              .content-reports-block-sub {
                display: flex;
                flex: 1;
                flex-direction: column;
                margin-right: 10px;
                .title {
                  font-size: 14px;
                  color: #000;
                  font-weight: normal;
                  float: left;
                }
                .sub-block {
                  flex: 1;
                  border: 1px solid #ccc;
                }
              }
              .header {
                width: 100%;
                height: 40px;
                line-height: 40px;
                text-align: center;
              }
            }
            .page {
              height: 40px;
              display: flex;
              flex-direction: row-reverse;
              margin-top: 20px;
            }
          }
        }
      }
    }
  }
  .callDurationListDetail {
    width: 100%;
    height: 100%;
    padding: 20px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    .el-table.call-table {
      height: 100% !important;
    }
    .header-back {
      height: 40px;
      margin: 10px 0;
    }
    .page {
      height: 40px;
      display: flex;
      flex-direction: row-reverse;
      margin-top: 20px;
    }
  }
}
</style>
<style lang="less">
.callDurationIndexWrap {
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 0px 0px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
}
</style>
