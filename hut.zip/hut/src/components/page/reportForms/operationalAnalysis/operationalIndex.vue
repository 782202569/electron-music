<template>
  <div class="operationalIndexWrap">
    <div v-show="!isShowDetail" class="operationalIndex">
      <div class="header-title">
        <span style="flex:1;font-size: 14px;">智能分析 ——— 业务分析</span>
      </div>
      <div class="header-search">
        <div style="flex:1">
          <span style="margin-right:10px;">业务</span>
          <businessTree ref="businessTree" @saveSubjectClassId="saveSubjectClassId"></businessTree>
          <dateComponent ref="dateComponent" @changeDate="getChildChangeDate"></dateComponent>
        </div>
        <div class="right">
          <el-button @click="onSearch" style="margin-left: 10px" type="primary">查询</el-button>
        </div>
      </div>
      <div class="content-chart">
        <div class="content-chart-block" style="border:1px solid #ccc; flex-direction: column;">
          <div class="header">
            <span style="font-size: 16px;">业务话务量分布</span>
          </div>
          <div style="flex:1;">
            <div id="myChart" style="width: 100%;height: 100%;"></div>
          </div>
        </div>
        <div class="content-chart-block" style="flex-direction: row">
          <div class="content-chart-block-sub">
            <div style="height:30px;line-height: 30px">
              <span style="font-size: 14px;float:left;">话务量趋势</span>
            </div>
            <div class="sub-block">
              <div style="width:100%;height:100%;" id="myChartSub1"></div>
            </div>
          </div>
          <div class="content-chart-block-sub">
            <div style="height:30px;line-height: 30px">
              <el-button type="text" @click="toHotWord"><span class="title">业务热词 >></span></el-button>
            </div>
            <div class="sub-block">
              <div style="width:100%;height:100%;" id="myChartSub2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="operationalDetailWrap" v-show="isShowDetail">
      <div class="wraper-operation" v-show="isShowOperation">
        <div class="header-back">
          <el-button @click="goback" type="text">
            <返回</el-button> </div> <div class="header-operate">
              <el-radio-group style="flex:1" v-model="selectTab" @change="changeTab">
                <el-radio-button label="0">分析情况</el-radio-button>
                <el-radio-button label="1">录音列表</el-radio-button>
              </el-radio-group>
              <el-button v-if="selectTab == 1" @click="exportExcel('callList')">导出</el-button>
        </div>
        <div class="content-wrap" v-if="selectTab == 0">
          <div class="content-reports-block">
            <div style="height:30px;line-height: 30px">
              <span style="font-size: 14px;float:left;">话务量趋势</span>
            </div>
            <div style="flex:1;border:1px solid #ccc;" id="myChartDetailSub1"></div>
          </div>
          <div class="content-reports-block">
            <div style="height:30px;line-height: 30px">
              <span style="font-size: 14px;float:left;">业务热词</span>
            </div>
            <div style="flex:1;border:1px solid #ccc;" id="myChartDetailSub2"></div>
          </div>
        </div>
        <div class="content-wrap" v-else>
          <div style="flex:1;overflow-y: auto">
            <el-table class="fh-table" :data="tableData" border height="100%" style="width: 100%;">
              <el-table-column type="index" width="50" show-overflow-tooltip label="序号">
              </el-table-column>
              <el-table-column prop="callId" label="录音编号" width="120">
              </el-table-column>
              <el-table-column prop="callSTime" label="录音时间" width="160">
                <template scope="scope">
                  <div>{{ scope.row.callSTime | filterCreatTime }}</div>
                </template>
              </el-table-column>
              <el-table-column sortable prop="callTime" label="通话时长">
                <template scope="scope">
                  <div>{{ scope.row.callTime | filterCallTime }}</div>
                </template>
              </el-table-column>
              <el-table-column prop="seatNo" label="坐席ID"> </el-table-column>
              <el-table-column prop="sortName" label="业务大类"> </el-table-column>
              <el-table-column prop="dataState" label="状态"> </el-table-column>
              <el-table-column sortable prop="systemScore" label="系统评分">
              </el-table-column>
              <el-table-column label="操作">
                <template scope="scope">
                  <el-button @click="showDetail(scope.row)" type="text">查看</el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="page">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
              :current-page="currentPage" :page-sizes="pageSizes" :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>
          </div>
        </div>
      </div>
      <div class="wraper-hotword" v-show="isShowHotword">
        <div class="header-back">
          <el-button @click="goback" type="text">
            <返回</el-button> </div> <div class="content-wrap">
              <div style="height:30px;line-height: 30px">
                <span style="font-size: 14px;float:left;">趋势分布</span>
              </div>
              <div style="flex:1;border:1px solid #ccc;" id="myChartHotDetailSub1"></div>
              <div style="height:45px;line-height: 45px">
                <span style="font-size: 14px;float:left;">来源</span>
                <el-button style="width:100px;float:right;margin-top:3px;" @click="exportExcel('recordListHot')">导出
                </el-button>
              </div>
              <div style="flex:1;overflow-y: auto">
                <el-table class="fh-table" :data="tableDataHot" border height="100%" style="width: 100%;">
                  <el-table-column type="index" width="50" show-overflow-tooltip label="序号">
                  </el-table-column>
                  <el-table-column prop="callId" label="录音编号" width="120">
                  </el-table-column>
                  <el-table-column prop="callSTime" label="录音开始时间" width="160">
                    <template scope="scope">
                      <div>{{ scope.row.callSTime | filterCreatTime }}</div>
                    </template>
                  </el-table-column>
                  <el-table-column sortable prop="callTime" label="录音时长">
                    <template scope="scope">
                      <div>{{ scope.row.callTime | filterCallTime }}</div>
                    </template>
                  </el-table-column>
                  <el-table-column prop="sortName" label="业务小类"> </el-table-column>
                  <el-table-column label="操作" width="100">
                    <template scope="scope">
                      <el-button @click="showDetail(scope.row)" type="text">查看</el-button>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="page">
                <el-pagination @size-change="handleSizeChangeHot" @current-change="handleCurrentChangeHot"
                  :current-page="currentPageHot" :page-sizes="pageSizeHots" :page-size="pageSizeHot"
                  layout="total,sizes, prev, pager, next, jumper" :total="totalHot">
                </el-pagination>
              </div>
        </div>
      </div>
      <el-dialog class="single" title="录音播放页面" :visible.sync="recordDialogVisible"
        :close-on-click-modal="false" :close-on-press-escape="false">
        <div class="recordingplayWrap">
          <recordingplay ref="recordPlay" @onclose="recordPlayCloseHandler" @onminimize="recordPlayMinimizeHandler">
          </recordingplay>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
  import formatdate from '../../../../utils/formatdate'
  import dateComponent from '../dateComponent'
  import businessTree from '../businessTree'
  import recordingplay from '../../recordingPlay/recordingPlayResultScore'
  import bus from '../../../common/bus'
  import qs from 'qs'
  import global from '../../../../global'
  import commonUtil from '../../../../utils/commonUtil.js'
  const colorList = [
    '#1890FF',
    '#41D9C7',
    '#2FC25B',
    '#FACC14',
    '#E6965C',
    '#223273',
    '#7564CC',
    '#8543E0',
    '#5C8EE6',
    '#13C2C2',
    '#5CA3E6',
    '#3436C7',
    '#B381E6',
    '#F04864',
    '#D598D9',
  ]
  const currentBaseUrl = global.currentBaseUrl
  export default {
    name: 'operationalIndex',
    components: {
      dateComponent: dateComponent,
      businessTree: businessTree,
      recordingplay: recordingplay,
    },
    data() {
      return {
        isShowDetail: false,
        isShowOperation: false,
        isShowHotword: false,
        subjectClassId: '', //当前树节点
        subjectClassIdCopy: '', //当前树节点
        // 子组件获取time
        startTime: '',
        endTime: '',
        selectTimeType: '',
        // 业务分析detail
        recordDialogVisible: false,
        selectTab: '0',
        currentPage: 1, // 当前页码
        total: 0, // 记录总条数
        pageSize: 20, // 每页显示的记录条数
        pageSizes: [10, 15, 20, 25],
        tableData: [],
        // 热词detail
        currentPageHot: 1, // 当前页码
        totalHot: 0, // 记录总条数
        pageSizeHot: 20, // 每页显示的记录条数
        pageSizeHots: [10, 15, 20, 25],
        tableDataHot: [],
        keyword: '',
      }
    },
    mounted() {
      this.onSearch()
    },
    methods: {
      init() {
        let params = {
          businessType: this.subjectClassId,
          statisticsSize: this.selectTimeType,
          startTime: this.startTime,
          endTime: this.endTime,
        }
        if (this.subjectClassId) {
          this.initBusinessTrafficAnalysisData(params)
          this.initTrafficTrend(params)
          this.initHotWordsTrend(params)
        }
      },
      goback() {
        this.isShowDetail = false
        this.isShowOperation = false
        this.isShowHotword = false
        this.subjectClassId = this.subjectClassIdCopy
        this.keyword = ''
        this.selectTab = '0'
        this.currentPage = 1
        this.currentPageHot = 1
        this.pageSize = 20
        this.pageSizeHot = 20
      },
      getChildChangeDate(val) {
        let arr = val.split(',')
        this.startTime = arr[1]
        this.endTime = arr[2]
        this.selectTimeType = arr[0]
      },
      // 获取树当前选中节点
      saveSubjectClassId(val) {
        if (!this.subjectClassId) {
          this.subjectClassId = val
          this.init()
        }
        this.subjectClassId = val
      },
      //进入热词模块
      toHotWord() {
        this.$router.push({
          path: 'hotwordAnalysis',
          query: {
            id: '388fc81b9bdf11e9b216000c295685cd'
          },
        })
      },
      initBusinessTrafficAnalysisData(params) {
        this.axios
          .get(
            `${currentBaseUrl}/businessAnalysis/trees/${this.subjectClassId}`, {
              params,
            }
          )
          .then((res) => {
            let data = res.data
            if (data.code === 0) {
              let dataval = !data.data ? [] : data.data
              this.businessTrafficAnalysis(dataval)
            } else {
              this.$message.error(data.message)
            }
          })
          .catch((err) => console.log(err))
      },
      initTrafficTrend(params) {
        this.axios
          .get(`${currentBaseUrl}/businessAnalysis/trend`, {
            params
          }, global.jsonHeader)
          .then((res) => {
            let data = res.data
            if (data.code === 0) {
              let dataval = data.data == null ? [] : data.data
              this.trafficTrend(dataval)
            } else {
              this.$message.error(data.message)
            }
          })
          .catch((err) => console.log(err))
      },
      initHotWordsTrend(params) {
        this.axios
          .get(currentBaseUrl + '/businessAnalysis/categoryWord', {
            params
          })
          .then((res) => {
            let data = res.data
            if (data.code === 0) {
              let dataval = data.data == null ? [] : data.data
              this.hotWordsTrend(dataval)
            } else {
              this.$message.error(data.message)
            }
          })
          .catch((err) => console.log(err))
      },
      // 业务话务量分布
      businessTrafficAnalysis(data) {
        let {
          sortID,
          count,
          sortName
        } = data
        let children = data.children == null ? [] : data.children
        let _this = this
        let xAxisData = []
        let seriesData = []
        if (this.subjectClassId.indexOf('other') > 0) {
          xAxisData.push('其他')
          seriesData.push({
            value: data.otherCount,
            id: data.sortID + '_other',
          })
        } else {
          if (data.children) {
            children.forEach((item) => {
              xAxisData.push(item.sortName)
              seriesData.push({
                value: item.count,
                id: item.sortID,
              })
            })
            xAxisData.push('其他')
            seriesData.push({
              value: data.otherCount,
              id: data.sortID + '_other',
            })
          } else {
            xAxisData.push(sortName)
            seriesData.push({
              value: count,
              id: sortID,
            })
          }
        }
        let option = {
          color: colorList,
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              // 坐标轴指示器，坐标轴触发有效
              type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
            },
          },
          dataZoom: [{
            type: 'inside'
          }],
          toolbox: {
            show: true,
            right: 10,
            top: 0,
            itemSize: 18,
            feature: {
              saveAsImage: {
                show: true,
                icon: 'image://static/img/downLoad.png',
                name: '业务话务量分布',
              },
              myExcel: {
                show: true,
                title: '导出Excel',
                icon: 'image://static/img/excelReport.png',
                z: '999',
                left: 'center',
                onclick: () => {
                  this.exportExcel('businessTrafficAnalysis')
                },
              },
            },
          },
          grid: {
            left: '3%',
            right: '5%',
            bottom: '3%',
            containLabel: true,
          },
          xAxis: [{
            type: 'category',
            data: xAxisData,
            axisTick: {
              alignWithLabel: true,
            },
            axisLabel: {
              interval: 0,
              rotate: 40,
            },
          }, ],
          yAxis: [{
            type: 'value',
          }, ],
          series: [{
            type: 'bar',
            barWidth: '60%',
            label: {
              normal: {
                show: true,
                position: 'top',
              },
            },
            data: seriesData,
          }, ],
        }
        this.$nextTick(function () {
          document.oncontextmenu = function () {
            return false
          }
          let myChart = _this.$echarts.init(document.getElementById('myChart'))
          myChart.clear()
          myChart.setOption(option)
          // 查看详情
          myChart.on('click', function (params) {
            _this.subjectClassIdCopy = _this.subjectClassId
            _this.subjectClassId = params.data.id
            let paramesData = {
              businessType: params.data.id,
              statisticsSize: _this.selectTimeType,
              startTime: _this.startTime,
              endTime: _this.endTime,
            }
            _this.isShowDetail = true
            _this.isShowOperation = true
            _this.isShowHotword = false
            _this.initDetailTrafficTrend(paramesData)
            _this.initDetailHotWordsTrend(paramesData)
            _this.recordPlayCloseHandler()
          })
        })
      },
      // 话务量趋势
      trafficTrend(data) {
        let _this = this
        let xAxisData = []
        let seriesData = []
        data.forEach((item) => {
          xAxisData.push(item.dateKey)
          seriesData.push(item.count)
        })
        let interval = 0
        let len = xAxisData.length
        if (len > 20) {
          interval = parseInt(len / 20)
        } else {
          interval = 0
        }
        let option = {
          color: colorList,
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              // 坐标轴指示器，坐标轴触发有效
              type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
            },
          },
          dataZoom: [{
            type: 'inside'
          }],
          toolbox: {
            show: true,
            right: 10,
            top: 0,
            itemSize: 18,
            feature: {
              saveAsImage: {
                show: true,
                icon: 'image://static/img/downLoad.png',
                name: '话务量趋势',
              },
              myExcel: {
                show: true,
                title: '导出Excel',
                icon: 'image://static/img/excelReport.png',
                z: '999',
                left: 'center',
                onclick: () => {
                  this.exportExcel('trafficTrend')
                },
              },
            },
          },
          grid: {
            left: '3%',
            right: '5%',
            bottom: '3%',
            containLabel: true,
          },
          xAxis: {
            type: 'category',
            data: xAxisData,
            axisLabel: {
              interval: interval,
              rotate: 40,
            },
          },
          yAxis: {
            type: 'value',
          },
          series: [{
            data: seriesData,
            type: 'line',
          }, ],
        }
        this.$nextTick(function () {
          document.oncontextmenu = function () {
            return false
          }
          let myChart = _this.$echarts.init(document.getElementById('myChartSub1'))
          myChart.clear()
          myChart.setOption(option)
        })
      },
      // 业务热词
      hotWordsTrend(data) {
        let _this = this
        let seriesData = []
        data.forEach((item) => {
          seriesData.push({
            word: item.word,
            value: item.value,
            symbolSize: 100,
          })
        })
        let option = {
          color: colorList,
          dataZoom: [{
            type: 'inside'
          }],
          toolbox: {
            show: true,
            right: 10,
            top: 0,
            itemSize: 18,
            feature: {
              saveAsImage: {
                show: true,
                icon: 'image://static/img/downLoad.png',
                name: '业务热词',
              },
              myExcel: {
                show: true,
                title: '导出Excel',
                icon: 'image://static/img/excelReport.png',
                z: '999',
                left: 'center',
                onclick: () => {
                  this.exportExcel('hotWordsTrend')
                },
              },
            },
          },
          tooltip: {
            trigger: 'item',
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true,
          },
          xAxis: {
            splitLine: {
              lineStyle: {
                type: 'dashed',
              },
            },
            axisLabel: {
              show: false,
            },
          },
          yAxis: {
            name: '匹配频次',
            nameLocation: 'middle',
            nameTextStyle: {
              color: '#ccc',
            },
            splitLine: {
              lineStyle: {
                type: 'dashed',
              },
            },
          },
          series: [{
            label: {
              show: true,
              formatter: function (param) {
                return param.data.word
              },
            },
            data: seriesData,
            type: 'scatter',
          }, ],
        }
        this.$nextTick(function () {
          document.oncontextmenu = function () {
            return false
          }
          let myChart = _this.$echarts.init(document.getElementById('myChartSub2'))
          myChart.clear()
          myChart.setOption(option)
          // 查看详情
          myChart.on('click', function (params) {
            _this.subjectClassIdCopy = _this.subjectClassId
            let {
              word
            } = params.data
            _this.keyword = word
            _this.isShowDetail = true
            _this.isShowOperation = false
            _this.isShowHotword = true
            _this.hotDetailTrendData()
            _this.getHotCallData()
            _this.recordPlayCloseHandler()
          })
        })
      },
      /*
       *业务分析detail
       * */
      initDetailTrafficTrend(params) {
        this.axios
          .get(`${currentBaseUrl}/businessAnalysis/trend`, {
            params
          }, global.jsonHeader)
          .then((res) => {
            let data = res.data
            if (data.code === 0) {
              this.detailTrafficTrend(data.data)
            } else {
              this.$message.error(data.message)
            }
          })
          .catch((err) => console.log(err))
      },
      initDetailHotWordsTrend(params) {
        this.axios
          .get(currentBaseUrl + '/businessAnalysis/categoryWord', {
            params
          })
          .then((res) => {
            let data = res.data
            if (data.code === 0) {
              this.detailHotWordsTrend(data.data)
            } else {
              this.$message.error(data.message)
            }
          })
          .catch((err) => console.log(err))
      },
      changeTab(val) {
        if (val == 0) {
          let params = {
            businessType: this.subjectClassId,
            statisticsSize: this.selectTimeType,
            startTime: this.startTime,
            endTime: this.endTime,
          }
          this.initDetailTrafficTrend(params)
          this.initDetailHotWordsTrend(params)
        } else {
          this.getCallData()
        }
      },
      recordPlayCloseHandler: function () {
        this.recordDialogVisible = false
        this.$store.commit('setPlayerInfo', {
          exist: false,
          extendClassName: '',
          maxCallback: null,
        })
        bus.$emit('closeToplayer')
      },
      recordPlayMinimizeHandler: function () {
        let self = this
        this.recordDialogVisible = false // 关闭弹窗
        this.$store.commit('setPlayerInfo', {
          isMaximization: false, // 播放器最小化
          exist: true, // 菜单出现播放器
          maxCallback: function () {
            self.recordDialogVisible = true
            self.$store.commit('setPlayerInfo', {
              isMaximization: true,
            })
          },
        })
      },
      // 分页
      handleSizeChange(val) {
        this.pageSize = val
        this.getCallData()
      },
      handleCurrentChange(val) {
        this.currentPage = val
        this.getCallData()
      },
      // 调到录音播放页
      showDetail(row) {
        let {
          callId,
          isSampled,
          callSTime,
          callNo,
          mblNo,
          recordFileURL
        } = row
        let obj = {}
        obj.from = 'recordingpoll'
        obj.callId = callId
        obj.recordFileURL = recordFileURL
        obj.isSampled = isSampled
        obj.callSTime = callSTime
        obj.mblNo = mblNo ? mblNo : ''
        obj.callNo = callNo ? callNo : ''
        this.$store.commit('setRecordingPlayPage', obj)
        this.recordDialogVisible = true
        this.$store.commit('setPlayerInfo', {
          isMaximization: true,
          exist: true,
          extendClassName: 'recordingPlay',
        })
        this.$refs.recordPlay && this.$refs.recordPlay.init()
      },
      // 录音列表
      getCallData() {
        let params = {
          businessType: this.subjectClassId,
          statisticsSize: this.selectTimeType,
          startTime: this.startTime,
          endTime: this.endTime,
          currentPage: this.currentPage,
          pageSize: this.pageSize,
        }
        this.axios
          .get(`${currentBaseUrl}/businessAnalysis/${this.subjectClassId}/records`, {
            params,
          })
          .then((res) => {
            let data = res.data
            if (data.success) {
              this.tableData = data.results == null ? [] : data.results
              this.total = data.count
            } else {}
          })
          .catch((err) => console.log(err))
      },
      // 话务量趋势
      detailTrafficTrend(data) {
        let _this = this
        let xAxisData = data.dates
        let seriesData = data.data.data
        let interval = 0
        let len = xAxisData.length
        if (len > 20) {
          interval = parseInt(len / 20)
        } else {
          interval = 0
        }
        let option = {
          color: colorList,
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              // 坐标轴指示器，坐标轴触发有效
              type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
            },
          },
          dataZoom: [{
            type: 'inside'
          }],
          toolbox: {
            show: true,
            right: 10,
            top: 0,
            itemSize: 18,
            feature: {
              saveAsImage: {
                show: true,
                icon: 'image://static/img/downLoad.png',
                name: '话务量趋势',
              },
              myExcel: {
                show: true,
                title: '导出Excel',
                icon: 'image://static/img/excelReport.png',
                z: '999',
                left: 'center',
                onclick: () => {
                  this.exportExcel('detailTrafficTrend')
                },
              },
            },
          },
          grid: {
            left: '3%',
            right: '5%',
            bottom: '3%',
            containLabel: true,
          },
          xAxis: {
            type: 'category',
            data: xAxisData,
            axisLabel: {
              interval: interval,
              rotate: 40,
            },
          },
          yAxis: {
            type: 'value',
          },
          series: [{
            data: seriesData,
            type: 'line',
          }, ],
        }
        this.$nextTick(function () {
          document.oncontextmenu = function () {
            return false
          }
          let myChart = _this.$echarts.init(document.getElementById('myChartDetailSub1'))
          myChart.clear()
          myChart.setOption(option)
        })
      },
      // 业务热词
      detailHotWordsTrend(data) {
        let _this = this
        let seriesData = []
        data.forEach((item) => {
          seriesData.push({
            word: item.word,
            value: item.value,
            symbolSize: 100,
          })
        })
        let option = {
          color: colorList,
          dataZoom: [{
            type: 'inside'
          }],
          toolbox: {
            show: true,
            right: 10,
            top: 0,
            itemSize: 18,
            feature: {
              saveAsImage: {
                show: true,
                icon: 'image://static/img/downLoad.png',
                name: '业务热词',
              },
              myExcel: {
                show: true,
                title: '导出Excel',
                icon: 'image://static/img/excelReport.png',
                z: '999',
                left: 'center',
                onclick: () => {
                  this.exportExcel('detailHotWordsTrend')
                },
              },
            },
          },
          tooltip: {
            trigger: 'item',
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true,
          },
          xAxis: {
            splitLine: {
              lineStyle: {
                type: 'dashed',
              },
            },
            axisLabel: {
              show: false,
            },
          },
          yAxis: {
            name: '匹配频次',
            nameLocation: 'middle',
            nameTextStyle: {
              color: '#ccc',
            },
            splitLine: {
              lineStyle: {
                type: 'dashed',
              },
            },
          },
          series: [{
            label: {
              show: true,
              formatter: function (param) {
                return param.data.word
              },
            },
            data: seriesData,
            type: 'scatter',
          }, ],
        }
        this.$nextTick(function () {
          document.oncontextmenu = function () {
            return false
          }
          let myChart = _this.$echarts.init(document.getElementById('myChartDetailSub2'))
          myChart.clear()
          myChart.setOption(option)
          // 查看详情
          myChart.on('click', function (params) {
            let {
              word
            } = params.data
            _this.keyword = word
            _this.isShowDetail = true
            _this.isShowOperation = false
            _this.isShowHotword = true
            _this.hotDetailTrendData()
            _this.getHotCallData()
            _this.recordPlayCloseHandler()
          })
        })
      },
      /*
       * 热词detail
       * */
      // 分页
      handleSizeChangeHot(val) {
        this.pageSizeHot = val
        this.getHotCallData()
      },
      handleCurrentChangeHot(val) {
        this.currentPageHot = val
        this.getHotCallData()
      },
      hotDetailTrendData() {
        let params = {
          businessType: this.subjectClassId,
          startTime: this.startTime,
          endTime: this.endTime,
          statisticsSize: this.selectTimeType,
          type: 0,
          keyword: this.keyword,
        }
        this.axios
          .post(`${currentBaseUrl}/hotWordAnalysis/trend`, qs.stringify(params))
          .then((res) => {
            let {
              code,
              data,
              message
            } = res.data
            if (code == 0) {
              this.hotDetailTrend(data)
            } else {
              this.$message.error(message)
            }
          })
          .catch((err) => console.log(err))
      },
      // 热词详情趋势
      hotDetailTrend(dataval) {
        let {
          data,
          dates
        } = dataval
        let xAxisData = dates
        let seriesData = data
        let _this = this
        let option = {
          color: colorList,
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              // 坐标轴指示器，坐标轴触发有效
              type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
            },
          },
          dataZoom: [{
            type: 'inside'
          }],
          toolbox: {
            show: true,
            right: 0,
            top: 10,
            itemSize: 18,
            feature: {
              saveAsImage: {
                show: true,
                icon: 'image://static/img/downLoad.png',
                name: '热词趋势分析',
              },
              myExcel: {
                show: true,
                title: '导出Excel',
                icon: 'image://static/img/excelReport.png',
                z: '999',
                left: 'center',
                onclick: () => {
                  this.exportExcel('hotDetailTrend')
                },
              },
            },
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true,
          },
          xAxis: {
            type: 'category',
            data: xAxisData,
          },
          yAxis: {
            type: 'value',
          },
          series: [{
            data: seriesData,
            type: 'line',
          }, ],
        }
        this.$nextTick(function () {
          document.oncontextmenu = function () {
            return false
          }
          let myChart = _this.$echarts.init(document.getElementById('myChartHotDetailSub1'))
          myChart.clear()
          myChart.setOption(option)
        })
      },
      // 热词录音列表
      getHotCallData() {
        let params = {
          businessType: this.subjectClassId,
          startTime: this.startTime,
          endTime: this.endTime,
          statisticsSize: this.selectTimeType,
          type: 0,
          keyword: this.keyword,
          currentPage: this.currentPageHot,
          pageSize: this.pageSizeHot,
        }
        this.axios
          .post(`${currentBaseUrl}/hotWordAnalysis/records`, qs.stringify(params))
          .then((res) => {
            let {
              success,
              results,
              count,
              message
            } = res.data
            if (success) {
              this.tableDataHot = results == null ? [] : results
              this.totalHot = count
            } else {
              this.$message.error(message)
            }
          })
          .catch((err) => console.log(err))
      },
      // 导出
      exportExcel(val) {
        let url = ''
        if (val == 'hotDetailTrend' || val == 'recordListHot') {
          let paramsHotTrend = {
            businessType: this.subjectClassId,
            startTime: this.startTime,
            endTime: this.endTime,
            statisticsSize: this.selectTimeType,
            type: 0,
            keyword: this.keyword,
          }
          url =
            val == 'hotDetailTrend' ?
            currentBaseUrl + '/hotWordAnalysis/trend/excel' :
            currentBaseUrl + '/hotWordAnalysis/records/excel'
          console.log(paramsHotTrend)
          commonUtil.doExport(url, paramsHotTrend, global.jsonHeader)
        } else {
          let params = {
            businessType: this.subjectClassId,
            statisticsSize: this.selectTimeType,
            startTime: this.startTime,
            endTime: this.endTime,
          }
          if (val == 'businessTrafficAnalysis') {
            url = currentBaseUrl + '/businessAnalysis/trees/excel'
          } else if (val == 'trafficTrend' || val == 'detailTrafficTrend') {
            url = currentBaseUrl + '/businessAnalysis/trend/excel'
          } else if (val == 'hotWordsTrend' || val == 'detailHotWordsTrend') {
            url = currentBaseUrl + '/businessAnalysis/categoryWord/excel'
          } else if (val == 'callList') {
            url = currentBaseUrl + '/businessAnalysis/records/excel'
          }
          console.log(params)
          commonUtil.doExport(url, params, global.jsonHeader)
        }
      },
      // 查询
      onSearch() {
        let start = this.getTime(this.startTime)
        let end = this.getTime(this.endTime)
        if (start > end) {
          this.$message.warning('请输入合理的时间范围')
          return
        }
        this.init()
      },
      // 获取时间戳
      getTime(val) {
        let newdata = new Date(val)
        let time = newdata.getTime()
        return time
      },
    },
    filters: {
      filterCreatTime(val) {
        if (val) {
          return formatdate.formatDate(val)
        }
      },
      filterCallTime(val) {
        if (val) {
          let time = parseInt(val / 1000)
          return time
        }
      },
    },
  }

</script>

<style scoped lang="less">
  .operationalIndexWrap {
    width: 100%;
    height: 100%;

    .operationalDetailWrap {
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      position: relative;
      overflow-x: hidden;

      .wraper-operation {
        width: 100%;
        height: 100%;
        position: relative;
        padding: 0 20px 10px;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;

        .header-title {
          height: 50px;
          display: flex;
          align-items: center;
        }

        .header-back {
          height: 40px;
          margin: 10px 0;
        }

        .header-operate {
          display: flex;
          height: 40px;
          margin-bottom: 10px;
        }

        .content-wrap {
          .el-table.fh-table {
            height: 100% !important;
          }

          flex: 1;
          display: flex;
          flex-direction: column;

          .content-reports-block {
            flex: 1;
            display: flex;
            flex-direction: column;
            margin: 5px 0;

            .sub-block {
              flex: 1;
            }
          }

          .page {
            height: 40px;
            display: flex;
            flex-direction: row-reverse;
            margin-top: 20px;
          }
        }
      }

      .wraper-hotword {
        width: 100%;
        height: 100%;
        position: relative;
        padding: 0 20px 10px;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;

        .header-title {
          height: 50px;
          display: flex;
          align-items: center;
        }

        .header-back {
          height: 40px;
          margin: 10px 0;
        }

        .header-operate {
          height: 40px;
          margin-bottom: 10px;
          display: flex;
        }

        .content-wrap {
          flex: 1;
          display: flex;
          flex-direction: column;

          .el-table.fh-table {
            height: 100% !important;
          }

          .content-reports-block {
            flex: 1;
            display: flex;
            flex-direction: column;
            margin: 5px 0;

            .sub-block {
              flex: 1;
            }
          }

          .page {
            height: 40px;
            display: flex;
            flex-direction: row-reverse;
            margin-top: 20px;
          }
        }
      }

      .recordingplayWrap {
        width: 100%;
        height: 100%;
        overflow-y: auto;
        position: relative;
      }
    }

    .operationalIndex {
      width: 100%;
      height: 100%;
      position: relative;
      padding: 0 20px 10px;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;

      .header-title {
        height: 50px;
        display: flex;
        align-items: center;
      }

      .header-search {
        height: 100px;
        display: flex;
        align-items: center;
        border: 1px solid #ccc;
        padding: 0 20px;
        font-size: 14px;
        box-sizing: border-box;
      }

      .content-chart {
        flex: 1;
        overflow-y: auto;
        padding-right: 10px;
        box-sizing: border-box;

        .content-chart-block {
          height: 450px;
          display: flex;
          margin: 10px 0 0;

          .content-chart-block-sub {
            display: flex;
            flex: 1;
            flex-direction: column;
            margin-right: 10px;

            .title {
              font-size: 14px;
              color: #000;
              font-weight: normal;
              float: left;
            }

            .sub-block {
              flex: 1;
              border: 1px solid #ccc;
            }
          }

          .header {
            width: 100%;
            height: 40px;
            line-height: 40px;
            text-align: center;
          }
        }
      }
    }
  }

</style>
<style lang="less">
  .operationalDetailWrap {
    .single {
      &.el-dialog__wrapper {
        position: fixed;
        top: 106px;
        left: 20px;
        right: 20px;
        bottom: 12px;

        .el-dialog {
          width: 100%;
          height: 100%;
          margin: 0 !important;
        }
      }

      .el-dialog__header {
        display: none;
      }

      .el-dialog__body {
        padding: 0px 0px;
        box-sizing: border-box;
        width: 100%;
        height: 100%;
      }
    }
  }

</style>
