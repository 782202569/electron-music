<template>
  <div style="display: inline-block">
    <span style="margin:0 10px 0 20px;">统计粒度</span>
    <el-select
      @change="changeSelect"
      style="width:100px;margin-right:10px;"
      v-model="selectTimeType"
      placeholder="请选择"
    >
      <el-option
        v-for="item in dateOptions"
        :key="item.value"
        :label="item.label"
        :value="item.value"
      />
    </el-select>

    <span style="margin-right: 10px;">录音时间</span>
    <div style="display: inline-block">
      <high-datepicker
        v-model="startTime"
        :clearable="false"
        :picker-options="{}"
        placeholder="选择日期"
        @change="changeStartTime($event, selectTimeType)"
        :type="selectTimeType"
      />
      -
      <high-datepicker
        v-model="endTime"
        :picker-options="{}"
        :clearable="false"
        placeholder="选择日期"
        @change="changeEndTime($event, selectTimeType)"
        :type="selectTimeType"
      />
    </div>
  </div>
</template>

<script>
import formatdate from '../../../utils/formatdate'
import highDatepicker from './highDatepicker'
export default {
  name: 'dateComponent',
  components: {
    highDatepicker,
  },
  data() {
    return {
      selectTimeType: 'date',
      dateOptions: [
        {
          value: 'date',
          label: '日',
        },
        {
          value: 'week',
          label: '周',
        },
        {
          value: 'month',
          label: '月',
        },
        {
          value: 'quarter',
          label: '季',
        },
      ],
      startTime: '',
      endTime: '',
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.startTime = this.initDefaultMonth()[0]
      this.endTime = this.initDefaultMonth()[1]
      let childData = [this.selectTimeType, this.startTime, this.endTime].toString()
      this.$emit('changeDate', childData)
    },
    reset() {
      this.startTime = ''
      this.endTime = ''
    },
    changeSelect(val) {
      this.reset()
      if (val == 'date' || val == 'week') {
        this.startTime = this.initDefaultMonth()[0]
        this.endTime = this.initDefaultMonth()[1]
      } else if (val == 'month' || val == 'quarter') {
        this.startTime = this.initDefaultYear()[0]
        this.endTime = this.initDefaultYear()[1]
      }
      let childData = [this.selectTimeType, this.startTime, this.endTime].toString()
      this.$emit('changeDate', childData)
    },
    changeStartTime(e, val) {
      this.startTime = e ? formatdate.formatDateWithoutTimes(e) : ''
      if (val == 'date') {
        this.startTime = this.formatDate(e)
      }
      //获取当前周的第一天
      if (val === 'week') {
        this.startTime = this.getWeekStartAndEnd(this.startTime).weekStart
      }
      //获取当前周的第一天 || 获取季度的第一天
      if (val === 'month' || val == 'quarter') {
        this.startTime = this.getCurrentMonthFirst(this.startTime)
      }
      let childData = [this.selectTimeType, this.startTime, this.endTime].toString()
      this.$emit('changeDate', childData)
    },
    changeEndTime(e, val) {
      this.endTime = e ? formatdate.formatDateWithoutTimes(e) : ''
      if (val == 'date') {
        this.startTime = this.formatDate(e)
      }
      //获取当前周的最后一天
      if (val === 'week') {
        this.endTime = this.getWeekStartAndEnd(this.endTime).weekEnd
      }
      //获取当前月的最后一天
      if (val === 'month') {
        this.endTime = this.getCurrentMonthLast(this.endTime)
      }
      //获取季度最后一天
      if (val == 'quarter') {
        this.endTime = this.getQuarterLast(this.endTime)
      }
      let childData = [this.selectTimeType, this.startTime, this.endTime].toString()
      this.$emit('changeDate', childData)
    },
    getWeekStartDate(now) {
      let nowDayOfWeek = now.getDay() //今天本周的第几天
      let nowDay = now.getDate()
      let nowMonth = now.getMonth()
      let nowYear = now.getFullYear()
      let weekStartDate = new Date(
        nowYear,
        nowMonth,
        parseInt(nowDay - (nowDayOfWeek - 1))
      )
      return formatdate.formatDateWithoutTimes(weekStartDate)
    },
    //默认月
    initDefaultMonth() {
      let fromData = ''
      let toform = ''
      let now = new Date()
      now.setDate(1)
      fromData = formatdate.formatDateWithoutTimes(now)
      let currentMonth = now.getMonth()
      let nextMonth = ++currentMonth
      let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
      let oneDay = 1
      toform = formatdate.formatDateWithoutTimes(new Date(nextMonthFirstDay - oneDay))
      if (this.selectTimeType === 'week') {
        fromData = this.getWeekStartDate(now)
        let weekLast = this.getWeekStartDate(new Date(nextMonthFirstDay - oneDay))
        toform = this.getWeekStartAndEnd(weekLast).weekEnd
      }
      if (this.selectTimeType === 'month') {
        //获取月的最后一天
        toform = this.getCurrentMonthLast(toform)
      }
      if (this.selectTimeType === 'quarter') {
        //获取季度的最后一天
        toform = this.getQuarterLast(toform)
      }
      return [fromData, toform]
    },
    //默认年
    initDefaultYear() {
      let fromData = ''
      let toform = ''
      let now = new Date()
      let nowYear = now.getFullYear()
      now.setFullYear(nowYear)
      now.setMonth(0)
      now.setDate(1)
      fromData = formatdate.formatDateWithoutTimes(now)
      let endnow = new Date()
      endnow.setFullYear(nowYear)
      this.selectTimeType == 'quarter' ? endnow.setMonth(9) : endnow.setMonth(11)
      endnow.setDate(1)
      toform = formatdate.formatDateWithoutTimes(endnow)
      if (this.selectTimeType === 'month') {
        //获取月的最后一天
        toform = this.getCurrentMonthLast(toform)
      }
      if (this.selectTimeType === 'quarter') {
        //获取季度的最后一天
        toform = this.getQuarterLast(toform)
      }
      return [fromData, toform]
    },
    getWeekStartAndEnd(val) {
      let now = ''
      if (val) {
        now = new Date(val)
      } else {
        now = new Date()
      }
      let nowDayOfWeek = now.getDay() // 本周的第几
      let nowDay = now.getDate() // 当前日
      let nowMonth = now.getMonth() // 当前月
      let nowYear = now.getFullYear() // 当前年

      let weekStart = this.getWeekStart(nowYear, nowMonth, nowDay, nowDayOfWeek)
      let weekEnd = this.getWeekEnd(nowYear, nowMonth, nowDay, nowDayOfWeek)

      let weekFormat = {
        weekStart: weekStart,
        weekEnd: weekEnd,
      }
      return weekFormat
    },
    formatDate(date) {
      let myyear = date.getFullYear()
      let mymonth = date.getMonth() + 1
      let myweekday = date.getDate()
      if (mymonth < 10) {
        mymonth = '0' + mymonth
      }
      if (myweekday < 10) {
        myweekday = '0' + myweekday
      }
      return `${myyear}-${mymonth}-${myweekday}`
    },
    // 获得某一周的开始日期
    getWeekStart(nowYear, nowMonth, nowDay, nowDayOfWeek) {
      let weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek)
      return this.formatDate(weekStartDate)
    },
    // 获得某一周的结束日期
    getWeekEnd(nowYear, nowMonth, nowDay, nowDayOfWeek) {
      let weekEndDate = new Date(nowYear, nowMonth, nowDay + (6 - nowDayOfWeek))
      return this.formatDate(weekEndDate)
    },
    //获取当前月的最后一天
    getCurrentMonthLast(val) {
      let date = new Date(val)
      let currentMonth = date.getMonth()
      let nextMonth = ++currentMonth
      let nextMonthFirstDay = new Date(date.getFullYear(), nextMonth, 1)
      let oneDay = 1000 * 60 * 60 * 24
      return this.formatDate(new Date(nextMonthFirstDay - oneDay))
    },
    // 获取当前月的第一天
    getCurrentMonthFirst(val) {
      let date = new Date(val)
      date.setDate(1)
      return this.formatDate(date)
    },
    //获取季度的最后一天
    getQuarterLast(val) {
      let now = new Date(val)
      let mounth = now.getMonth() + 3
      let date = `${now.getFullYear()}-${mounth}-${now.getDate()}`
      return this.getCurrentMonthLast(date)
    },
  },
}
</script>

<style scoped></style>
