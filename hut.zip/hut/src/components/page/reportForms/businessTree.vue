<template>
  <div class="business-tree-wrap" v-click-outside="handleOutSide">
    <div id="treeSpan" v-show="isHideTree" @click.native.stop>
      <el-tree
        :data="data"
        :props="defaultProps"
        :expand-on-click-node="false"
        :check-on-click-node="true"
        :highlight-current="true"
        @node-click="handleChangeNode"
        ref="keyWordsMenu"
        node-key="id"
        :check-strictly="true"
        @node-expand="nodeCase(data)"
      >
      </el-tree>
    </div>
    <el-tooltip placement="top" disabled>
      <div slot="content">{{ treeValue }}</div>
      <div @click="deopShow" style="display: inline-block;">
        <el-input
          v-model="treeValue"
          ref="content"
          class="newSetall"
          style="width: 200px;cursor: pointer;"
        ></el-input>
      </div>
    </el-tooltip>
    <div v-show="isShowTree" class="treeCell" @click.native.stop>
      <ul>
        <li
          @click="changActive(index, item.label)"
          class="newSetcss"
          v-for="(item, index) in options"
          :key="index"
        >
          {{ item.label }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import $ from 'jquery'
import global from '../../../global'
const currentBaseUrl = global.currentBaseUrl
export default {
  name: 'businessTree',
  data() {
    return {
      isHideTree: false,
      isShowTree: false,
      data: [],
      defaultProps: {
        children: 'children',
        label: 'label',
      },
      treeValue: '',
      topValue: '',
      ghlgood: [],
      options: [],
      datawer: [],
    }
  },
  created() {
    this.getTreelist()
  },
  methods: {
    // 获取树列表信息
    getTreelist: function() {
      this.axios.post(currentBaseUrl + '/thematicView/getClassTree.do').then((res) => {
        ;(this.options = res.data.options),
          (this.datawer = res.data.data),
          (this.subjectClassId = res.data.data[0][0].subjectClassId)
        this.handleChangeNode()
      })
    },
    // 树节点被点击
    handleChangeNode: function() {
      let regions = this.$refs.keyWordsMenu.getCheckedNodes()
      let arr = []
      let stringSize = ''
      let subjectClassId = ''
      if (this.$refs.keyWordsMenu.getCurrentNode() == null) {
        this.treeValue = this.options[0].label
        this.topValue = this.treeValue
        subjectClassId = this.datawer[0][0].subjectClassId
      } else {
        if (this.$refs.keyWordsMenu.getCurrentNode().name > 2) {
          arr.push('...')
        }
        for (let i = 0; i < regions.length; i++) {
          arr.push(regions[i].label)
        }
        for (let y = 0; y < this.ghlgood.length; y++) {
          if (
            regions[0].text == this.ghlgood[y].text &&
            regions[0].label != this.ghlgood[y].label
          ) {
            arr.unshift(this.ghlgood[y].label)
          }
        }
        stringSize = arr.join('/')
        if (this.treeValue.indexOf(stringSize) != -1) {
          this.treeValue = this.treeValue
        } else {
          this.treeValue = this.treeValue + '/' + stringSize
        }
        this.topValue = this.treeValue
        subjectClassId = this.$refs.keyWordsMenu.getCurrentNode().subjectClassId
      }
      this.isShowTree = false
      this.isHideTree = false
      this.$emit('saveSubjectClassId', subjectClassId)
    },
    nodeCase(index) {
      this.ghlgood = index
    },
    changActive: function(index, flag) {
      $('.treeCell ul li').removeClass('featureActive')
      $(event.target).addClass('featureActive')
      this.data = this.datawer[index]
      this.treeValue = ''
      this.$refs.keyWordsMenu.setCheckedKeys([])
      this.treeValue = flag
      this.isHideTree = true
    },
    deopShow: function(e) {
      this.$refs.content.blur()
      this.$refs.keyWordsMenu.setCheckedKeys([])
      e.stopPropagation()
      if (this.isShowTree == false) {
        this.isShowTree = true
      } else {
        this.isShowTree = false
        this.isHideTree = false
      }
    },
    handleOutSide() {
      this.isShowTree = false
      this.isHideTree = false
    },
  },
  directives: {
    'click-outside': {
      bind: function(el, binding, vNode) {
        const bubble = binding.modifiers.bubble
        const handler = (e) => {
          if (bubble || (!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },
      unbind: function(el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      },
    },
  },
}
</script>

<style scoped lang="less">
.business-tree-wrap {
  display: inline-block;
  position: relative;
  .treeCell {
    width: 200px;
    height: 200px;
    border: 1px solid #e4e7ed;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    border-radius: 2px;
    position: absolute;
    top: 84%;
    z-index: 3000;
    background: #fff;
    overflow: hidden;
    overflow-y: auto;
  }
  .featureActive {
    color: #409eff;
  }
}
</style>

<style lang="less">
.business-tree-wrap {
  .newSetcss {
    font-size: 14px;
    padding: 8px 20px;
    position: relative;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #606266;
    height: 34px;
    line-height: 1.5;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    cursor: pointer;
    outline: 0;
    list-style-type: none;
  }
  .newSetcss:after {
    font-family: element-icons;
    content: '\E604';
    font-size: 14px;
    color: #bfcbd9;
    position: absolute;
    right: 15px;
    top: 10px;
  }
  .newSetall:after {
    font-family: element-icons;
    content: '\E603';
    font-size: 14px;
    color: #bfcbd9;
    position: absolute;
    right: 15px;
    top: 10px;
  }
  #treeSpan .el-tree {
    position: absolute;
    left: 200px;
    width: 200px;
    height: 194px;
    border: 1px solid #e4e7ed;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    border-radius: 2px;
    position: absolute;
    top: 84%;
    z-index: 3000;
    background: #fff;
    padding-top: 6px;
    overflow: hidden;
    overflow-y: auto;
  }
  .newSetall {
    input.el-input__inner {
      color: #fff;
    }
    input.el-input__inner::first-line {
      color: #333;
    }
  }
}
</style>
