<!--

质检校准会打分 质检主管，质检员 role 区分

质检主管：标准成绩和校准 用activeName 判断  first 标准  second 校准
质检员：标准成绩和校准 用activeName 判断  first 校准  second 标准

标准和校准 公用模版，根据不同形态获取不同情况下的分数详情

isCreator 是否可以标准评分的标识 0 创建者
-->
<template>
  <div class="recordingPlayContainer">
    <div class="controller_btns">
      <div class="controller_btn" @click="minimizePage">
        <i class="el-icon-minus"></i>
      </div>
      <div class="controller_btn" @click="closePage"><i class="el-icon-close"></i></div>
    </div>
    <el-row>
      <el-col :span="spanFirst">
        <div class="leftContainer">
          <div class="info-base">
            <el-tabs type="border-card">
              <el-tab-pane label="基本信息">
                <div class="infoContent">
                  <div class="info_item">
                    <label>录音编号:</label>
                    <span>{{ esResultModel.callId }}</span>
                  </div>
                  <div class="info_item">
                    <label>开始时间:</label>
                    <span>{{ esResultModel.callSTime | timeFormat }}</span>
                  </div>
                  <div class="info_item">
                    <label>通话时长:</label>
                    <span>{{ esResultModel.callTime / 1000 + '秒' }}</span>
                  </div>
                  <div class="borderRight">
                    <label>情绪标签:</label>
                    <span
                      v-if="
                        esResultModel.emotionLabel != '' &&
                          esResultModel.emotionLabel != null &&
                          esResultModel.emotionLabel.indexOf('积极') != -1
                      "
                      class="borderPositive"
                      >{{ esResultModel.emotionLabel }}</span
                    >
                    <span
                      v-if="
                        esResultModel.emotionLabel != '' &&
                          esResultModel.emotionLabel != null &&
                          esResultModel.emotionLabel.indexOf('消极') != -1
                      "
                      class="borderNegative"
                      >{{ esResultModel.emotionLabel }}</span
                    >
                  </div>
                  <div class="borderLeft">
                    <label>关键词标签:</label>
                    <span
                      v-if="esResultModel.labelContent"
                      class="borderBlue"
                      v-for="(list, indexOne) in esResultModel.labelContent &&
                        esResultModel.labelContent.split(',')"
                      >{{ list }}</span
                    >
                  </div>
                </div>
                <div class="infoContent">
                  <div class="info_item">
                    <label>坐席工号:</label>
                    <span>{{ esResultModel.seatNo }}</span>
                  </div>
                  <div class="info_item">
                    <label>坐席姓名:</label>
                    <span>{{ esResultModel.seatName }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属角色:</label>
                    <span>{{
                      aclOperVo.roleNames != null ? aclOperVo.roleNames.join(',') : ''
                    }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属部门:</label>
                    <span>{{ aclOperVo.deptName }}</span>
                  </div>
                  <div class="info_item" style="width:100%;">
                    <label>坐席星级:</label>
                    <span>
                      <el-rate
                        v-model="esResultModel.seatStar"
                        disabled
                        text-color="#ff9900"
                      >
                      </el-rate
                    ></span>
                  </div>
                  <div class="info_item agentLabel">
                    <label>坐席标签:</label>
                    <el-tag
                      :type="color[index % 4]"
                      v-if="item.trim()"
                      v-for="(item, index) in serviceLabels"
                      :key="item"
                      >{{ item }}
                    </el-tag>
                    <el-tag v-if="!serviceLabels || serviceLabels.length == 0"
                      >暂无标签</el-tag
                    >
                  </div>
                </div>
                <div class="infoContent infoContent-kehuInfo">
                  <div class="info_item">
                    <label>客户姓名:</label>
                    <span>{{ esResultModel.customerName }}</span>
                  </div>
                  <div class="info_item">
                    <label>账号:</label>
                    <span>{{ esResultModel.customerNo }}</span>
                  </div>
                  <div class="info_item">
                    <label>证件信息:</label>
                    <span>{{ esResultModel.certType }}</span>
                  </div>
                  <div class="info_item">
                    <label>证件号:</label>
                    <span>{{ esResultModel.certNo }}</span>
                  </div>
                  <div class="info_item agentLabel">
                    <label>客户标签:</label>
                    <el-tag
                      :type="color[index % 4]"
                      v-for="(item, index) in customInfoModel"
                      :key="item"
                      class="customLabel"
                      >{{ item }}
                    </el-tag>
                    <el-tag v-if="!customInfoModel || customInfoModel.length === 0"
                      >暂无标签</el-tag
                    >
                  </div>
                  <div class="tagWrap" v-if="caseTag.length > 0">
                    <el-tag v-for="item in caseTag">{{ item }}</el-tag>
                  </div>
                  <div class="btnWrap">
                    <el-button
                      v-if="
                        (isCreator === '0' && roleCodeId.includes('qa')) ||
                          (isCreator === '1' && roleCodeId.includes('qa'))
                      "
                      @click="addCase_btn"
                      >添加案例
                    </el-button>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </el-col>
      <el-col :span="spanSecond">
        <div class="leftContainer">
          <div class="info">
            <el-tabs type="border-card">
              <el-tab-pane label="语音特征">
                <div class="infoContent">
                  <div class="info_item">
                    <label>静默次数:</label>
                    <span>{{ esResultModel.silenceCount }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默时长:</label>
                    <span>{{ esResultModel.silenceLong / 1000 || 0 }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默占比:</label>
                    <span
                      >{{ Math.round(esResultModel.silencePer * 1000) / 10 || 0 }}%</span
                    >
                  </div>
                  <div class="info_item">
                    <label>语音重叠次数:</label>
                    <span>{{ esResultModel.overLap }}</span>
                  </div>
                  <div class="info_item">
                    <label>情绪分值:</label>
                    <span>{{ esResultModel.moodScore }}</span>
                  </div>
                  <div class="info_item">
                    <label>平均语速:</label>
                    <span>{{ Math.round(esResultModel.avgSpeed * 100) / 100 }}字/秒</span>
                  </div>
                  <div class="info_item">
                    <label>最快语速:</label>
                    <span>{{ Math.round(esResultModel.maxSpeed * 100) / 100 }}字/秒</span>
                  </div>
                  <div class="info_item">
                    <label>最长静默:</label>
                    <span>{{ Math.round(esResultModel.maxSilenceLong / 10) / 100 }}</span>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
            <el-button
              class="submit-playinfo-list"
              v-if="
                roleCodeId.includes('qa_suvs') &&
                  (esResultModel.labelContent == null ||
                    esResultModel.labelContent == '') &&
                  esResultModel.isSampled == '0'
              "
              ><span @click="submitPlayInfoList('1')" v-if="isEditPlayInfoList"
                >文本修改</span
              ><span @click="submitPlayInfoList('2')" v-else>保存</span></el-button
            >
          </div>
          <div class="dialog" @mousewheel="test">
            <ul>
              <li
                :class="classes(item.role, item.startTime, item.endTime)"
                v-for="(item, index) in playInfoVosList"
                :key="item.startTime"
              >
                <div v-if="item.role == '1'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/seat.png"
                  />
                </div>
                <div v-if="item.role == '2'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/customer.png"
                  />
                </div>
                <div class="dialog-content" v-if="item.role != 'UNK'">
                  <div style="display: inline-block" v-if="!isEditPlayInfoList">
                    <el-input
                      type="textarea"
                      v-model="playInfoVosList[index].changeText"
                    />
                  </div>
                  <div
                    style="display: inline-block"
                    v-else
                    @click="playClip(item.startTime)"
                  >
                    <el-tooltip
                      :disabled="isShowPlayInfoTooltip"
                      class="item"
                      effect="dark"
                      placement="top"
                      :content="item.originalText"
                    >
                      <button
                        style="background: none;border:0;"
                        @mouseenter="playShowToolTip($event, item)"
                      >
                        <span
                          class="aims"
                          :class="[item.startTime, item.endTime]"
                          style="cursor: pointer"
                          v-html="item.text"
                        ></span>
                      </button>
                    </el-tooltip>
                  </div>
                </div>
                <div
                  class="content-tag"
                  v-if="item.role == 1 && isShowSpeedFlag(item.speed)"
                >
                  <el-tag :type="item.speed | dealSpeedType(minSpeed, maxSpeed)">
                    {{ item.speed | dealSpeed(minSpeed, maxSpeed) }}
                  </el-tag>
                </div>
                <div v-if="item.role == 'UNK'" class="UNK_text">
                  <el-row>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                    <el-col :span="4">{{ item.text }}</el-col>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                  </el-row>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </el-col>
      <el-col :span="spanThird">
        <el-tabs
          class="cailbtat_meet"
          v-model="activeName"
          type="card"
          @tab-click="handleClick"
          v-if="isCreator === '0'"
        >
          <el-tab-pane label="标准成绩" name="first">
            <template>
              <div class="rightContainer">
                <div class="standards_parts cailbtatMeet">
                  <div class="standards_part">
                    <div class="standards_part_title">
                      <h2 class="h2">评分模板：{{ modleTitle }}</h2>
                      <div class="score">
                        <span
                          v-if="!isDefaultScore && normalScored"
                          class="score_result"
                          >{{ newTotalScoreFun }}</span
                        >
                        <span v-else class="score_result">{{ totalScoreFun }}</span>
                      </div>
                    </div>
                    <div class="standards_part_title">
                      <h3>
                        评分标准
                      </h3>
                      <div class="score">
                        <span v-if="!isDefaultScore && normalScored">{{
                          newAutoScoreFun
                        }}</span>
                        <span v-else-if="!isDefaultScore && !normalScored">{{
                          autoScoreFun
                        }}</span>
                        <span v-else>--</span>
                      </div>
                    </div>
                    <div class="standards_detail">
                      <div
                        v-for="(standardsList, key) in standardsListWithAutoScoreQa"
                        :key="key"
                      >
                        <div class="normalNameClass">{{ key }}</div>
                        <el-table
                          ref="standardsListTable"
                          :data="standardsListWithAutoScoreQa[key]"
                          border
                          tooltip-effect="dark"
                        >
                          <el-table-column prop="normalName" label="质检标准">
                          </el-table-column>
                          <el-table-column
                            prop="judge"
                            :formatter="formatJudge"
                            label="打分方式"
                          >
                          </el-table-column>
                          <el-table-column label="内容">
                            <template scope="scope">
                              <div v-if="scope.row.judge === 5">
                                <p v-if="scope.row.resultsObject !== null">
                                  <span
                                    v-for="(item, key) in scope.row.resultsObject"
                                    :index="key"
                                  >
                                    <span>{{ item.keywordContext }}</span>
                                    <span>{{
                                      getKeywordScoreFilter(item, scope.row.judge)
                                    }}</span>
                                  </span>
                                  <el-popover
                                    placement="right"
                                    width="120"
                                    trigger="hover"
                                  >
                                    <template
                                      v-if="scope.row.resultsObject[0].deadItem == '1'"
                                      slot="reference"
                                    >
                                      <i class="el-icon-warning" style="color: red"></i>
                                    </template>
                                    <p>{{ mingzhongTip }}</p>
                                  </el-popover>
                                </p>
                              </div>
                              <div v-else-if="scope.row.judge === 4">
                                <div
                                  v-for="(srrt, key) in scope.row.resultsObject"
                                  :index="key"
                                >
                                  <p>
                                    {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span
                                      class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 1">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.silenceTimeMin }}-{{
                                      srrt.silenceTimeMax
                                    }}分<span class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 2">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.silenceTimeMin }}-{{
                                      srrt.silenceTimeMax
                                    }}次<span class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 11">
                                <p v-for="keyValue in scope.row.resultsObject">
                                  {{ keyValue.labelName }}
                                  <span v-if="keyValue.score !== 0"
                                    >{{ +keyValue.increaseDeduction == '2' ? '减' : '加'
                                    }}{{ keyValue.score }}分</span
                                  >
                                </p>
                                <el-popover placement="right" width="120" trigger="hover">
                                  <template
                                    v-if="scope.row.resultsObject[0].deadItem == '1'"
                                    slot="reference"
                                  >
                                    <i class="el-icon-warning" style="color: red"></i>
                                  </template>
                                  <p>{{ mingzhongTip }}</p>
                                </el-popover>
                              </div>
                              <div v-else-if="scope.row.judge === 3">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <div v-if="srrt.silenceType === 1">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}秒<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 2">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}次<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 3">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}%<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 4">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}秒<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 5">
                                    <span>{{ srrt.keywordContext }}</span>
                                    {{ getKeywordScoreFilter(srrt, scope.row.judge) }}
                                  </div>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 12">
                                <div>
                                  {{
                                    scope.row.resultsObject[0].firstRoleType == 1
                                      ? '坐席:'
                                      : '客户:'
                                  }}
                                  <span
                                    v-html="
                                      getHtml(scope.row.resultsObject[0].firstContext)
                                    "
                                  ></span>
                                </div>
                                <div>
                                  {{
                                    scope.row.resultsObject[0].secondRoleType == 1
                                      ? '坐席:'
                                      : '客户:'
                                  }}
                                  <span
                                    v-html="
                                      getHtml(scope.row.resultsObject[0].secondContext)
                                    "
                                  ></span>
                                </div>
                                <div>
                                  规则:
                                  {{
                                    `${scope.row.resultsObject[0].sentenceCount}句内，${
                                      scope.row.resultsObject[0].isAppear == 1
                                        ? '出现'
                                        : '未出现'
                                    }`
                                  }}<span
                                    v-if="
                                      scope.row.resultsObject[0].sentenceDeadItem == '2'
                                    "
                                    >{{
                                      `${
                                        scope.row.resultsObject[0].increaseDeduction == 1
                                          ? '加'
                                          : '减'
                                      }${scope.row.resultsObject[0].score}分`
                                    }}</span
                                  >
                                </div>
                                <el-popover placement="right" width="120" trigger="hover">
                                  <template
                                    v-if="
                                      scope.row.resultsObject[0].sentenceDeadItem == '1'
                                    "
                                    slot="reference"
                                  >
                                    <i class="el-icon-warning" style="color: red"></i>
                                  </template>
                                  <p>此标准为致命项标准，命中则总分为 0</p>
                                </el-popover>
                              </div>
                              <div v-else-if="scope.row.judge === 13">
                                <div>
                                  意图:
                                  <span
                                    v-html="getContentHtml(scope.row.faqContent)"
                                  ></span>
                                </div>
                                <div
                                  v-for="(item, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <div>
                                    话术:
                                    <span v-html="getContentHtml(item.content)"></span>
                                  </div>
                                  <div>
                                    规则:
                                    {{
                                      `${item.isAppear == 1 ? '出现' : '未出现'}${
                                        item.addsub == 1 ? '加' : '减'
                                      }${item.score}分`
                                    }}
                                  </div>
                                </div>
                              </div>
                              <div v-else>{{ scope.row.normalContent }}</div>
                            </template>
                          </el-table-column>
                          <el-table-column label="得分" width="120">
                            <template scope="scope">
                              <div v-if="normalScored">
                                <span
                                  v-if="scope.row.judge == 5 || scope.row.judge == 11"
                                >
                                  <span v-if="scope.row.resultsObject">
                                    <span
                                      v-if="
                                        (scope.row.resultsObject[0].deadItem === '1') &
                                          (standardsListWithAutoScoreQa[key][scope.$index]
                                            .score ==
                                            '2')
                                      "
                                    >
                                      非致命
                                    </span>
                                    <span
                                      v-else-if="
                                        (scope.row.resultsObject[0].deadItem === '1') &
                                          (standardsListWithAutoScoreQa[key][scope.$index]
                                            .score ==
                                            '1')
                                      "
                                    >
                                      致命
                                    </span>
                                    <span v-else>{{
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .score
                                    }}</span>
                                  </span>
                                </span>
                                <el-select
                                  v-else-if="scope.row.judge == 7"
                                  :disabled="true"
                                  v-model="
                                    standardsListWithAutoScoreQa[key][scope.$index].score
                                  "
                                >
                                  <el-option
                                    v-for="val in scope.row.resultsObject"
                                    :key="val"
                                    :label="val"
                                    :value="val"
                                  >
                                  </el-option>
                                </el-select>
                                <span
                                  v-else-if="
                                    scope.row.judge == 8 &&
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .score == '2'
                                  "
                                  >非致命</span
                                >
                                <span
                                  v-else-if="
                                    scope.row.judge == 8 &&
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .score == '1'
                                  "
                                  >致命</span
                                >
                                <span
                                  v-else-if="
                                    scope.row.judge == 12 &&
                                      scope.row.resultsObject[0].sentenceDeadItem === '1'
                                  "
                                >
                                  <span v-if="scope.row.resultsObject">
                                    <span
                                      v-if="
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score == '2'
                                      "
                                    >
                                      非致命
                                    </span>
                                    <span
                                      v-else-if="
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score == '1'
                                      "
                                    >
                                      致命
                                    </span>
                                  </span>
                                </span>
                                <span v-else>{{
                                  standardsListWithAutoScoreQa[key][scope.$index].score
                                }}</span>
                              </div>
                              <div v-else-if="!normalScored">
                                <div v-if="scope.row.judge == 5 || scope.row.judge == 11">
                                  <div v-if="scope.row.resultsObject">
                                    <el-select
                                      v-if="scope.row.resultsObject[0].deadItem === '1'"
                                      @change="
                                        changeDead(scope.row.newIndex, scope.row.judge)
                                      "
                                      v-model="
                                        currentDistribute[scope.row.newIndex].score
                                      "
                                      placeholder="请选择"
                                      style="width: 95px;"
                                    >
                                      <el-option
                                        v-for="item in deadOptions"
                                        :key="item.value"
                                        :label="item.label"
                                        :value="item.value"
                                      >
                                      </el-option>
                                    </el-select>
                                    <el-input
                                      v-else
                                      v-model.number="
                                        currentDistribute[scope.row.newIndex].score
                                      "
                                      oninput="value=value.replace(/[^-\d]/g,'')"
                                      @blur="
                                        !isClose &&
                                          checkNumber(scope.row.newIndex, scope.row)
                                      "
                                    ></el-input>
                                  </div>
                                </div>
                                <el-input
                                  v-else-if="scope.row.judge == 6"
                                  v-model.number="
                                    currentDistribute[scope.row.newIndex].score
                                  "
                                  oninput="value=value.replace(/[^-\d]/g,'')"
                                  @blur="
                                    checkRange(
                                      currentDistribute[scope.row.newIndex].score,
                                      currentDistribute[scope.row.newIndex].minScoreRange,
                                      currentDistribute[scope.row.newIndex].maxScoreRange
                                    )
                                  "
                                ></el-input>
                                <el-select
                                  v-else-if="scope.row.judge == 7"
                                  v-model="currentDistribute[scope.row.newIndex].score"
                                >
                                  <el-option
                                    v-for="val in scope.row.resultsObject"
                                    :key="val"
                                    :label="val"
                                    :value="val"
                                  >
                                  </el-option>
                                </el-select>
                                <el-select
                                  v-else-if="
                                    scope.row.judge == 8 ||
                                      (scope.row.judge == 12 &&
                                        scope.row.resultsObject[0].sentenceDeadItem ===
                                          '1')
                                  "
                                  @change="
                                    changeDead(scope.row.newIndex, scope.row.judge)
                                  "
                                  v-model="currentDistribute[scope.row.newIndex].score"
                                  placeholder="请选择"
                                  style="width: 95px;"
                                >
                                  <el-option key="1" label="致命" value="1"></el-option>
                                  <el-option key="2" label="非致命" value="2"></el-option>
                                </el-select>
                                <el-input
                                  v-else
                                  v-model.number="
                                    currentDistribute[scope.row.newIndex].score
                                  "
                                  oninput="value=value.replace(/[^-\d]/g,'')"
                                  @blur="
                                    !isClose && checkNumber(scope.row.newIndex, scope.row)
                                  "
                                ></el-input>
                              </div>
                            </template>
                          </el-table-column>
                        </el-table>
                      </div>
                    </div>
                  </div>
                  <div class="standards_part">
                    <div class="standards_part_title">
                      <h3>
                        流程评分
                      </h3>
                      <div class="score">
                        <span>{{ flowScoreFun }}</span>
                      </div>
                    </div>
                    <div style="width: 200px;">
                      <el-select
                        v-model="flowValue"
                        @change="changeFlowOption"
                        :disabled="normalScored"
                        multiple
                        placeholder="请选择流程"
                      >
                        <el-option
                          v-for="item in flowoptions"
                          :key="item.processId"
                          :label="item.processName"
                          :value="item.processId"
                        >
                        </el-option>
                      </el-select>
                    </div>
                    <div class="standards_detail">
                      <div
                        class="classification_part"
                        v-for="(key, index) in flowListWithScoreQa"
                        :key="index"
                      >
                        <h3>
                          {{ key.processName }}
                        </h3>
                        <div class="classification_detail">
                          <el-table
                            ref="standardsListTable"
                            :data="key.processDetail"
                            border
                            max-height="500"
                            tooltip-effect="dark"
                          >
                            <el-table-column prop="intentName" label="意图">
                            </el-table-column>
                            <el-table-column prop="intentRule" label="规则">
                            </el-table-column>
                            <el-table-column label="得分">
                              <template scope="scope">
                                <div v-if="normalScored">
                                  <span>{{ key.processDetail[scope.$index].score }}</span>
                                </div>
                                <div v-else>
                                  <el-input
                                    v-model.number="
                                      flowListScoreObjs[scope.row.newIndex].score
                                    "
                                    oninput="value=value.replace(/[^-\d]/g,'')"
                                    @blur="checkFlowNumber(scope.row.newIndex, scope.row)"
                                  ></el-input>
                                </div>
                              </template>
                            </el-table-column>
                          </el-table>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="btns footer">
                    <el-button
                      :disabled="normalScored"
                      @click="zgSubmitScore"
                      type="primary"
                    >
                      提交成绩
                    </el-button>
                  </div>
                </div>
              </div>
            </template>
          </el-tab-pane>
          <el-tab-pane label="校准评分" name="second">
            <template>
              <div class="rightContainer">
                <div class="standards_parts cailbtatMeet">
                  <div class="standards_part">
                    <div class="zjyWrap">
                      <span class="zjyWrap_title">请选择质检员</span>
                      <el-select
                        class="zjyWrap_select"
                        v-model="zjySelect"
                        placeholder="请选择"
                        @change="changeZjy"
                      >
                        <el-option
                          v-for="item in zjyOptions"
                          :key="item.qaId"
                          :label="item.qaName"
                          :value="item.qaId"
                          :disabled="!item.isSubmit"
                        >
                        </el-option>
                      </el-select>
                    </div>
                    <div class="standards_part_title">
                      <h2 class="h2">评分模板：{{ modleTitle }}</h2>
                      <div class="score">
                        <span
                          v-if="!isDefaultScore && normalScored"
                          class="score_result"
                          >{{ newTotalScoreFun }}</span
                        >
                        <span v-else class="score_result">{{ totalScoreFun }}</span>
                      </div>
                    </div>
                    <div class="standards_part_title">
                      <h3>
                        评分标准
                      </h3>
                      <div class="score">
                        <span v-if="!isDefaultScore && normalScored">{{
                          newAutoScoreFun
                        }}</span>
                        <span v-else-if="!isDefaultScore && !normalScored">{{
                          autoScoreFun
                        }}</span>
                        <span v-else>--</span>
                      </div>
                    </div>
                    <div class="standards_detail">
                      <div
                        v-for="(standardsList, key) in standardsListWithAutoScoreQa"
                        :key="key"
                      >
                        <div class="normalNameClass">{{ key }}</div>
                        <el-table
                          ref="standardsListTable"
                          :data="standardsListWithAutoScoreQa[key]"
                          border
                          tooltip-effect="dark"
                        >
                          <el-table-column prop="normalName" label="质检标准">
                          </el-table-column>
                          <el-table-column
                            prop="judge"
                            :formatter="formatJudge"
                            label="打分方式"
                          >
                          </el-table-column>
                          <el-table-column label="内容">
                            <template scope="scope">
                              <div v-if="scope.row.judge === 5">
                                <p v-if="scope.row.resultsObject !== null">
                                  <span
                                    v-for="(item, key) in scope.row.resultsObject"
                                    :index="key"
                                  >
                                    <span>{{ item.keywordContext }}</span>
                                    <span>{{
                                      getKeywordScoreFilter(item, scope.row.judge)
                                    }}</span>
                                  </span>
                                  <!-- <span v-for="(item, index) in scope.row.resultsObject.keywordContext.split('OR')"
                                        :key="index">
                                    <span class="hightlightContent_span"
                                          @click="hightlightContent(item)">{{item}} </span>
                                    <span v-if="index<scope.row.resultsObject.keywordContext.split('OR').length-1">&nbsp;OR&nbsp;</span>
                                  </span> -->
                                  <el-popover
                                    placement="right"
                                    width="120"
                                    trigger="hover"
                                  >
                                    <template
                                      v-if="scope.row.resultsObject[0].deadItem == '1'"
                                      slot="reference"
                                    >
                                      <i class="el-icon-warning" style="color: red"></i>
                                    </template>
                                    <p>{{ mingzhongTip }}</p>
                                  </el-popover>
                                </p>
                              </div>
                              <div v-else-if="scope.row.judge === 4">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span
                                      class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 1">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.silenceTimeMin }}-{{
                                      srrt.silenceTimeMax
                                    }}分<span class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 2">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.silenceTimeMin }}-{{
                                      srrt.silenceTimeMax
                                    }}次<span class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 11">
                                <p v-for="keyValue in scope.row.resultsObject">
                                  {{ keyValue.labelName }}
                                  <span v-if="keyValue.score !== 0"
                                    >{{ +keyValue.increaseDeduction == '2' ? '减' : '加'
                                    }}{{ keyValue.score }}分</span
                                  >
                                </p>
                                <el-popover placement="right" width="120" trigger="hover">
                                  <template
                                    v-if="scope.row.resultsObject[0].deadItem == '1'"
                                    slot="reference"
                                  >
                                    <i class="el-icon-warning" style="color: red"></i>
                                  </template>
                                  <p>{{ mingzhongTip }}</p>
                                </el-popover>
                              </div>
                              <div v-else-if="scope.row.judge === 3">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <div v-if="srrt.silenceType === 1">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}秒<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 2">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}次<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 3">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}%<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 4">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}秒<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 5">
                                    <span>{{ srrt.keywordContext }}</span>
                                    {{ getKeywordScoreFilter(srrt, scope.row.judge) }}
                                  </div>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 12">
                                <div>
                                  {{
                                    scope.row.resultsObject[0].firstRoleType == 1
                                      ? '坐席:'
                                      : '客户:'
                                  }}
                                  <span
                                    v-html="
                                      getHtml(scope.row.resultsObject[0].firstContext)
                                    "
                                  ></span>
                                </div>
                                <div>
                                  {{
                                    scope.row.resultsObject[0].secondRoleType == 1
                                      ? '坐席:'
                                      : '客户:'
                                  }}
                                  <span
                                    v-html="
                                      getHtml(scope.row.resultsObject[0].secondContext)
                                    "
                                  ></span>
                                </div>
                                <div>
                                  规则:
                                  {{
                                    `${scope.row.resultsObject[0].sentenceCount}句内，${
                                      scope.row.resultsObject[0].isAppear == 1
                                        ? '出现'
                                        : '未出现'
                                    }`
                                  }}<span
                                    v-if="
                                      scope.row.resultsObject[0].sentenceDeadItem == '2'
                                    "
                                    >{{
                                      `${
                                        scope.row.resultsObject[0].increaseDeduction == 1
                                          ? '加'
                                          : '减'
                                      }${scope.row.resultsObject[0].score}分`
                                    }}</span
                                  >
                                </div>
                                <el-popover placement="right" width="120" trigger="hover">
                                  <template
                                    v-if="
                                      scope.row.resultsObject[0].sentenceDeadItem == '1'
                                    "
                                    slot="reference"
                                  >
                                    <i class="el-icon-warning" style="color: red"></i>
                                  </template>
                                  <p>此标准为致命项标准，命中则总分为 0</p>
                                </el-popover>
                              </div>
                              <div v-else-if="scope.row.judge === 13">
                                <div>
                                  意图:
                                  <span
                                    v-html="getContentHtml(scope.row.faqContent)"
                                  ></span>
                                </div>
                                <div
                                  v-for="(item, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <div>
                                    话术:
                                    <span v-html="getContentHtml(item.content)"></span>
                                  </div>
                                  <div>
                                    规则:
                                    {{
                                      `${item.isAppear == 1 ? '出现' : '未出现'}${
                                        item.addsub == 1 ? '加' : '减'
                                      }${item.score}分`
                                    }}
                                  </div>
                                </div>
                              </div>
                              <div v-else>{{ scope.row.normalContent }}</div>
                            </template>
                          </el-table-column>
                          <el-table-column label="得分" width="120">
                            <template scope="scope">
                              <div v-if="isDefaultScore">
                                <span
                                  v-if="scope.row.judge == 5 || scope.row.judge == 11"
                                >
                                  <span v-if="scope.row.resultsObject">
                                    <span
                                      v-if="scope.row.resultsObject[0].deadItem == '1'"
                                      >非致命</span
                                    >
                                  </span>
                                </span>
                                <el-select
                                  v-else-if="scope.row.judge == 7"
                                  :disabled="true"
                                  v-model="scope.row.resultsObject[0]"
                                >
                                  <el-option
                                    v-for="val in scope.row.resultsObject"
                                    :key="val"
                                    :label="val"
                                    :value="val"
                                  >
                                  </el-option>
                                </el-select>
                                <span v-else-if="scope.row.judge == 8">非致命</span>
                                <span
                                  v-else-if="
                                    scope.row.judge == 12 &&
                                      scope.row.resultsObject[0].sentenceDeadItem === '1'
                                  "
                                >
                                  <span v-if="scope.row.resultsObject">
                                    <span v-if="scope.row.defaultScore == '2'">
                                      非致命
                                    </span>
                                    <span v-else-if="scope.row.defaultScore == '1'">
                                      致命
                                    </span>
                                  </span>
                                </span>
                                <span v-else>{{ scope.row.defaultScore }}</span>
                              </div>
                              <div v-else>
                                <div v-if="scored">
                                  <span
                                    v-if="scope.row.judge == 5 || scope.row.judge == 11"
                                  >
                                    <span v-if="scope.row.resultsObject">
                                      <span
                                        v-if="
                                          (scope.row.resultsObject[0].deadItem === '1') &
                                            (standardsListWithAutoScoreQa[key][
                                              scope.$index
                                            ].score ==
                                              '2')
                                        "
                                      >
                                        非致命
                                      </span>
                                      <span
                                        v-else-if="
                                          (scope.row.resultsObject[0].deadItem === '1') &
                                            (standardsListWithAutoScoreQa[key][
                                              scope.$index
                                            ].score ==
                                              '1')
                                        "
                                      >
                                        致命
                                      </span>
                                      <span v-else>{{
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score
                                      }}</span>
                                    </span>
                                  </span>
                                  <el-select
                                    v-else-if="scope.row.judge == 7"
                                    :disabled="true"
                                    v-model="
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .score
                                    "
                                  >
                                    <el-option
                                      v-for="val in scope.row.resultsObject"
                                      :key="val"
                                      :label="val"
                                      :value="val"
                                    >
                                    </el-option>
                                  </el-select>
                                  <span
                                    v-else-if="
                                      scope.row.judge == 8 &&
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score == '2'
                                    "
                                    >非致命</span
                                  >
                                  <span
                                    v-else-if="
                                      scope.row.judge == 8 &&
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score == '1'
                                    "
                                    >致命</span
                                  >
                                  <span
                                    v-else-if="
                                      scope.row.judge == 12 &&
                                        scope.row.resultsObject[0].sentenceDeadItem ===
                                          '1'
                                    "
                                  >
                                    <span v-if="scope.row.resultsObject">
                                      <span
                                        v-if="
                                          standardsListWithAutoScoreQa[key][scope.$index]
                                            .score == '2'
                                        "
                                      >
                                        非致命
                                      </span>
                                      <span
                                        v-else-if="
                                          standardsListWithAutoScoreQa[key][scope.$index]
                                            .score == '1'
                                        "
                                      >
                                        致命
                                      </span>
                                    </span>
                                  </span>
                                  <span v-else>{{
                                    standardsListWithAutoScoreQa[key][scope.$index].score
                                  }}</span>
                                </div>
                                <div v-else-if="!scored">
                                  <div
                                    v-if="scope.row.judge == 5 || scope.row.judge == 11"
                                  >
                                    <div v-if="scope.row.resultsObject">
                                      <el-select
                                        v-if="scope.row.resultsObject[0].deadItem === '1'"
                                        @change="
                                          changeDead(scope.row.newIndex, scope.row.judge)
                                        "
                                        v-model="
                                          currentDistribute[scope.row.newIndex].score
                                        "
                                        placeholder="请选择"
                                        style="width: 95px;"
                                      >
                                        <el-option
                                          v-for="item in deadOptions"
                                          :key="item.value"
                                          :label="item.label"
                                          :value="item.value"
                                        >
                                        </el-option>
                                      </el-select>
                                      <el-input
                                        v-else
                                        v-model.number="
                                          currentDistribute[scope.row.newIndex].score
                                        "
                                        oninput="value=value.replace(/[^-\d]/g,'')"
                                        @blur="
                                          !isClose &&
                                            checkNumber(scope.row.newIndex, scope.row)
                                        "
                                      ></el-input>
                                    </div>
                                  </div>
                                  <el-input
                                    v-else-if="scope.row.judge == 6"
                                    v-model.number="
                                      currentDistribute[scope.row.newIndex].score
                                    "
                                    oninput="value=value.replace(/[^-\d]/g,'')"
                                    @blur="
                                      checkRange(
                                        currentDistribute[scope.row.newIndex].score,
                                        currentDistribute[scope.row.newIndex]
                                          .minScoreRange,
                                        currentDistribute[scope.row.newIndex]
                                          .maxScoreRange
                                      )
                                    "
                                  ></el-input>
                                  <el-select
                                    v-else-if="scope.row.judge == 7"
                                    v-model="currentDistribute[scope.row.newIndex].score"
                                  >
                                    <el-option
                                      v-for="val in scope.row.resultsObject"
                                      :key="val"
                                      :label="val"
                                      :value="val"
                                    >
                                    </el-option>
                                  </el-select>
                                  <el-select
                                    v-else-if="
                                      scope.row.judge == 8 ||
                                        (scope.row.judge == 12 &&
                                          scope.row.resultsObject[0].sentenceDeadItem ===
                                            '1')
                                    "
                                    @change="
                                      changeDead(scope.row.newIndex, scope.row.judge)
                                    "
                                    v-model="currentDistribute[scope.row.newIndex].score"
                                    placeholder="请选择"
                                    style="width: 95px;"
                                  >
                                    <el-option key="1" label="致命" value="1"></el-option>
                                    <el-option
                                      key="2"
                                      label="非致命"
                                      value="2"
                                    ></el-option>
                                  </el-select>
                                  <el-input
                                    v-else
                                    v-model.number="
                                      currentDistribute[scope.row.newIndex].score
                                    "
                                    oninput="value=value.replace(/[^-\d]/g,'')"
                                    @blur="
                                      !isClose &&
                                        checkNumber(scope.row.newIndex, scope.row)
                                    "
                                  ></el-input>
                                </div>
                              </div>
                            </template>
                          </el-table-column>
                        </el-table>
                      </div>
                    </div>
                  </div>
                  <div class="standards_part">
                    <div class="standards_part_title">
                      <h3>
                        流程评分
                      </h3>
                      <div class="score">
                        <span>{{ flowScoreFun }}</span>
                      </div>
                    </div>
                    <div style="width: 200px;">
                      <el-select
                        v-model="flowValue"
                        @change="changeFlowOption"
                        :disabled="normalScored"
                        multiple
                        placeholder="请选择流程"
                      >
                        <el-option
                          v-for="item in flowoptions"
                          :key="item.processId"
                          :label="item.processName"
                          :value="item.processId"
                        >
                        </el-option>
                      </el-select>
                    </div>
                    <div class="standards_detail">
                      <div
                        class="classification_part"
                        v-for="(key, index) in flowListWithScoreQa"
                        :key="index"
                      >
                        <h3>
                          {{ key.processName }}
                        </h3>
                        <div class="classification_detail">
                          <el-table
                            ref="standardsListTable"
                            :data="key.processDetail"
                            max-height="500"
                            border
                            tooltip-effect="dark"
                          >
                            <el-table-column prop="intentName" label="意图">
                            </el-table-column>
                            <el-table-column prop="intentRule" label="规则">
                            </el-table-column>
                            <el-table-column label="得分">
                              <template scope="scope">
                                <div v-if="isDefaultScore">
                                  <span>{{ scope.row.firstScore }}</span>
                                </div>
                                <div v-else>
                                  <div v-if="scored">
                                    <span>{{
                                      key.processDetail[scope.$index].score
                                    }}</span>
                                  </div>
                                  <div v-else>
                                    <el-input
                                      v-model.number="
                                        flowListScoreObjs[scope.row.newIndex].score
                                      "
                                      oninput="value=value.replace(/[^-\d]/g,'')"
                                      @blur="
                                        checkFlowNumber(scope.row.newIndex, scope.row)
                                      "
                                    ></el-input>
                                  </div>
                                </div>
                              </template>
                            </el-table-column>
                          </el-table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </template>
          </el-tab-pane>
        </el-tabs>

        <el-tabs
          class="cailbtat_meet"
          v-model="activeName"
          type="card"
          @tab-click="handleClick"
          @tab-remove="closeNormalTab"
          v-if="isCreator === '1'"
        >
          <el-tab-pane label="校准评分" name="first">
            <template>
              <div class="rightContainer">
                <div class="standards_parts cailbtatMeet">
                  <div class="standards_part">
                    <div class="standards_part_title">
                      <h2 class="h2">评分模板：{{ modleTitle }}</h2>
                      <div class="score">
                        <span v-if="!isDefaultScore & scored" class="score_result">{{
                          newTotalScoreFun
                        }}</span>
                        <span v-else class="score_result">{{ totalScoreFun }}</span>
                      </div>
                    </div>
                    <div class="standards_part_title">
                      <h3>
                        评分标准
                      </h3>
                      <div class="score">
                        <span v-if="!isDefaultScore & !scored">{{ autoScoreFun }}</span>
                        <span v-else-if="!isDefaultScore & scored">{{
                          newAutoScoreFun
                        }}</span>
                        <span v-else>--</span>
                      </div>
                    </div>
                    <div class="standards_detail">
                      <div
                        v-for="(standardsList, key) in standardsListWithAutoScoreQa"
                        :key="key"
                      >
                        <div class="normalNameClass">{{ key }}</div>
                        <el-table
                          ref="standardsListTable"
                          :data="standardsListWithAutoScoreQa[key]"
                          border
                          tooltip-effect="dark"
                        >
                          <el-table-column prop="normalName" label="质检标准">
                          </el-table-column>
                          <el-table-column
                            prop="judge"
                            :formatter="formatJudge"
                            label="打分方式"
                          >
                          </el-table-column>
                          <el-table-column label="内容">
                            <template scope="scope">
                              <div v-if="scope.row.judge === 5">
                                <div v-if="scope.row.resultsObject !== null">
                                  <span
                                    v-for="(item, key) in scope.row.resultsObject"
                                    :index="key"
                                  >
                                    <span>{{ item.keywordContext }}</span>
                                    <span>{{
                                      getKeywordScoreFilter(item, scope.row.judge)
                                    }}</span>
                                  </span>
                                  <!-- <span v-for="(item, index) in scope.row.resultsObject.keywordContext.split('OR')"
                                        :key="index">
                                    <span class="hightlightContent_span"
                                          @click="hightlightContent(item)">{{item}} </span>
                                    <span v-if="index<scope.row.resultsObject.keywordContext.split('OR').length-1">&nbsp;OR&nbsp;</span>
                                  </span> -->
                                  <el-popover
                                    placement="right"
                                    width="120"
                                    trigger="hover"
                                  >
                                    <template
                                      v-if="scope.row.resultsObject[0].deadItem == '1'"
                                      slot="reference"
                                    >
                                      <i class="el-icon-warning" style="color: red"></i>
                                    </template>
                                    <p>{{ mingzhongTip }}</p>
                                  </el-popover>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 4">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span
                                      class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 1">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.silenceTimeMin }}-{{
                                      srrt.silenceTimeMax
                                    }}分<span class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 2">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.silenceTimeMin }}-{{
                                      srrt.silenceTimeMax
                                    }}次<span class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 11">
                                <p v-for="keyValue in scope.row.resultsObject">
                                  {{ keyValue.labelName }}
                                  <span v-if="keyValue.score !== 0"
                                    >{{ +keyValue.increaseDeduction == '2' ? '减' : '加'
                                    }}{{ keyValue.score }}分</span
                                  >
                                </p>
                                <el-popover placement="right" width="120" trigger="hover">
                                  <template
                                    v-if="scope.row.resultsObject[0].deadItem == '1'"
                                    slot="reference"
                                  >
                                    <i class="el-icon-warning" style="color: red"></i>
                                  </template>
                                  <p>{{ mingzhongTip }}</p>
                                </el-popover>
                              </div>
                              <div v-else-if="scope.row.judge === 3">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <div v-if="srrt.silenceType === 1">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}秒<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 2">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}次<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 3">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}%<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 4">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}秒<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 5">
                                    <span>{{ srrt.keywordContext }}</span>
                                    {{ getKeywordScoreFilter(srrt, scope.row.judge) }}
                                  </div>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 12">
                                <div>
                                  {{
                                    scope.row.resultsObject[0].firstRoleType == 1
                                      ? '坐席:'
                                      : '客户:'
                                  }}
                                  <span
                                    v-html="
                                      getHtml(scope.row.resultsObject[0].firstContext)
                                    "
                                  ></span>
                                </div>
                                <div>
                                  {{
                                    scope.row.resultsObject[0].secondRoleType == 1
                                      ? '坐席:'
                                      : '客户:'
                                  }}
                                  <span
                                    v-html="
                                      getHtml(scope.row.resultsObject[0].secondContext)
                                    "
                                  ></span>
                                </div>
                                <div>
                                  规则:
                                  {{
                                    `${scope.row.resultsObject[0].sentenceCount}句内，${
                                      scope.row.resultsObject[0].isAppear == 1
                                        ? '出现'
                                        : '未出现'
                                    }`
                                  }}<span
                                    v-if="
                                      scope.row.resultsObject[0].sentenceDeadItem == '2'
                                    "
                                    >{{
                                      `${
                                        scope.row.resultsObject[0].increaseDeduction == 1
                                          ? '加'
                                          : '减'
                                      }${scope.row.resultsObject[0].score}分`
                                    }}</span
                                  >
                                </div>
                                <el-popover placement="right" width="120" trigger="hover">
                                  <template
                                    v-if="
                                      scope.row.resultsObject[0].sentenceDeadItem == '1'
                                    "
                                    slot="reference"
                                  >
                                    <i class="el-icon-warning" style="color: red"></i>
                                  </template>
                                  <p>此标准为致命项标准，命中则总分为 0</p>
                                </el-popover>
                              </div>
                              <div v-else-if="scope.row.judge === 13">
                                <div>
                                  意图:
                                  <span
                                    v-html="getContentHtml(scope.row.faqContent)"
                                  ></span>
                                </div>
                                <div
                                  v-for="(item, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <div>
                                    话术:
                                    <span v-html="getContentHtml(item.content)"></span>
                                  </div>
                                  <div>
                                    规则:
                                    {{
                                      `${item.isAppear == 1 ? '出现' : '未出现'}${
                                        item.addsub == 1 ? '加' : '减'
                                      }${item.score}分`
                                    }}
                                  </div>
                                </div>
                              </div>
                              <div v-else>{{ scope.row.normalContent }}</div>
                            </template>
                          </el-table-column>
                          <el-table-column label="得分" width="120">
                            <template scope="scope">
                              <div v-if="isDefaultScore">
                                <span
                                  v-if="scope.row.judge == 5 || scope.row.judge == 11"
                                >
                                  <span v-if="scope.row.resultsObject">
                                    <span
                                      v-if="scope.row.resultsObject[0].deadItem == '1'"
                                      >非致命</span
                                    >
                                    <span v-else>{{ scope.row.defaultScore }}</span>
                                  </span>
                                </span>
                                <el-select
                                  v-else-if="scope.row.judge == 7"
                                  :disabled="true"
                                  v-model="scope.row.resultsObject[0]"
                                >
                                  <el-option
                                    v-for="val in scope.row.resultsObject"
                                    :key="val"
                                    :label="val"
                                    :value="val"
                                  >
                                  </el-option>
                                </el-select>
                                <span v-else-if="scope.row.judge == 8">非致命</span>
                                <span
                                  v-else-if="
                                    scope.row.judge == 12 &&
                                      scope.row.resultsObject[0].sentenceDeadItem === '1'
                                  "
                                >
                                  <span v-if="scope.row.resultsObject">
                                    <span v-if="scope.row.defaultScore == '2'">
                                      非致命
                                    </span>
                                    <span v-else-if="scope.row.defaultScore == '1'">
                                      致命
                                    </span>
                                  </span>
                                </span>
                                <span v-else>{{ scope.row.defaultScore }}</span>
                              </div>
                              <div v-else>
                                <div
                                  v-if="
                                    scored ||
                                      (isCreator === '1' && calibrateTaskState === '3')
                                  "
                                >
                                  <span
                                    v-if="scope.row.judge == 5 || scope.row.judge == 11"
                                  >
                                    <span v-if="scope.row.resultsObject">
                                      <span
                                        v-if="
                                          (scope.row.resultsObject[0].deadItem === '1') &
                                            (standardsListWithAutoScoreQa[key][
                                              scope.$index
                                            ].score ==
                                              '2')
                                        "
                                      >
                                        非致命
                                      </span>
                                      <span
                                        v-else-if="
                                          (scope.row.resultsObject[0].deadItem === '1') &
                                            (standardsListWithAutoScoreQa[key][
                                              scope.$index
                                            ].score ==
                                              '1')
                                        "
                                      >
                                        致命
                                      </span>
                                      <span v-else>{{
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score
                                      }}</span>
                                    </span>
                                  </span>
                                  <el-select
                                    v-else-if="scope.row.judge == 7"
                                    :disabled="true"
                                    v-model="
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .score
                                    "
                                  >
                                    <el-option
                                      v-for="val in scope.row.resultsObject"
                                      :key="val"
                                      :label="val"
                                      :value="val"
                                    >
                                    </el-option>
                                  </el-select>
                                  <span
                                    v-else-if="
                                      scope.row.judge == 8 &&
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score == '2'
                                    "
                                    >非致命</span
                                  >
                                  <span
                                    v-else-if="
                                      scope.row.judge == 8 &&
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score == '1'
                                    "
                                    >致命</span
                                  >
                                  <span
                                    v-else-if="
                                      scope.row.judge == 12 &&
                                        scope.row.resultsObject[0].sentenceDeadItem ===
                                          '1'
                                    "
                                  >
                                    <span v-if="scope.row.resultsObject">
                                      <span
                                        v-if="
                                          standardsListWithAutoScoreQa[key][scope.$index]
                                            .score == '2'
                                        "
                                      >
                                        非致命
                                      </span>
                                      <span
                                        v-else-if="
                                          standardsListWithAutoScoreQa[key][scope.$index]
                                            .score == '1'
                                        "
                                      >
                                        致命
                                      </span>
                                    </span>
                                  </span>
                                  <span v-else>{{
                                    standardsListWithAutoScoreQa[key][scope.$index].score
                                  }}</span>
                                </div>
                                <div v-else-if="!scored">
                                  <div
                                    v-if="scope.row.judge == 5 || scope.row.judge == 11"
                                  >
                                    <div v-if="scope.row.resultsObject">
                                      <el-select
                                        v-if="scope.row.resultsObject[0].deadItem === '1'"
                                        @change="
                                          changeDead(scope.row.newIndex, scope.row.judge)
                                        "
                                        v-model="
                                          currentDistribute[scope.row.newIndex].score
                                        "
                                        placeholder="请选择"
                                        style="width: 95px;"
                                      >
                                        <el-option
                                          v-for="item in deadOptions"
                                          :key="item.value"
                                          :label="item.label"
                                          :value="item.value"
                                        >
                                        </el-option>
                                      </el-select>
                                      <el-input
                                        v-else
                                        v-model.number="
                                          currentDistribute[scope.row.newIndex].score
                                        "
                                        oninput="value=value.replace(/[^-\d]/g,'')"
                                        @blur="
                                          !isClose &&
                                            checkNumber(scope.row.newIndex, scope.row)
                                        "
                                      ></el-input>
                                    </div>
                                  </div>
                                  <el-input
                                    v-else-if="scope.row.judge == 6"
                                    v-model.number="
                                      currentDistribute[scope.row.newIndex].score
                                    "
                                    oninput="value=value.replace(/[^-\d]/g,'')"
                                    @blur="
                                      checkRange(
                                        currentDistribute[scope.row.newIndex].score,
                                        currentDistribute[scope.row.newIndex]
                                          .minScoreRange,
                                        currentDistribute[scope.row.newIndex]
                                          .maxScoreRange
                                      )
                                    "
                                  ></el-input>
                                  <el-select
                                    v-else-if="scope.row.judge == 7"
                                    v-model="currentDistribute[scope.row.newIndex].score"
                                  >
                                    <el-option
                                      v-for="val in scope.row.resultsObject"
                                      :key="val"
                                      :label="val"
                                      :value="val"
                                    >
                                    </el-option>
                                  </el-select>
                                  <el-select
                                    v-else-if="
                                      scope.row.judge == 8 ||
                                        (scope.row.judge == 12 &&
                                          scope.row.resultsObject[0].sentenceDeadItem ===
                                            '1')
                                    "
                                    @change="
                                      changeDead(scope.row.newIndex, scope.row.judge)
                                    "
                                    v-model="currentDistribute[scope.row.newIndex].score"
                                    placeholder="请选择"
                                    style="width: 95px;"
                                  >
                                    <el-option key="1" label="致命" value="1"></el-option>
                                    <el-option
                                      key="2"
                                      label="非致命"
                                      value="2"
                                    ></el-option>
                                  </el-select>
                                  <el-input
                                    v-else
                                    v-model.number="
                                      currentDistribute[scope.row.newIndex].score
                                    "
                                    oninput="value=value.replace(/[^-\d]/g,'')"
                                    @blur="
                                      !isClose &&
                                        checkNumber(scope.row.newIndex, scope.row)
                                    "
                                  ></el-input>
                                </div>
                              </div>
                            </template>
                          </el-table-column>
                        </el-table>
                      </div>
                    </div>
                  </div>
                  <div class="standards_part">
                    <div class="standards_part_title">
                      <h3>
                        流程评分
                      </h3>
                      <div class="score">
                        <span>{{ flowScoreFun }}</span>
                      </div>
                    </div>
                    <div style="width: 200px;">
                      <el-select
                        v-model="flowValue"
                        @change="changeFlowOption"
                        :disabled="scored"
                        multiple
                        placeholder="请选择流程"
                      >
                        <el-option
                          v-for="item in flowoptions"
                          :key="item.processId"
                          :label="item.processName"
                          :value="item.processId"
                        >
                        </el-option>
                      </el-select>
                    </div>
                    <div class="standards_detail">
                      <div
                        class="classification_part"
                        v-for="(key, index) in flowListWithScoreQa"
                        :key="index"
                      >
                        <h3>
                          {{ key.processName }}
                        </h3>
                        <div class="classification_detail">
                          <el-table
                            ref="standardsListTable"
                            :data="key.processDetail"
                            max-height="500"
                            border
                            tooltip-effect="dark"
                          >
                            <el-table-column prop="intentName" label="意图">
                            </el-table-column>
                            <el-table-column prop="intentRule" label="规则">
                            </el-table-column>
                            <el-table-column label="得分">
                              <template scope="scope">
                                <div
                                  v-if="
                                    scored ||
                                      (isCreator === '1' && calibrateTaskState === '3')
                                  "
                                >
                                  <span>{{ key.processDetail[scope.$index].score }}</span>
                                </div>
                                <div v-else>
                                  <el-input
                                    v-model.number="
                                      flowListScoreObjs[scope.row.newIndex].score
                                    "
                                    oninput="value=value.replace(/[^-\d]/g,'')"
                                    @blur="checkFlowNumber(scope.row.newIndex, scope.row)"
                                  ></el-input>
                                </div>
                              </template>
                            </el-table-column>
                          </el-table>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div style="float:left;">
                    <el-button :disabled="!isNormalTab" @click="showNormalTab">
                      查看标准成绩
                    </el-button>
                    <p class="tip" v-if="!isNormalTab">暂未公布</p>
                  </div>
                  <div class="btns footer">
                    <!-- {{scored}}{{isCreator}}{{calibrateTaskState}} -->
                    <el-button
                      :disabled="
                        scored || (isCreator === '1' && calibrateTaskState === '3')
                      "
                      @click="zjySubmitScore"
                      type="primary"
                    >
                      提交成绩
                    </el-button>
                  </div>
                </div>
              </div>
            </template>
          </el-tab-pane>
          <el-tab-pane
            v-if="isShowNormalTab"
            label="标准成绩"
            name="second"
            :closable="true"
          >
            <template>
              <div class="rightContainer">
                <div class="standards_parts cailbtatMeet">
                  <div class="standards_part">
                    <div class="standards_part_title">
                      <h2 class="h2">评分模板：{{ modleTitle }}</h2>
                      <div class="score">
                        <span class="score_result">{{ newTotalScoreFun }}</span>
                      </div>
                    </div>
                    <div class="standards_part_title">
                      <h3>
                        评分标准
                      </h3>
                      <div class="score">
                        <span v-if="!isDefaultScore">{{ newAutoScoreFun }}</span>
                        <span v-else>--</span>
                      </div>
                    </div>
                    <div class="standards_detail">
                      <div
                        v-for="(standardsList, key) in standardsListWithAutoScoreQa"
                        :key="key"
                      >
                        <div class="normalNameClass">{{ key }}</div>
                        <el-table
                          ref="standardsListTable"
                          :data="standardsListWithAutoScoreQa[key]"
                          border
                          tooltip-effect="dark"
                        >
                          <el-table-column prop="normalName" label="质检标准">
                          </el-table-column>
                          <el-table-column
                            prop="judge"
                            :formatter="formatJudge"
                            label="打分方式"
                          >
                          </el-table-column>
                          <el-table-column label="内容">
                            <template scope="scope">
                              <div v-if="scope.row.judge === 5">
                                <p v-if="scope.row.resultsObject !== null">
                                  <span
                                    v-for="(item, key) in scope.row.resultsObject"
                                    :index="key"
                                  >
                                    <span>{{ item.keywordContext }}</span>
                                    <span>{{
                                      getKeywordScoreFilter(item, scope.row.judge)
                                    }}</span>
                                  </span>
                                  <!-- <span v-for="(item, index) in scope.row.resultsObject.keywordContext.split('OR')"
                                        :key="index">
                                    <span class="hightlightContent_span"
                                          @click="hightlightContent(item)">{{item}} </span>
                                    <span v-if="index<scope.row.resultsObject.keywordContext.split('OR').length-1">&nbsp;OR&nbsp;</span>
                                  </span> -->
                                  <el-popover
                                    placement="right"
                                    width="120"
                                    trigger="hover"
                                  >
                                    <template
                                      v-if="scope.row.resultsObject[0].deadItem == '1'"
                                      slot="reference"
                                    >
                                      <i class="el-icon-warning" style="color: red"></i>
                                    </template>
                                    <p>{{ mingzhongTip }}</p>
                                  </el-popover>
                                </p>
                              </div>
                              <div v-else-if="scope.row.judge === 4">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span
                                      class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 1">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.silenceTimeMin }}-{{
                                      srrt.silenceTimeMax
                                    }}分<span class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 2">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <p>
                                    {{ srrt.silenceTimeMin }}-{{
                                      srrt.silenceTimeMax
                                    }}次<span class="defualtScore"
                                      ><span v-if="srrt.increaseDeduction === '1'"
                                        >加</span
                                      ><span v-else>减</span
                                      >{{
                                        srrt.score.toString().replace('-', ' ')
                                      }}分</span
                                    >
                                  </p>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 11">
                                <p v-for="keyValue in scope.row.resultsObject">
                                  {{ keyValue.labelName }}
                                  <span v-if="keyValue.score !== 0"
                                    >{{ +keyValue.increaseDeduction == '2' ? '减' : '加'
                                    }}{{ keyValue.score }}分</span
                                  >
                                </p>
                                <el-popover placement="right" width="120" trigger="hover">
                                  <template
                                    v-if="scope.row.resultsObject[0].deadItem == '1'"
                                    slot="reference"
                                  >
                                    <i class="el-icon-warning" style="color: red"></i>
                                  </template>
                                  <p>{{ mingzhongTip }}</p>
                                </el-popover>
                              </div>
                              <div v-else-if="scope.row.judge === 3">
                                <div
                                  v-for="(srrt, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <div v-if="srrt.silenceType === 1">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}秒<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 2">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}次<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 3">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}%<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 4">
                                    <p>
                                      {{ srrt.silenceTimeMin }}-{{
                                        srrt.silenceTimeMax
                                      }}秒<span class="defualtScore"
                                        ><span v-if="srrt.increaseDeduction === '1'"
                                          >加</span
                                        ><span v-else>减</span
                                        >{{
                                          srrt.score.toString().replace('-', ' ')
                                        }}分</span
                                      >
                                    </p>
                                  </div>
                                  <div v-else-if="srrt.silenceType === 5">
                                    <span>{{ srrt.keywordContext }}</span>
                                    {{ getKeywordScoreFilter(srrt, scope.row.judge) }}
                                  </div>
                                </div>
                              </div>
                              <div v-else-if="scope.row.judge === 12">
                                <div>
                                  {{
                                    scope.row.resultsObject[0].firstRoleType == 1
                                      ? '坐席:'
                                      : '客户:'
                                  }}
                                  <span
                                    v-html="
                                      getHtml(scope.row.resultsObject[0].firstContext)
                                    "
                                  ></span>
                                </div>
                                <div>
                                  {{
                                    scope.row.resultsObject[0].secondRoleType == 1
                                      ? '坐席:'
                                      : '客户:'
                                  }}
                                  <span
                                    v-html="
                                      getHtml(scope.row.resultsObject[0].secondContext)
                                    "
                                  ></span>
                                </div>
                                <div>
                                  规则:
                                  {{
                                    `${scope.row.resultsObject[0].sentenceCount}句内，${
                                      scope.row.resultsObject[0].isAppear == 1
                                        ? '出现'
                                        : '未出现'
                                    }`
                                  }}<span
                                    v-if="
                                      scope.row.resultsObject[0].sentenceDeadItem == '2'
                                    "
                                    >{{
                                      `${
                                        scope.row.resultsObject[0].increaseDeduction == 1
                                          ? '加'
                                          : '减'
                                      }${scope.row.resultsObject[0].score}分`
                                    }}</span
                                  >
                                </div>
                                <el-popover placement="right" width="120" trigger="hover">
                                  <template
                                    v-if="
                                      scope.row.resultsObject[0].sentenceDeadItem == '1'
                                    "
                                    slot="reference"
                                  >
                                    <i class="el-icon-warning" style="color: red"></i>
                                  </template>
                                  <p>此标准为致命项标准，命中则总分为 0</p>
                                </el-popover>
                              </div>
                              <div v-else-if="scope.row.judge === 13">
                                <div>
                                  意图:
                                  <span
                                    v-html="getContentHtml(scope.row.faqContent)"
                                  ></span>
                                </div>
                                <div
                                  v-for="(item, index) in scope.row.resultsObject"
                                  :key="index"
                                >
                                  <div>
                                    话术:
                                    <span v-html="getContentHtml(item.content)"></span>
                                  </div>
                                  <div>
                                    规则:
                                    {{
                                      `${item.isAppear == 1 ? '出现' : '未出现'}${
                                        item.addsub == 1 ? '加' : '减'
                                      }${item.score}分`
                                    }}
                                  </div>
                                </div>
                              </div>
                              <div v-else>{{ scope.row.normalContent }}</div>
                            </template>
                          </el-table-column>
                          <el-table-column label="得分" width="120">
                            <template scope="scope">
                              <div v-if="normalScored">
                                <span
                                  v-if="scope.row.judge == 5 || scope.row.judge == 11"
                                >
                                  <span v-if="scope.row.resultsObject">
                                    <span
                                      v-if="
                                        (scope.row.resultsObject[0].deadItem === '1') &
                                          (standardsListWithAutoScoreQa[key][scope.$index]
                                            .score ==
                                            '2')
                                      "
                                    >
                                      非致命
                                    </span>
                                    <span
                                      v-else-if="
                                        (scope.row.resultsObject[0].deadItem === '1') &
                                          (standardsListWithAutoScoreQa[key][scope.$index]
                                            .score ==
                                            '1')
                                      "
                                    >
                                      致命
                                    </span>
                                    <span v-else>{{
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .score
                                    }}</span>
                                  </span>
                                </span>
                                <el-select
                                  v-else-if="scope.row.judge == 7"
                                  :disabled="true"
                                  v-model="
                                    standardsListWithAutoScoreQa[key][scope.$index].score
                                  "
                                >
                                  <el-option
                                    v-for="val in scope.row.resultsObject"
                                    :key="val"
                                    :label="val"
                                    :value="val"
                                  >
                                  </el-option>
                                </el-select>
                                <span
                                  v-else-if="
                                    scope.row.judge == 8 &&
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .score == '2'
                                  "
                                  >非致命</span
                                >
                                <span
                                  v-else-if="
                                    scope.row.judge == 8 &&
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .score == '1'
                                  "
                                  >致命</span
                                >
                                <span
                                  v-else-if="
                                    scope.row.judge == 12 &&
                                      scope.row.resultsObject[0].sentenceDeadItem === '1'
                                  "
                                >
                                  <span v-if="scope.row.resultsObject">
                                    <span
                                      v-if="
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score == '2'
                                      "
                                    >
                                      非致命
                                    </span>
                                    <span
                                      v-else-if="
                                        standardsListWithAutoScoreQa[key][scope.$index]
                                          .score == '1'
                                      "
                                    >
                                      致命
                                    </span>
                                  </span>
                                </span>
                                <span v-else>{{
                                  standardsListWithAutoScoreQa[key][scope.$index].score
                                }}</span>
                              </div>
                              <div v-else-if="!normalScored">
                                <div v-if="scope.row.judge == 5 || scope.row.judge == 11">
                                  <div v-if="scope.row.resultsObject">
                                    <el-select
                                      v-if="scope.row.resultsObject[0].deadItem === '1'"
                                      @change="
                                        changeDead(scope.row.newIndex, scope.row.judge)
                                      "
                                      v-model="
                                        currentDistribute[scope.row.newIndex].score
                                      "
                                      placeholder="请选择"
                                      style="width: 95px;"
                                    >
                                      <el-option
                                        v-for="item in deadOptions"
                                        :key="item.value"
                                        :label="item.label"
                                        :value="item.value"
                                      >
                                      </el-option>
                                    </el-select>
                                    <el-input
                                      v-else
                                      v-model.number="
                                        currentDistribute[scope.row.newIndex].score
                                      "
                                      oninput="value=value.replace(/[^-\d]/g,'')"
                                      @blur="
                                        !isClose &&
                                          checkNumber(scope.row.newIndex, scope.row)
                                      "
                                    ></el-input>
                                  </div>
                                </div>
                                <el-input
                                  v-else-if="scope.row.judge == 6"
                                  v-model.number="
                                    currentDistribute[scope.row.newIndex].score
                                  "
                                  oninput="value=value.replace(/[^-\d]/g,'')"
                                  @blur="
                                    checkRange(
                                      currentDistribute[scope.row.newIndex].score,
                                      currentDistribute[scope.row.newIndex].minScoreRange,
                                      currentDistribute[scope.row.newIndex].maxScoreRange
                                    )
                                  "
                                ></el-input>
                                <el-select
                                  v-else-if="scope.row.judge == 7"
                                  v-model="currentDistribute[scope.row.newIndex].score"
                                >
                                  <el-option
                                    v-for="val in scope.row.resultsObject"
                                    :key="val"
                                    :label="val"
                                    :value="val"
                                  >
                                  </el-option>
                                </el-select>
                                <el-select
                                  v-else-if="
                                    scope.row.judge == 8 ||
                                      (scope.row.judge == 12 &&
                                        scope.row.resultsObject[0].sentenceDeadItem ===
                                          '1')
                                  "
                                  @change="
                                    changeDead(scope.row.newIndex, scope.row.judge)
                                  "
                                  v-model="currentDistribute[scope.row.newIndex].score"
                                  placeholder="请选择"
                                  style="width: 95px;"
                                >
                                  <el-option key="1" label="致命" value="1"></el-option>
                                  <el-option key="2" label="非致命" value="2"></el-option>
                                </el-select>
                                <el-input
                                  v-else
                                  v-model.number="
                                    currentDistribute[scope.row.newIndex].score
                                  "
                                  oninput="value=value.replace(/[^-\d]/g,'')"
                                  @blur="
                                    !isClose && checkNumber(scope.row.newIndex, scope.row)
                                  "
                                ></el-input>
                              </div>
                            </template>
                          </el-table-column>
                        </el-table>
                      </div>
                    </div>
                  </div>
                  <div class="standards_part">
                    <div class="standards_part_title">
                      <h3>
                        流程评分
                      </h3>
                      <div class="score">
                        <span>{{ flowScoreFun }}</span>
                      </div>
                    </div>
                    <div style="width: 200px;">
                      <el-select
                        v-model="flowValue"
                        @change="changeFlowOption"
                        :disabled="scored"
                        multiple
                        placeholder="请选择流程"
                      >
                        <el-option
                          v-for="item in flowoptions"
                          :key="item.processId"
                          :label="item.processName"
                          :value="item.processId"
                        >
                        </el-option>
                      </el-select>
                    </div>
                    <div class="standards_detail">
                      <div
                        class="classification_part"
                        v-for="(key, index) in flowListWithScoreQa"
                        :key="index"
                      >
                        <h3>
                          {{ key.processName }}
                        </h3>
                        <div class="classification_detail">
                          <el-table
                            ref="standardsListTable"
                            :data="key.processDetail"
                            max-height="500"
                            border
                            tooltip-effect="dark"
                          >
                            <el-table-column prop="intentName" label="意图">
                            </el-table-column>
                            <el-table-column prop="intentRule" label="规则">
                            </el-table-column>
                            <el-table-column label="得分">
                              <template scope="scope">
                                <div v-if="normalScored">
                                  <span>{{ key.processDetail[scope.$index].score }}</span>
                                </div>
                                <div v-else>
                                  <el-input
                                    v-model.number="
                                      flowListScoreObjs[scope.row.newIndex].score
                                    "
                                    oninput="value=value.replace(/[^-\d]/g,'')"
                                    @blur="checkFlowNumber(scope.row.newIndex, scope.row)"
                                  ></el-input>
                                </div>
                              </template>
                            </el-table-column>
                          </el-table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </template>
          </el-tab-pane>
        </el-tabs>
      </el-col>
    </el-row>
    <el-dialog
      append-to-body
      title="添加案例"
      :visible.sync="showAddCaseDialog"
      :close-on-click-modal="false"
      :before-close="handleCloseAddCaseDialog"
      class="showDialogHeader"
    >
      <el-form
        :model="AddCaseModel"
        ref="AddCaseModel"
        label-width="70px"
        :rules="addCaseRules"
        label-position="left"
      >
        <div class="contentRight">
          <div class="addCaseReason">
            <el-form-item label="添加到" prop="dataType">
              <el-select v-model="AddCaseModel.dataType" placeholder="请选择">
                <el-option
                  v-for="item in dataTree"
                  :key="item.caseClassId"
                  :label="item.className"
                  :value="item.caseClassId"
                  :disabled="item.disabled"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="理由" prop="addCaseReason">
              <el-input
                type="textarea"
                :rows="12"
                placeholder="请输入添加原因"
                v-model="AddCaseModel.addCaseReason"
              >
              </el-input>
            </el-form-item>
          </div>
        </div>
        <el-form-item>
          <div class="btns addCaseReason_btns">
            <el-button @click="handleCloseAddCaseDialog">取消</el-button>
            <el-button type="primary" @click="hasSameCaseThrottle">添加</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import moment from 'moment'
import global from '../../../global.js'
import qs from 'qs'
import vPlayer from '../../common/player.vue'
import formatdate from '../../../utils/formatdate.js'
import cache from '../../../utils/cache'
import throttledMessage from './throttledMessage'
let qualityUrl = global.qualityUrl
let hrmApi = global.hrmApi

export default {
  name: 'recordingPlayCailbratMeet', // 质检校准会翻译是tm calibration meeting
  beforeCreate() {
    this.$message = throttledMessage
  },
  components: {
    vPlayer,
  },
  data() {
    return {
      isShowPlayInfoTooltip: false,
      isEditPlayInfoList: true,
      isShowrefuse: false,
      isShowadopt: false,
      isShoweditCase: false,
      isShowLook: false,
      isShowdelby: false,
      isShowdelete: false,
      isShowclose: false,
      isShowedit: false,
      isShowplus: false,
      isDisabledEdit: false,
      isDisabledPlus: false,
      isShowAnLiGuanLi: false,
      activeName: 'first',
      playInfoVosList: [], // 通话内容列表
      aclOperVo: {},
      value: 4, // 坐席星级
      serviceLabels: [], // 坐席标签
      customInfoModel: {},
      parentModel: {},
      esResultModel: {
        seatStar: 1,
        callSTime: '',
        callETime: '',
      }, // 基本信息
      caseTag: [], // 录音的案例标签
      showQaAppealScore: false,
      showReturnVisitMatchResult: false,
      showQaReconsider: false,
      showCustrmerInfo: false,
      showInitalQaScore: false,
      showQaCalibration: false,
      showQaCalibrationScore: false,
      showInitalQaScoreRead: false,
      showAddCaseDialog: false, // 添加案例
      dataTree: [], // 获取质检员列表
      classifyObject: {}, // 选中的分类
      defaultProps: {
        children: 'listClass',
        label: 'name',
      },
      addClassRules: {
        // 添加案例验证
        name: [
          {
            required: true,
            message: '分类名称不能为空',
            trigger: 'blur',
          },
        ],
      },
      AddCaseModel: {
        dataType: '', // 案例分类
        addCaseReason: '', // 案例弹窗
      },
      addCaseRules: {
        // 添加案例验证
        dataType: [
          {
            required: true,
            message: '请选择分类',
            trigger: 'change',
          },
        ],
        addCaseReason: [
          {
            required: true,
            message: '请输入添加原因',
            trigger: 'blur',
          },
        ],
      },
      returnVisitMatchResult: [],
      minSpeed: 1, // 最慢语速
      maxSpeed: 10, // 最快语速
      times: [], // 对话时间
      editReQaScore: false, // 复检评分
      showReQaScore: false, // 复检得分
      modleTitle: '', // 质检模版名称
      standardsListWithAutoScoreQa: [],
      showQaQualityScore: false,
      showItFilter: false,
      focusWord: '', // 要高亮显示的词
      // 智能筛选高亮词
      focusWordIntell: {
        keyword: '',
        clickIndex: 0,
        fullScriptRole: '',
        targetTimeStart: '',
        targetTimeEnd: '',
      },
      // 智能筛选命中词
      keywordCollection: new Set(),
      keywords: [],
      keys: [], // 其他质检评分的命中关键词
      // 是否第一次点击
      isFirst: true,
      currentClass: '', // 当前正在播放的录音内容所在的盒子的class
      color: ['success', 'warning', 'danger', 'gray'],
      hitWords: {
        '1': [],
        '2': [],
        '0': [],
      }, // 智能筛选命中词
      countHasError: false, // 自动打分修改的是否正确
      editCountKey: '',
      handleContent: '',
      tabChange: '', // 播放器标准成绩与校准评分切换数据存储
      modleId: '',
      testData: {
        ad: '0',
      },
      isAutoDead: '2',
      isDead: '2',
      deadItem: '2',
      deadOptions: [
        {
          value: 1,
          label: '致命',
        },
        {
          value: 2,
          label: '非致命',
        },
      ],
      taskIds: [],
      isDefaultScore: '', // 未选择质检员展示默认成绩
      zjySelect: '', // 质检员model
      zjyOptions: [], // 质检员arr
      scoreDetails: [], // 人工打分table
      filterFaq: [], // 过滤内容质检话术意图命中项
      currentDistribute: [], // 要保存的当前分数列表,自动打分项
      scored: false, // 默认未打分
      normalScored: false, // 是否标准打分
      isScored: false, // 质检员默认未打分
      isNormalTab: false, // 质检主管是否标准打分
      isShowNormalTab: false, // 是否展示标准打分tab
      modelId: '', // 模版ID
      role: '', // 角色
      roleId: '', // 角色ID
      roleNameId: '', // 角色对应Id
      okToSubmit: true, // 是否可以提交
      errorMessage: {}, // 错误信息
      baseScore: 100,
      flowoptions: [],
      flowValue: [],
      flowValueData: [],
      flowListWithScoreQa: [], // 流程对象存储
      flowListScoreObjs: [], // 要保存的当前分数列表，流程评分
      roleCodeId: [],
      mingzhongTip: '此标准为致命项标准，命中则总分为 0',
      isClose: false,
    }
  },
  computed: {
    keywordsHigh() {
      if (this.$store.state.keywordsHigh == null) {
        return ''
      } else {
        return this.$store.state.keywordsHigh.keywords
      }
    },
    accountId() {
      return this.$store.state.loginUserinfo.accountId
    },
    currentTime() {
      return this.$store.state.playerInfo.currentTime * 1000
    },
    callId() {
      return this.$store.state.recordingPlayPage.callId
    },
    calibrateId() {
      return this.$store.state.recordingPlayPage.calibrateId
    },
    calibrateTaskId() {
      return this.$store.state.recordingPlayPage.calibrateTaskId
    },
    taskId() {
      return this.$store.state.recordingPlayPage.taskId
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
    FuyiTask_EndTime() {
      return this.$store.state.recordingPlayPage.FuyiTask_EndTime
    },
    fromUrl() {
      let name = this.$store.state.recordingPlayPage.from
      return name
    },
    fromPage() {
      return this.$store.state.recordingPlayPage.fromPage
    },
    obj() {
      return this.$store.state.recordingPlayPage
    },
    spanFirst() {
      return this.obj.from === 'artificialSample' ||
        this.obj.from === 'caseManage_new' ||
        this.obj.from === 'myColList'
        ? 10
        : 7
    },
    spanSecond() {
      return this.obj.from === 'artificialSample' ||
        this.obj.from === 'caseManage_new' ||
        this.obj.from === 'myColList'
        ? 14
        : 8
    },
    spanThird() {
      return this.obj.from === 'artificialSample' ||
        this.obj.from === 'caseManage_new' ||
        this.obj.from === 'myColList'
        ? 0
        : 9
    },
    qaScoreType() {
      // 初检还是复检
      return this.$store.state.recordingPlayPage.qaScoreType
    },
    isCreator() {
      // 是否可以标准评分
      return this.$store.state.recordingPlayPage.isCreator
    },
    calibrateTaskState() {
      // 质检校准会当前状态，若为3已结束，并且当前是质检员，则不能打分
      return this.$store.state.recordingPlayPage.calibrateTaskState
    },
    flowScoreFun() {
      let total = 0
      let _this = this
      _this.flowListScoreObjs.forEach(function(temp, index) {
        total += parseInt(temp.score) || 0
        if (_this.isDefaultScore) {
          total += parseInt(temp.firstScore) || 0
        }
      })
      console.log(_this.flowListScoreObjs)
      return total
    },
    newTotalScoreFun() {
      let _this = this
      let total = 0
      for (let key in _this.standardsListWithAutoScoreQa) {
        _this.standardsListWithAutoScoreQa[key].forEach((item) => {
          if (item.judge == 8 || item.judge == 6 || item.judge == 7) {
            if (_this.isDefaultScore) {
              total += 0
            } else {
              if (item.judge == 8) {
                // 改为在changeDeadItem中实现
              } else {
                total += parseInt(item.score) || 0
              }
            }
          } else {
            if (item.deadItem !== '1') {
              if (_this.isDefaultScore) {
                if (item.judge == 5 || item.judge == 11) {
                  total += 0
                } else {
                  total += parseInt(item.defaultScore) || 0
                }
              } else {
                total += parseInt(item.score) || 0
              }
            }
          }
        })
      }
      console.info('get isAutoDead2 =' + _this.isAutoDead)
      if (this.flowScoreFun) {
        total += this.flowScoreFun
      }
      if (this.autoScoreFun) {
        total += this.autoScoreFun
      }
      total += this.baseScore
      if (_this.isAutoDead == '1' || _this.isDead == '1') {
        return 0
      }
      return total
    },
    newAutoScoreFun() {
      let _this = this
      let total = 0
      for (let key in _this.standardsListWithAutoScoreQa) {
        _this.standardsListWithAutoScoreQa[key].forEach((item) => {
          if (item.judge == 8 || item.judge == 6 || item.judge == 7) {
            if (_this.isDefaultScore) {
              total += 0
            } else {
              if (item.judge == 8) {
                // 改为在changeDeadItem中实现
              } else {
                total += parseInt(item.score) || 0
              }
            }
          } else {
            if (item.deadItem !== '1') {
              if (_this.isDefaultScore) {
                if (item.judge == 5 || item.judge == 11) {
                  total += 0
                } else {
                  total += parseInt(item.defaultScore) || 0
                }
              } else {
                total += parseInt(item.score) || 0
              }
            }
          }
        })
      }
      if (_this.isAutoDead == '1' || _this.isDead == '1') {
        return 0
      }
      return total
    },
    autoScoreFun() {
      console.info('autoScoreFun change')
      console.info(this.isDefaultScore)
      console.info(this.currentDistribute)
      let total = 0
      let _this = this
      let flag = true
      _this.currentDistribute.forEach(function(item) {
        if (item.judge == 8 || item.judge == 6 || item.judge == 7) {
          if (_this.isDefaultScore) {
            total += 0
          } else {
            if (item.judge == 8) {
              if (item.score == '1') {
                // 如果有一项是致命项则所有的非致命项不能生效
                _this.isDead = '1'
                flag = false
              } else {
                _this.isDead = '2'
              }
            } else {
              total += parseInt(item.score) || 0
            }
          }
        } else {
          if (item.deadItem !== '1') {
            if (_this.isDefaultScore) {
              if (item.judge == 5 || item.judge == 11 || item.judge == 12) {
                total += 0
              } else {
                total += parseInt(item.defaultScore) || 0
              }
            } else {
              total += parseInt(item.score) || 0
            }
          }
        }
      })
      console.info('get isAutoDead2 =' + _this.isAutoDead)
      if (_this.isAutoDead == '1' || _this.isDead == '1') {
        return 0
      }
      return total
    },
    totalScoreFun() {
      console.info('totalScoreFun get isAutoDead = ' + this.isAutoDead)
      if (this.isAutoDead == '1' || this.isDead == '1') {
        this.deadItem = '1'
        return 0
      }
      this.deadItem = '2'
      let totalScore =
        this.baseScore + (this.autoScoreFun + this.flowScoreFun) > 0
          ? this.baseScore + (this.autoScoreFun + this.flowScoreFun)
          : 0
      return totalScore
    },
  },
  created() {
    this.getZGNormalScored(this.obj) // 查看主管是否标准打分
    this.getModalId(this.obj) // 获取模版ID 以及质检员taskID
    this.initActRole() // 获取当前角色
    this.getCaseTag() // 获取录音案例标签
    this.initZjyCailbratMeet() // init质检员校准会
    this.getRoleInfo() // 获取当前登陆人信息
    this.getProcessList() // 获取模版
  },
  mounted() {
    // this.getPlayInfo() // 获取录音文本信息（对话内容)
  },
  methods: {
    init: function() {
      this.activeName = 'first'
      this.isDefaultScore = false
      this.getPlayInfo() // 获取录音文本信息（对话内容）
      this.getZGNormalScored(this.obj) // 查看主管是否标准打分
      this.initScore()
      this.getCaseTag() // 获取录音案例标签
      this.getModalId(this.obj)
      this.initZjyCailbratMeet() // init质检员校准会
      this.getRoleInfo() // 获取当前登陆人信息
      this.isAutoDead = '2'
      this.isDead = '2'
      this.calibrateTaskState = this.obj.calibrateTaskState
    },
    formatJudge(row) {
      let objname = {
        '1': '情绪',
        '2': '重叠次数',
        '3': '静默',
        '4': '语速',
        '5': '关键词',
        '6': '自定义输入',
        '7': '自定义选择',
        '8': '自定义致命',
        '11': '标签',
        '12': '上下文质检',
        '13': '内容质检',
      }
      return objname[row.judge]
    },
    getHtml(flag) {
      let arrAll = flag.split(' ')
      for (let i = 0; i < arrAll.length; i++) {
        if (
          this.esResultModel.correctWholeContent &&
          this.esResultModel.correctWholeContent.includes(arrAll[i].replace(/[(|)]/g, ''))
        ) {
          if (arrAll[i].includes('(')) {
            arrAll[i] = `(<span style='color:#409eff;'>${arrAll[i].replace(
              /[(|)]/g,
              ''
            )}</span>`
          } else if (arrAll[i].includes(')')) {
            arrAll[i] = `<span style='color:#409eff;'>${arrAll[i].replace(
              /[(|)]/g,
              ''
            )}</span>)`
          } else {
            arrAll[i] = `<span style='color:#409eff;'>${arrAll[i]}</span>`
          }
        }
      }
      let endStr = arrAll.toString().replace(/,/g, ' ')
      return endStr
    },
    getContentHtml(flag) {
      if (this.filterFaq.includes(flag)) {
        flag = `<span style='color:#409eff;'>${flag}</span>`
      }
      return flag
    },
    initScore: function() {
      this.currentDistribute = []
    },
    // 致命项得分
    getKeywordScoreFilter(rules, judge) {
      const { roleOptions, positionOptions, positionOptionsText } = global
      const {
        increaseDeduction,
        score,
        isAppear,
        deadItem,
        offset,
        position,
        roleType,
        sceneTime,
        silenceTimeMax,
      } = rules
      let str = ''
      if (deadItem !== '1') {
        let offsetValue = judge === 5 && position != 0 ? `${offset} 句` : ''
        judge === 5
          ? (str = ` 在 ${roleOptions[roleType]}侧 在 ${
              positionOptionsText[position]
            } ${offsetValue} ${isAppear == '1' ? '出现' : '未出现'}${
              increaseDeduction == '2' ? '减' : '加'
            }${score}分`)
          : (str = ` 在${roleOptions[roleType]}侧 在静默时间大于 ${silenceTimeMax} 秒 ${
              positionOptions[position]
            } ${sceneTime} 句 ${isAppear == '1' ? '出现' : '未出现'}${
              increaseDeduction == '2' ? '减' : '加'
            }${score}分`)
      }
      return str
    },
    dateFormat: function(date) {
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // 获取模板列表
    getProcessList() {
      let _this = this
      let url = qualityUrl + '/process/getCalibrateAllProcess.do'
      _this.axios
        .post(url)
        .then(function(response) {
          _this.flowoptions = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '流程获取失败',
          })
        })
    },
    // 选择流程模版
    changeFlowOption(val) {
      let valArr = []
      let _this = this
      this.flowValueData = this.flowValueData.filter(
        (itf) => val.includes(itf.processName) || val.includes(itf.processId)
      )
      for (let i = 0; i < val.length; i++) {
        let itm = val[i]
        let isStatus = _this.flowValueData.some(
          (item) => item.processName == itm || item.processId == itm
        )
        _this.flowoptions.forEach(function(item) {
          if (itm === item.processName) {
            valArr.push({
              processId: item.processId,
              status: isStatus ? 0 : 1,
            })
          } else if (itm === item.processId) {
            valArr.push({
              processId: itm,
              status: isStatus ? 0 : 1,
            })
          }
        })
      }
      this.countHasError = false
      this.errorMsg = ''
      this.flowListScoreObjs = []
      this.flowListWithScoreQa = []
      let url = qualityUrl + '/process/getCalibrateProcessConfigDetails.do'
      let params = {
        processStatusList: JSON.stringify(valArr),
        callId: this.callId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then((res) => {
          if (res.data) {
            let data = res.data
            _this.flowListWithScoreQa = data
            _this.flowValue = []
            data.forEach(function(item) {
              _this.flowValue.push(item.processId)
            })
            let indexT = 0
            for (let i = 0; i < data.length; i++) {
              let obj = _this.flowListWithScoreQa[i].processDetail
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.processId = data[i].processId
                temp.distinctSingle = data[i].distinctSingle
                temp.intentId = item.intentId
                temp.firstScore = item.firstScore
                temp.secondScore = item.secondScore
                temp.thirdScore = item.thirdScore
                temp.scoreMin = item.scoreMin
                temp.scoreMax = item.scoreMax
                temp.processConfigDetailId = item.processConfigDetailId
                temp.intentName = item.intentName
                temp.intentRule = item.intentRule
                temp.processName = data[i].processName
                _this.$set(_this.flowListScoreObjs, indexT, temp)
                indexT++
              })
            }
          }
        })
        .catch(function(e) {
          console.log(e)
          _this.$message({
            type: 'error',
            message: '查询失败',
          })
        })
    },
    // 获取分类树
    getTreeData() {
      let _this = this
      let url = qualityUrl + '/caseManage/getEffectiveTreeData.do'
      let params = {
        objectId: this.callId,
        objectType: ' ',
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.dataTree = response.data
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分类获取失败',
          })
        })
    },
    // 获取案例标签
    getCaseTag() {
      let _this = this
      let url = qualityUrl + '/caseManage/showClassName.do'
      let params = {
        objectId: this.callId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.caseTag = response.data.data.length == 0 ? [] : response.data.data
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分类标签获取失败',
          })
        })
    },
    // init 质检员
    initZjyCailbratMeet: function() {
      this.isShowNormalTab = false
      this.activeName = 'first'
    },
    // 质检员点击查看标准成绩
    showNormalTab: function() {
      this.isShowNormalTab = true
      this.activeName = 'second'
      this.getConditonScore(this.obj, this.modelId)
    },
    // 质检员关闭标准成绩
    closeNormalTab: function(targetName) {
      if (targetName == 'second') {
        this.isShowNormalTab = false
        this.activeName = 'first'
        this.getConditonScore(this.obj, this.modelId)
      }
    },
    // 获取所有质检员
    getAllZjy() {
      let _this = this
      let url = qualityUrl + '/qtctc/queryProgress.do'
      let params = {
        calibrateId: this.calibrateId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.zjyOptions = response.data.Data
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分类标签获取失败',
          })
        })
    },
    handleClick(val) {
      console.log(val.name)
      this.tabChange = val.name
      if (this.isCreator === '0') {
        if (val.name == 'first') {
          this.getModalId(this.obj)
          this.isDefaultScore = false
          if (this.scored) {
            this.normalScored = true
          } else {
            this.normalScored = false
          }
          this.zjySelect = ''
        } else {
          this.isDefaultScore = true
          this.zjySelect = ''
          this.getAllZjy() // 获取所有质检员
          this.getModalId(this.obj)
          this.flowValue = []
          this.flowListScoreObjs = []
          this.flowListWithScoreQa = []
          this.normalScored = true
        }
      } else {
        this.getModalId(this.obj)
      }
      console.log('11111111111111111' + this.isDefaultScore)
    },
    // 初检
    changeDead(index, judge) {
      if (this.currentDistribute[index].score == 1) {
        judge == 5 || judge == 11 || judge == 12
          ? (this.isAutoDead = '1')
          : (this.isDead = '1')
        this.changeDeadItem()
      } else {
        const deadFlag = this.currentDistribute
          .filter((item) => item.judge == 5 || item.judge == 11 || item.judge == 12)
          .some((flag) => flag.score == '1' && flag.deadItem == '1')
        if (deadFlag) {
          this.isAutoDead = '1'
        } else {
          this.isAutoDead = '2'
          this.isDead = '2'
        }
      }
    },
    // 检查致命项，避免在computed里面产生循环
    changeDeadItem() {
      for (let key in this.standardsListWithAutoScoreQa) {
        this.standardsListWithAutoScoreQa[key].forEach((item) => {
          if (item.judge == 8) {
            // 如果有一项是致命项则所有的非致命项不能生效
            if (item.score == '1') {
              this.isDead = '1'
            } else {
              this.isDead = '2'
            }
          }
        })
      }
    },
    showhighlightscore(keys) {
      this.keys = keys
    },
    // 获取角色与角色ID
    initActRole() {
      let codes = cache.getItem('roleInfo')
      this.roleCodeId = codes.split(',')
      console.log(this.roleCodeId)
    },
    getKeyWordsAndHighLight(keywords) {
      this.keywords = keywords
    },
    // 时间转化
    fromData: function(data) {
      let newData = new Date(data)
      let m = newData.getMonth()
      let d = newData.getDay()
      return m + '-' + d
    },
    // 获取开始时间和结束时间，保存到vuex中
    playClip(startTime, endTime) {
      let playInfo = {}
      playInfo.timeSection = [startTime, endTime]
      this.$store.commit('setPlayerInfo', playInfo)
    },
    // 高亮关键词
    hightlightContent(word) {
      this.focusWord = word
    },
    hightlightContentIntell(word) {
      this.focusWordIntell = word
    },
    // 智能筛选的质检分数中设置高亮词 role为custom=>客户，agent=> 客服
    highlightWord(val, oldval, fullScriptRole) {
      let selector = ''
      if (parseInt(fullScriptRole) === 1) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(fullScriptRole) === 2) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let _this = this
      val = val.trim()
      oldval = oldval.trim() || ''
      let elesSelector = document.querySelectorAll(selector)
      if (elesSelector.length === 0) {
        return
      } else {
        elesSelector.forEach(function(item) {
          // 当要高亮显示的文字变化时，先清空原来的高亮
          if (oldval) {
            // 去掉原先的高亮，不能直接用oldval替换，oldval的值有可能是查询条件的值，比如‘你好 or 您好’
            item.innerHTML = item.innerText
            // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, oldval)
          }
          if (val) {
            // 多个高亮
            let keywordArray = val.split(' ')
            keywordArray.forEach(function(keyword) {
              if (keyword != '' && item.innerHTML.indexOf(keyword) != -1) {
                item.innerHTML = item.innerHTML.replace(
                  new RegExp(keyword, 'gm'),
                  '<span style="color: red">' + keyword + '</span>'
                )
                if (
                  _this.hitWords[fullScriptRole] &&
                  _this.hitWords[fullScriptRole].indexOf(keyword) <= 0
                ) {
                  _this.hitWords[fullScriptRole].push(keyword)
                }
              }
            })
          }
        })
      }
    },
    // 智能筛选页面刚刚进来的时候要把所有符合条件的关键词都标红
    highlightWordAll(val) {
      let selector = ''
      if (parseInt(val.fullScriptRole) === 1) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 2) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let eles = document.querySelectorAll(selector)
      if (!eles || eles.length === 0) {
        return
      } else {
        eles.forEach(function(item) {
          let className = item.parentElement.className.split(' ')
          let startTime = parseInt(className[1].substr(1).trim())
          let endTime = parseInt(className[2].substr(1).trim())
          if (!(startTime <= val.targetTimeEnd && endTime >= val.targetTimeStart)) {
            return
          }
          if (item.innerHTML.indexOf(val.keyword) != -1) {
            item.innerHTML = item.innerHTML.replace(
              new RegExp(val.keyword, 'gm'),
              '<span style="color: red">' + val.keyword + '</span>'
            )
          }
        })
      }
    },
    // 检查当前分配输入的是否是数字并且是否输入
    checkFlowNumber(index, row) {
      if (
        typeof +this.flowListScoreObjs[index].score !== 'number' ||
        Number.isNaN(+this.flowListScoreObjs[index].score)
      ) {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
        this.countHasError = true
        this.errorMsg = '请输入数字'
        return false
      } else if (
        this.flowListScoreObjs[index].score > row.scoreMax ||
        this.flowListScoreObjs[index].score < row.scoreMin
      ) {
        console.log(row.scoreMin)
        this.$message({
          type: 'error',
          message: '分值范围为' + row.scoreMin + '~' + row.scoreMax,
        })
        event.target.focus()
        this.countHasError = true
        return false
      } else {
        this.countHasError = false
      }
    },
    // 初检检查当前分配输入的是否是数字
    checkNumber(index, obj) {
      this.countHasError = false
      let arr = []
      if (typeof obj.minScoreRange === 'number' && !Number.isNaN(obj.minScoreRange)) {
        arr.push(obj.minScoreRange)
      } else {
        arr.push(0)
      }
      if (typeof obj.maxScoreRange === 'number' && !Number.isNaN(obj.maxScoreRange)) {
        arr.push(obj.maxScoreRange)
      }
      if (typeof obj.defaultScore === 'number' && !Number.isNaN(obj.defaultScore)) {
        arr.push(obj.defaultScore)
      }
      arr.sort(function(a, b) {
        return a - b
      })
      let min = arr[0] > obj.defaultScore ? obj.defaultScore : arr[0]
      let max =
        arr[arr.length - 1] < obj.defaultScore ? obj.defaultScore : arr[arr.length - 1]
      // 设置自动评分的致命项
      if (obj.resultsObject[0].deadItem == '1') {
        // 致命项只能打分0/1
        min = 0
        max = 1
        if (
          obj.resultsObject[0].deadItem == '1' &&
          this.currentDistribute[index].score <= 0
        ) {
          this.isAutoDead = '1'
        } else {
          this.isAutoDead = '2'
        }
      }
      if (this.currentDistribute[index].score === '') {
        this.countHasError = true
      }
      if (
        typeof +this.currentDistribute[index].score !== 'number' ||
        Number.isNaN(+this.currentDistribute[index].score)
      ) {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
        this.countHasError = true
        return false
      } else if (
        (this.currentDistribute[index].score != '' &&
          this.currentDistribute[index].score < min) ||
        (this.currentDistribute[index].score != '' &&
          this.currentDistribute[index].score > max)
      ) {
        this.$message({
          type: 'error',
          message: '分值范围为' + min + '~' + max,
        })
        event.target.focus()
        this.countHasError = true
        return false
      }
    },
    checkRange(val, min, max) {
      if (isNaN(val)) {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
      } else if (val === '') {
        this.countHasError = true
      } else if (val < min || val > max) {
        this.$message({
          type: 'error',
          message: '分值范围为' + min + '~' + max,
        })
        event.target.focus()
      }
    },
    // 播放器缩小
    minimizePage() {
      this.volumeControl = false
      let playInfo = {}
      playInfo.isMaximization = false
      this.isPlayinfo = playInfo.isclosedialog
      let taskId = this.$store.state.returnVisitConfig.taskId
      let projectId = this.$store.state.returnVisitConfig.projectId
      let matchRecordCount = this.$store.state.returnVisitConfig.matchRecordCount
      let allRecordCount = this.$store.state.returnVisitConfig.allRecordCount
      let matchRatio = this.$store.state.returnVisitConfig.matchRatio
      let obj = {
        taskId: taskId,
        showTaskResult: true,
        showDetailPage: true,
        projectId: projectId,
        matchRecordCount: matchRecordCount,
        allRecordCount: allRecordCount,
        matchRatio: matchRatio,
      }
      this.$store.commit('setTaskResult', obj)
      this.$store.commit('setPlayerInfo', playInfo)
      this.$emit('onminimize', playInfo)
    },
    // 播放器关闭
    closePage() {
      this.isClose = true
      let _this = this
      this.$confirm('关闭界面将停止录音播放，确定关闭么', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let playInfo = {}
          playInfo.isMaximization = false
          playInfo.exist = false
          // let url = _this.fromPage || 'home'
          let taskId = _this.$store.state.returnVisitConfig.taskId
          let projectId = _this.$store.state.returnVisitConfig.projectId
          let matchRecordCount = _this.$store.state.returnVisitConfig.matchRecordCount
          let allRecordCount = _this.$store.state.returnVisitConfig.allRecordCount
          let matchRatio = _this.$store.state.returnVisitConfig.matchRatio
          let obj = {
            taskId: taskId,
            showTaskResult: true,
            showDetailPage: true,
            projectId: projectId,
            matchRecordCount: matchRecordCount,
            allRecordCount: allRecordCount,
            matchRatio: matchRatio,
          }
          _this.$store.commit('setTaskResult', obj)
          _this.$store.commit('setPlayerInfo', playInfo)
          _this.focusWord = ''
          _this.keywords = []
          _this.keys = []
          _this.parentModel = {}
          this.$emit('onclose')
          setTimeout(() => {
            this.isClose = false
          }, 500)
        })
        .catch(() => {
          this.isClose = false
        })
    },
    test() {
      // 停止正在进行的动画  减少卡顿感
      $('.dialog').stop(true, false)
      if (window.myinterVal) {
        return
      } else {
        window.myinterVal = 5
      }
      setTimeout(function() {
        window.myinterVal = 0
      }, 5000)
      // 清除计时任务
      // 3秒后重新
    },
    // 获取modalId ,获取taskId
    getModalId(obj) {
      let _this = this
      let url = global.qualityUrl + '/qtctc/getQaUserAndTaskIdAndModelId.do'
      let params = {}
      params.calibrateId = obj.calibrateId
      params.calibrateTapId = obj.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.modelId = response.data.ModelId // 模版id
          _this.getConditonScore(_this.obj, _this.modelId)
          _this.taskIds = response.data.TaskId // 质检员对应的taskId
          _this.getBaseScore(_this.modelId, _this.callId, obj.calibrateId)
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取失败',
          })
        })
    },
    // 获取基准分
    getBaseScore(modelId, callId, calibrateId) {
      let _this = this
      let params = {
        callId: callId,
        moduleId: modelId,
        calibrateId: calibrateId,
      }
      let url = qualityUrl + '/qaDetail/getBaseScoreToJiaoZhun.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.baseScore = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取基准分失败',
          })
        })
    },
    // 获取当前角色的 id和taskId
    getRoleInfo() {
      let _this = this
      let url = global.qualityUrl + '/csc/getUsername.do'
      let params = {}
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.roleNameId = response.data
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取失败',
          })
        })
    },
    // 获取质检主管是否提交标准成绩
    getZGNormalScored(obj) {
      let _this = this
      let url = global.qualityUrl + '/qtctc/queryNormalScore.do'
      let params = {
        calibrateId: obj.calibrateId,
        calibrateTapId: obj.callId,
      }
      // params.taskId = obj.taskId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.normalScored = true
            _this.isNormalTab = true
          } else {
            _this.normalScored = false
            _this.isNormalTab = false
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取失败',
          })
        })
    },
    // 获取当前流程ID和模版信息
    getFlowIds() {
      let _this = this
      let params = {
        callId: this.callId,
        qaScoreType: this.qaScoreType,
      }
      this.axios
        .post(qualityUrl + '/process/queryProcessDetailByCallId.do', qs.stringify(params))
        .then((res) => {
          if (res.data) {
            let data = res.data
            _this.flowListWithScoreQa = data
            _this.flowValue = []
            _this.flowValueData = []
            data.forEach(function(item) {
              _this.flowValue.push(item.processName)
              _this.flowValueData.push({
                processName: item.processName,
                processId: item.processId,
              })
            })
            let indexT = 0
            for (let i = 0; i < data.length; i++) {
              let obj = _this.flowListWithScoreQa[i].processDetail
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.processId = data[i].processId
                temp.intentId = item.intentId
                temp.score = item.score || ''
                temp.firstScore = item.firstScore || ''
                temp.secondScore = item.secondScore || ''
                temp.thirdScore = item.thirdScore || ''
                temp.fourthScore = item.fourthScore || ''
                temp.intentName = item.intentName
                temp.intentRule = item.intentRule
                temp.processName = data[i].processName
                _this.$set(_this.flowListScoreObjs, indexT, temp)
                indexT++
              })
            }
          }
        })
        .catch(function(e) {
          console.log(e)
        })
    },
    // 获取标准模版
    getConditonScore(obj, modelId) {
      let _this = this
      let url = global.qualityUrl + '/manualQualityAssurance/yulanModleInfoScore.do'
      let params = {
        calibrateId: obj.calibrateId,
        modleId: modelId,
      }
      _this.standardsListWithAutoScoreQa = []
      _this.currentDistribute = []
      this.axios.post(url, qs.stringify(params)).then(function(response) {
        _this.standardsListWithAutoScoreQa = response.data.dataT // 有层级关系自动评分
        _this.modleTitle = response.data.modle.modleTitle // 模版名称
        _this.modelId = response.data.modle.modleId // 模版id
        _this.getPlayInfo()
        let indexT = 0
        for (let key in _this.standardsListWithAutoScoreQa) {
          let obj = _this.standardsListWithAutoScoreQa[key]
          obj.forEach(function(item, index) {
            item.newIndex = indexT
            let temp = {}
            temp.normalId = item.normalId
            temp.judge = item.judge
            temp.defaultScore = item.defaultScore
            temp.score = item.score
            if (item.judge === 5 || item.judge === 11) {
              temp.deadItem = item.resultsObject[0].deadItem
              if (temp.deadItem == '1') {
                // 默认分数特殊处理，在建评分模板时，deaditem =1 时，默认是非致命 = 1，故此处要强制把 非致命改成2
                item.score = item.score ? item.score : 2
                temp.score = item.score
              }
            } else if (item.judge === 12) {
              temp.deadItem = item.resultsObject[0].sentenceDeadItem
              if (temp.deadItem == '1') {
                // 默认分数特殊处理，在建评分模板时，sentenceDeadItem =1 时，默认是非致命 = 1，故此处要强制把 非致命改成2
                item.score = item.score ? item.score : '2'
                temp.score = item.score
              }
            } else if (item.judge === 7 && _this.checkArrayType(item.resultsObject)) {
              temp.score = item.resultsObject[0]
            } else if (item.judge === 8) {
              item.score = item.score || '2'
              temp.score = item.score
            } else {
              temp.deadItem = '2'
            }
            _this.$set(_this.currentDistribute, indexT, temp)
            indexT++
          })
        }
        if (_this.roleCodeId.includes('qa')) {
          // 质检员 并且未制定标准成绩
          if (_this.isCreator == 1) {
            // 校准评分
            if (_this.activeName != 'second') {
              _this.getZjyScore(obj, _this.roleNameId, _this.calibrateTaskId)
            } else {
              _this.getAllScore(_this.obj)
              _this.normalScored = true
            } // ghl2018830质检主管&&质检员
            if (response.data.status == 'false') {
              // 是否质检状态
              _this.scored = false
              if (_this.isCreator == '1' && _this.calibrateTaskState == '3') {
                _this.isDefaultScore = true
              }
            } else {
              _this.scored = true
              _this.isDefaultScore = false
            }
          } else if (_this.isCreator == 0) {
            if (_this.activeName != 'second') {
              _this.getAllScore(_this.obj)
            }
          }
        } else {
          if (_this.activeName != 'second') {
            _this.getAllScore(_this.obj)
          }
        }
      })
    },
    // 获取标准分数
    getAllScore(obj) {
      let _this = this
      _this.flowListWithScoreQa = []
      _this.flowListScoreObjs = []
      let url = global.qualityUrl + '/qtctc/getIvsQaCalibrateScoreNormal.do'
      let params = {
        calibrateId: obj.calibrateId,
        calibrateTapId: obj.callId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.Data) {
            _this.normalScored = true
          } else {
            _this.normalScored = false
          }
          // 获取内容质检意图与话术的命中词
          _this.filterFaq = []
            .concat(
              ...response.data.Detail.map((item) => {
                return item.contents ? item.contents : []
              })
            )
            .filter((flag) => flag.status === 1)
            .map((val) => val.content)
          let data = response.data.processScore
          // 如果获取到了数据则赋值
          if (response.data && response.data.Detail) {
            _this.scoreDetails = response.data.Detail
            console.log(_this.scoreDetails)
            // 如果是初检页面，则给编辑界面的值赋值
            _this.changData(_this.scoreDetails)
          }
          _this.flowValue = []
          if (!(_this.isCreator == '0' && _this.activeName == 'second')) {
            // if ((_this.activeName == 'second' && _this.role.indexOf('质检员') !== -1) || _this.tabChange != 'second') {
            _this.flowListWithScoreQa = response.data.processScore
            response.data.processIdList.forEach(function(item) {
              _this.flowValue.push(item.processName)
            })
            if (response.data.Data) {
              _this.scored = true
            } else {
              _this.scored = false
            }
            let indexT = 0
            for (let i = 0; i < data.length; i++) {
              let obj = _this.flowListWithScoreQa[i].processDetail
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.processId = data[i].processId
                temp.distinctSingle = data[i].distinctSingle
                temp.intentId = item.intentId
                temp.firstScore = item.firstScore
                temp.secondScore = item.secondScore
                temp.thirdScore = item.thirdScore
                temp.scoreMin = item.scoreMin
                temp.scoreMax = item.scoreMax
                temp.score = item.score || ''
                temp.processConfigDetailId = item.processConfigDetailId
                temp.intentName = item.intentName
                temp.intentRule = item.intentRule
                temp.processName = data[i].processName
                _this.$set(_this.flowListScoreObjs, indexT, temp)
                indexT++
              })
            }
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数获取失败',
          })
        })
    },
    // 获取质检员分数
    getZjyScore(obj, qaUser, calibrateTaskId) {
      let _this = this
      _this.flowListWithScoreQa = []
      _this.flowListScoreObjs = []
      let url = global.qualityUrl + '/qtctc/getScoreAndDetailByUser.do'
      let params = {
        calibrateId: obj.calibrateId,
        qaUser: qaUser,
        calibrateTapId: obj.callId,
        calibrateTaskId: calibrateTaskId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.Score) {
            _this.scored = true
          } else {
            _this.scored = false
          }
          // 获取内容质检意图与话术的命中词
          _this.filterFaq = []
            .concat(
              ...response.data.ScoreDetail.map((item) => {
                return item.contents ? item.contents : []
              })
            )
            .filter((flag) => flag.status === 1)
            .map((val) => val.content)
          let data = response.data.processScore
          // 如果获取到了数据则赋值
          if (response.data && response.data.ScoreDetail) {
            _this.scoreDetails = response.data.ScoreDetail
            // 如果是初检页面，则给编辑界面的值赋值
            _this.changData(_this.scoreDetails)
          }
          _this.flowValue = []
          _this.flowListWithScoreQa = response.data.processScore
          response.data.processIdList.forEach(function(item) {
            _this.flowValue.push(item.processName)
          })
          let indexT = 0
          for (let i = 0; i < data.length; i++) {
            let obj = _this.flowListWithScoreQa[i].processDetail
            obj.forEach(function(item, index) {
              item.newIndex = indexT
              let temp = {}
              temp.processId = data[i].processId
              temp.distinctSingle = data[i].distinctSingle
              temp.intentId = item.intentId
              temp.firstScore = item.firstScore
              temp.secondScore = item.secondScore
              temp.thirdScore = item.thirdScore
              temp.scoreMin = item.scoreMin
              temp.scoreMax = item.scoreMax
              temp.score = item.score || ''
              temp.processConfigDetailId = item.processConfigDetailId
              temp.intentName = item.intentName
              temp.intentRule = item.intentRule
              temp.processName = data[i].processName
              _this.$set(_this.flowListScoreObjs, indexT, temp)
              indexT++
            })
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数获取失败',
          })
        })
    },
    // 获取当前质检员
    changeZjy(val) {
      let calibrateTaskId = ''
      this.taskIds.forEach(function(item) {
        if (item.id == val) {
          calibrateTaskId = item.taskId
        }
      })
      this.isDefaultScore = false
      this.getZjyScore(this.obj, val, calibrateTaskId)
    },
    // 根据获取的分数修改模板内容
    changData(scoreDetails) {
      let _this = this
      scoreDetails.forEach(function(item) {
        console.info('has scoreDetails')
        // let isFind = false
        // let indexT = 0

        for (let key in _this.standardsListWithAutoScoreQa) {
          _this.standardsListWithAutoScoreQa[key].forEach(function(itm) {
            if (itm.normalId == item.normalId) {
              let obj = {}
              itm.score = item.score == null ? '' : parseInt(item.score)
              if (itm.deadItem === '1') {
                if (itm.score == 0) {
                  _this.isAutoDead = '1'
                }
              }
              if (itm.judge === 5 || itm.judge === 11) {
                itm.deadItem = itm.resultsObject[0].deadItem
              } else if (itm.judge === 12) {
                itm.deadItem = itm.resultsObject[0].sentenceDeadItem
              } else if (itm.judge === 7) {
                if (item.optioniItem !== null && item.optioniItem !== 0) {
                  itm.score = item.optioniItem
                } else {
                  itm.score = item.score || '2'
                  itm.defaultScore = item.defaultScore
                }
                if (_this.checkArrayType(itm.resultsObject)) {
                  obj.score = itm.score || itm.resultsObject[0]
                }
              } else if (itm.judge === 8 && item.optioniItem == '1') {
                // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                _this.isDead = '1'
              } else {
                itm.deadItem = '2'
              }
              for (let key in itm) {
                obj[key] = itm[key]
              }
              _this.currentDistribute[itm.newIndex] = obj
              // _this.$set(_this.currentDistribute, itm.newIndex, obj)
            }
          })
        }
      })
    },
    // 判断数组元素是否都可以转为数字
    checkArrayType(arr) {
      return arr.every(function(val, index, arr) {
        let temp = +val
        return typeof temp === 'number' && !Number.isNaN(temp)
      })
    },
    // 命中场景 点击按钮
    playOccurrence(keywordItem) {
      this.$emit('clickhighlightkeys', keywordItem)
    },
    // 主管打分
    zgSubmitScore() {
      this.submitScore() // 质检主管标准打分
    },
    // 质检员打分
    zjySubmitScore() {
      this.submitZjyScore() // 质检员校准打分
    },
    // 质检主管标准打分
    submitScore() {
      // 提交分数
      if (this.countHasError) {
        this.$message({
          type: 'error',
          message: '请将打分项填写完整',
        })
      } else {
        let _this = this
        let url = global.qualityUrl + '/qtctc/gbCalibrateProcessScore.do'
        let result = []
        this.currentDistribute.forEach(function(temp, index) {
          _this.isScoreNull(temp.score)
          if (temp.judge == 8) {
            temp.optioniItem = temp.score.toString().trim()
          }
          temp.score = temp.score.toString().trim()
        })
        result = result.concat(_this.currentDistribute)
        let params = {}
        let deadItem
        if (this.isDead == '2' && this.isAutoDead == '2') {
          deadItem = '2'
        } else {
          deadItem = '1'
        }
        params.listScoreDetail = JSON.stringify(result) // 模板
        params.modelId = this.modelId
        params.socre = this.totalScoreFun
        params.calibrateTapId = this.callId
        params.calibrateId = this.calibrateId
        params.calibrateTaskId = this.calibrateTaskId
        params.comments = this.handleContent // 处理内容
        params.qaedUser = this.esResultModel.seatNo
        params.deadItem = deadItem
        params.listProcessScore = JSON.stringify(this.flowListScoreObjs) // 流程
        // 如果有错误，则不提交，并展示错误
        if (!_this.okToSubmit) {
          _this.$message(_this.errorMessage)
          return
        }
        if (_this.countHasError) {
          _this.$message({
            type: 'error',
            message: '请将打分项填写完整',
          })
        } else {
          this.axios
            .post(url, qs.stringify(params))
            .then(function(response) {
              if (response.data) {
                _this.$message({
                  type: 'success',
                  message: '打分成功',
                })
                _this.getConditonScore(_this.obj, _this.modelId)
                _this.normalScored = true
              } else {
                return Promise.reject()
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '分数提交失败',
              })
            })
        }
      }
    },
    // 质检员校准打分
    submitZjyScore() {
      // 提交分数
      if (this.countHasError) {
        this.$message({
          type: 'error',
          message: '请将打分项填写完整',
        })
      } else {
        let _this = this
        let url = global.qualityUrl + '/qtctc/insertCalibrateScoreAndDetail.do'
        let result = []
        this.currentDistribute.forEach(function(temp, index) {
          _this.isScoreNull(temp.score)
          if (temp.judge == 7) {
            temp.optioniItem = temp.score.toString().trim()
            temp.score = ''
            return
          } else if (temp.judge == 8) {
            temp.optioniItem = temp.score.toString().trim()
          }
          temp.score = temp.score.toString().trim()
        })
        result = result.concat(_this.currentDistribute)
        console.info(result)
        let params = {}
        let deadItem
        if (this.isDead == '2' && this.isAutoDead == '2') {
          deadItem = '2'
        } else {
          deadItem = '1'
        }
        params.listScoreDetail = JSON.stringify(result)
        params.modelId = this.modelId
        params.socre = this.totalScoreFun
        params.calibrateTapId = this.callId
        params.calibrateId = this.calibrateId
        params.calibrateTaskId = this.calibrateTaskId
        params.comments = this.handleContent // 处理内容
        params.qaedUser = this.esResultModel.seatNo
        params.deadItem = deadItem
        params.listProcessScore = JSON.stringify(this.flowListScoreObjs)
        // 如果有错误，则不提交，并展示错误
        if (!_this.okToSubmit) {
          _this.$message(_this.errorMessage)
          return
        }
        if (_this.countHasError) {
          _this.$message({
            type: 'error',
            message: '请将打分项填写完整',
          })
        } else {
          this.axios
            .post(url, qs.stringify(params))
            .then(function(response) {
              if (response.data) {
                _this.$message({
                  type: 'success',
                  message: '打分成功',
                })
                _this.getConditonScore(_this.obj, _this.modelId)
                _this.scored = true
              } else {
                return Promise.reject()
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '分数提交失败',
              })
            })
        }
      }
    },
    // 判断分数是否为空
    isScoreNull(val) {
      if (val === null || val === '' || val === undefined) {
        this.countHasError = true
      }
    },
    // 获取录音信息
    getPlayInfo() {
      // 将播放器重置为录音播放器
      let _this = this
      let url = qualityUrl + '/speechFeature/getPlayInfo.do'
      let params = {}
      params.callId = this.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.serviceLabels = response.data.serviceLabels
            _this.customInfoModel = response.data.customerLabels
            _this.playInfoVosList = response.data.playInfoVosList
            _this.judgePlayInfoList(_this.playInfoVosList)
            _this.insertSort(_this.playInfoVosList)
            // 过滤出上下文质检与内容质检的数据
            _this.filterContentData()
            _this.times = []
            _this.playInfoVosList.forEach(function(item) {
              _this.times.push(item.startTime)
              _this.times.push(item.endTime)
            })
            _this.$store.commit('setVoiceDetal', _this.playInfoVosList)
            _this.voiceTotalTime = response.data.voiceTotalTime
            _this.esResultModel = response.data.esResultModel
            _this.aclOperVo = response.data.aclOperVo
            _this.minSpeed = response.data.minSpeead
            _this.maxSpeed = response.data.maxSpeed
            let playInfo = {}
            playInfo.voiceTotalTime = _this.voiceTotalTime
            _this.$nextTick(function() {
              _this.$store.commit('setPlayerInfo', playInfo)
              _this.hightlightContent(_this.keywordsHigh) // 获取高亮文本
            })
          } else {
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '录音信息获取失败',
          })
        })
    },
    // 录音修改文本 设置toolTip
    playShowToolTip(e, item) {
      var target = e.currentTarget
      if (target) {
        if (item.text.replace(/<[^>]+>/g, '').trim() == item.originalText.trim()) {
          if (item.needCorrect) {
            if (item.text.replace(/<[^>]+>/g, '').trim() !== item.correctText.trim()) {
              this.isShowPlayInfoTooltip = false
            } else {
              this.isShowPlayInfoTooltip = true
            }
          } else {
            this.isShowPlayInfoTooltip = true
          }
        } else {
          this.isShowPlayInfoTooltip = false
        }
      } else {
        this.isShowPlayInfoTooltip = true
      }
    },
    // 提交修改文本
    submitPlayInfoList(val) {
      // isEditPlayInfoList===true 修改文本
      // isEditPlayInfoList===false 保存
      if (val == '1') {
        // 点击文本修改
        this.isEditPlayInfoList = !this.isEditPlayInfoList
      } else {
        let newVoiceList = this.playInfoVosList.filter((item) => {
          return item.role != 'UNK'
        })
        for (var i = 0; i < newVoiceList.length; i++) {
          let item = newVoiceList[i]
          item.text = item.changeText
        }
        // 点击保存
        let jsonStr = JSON.stringify(newVoiceList)
        let params = {
          callId: this.callId,
          json: jsonStr,
        }
        this.axios
          .post(qualityUrl + '/speechFeature/updateContent.do', qs.stringify(params))
          .then((res) => {
            if (res.data) {
              this.isEditPlayInfoList = true
              this.getPlayInfo()
            } else {
              this.$message.error('提交失败')
            }
          })
          .catch((err) => console.log(err))
      }
    },
    // 判断文本是否修改
    judgePlayInfoList(data) {
      let _this = this
      for (var i = 0; i < data.length; i++) {
        let item = data[i]
        if (item.role == 'UNK' || !item.originalText) {
          return
        }
        _this.$set(item, 'changeText', item.text)
        if (item.text.trim() == item.originalText.trim()) {
          if (item.needCorrect) {
            if (item.text.trim() !== item.correctText.trim()) {
              _this.$set(item, 'changeText', item.correctText)
              item.text =
                '<span style="text-decoration:underline">' + item.correctText + '</span>'
            }
          }
        } else {
          item.text = '<span style="text-decoration:underline">' + item.text + '</span>'
        }
      }
    },
    filterContentData() {
      // 过滤上下文质检关键字
      const conTextList = []
        .concat(...Object.values(this.standardsListWithAutoScoreQa))
        .filter((item) => item.judge == 12)
        .map((item) => {
          return (
            item.resultsObject[0].firstContext + ' ' + item.resultsObject[0].secondContext
          )
        })
      let keyWordContent = conTextList.length == 0 ? [] : conTextList.join(' ').split(' ')
      // 过滤内容质检话术关键词
      const contextObject = [].concat(
        ...this.scoreDetails.map((flag) => {
          return flag.matchDialogs ? flag.matchDialogs : []
        })
      )
      keyWordContent = [...contextObject, ...keyWordContent]
      console.log(keyWordContent)
      this.setPlayInfoList(this.playInfoVosList, keyWordContent)
    },
    setPlayInfoList(data, keyWordContent) {
      for (let i = 0; i < data.length; i++) {
        let item = data[i]
        if (keyWordContent && keyWordContent.length > 0) {
          for (let y = 0; y < keyWordContent.length; y++) {
            item.text = item.text.replace(
              keyWordContent[y].replace(/[(|)]/g, ''),
              `<font style=color:#409eff;>${keyWordContent[y].replace(
                /[(|)]/g,
                ''
              )}</font>`
            )
          }
        }
      }
    },
    isShowSpeedFlag(speed) {
      if (speed == '') {
        return false
      } else {
        if (speed > this.maxSpeed || speed < this.minSpeed) {
          return true
        } else {
          return false
        }
      }
    },
    // 对话列表的class
    classes(role, startTime, endTime) {
      let active = ''
      if (+this.currentClass === +startTime || +this.currentClass === +endTime) {
        active = 'currentClass'
      }
      if (role == 2) {
        return 'custom_content _' + startTime + ' _' + endTime + ' ' + active
      } else if (role == 1) {
        return 'agent_content _' + startTime + ' _' + endTime + ' ' + active
      } else {
        return 'UNK _' + startTime
      }
    },
    // 调整滚动条位置， scrollTop = offsetTop + 偏移
    scrollDialog(seconds) {
      let liClass = '._' + seconds
      let ele = document.querySelector(liClass)
      if (ele) {
        let offsetTop = ele.offsetTop
        if (offsetTop < 20) {
          // dialog有10pxpadding
          document.querySelector('.dialog').scrollTop = 0
        } else {
          // document.querySelector('.dialog').scrollTop = offsetTop + 20
          $('.dialog').animate(
            {
              scrollTop: offsetTop - document.querySelector('.dialog').clientHeight / 3,
            },
            500
          )
        }
      }
    },
    // 查找距离当前时间最近的对话内容所在的区域的class， 二分查找
    findCurrentMessage(seconds) {
      if (this.times.indexOf(seconds) != -1) {
        return seconds
      } else if (seconds < this.times[0]) {
        return this.times[0]
      } else if (seconds > this.times[this.times.length - 1]) {
        return this.times[this.times.length - 1]
      } else {
        let low = 0
        let high = this.times.length - 1
        let closeData = ''
        let diff = 0
        while (low <= high) {
          let mid = parseInt((high + low) / 2)
          if (seconds > this.times[mid]) {
            low = mid + 1
            if (diff == 0) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            } else if (Math.abs(this.times[mid] - seconds) < Math.abs(diff)) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            }
          } else if (seconds < this.times[mid]) {
            high = mid - 1
            if (diff == 0) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            } else if (Math.abs(this.times[mid] - seconds) < Math.abs(diff)) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            }
          } else {
            return this.times[mid]
          }
        }
        return closeData
      }
    },
    // 插入排序
    insertSort(arr) {
      if (Object.prototype.toString.call(arr) !== '[object Array]') {
        return false
      }
      for (let i = 1; i < arr.length; i++) {
        let j = i
        let temp = arr[i]
        while (j > 0 && parseInt(temp.startTime) < parseInt(arr[j - 1].startTime)) {
          arr[j] = arr[--j]
        }
        arr[j] = temp
      }
    },
    playOccurrence_intelligent(keywordItem) {
      // console.log(keywordItem)
      // 单独高亮显示本次关键词的结果
      this.hightlightContentIntell(keywordItem)
      let self = this
      let selectedMsg = null // 当前消息
      let selectedIndex = 0 // 当前匹配的消息数
      let pipeiMsgCount = 0 // 可匹配的消息总数

      // 1.获取此关键字所有的消息数
      self.playInfoVosList.forEach((item) => {
        if (
          parseInt(item.startTime) <= parseInt(keywordItem.targetTimeEnd) &&
          parseInt(item.endTime) >= parseInt(keywordItem.targetTimeStart)
        ) {
          if (parseInt(keywordItem.fullScriptRole) === 1) {
            if (item.role == '1' && item.text.indexOf(keywordItem.keyword) >= 0) {
              pipeiMsgCount++
            }
          } else if (parseInt(keywordItem.fullScriptRole) === 2) {
            if (item.role == '2' && item.text.indexOf(keywordItem.keyword) >= 0) {
              pipeiMsgCount++
            }
          } else {
            if (item.text.indexOf(keywordItem.keyword) >= 0) {
              pipeiMsgCount++
            }
          }
        }
      })

      // 2.获取已选中的消息
      for (let i = 0; i < self.playInfoVosList.length; i++) {
        let item = self.playInfoVosList[i]
        if (
          parseInt(item.startTime) <= parseInt(keywordItem.targetTimeEnd) &&
          parseInt(item.endTime) >= parseInt(keywordItem.targetTimeStart)
        ) {
          if (parseInt(keywordItem.fullScriptRole) === 1) {
            if (item.role == '1' && item.text.indexOf(keywordItem.keyword) >= 0) {
              if (selectedIndex == keywordItem.clickIndex) {
                keywordItem.clickIndex++
                selectedMsg = item
                break
              }
              selectedIndex++
            }
          } else if (parseInt(keywordItem.fullScriptRole) === 2) {
            if (item.role == '2' && item.text.indexOf(keywordItem.keyword) >= 0) {
              if (selectedIndex == keywordItem.clickIndex) {
                keywordItem.clickIndex++
                selectedMsg = item
                break
              }
              selectedIndex++
            }
          } else {
            if (item.text.indexOf(keywordItem.keyword) >= 0) {
              if (selectedIndex == keywordItem.clickIndex) {
                keywordItem.clickIndex++
                selectedMsg = item
                break
              }
              selectedIndex++
            }
          }
        }
      }

      // 3.重制点击数
      if (keywordItem.clickIndex == pipeiMsgCount) {
        keywordItem.clickIndex = 0
      }
      if (selectedMsg != null) {
        self.playClip(selectedMsg.startTime)
      }
    },
    // 添加案例
    addCase_btn() {
      this.getTreeData()
      this.showAddCaseDialog = true
      this.resetForm('AddCaseModel')
    },
    // 关闭添加案例弹出层
    handleCloseAddCaseDialog() {
      this.showAddCaseDialog = false
    },
    // 判断是否重复添加案例
    hasSameCaseThrottle() {
      this.lodashThrottle.throttle(this.hasSameCase, this)
    },
    // 添加案例
    addCase() {
      let _this = this
      this.$refs.AddCaseModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let url = qualityUrl + '/qaDetail/colCase.do'
          let params = {
            objectId: _this.callId,
            apReaSon: _this.AddCaseModel.addCaseReason,
            casClassId: _this.AddCaseModel.dataType,
          }
          if (_this.AddCaseModel.addCaseReason.length > 255) {
            _this.$message({
              type: 'error',
              message: '请填写小于255字符的理由',
            })
            return
          }
          this.axios
            .post(url, qs.stringify(params))
            .then(function(response) {
              if (response.data.status == 'success') {
                _this.$message({
                  type: 'success',
                  message: response.data.data,
                })
                _this.showAddCaseDialog = false
              } else {
                _this.$message({
                  type: 'error',
                  message: response.data.data,
                })
                return Promise.reject()
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    // 添加案例 添加按钮
    hasSameCase() {
      let _this = this
      let url = qualityUrl + '/qaDetail/hasSameCase.do'
      let params = {
        objectId: this.callId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.status !== 'success') {
            _this.addCase()
          } else {
            _this.$message({
              type: 'success',
              message: response.data.data,
            })
            _this.showAddCaseDialog = false
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '检查是否重复添加失败',
          })
        })
    },
    // 获取权限按钮
    getFuncId: function() {
      this.axios
        .post(global.hrmApi + '/accountApi/accessible/getFuncIdByAccountId.do')
        .then((res) => {
          for (let i = 0; i < res.data.length; i++) {
            if (res.data[i] == 'alca11') {
              this.isShowedit = true
            }
            if (res.data[i] == 'alca00') {
              this.isShowplus = true
            }
            if (res.data[i] == 'alca22') {
              this.isShowclose = true
            }
            // 删除
            if (res.data[i] == 'alca33') {
              this.isShowdelete = true
            }
            // 编辑
            if (res.data[i] == 'alca44') {
              this.isShoweditCase = true
            }
            // 查看
            if (res.data[i] == 'alca55') {
              this.isShowLook = true
            }
            // 批量删除
            if (res.data[i] == 'alca66') {
              this.isShowdelby = true
            }
            // 通过
            if (res.data[i] == 'alca77') {
              this.isShowadopt = true
            }
            // 拒绝
            if (res.data[i] == 'alca88') {
              this.isShowrefuse = true
            }
          }
        })
    },
    // 重置表单
    resetForm(name) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[name].resetFields()
      })
    },
    // 智能筛选命中词点击
    highlightWordIntell(val, oldval) {
      let selector = ''
      if (parseInt(val.fullScriptRole) === 1) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 2) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let _this = this
      let eles = document.querySelectorAll(selector)
      if (!eles || eles.length === 0) {
        return
      } else {
        // 第一次点击的时候先把全部的关键词都替换掉
        if (_this.isFirst) {
          console.log(_this.keywordCollection)
          document
            .querySelectorAll('div.dialog ul li .dialog-content')
            .forEach(function(item) {
              for (let i of _this.keywordCollection) {
                if (item.innerHTML.indexOf(i.keyword) != -1) {
                  // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, i.keyword)
                  item.innerHTML = item.innerHTML
                    .replace(/<span style="color: red">/g, '')
                    .replace(/<\/span>/g, '')
                }
              }
            })
          _this.isFirst = false
        } else {
          // 如果不是第一次点击关键词的时候把上次的关键词红色去除
          if (oldval) {
            // 当要高亮显示的文字变化时，先清空原来所有的高亮
            document
              .querySelectorAll('div.dialog ul li .dialog-content')
              .forEach(function(item) {
                // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, oldval.keyword)
                item.innerHTML = item.innerHTML
                  .replace(/<span style="color: red">/g, '')
                  .replace(/<\/span>/g, '')
              })
          }
        }
        eles.forEach(function(item) {
          let className = item.parentElement.className.split(' ')
          let startTime = parseInt(className[1].substr(1).trim())
          let endTime = parseInt(className[2].substr(1).trim())
          if (!(startTime <= val.targetTimeEnd && endTime >= val.targetTimeStart)) {
            return
          }
          if (item.innerHTML.indexOf(val.keyword) != -1) {
            item.innerHTML = item.innerHTML.replace(
              new RegExp(val.keyword, 'gm'),
              '<span style="color: red">' + val.keyword + '</span>'
            )
          }
        })
      }
    },
  },
  watch: {
    currentTime(val) {
      this.currentClass = this.findCurrentMessage(val - 250)
      this.scrollDialog(this.currentClass)
    },
    focusWord(val, oldval) {
      this.highlightWord(val, oldval, '0')
    },
    focusWordIntell: {
      handler: function(val, oldval) {
        this.highlightWordIntell(val, oldval)
      },
      deep: true, // 对象内部的属性监听，也叫深度监听
    },
    playInfoVosList() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.fromUrl == 'task_result' && this.keywords && this.keywords.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keywords.forEach(function(item, index) {
            if (item.keywordContext.indexOf('NOT') == -1) {
              let temp = item.keywordContext.replace(/([\\(\\)])*(AND)*(OR)*/g, '')
              temp.split(' ').forEach(function(i) {
                if (i) {
                  // self.highlightWord(i, '', item.fullScriptRole)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      }
    },
    keywords() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.fromUrl == 'task_result' && this.keywords && this.keywords.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keywords.forEach(function(item, index) {
            if (item.keywordContext.indexOf('NOT') == -1) {
              item.targetContent.forEach(function(i) {
                if (i) {
                  self.keywordCollection.add(i)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      }
    },
    keys() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.keys && this.keys.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keys.forEach(function(item, index) {
            if (
              item.judge == 5 &&
              item.resultsObject.keywordContext.indexOf('NOT') == -1
            ) {
              item.resultsObject.keyword.forEach(function(i) {
                if (i) {
                  self.keywordCollection.add(i)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      }
    },
  },
  filters: {
    dealSpeed(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return '过慢'
      } else if (val > maxSpeed) {
        return '过快'
      }
    },
    dealSpeedType(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return 'danger'
      } else if (val > maxSpeed) {
        return 'primary'
      }
    },
    timeFormat(val) {
      if (val === '' || !val) {
        return ''
      }
      return moment(val).format('YYYY-MM-DD HH:mm:ss')
    },
    timeFormatMD(val) {
      if (val === '' || !val) {
        return ''
      }
      let date = moment(val)
        .format('YYYY-MM-DD HH:mm:ss')
        .substring(5, 10)
      let m = date.substring(0, 2)
      if (m.substring(0, 1) == 0) {
        m = m.substring(1, 2)
      } else {
        m = m.substring(0, 2)
      }
      let d = date.substring(3, 5)
      if (d.substring(0, 1) == 0) {
        d = d.substring(1, 2)
      } else {
        d = d.substring(0, 2)
      }
      return m + '-' + d
    },
  },
}
</script>
<style lang="less">
@borderColor: #c3ccd9;
@playerHeight: 50px;
@infoHeight: 220px;
@controlBtnsHeight: 40px;
.recordingPlayContainer {
  width: 100%;
  height: 100%;
  position: relative;
  & > .controller_btns {
    position: absolute;
    width: 100px;
    line-height: 40px;
    top: 0px;
    right: 0px;
    z-index: 999;
    text-align: right;
    padding-right: 10px;
    .controller_btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      line-height: 24px;
      border-radius: 50%;
      margin-left: 5px;
      text-align: center;
      background: #c3ccd9;
      color: #fff;
      &:hover {
        cursor: pointer;
      }
    }
  }
  & > .el-row {
    height: 100%;
    border-top: 1px solid @borderColor;
    & > .el-col {
      height: 100%;
      position: relative;
    }
  }
  // 修改tab组件样式
  .el-tabs__item.is-active {
    color: #1f2d3d !important;
    font-size: 14px;
    font-weight: bold;
  }
  .el-tabs--border-card {
    border: none;
    height: 100%;
    position: relative;
    & > div {
      border: none;
    }
    & > .el-tabs__header {
    }
    & > .el-tabs__content {
      position: absolute;
      top: 40px;
      left: 0;
      right: 0;
      bottom: 0;
      overflow-y: auto;
      & > .el-tab-pane {
        height: 100%;
      }
    }
    & > .el-tabs__header .el-tabs__item {
      border: none;
    }
  }

  // 修改tab组件样式结束
  .leftContainer,
  .rightContainer {
    position: absolute;
    right: 0;
    left: 0;
    top: 0;
    bottom: 0;
  }
  .leftContainer {
    .info-base {
      height: 100%;
      overflow-y: hidden;
      .infoContent {
        height: auto;
        float: left;
        width: 100%;
        border-bottom: 1px solid #e4e4e4;
        padding: 20px 0;
        box-sizing: border-box;
        &.infoContent-kehuInfo {
          border: none;
          .tagWrap {
            position: absolute;
            left: 10px;
            bottom: 10px;
            right: 120px;
            .el-tag {
              margin-right: 10px;
              margin-bottom: 10px;
            }
          }
          .btnWrap {
            position: absolute;
            right: 10px;
            bottom: 10px;
          }
        }
        .borderLeft {
          width: 100%;
          height: 30px;
          line-height: 30px;
          overflow: hidden;
          color: #8691a5;
          .borderBlue {
            margin-left: 10px;
            display: inline-block;
            color: #1791ec;
            text-align: center;
            line-height: 8px;
            border-radius: 2px;
            border: 1px solid #9ed9f3;
            padding: 4px 10px;
            color: #1791ec;
            height: 10px;
            background: #d7eeff;
            font-size: 12px;
          }
          .borderGreen {
            margin-left: 10px;
            display: inline-block;
            color: #1791ec;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #6bdec4;
            padding: 4px 10px;
            color: #12a080;
            height: 12px;
            background: #caf7ed;
            font-size: 12px;
          }
        }
        .borderRight {
          width: 50%;
          color: #8691a5;
          display: inline-block;
          height: 30px;
          line-height: 30px;
          .borderPositive {
            display: inline-block;
            font-size: 12px;
            color: #12a080;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #12a037;
            padding: 4px 10px;
            height: 12px;
            padding: 4px 10px;
            color: #12a037;
          }
          .borderNegative {
            display: inline-block;
            font-size: 12px;
            margin-right: 10px;
            color: #12a080;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #ff0000;
            padding: 4px 10px;
            height: 12px;
            padding: 4px 10px;
            color: #ff0000;
          }
        }
        .info_item {
          min-width: 50%;
          float: left;
          line-height: 30px;
          color: #8691a5;
          font-size: 14px;
          .el-rate {
            display: inline-block;
            margin-left: 5px;
            vertical-align: middle;
          }
          span.el-tag {
            margin-right: 2px;
          }
          &.agentLabel {
            width: 100%;
            .el-tag {
              margin-right: 5px;
            }
          }
        }
        .borderRight {
          width: 50%;
          display: inline-block;
          height: 30px;
          line-height: 30px;
          .borderPositive {
            display: inline-block;
            font-size: 12px;
            color: #12a080;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #12a037;
            padding: 4px 10px;
            height: 12px;
            padding: 4px 10px;
            color: #12a037;
          }
          .borderNegative {
            display: inline-block;
            font-size: 12px;
            margin-right: 10px;
            color: #12a080;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #ff0000;
            padding: 4px 10px;
            height: 12px;
            padding: 4px 10px;
            color: #ff0000;
          }
        }
      }
    }
    .info {
      height: @infoHeight;
      position: relative;
      .submit-playinfo-list {
        position: absolute;
        right: 10px;
        bottom: 3px;
        height: 30px;
        padding: 7px 10px;
      }
      .infoContent {
        height: 100%;
        .info_item {
          min-width: 50%;
          float: left;
          line-height: 30px;
          color: #8691a5;
          font-size: 14px;
          .el-rate {
            display: inline-block;
            margin-left: 5px;
            vertical-align: middle;
          }
          span.el-tag {
            margin-right: 2px;
          }
          &.agentLabel {
            width: 100%;
            .el-tag {
              margin-right: 5px;
            }
          }
        }
      }
    }
    .dialog {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      top: @infoHeight;
      overflow-y: auto;
      padding: 10px;
      background: #eef1f6;
      & > ul {
        position: relative;
        & > li {
          overflow: hidden;
          margin: 10px 0px;
          .avatar {
            width: 46px;
            height: 46px;
            line-height: 46px;
            border-radius: 23px;
            border: 1px solid @borderColor;
            text-align: center;
            background: #fff;
          }
          .dialog-content {
            background: #fff;
            padding: 10px 15px;
            line-height: 20px;
            border-radius: 5px;
            margin-left: 15px;
            position: relative;
            max-width: 280px;
            margin-top: 5px;
            cursor: pointer;
          }
          .content-tag {
            margin-top: 15px;
          }
          &.custom_content {
            div {
              float: left;
            }
            .dialog-content {
              background: #fff;
              &::before {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #fff;
                position: absolute;
                top: 10px;
                left: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.agent_content {
            div {
              float: right;
            }
            .dialog-content {
              margin-left: 10px;
              margin-right: 15px;
              background: #9eea6a;
              color: #000000;
              &::after {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #9eea6a;
                position: absolute;
                top: 10px;
                right: -6px;
                transform: rotate(45deg);
              }
            }
          }
          // 当前正在播放的对话内容样式
          &.currentClass {
            .dialog-content {
              background: #22b8fe;
              color: #000000;
              &::after {
                background: #22b8fe;
              }
              &::before {
                background: #22b8fe;
              }
            }
          }
          &.UNK {
            div {
              text-align: center;
              display: block;
              color: #97a8be;
            }
            div.line {
              width: 100%;
              height: 15px;
              background: url('../../../assets/img/unk.png') no-repeat;
              background-position: center;
            }
          }
        }
      }
    }
    #lrc_list {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      top: @infoHeight;
      overflow-y: auto;
      padding: 10px;
      background: #eef1f6;
      & > ul {
        position: relative;
        & > li {
          overflow: hidden;
          margin: 10px 0px;
          .avatar {
            width: 46px;
            height: 46px;
            line-height: 46px;
            border-radius: 23px;
            border: 1px solid @borderColor;
            text-align: center;
            background: #fff;
          }
          .dialog-content {
            background: #fff;
            padding: 10px 15px;
            line-height: 20px;
            border-radius: 5px;
            margin-left: 15px;
            position: relative;
            max-width: 280px;
            margin-top: 5px;
          }
          .content-tag {
            margin-top: 15px;
          }
          &.custom_content {
            div {
              float: left;
            }
            .dialog-content {
              background: #fff;
              &::before {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #fff;
                position: absolute;
                top: 10px;
                left: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.agent_content {
            div {
              float: right;
            }
            .dialog-content {
              margin-left: 10px;
              margin-right: 15px;
              background: #9eea6a;
              color: #000000;
              &::after {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #9eea6a;
                position: absolute;
                top: 10px;
                right: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.UNK {
            div {
              text-align: center;
              display: block;
              color: #97a8be;
            }
            div.line {
              width: 100%;
              height: 15px;
              background: url('../../../assets/img/unk.png') no-repeat;
              background-position: center;
            }
          }
        }
      }
    }
  }
  .btns {
    text-align: right;
    button {
      width: 90px;
    }
  }
  .contentLeft,
  .contentRight {
    border: 1px solid @borderColor;
  }
  .el-dialog__body {
    padding-top: 10px;
    .footer {
      margin-top: 10px;
    }
  }
  .dialogTitle {
    color: #8691a5;
    font-size: 14px;
    font-weight: normal;
    box-sizing: border-box;
    height: 50px;
    line-height: 50px;
    padding: 0px 10px;
    border-bottom: 1px dotted @borderColor;
    .btns button {
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      padding: 0px;
    }
  }
  .hidden {
    display: none;
  }
}

.cailbtatMeet {
  margin: 10px 20px;
  .showDialogHeader {
    .el-dialog__header {
      display: block !important;
    }
  }
  .tip {
    font-size: 12px;
    color: red;
  }
  .playClip_btn {
    cursor: pointer;
  }
  .shareReason {
    padding: 10px;
    height: 300px;
    width: 90%;
    overflow-y: auto;
    .el-tree.filter-tree {
      border: none;
    }
  }
  .dialogTitle {
    color: #8691a5;
    font-size: 14px;
    font-weight: normal;
    box-sizing: border-box;
    height: 50px;
    line-height: 50px;
    padding: 0px 10px;
    border-bottom: 1px dotted @borderColor;
    .btns button {
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      padding: 0px;
    }
  }
  .contentLeft,
  .contentRight {
    border: 1px solid @borderColor;
  }
  .el-input.w-123 {
    width: 123px;
  }
}

.cailbtat_meet {
  .standards_parts {
    position: absolute;
    top: 0px;
    right: 0px;
    left: 0px;
    bottom: 0px;
    overflow-y: auto;
    .standards_part {
      position: relative;
      .zjyWrap {
        width: 100%;
        margin: 20px 0;
        .zjyWrap_title {
          font-size: 16px;
          margin-right: 10px;
        }
        .el-select.zjyWrap_select {
          display: inline-block;
          width: 180px;
        }
      }
      h3 {
        line-height: 30px;
        font-size: 14px;
        color: #1f2d3d;
        font-weight: normal;
      }
      .standards_detail {
        padding-left: 0;
        .classification_part {
          h3 {
            line-height: 30px;
            font-size: 14px;
            color: #9dadc2;
            font-weight: normal;
          }
          .classification_detail {
            padding: 10px 0;
            .el-form-item > label {
              font-size: 14px;
              color: #8691a5;
            }
          }
        }
        .normalNameClass {
          line-height: 30px;
          color: #9dadc2;
          font-size: 14px;
        }
      }
      &.noBorder {
        border-bottom: none;
        & > p {
          font-size: 14px;
          margin-bottom: 10px;
        }
      }
      .btns {
        margin: 10px;
      }
    }
    .standards_part_title {
      position: relative;
      line-height: 30px;
      font-size: 14px;
      color: #1f2d3d;
      font-weight: normal;
      h2,
      h3 {
        display: inline-block;
      }
      .h2 {
        font-weight: bold;
        font-size: 13px;
        color: #1f2d3d;
        line-height: 17px;
      }
      .score {
        display: inline-block;
        float: right;
        label {
          display: inline-block;
          width: 35px;
          font-size: 13px;
          color: #1f2d3d;
          line-height: 17px;
        }
        span {
          display: inline-block;
          width: 35px;
          font-size: 13px;
          color: #1f2d3d;
          line-height: 17px;
        }
        .score_result {
          width: 35px;
          font-size: 13px;
          color: #20a0ff;
          line-height: 17px;
        }
      }
    }
    .selectInspector {
      width: 120px;
      line-height: 30px;
      position: absolute;
      right: 145px;
      top: 6px;
    }
    &.screening {
      top: 10px;
    }
    &.appealScore {
      h3 {
        color: #9dadc2;
      }
      label {
        color: #8691a5;
      }
    }
  }
  .rightContainer {
    .infoForm {
      height: 100%;
      .detailInfoContents_part {
        border-bottom: 1px dashed @borderColor;
        .detailInfoContentsInputs {
          padding: 10px;
          .el-form-item > label {
            font-size: 14px;
            color: #8691a5;
          }
        }
        h3 {
          padding-left: 10px;
          line-height: 30px;
          font-size: 14px;
          color: #9dadc2;
          font-weight: normal;
        }
      }
    }
    .el-date-editor.el-input {
      width: 100%;
    }
    .el-select {
      width: 100%;
    }
    .operation {
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      padding: 0px 10px 0px 0px;
      border-bottom: 1px dashed @borderColor;
      position: absolute;
      top: 0px;
      left: 10px;
      right: 10px;
      h3 {
        width: 65px;
        float: left;
        font-size: 14px;
        color: #5e6d82;
        font-weight: normal;
      }
    }
    .btns {
      float: right;
      button {
        width: 90px;
      }
    }
  }
}

.cailbtat_meet.el-tabs.el-tabs--card.el-tabs--top {
  height: 100%;
  .el-tabs__content {
    position: absolute;
    top: 40px;
    left: 0;
    right: 0;
    bottom: 0;
  }
}
</style>
