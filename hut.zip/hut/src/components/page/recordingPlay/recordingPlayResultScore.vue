<!--
不同模块的模版  用fromUrl 区分    此页面用来处理：系统自动评分 质检结果查看 录音池fromUrl == 'recordingpoll'
同模块不同角色的  role 区分 坐席 组长 主管
同模块下不同状态  appealStatus  当前状态值 3主管一次审批通过 4主管二次审批通过 6 坐席发起二次申诉 8 主管二次申诉驳回
resultScoreIndex  1申诉中 2已确认 3未确认
shensuTabIndex 1已处理 2未处理
关键词高亮：系统自动评分进入后，模板出内容的命中关键词高亮，点击后相继亮，录音池搜索时有关键词，进入播放页录音内容里含搜索关键词的全部高亮关键词
坐席和组长查看时，申诉状态：
一次申诉中：  1 和2
一次申诉成绩已公布： 3
一次申诉成绩已驳回：7和5
二次申诉中：6
二次申诉成绩已公布：4
二次申诉成绩已驳回：8

已确认：10、11、13和14
-->

<template>
  <div class="recordingPlayContainer">
    <div class="controller_btns">
      <div class="controller_btn" @click="minimizePage">
        <i class="el-icon-minus"></i>
      </div>
      <div class="controller_btn" @click="closePage"><i class="el-icon-close"></i></div>
    </div>
    <el-row class="fromUrl == 'recordingpoll' ? pb50 : ''">
      <el-col :span="spanFirst">
        <div class="leftContainer">
          <div class="info-base">
            <el-tabs type="border-card">
              <el-tab-pane label="基本信息">
                <div class="infoContent">
                  <div class="info_item">
                    <label>录音编号:</label>
                    <span>{{ esResultModel.callId }}</span>
                  </div>
                  <div class="info_item">
                    <label>开始时间:</label>
                    <span>{{ esResultModel.callSTime | timeFormat }}</span>
                  </div>
                  <div class="info_item">
                    <label>通话时长:</label>
                    <span>{{
                      isNaN(esResultModel.callTime / 1000)
                        ? ''
                        : esResultModel.callTime / 1000 + '秒'
                    }}</span>
                  </div>
                  <div class="borderRight">
                    <label>情绪标签:</label>
                    <span
                      v-if="
                        esResultModel.emotionLabel != '' &&
                          esResultModel.emotionLabel != null &&
                          esResultModel.emotionLabel.indexOf('积极') != -1
                      "
                      class="borderPositive"
                      >{{ esResultModel.emotionLabel }}</span
                    >
                    <span
                      v-if="
                        esResultModel.emotionLabel != '' &&
                          esResultModel.emotionLabel != null &&
                          esResultModel.emotionLabel.indexOf('消极') != -1
                      "
                      class="borderNegative"
                      >{{ esResultModel.emotionLabel }}</span
                    >
                  </div>
                  <div class="borderLeft">
                    <label>关键词标签:</label>
                    <span
                      v-if="
                        esResultModel.labelContent != '' &&
                          esResultModel.labelContent != null
                      "
                    >
                      <span
                        class="borderBlue"
                        v-for="(list, indexOne) in getLabelContentList(
                          esResultModel.labelContent
                        )"
                        :key="indexOne"
                        >{{ list }}</span
                      >
                    </span>
                  </div>
                </div>
                <div class="infoContent">
                  <div class="info_item">
                    <label>坐席工号:</label>
                    <span>{{ esResultModel.seatNo }}</span>
                  </div>
                  <div class="info_item">
                    <label>坐席姓名:</label>
                    <span>{{ esResultModel.seatName }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属角色:</label>
                    <span>{{
                      aclOperVo.roleNames != null ? aclOperVo.roleNames.join(',') : ''
                    }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属部门:</label>
                    <span>{{ aclOperVo.deptName }}</span>
                  </div>
                  <div class="info_item" style="width:100%;">
                    <label>坐席星级:</label>
                    <span>
                      <el-rate
                        v-model="esResultModel.seatStar"
                        disabled
                        text-color="#ff9900"
                      >
                      </el-rate>
                    </span>
                  </div>
                  <div class="info_item agentLabel">
                    <label>坐席标签:</label>
                    <el-tag
                      :type="color[index % 4]"
                      v-if="item.trim()"
                      v-for="(item, index) in serviceLabels"
                      :key="item"
                      >{{ item }}
                    </el-tag>
                    <el-tag v-if="!serviceLabels || serviceLabels.length == 0"
                      >暂无标签
                    </el-tag>
                  </div>
                </div>
                <div class="infoContent infoContent-kehuInfo">
                  <div class="info_item">
                    <label>客户姓名:</label>
                    <span>{{ esResultModel.customerName }}</span>
                  </div>
                  <div class="info_item">
                    <label>账号:</label>
                    <span>{{ esResultModel.customerNo }}</span>
                  </div>
                  <div class="info_item">
                    <label>证件信息:</label>
                    <span>{{ esResultModel.certType }}</span>
                  </div>
                  <div class="info_item">
                    <label>证件号:</label>
                    <span>{{ esResultModel.certNo }}</span>
                  </div>
                  <div class="info_item agentLabel">
                    <label>客户标签:</label>
                    <el-tag
                      :type="color[index % 4]"
                      v-for="(item, index) in customInfoModel"
                      :key="item"
                      class="customLabel"
                      >{{ item }}
                    </el-tag>
                    <el-tag v-if="!customInfoModel || customInfoModel.length === 0"
                      >暂无标签
                    </el-tag>
                  </div>
                  <div class="tagWrap" v-if="caseTag.length > 0">
                    <el-tag v-for="(item, i) in caseTag" :key="i">{{ item }}</el-tag>
                  </div>
                  <div class="btnWrap">
                    <el-button v-if="roleCodeId.includes('qa')" @click="addCase_btn"
                      >添加案例
                    </el-button>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </el-col>
      <el-col :span="spanSecond">
        <div class="leftContainer">
          <div class="info">
            <el-tabs type="border-card">
              <el-tab-pane label="语音特征">
                <div class="infoContent">
                  <div class="info_item">
                    <label>静默次数:</label>
                    <span>{{ esResultModel.silenceCount }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默时长:</label>
                    <span>{{ esResultModel.silenceLong / 1000 || 0 }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默占比:</label>
                    <span
                      >{{ Math.round(esResultModel.silencePer * 1000) / 10 || 0 }}%</span
                    >
                  </div>
                  <div class="info_item">
                    <label>语音重叠次数:</label>
                    <span>{{ esResultModel.overLap }}</span>
                  </div>
                  <div class="info_item">
                    <label>情绪分值:</label>
                    <span>{{ esResultModel.moodScore }}</span>
                  </div>
                  <div class="info_item">
                    <label>平均语速:</label>
                    <span>{{
                      isNaN(Math.round(esResultModel.avgSpeed * 100) / 100)
                        ? ''
                        : Math.round(esResultModel.avgSpeed * 100) / 100 + '字/秒'
                    }}</span>
                  </div>
                  <div class="info_item">
                    <label>最快语速:</label>
                    <span>{{
                      isNaN(Math.round(esResultModel.maxSpeed * 100) / 100)
                        ? ''
                        : Math.round(esResultModel.maxSpeed * 100) / 100 + '字/秒'
                    }}</span>
                  </div>
                  <div class="info_item">
                    <label>最长静默:</label>
                    <span>{{
                      isNaN(Math.round(esResultModel.maxSilenceLong / 10) / 100)
                        ? ''
                        : Math.round(esResultModel.maxSilenceLong / 10) / 100
                    }}</span>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
            <el-button
              class="submit-playinfo-list"
              v-if="
                roleCodeId.includes('qa_suvs') &&
                  (esResultModel.labelContent == null ||
                    esResultModel.labelContent == '') &&
                  esResultModel.isSampled == '0'
              "
              ><span @click="submitPlayInfoList('1')" v-if="isEditPlayInfoList"
                >文本修改</span
              ><span @click="submitPlayInfoList('2')" v-else>保存</span></el-button
            >
          </div>
          <div class="dialog" @mousewheel="test">
            <ul>
              <li
                :class="classes(item.role, item.startTime, item.endTime)"
                v-for="(item, index) in playInfoVosList"
                :key="item.startTime"
              >
                <div v-if="item.role == '1'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/seat.png"
                  />
                </div>
                <div v-if="item.role == '2'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/customer.png"
                  />
                </div>
                <div class="dialog-content" v-if="item.role != 'UNK'">
                  <div style="display: inline-block" v-if="!isEditPlayInfoList">
                    <el-input
                      type="textarea"
                      v-model="playInfoVosList[index].changeText"
                    />
                  </div>

                  <div
                    style="display: inline-block"
                    v-else
                    @click="playClip(item.startTime)"
                  >
                    <el-tooltip
                      popper-class="tooltipWidth"
                      :disabled="isShowPlayInfoTooltip"
                      class="item"
                      effect="dark"
                      placement="top"
                      :content="item.originalText"
                    >
                      <button
                        style="background: none;border:0;"
                        @mouseenter="playShowToolTip($event, item)"
                      >
                        <span
                          class="aims"
                          :class="[item.startTime, item.endTime]"
                          style="cursor: pointer;max-width: 100px;word-wrap:break-word;word-break:break-all;white-space: normal"
                          v-html="item.text"
                        ></span>
                      </button>
                    </el-tooltip>
                  </div>
                </div>
                <div
                  class="content-tag"
                  v-if="item.role == 1 && isShowSpeedFlag(item.speed)"
                >
                  <el-tag :type="item.speed | dealSpeedType(minSpeed, maxSpeed)">
                    {{ item.speed | dealSpeed(minSpeed, maxSpeed) }}
                  </el-tag>
                </div>
                <div v-if="item.role == 'UNK'" class="UNK_text">
                  <el-row>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                    <el-col :span="4">{{ item.text }}</el-col>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                  </el-row>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </el-col>
      <el-col :span="spanThird">
        <div class="rightContainer">
          <div class="lable">
            质检评分
          </div>
          <div class="process_s">
            <div
              v-if="
                scoringTrajectory.length > 0 &&
                  recordingPlayPage.scoreResultRole !== 'scoreResultZuoXi' &&
                  recordingPlayPage.scoreResultRole !== 'scoreResultZuZhang'
              "
            >
              <div
                class="process-wrap"
                v-for="(item, index) in scoringTrajectory"
                :key="index"
              >
                <span class="process">{{ item.stepName }}</span>
                <span class="process">{{ item.scoreDate | timeFormatMD }}</span>
              </div>
            </div>
            <p
              v-if="
                recordingPlayPage.scoreResultRole !== 'scoreResultZuoXi' &&
                  recordingPlayPage.scoreResultRole !== 'scoreResultZuZhang'
              "
            ></p>
            <p v-else>
              {{
                recordingPlayPage.scoreResultRole == 'scoreResultZuoXi' ||
                recordingPlayPage.scoreResultRole == 'scoreResultZuZhang'
                  ? ''
                  : '暂无评分轨迹'
              }}
            </p>
          </div>
          <div class="standards_parts resultScore">
            <div class="standards_part">
              <div class="standards_part_title">
                <div class="verticalMiddle">
                  <h2 class="h2">评分模板：{{ modleTitle }}</h2>
                </div>
                <div class="score">
                  <span
                    class="score_result"
                    v-if="fromUrl == 'recordingpoll' && qaScoreType == 0"
                  ></span>
                  <span class="score_result" v-else="">{{ totalScoreFun }}</span>
                </div>
              </div>
              <!--自动与人工合并-->
              <div class="standards_part_title">
                <h3>
                  评分标准
                </h3>
                <div class="score">
                  <span v-if="fromUrl == 'recordingpoll' && qaScoreType == 0"></span>
                  <span v-else="">{{ autoScoreFun }}</span>
                </div>
              </div>
              <div class="standards_detail">
                <div
                  v-for="(standardsList, key) in standardsListWithAutoScoreQa"
                  :key="key"
                >
                  <div class="normalNameClass">{{ key }}</div>
                  <!--系统自动评分与质检检结果查看非主管-->
                  <el-table
                    v-if="
                      fromUrl == 'sysAutoScoringInCallResult' ||
                        (fromUrl == 'scoreResultInfo' &&
                          roleCodeId.includes('qa_suvs') === false)
                    "
                    ref="standardsListTable"
                    :data="standardsList"
                    border
                    :key="key"
                    tooltip-effect="dark"
                  >
                    <el-table-column prop="normalName" label="质检标准">
                    </el-table-column>
                    <el-table-column
                      prop="judge"
                      :formatter="formatJudge"
                      label="打分方式"
                    >
                    </el-table-column>
                    <el-table-column label="内容">
                      <template scope="scope">
                        <div v-if="scope.row.judge === 5">
                          <div v-if="scope.row.resultsObject !== null">
                            <div
                              v-for="(item, index) in standardsList[scope.$index]
                                .resultsObject"
                              :key="index"
                            >
                              <span v-for="(subitem, index) in item.keyword" :key="index">
                                <span
                                  v-if="subitem.ishighlight"
                                  :class="
                                    item.deadItem == 1
                                      ? 'hightlightContent_span'
                                      : 'notHightlightContent_span'
                                  "
                                  @click="
                                    playOccurrence_intelligent(subitem, item.deadItem)
                                  "
                                  >{{ subitem.keyword }}&nbsp;</span
                                >
                                <span v-else>{{ subitem.keyword }}&nbsp;</span>
                              </span>
                              <span>{{
                                getKeywordScoreFilter(item, scope.row.judge)
                              }}</span>
                            </div>
                            <!-- <span v-for="(item, index) in standardsListWithAutoScoreQa[key][scope.$index].resultsObject.keywordContext"
                                      :key="index">
                                  <span v-if="item.ishighlight" :class="item.ishighlight ? 'hightlightContent_span' : ''" @click="hightlightContent(item.keywordContext)">{{item.keywordContext}}&nbsp;</span>
                                  <span v-else>{{item}}&nbsp;</span>
                                </span> -->
                            <el-popover placement="right" width="120" trigger="hover">
                              <template
                                v-if="scope.row.resultsObject[0].deadItem == '1'"
                                slot="reference"
                              >
                                <i class="el-icon-warning" style="color: red"></i>
                              </template>
                              <p>{{ mingzhongTip }}</p>
                            </el-popover>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 4">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span
                                class="defualtScore"
                              >
                                <span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                ><span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                ></span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 1">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}分<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 2">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 11">
                          <p
                            v-for="(keyValue, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            {{ keyValue.labelName }}
                            <span v-if="keyValue.score !== 0"
                              >{{ +keyValue.increaseDeduction == '2' ? '减' : '加'
                              }}{{ keyValue.score }}分</span
                            >
                          </p>
                          <el-popover placement="right" width="120" trigger="hover">
                            <template
                              v-if="scope.row.resultsObject[0].deadItem == '1'"
                              slot="reference"
                            >
                              <i class="el-icon-warning" style="color: red"></i>
                            </template>
                            <p>{{ mingzhongTip }}</p>
                          </el-popover>
                        </div>
                        <div v-else-if="scope.row.judge === 3">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <div v-if="srrt.silenceType === 2">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 1">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 3">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 4">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 5">
                              <span v-for="(subitem, index) in srrt.keyword" :key="index">
                                <span
                                  v-if="subitem.ishighlight"
                                  :class="
                                    srrt.deadItem == 1
                                      ? 'hightlightContent_span'
                                      : 'notHightlightContent_span'
                                  "
                                  @click="
                                    playOccurrence_intelligent(subitem, srrt.deadItem)
                                  "
                                  >{{ subitem.keyword }}&nbsp;</span
                                >
                                <span v-else>{{ subitem.keyword }}&nbsp;</span>
                              </span>
                              {{ getKeywordScoreFilter(srrt, scope.row.judge) }}
                            </div>
                            <div v-else></div>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 12">
                          <div>
                            {{
                              scope.row.resultsObject[0].firstRoleType == 1
                                ? '坐席:'
                                : '客户:'
                            }}
                            <span
                              v-html="getHtml(scope.row.resultsObject[0].firstContext)"
                            ></span>
                          </div>
                          <div>
                            {{
                              scope.row.resultsObject[0].secondRoleType == 1
                                ? '坐席:'
                                : '客户:'
                            }}
                            <span
                              v-html="getHtml(scope.row.resultsObject[0].secondContext)"
                            ></span>
                          </div>
                          <div>
                            规则:
                            {{
                              `${scope.row.resultsObject[0].sentenceCount}句内，${
                                scope.row.resultsObject[0].isAppear == 1
                                  ? '出现'
                                  : '未出现'
                              }`
                            }}<span
                              v-if="scope.row.resultsObject[0].sentenceDeadItem == '2'"
                              >{{
                                ` ${
                                  scope.row.resultsObject[0].increaseDeduction == 1
                                    ? '加'
                                    : '减'
                                }${scope.row.resultsObject[0].score}分`
                              }}</span
                            >
                          </div>
                          <el-popover placement="right" width="120" trigger="hover">
                            <template
                              v-if="scope.row.resultsObject[0].sentenceDeadItem == '1'"
                              slot="reference"
                            >
                              <i class="el-icon-warning" style="color: red"></i>
                            </template>
                            <p>此标准为致命项标准，命中则总分为 0</p>
                          </el-popover>
                        </div>
                        <div v-else-if="scope.row.judge === 13">
                          <div>
                            意图:
                            <span v-html="getContentHtml(scope.row.faqContent)"></span>
                          </div>
                          <div
                            v-for="(item, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <div>
                              话术: <span v-html="getContentHtml(item.content)"></span>
                            </div>
                            <div>
                              规则:
                              {{
                                `${item.isAppear == 1 ? '出现' : '未出现'}${
                                  item.addsub == 1 ? '加' : '减'
                                }${item.score}分`
                              }}
                            </div>
                          </div>
                        </div>
                        <div v-else>
                          {{ scope.row.normalContent }}
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="fromUrl == 'sysAutoScoringInCallResult'"
                      prop="defaultScore"
                      label="初检得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .defaultScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .defaultScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .defaultScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].defaultScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span v-else-if="scope.row.judge == 8">
                            <span
                              v-if="
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .defaultScore == '2'
                              "
                              >非致命</span
                            >
                            <span
                              v-else-if="
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .defaultScore == '1'
                              "
                              >致命</span
                            >
                          </span>
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .defaultScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .defaultScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{
                            standardsListWithAutoScoreQa[key][scope.$index].defaultScore
                          }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="fromUrl == 'scoreResultInfo'"
                      prop="defaultScore"
                      label="得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div
                          v-if="
                            (fromUrl == 'scoreResultInfo' &&
                              roleCodeId.includes('seatman') &&
                              resultScoreIndex == 1 &&
                              appealStatus == '3') ||
                              (fromUrl == 'scoreResultInfo' &&
                                roleCodeId.includes('seatman') &&
                                resultScoreIndex == 1 &&
                                appealStatus == '4') ||
                              (fromUrl == 'scoreResultInfo' &&
                                roleCodeId.includes('seatman') &&
                                resultScoreIndex == 1 &&
                                appealStatus == '6') ||
                              (fromUrl == 'scoreResultInfo' &&
                                roleCodeId.includes('seatman') &&
                                resultScoreIndex == 1 &&
                                appealStatus == '8')
                          "
                        >
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span
                                v-else-if="scope.row.resultsObject[0].deadItem !== '1'"
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index]
                                .secondQaScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{
                            standardsListWithAutoScoreQa[key][scope.$index].secondQaScore
                          }}</span>
                        </div>
                        <div v-else>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .defaultScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .defaultScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span
                                v-else-if="scope.row.resultsObject[0].deadItem !== '1'"
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .defaultScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].defaultScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .defaultScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .defaultScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .defaultScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .defaultScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{
                            standardsListWithAutoScoreQa[key][scope.$index].defaultScore
                          }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="
                        (fromUrl == 'scoreResultInfo' &&
                          roleCodeId.includes('seatman') &&
                          resultScoreIndex == 1 &&
                          appealStatus == '3') ||
                          (fromUrl == 'scoreResultInfo' &&
                            roleCodeId.includes('seatman') &&
                            resultScoreIndex == 1 &&
                            appealStatus == '6')
                      "
                      label="一次申诉得分"
                      width="120"
                    >
                      <template slot-scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  scope.row.resultsObject[0].deadItem === '1' &&
                                    scope.row.threeScore == '2'
                                "
                                >非致命</span
                              >
                              <span
                                v-if="
                                  scope.row.resultsObject[0].deadItem === '1' &&
                                    scope.row.threeScore == '1'
                                "
                                >致命</span
                              >
                              <span
                                v-else-if="scope.row.resultsObject[0].deadItem !== '1'"
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].threeScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 && scope.row.threeScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 && scope.row.threeScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else="">{{ scope.row.threeScore }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="
                        (fromUrl == 'scoreResultInfo' &&
                          roleCodeId.includes('seatman') &&
                          resultScoreIndex == 1 &&
                          appealStatus == '4') ||
                          (fromUrl == 'scoreResultInfo' &&
                            roleCodeId.includes('seatman') &&
                            resultScoreIndex == 1 &&
                            appealStatus == '8')
                      "
                      label="二次申诉得分"
                      width="120"
                    >
                      <template slot-scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  scope.row.resultsObject[0].deadItem === '1' &&
                                    scope.row.fourScore == '2'
                                "
                                >非致命</span
                              >
                              <span
                                v-else-if="
                                  scope.row.resultsObject[0].deadItem === '1' &&
                                    scope.row.fourScore == '1'
                                "
                                >致命</span
                              >
                              <span
                                v-else-if="scope.row.resultsObject[0].deadItem !== '1'"
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .fourScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].fourScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="scope.row.judge == 8 && scope.row.fourScore == '2'"
                            >非致命</span
                          >
                          <span
                            v-else-if="scope.row.judge == 8 && scope.row.fourScore == '1'"
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .fourScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .fourScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{ scope.row.fourScore }}</span>
                        </div>
                      </template>
                    </el-table-column>
                  </el-table>
                  <!--质检检结果查看主管-->
                  <el-table
                    v-if="fromUrl == 'scoreResultInfo' && roleCodeId.includes('qa_suvs')"
                    ref="standardsListTable"
                    :data="standardsListWithAutoScoreQa[key]"
                    border
                    tooltip-effect="dark"
                  >
                    <el-table-column prop="normalName" label="质检标准">
                    </el-table-column>
                    <el-table-column
                      prop="judge"
                      :formatter="formatJudge"
                      label="打分方式"
                    >
                    </el-table-column>
                    <el-table-column label="内容">
                      <template scope="scope">
                        <div v-if="scope.row.judge === 5">
                          <div v-if="scope.row.resultsObject !== null">
                            <span
                              v-for="(item, key) in scope.row.resultsObject"
                              :index="key"
                              :key="key"
                            >
                              {{ item.keywordContext }}
                            </span>
                            <!-- <span v-for="(item, index) in scope.row.resultsObject.keywordContext.split('OR')"
                                      :key="index">
                                  <span class="hightlightContent_span" @click="hightlightContent(item)">{{item}} </span>
                                  <span v-if="index<scope.row.resultsObject.keywordContext.split('OR').length-1">&nbsp;OR&nbsp;</span>
                                </span> -->
                            <el-popover placement="right" width="120" trigger="hover">
                              <template
                                v-if="scope.row.resultsObject[0].deadItem == '1'"
                                slot="reference"
                              >
                                <i class="el-icon-warning" style="color: red"></i>
                              </template>
                              <p>{{ mingzhongTip }}</p>
                            </el-popover>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 4">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                ><span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                ></span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 1">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}分<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 2">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 11">
                          <p v-for="(keyValue, i) in scope.row.resultsObject" :key="i">
                            {{ keyValue.labelName }}
                            <span v-if="keyValue.score !== 0"
                              >{{ +keyValue.increaseDeduction == '2' ? '减' : '加'
                              }}{{ keyValue.score }}分</span
                            >
                          </p>
                          <el-popover placement="right" width="120" trigger="hover">
                            <template
                              v-if="scope.row.resultsObject[0].deadItem == '1'"
                              slot="reference"
                            >
                              <i class="el-icon-warning" style="color: red"></i>
                            </template>
                            <p>{{ mingzhongTip }}</p>
                          </el-popover>
                        </div>
                        <div v-else-if="scope.row.judge === 3">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <div v-if="srrt.silenceType === 2">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 1">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 3">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 4">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 5">
                              <span>{{ srrt.keywordContext }}</span>
                              {{ getKeywordScoreFilter(srrt, scope.row.judge) }}
                            </div>
                            <div v-else></div>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 12">
                          <div>
                            {{
                              scope.row.resultsObject[0].firstRoleType == 1
                                ? '坐席:'
                                : '客户:'
                            }}
                            <span
                              v-html="getHtml(scope.row.resultsObject[0].firstContext)"
                            ></span>
                          </div>
                          <div>
                            {{
                              scope.row.resultsObject[0].secondRoleType == 1
                                ? '坐席:'
                                : '客户:'
                            }}
                            <span
                              v-html="getHtml(scope.row.resultsObject[0].secondContext)"
                            ></span>
                          </div>
                          <div>
                            规则:
                            {{
                              `${scope.row.resultsObject[0].sentenceCount}句内，${
                                scope.row.resultsObject[0].isAppear == 1
                                  ? '出现'
                                  : '未出现'
                              }`
                            }}
                            <span
                              v-if="scope.row.resultsObject[0].sentenceDeadItem == '2'"
                              >{{
                                `${
                                  scope.row.resultsObject[0].increaseDeduction == 1
                                    ? '加'
                                    : '减'
                                }${scope.row.resultsObject[0].score}分`
                              }}</span
                            >
                          </div>
                          <el-popover placement="right" width="120" trigger="hover">
                            <template
                              v-if="scope.row.resultsObject[0].sentenceDeadItem == '1'"
                              slot="reference"
                            >
                              <i class="el-icon-warning" style="color: red"></i>
                            </template>
                            <p>此标准为致命项标准，命中则总分为 0</p>
                          </el-popover>
                        </div>
                        <div v-else-if="scope.row.judge === 13">
                          <div>
                            意图:
                            <span v-html="getContentHtml(scope.row.faqContent)"></span>
                          </div>
                          <div
                            v-for="(item, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <div>
                              话术: <span v-html="getContentHtml(item.content)"></span>
                            </div>
                            <div>
                              规则:
                              {{
                                `${item.isAppear == 1 ? '出现' : '未出现'}${
                                  item.addsub == 1 ? '加' : '减'
                                }${item.score}分`
                              }}
                            </div>
                          </div>
                        </div>
                        <div v-else>
                          {{ scope.row.normalContent }}
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column prop="defaultScore" label="初检得分" width="120">
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .firstQaScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .firstQaScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].firstQaScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .firstQaScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .firstQaScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{
                            standardsListWithAutoScoreQa[key][scope.$index].firstQaScore
                          }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column prop="defaultScore" label="复检得分" width="120">
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index]
                                .secondQaScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span
                            v-else-if="scope.row.judge != 5 && scope.row.judge != 11"
                            >{{
                              standardsListWithAutoScoreQa[key][scope.$index]
                                .secondQaScore
                            }}</span
                          >
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="(qaScoreType == 3 && isScored == true) || qaScoreType == 4"
                      label="一次申诉得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .threeScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .threeScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].threeScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .threeScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .threeScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-if="!judgeArr.includes(scope.row.judge)">{{
                            standardsListWithAutoScoreQa[key][scope.$index].threeScore
                          }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="qaScoreType == 4 && isScored == true"
                      label="二次申诉得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .fourScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .fourScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .fourScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].fourScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .fourScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .fourScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .fourScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .fourScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span
                            v-else-if="scope.row.judge !== 5 && scope.row.judge !== 11"
                            >{{
                              standardsListWithAutoScoreQa[key][scope.$index].fourScore
                            }}</span
                          >
                        </div>
                      </template>
                    </el-table-column>
                  </el-table>
                  <!--录音池-->
                  <el-table
                    v-if="fromUrl == 'recordingpoll' && roleCodeId.includes('qa_suvs')"
                    ref="standardsListTable"
                    :data="standardsListWithAutoScoreQa[key]"
                    border
                    tooltip-effect="dark"
                  >
                    <el-table-column prop="normalName" label="质检标准">
                    </el-table-column>
                    <el-table-column
                      prop="judge"
                      :formatter="formatJudge"
                      label="打分方式"
                    >
                    </el-table-column>
                    <el-table-column label="内容">
                      <template scope="scope">
                        <div v-if="scope.row.judge === 5">
                          <div v-if="scope.row.resultsObject !== null">
                            <div
                              v-for="(item, index) in standardsListWithAutoScoreQa[key][
                                scope.$index
                              ].resultsObject"
                              :key="index"
                            >
                              <span v-for="(subitem, index) in item.keyword" :key="index">
                                <span
                                  v-if="subitem.ishighlight"
                                  :class="
                                    item.deadItem == 1
                                      ? 'hightlightContent_span'
                                      : 'notHightlightContent_span'
                                  "
                                  @click="
                                    playOccurrence_intelligent(subitem, item.deadItem)
                                  "
                                  >{{ subitem.keyword }}&nbsp;</span
                                >
                                <span v-else>{{ subitem.keyword }}&nbsp;</span>
                              </span>
                              <span>{{
                                getKeywordScoreFilter(item, scope.row.judge)
                              }}</span>
                            </div>
                            <!-- <span v-for="(item, index) in standardsListWithAutoScoreQa[key][scope.$index].resultsObject.keywordContext"
                                  :key="index">
                              <span v-if="item.ishighlight" :class="item.ishighlight ? 'hightlightContent_span' : ''" @click="hightlightContent(item.keywordContext)">{{item.keywordContext}}&nbsp;</span>
                              <span v-else>{{item}}&nbsp;</span>
                            </span> -->
                            <el-popover placement="right" width="120" trigger="hover">
                              <template
                                v-if="scope.row.resultsObject[0].deadItem == '1'"
                                slot="reference"
                              >
                                <i class="el-icon-warning" style="color: red"></i>
                              </template>
                              <p>{{ mingzhongTip }}</p>
                            </el-popover>
                          </div>
                          <!--<p v-if="scope.row.resultsObject !== null">
                            <span>{{scope.row.resultsObject.keywordContext}}</span>
                                &lt;!&ndash; <span v-for="(item, index) in scope.row.resultsObject.keywordContext.split('OR')"
                                      :key="index">
                                  <span class="hightlightContent_span" @click="hightlightContent(item)">{{item}} </span>
                                  <span v-if="index<scope.row.resultsObject.keywordContext.split('OR').length-1">&nbsp;OR&nbsp;</span>
                                </span> &ndash;&gt;
                            <el-popover placement="right"
                                        width="120"
                                        trigger="hover">
                              <template v-if="scope.row.resultsObject[0].deadItem == '1'" slot="reference">
                                <i class="el-icon-warning" style="color: red"></i>
                              </template>
                          <p>此标准为致命项标准，命中则分数为 0</p>
                          </el-popover>
                          </p>-->
                        </div>
                        <div v-else-if="scope.row.judge === 4">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 1">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}分<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 2">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 11">
                          <p v-for="(keyValue, i) in scope.row.resultsObject" :key="i">
                            {{ keyValue.labelName }}
                            <span v-if="keyValue.score !== 0"
                              >{{ +keyValue.increaseDeduction == '2' ? '减' : '加'
                              }}{{ keyValue.score }}分</span
                            >
                          </p>
                          <el-popover placement="right" width="120" trigger="hover">
                            <template
                              v-if="scope.row.resultsObject[0].deadItem == '1'"
                              slot="reference"
                            >
                              <i class="el-icon-warning" style="color: red"></i>
                            </template>
                            <p>{{ mingzhongTip }}</p>
                          </el-popover>
                        </div>
                        <div v-else-if="scope.row.judge === 3">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <div v-if="srrt.silenceType === 2">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 1">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 3">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 5">
                              <span v-for="(subitem, index) in srrt.keyword" :key="index">
                                <span
                                  v-if="subitem.ishighlight"
                                  :class="
                                    srrt.deadItem == 1
                                      ? 'hightlightContent_span'
                                      : 'notHightlightContent_span'
                                  "
                                  @click="
                                    playOccurrence_intelligent(subitem, srrt.deadItem)
                                  "
                                  >{{ subitem.keyword }}&nbsp;</span
                                >
                                <span v-else>{{ subitem.keyword }}&nbsp;</span>
                              </span>
                              {{ getKeywordScoreFilter(srrt, scope.row.judge) }}
                            </div>
                            <div v-else-if="srrt.silenceType === 4">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 12">
                          <div>
                            {{
                              scope.row.resultsObject[0].firstRoleType == 1
                                ? '坐席:'
                                : '客户:'
                            }}
                            <span
                              v-html="getHtml(scope.row.resultsObject[0].firstContext)"
                            ></span>
                          </div>
                          <div>
                            {{
                              scope.row.resultsObject[0].secondRoleType == 1
                                ? '坐席:'
                                : '客户:'
                            }}
                            <span
                              v-html="getHtml(scope.row.resultsObject[0].secondContext)"
                            ></span>
                          </div>
                          <div>
                            规则:
                            {{
                              `${scope.row.resultsObject[0].sentenceCount}句内，${
                                scope.row.resultsObject[0].isAppear == 1
                                  ? '出现'
                                  : '未出现'
                              }`
                            }}<span
                              v-if="scope.row.resultsObject[0].sentenceDeadItem == '2'"
                              >{{
                                `${
                                  scope.row.resultsObject[0].increaseDeduction == 1
                                    ? '加'
                                    : '减'
                                }${scope.row.resultsObject[0].score}分`
                              }}</span
                            >
                          </div>
                          <el-popover placement="right" width="120" trigger="hover">
                            <template
                              v-if="scope.row.resultsObject[0].sentenceDeadItem == '1'"
                              slot="reference"
                            >
                              <i class="el-icon-warning" style="color: red"></i>
                            </template>
                            <p>此标准为致命项标准，命中则总分为 0</p>
                          </el-popover>
                        </div>
                        <div v-else-if="scope.row.judge === 13">
                          <div>
                            意图:
                            <span v-html="getContentHtml(scope.row.faqContent)"></span>
                          </div>
                          <div
                            v-for="(item, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <div>
                              话术: <span v-html="getContentHtml(item.content)"></span>
                            </div>
                            <div>
                              规则:
                              {{
                                `${item.isAppear == 1 ? '出现' : '未出现'}${
                                  item.addsub == 1 ? '加' : '减'
                                }${item.score}分`
                              }}
                            </div>
                          </div>
                        </div>
                        <div v-else>
                          {{ scope.row.normalContent }}
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="
                        qaScoreType == 1 ||
                          qaScoreType == 2 ||
                          qaScoreType == 3 ||
                          qaScoreType == 4
                      "
                      prop="defaultScore"
                      label="初检得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .firstQaScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .firstQaScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].firstQaScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .firstQaScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .firstQaScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{
                            standardsListWithAutoScoreQa[key][scope.$index].firstQaScore
                          }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="qaScoreType == 2 || qaScoreType == 3 || qaScoreType == 4"
                      prop="defaultScore"
                      label="复检得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index]
                                .secondQaScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{
                            standardsListWithAutoScoreQa[key][scope.$index].secondQaScore
                          }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="qaScoreType == 3 || qaScoreType == 4"
                      label="一次申诉得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .threeScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .threeScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span
                                v-else-if="scope.row.resultsObject[0].deadItem !== '1'"
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].threeScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .threeScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .threeScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{
                            standardsListWithAutoScoreQa[key][scope.$index].threeScore
                          }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="qaScoreType == 4"
                      label="二次申诉得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .fourScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .fourScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span
                                v-else-if="scope.row.resultsObject[0].deadItem !== '1'"
                                >{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .fourScore
                                }}
                              </span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            disabled
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].fourScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .fourScore == '2'
                            "
                            >非致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .fourScore == '1'
                            "
                            >致命</span
                          >
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .fourScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .fourScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{
                            standardsListWithAutoScoreQa[key][scope.$index].fourScore
                          }}</span>
                        </div>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
              </div>
            </div>
            <!--流程-->
            <div class="standards_part">
              <div class="standards_part_title">
                <h3>
                  流程评分
                </h3>
                <div class="score">
                  <span>{{ flowScoreFun }}</span>
                </div>
              </div>
              <div class="standards_detail">
                <div
                  class="classification_part"
                  v-for="(key, index) in flowListWithScoreQa"
                  :key="index"
                >
                  <h3>
                    {{ key.processName }}
                  </h3>
                  <div class="classification_detail">
                    <!--系统自动评分与质检检结果查看非主管-->
                    <el-table
                      v-if="
                        fromUrl == 'sysAutoScoringInCallResult' ||
                          (fromUrl == 'scoreResultInfo' &&
                            roleCodeId.includes('qa_suvs') === false)
                      "
                      ref="flowListTable"
                      :data="key.processDetail"
                      border
                      tooltip-effect="dark"
                    >
                      <el-table-column prop="intentName" label="意图"></el-table-column>
                      <el-table-column prop="intentRule" label="规则"></el-table-column>
                      <el-table-column
                        v-if="fromUrl == 'sysAutoScoringInCallResult'"
                        prop="firstScore"
                        width="120"
                        label="初检得分"
                      >
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="fromUrl == 'scoreResultInfo'"
                        width="120"
                        prop="defaultScore"
                        label="得分"
                      >
                        <template scope="scope">
                          <div
                            v-if="
                              (roleCodeId.includes('seatman') && appealStatus == '3') ||
                                (roleCodeId.includes('seatman') && appealStatus == '4') ||
                                (roleCodeId.includes('seatman') && appealStatus == '6') ||
                                (roleCodeId.includes('seatman') && appealStatus == '8')
                            "
                          >
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty(
                                'secondScore'
                              )
                                ? key.processDetail[scope.$index].secondScore
                                : '--'
                            }}</span>
                          </div>
                          <div
                            v-else-if="
                              roleCodeId.includes('seatman') && appealStatus == '13'
                            "
                          >
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty('thirdScore')
                                ? key.processDetail[scope.$index].thirdScore
                                : '--'
                            }}</span>
                          </div>
                          <div v-else>
                            <span
                              v-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                                  ? key.processDetail[scope.$index].secondScore
                                  : '--'
                              }}</span
                            >
                            <span v-else="">{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="
                          (fromUrl == 'scoreResultInfo' &&
                            roleCodeId.includes('seatman') &&
                            resultScoreIndex == 1 &&
                            appealStatus == '3') ||
                            (fromUrl == 'scoreResultInfo' &&
                              roleCodeId.includes('seatman') &&
                              resultScoreIndex == 1 &&
                              appealStatus == '6')
                        "
                        label="一次申诉得分"
                        width="120"
                      >
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty('thirdScore')
                                ? key.processDetail[scope.$index].thirdScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="
                          (fromUrl == 'scoreResultInfo' &&
                            roleCodeId.includes('seatman') &&
                            resultScoreIndex == 1 &&
                            appealStatus == '4') ||
                            (fromUrl == 'scoreResultInfo' &&
                              roleCodeId.includes('seatman') &&
                              resultScoreIndex == 1 &&
                              appealStatus == '8')
                        "
                        label="二次申诉得分"
                      >
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty(
                                'fourthScore'
                              )
                                ? key.processDetail[scope.$index].fourthScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                    </el-table>
                    <!--质检检结果查看主管-->
                    <el-table
                      v-if="
                        fromUrl == 'scoreResultInfo' && roleCodeId.includes('qa_suvs')
                      "
                      ref="flowListTable"
                      :data="key.processDetail"
                      border
                      tooltip-effect="dark"
                    >
                      <el-table-column prop="intentName" label="意图"></el-table-column>
                      <el-table-column prop="intentRule" label="规则"></el-table-column>
                      <el-table-column width="120" prop="defaultScore" label="初检得分">
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column width="120" prop="defaultScore" label="复检得分">
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty(
                                'secondScore'
                              )
                                ? key.processDetail[scope.$index].secondScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="(qaScoreType == 3 && isScored == true) || qaScoreType == 4"
                        label="一次申诉得分"
                        width="120"
                      >
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty('thirdScore')
                                ? key.processDetail[scope.$index].thirdScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="qaScoreType == 4 && isScored == true"
                        label="二次申诉得分"
                        width="120"
                      >
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty(
                                'fourthScore'
                              )
                                ? key.processDetail[scope.$index].fourthScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                    </el-table>
                    <!--录音池-->
                    <el-table
                      v-if="fromUrl == 'recordingpoll' && roleCodeId.includes('qa_suvs')"
                      ref="flowListTable"
                      :data="key.processDetail"
                      border
                      tooltip-effect="dark"
                    >
                      <el-table-column prop="intentName" label="意图"></el-table-column>
                      <el-table-column prop="intentRule" label="规则"></el-table-column>
                      <el-table-column
                        v-if="
                          qaScoreType == 1 ||
                            qaScoreType == 2 ||
                            qaScoreType == 3 ||
                            qaScoreType == 4
                        "
                        prop="firstScore"
                        width="120"
                        label="初检得分"
                      >
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="qaScoreType == 2 || qaScoreType == 3 || qaScoreType == 4"
                        prop="defaultScore"
                        width="120"
                        label="复检得分"
                      >
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty(
                                'secondScore'
                              )
                                ? key.processDetail[scope.$index].secondScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="qaScoreType == 3 || qaScoreType == 4"
                        label="一次申诉得分"
                        width="120"
                      >
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty('thirdScore')
                                ? key.processDetail[scope.$index].thirdScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="qaScoreType == 4"
                        label="二次申诉得分"
                        width="120"
                      >
                        <template scope="scope">
                          <div>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty(
                                'fourthScore'
                              )
                                ? key.processDetail[scope.$index].fourthScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </div>
              </div>
            </div>
            <div
              class="standards_part"
              v-if="roleCodeId.includes('seatman') && secAppFlag == 1 && taskStatus != 1"
            >
              <div class="standards_detail">
                <div class="classification_part">
                  <div class="classification_detail">
                    <el-form ref="reTaskModel" :model="reTaskModel">
                      <el-row>
                        <el-col :span="24">
                          <el-form-item>
                            <el-radio-group
                              @change="changeReTaskModel"
                              v-model="reTaskModel.responseResult"
                              :disabled="isShenSuScored"
                              fill="#97a8be"
                            >
                              <el-radio
                                :label="1"
                                v-if="
                                  appealStatus == 3 ||
                                    appealStatus == 5 ||
                                    appealStatus == 7
                                "
                                >确认成绩
                              </el-radio>
                              <el-radio
                                v-if="
                                  (appealStatus == 5 ||
                                    appealStatus == 3 ||
                                    appealStatus == 7) &&
                                    procTaskId != null
                                "
                                :label="2"
                                >提起二次申诉
                              </el-radio>
                            </el-radio-group>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row
                        v-if="
                          (appealStatus == 5 || appealStatus == 3 || appealStatus == 7) &&
                            procTaskId != null &&
                            reTaskModel.responseResult == 2
                        "
                      >
                        <el-col :span="24">
                          <el-form-item label="申诉理由" label-width="69px">
                            <el-input
                              v-model="reTaskModel.responseContent"
                              placeholder="请输入内容"
                              :disabled="isShenSuScored"
                            ></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col
                          :span="24"
                          v-if="
                            appealStatus == 3 || appealStatus == 5 || appealStatus == 7
                          "
                        >
                          <div class="btns footer">
                            <div>
                              <el-button
                                :disabled="isShenSuScored"
                                @click="submitScore"
                                type="primary"
                              >
                                提交
                              </el-button>
                            </div>
                          </div>
                        </el-col>
                      </el-row>
                    </el-form>
                  </div>
                </div>
              </div>
            </div>
            <div class="standards_part">
              <div class="label">评分说明</div>
              <el-collapse class="coll" v-model="activeName" accordion>
                <template v-if="isShowFirst">
                  <el-collapse-item title="初检评分说明" name="1">
                    <div>{{ noteList[0] || '--' }}</div>
                  </el-collapse-item>
                </template>
                <template v-if="isShowSecond">
                  <el-collapse-item title="复检评分说明" name="2">
                    <div>{{ noteList[1] || '--' }}</div>
                  </el-collapse-item>
                </template>
                <template v-if="isShowThird">
                  <el-collapse-item title="一次申诉评分说明" name="3">
                    <div>{{ noteList[2] || '--' }}</div>
                  </el-collapse-item>
                </template>
                <template v-if="isShowFour">
                  <el-collapse-item title="二次申诉评分说明" name="4">
                    <div>
                      {{ noteList[3] || '--' }}
                    </div>
                  </el-collapse-item>
                </template>
              </el-collapse>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
    <el-dialog
      append-to-body
      title="添加案例"
      :visible.sync="showAddCaseDialog"
      :close-on-click-modal="false"
      :before-close="handleCloseAddCaseDialog"
      class="showDialogHeader"
    >
      <el-form
        :model="AddCaseModel"
        ref="AddCaseModel"
        label-width="70px"
        :rules="addCaseRules"
        label-position="left"
      >
        <div class="contentRight">
          <div class="addCaseReason">
            <el-form-item label="添加到" prop="dataType">
              <el-select v-model="AddCaseModel.dataType" placeholder="请选择">
                <el-option
                  v-for="item in dataTree"
                  :key="item.caseClassId"
                  :label="item.className"
                  :value="item.caseClassId"
                  :disabled="item.disabled"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="理由" prop="addCaseReason">
              <el-input
                type="textarea"
                :rows="12"
                placeholder="请输入添加原因"
                v-model="AddCaseModel.addCaseReason"
              >
              </el-input>
            </el-form-item>
          </div>
        </div>
        <el-form-item>
          <div class="btns addCaseReason_btns">
            <el-button @click="handleCloseAddCaseDialog">取消</el-button>
            <el-button type="primary" @click="hasSameCaseThrottle">添加</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
    <div v-if="fromUrl == 'recordingpoll'" class="callInTrailBar" id="callInBtnBar">
      <el-popover
        style="margin-right: 20px;text-align:left;"
        v-for="(item, i) in callInTrailBarsData"
        :key="i"
        placement="bottom"
        width="300"
        trigger="hover"
      >
        <div>
          <div style="min-height:40px;line-height: 20px;">
            <span>录音编号：</span>{{ item.callId }}
          </div>
          <div style="min-height:40px;line-height: 40px;">
            <span>关键词标签：</span>
            <el-tag
              style="margin-right: 10px;"
              v-for="(tag, i) in item.keyWordLabels"
              :key="i"
              >{{ tag }}
            </el-tag>
          </div>
          <div style="min-height:40px;line-height: 40px;">
            <span>情绪标签：</span>
            <div
              style="margin-right: 10px;display: inline-block"
              v-for="(senttag, i) in item.sentimentLabels"
              :key="i"
            >
              <span
                style="color:#12a037;border: 1px solid #12a037;display: inline-block;
    font-size: 12px;
    height: 12px;
    line-height: 12px;
    border-radius: 4px;
    padding: 4px 10px;"
                v-if="senttag && senttag.indexOf('积极') != -1"
                class="callInTrailBar_emotionBlock"
                >{{ senttag }}</span
              >
              <span
                style="color:#f00;border: 1px solid #f00;display: inline-block;
    font-size: 12px;
    height: 12px;
    line-height: 12px;
    border-radius: 4px;
    padding: 4px 10px;"
                v-if="senttag && senttag.indexOf('消极') != -1"
                class="callInTrailBar_emotionBlock"
                >{{ senttag }}</span
              >
            </div>
          </div>
          <div style="min-height:40px;line-height: 40px;"><span>备注：</span></div>
          <div style="line-height: 20px;">{{ item.remarks }}</div>
        </div>
        <el-button
          @click="showDetail($event, item.callId, item.recordFileURL)"
          type="text"
          style="color:#000"
          slot="reference"
          >{{ item.callSTime }} 呼入
        </el-button>
      </el-popover>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import moment from 'moment'
import global from '../../../global.js'
import qs from 'qs'
// import vPlayer from '../../common/player.vue'
import formatdate from '../../../utils/formatdate.js'
import matchRoleId from '../../../utils/matchRoleId'
import throttledMessage from './throttledMessage'

let qualityUrl = global.qualityUrl
let hrmApi = global.hrmApi

export default {
  name: 'recordingPlayResultScore',
  beforeCreate() {
    this.$message = throttledMessage
  },
  data() {
    return {
      noteList: [], // 多个评分说明
      activeName: '', // 评分说明
      judgeArr: [5, 11, 7, 8],
      isShowPlayInfoTooltip: false,
      isEditPlayInfoList: true,
      callInTrailBarsData: [], // 此来电录音轨迹数据
      isShowrefuse: false,
      isShowadopt: false,
      isShoweditCase: false,
      isShowLook: false,
      isShowdelby: false,
      isShowdelete: false,
      isShowclose: false,
      isShowedit: false,
      isShowplus: false,
      isDisabledEdit: false,
      isDisabledPlus: false,
      isShowAnLiGuanLi: false,
      playInfoVosList: [], // 通话内容列表
      scoringTrajectory: [], // 评分轨迹
      aclOperVo: {},
      value: 4, // 坐席星级
      serviceLabels: [], // 坐席标签
      customInfoModel: {},
      parentModel: {},
      esResultModel: {
        seatStar: 1,
        callSTime: '',
        callETime: '',
      }, // 基本信息
      showAddCaseDialog: false, // 添加案例
      labelWidth: '80px',
      classifyObject: {}, // 选中的分类
      defaultProps: {
        children: 'listClass',
        label: 'name',
      },
      addClassRules: {
        // 添加案例验证
        name: [
          {
            required: true,
            message: '分类名称不能为空',
            trigger: 'blur',
          },
        ],
      },
      AddCaseModel: {
        dataType: '', // 案例分类
        addCaseReason: '', // 案例弹窗
      },
      addCaseRules: {
        // 添加案例验证
        dataType: [
          {
            required: true,
            message: '请选择分类',
            trigger: 'change',
          },
        ],
        addCaseReason: [
          {
            required: true,
            message: '请输入添加原因',
            trigger: 'blur',
          },
        ],
      },
      caseTag: [],
      returnVisitMatchResult: [],
      minSpeed: 1, // 最慢语速
      maxSpeed: 10, // 最快语速
      times: [], // 对话时间
      modleTitle: '', // 质检模版名称
      qaScoreType: '', // 质检打分阶段
      isScored: false, // 申诉是否已打分
      standardsListWithAutoScoreQa: [],
      focusWord: '', // 要高亮显示的词
      // 智能筛选高亮词
      focusWordIntell: {
        keyword: '',
        clickIndex: 0,
        fullScriptRole: '',
        targetTimeStart: '',
        targetTimeEnd: '',
      },
      // 智能筛选命中词
      keywordCollection: new Set(),
      keywords: [],
      roleCodeId: [], // 角色编码
      // 是否第一次点击
      isFirst: true,
      currentClass: '', // 当前正在播放的录音内容所在的盒子的class
      color: ['success', 'warning', 'danger', 'gray'],
      hitWords: {
        '1': [],
        '2': [],
        '0': [],
      }, // 智能筛选命中词
      countHasError: false, // 自动打分修改的是否正确
      editCountKey: '',
      handleContent: '',
      modleId: '',
      testData: {
        ad: '0',
      },
      isAutoDead: '2',
      isDead: '1',
      deadItem: '2',
      deadOptions: [
        {
          value: 1,
          label: '致命',
        },
        {
          value: 2,
          label: '非致命',
        },
      ],
      scoreDetails: [], // 人工打分table
      filterFaq: [], // 过滤内容质检话术意图命中项
      currentDistribute: [], // 要保存的当前分数列表,自动打分项
      scoreObjs: [], // 人工质检打分项对象
      scored: false, // 默认未打分
      modelId: '', // 模版ID
      role: '', // 角色
      roleId: '', // 角色ID
      procTaskId: '', // 如果null  不进行2次申诉 !null 可以进行二次申诉
      reTaskModel: {
        responseContent: '',
        responseResult: '',
      },
      isShenSuScored: false, // 申诉已打分
      okToSubmit: true, // 是否可以提交
      errorMessage: {}, // 错误信息
      dataTree: [],
      baseScore: 100,
      flowListWithScoreQa: [], // 流程对象存储
      flowListScoreObjs: [], // 要保存的当前分数列表，流程评分
      mingzhongTip: '此标准为致命项标准，命中则总分为 0',
      historyDeadItem: 2,
    }
  },
  computed: {
    isShowFirst() {
      const { roleCodeId, fromUrl, qaScoreType } = this
      let isShow = false
      if (roleCodeId.includes('qa_suvs')) {
        if (fromUrl == 'recordingpoll') {
          if ([1, 2, 3, 4].includes(qaScoreType)) isShow = true
        } else if (fromUrl == 'scoreResultInfo') {
          isShow = true
        }
      } else {
        isShow = qaScoreType == 1
      }
      return isShow
    },
    isShowSecond() {
      const { roleCodeId, fromUrl, qaScoreType } = this
      let isShow = false
      if (roleCodeId.includes('qa_suvs')) {
        if (fromUrl == 'recordingpoll') {
          if ([2, 3, 4].includes(qaScoreType)) isShow = true
        } else if (fromUrl == 'scoreResultInfo') {
          isShow = true
        }
      } else {
        isShow = qaScoreType == 2
      }
      return isShow
    },
    isShowThird() {
      const { roleCodeId, fromUrl, qaScoreType, isScored } = this
      let isShow = false
      if (roleCodeId.includes('qa_suvs')) {
        if (fromUrl == 'recordingpoll') {
          isShow = [3, 4].includes(qaScoreType)
        } else if (fromUrl == 'scoreResultInfo') {
          isShow = (qaScoreType == 3 && isScored == true) || qaScoreType == 4
        }
      } else {
        isShow = qaScoreType == 3
      }
      return isShow
    },
    isShowFour() {
      const { roleCodeId, fromUrl, qaScoreType, isScored } = this
      let isShow = false
      if (roleCodeId.includes('qa_suvs')) {
        if (fromUrl == 'recordingpoll') {
          isShow = qaScoreType == 4
        } else if (fromUrl == 'scoreResultInfo') {
          isShow = qaScoreType == 4 && isScored == true
        }
      } else {
        isShow = qaScoreType == 4
      }
      return isShow
    },
    keywordsHigh() {
      if (this.$store.state.keywordsHigh == null) {
        return ''
      } else {
        return this.$store.state.keywordsHigh.keywords
      }
    },
    accountId() {
      return this.$store.state.loginUserinfo.accountId
    },
    currentTime() {
      return this.$store.state.playerInfo.currentTime * 1000
    },
    callId() {
      return this.$store.state.recordingPlayPage.callId
    },
    callSTime() {
      return this.$store.state.recordingPlayPage.callSTime
    },
    callNo() {
      return this.$store.state.recordingPlayPage.callNo
    },
    mblNo() {
      return this.$store.state.recordingPlayPage.mblNo
    },
    appealId() {
      return this.$store.state.recordingPlayPage.appealId
    },
    appealStatus() {
      return this.$store.state.recordingPlayPage.appealStatus
    },
    taskStatus() {
      return this.$store.state.recordingPlayPage.taskStatus
    },
    secAppFlag() {
      return this.$store.state.recordingPlayPage.secAppFlag
    },
    resultScoreIndex() {
      return this.$store.state.recordingPlayPage.resultScoreIndex
    },
    taskId() {
      return this.$store.state.recordingPlayPage.taskId
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
    FuyiTask_EndTime() {
      return this.$store.state.recordingPlayPage.FuyiTask_EndTime
    },
    fromUrl() {
      let name = this.$store.state.recordingPlayPage.from
      return name
    },
    fromPage() {
      return this.$store.state.recordingPlayPage.fromPage
    },
    isSampled() {
      return this.$store.state.recordingPlayPage.isSampled
    },
    obj() {
      return this.$store.state.recordingPlayPage
    },
    spanFirst() {
      const from = this.obj.from
      return from === 'artificialSample' ||
        from === 'caseManage_new' ||
        from === 'myColList' ||
        from === 'hotWord' ||
        from === 'audioClassification' ||
        from === 'clusterRule_hrlist' ||
        from === 'clusterTrain' ||
        (from == 'recordingpoll' && this.isSampled == 0)
        ? 10
        : 7
    },
    spanSecond() {
      const from = this.obj.from
      return from === 'artificialSample' ||
        from === 'caseManage_new' ||
        from === 'myColList' ||
        from === 'hotWord' ||
        from === 'audioClassification' ||
        from === 'clusterRule_hrlist' ||
        from === 'clusterTrain' ||
        (from == 'recordingpoll' && this.isSampled == 0)
        ? 14
        : 8
    },
    spanThird() {
      const from = this.obj.from
      return from === 'artificialSample' ||
        from === 'caseManage_new' ||
        from === 'myColList' ||
        from === 'hotWord' ||
        from === 'audioClassification' ||
        from === 'clusterRule_hrlist' ||
        from === 'clusterTrain' ||
        (from == 'recordingpoll' && this.isSampled == 0)
        ? 0
        : 9
    },
    flowScoreFun() {
      let total = 0
      let _this = this
      if (_this.qaScoreType == 0) {
        this.flowListScoreObjs.forEach(function(temp, index) {
          if (_this.fromUrl == 'recordingpoll') {
            // 录音池
            if (_this.qaScoreType == 1) {
              total += parseInt(temp.firstScore) || 0
            } else if (_this.qaScoreType == 2) {
              total += parseInt(temp.secondScore) || 0
            } else if (_this.qaScoreType == 3) {
              total += parseInt(temp.thirdScore) || 0
            } else if (_this.qaScoreType == 4) {
              total += parseInt(temp.fourthScore) || 0
            }
          }
        })
      } else {
        for (let key = 0; key < this.flowListWithScoreQa.length; key++) {
          _this.flowListWithScoreQa[key].processDetail.forEach(function(temp, index) {
            if (
              _this.fromUrl !== 'recordingpoll' &&
              _this.fromUrl !== 'sysAutoScoringInCallResult'
            ) {
              // 系统自动评分，质检成绩查看
              // 坐席成绩查看 最终成绩
              if (
                (_this.roleCodeId.includes('seatman') && _this.appealStatus == 3) ||
                (_this.roleCodeId.includes('seatman') && _this.appealStatus == 6) ||
                (_this.roleCodeId.includes('seatman') && _this.appealStatus == 13)
              ) {
                total += parseInt(temp.thirdScore) || 0
              } else if (
                (_this.roleCodeId.includes('seatman') && _this.appealStatus == 4) ||
                (_this.roleCodeId.includes('seatman') && _this.appealStatus == 8)
              ) {
                total += parseInt(temp.fourthScore) || 0
              } else if (_this.roleCodeId.includes('qa_suvs') === false) {
                total += parseInt(temp.secondScore) || 0
              } else if (_this.roleCodeId.includes('qa_suvs')) {
                // 主管成绩查看， 系统自动评分
                if (
                  (_this.qaScoreType == 1 && _this.isScored == true) ||
                  (_this.qaScoreType == 2 && _this.isScored == false)
                ) {
                  total += parseInt(temp.firstScore) || 0
                } else if (
                  (_this.qaScoreType == 2 && _this.isScored == true) ||
                  (_this.qaScoreType == 3 && _this.isScored == false)
                ) {
                  total += parseInt(temp.secondScore) || 0
                } else if (
                  (_this.qaScoreType == 3 && _this.isScored == true) ||
                  (_this.qaScoreType == 4 && _this.isScored == false)
                ) {
                  total += parseInt(temp.thirdScore) || 0
                } else if (_this.qaScoreType == 4 && _this.isScored == true) {
                  total += parseInt(temp.fourthScore) || 0
                }
              }
            } else if (_this.fromUrl == 'recordingpoll') {
              // 录音池
              if (_this.qaScoreType == 1) {
                total += parseInt(temp.firstScore) || 0
              } else if (_this.qaScoreType == 2) {
                total += parseInt(temp.secondScore) || 0
              } else if (_this.qaScoreType == 3) {
                total += parseInt(temp.thirdScore) || 0
              } else if (_this.qaScoreType == 4) {
                total += parseInt(temp.fourthScore) || 0
              }
            }
            if (_this.fromUrl == 'sysAutoScoringInCallResult') {
              total += parseInt(temp.firstScore) || 0
            }
          })
        }
      }
      return total
    },
    autoScoreFun() {
      let total = 0
      let _this = this
      let flag = true
      for (let key in this.standardsListWithAutoScoreQa) {
        _this.standardsListWithAutoScoreQa[key].forEach(function(item) {
          // 坐席成绩查看
          if (
            _this.fromUrl !== 'recordingpoll' &&
            _this.fromUrl !== 'sysAutoScoringInCallResult'
          ) {
            // 系统自动评分，质检成绩查看
            if (_this.roleCodeId.includes('qa_suvs') === false) {
              if (item.judge !== 8 && item.deadItem !== '1') {
                total += parseInt(item.defaultScore) || 0
              }
              if (item.judge == 8 && flag) {
                if (item.defaultScore == '1') {
                  // 如果有一项是致命项则所有的非致命项不能生效
                  _this.isDead = '0'
                  flag = false
                } else {
                  _this.isDead = '1'
                }
              }
            } else if (
              (_this.roleCodeId.includes('seatman') && _this.appealStatus == 3) ||
              (_this.roleCodeId.includes('seatman') && _this.appealStatus == 6)
            ) {
              if (item.judge !== 8 && item.deadItem !== '1') {
                total += parseInt(item.threeScore) || 0
              } else if (item.judge == 8 && flag) {
                if (item.threeScore == '1') {
                  // 如果有一项是致命项则所有的非致命项不能生效
                  _this.isDead = '0'
                  flag = false
                } else {
                  _this.isDead = '1'
                }
              }
            } else if (
              (_this.roleCodeId.includes('seatman') && _this.appealStatus == 4) ||
              (_this.roleCodeId.includes('seatman') && _this.appealStatus == 8)
            ) {
              if (item.judge !== 8 && item.deadItem !== '1') {
                total += parseInt(item.fourScore) || 0
              } else if (item.judge == 8 && flag) {
                if (item.fourScore == '1') {
                  // 如果有一项是致命项则所有的非致命项不能生效
                  _this.isDead = '0'
                  flag = false
                } else {
                  _this.isDead = '1'
                }
              }
            } else if (_this.roleCodeId.includes('qa_suvs')) {
              // 主管成绩查看
              if (
                (_this.qaScoreType == 1 && _this.isScored == true) ||
                (_this.qaScoreType == 2 && _this.isScored == false)
              ) {
                if (item.judge !== 8 && item.deadItem !== '1') {
                  total += parseInt(item.firstQaScore) || 0
                } else if (item.judge == 8 && flag) {
                  if (item.firstQaScore == '1') {
                    // 如果有一项是致命项则所有的非致命项不能生效
                    _this.isDead = '0'
                    flag = false
                  } else {
                    _this.isDead = '1'
                  }
                }
              } else if (
                (_this.qaScoreType == 2 && _this.isScored == true) ||
                (_this.qaScoreType == 3 && _this.isScored == false)
              ) {
                if (item.judge !== 8 && item.deadItem !== '1') {
                  total += parseInt(item.secondQaScore) || 0
                } else if (item.judge == 8 && flag) {
                  if (item.secondQaScore == '1') {
                    // 如果有一项是致命项则所有的非致命项不能生效
                    _this.isDead = '0'
                    flag = false
                  } else {
                    _this.isDead = '1'
                  }
                }
              } else if (
                (_this.qaScoreType == 3 && _this.isScored == true) ||
                (_this.qaScoreType == 4 && _this.isScored == false)
              ) {
                if (item.judge !== 8 && item.deadItem !== '1') {
                  total += parseInt(item.threeScore) || 0
                } else if (item.judge == 8 && flag) {
                  if (item.threeScore == '1') {
                    // 如果有一项是致命项则所有的非致命项不能生效
                    _this.isDead = '0'
                    flag = false
                  } else {
                    _this.isDead = '1'
                  }
                }
              } else if (_this.qaScoreType == 4 && _this.isScored == true) {
                if (item.judge !== 8 && item.deadItem !== '1') {
                  total += parseInt(item.fourScore) || 0
                } else if (item.judge == 8 && flag) {
                  if (item.fourScore == '1') {
                    // 如果有一项是致命项则所有的非致命项不能生效
                    _this.isDead = '0'
                    flag = false
                  } else {
                    _this.isDead = '1'
                  }
                }
              }
            }
          } else if (_this.fromUrl == 'recordingpoll') {
            // 录音池
            if (_this.qaScoreType == 1) {
              if (item.judge !== 8 && item.deadItem !== '1') {
                total += parseInt(item.firstQaScore) || 0
              } else if (item.judge == 8 && flag) {
                if (item.firstQaScore == '1') {
                  // 如果有一项是致命项则所有的非致命项不能生效
                  _this.isDead = '0'
                  flag = false
                } else {
                  _this.isDead = '1'
                }
              }
            } else if (_this.qaScoreType == 2) {
              if (item.judge !== 8 && item.deadItem !== '1') {
                total += parseInt(item.secondQaScore) || 0
              } else if (item.judge == 8 && flag) {
                if (item.secondQaScore == '1') {
                  // 如果有一项是致命项则所有的非致命项不能生效
                  _this.isDead = '0'
                  flag = false
                } else {
                  _this.isDead = '1'
                }
              }
            } else if (_this.qaScoreType == 3) {
              if (item.judge !== 8 && item.deadItem !== '1') {
                total += parseInt(item.threeScore) || 0
              } else if (item.judge == 8 && flag) {
                if (item.threeScore == '1') {
                  // 如果有一项是致命项则所有的非致命项不能生效
                  _this.isDead = '0'
                  flag = false
                } else {
                  _this.isDead = '1'
                }
              }
            } else if (_this.qaScoreType == 4) {
              if (item.judge !== 8 && item.deadItem !== '1') {
                total += parseInt(item.fourScore) || 0
              } else if (item.judge == 8 && flag) {
                if (item.fourScore == '1') {
                  // 如果有一项是致命项则所有的非致命项不能生效
                  _this.isDead = '0'
                  flag = false
                } else {
                  _this.isDead = '1'
                }
              }
            }
          }
          if (_this.fromUrl == 'sysAutoScoringInCallResult') {
            // 系统自动评分
            if (item.judge !== 8 && item.deadItem !== '1') {
              total += parseInt(item.defaultScore) || 0
            } else if (item.judge == 8 && flag) {
              if (item.defaultScore == '1') {
                // 如果有一项是致命项则所有的非致命项不能生效
                _this.isDead = '0'
                flag = false
              } else {
                _this.isDead = '1'
              }
            }
          }
        })
      }
      if (_this.isAutoDead == '1' || _this.isDead == '0') {
        return 0
      }
      return total
    },
    totalScoreFun() {
      if (this.isAutoDead == '1' || this.isDead == '0') {
        this.deadItem = '1'
        return 0
      }
      this.deadItem = '2'
      let totalScore =
        this.baseScore + (this.autoScoreFun + this.flowScoreFun) > 0
          ? this.baseScore + (this.autoScoreFun + this.flowScoreFun)
          : 0
      return totalScore
    },
  },
  created() {
    this.resetOrderFlag()
    const promise = this.getPlayInfo() // 获取录音文本信息（对话内容)
    let _this = this
    this.$nextTick(() => {
      promise.then(() => _this.initFrom())
      if (_this.fromUrl != 'audioClassification') {
        // 业务分类播放页不需要获取模板
        _this.getFlowIds()
      }
      if (this.fromUrl === 'recordingpoll') {
        this.getIncomngTrail()
      }
    })
    this.initActRole()
    this.getCaseTag() // 获取录音案例标签
  },
  mounted() {
    this.getLocus()
  },
  methods: {
    formatJudge(row) {
      let objname = {
        '1': '情绪',
        '2': '重叠次数',
        '3': '静默',
        '4': '语速',
        '5': '关键词',
        '6': '自定义输入',
        '7': '自定义选择',
        '8': '自定义致命',
        '11': '标签',
        '12': '上下文质检',
        '13': '内容质检',
      }
      return objname[row.judge]
    },
    getHtml(flag) {
      let arrAll = flag.split(' ')
      for (let i = 0; i < arrAll.length; i++) {
        if (
          this.esResultModel.correctWholeContent &&
          this.esResultModel.correctWholeContent.includes(arrAll[i].replace(/[(|)]/g, ''))
        ) {
          if (arrAll[i].includes('(')) {
            arrAll[i] = `(<span style='color:#409eff;'>${arrAll[i].replace(
              /[(|)]/g,
              ''
            )}</span>`
          } else if (arrAll[i].includes(')')) {
            arrAll[i] = `<span style='color:#409eff;'>${arrAll[i].replace(
              /[(|)]/g,
              ''
            )}</span>)`
          } else {
            arrAll[i] = `<span style='color:#409eff;'>${arrAll[i]}</span>`
          }
        }
      }
      let endStr = arrAll.toString().replace(/,/g, ' ')
      return endStr
    },
    getContentHtml(flag) {
      if (this.filterFaq.includes(flag)) {
        flag = `<span style='color:#409eff;'>${flag}</span>`
      }
      return flag
    },
    getLabelContentList(content) {
      return typeof content === 'string' ? content.split(',') : []
    },
    init: function() {
      // 重置
      this.standardsListWithAutoScoreQa = []
      this.flowListWithScoreQa = []
      this.playInfoVosList = []
      this.isShenSuScored = false // 清除状态
      this.reTaskModel = {
        responseContent: '',
        responseResult: '',
      }
      // 获取录音文本信息（对话内容）
      this.getPlayInfo().then(() => this.initFrom())
      this.getLocus()
      if (this.fromUrl != 'audioClassification') {
        // 业务分类播放页不需要获取模板
        this.getFlowIds()
      }
      this.isAutoDead = '2'
      this.isDead = '1'
      if (this.fromUrl === 'recordingpoll') {
        this.getIncomngTrail()
        this.clearHigh()
      }
    },
    initRecordingpoll: function() {
      // 获取录音文本信息（对话内容）
      this.getPlayInfo().then(() => this.initFrom())
      this.getLocus()
      this.isAutoDead = '2'
      this.isDead = '1'
    },
    // 坐席成绩确认change
    changeReTaskModel(val) {
      this.reTaskModel.responseContent = ''
    },
    // 致命项得分
    getKeywordScoreFilter(rules, judge) {
      const { roleOptions, positionOptions, positionOptionsText } = global
      const {
        increaseDeduction,
        score,
        isAppear,
        deadItem,
        offset,
        position,
        roleType,
        sceneTime,
        silenceTimeMax,
      } = rules
      let str = ''
      if (deadItem !== '1') {
        let offsetValue = judge === 5 && position != 0 ? `${offset} 句` : ''
        judge === 5
          ? (str = ` 在 ${roleOptions[roleType]}侧 在 ${
              positionOptionsText[position]
            } ${offsetValue} ${isAppear == '1' ? '出现' : '未出现'}${
              increaseDeduction == '2' ? '减' : '加'
            }${score}分`)
          : (str = ` 在${roleOptions[roleType]}侧 在静默时间大于 ${silenceTimeMax} 秒 ${
              positionOptions[position]
            } ${sceneTime} 句 ${isAppear == '1' ? '出现' : '未出现'}${
              increaseDeduction == '2' ? '减' : '加'
            }${score}分`)
      }
      return str
    },
    // 录音池页面获取当前号码录音
    getIncomngTrail: function() {
      let _this = this
      let params = {
        callNo: this.callNo || this.mblNo,
        callSTime: this.callSTime,
      }
      this.axios
        .post(qualityUrl + '/spc/getIncomingCallTrack.do', qs.stringify(params))
        .then((res) => {
          _this.callInTrailBarsData = res.data
        })
        .catch(() => {})
    },
    clearHigh: function() {
      let childs = document.getElementById('callInBtnBar').children
      for (let i = 0; i < childs.length; i++) {
        let item = childs[i].children[0].children[0]
        item.style.color = '#000'
      }
    },
    showDetail(e, id, recordFileURL) {
      this.clearHigh()
      e.target.style.color = '#20a0ff'
      let obj = {}
      obj.callId = id
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      this.initRecordingpoll()
    },
    initFrom: function() {
      this.isEditPlayInfoList = true
      if (this.fromUrl === 'scoreResultInfo') {
        this.getResultScore(this.obj)
      } else if (this.fromUrl === 'recordingpoll') {
        if (this.isSampled == 1) {
          this.getRecordPollScore(this.obj) // 录音池
        }
      } else {
        if (
          ['audioClassification', 'clusterTrain', 'hotWord'].indexOf(this.fromUrl) === -1
        ) {
          // 业务分类、主题聚类、热词分析播放页不需要获取评分
          this.getConditonScore(this.obj)
        }
      }
    },
    // 获取基准分
    getBaseScore(modelId, callId) {
      let _this = this
      let params = {
        moduleId: modelId,
        callId: callId,
      }
      let url = qualityUrl + '/qaDetail/getBaseScore.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.baseScore = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取基准分失败',
          })
        })
    },
    dateFormat: function(date) {
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // 获取角色
    initActRole() {
      let that = this
      this.axios
        .get(hrmApi + '/role/rolesForAccount.do?accountID=' + this.accountId, {})
        .then((res) => {
          that.role = res.data.Data
          that.roleId = res.data.IDS
          if (that.role == null || that.role == '') {
            that.role = '主管'
            that.roleId = '超级管理员'
          }
          that.matchActRoleId(res.data.IDS)
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 匹配角色ID
    matchActRoleId(id) {
      let _this = this
      let ids = id.split(',')
      let parames = {
        code: global.roleCode.toString(),
      }
      this.axios
        .post(qualityUrl + '/pageConstant/getRoleIdByCode.do', qs.stringify(parames))
        .then((res) => {
          if (_this.role == '主管' && _this.roleId == '超级管理员') {
            _this.roleCodeId.push('qa_suvs')
          } else {
            let resdata = res.data
            _this.roleCodeId = matchRoleId.match(ids, resdata)
          }
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 时间转化
    fromData: function(data) {
      let newData = new Date(data)
      let m = newData.getMonth()
      let d = newData.getDay()
      return m + '-' + d
    },
    // 坐席提起二次申诉
    submitScore() {
      if (!this.reTaskModel.responseResult) {
        this.$message({
          type: 'error',
          message: '请选择质检状态',
        })
        return
      }
      let _this = this
      let url = global.qualityUrl + '/appealsProcess/appealResuslt.do'
      let params = {
        callId: this.callId,
        comments: this.reTaskModel.responseContent,
        appealResultState: this.reTaskModel.responseResult,
        procTaskId: this.procTaskId,
        appealId: this.appealId,
        scoreId: _this.obj.scoreId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then((response) => {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '提交成功',
            })
            _this.getResultScore(_this.obj)
            this.$emit('shenSuScored')
            _this.isShenSuScored = true
          } else {
            _this.$message({
              type: 'error',
              message: response.message,
            })
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '提交成绩失败',
          })
        })
    },
    // 获取开始时间和结束时间，保存到vuex中
    playClip(startTime, endTime) {
      console.log(startTime)
      let playInfo = {}
      playInfo.timeSection = [startTime, endTime]
      this.$store.commit('setPlayerInfo', playInfo)
    },
    // 高亮关键词
    hightlightContent(word) {
      this.focusWord = word
    },
    hightlightContentIntell(word, deadItem) {
      this.focusWordIntell = word
      this.historyDeadItem = deadItem
    },
    // 智能筛选的质检分数中设置高亮词 role为custom=>客户，agent=> 客服
    highlightWord(val, oldval, fullScriptRole) {
      let selector = ''
      if (parseInt(fullScriptRole) === 1) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(fullScriptRole) === 2) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let _this = this
      val = val.trim().replace(/[(|)]/g, '')
      oldval = oldval.trim() || ''
      let elesSelector = document.querySelectorAll(selector)
      if (elesSelector.length === 0) {
        return
      } else {
        elesSelector.forEach(function(item) {
          // 当要高亮显示的文字变化时，先清空原来的高亮
          if (oldval) {
            // 去掉原先的高亮，不能直接用oldval替换，oldval的值有可能是查询条件的值，比如‘你好 or 您好’
            item.innerHTML = item.innerText
            // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, oldval)
          }
          if (val) {
            // 多个高亮
            let keywordArray = val.split(' ')
            keywordArray.forEach(function(keyword) {
              if (keyword != '' && item.innerHTML.indexOf(keyword) != -1) {
                item.innerHTML = item.innerHTML.replace(
                  new RegExp(keyword, 'gm'),
                  '<span style="color: #20a0ff">' + keyword + '</span>'
                )
                if (
                  _this.hitWords[fullScriptRole] &&
                  _this.hitWords[fullScriptRole].indexOf(keyword) <= 0
                ) {
                  _this.hitWords[fullScriptRole].push(keyword)
                }
              }
            })
          }
        })
      }
    },
    // 智能筛选页面刚刚进来的时候要把所有符合条件的关键词都标红
    highlightWordAll(val) {
      let selector = ''
      if (parseInt(val.fullScriptRole) === 1) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 2) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let eles = document.querySelectorAll(selector)
      if (!eles || eles.length === 0) {
        return
      } else {
        eles.forEach(function(item) {
          let className = item.parentElement.className.split(' ')
          let startTime = parseInt(className[1].substr(1).trim())
          let endTime = parseInt(className[2].substr(1).trim())
          if (!(startTime <= val.targetTimeEnd && endTime >= val.targetTimeStart)) {
            return
          }
          if (item.innerHTML.indexOf(val.keyword) != -1) {
            item.innerHTML = item.innerHTML.replace(
              new RegExp(val.keyword, 'gm'),
              '<span style="color: #20a0ff">' + val.keyword + '</span>'
            )
          }
        })
      }
    },
    // 播放器缩小
    minimizePage() {
      this.volumeControl = false
      let playInfo = {}
      playInfo.isMaximization = false
      this.isPlayinfo = playInfo.isclosedialog
      let taskId = this.$store.state.returnVisitConfig.taskId
      let projectId = this.$store.state.returnVisitConfig.projectId
      let matchRecordCount = this.$store.state.returnVisitConfig.matchRecordCount
      let allRecordCount = this.$store.state.returnVisitConfig.allRecordCount
      let matchRatio = this.$store.state.returnVisitConfig.matchRatio
      let obj = {
        taskId: taskId,
        showTaskResult: true,
        showDetailPage: true,
        projectId: projectId,
        matchRecordCount: matchRecordCount,
        allRecordCount: allRecordCount,
        matchRatio: matchRatio,
      }
      this.$store.commit('setTaskResult', obj)
      this.$store.commit('setPlayerInfo', playInfo)
      this.$emit('onminimize', playInfo)
    },
    // 播放器关闭
    closePage() {
      let _this = this
      this.$confirm('关闭界面将停止录音播放，确定关闭么', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let playInfo = {}
          playInfo.isMaximization = false
          playInfo.exist = false
          // let url = _this.fromPage || 'home'
          let taskId = this.$store.state.returnVisitConfig.taskId
          let projectId = this.$store.state.returnVisitConfig.projectId
          let matchRecordCount = this.$store.state.returnVisitConfig.matchRecordCount
          let allRecordCount = this.$store.state.returnVisitConfig.allRecordCount
          let matchRatio = this.$store.state.returnVisitConfig.matchRatio
          let obj = {
            taskId: taskId,
            showTaskResult: true,
            showDetailPage: true,
            projectId: projectId,
            matchRecordCount: matchRecordCount,
            allRecordCount: allRecordCount,
            matchRatio: matchRatio,
          }
          this.$store.commit('setTaskResult', obj)
          this.$store.commit('setPlayerInfo', playInfo)
          this.focusWord = ''
          this.keywords = []
          this.parentModel = {}
          this.activeName = ''
          this.$emit('onclose')
        })
        .catch(() => {})
    },
    test() {
      // 停止正在进行的动画  减少卡顿感
      $('.dialog').stop(true, false)
      if (window.myinterVal) {
        return
      } else {
        window.myinterVal = 5
      }
      setTimeout(function() {
        window.myinterVal = 0
      }, 5000)
      // 清除计时任务
      // 3秒后重新
    },
    // 重置orderFlag字段
    resetOrderFlag() {
      let obj = {}
      obj.orderId = 'call'
      this.$store.commit('setOrderRecordingPlayPage', obj)
    },
    // 获取评分轨迹
    getLocus() {
      let _this = this
      let url = qualityUrl + '/scoreView/getLocus.do'
      let params = {}
      params.objectId = this.callId
      params.scoreClass = '1'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.scoringTrajectory = response.data.locus
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取评分轨迹失败',
          })
        })
    },
    // 质检结果查看成绩查询
    getResultScore(obj) {
      let _this = this
      let url = global.qualityUrl + '/scoreResult/getAllScoreByRole.do'
      let params = {}
      params.objectId = obj.callId
      params.appealId = obj.appealId
      params.state = obj.resultScoreIndex
      params.appealStatus = obj.appealStatus
      // 质检成绩查看页面标识
      params.pageFlag = 1
      // 当主管操作后应该可以确认成绩
      if (
        params.appealStatus == 3 ||
        params.appealStatus == 7 ||
        params.appealStatus == 4 ||
        params.appealStatus == 8
      ) {
        _this.isShenSuScored = false
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.standardsListWithAutoScoreQa = response.data.modleTitle.TempltTA // 有层级关系模版
          _this.modleTitle = response.data.modleTitle.modleTitle // 模版名称
          _this.modelId =
            response.data.modleTitle.Templt.length > 0
              ? response.data.modleTitle.Templt[0].modleId
              : '' // 模版id
          _this.qaScoreType = response.data.modleTitle.qaScoreType
          _this.noteList = response.data.noteList || [null, null, null, null] // 各项打分时的评分说明(初检/复检/一次申诉/二次申诉)
          // 获取内容质检意图与话术的命中词
          _this.filterFaq = []
            .concat(
              ...response.data.scoreDetails.map((item) => {
                return item.contents ? item.contents : []
              })
            )
            .filter((flag) => flag.status === 1)
            .map((val) => val.content)
          _this.getBaseScore(_this.modelId, obj.callId) // 获取基准分
          if (response.data.modleTitle.status == 1) {
            _this.isScored = true
          } else {
            _this.isScored = false
          }
          if (obj.resultScoreIndex == '3') {
            _this.procTaskId = null
          } else {
            _this.procTaskId = response.data.procTaskId
          }
          // 如果获取到了数据则赋值分数
          if (response.data && response.data.scoreDetails) {
            _this.scoreDetails = response.data.scoreDetails
            // 如果是初检页面，则给编辑界面的值赋值
            _this.changData(response.data.scoreDetails)
            _this.handleContent = response.data.score.comments || ''
          } else if (response.data && response.data.score) {
            _this.handleContent = response.data.score.comments
          }
          _this.showKeywordsData()
          _this.judgePlayInfoList(_this.playInfoVosList)
          // 过滤出上下文质检与内容质检的数据
          _this.filterContentData()
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '分数获取失败',
          })
        })
    },
    // 录音池结果成绩查询
    getRecordPollScore(obj) {
      let _this = this
      let url = global.qualityUrl + '/recordingPool/getRecordScore.do'
      let params = {}
      params.callId = obj.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.standardsListWithAutoScoreQa = response.data.dataT // 有层级关系模版
          _this.modleTitle = response.data.modle.modleTitle // 模版名称
          _this.modelId = response.data.modle.modleId // 模版id
          _this.qaScoreType = response.data.qaScoreType
          _this.noteList = response.data.noteList || [null, null, null, null] // 各项打分时的评分说明(初检/复检/一次申诉/二次申诉)
          // 获取内容质检意图与话术的命中词
          _this.filterFaq = []
            .concat(
              ...response.data.scoreDetails.map((item) => {
                return item.contents ? item.contents : []
              })
            )
            .filter((flag) => flag.status === 1)
            .map((val) => val.content)
          _this.getBaseScore(_this.modelId, _this.callId) // 获取基准分
          let indexT = 0
          for (let key in _this.standardsListWithAutoScoreQa) {
            let obj = _this.standardsListWithAutoScoreQa[key]
            obj.forEach(function(item, index) {
              item.newIndex = indexT
              let temp = {}
              temp.normalId = item.normalId
              temp.judge = item.judge
              temp.defaultScore = item.defaultScore
              temp.secondQaScore = item.secondQaScore
              temp.threeScore = item.threeScore
              if (item.judge === 5 || item.judge === 11) {
                // 默认分数特殊处理，在建评分模板时，deaditem =1 时，默认是非致命 = 1，故此处要强制把 非致命改成2
                item.defaultScore =
                  item.resultsObject[0].deadItem == '1' && item.defaultScore == 1
                    ? 2
                    : item.defaultScore
                temp.defaultScore = item.defaultScore
                temp.deadItem = item.resultsObject[0].deadItem
                item.deadItem = item.resultsObject[0].deadItem
              } else if (temp.judge === 7) {
                temp.defaultScore = item.resultsObject[0]
                temp.secondQaScore = item.resultsObject[0]
                temp.threeScore = item.resultsObject[0]
              } else if (temp.judge === 8) {
                // 人工打分致命项默认给个非致命项
                item.defaultScore = item.defaultScore || '2'
                temp.defaultScore = item.defaultScore
                if (!temp.secondQaScore) {
                  temp.secondQaScore = item.defaultScore || '2'
                }
                if (!temp.threeScore) {
                  temp.threeScore = item.defaultScore || '2'
                }
              } else {
                temp.deadItem = '2'
                item.deadItem = '2'
              }
              _this.$set(_this.currentDistribute, indexT, temp)
              indexT++
            })
          }
          // 如果获取到了数据则赋值分数
          if (response.data && response.data.scoreDetails) {
            _this.scoreDetails = response.data.scoreDetails
            // 如果是初检页面，则给编辑界面的值赋值
            _this.changData(_this.scoreDetails)
            _this.handleContent = response.data.score.comments || ''
          } else if (response.data && response.data.score) {
            _this.handleContent = response.data.score.comments
          }
          _this.showKeywordsData()
          _this.judgePlayInfoList(_this.playInfoVosList)
          // 过滤出上下文质检与内容质检的数据
          _this.filterContentData()
        })
        .catch(function() {})
    },
    // 获取当前流程ID和模版信息
    getFlowIds() {
      let _this = this
      let params = {
        callId: this.callId,
        qaScoreType: this.$store.state.recordingPlayPage.qaScoreType,
      }
      this.flowListScoreObjs = []
      this.flowListWithScoreQa = []
      let url = ''
      if (this.fromUrl === 'scoreResultInfo') {
        url = qualityUrl + '/process/queryProcessDetailByCallId.do'
      } else if (this.fromUrl === 'recordingpoll' && this.isSampled == 1) {
        url = qualityUrl + '/process/queryProcessDetailByCallId.do' // 录音池
      } else if (this.fromUrl === 'recordingpoll' && this.isSampled != 1) {
        return false
      } else if (this.fromUrl === 'sysAutoScoringInCallResult') {
        url = qualityUrl + '/process/queryRobertProcessDetailByCallId.do' // 系统自动评分
      } else {
        url = qualityUrl + '/process/queryProcessDetailByCallId.do'
      }
      this.axios
        .post(url, qs.stringify(params))
        .then((res) => {
          if (res.data) {
            let data = res.data
            _this.flowListWithScoreQa = data
            // data.forEach(function (item) {
            //   _this.flowValue.push(item.processId)
            // })
            let indexT = 0
            for (let i = 0; i < data.length; i++) {
              let obj = _this.flowListWithScoreQa[i].processDetail
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.processId = data[i].processId
                temp.intentId = item.intentId
                temp.firstScore = item.firstScore
                temp.secondScore = item.secondScore
                temp.thirdScore = item.thirdScore
                temp.fourthScore = item.fourthScore
                _this.$set(_this.flowListScoreObjs, indexT, temp)
                indexT++
              })
            }
          }
        })
        .catch(function(e) {
          console.log(e)
        })
    },
    // 系统自动评分成绩查询
    getConditonScore(obj) {
      let _this = this
      let url = global.qualityUrl + '/scoreView/getConditonScore.do'
      let params = {}
      params.objectId = obj.callId
      params.taskId = obj.taskId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.standardsListWithAutoScoreQa = response.data.dataT // 有层级关系自动评分
          _this.modleTitle = response.data.modleTitle // 模版名称
          _this.modelId = response.data.modle.modleId // 模版id
          _this.qaScoreType = 1
          _this.getBaseScore(_this.modelId, obj.callId) // 获取基准分
          if (response.data.modle.status === 0) {
            // 是否质检状态
            _this.scored = false
          } else {
            _this.scored = true
          }
          // 获取内容质检意图与话术的命中词
          _this.filterFaq = []
            .concat(
              ...response.data.scoreDetails.map((item) => {
                return item.contents ? item.contents : []
              })
            )
            .filter((flag) => flag.status === 1)
            .map((val) => val.content)
          // 如果获取到了数据则赋值
          if (response.data && response.data.scoreDetails) {
            _this.scoreDetails = response.data.scoreDetails
            // 如果是初检页面，则给编辑界面的值赋值
            _this.changData(response.data.scoreDetails)
            _this.handleContent = response.data.score.comments || ''
          } else if (response.data && response.data.score) {
            _this.handleContent = response.data.score.comments || ''
          }
          _this.showKeywordsData()
          _this.judgePlayInfoList(_this.playInfoVosList)
          // 过滤出上下文质检与内容质检的数据
          _this.filterContentData()
        })
        .catch(function(err) {
          console.log(err)
          _this.$message({
            type: 'error',
            message: '分数获取失败',
          })
        })
    },
    // 根据获取的分数修改模板内容
    changData(scoreDetails) {
      let _this = this
      scoreDetails.forEach(function(item) {
        // let isFind = false
        // let indexT = 0
        for (let key in _this.standardsListWithAutoScoreQa) {
          _this.standardsListWithAutoScoreQa[key].forEach(function(itm) {
            if (itm.normalId == item.normalId) {
              itm.defaultScore = item.score
              if (itm.judge === 5 || itm.judge === 11) {
                itm.deadItem = itm.resultsObject[0].deadItem
              } else if (itm.judge === 12) {
                itm.deadItem = itm.resultsObject[0].sentenceDeadItem
              } else if (
                itm.judge === 7 &&
                item.optioniItem !== null &&
                (itm.judge === 7 && item.optioniItem !== 0)
              ) {
                itm.defaultScore = item.optioniItem
              } else if (itm.judge === 8 && item.optioniItem == '1') {
                // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                _this.isDead = '0'
              } else if (itm.judge === 8 && item.optioniItem == '2') {
                // 非致命
                itm.defaultScore = item.optioniItem
                itm.firstQaScore = item.optioniItem1
                itm.secondQaScore = item.optioniItem2
                itm.threeScore = item.optioniItem3
                itm.fourScore = item.optioniItem4
              } else {
                itm.deadItem = '2'
              }
              if (itm.deadItem === '1') {
                if (itm.defaultScore === 1) {
                  // 已初检
                  _this.isAutoDead = '1'
                }
              }
              if (_this.fromUrl == 'scoreResultInfo') {
                // 质检结果查看
                if (
                  (_this.roleCodeId.includes('seatman') && _this.appealStatus == 3) ||
                  (_this.roleCodeId.includes('seatman') && _this.appealStatus == 6)
                ) {
                  itm.secondQaScore =
                    item.secondQaScore == null ? '' : parseInt(item.secondQaScore)
                  itm.threeScore =
                    item.threeScore == null ? '' : parseInt(item.threeScore)
                  if (itm.judge === 5 || itm.judge === 11) {
                    itm.deadItem = itm.resultsObject[0].deadItem
                  } else if (itm.judge === 12) {
                    itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                  } else if (
                    itm.judge === 7 &&
                    item.optioniItem !== null &&
                    item.optioniItem !== 0
                  ) {
                    itm.secondQaScore = item.optioniItem2
                    itm.threeScore = item.optioniItem3
                  } else if (itm.judge === 8 && itm.threeScore == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '0'
                  } else {
                    itm.deadItem = '2'
                  }
                  if (itm.deadItem === '1') {
                    if (itm.threeScore === 1) {
                      // 已初检
                      _this.isAutoDead = '1'
                    }
                  }
                } else if (
                  (_this.roleCodeId.includes('seatman') && _this.appealStatus == '4') ||
                  (_this.roleCodeId.includes('seatman') && _this.appealStatus == 8)
                ) {
                  itm.secondQaScore =
                    item.secondQaScore == null ? '' : parseInt(item.secondQaScore)
                  itm.fourScore = item.fourScore == null ? '' : parseInt(item.fourScore)

                  if (itm.judge === 5 || itm.judge === 11) {
                    itm.deadItem = itm.resultsObject[0].deadItem
                  } else if (itm.judge === 12) {
                    itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                  } else if (
                    itm.judge === 7 &&
                    item.optioniItem !== null &&
                    item.optioniItem !== 0
                  ) {
                    itm.secondQaScore = item.optioniItem2
                    itm.fourScore = item.optioniItem4
                  } else if (itm.judge === 8 && itm.fourScore == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '0'
                  } else {
                    itm.deadItem = '2'
                  }
                  if (itm.deadItem === '1') {
                    if (itm.fourScore === 1) {
                      // 已初检
                      _this.isAutoDead = '1'
                    }
                  }
                } else if (_this.roleCodeId.includes('qa_suvs')) {
                  if (
                    (_this.qaScoreType == 1 && _this.isScored == true) ||
                    (_this.qaScoreType == 2 && _this.isScored == false)
                  ) {
                    itm.firstQaScore =
                      item.firstQaScore == null ? '' : parseInt(item.firstQaScore)
                    if (itm.judge === 5 || itm.judge === 11) {
                      itm.deadItem = itm.resultsObject[0].deadItem
                    } else if (itm.judge === 12) {
                      itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                    } else if (
                      itm.judge === 7 &&
                      tem.optioniItem1 !== null &&
                      item.optioniItem1 !== 0
                    ) {
                      itm.firstQaScore = item.optioniItem1
                    } else if (itm.judge === 8 && itm.firstQaScore == '1') {
                      // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                      _this.isDead = '0'
                    } else {
                      itm.deadItem = '2'
                    }
                    if (itm.deadItem === '1') {
                      if (itm.firstQaScore === 1) {
                        _this.isAutoDead = '1'
                      }
                    }
                  } else if (
                    (_this.qaScoreType == 2 && _this.isScored == true) ||
                    (_this.qaScoreType == 3 && _this.isScored == false)
                  ) {
                    itm.firstQaScore =
                      item.firstQaScore == null ? '' : parseInt(item.firstQaScore)
                    itm.secondQaScore =
                      item.secondQaScore == null ? '' : parseInt(item.secondQaScore)
                    if (itm.judge === 5 || itm.judge === 11) {
                      itm.deadItem = itm.resultsObject[0].deadItem
                    } else if (itm.judge === 12) {
                      itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                    } else if (
                      itm.judge === 7 &&
                      item.optioniItem2 !== null &&
                      item.optioniItem2 !== 0
                    ) {
                      itm.firstQaScore = item.optioniItem1
                      itm.secondQaScore = item.optioniItem2
                    } else if (itm.judge === 8 && itm.secondQaScore == '1') {
                      // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                      _this.isDead = '0'
                    } else {
                      itm.deadItem = '2'
                    }
                    if (itm.deadItem === '1') {
                      if (itm.secondQaScore === 1) {
                        _this.isAutoDead = '1'
                      }
                    }
                  } else if (
                    (_this.qaScoreType == 3 && _this.isScored == true) ||
                    (_this.qaScoreType == 4 && _this.isScored == false)
                  ) {
                    itm.firstQaScore =
                      item.firstQaScore == null ? '' : parseInt(item.firstQaScore)
                    itm.secondQaScore =
                      item.secondQaScore == null ? '' : parseInt(item.secondQaScore)
                    itm.threeScore =
                      item.threeScore == null ? '' : parseInt(item.threeScore)
                    if (itm.judge === 5 || itm.judge === 11) {
                      itm.deadItem = itm.resultsObject[0].deadItem
                    } else if (itm.judge === 12) {
                      itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                    } else if (
                      itm.judge === 7 &&
                      item.optioniItem3 !== null &&
                      item.optioniItem3 !== 0
                    ) {
                      itm.firstQaScore = item.optioniItem1
                      itm.secondQaScore = item.optioniItem2
                      itm.threeScore = item.optioniItem3
                    } else if (itm.judge === 8 && itm.threeScore == '1') {
                      // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                      _this.isDead = '0'
                    } else {
                      itm.deadItem = '2'
                    }
                    if (itm.deadItem === '1') {
                      if (itm.threeScore === 1) {
                        _this.isAutoDead = '1'
                      }
                    }
                  } else if (_this.qaScoreType == 4 && _this.isScored == true) {
                    itm.firstQaScore =
                      item.firstQaScore == null ? '' : parseInt(item.firstQaScore)
                    itm.secondQaScore =
                      item.secondQaScore == null ? '' : parseInt(item.secondQaScore)
                    itm.threeScore =
                      item.threeScore == null ? '' : parseInt(item.threeScore)
                    itm.fourScore = item.fourScore == null ? '' : parseInt(item.fourScore)
                    if (itm.judge === 5 || itm.judge === 11) {
                      itm.deadItem = itm.resultsObject[0].deadItem
                    } else if (itm.judge === 12) {
                      itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                    } else if (
                      itm.judge === 7 &&
                      item.optioniItem4 !== null &&
                      item.optioniItem4 !== 0
                    ) {
                      itm.firstQaScore = item.optioniItem1
                      itm.secondQaScore = item.optioniItem2
                      itm.threeScore = item.optioniItem3
                      itm.fourScore = item.optioniItem4
                    } else if (itm.judge === 8 && itm.fourScore == '1') {
                      // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                      _this.isDead = '0'
                    } else {
                      itm.deadItem = '2'
                    }
                    if (itm.deadItem === '1') {
                      if (itm.fourScore === 1) {
                        _this.isAutoDead = '1'
                      }
                    }
                  }
                }
              } else if (
                _this.fromUrl == 'recordingpoll' &&
                _this.roleCodeId.includes('qa_suvs')
              ) {
                // 录音池
                if (_this.qaScoreType == 1) {
                  itm.firstQaScore =
                    item.firstQaScore == null ? '' : parseInt(item.firstQaScore)
                  if (itm.judge === 5 || itm.judge === 11) {
                    itm.deadItem = itm.resultsObject[0].deadItem
                  } else if (itm.judge === 12) {
                    itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                  } else if (
                    itm.judge === 7 &&
                    item.optioniItem1 !== null &&
                    item.optioniItem1 !== 0
                  ) {
                    itm.firstQaScore = item.optioniItem1
                  } else if (itm.judge === 8 && itm.firstQaScore == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '0'
                  } else {
                    itm.deadItem = '2'
                  }
                  if (itm.deadItem === '1') {
                    if (itm.firstQaScore === 1) {
                      _this.isAutoDead = '1'
                    }
                  }
                } else if (_this.qaScoreType == 2) {
                  itm.firstQaScore =
                    item.firstQaScore == null ? '' : parseInt(item.firstQaScore)
                  itm.secondQaScore =
                    item.secondQaScore == null ? '' : parseInt(item.secondQaScore)
                  if (itm.judge === 5 || itm.judge === 11) {
                    itm.deadItem = itm.resultsObject[0].deadItem
                  } else if (itm.judge === 12) {
                    itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                  } else if (
                    itm.judge === 7 &&
                    item.optioniItem2 !== null &&
                    item.optioniItem2 !== 0
                  ) {
                    itm.firstQaScore = item.optioniItem1
                    itm.secondQaScore = item.optioniItem2
                  } else if (itm.judge === 8 && itm.secondQaScore == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '0'
                  } else {
                    itm.deadItem = '2'
                  }
                  if (itm.deadItem === '1') {
                    if (itm.secondQaScore === 1) {
                      _this.isAutoDead = '1'
                    }
                  }
                } else if (_this.qaScoreType == 3) {
                  itm.firstQaScore =
                    item.firstQaScore == null ? '' : parseInt(item.firstQaScore)
                  itm.secondQaScore =
                    item.secondQaScore == null ? '' : parseInt(item.secondQaScore)
                  itm.threeScore =
                    item.threeScore == null ? '' : parseInt(item.threeScore)
                  if (itm.judge === 5 || itm.judge === 11) {
                    itm.deadItem = itm.resultsObject[0].deadItem
                  } else if (itm.judge === 12) {
                    itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                  } else if (
                    itm.judge === 7 &&
                    item.optioniItem3 !== null &&
                    item.optioniItem3 !== 0
                  ) {
                    itm.firstQaScore = item.optioniItem1
                    itm.secondQaScore = item.optioniItem2
                    itm.threeScore = item.optioniItem3
                  } else if (itm.judge === 8 && itm.threeScore == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '0'
                  } else {
                    itm.deadItem = '2'
                  }
                  if (itm.deadItem === '1') {
                    if (itm.threeScore === 1) {
                      _this.isAutoDead = '1'
                    }
                  }
                } else if (_this.qaScoreType == 4) {
                  itm.firstQaScore =
                    item.firstQaScore == null ? '' : parseInt(item.firstQaScore)
                  itm.secondQaScore =
                    item.secondQaScore == null ? '' : parseInt(item.secondQaScore)
                  itm.threeScore =
                    item.threeScore == null ? '' : parseInt(item.threeScore)
                  itm.fourScore = item.fourScore == null ? '' : parseInt(item.fourScore)
                  if (itm.judge === 5 || itm.judge === 11) {
                    itm.deadItem = itm.resultsObject[0].deadItem
                  } else if (itm.judge === 12) {
                    itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                  } else if (
                    itm.judge === 7 &&
                    item.optioniItem4 !== null &&
                    item.optioniItem4 !== 0
                  ) {
                    itm.firstQaScore = item.optioniItem1
                    itm.secondQaScore = item.optioniItem2
                    itm.threeScore = item.optioniItem3
                    itm.fourScore = item.optioniItem4
                  } else if (itm.judge === 8 && itm.fourScore == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '0'
                  } else {
                    itm.deadItem = '2'
                  }
                  if (itm.deadItem === '1') {
                    if (itm.fourScore === 1) {
                      _this.isAutoDead = '1'
                    }
                  }
                }
              }
            }
          })
        }
      })
    },
    // 判断数组元素是否都可以转为数字
    checkArrayType(arr) {
      return arr.every(function(val, index, arr) {
        let temp = +val
        return typeof temp === 'number' && !Number.isNaN(temp)
      })
    },
    // 命中场景 点击按钮
    playOccurrence(keywordItem) {
      this.$emit('clickhighlightkeys', keywordItem)
    },
    changeTargetTime(key) {
      let _this = this
      for (let j in _this.scoreDetails) {
        if (key.normalId == _this.scoreDetails[j].normalId) {
          key.targetTime = _this.scoreDetails[j].targetTime
        }
      }
    },
    // 关键词展示
    showKeywordsData() {
      let _this = this
      let array = []
      let newobj = {}
      if (_this.playInfoVosList.length <= 0) {
        return false
      }
      for (let k in _this.standardsListWithAutoScoreQa) {
        let newarray = []
        _this.standardsListWithAutoScoreQa[k].forEach(function(normal) {
          let key = normal
          _this.changeTargetTime(key)
          // let reg = /[A-Z()\s]+/
          if (
            key.judge == 5 ||
            (key.judge == 3 && key.resultsObject && key.resultsObject[0].silenceType == 5)
          ) {
            if (key.targetTime) {
              let targetTime = ''
              targetTime = key.targetTime
              let target = targetTime.split(',')
              let targetTimeStart = target[0]
              let targetTimeEnd = target[1]
              key.targetTimeStart = targetTimeStart
              key.targetTimeEnd = targetTimeEnd
              for (let n = 0; n < _this.playInfoVosList.length; n++) {
                if (
                  parseInt(_this.playInfoVosList[n].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[n].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.Start = n
                  key.targetTimeStart = _this.playInfoVosList[n].startTime
                  break
                }
              }
              for (let m = _this.playInfoVosList.length - 1; m >= 0; m--) {
                if (
                  parseInt(_this.playInfoVosList[m].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[m].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.End = m
                  key.targetTimeEnd = _this.playInfoVosList[m].endTime
                  break
                }
              }
            } else {
              key.Start = 0
              key.End = _this.playInfoVosList.length - 1
              key.targetTimeStart = '0'
              key.targetTimeEnd = _this.playInfoVosList[key.End].endTime
            }
            for (let i = 0; i < key.resultsObject.length; i++) {
              let keywordContext = key.resultsObject[i].keywordContext
              keywordContext = keywordContext
                .trim()
                .replace(/\(/g, ' ( ')
                .replace(/\)/g, ' ) ')
              keywordContext = keywordContext.split(' ')
              let keywordContext1 = []
              let o = 0
              for (let l = 0; l < keywordContext.length; l++) {
                if (keywordContext[l] != '') {
                  // 特殊处理，如果是OR AND BEFORE NOT NEAR AFTER 则不进行匹配操作
                  if (
                    keywordContext[l] == '(' ||
                    keywordContext[l] == ')' ||
                    keywordContext[l] == 'OR' ||
                    keywordContext[l] == 'AND' ||
                    keywordContext[l] == 'BEFORE' ||
                    keywordContext[l] == 'AFTER' ||
                    keywordContext[l] == 'NEAR' ||
                    keywordContext[l] == 'NOT'
                  ) {
                    keywordContext1[o] = {
                      keyword: keywordContext[l],
                      ishighlight: false,
                    }
                  } else {
                    let isFind = false

                    // 相似词
                    const keywordContextForHighlight =
                      key.resultsObject[i].keywordContextForHighlight
                    let similarMap = null
                    try {
                      if (keywordContextForHighlight) {
                        similarMap = JSON.parse(keywordContextForHighlight)
                      } else {
                        similarMap = {}
                      }
                    } catch (e) {
                      similarMap = {}
                    }
                    const matchKeywordsRegExp = new RegExp(
                      (similarMap[keywordContext[l]] || [])
                        .concat(keywordContext[l])
                        .join('|')
                    )

                    for (let j = key.Start; j <= key.End; j++) {
                      if (!isFind) {
                        if (key.resultsObject[i].roleType == 1) {
                          if (
                            _this.playInfoVosList[j].role == '1' &&
                            matchKeywordsRegExp.test(_this.playInfoVosList[j].text)
                          ) {
                            isFind = true
                            keywordContext1[o] = {
                              keyword: keywordContext[l],
                              similarWord: similarMap[keywordContext[l]],
                              ishighlight: true,
                              targetTimeStart: _this.playInfoVosList[j].startTime,
                              targetTimeEnd: _this.playInfoVosList[j].endTime,
                              position: key.resultsObject[i].position,
                              offset: key.resultsObject[i].offset,
                              sceneTime: key.resultsObject[i].sceneTime,
                            }
                            break
                          }
                        } else if (key.resultsObject[i].roleType == 2) {
                          if (
                            _this.playInfoVosList[j].role == '2' &&
                            matchKeywordsRegExp.test(_this.playInfoVosList[j].text)
                          ) {
                            isFind = true
                            keywordContext1[o] = {
                              keyword: keywordContext[l],
                              similarWord: similarMap[keywordContext[l]],
                              ishighlight: true,
                              targetTimeStart: _this.playInfoVosList[j].startTime,
                              targetTimeEnd: _this.playInfoVosList[j].endTime,
                              position: key.resultsObject[i].position,
                              offset: key.resultsObject[i].offset,
                              sceneTime: key.resultsObject[i].sceneTime,
                            }
                            break
                          }
                        } else {
                          if (matchKeywordsRegExp.test(_this.playInfoVosList[j].text)) {
                            isFind = true
                            keywordContext1[o] = {
                              keyword: keywordContext[l],
                              similarWord: similarMap[keywordContext[l]],
                              ishighlight: true,
                              targetTimeStart: _this.playInfoVosList[j].startTime,
                              targetTimeEnd: _this.playInfoVosList[j].endTime,
                              position: key.resultsObject[i].position,
                              offset: key.resultsObject[i].offset,
                              sceneTime: key.resultsObject[i].sceneTime,
                            }
                            break
                          }
                        }
                      }
                    }
                    if (!isFind) {
                      keywordContext1[o] = {
                        keyword: keywordContext[l],
                        ishighlight: false,
                      }
                    }
                  }
                  o++
                }
              }
              key.resultsObject[i].keyword = []
              keywordContext1.forEach((item) => {
                key.resultsObject[i].keyword.push({
                  keyword: item.keyword,
                  similarWord: item.similarWord,
                  clickIndex: 0,
                  ishighlight: item.ishighlight,
                  fullScriptRole: key.resultsObject[i].roleType,
                  targetTimeStart: key.targetTimeStart,
                  targetTimeEnd: key.targetTimeEnd,
                  position: key.resultsObject[i].position,
                  offset: key.resultsObject[i].offset,
                  sceneTime: key.resultsObject[i].sceneTime,
                })
              })
            }
          }
          array.push(key)
          newarray.push(key)
        })
        newobj[k] = newarray
      }
      _this.standardsListWithAutoScoreQa = newobj
      _this.keywords = array
    },
    // 获取录音信息
    getPlayInfo() {
      // 将播放器重置为录音播放器
      let url = qualityUrl + '/speechFeature/getPlayInfo.do'
      let params = {}
      params.callId = this.callId
      return this.axios
        .post(url, qs.stringify(params))
        .then((response) => {
          if (response.data) {
            this.$store.commit('setRecordingPlayUrl', {
              recordFileURL: response.data.esResultModel.recordFileURL || '',
            })

            this.serviceLabels = response.data.serviceLabels
            this.customInfoModel = response.data.customerLabels
            this.playInfoVosList = response.data.playInfoVosList
            this.judgePlayInfoList(this.playInfoVosList)
            this.insertSort(this.playInfoVosList)
            this.times = []
            this.playInfoVosList.forEach((item) => {
              this.times.push(item.startTime)
              this.times.push(item.endTime)
            })

            this.$store.commit('setVoiceDetal', this.playInfoVosList)
            this.voiceTotalTime = response.data.voiceTotalTime
            this.esResultModel = response.data.esResultModel
            this.aclOperVo = response.data.aclOperVo
            this.minSpeed = response.data.minSpeead
            this.maxSpeed = response.data.maxSpeed
            let playInfo = {}
            playInfo.voiceTotalTime = this.voiceTotalTime

            this.$nextTick(() => {
              this.$store.commit('setPlayerInfo', playInfo)
              this.hightlightContent(this.keywordsHigh) // 获取高亮文本
            })
          }
        })
        .catch((err) => {
          console.log(err)
          this.$message({
            type: 'error',
            message: '录音信息获取失败',
          })
        })
    },
    // 录音修改文本 设置toolTip
    playShowToolTip(e, item) {
      var target = e.currentTarget
      if (target) {
        if (
          item.text &&
          item.text.replace(/<[^>]+>/g, '').trim() == item.originalText &&
          item.originalText.trim()
        ) {
          if (item.needCorrect && item.correctText) {
            if (item.text.replace(/<[^>]+>/g, '').trim() !== item.correctText.trim()) {
              this.isShowPlayInfoTooltip = false
            } else {
              this.isShowPlayInfoTooltip = true
            }
          } else {
            this.isShowPlayInfoTooltip = true
          }
        } else {
          this.isShowPlayInfoTooltip = false
        }
      } else {
        this.isShowPlayInfoTooltip = true
      }
    },
    // 提交修改文本
    submitPlayInfoList(val) {
      // isEditPlayInfoList===true 修改文本
      // isEditPlayInfoList===false 保存
      if (val == '1') {
        // 点击文本修改
        this.isEditPlayInfoList = !this.isEditPlayInfoList
      } else {
        let newVoiceList = this.playInfoVosList.filter((item) => {
          return item.role != 'UNK'
        })
        for (var i = 0; i < newVoiceList.length; i++) {
          let item = newVoiceList[i]
          item.text = item.changeText
        }
        // 点击保存
        let jsonStr = JSON.stringify(newVoiceList)
        let params = {
          callId: this.callId,
          json: jsonStr,
        }
        this.axios
          .post(qualityUrl + '/speechFeature/updateContent.do', qs.stringify(params))
          .then((res) => {
            if (res.data) {
              this.isEditPlayInfoList = true
              this.getPlayInfo()
            } else {
              this.$message.error('提交失败')
            }
          })
          .catch((err) => console.log(err))
      }
    },
    // 判断文本是否修改
    judgePlayInfoList(data) {
      let _this = this
      for (var i = 0; i < data.length; i++) {
        let item = data[i]
        if (item.role == 'UNK' || !item.originalText) {
          return
        }
        _this.$set(item, 'changeText', item.text)
        if (item.text.trim() == item.originalText.trim()) {
          if (item.needCorrect && item.correctText) {
            if (item.text.trim() !== item.correctText.trim()) {
              _this.$set(item, 'changeText', item.correctText)
              item.text =
                '<p style="text-decoration:underline">' + item.correctText + '</p>'
            }
          }
        } else {
          item.text = '<p style="text-decoration:underline">' + item.text + '</p>'
        }
      }
    },
    filterContentData() {
      // 过滤上下文质检关键字
      const conTextList = []
        .concat(...Object.values(this.standardsListWithAutoScoreQa))
        .filter((item) => item.judge == 12)
        .map((item) => {
          return (
            item.resultsObject[0].firstContext + ' ' + item.resultsObject[0].secondContext
          )
        })
      let keyWordContent = conTextList.length == 0 ? [] : conTextList.join(' ').split(' ')
      // 过滤内容质检话术关键词
      const contextObject = [].concat(
        ...this.scoreDetails.map((flag) => {
          return flag.matchDialogs ? flag.matchDialogs : []
        })
      )
      keyWordContent = [...contextObject, ...keyWordContent]
      console.log(keyWordContent)
      this.setPlayInfoList(this.playInfoVosList, keyWordContent)
    },
    setPlayInfoList(data, keyWordContent) {
      for (let i = 0; i < data.length; i++) {
        let item = data[i]
        if (keyWordContent && keyWordContent.length > 0) {
          for (let y = 0; y < keyWordContent.length; y++) {
            item.text = item.text.replace(
              keyWordContent[y].replace(/[(|)]/g, ''),
              `<font style=color:#409eff;>${keyWordContent[y].replace(
                /[(|)]/g,
                ''
              )}</font>`
            )
          }
        }
      }
    },
    isShowSpeedFlag(speed) {
      if (speed == '') {
        return false
      } else {
        if (speed > this.maxSpeed || speed < this.minSpeed) {
          return true
        } else {
          return false
        }
      }
    },
    // 对话列表的class
    classes(role, startTime, endTime) {
      let active = ''
      if (+this.currentClass === +startTime || +this.currentClass === +endTime) {
        active = 'currentClass'
      }
      if (role == 2) {
        return 'custom_content _' + startTime + ' _' + endTime + ' ' + active
      } else if (role == 1) {
        return 'agent_content _' + startTime + ' _' + endTime + ' ' + active
      } else {
        return 'UNK _' + startTime
      }
    },
    // 调整滚动条位置， scrollTop = offsetTop + 偏移
    scrollDialog(seconds) {
      let liClass = '._' + seconds
      let ele = document.querySelector(liClass)
      if (ele) {
        let offsetTop = ele.offsetTop
        if (offsetTop < 20) {
          // dialog有10pxpadding
          document.querySelector('.dialog').scrollTop = 0
        } else {
          // document.querySelector('.dialog').scrollTop = offsetTop + 20
          $('.dialog').animate(
            {
              scrollTop: offsetTop - document.querySelector('.dialog').clientHeight / 3,
            },
            500
          )
        }
      }
    },
    // 查找距离当前时间最近的对话内容所在的区域的class， 二分查找
    findCurrentMessage(seconds) {
      if (this.times.indexOf(seconds) != -1) {
        return seconds
      } else if (seconds < this.times[0]) {
        return this.times[0]
      } else if (seconds > this.times[this.times.length - 1]) {
        return this.times[this.times.length - 1]
      } else {
        let low = 0
        let high = this.times.length - 1
        let closeData = ''
        let diff = 0
        while (low <= high) {
          let mid = parseInt((high + low) / 2)
          if (seconds > this.times[mid]) {
            low = mid + 1
            if (diff == 0) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            } else if (Math.abs(this.times[mid] - seconds) < Math.abs(diff)) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            }
          } else if (seconds < this.times[mid]) {
            high = mid - 1
            if (diff == 0) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            } else if (Math.abs(this.times[mid] - seconds) < Math.abs(diff)) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            }
          } else {
            return this.times[mid]
          }
        }
        return closeData
      }
    },
    // 插入排序
    insertSort(arr) {
      if (Object.prototype.toString.call(arr) !== '[object Array]') {
        return false
      }
      for (let i = 0; i < arr.length; i++) {
        let j = i
        let temp = arr[i]
        while (j > 0 && parseInt(temp.startTime) < parseInt(arr[j - 1].startTime)) {
          arr[j] = arr[--j]
        }
        arr[j] = temp
      }
    },
    playOccurrence_intelligent(keywordItem, deadItem) {
      // 单独高亮显示本次关键词的结果
      this.hightlightContentIntell(keywordItem, deadItem)
    },
    // 获取分类树
    getTreeData() {
      let _this = this
      let url = qualityUrl + '/caseManage/getEffectiveTreeData.do'
      let params = {
        objectId: this.callId,
        objectType: ' ',
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.dataTree = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '分类获取失败',
          })
        })
    },
    // 获取案例标签
    getCaseTag() {
      let _this = this
      let url = qualityUrl + '/caseManage/showClassName.do'
      let params = {
        objectId: this.callId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.caseTag = response.data.data.length == 0 ? [] : response.data.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '分类标签获取失败',
          })
        })
    },
    // 添加案例
    addCase_btn() {
      this.getTreeData()
      this.showAddCaseDialog = true
      this.resetForm('AddCaseModel')
    },
    // 关闭添加案例弹出层
    handleCloseAddCaseDialog() {
      this.showAddCaseDialog = false
    },
    // 判断是否重复添加案例
    hasSameCaseThrottle() {
      this.lodashThrottle.throttle(this.hasSameCase, this)
    },
    // 添加案例
    addCase() {
      let _this = this
      this.$refs.AddCaseModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let url = qualityUrl + '/qaDetail/colCase.do'
          let params = {
            objectId: _this.callId,
            apReason: _this.AddCaseModel.addCaseReason,
            casClassId: _this.AddCaseModel.dataType,
          }
          if (_this.AddCaseModel.addCaseReason.length > 255) {
            _this.$message({
              type: 'error',
              message: '请填写小于255字符的理由',
            })
            return
          }
          this.axios
            .post(url, qs.stringify(params))
            .then(function(response) {
              if (response.data.status == 'success') {
                _this.$message({
                  type: 'success',
                  message: response.data.data,
                })
                _this.showAddCaseDialog = false
                _this.getCaseTag() // 获取录音案例标签
              } else {
                _this.$message({
                  type: 'error',
                  message: response.data.data,
                })
                return Promise.reject()
              }
            })
            .catch(function() {})
        }
      })
    },
    // 添加案例 添加按钮
    hasSameCase() {
      let _this = this
      let url = qualityUrl + '/qaDetail/colCase.do'
      let params = {
        objectId: this.callId,
        apReason: this.AddCaseModel.addCaseReason,
        casClassId: this.AddCaseModel.dataType,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.status !== 'success') {
            _this.addCase()
          } else {
            _this.$message({
              type: 'success',
              message: response.data.data,
            })
            _this.showAddCaseDialog = false
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '检查是否重复添加失败',
          })
        })
    },
    // 获取权限按钮
    getFuncId: function() {
      this.axios
        .post(global.hrmApi + '/accountApi/accessible/getFuncIdByAccountId.do')
        .then((res) => {
          for (let i = 0; i < res.data.length; i++) {
            if (res.data[i] == 'alca11') {
              this.isShowedit = true
            }
            if (res.data[i] == 'alca00') {
              this.isShowplus = true
            }
            if (res.data[i] == 'alca22') {
              this.isShowclose = true
            }
            // 删除
            if (res.data[i] == 'alca33') {
              this.isShowdelete = true
            }
            // 编辑
            if (res.data[i] == 'alca44') {
              this.isShoweditCase = true
            }
            // 查看
            if (res.data[i] == 'alca55') {
              this.isShowLook = true
            }
            // 批量删除
            if (res.data[i] == 'alca66') {
              this.isShowdelby = true
            }
            // 通过
            if (res.data[i] == 'alca77') {
              this.isShowadopt = true
            }
            // 拒绝
            if (res.data[i] == 'alca88') {
              this.isShowrefuse = true
            }
          }
        })
    },
    // 点击分类树时选择分类
    selectClass(val) {
      this.classifyObject.classifyId = val.collectShareClassId
      this.classifyObject.name = val.name
    },
    // 重置表单
    resetForm(name) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[name].resetFields()
      })
    },
    // 智能筛选命中词点击
    highlightWordIntell(val, oldval) {
      let selector = ''
      if (parseInt(val.fullScriptRole) === 1) {
        selector = 'div.dialog ul li.agent_content .dialog-content .aims'
      } else if (parseInt(val.fullScriptRole) === 2) {
        selector = 'div.dialog ul li.custom_content .dialog-content .aims'
      } else if (parseInt(val.fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content .aims'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content .aims'
      }
      let _this = this
      // let elesnew = document.querySelectorAll(selector)
      let NodeList = []
      /*let {position, offset, sceneTime} = val
                if (+position && (offset || sceneTime)) {
                    if (!sceneTime) {
                        if (position != 0) {
                            elesnew = position == 2 ? elesnew[-(val.offset - 1)] : elesnew[val.offset - 1]
                            NodeList.push(elesnew)
                        }
                    } else if (sceneTime) {
                        // elesnew=position == 1 ? elesnew[-(val.sceneTime-1)] : elesnew[val.sceneTime - 1]
                        NodeList = document.querySelectorAll(selector)
                    }
                } else {
                    NodeList = document.querySelectorAll(selector)
                }*/
      NodeList = document.querySelectorAll(selector)
      let eles = NodeList
      if (!eles || eles.length === 0) {
        return
      } else {
        // 第一次点击的时候先把全部的关键词都替换掉
        let htmlValue = ''
        if (_this.isFirst) {
          eles.forEach(function(item) {
            for (let i of _this.keywordCollection) {
              const similarWord = Array.isArray(i.similarWord) ? i.similarWord : []
              if (
                item.innerHTML.search(
                  new RegExp(similarWord.concat(i.keyword).join('|'))
                ) !== -1
              ) {
                // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, i.keyword)
                if (_this.historyDeadItem == 1) {
                  htmlValue = item.innerHTML
                    .replace(/<span style="color: red">/g, '')
                    .replace(/<\/span>/g, '')
                } else {
                  htmlValue = item.innerHTML
                    .replace(/<span style="color: #20a0ff">/g, '')
                    .replace(/<\/span>/g, '')
                }
              }
            }
          })
          _this.isFirst = false
        } else {
          // 如果不是第一次点击关键词的时候把上次的关键词红色去除
          if (oldval) {
            // 当要高亮显示的文字变化时，先清空原来所有的高亮
            eles.forEach(function(item) {
              // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, oldval.keyword)
              if (_this.historyDeadItem == 1) {
                htmlValue = item.innerHTML
                  .replace(/<span style="color: red">/g, '')
                  .replace(/<\/span>/g, '')
              } else {
                htmlValue = item.innerHTML
                  .replace(/<span style="color: #20a0ff">/g, '')
                  .replace(/<\/span>/g, '')
              }
            })
          }
        }
        let findCount = 0
        document
          .querySelectorAll('div.dialog ul li .dialog-content .aims')
          .forEach(function(item2) {
            /*if(item2.innerHTML.search(val.keyword) != "-1") {

                            }*/
            if (_this.historyDeadItem == 1) {
              item2.innerHTML = item2.innerHTML
                .replace(/<span style="color: #20a0ff">/g, '')
                .replace(/<span style="color: red">/g, '')
                .replace(/<\/span>/g, '')
            } else {
              item2.innerHTML = item2.innerHTML
                .replace(/<span style="color: red">/g, '')
                .replace(/<span style="color: #20a0ff">/g, '')
                .replace(/<\/span>/g, '')
            }
          })
        eles.forEach(function(item) {
          let className = item.className.split(' ')
          let startTime = parseInt(className[1].substr(1).trim())
          let endTime = parseInt(className[2].substr(1).trim())
          /*if (!(startTime <= val.targetTimeEnd && endTime >= val.targetTimeStart)) {
            return
          }*/
          const similarWord = Array.isArray(val.similarWord) ? val.similarWord : []
          if (
            item.innerHTML.search(
              new RegExp(similarWord.concat(val.keyword).join('|'))
            ) !== -1
          ) {
            findCount++
            if (findCount == val.clickIndex) {
              if (_this.historyDeadItem == 1) {
                htmlValue = item.innerHTML.replace(
                  new RegExp(similarWord.concat(val.keyword).join('|'), 'gm'),
                  '<span style="color: red">$&</span>'
                )
              } else {
                htmlValue = item.innerHTML.replace(
                  new RegExp(similarWord.concat(val.keyword).join('|'), 'gm'),
                  '<span style="color: #20a0ff">$&</span>'
                )
              }
            }
            if (val.clickIndex == 0) {
              if (_this.historyDeadItem == 1) {
                htmlValue = item.innerHTML.replace(
                  new RegExp(similarWord.concat(val.keyword).join('|'), 'gm'),
                  '<span style="color: red">$&</span>'
                )
              } else {
                htmlValue = item.innerHTML.replace(
                  new RegExp(similarWord.concat(val.keyword).join('|'), 'gm'),
                  '<span style="color: #20a0ff">$&</span>'
                )
              }
              item.innerHTML = htmlValue
            }
            _this.playInfoVosList.forEach(function(itm) {
              let arr = item.className.split(' ')
              if (itm.startTime == arr[1] && itm.endTime == arr[2]) {
                itm.text = htmlValue
                _this.playClip(arr[1], arr[2])
              }
            })
          }
        })
      }
    },
  },
  watch: {
    currentTime(val) {
      this.currentClass = this.findCurrentMessage(val - 250)
      this.scrollDialog(this.currentClass)
    },
    focusWord(val, oldval) {
      this.highlightWord(val, oldval, '0')
    },
    focusWordIntell: {
      handler: function(val, oldval) {
        this.highlightWordIntell(val, oldval)
      },
      deep: true, // 对象内部的属性监听，也叫深度监听
    },
    playInfoVosList() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.fromUrl == 'task_result' && this.keywords && this.keywords.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keywords.forEach(function(item, index) {
            if (item.keywordContext.indexOf('NOT') == -1) {
              let temp = item.keywordContext.replace(
                /([\\(\\)])*(AND)*(OR)*(BEFORE)*(AFTER)*(NEAR)*(NOT)*/g,
                ''
              )
              temp.split(' ').forEach(function(i) {
                if (i) {
                  // self.highlightWord(i, '', item.fullScriptRole)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      } else if (this.fromUrl == 'sysAutoScoringInCallResult') {
        this.showKeywordsData()
      }
    },
    keywords() {
      // 如果是系统自动评分
      if (
        this.fromUrl == 'sysAutoScoringInCallResult' &&
        this.keywords &&
        this.keywords.length > 0
      ) {
        let self = this
        this.$nextTick(function() {
          self.keywords.forEach(function(item, index) {
            if (item.judge == 5 && item.resultObject) {
              item.resultObject.forEach((itm, index) => {
                if (itm.keywordContext.indexOf('NOT') == -1) {
                  itm.keyword.forEach(function(i) {
                    if (i && i.ishighlight) {
                      self.keywordCollection.add(i)
                    }
                  })
                }
              })
            }
          })
        })
      }
    },
  },
  filters: {
    dealSpeed(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return '过慢'
      } else if (val > maxSpeed) {
        return '过快'
      }
    },
    dealSpeedType(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return 'danger'
      } else if (val > maxSpeed) {
        return 'primary'
      }
    },
    timeFormat(val) {
      if (val === '' || !val) {
        return ''
      }
      return moment(val).format('YYYY-MM-DD HH:mm:ss')
    },
    timeFormatMD(val) {
      if (val === '' || !val) {
        return ''
      }
      let date = moment(val)
        .format('YYYY-MM-DD HH:mm:ss')
        .substring(5, 10)
      let m = date.substring(0, 2)
      if (m.substring(0, 1) == 0) {
        m = m.substring(1, 2)
      } else {
        m = m.substring(0, 2)
      }
      let d = date.substring(3, 5)
      if (d.substring(0, 1) == 0) {
        d = d.substring(1, 2)
      } else {
        d = d.substring(0, 2)
      }
      return m + '-' + d
    },
  },
}
</script>
<style lang="less">
@borderColor: #c3ccd9;
@playerHeight: 50px;
@infoHeight: 220px;
@controlBtnsHeight: 40px;
.tooltipWidth {
  max-width: 250px;
}

.recordingPlayContainer {
  width: 100%;
  height: 100%;
  position: absolute;

  .pb50 {
    padding-bottom: 50px;
  }

  .callInTrailBar {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 50px;
    line-height: 50px;
    background-color: #fff;
    border: 1px solid #c3ccd9;
    padding: 0 20px;
    overflow-y: auto;
  }

  .callInTrailBar_emotionBlock {
  }

  .hightlightContent_span {
    cursor: pointer;
    color: red;
  }

  .notHightlightContent_span {
    color: #20a0ff;
    cursor: pointer;
  }

  & > .controller_btns {
    position: absolute;
    width: 100px;
    line-height: 40px;
    top: 0px;
    right: 0px;
    z-index: 999;
    text-align: right;
    padding-right: 10px;

    .controller_btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      line-height: 24px;
      border-radius: 50%;
      margin-left: 5px;
      text-align: center;
      background: #c3ccd9;
      color: #fff;

      &:hover {
        cursor: pointer;
      }
    }
  }

  & > .el-row {
    height: 100%;
    border-top: 1px solid @borderColor;

    & > .el-col {
      height: 100%;
      position: relative;
    }
  }

  // 修改tab组件样式
  .el-tabs__item.is-active {
    color: #1f2d3d !important;
    font-size: 14px;
    font-weight: bold;
  }

  .el-tabs--border-card {
    border: none;
    height: 100%;
    position: relative;

    & > div {
      border: none;
    }

    & > .el-tabs__header {
    }

    & > .el-tabs__content {
      position: absolute;
      top: 40px;
      left: 0;
      right: 0;
      bottom: 0;
      overflow-y: auto;

      & > .el-tab-pane {
        height: 100%;
      }
    }

    & > .el-tabs__header .el-tabs__item {
      border: none;
    }
  }

  // 修改tab组件样式结束
  .leftContainer,
  .rightContainer {
    position: absolute;
    right: 0;
    left: 0;
    top: 0;
    bottom: 0;
  }

  .leftContainer {
    .info-base {
      position: relative;
      height: 100%;
      overflow-y: hidden;

      .infoContent {
        height: auto;
        float: left;
        width: 100%;
        border-bottom: 1px solid #e4e4e4;
        padding: 20px 0;
        box-sizing: border-box;

        &.infoContent-kehuInfo {
          border: none;

          .tagWrap {
            position: absolute;
            left: 10px;
            bottom: 10px;
            right: 120px;

            .el-tag {
              margin-right: 10px;
              margin-bottom: 10px;
            }
          }

          .btnWrap {
            position: absolute;
            right: 10px;
            bottom: 10px;
          }
        }

        .borderLeft {
          width: 100%;
          height: 30px;
          line-height: 30px;
          overflow: hidden;
          color: #8691a5;

          .borderBlue {
            margin-left: 10px;
            display: inline-block;
            color: #1791ec;
            text-align: center;
            line-height: 8px;
            border-radius: 2px;
            border: 1px solid #9ed9f3;
            padding: 4px 10px;
            color: #1791ec;
            height: 10px;
            background: #d7eeff;
            font-size: 12px;
          }

          .borderGreen {
            margin-left: 10px;
            display: inline-block;
            color: #1791ec;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #6bdec4;
            padding: 4px 10px;
            color: #12a080;
            height: 12px;
            background: #caf7ed;
            font-size: 12px;
          }
        }

        .borderRight {
          width: 50%;
          color: #8691a5;
          display: inline-block;
          height: 30px;
          line-height: 30px;

          .borderPositive {
            display: inline-block;
            font-size: 12px;
            color: #12a080;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #12a037;
            padding: 4px 10px;
            height: 12px;
            padding: 4px 10px;
            color: #12a037;
          }

          .borderNegative {
            display: inline-block;
            font-size: 12px;
            margin-right: 10px;
            color: #12a080;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #ff0000;
            padding: 4px 10px;
            height: 12px;
            padding: 4px 10px;
            color: #ff0000;
          }
        }

        .info_item {
          min-width: 50%;
          float: left;
          line-height: 30px;
          color: #8691a5;
          font-size: 14px;

          .el-rate {
            display: inline-block;
            margin-left: 5px;
            vertical-align: middle;
          }

          span.el-tag {
            margin-right: 2px;
          }

          &.agentLabel {
            width: 100%;

            .el-tag {
              margin-left: 5px;
            }
          }
        }
      }
    }

    .info {
      height: @infoHeight;
      position: relative;

      .submit-playinfo-list {
        position: absolute;
        right: 10px;
        bottom: 3px;
        height: 30px;
        padding: 7px 10px;
      }

      .infoContent {
        height: 100%;

        .info_item {
          min-width: 50%;
          float: left;
          line-height: 30px;
          color: #8691a5;
          font-size: 14px;

          .el-rate {
            display: inline-block;
            margin-left: 5px;
            vertical-align: middle;
          }

          span.el-tag {
            margin-right: 2px;
          }

          &.agentLabel {
            width: 100%;

            .el-tag {
              margin-left: 5px;
            }
          }
        }
      }
    }

    .dialog {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      top: @infoHeight;
      overflow-y: auto;
      padding: 10px;
      background: #eef1f6;

      & > ul {
        position: relative;

        & > li {
          overflow: hidden;
          margin: 10px 0px;

          .avatar {
            width: 46px;
            height: 46px;
            line-height: 46px;
            border-radius: 23px;
            border: 1px solid @borderColor;
            text-align: center;
            background: #fff;
          }

          .dialog-content {
            background: #fff;
            padding: 10px 15px;
            line-height: 20px;
            border-radius: 5px;
            margin-left: 15px;
            position: relative;
            max-width: 280px;
            margin-top: 5px;
            cursor: pointer;
          }

          .content-tag {
            margin-top: 15px;
          }

          &.custom_content {
            div {
              float: left;
            }

            .dialog-content {
              background: #fff;

              &::before {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #fff;
                position: absolute;
                top: 10px;
                left: -6px;
                transform: rotate(45deg);
              }
            }
          }

          &.agent_content {
            div {
              float: right;
            }

            .dialog-content {
              margin-left: 10px;
              margin-right: 15px;
              background: #9eea6a;
              color: #000000;

              &::after {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #9eea6a;
                position: absolute;
                top: 10px;
                right: -6px;
                transform: rotate(45deg);
              }
            }
          }

          // 当前正在播放的对话内容样式
          &.currentClass {
            .dialog-content {
              background: #22b8fe;
              color: #000000;

              &::after {
                background: #22b8fe;
              }

              &::before {
                background: #22b8fe;
              }
            }
          }

          &.UNK {
            div {
              text-align: center;
              display: block;
              color: #97a8be;
            }

            div.line {
              width: 100%;
              height: 15px;
              background: url('../../../assets/img/unk.png') no-repeat;
              background-position: center;
            }
          }
        }
      }
    }

    #lrc_list {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      top: @infoHeight;
      overflow-y: auto;
      padding: 10px;
      background: #eef1f6;

      & > ul {
        position: relative;

        & > li {
          overflow: hidden;
          margin: 10px 0px;

          .avatar {
            width: 46px;
            height: 46px;
            line-height: 46px;
            border-radius: 23px;
            border: 1px solid @borderColor;
            text-align: center;
            background: #fff;
          }

          .dialog-content {
            background: #fff;
            padding: 10px 15px;
            line-height: 20px;
            border-radius: 5px;
            margin-left: 15px;
            position: relative;
            max-width: 280px;
            margin-top: 5px;
          }

          .content-tag {
            margin-top: 15px;
          }

          &.custom_content {
            div {
              float: left;
            }

            .dialog-content {
              background: #fff;

              &::before {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #fff;
                position: absolute;
                top: 10px;
                left: -6px;
                transform: rotate(45deg);
              }
            }
          }

          &.agent_content {
            div {
              float: right;
            }

            .dialog-content {
              margin-left: 10px;
              margin-right: 15px;
              background: #9eea6a;
              color: #000000;

              &::after {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #9eea6a;
                position: absolute;
                top: 10px;
                right: -6px;
                transform: rotate(45deg);
              }
            }
          }

          &.UNK {
            div {
              text-align: center;
              display: block;
              color: #97a8be;
            }

            div.line {
              width: 100%;
              height: 15px;
              background: url('../../../assets/img/unk.png') no-repeat;
              background-position: center;
            }
          }
        }
      }
    }
  }

  .rightContainer {
    .lable {
      height: 42px;
      line-height: 42px;
      width: 100%;
      padding-left: 20px;
      box-sizing: border-box;
      font-size: 14px;
      color: #1f2d3d;
      font-weight: bold;
    }

    .process_s {
      height: 36px;
      line-height: 36px;
      background: #eff2f7;
      padding: 0 20px;
      box-sizing: border-box;

      .process-wrap {
        display: inline-block;
        margin-right: 22px;
        position: relative;

        .process {
          color: #1f2d3d;
          font-size: 12px;
        }
      }
    }

    .infoForm {
      height: 100%;

      .detailInfoContents_part {
        border-bottom: 1px dashed @borderColor;

        .detailInfoContentsInputs {
          padding: 10px;

          .el-form-item > label {
            font-size: 14px;
            color: #8691a5;
          }
        }

        h3 {
          padding-left: 10px;
          line-height: 30px;
          font-size: 14px;
          color: #9dadc2;
          font-weight: normal;
        }
      }
    }

    .operation {
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      padding: 0px 10px 0px 0px;
      border-bottom: 1px dashed @borderColor;
      position: absolute;
      top: 0px;
      left: 10px;
      right: 10px;

      h3 {
        width: 65px;
        float: left;
        font-size: 14px;
        color: #5e6d82;
        font-weight: normal;
      }
    }

    .btns {
      float: right;

      button {
        width: 90px;
      }

      margin-right: 10px;
    }

    .standards_parts.resultScore {
      position: absolute;
      top: 80px;
      right: 0px;
      left: 0px;
      bottom: 0px;
      overflow-y: auto;

      .standards_part {
        position: relative;

        h3 {
          line-height: 30px;
          font-size: 14px;
          color: #1f2d3d;
          font-weight: normal;
        }
        .label {
          height: 42px;
          line-height: 42px;
          width: 100%;
          -webkit-box-sizing: border-box;
          box-sizing: border-box;
          font-size: 14px;
          color: #1f2d3d;
          font-weight: bold;
        }
        .coll {
          padding: 0 10px;
        }

        .standards_detail {
          padding: 10px;
          padding-left: 0;

          .classification_part {
            h3 {
              padding-left: 10px;
              line-height: 30px;
              font-size: 14px;
              color: #9dadc2;
              font-weight: normal;
            }

            .classification_detail {
              padding: 10px 0;

              .el-form-item > label {
                font-size: 14px;
                color: #8691a5;
              }
            }
          }

          .normalNameClass {
            line-height: 30px;
            color: #9dadc2;
            font-size: 14px;
          }
        }

        &.noBorder {
          border-bottom: none;

          & > p {
            font-size: 14px;
            margin-bottom: 10px;
          }
        }

        .btns {
          margin: 10px;
        }

        .standards_part_title {
          position: relative;
          line-height: 30px;
          font-size: 14px;
          color: #1f2d3d;
          font-weight: normal;
          overflow: hidden;

          h2,
          h3 {
            display: inline-block;
          }

          .verticalMiddle {
            float: left;
            width: 85%;

            .h2 {
              font-weight: bold;
              font-size: 13px;
              color: #1f2d3d;
              line-height: 17px;
            }
          }

          .score {
            display: inline-block;
            float: right;

            label {
              display: inline-block;
              width: 35px;
              font-size: 13px;
              color: #1f2d3d;
            }

            span {
              display: inline-block;
              width: 35px;
              font-size: 13px;
              color: #1f2d3d;
              text-align: right;
              padding-right: 10px;
            }

            .score_result {
              color: #20a0ff;
            }
          }
        }
      }

      .selectInspector {
        width: 120px;
        line-height: 30px;
        position: absolute;
        right: 145px;
        top: 6px;
      }

      &.screening {
        top: 10px;
      }

      &.appealScore {
        h3 {
          color: #9dadc2;
        }

        label {
          color: #8691a5;
        }
      }
    }
  }

  .btns {
    text-align: right;

    button {
      width: 90px;
    }
  }

  .contentLeft,
  .contentRight {
    border: 1px solid @borderColor;
  }

  .el-dialog__body {
    padding-top: 10px;

    .footer {
      margin-top: 10px;
    }
  }

  .dialogTitle {
    color: #8691a5;
    font-size: 14px;
    font-weight: normal;
    box-sizing: border-box;
    height: 50px;
    line-height: 50px;
    padding: 0px 10px;
    border-bottom: 1px dotted @borderColor;

    .btns button {
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      padding: 0px;
    }
  }

  .hidden {
    display: none;
  }
}

.resultScore {
  margin: 10px 20px;

  .dialog-addcass {
    .el-dialog__header {
      display: block !important;
    }
  }

  .playClip_btn {
    cursor: pointer;
  }

  .dialogTitle {
    color: #8691a5;
    font-size: 14px;
    font-weight: normal;
    box-sizing: border-box;
    height: 50px;
    line-height: 50px;
    padding: 0px 10px;
    border-bottom: 1px dotted @borderColor;

    .btns button {
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      padding: 0px;
    }
  }

  .contentLeft,
  .contentRight {
    border: 1px solid @borderColor;
  }

  .el-input.w-123 {
    width: 123px;
  }
}
.rightContainer {
  .el-collapse-item__header {
    font-size: 12px;
    font-weight: normal;
    color: #1f2d3d;
  }
  .el-collapse-item__content {
    background-color: #f8f9fb;
    padding: 10px;
    color: #606266;
    font-size: 12px;
  }
}
</style>
