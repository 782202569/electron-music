录音播放详情页前端文档说明

### 流程

主管分配(质检任务-初检任务)-分配给相应质检员-质检员(我的质检任务进行评分)-坐席(我的质检成绩查看)
-发起一次申诉-主管(申诉管理)评分-坐席(发起二次申诉)-主管(申诉管理)评分-流程结束

公用重要相关参数
[qaScoreType]: 打分阶段 1初检 2 复检 3 复议，一次申诉 4二次申诉，二次复议
[isScored]：是否打分 true已打分 false未打分
[role]角色： 'seatman' 坐席  'headman'组长  'qa'质检员  'qa_suvs'质检主管
[judge]：打分方式
case 1:'情绪'
case 2:'重叠次数'
case 3:'静默'
case 4:'语速'
case 5:'关键词'
case 11:'标签'
case 6:'自定义输入'
case 7:'自定义选项'
case 8:'自定义致命项'
case 12:'上下文质检'
case 13:'内容质检'


分数实时计算
如果有一项deadItem为致命，整个模版评分为0
[flowScoreFun] 流程模版评分
[autoScoreFun] 系统自动模版评分或者人工模版评分
[totalScoreFun] flowScoreFun+autoScoreFun

对模版打的分数进行相应附值
[changData(){}]
根据normalId对每一行模版数据赋值[分数(firstQaScore,secondQaScore,threeScore,fourScore)、致命项deadItem、case===7 分数赋值optioniItem1，optioniItem2..]

关键词高亮相关
[showKeywordsData(){}] 关键词以及相似词高亮展示

文本修改
[judgePlayInfoList(){}] 如果文本有相应修改，下划线标出


人工和自动评分计算
[autoScoreFun(){}]
流程分数计算
[flowScoreFun(){}]
录音文本修改
[judgePlayInfoList(){}]
一进入页面判断文本是否有修改
[playShowToolTip(){}]
!originalText没有原始文本不做处理  text 现在要展示的文本 needCorrect 是否修改过 correctText修改的文本
---


### 仅展示分数在此页面
### recordingPlayResultScore.vue

相关参数
[qaScoreType]: 打分阶段 1初检 2 复检 3 复议，一次申诉 4二次申诉
[isScored]：是否打分 true已打分 false未打分
[fromUrl]页面来源:recordingpoll录音池，sysAutoScoringInCallResult系统自动评分 scoreResultInfo质检成绩查看
[resultScoreIndex]  1申诉中 2已确认 3未确认
[shensuTabIndex] 1已处理 2未处理
[appealStatus]申诉状态：
一次申诉中：  1 和2
一次申诉成绩已公布： 3
一次申诉成绩已驳回：7和5
二次申诉中：6
二次申诉成绩已公布：4
二次申诉成绩已驳回：8
已确认：10、11、13和14
[关键词高亮]：系统自动评分进入后，模板出内容的命中关键词高亮，点击后相继亮，录音池搜索时有关键词，进入播放页录音内容里含搜索关键词的全部高亮关键词，
点击高亮，相似词也会进行相应高亮跳转。

相关接口
相应页面获取相应模版

[scoreResultInfo]: /scoreResult/getAllScoreByRole.do "质检成绩查看"
[recordingpoll]: /recordingPool/getRecordScore.do "录音池"
[其他]: /scoreView/getConditonScore "其他"


---

### 主管申诉打分(一次申诉，二次申诉)
### recordingPlayShenSu.vue
相关参数
[qaScoreType]: 打分阶段 1初检 2 复检 3 复议，一次申诉 4二次申诉
[isScored]：是否打分 true已打分 false未打分
[role组长]：展示最终得分
[role主管]：展示细项以及轨迹，并且可以打分
[shensuTabIndex]:2未处理1已处理
[appealStatus] 申诉状态
一次申诉中：  1和2
一次申诉成绩已公布： 3
一次申诉成绩已驳回：7和5
二次申诉中：6
二次申诉成绩已公布：4
二次申诉成绩已驳回：8
已确认：10、11、13和14



---
### 质检校准会(标准校准评分，校准会打分)
### recordingPlayCailbratMeet.vue
相关参数
[qaScoreType]: 打分阶段 1初检 2 复检 3 复议，一次申诉 4二次申诉
[isScored]：是否打分 true已打分 false未打分

[role]质检校准会打分 质检主管，质检员 role 区分

[质检主管activeName] 质检主管：标准成绩和校准 用activeName 判断  first 标准  second 校准
[质检员activeName] 质检员：标准成绩和校准 用activeName 判断  first 校准  second 标准

标准和校准 公用模版，根据不同形态获取不同情况下的分数详情
isCreator (是否可以进行校准评分)创建者可以标准评分的标识 0 创建者

---
### 质检任务(初检,复检打分)
### recordingPlayMultiple.vue
相关参数
[qaScoreType]: 打分阶段 1初检 2 复检
[isScored]:是否打分 true已打分 false未打分
[fromUrl]:页面来源:我的质检任务（初检 复检 myQaTasks_reconsider 复议）  caseManage_new 案例管理
[checkNumber]:输入打分项是否符合规范(类型控制以及范围控制)
[checkRange]:输入打分项范围控制(judge===6时)

特别功能
playerMultiple.vue
[批量打分]：
[$store.state.notScoreList.scoreList] 批量选择的录音列表
触发打开下一通录音
bus.$emit('nextcall')
[isNext] 下一步按钮是否禁用状态



