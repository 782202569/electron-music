<!--
qaScoreType：1，初检，2复检，3一次申诉、一次复议，4二次申诉、二次复议
-->
<template>
  <div class="recordingPlayContainer">
    <div class="controller_btns">
      <div class="controller_btn" @click="minimizePage">
        <i class="el-icon-minus"></i>
      </div>
      <div class="controller_btn" @click="closePage"><i class="el-icon-close"></i></div>
    </div>
    <el-row>
      <el-col :span="spanFirst">
        <div class="leftContainer">
          <div class="info-base">
            <el-tabs type="border-card">
              <el-tab-pane label="基本信息">
                <div class="infoContent">
                  <div class="info_item">
                    <label>录音编号:</label>
                    <span>{{ esResultModel.callId }}</span>
                  </div>
                  <div class="info_item">
                    <label>开始时间:</label>
                    <span>{{ esResultModel.callSTime | timeFormat }}</span>
                  </div>
                  <div class="info_item">
                    <label>通话时长:</label>
                    <span>{{
                      isNaN(esResultModel.callTime / 1000)
                        ? ''
                        : esResultModel.callTime / 1000 + '秒'
                    }}</span>
                  </div>
                  <div class="borderRight">
                    <label>情绪标签:</label>
                    <span
                      v-if="
                        esResultModel.emotionLabel &&
                          esResultModel.emotionLabel.indexOf('积极') != -1
                      "
                      class="borderPositive"
                      >{{ esResultModel.emotionLabel }}</span
                    >
                    <span
                      v-if="
                        esResultModel.emotionLabel &&
                          esResultModel.emotionLabel.indexOf('消极') != -1
                      "
                      class="borderNegative"
                      >{{ esResultModel.emotionLabel }}</span
                    >
                  </div>
                  <div class="borderLeft">
                    <label>关键词标签:</label>
                    <span
                      v-if="esResultModel.labelContent"
                      class="borderBlue"
                      v-for="(list, indexOne) in esResultModel.labelContent.split(',')"
                      >{{ list }}</span
                    >
                  </div>
                </div>
                <div class="infoContent">
                  <div class="info_item">
                    <label>坐席工号:</label>
                    <span>{{ esResultModel.seatNo }}</span>
                  </div>
                  <div class="info_item">
                    <label>坐席姓名:</label>
                    <span>{{ esResultModel.seatName }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属角色:</label>
                    <span>{{
                      aclOperVo.roleNames != null ? aclOperVo.roleNames.join(',') : ''
                    }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属部门:</label>
                    <span>{{ aclOperVo.deptName }}</span>
                  </div>
                  <div class="info_item" style="width:100%;">
                    <label>坐席星级:</label>
                    <span>
                      <el-rate
                        v-model="esResultModel.seatStar"
                        disabled
                        text-color="#ff9900"
                      >
                      </el-rate
                    ></span>
                  </div>
                  <div class="info_item agentLabel">
                    <label>坐席标签:</label>
                    <el-tag
                      :type="color[index % 4]"
                      v-if="item.trim()"
                      v-for="(item, index) in serviceLabels"
                      :key="index"
                      >{{ item }}
                    </el-tag>
                    <el-tag v-if="!serviceLabels || serviceLabels.length == 0"
                      >暂无标签</el-tag
                    >
                  </div>
                </div>
                <div class="infoContent infoContent-kehuInfo">
                  <div class="info_item">
                    <label>客户姓名:</label>
                    <span>{{ esResultModel.customerName }}</span>
                  </div>
                  <div class="info_item">
                    <label>账号:</label>
                    <span>{{ esResultModel.customerNo }}</span>
                  </div>
                  <div class="info_item">
                    <label>证件信息:</label>
                    <span>{{ esResultModel.certType }}</span>
                  </div>
                  <div class="info_item">
                    <label>证件号:</label>
                    <span>{{ esResultModel.certNo }}</span>
                  </div>
                  <div class="info_item agentLabel">
                    <label>客户标签:</label>
                    <el-tag
                      :type="color[index % 4]"
                      v-for="(item, index) in customInfoModel"
                      :key="index"
                      class="customLabel"
                      >{{ item }}
                    </el-tag>
                    <el-tag v-if="!customInfoModel || customInfoModel.length === 0">
                      暂无标签
                    </el-tag>
                  </div>
                  <div class="tagWrap" v-if="caseTag.length > 0">
                    <el-tag v-for="(item, index) in caseTag" :key="index">{{
                      item
                    }}</el-tag>
                  </div>
                  <div class="btnWrap">
                    <el-button v-if="roleCodeId.includes('qa')" @click="addCase_btn">
                      添加案例
                    </el-button>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </el-col>
      <el-col :span="spanSecond">
        <div class="leftContainer">
          <div class="info">
            <el-tabs type="border-card">
              <el-tab-pane label="语音特征">
                <div class="infoContent">
                  <div class="info_item">
                    <label>静默次数:</label>
                    <span>{{ esResultModel.silenceCount }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默时长:</label>
                    <span>{{ esResultModel.silenceLong / 1000 || 0 }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默占比:</label>
                    <span
                      >{{ Math.round(esResultModel.silencePer * 1000) / 10 || 0 }}%</span
                    >
                  </div>
                  <div class="info_item">
                    <label>语音重叠次数:</label>
                    <span>{{ esResultModel.overLap }}</span>
                  </div>
                  <div class="info_item">
                    <label>情绪分值:</label>
                    <span>{{ esResultModel.moodScore }}</span>
                  </div>
                  <div class="info_item">
                    <label>平均语速:</label>
                    <span>{{
                      isNaN(Math.round(esResultModel.avgSpeed * 100) / 100)
                        ? ''
                        : Math.round(esResultModel.avgSpeed * 100) / 100 + '字/秒'
                    }}</span>
                  </div>
                  <div class="info_item">
                    <label>最快语速:</label>
                    <span>{{
                      isNaN(Math.round(esResultModel.maxSpeed * 100) / 100)
                        ? ''
                        : Math.round(esResultModel.maxSpeed * 100) / 100 + '字/秒'
                    }}</span>
                  </div>
                  <div class="info_item">
                    <label>最长静默:</label>
                    <span>{{
                      isNaN(Math.round(esResultModel.maxSilenceLong / 10) / 100)
                        ? ''
                        : Math.round(esResultModel.maxSilenceLong / 10) / 100
                    }}</span>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
            <el-button
              class="submit-playinfo-list"
              v-if="
                roleCodeId.includes('qa_suvs') &&
                  (esResultModel.labelContent == null ||
                    esResultModel.labelContent == '') &&
                  esResultModel.isSampled == '0'
              "
              ><span @click="submitPlayInfoList('1')" v-if="isEditPlayInfoList">
                文本修改 </span
              ><span @click="submitPlayInfoList('2')" v-else>保存</span></el-button
            >
          </div>
          <div class="dialog" @mousewheel="test">
            <ul>
              <li
                :class="classes(item.role, item.startTime, item.endTime)"
                v-for="(item, index) in playInfoVosList"
                :key="item.startTime"
              >
                <div v-if="item.role == '1'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/seat.png"
                  />
                </div>
                <div v-if="item.role == '2'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/customer.png"
                  />
                </div>
                <div class="dialog-content" v-if="item.role != 'UNK'">
                  <div style="display: inline-block" v-if="!isEditPlayInfoList">
                    <el-input
                      type="textarea"
                      v-model="playInfoVosList[index].changeText"
                    />
                  </div>
                  <div
                    style="display: inline-block"
                    v-else
                    @click="playClip(item.startTime)"
                  >
                    <el-tooltip
                      :disabled="isShowPlayInfoTooltip"
                      class="item"
                      effect="dark"
                      placement="top"
                      :content="item.originalText"
                    >
                      <button
                        style="background: none;border:0;"
                        @mouseenter="playShowToolTip($event, item)"
                      >
                        <span
                          class="aims"
                          :class="[item.startTime, item.endTime]"
                          style="cursor: pointer"
                          v-html="item.text"
                        ></span>
                      </button>
                    </el-tooltip>
                  </div>
                </div>
                <div
                  class="content-tag"
                  v-if="item.role == 1 && isShowSpeedFlag(item.speed)"
                >
                  <el-tag :type="item.speed | dealSpeedType(minSpeed, maxSpeed)">
                    {{ item.speed | dealSpeed(minSpeed, maxSpeed) }}
                  </el-tag>
                </div>
                <div v-if="item.role == 'UNK'" class="UNK_text">
                  <el-row>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                    <el-col :span="4">{{ item.text }}</el-col>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                  </el-row>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </el-col>
      <el-col :span="spanThird">
        <div class="rightContainer">
          <div class="lable">
            质检评分
          </div>
          <div class="process_s">
            <div v-if="scoringTrajectory.length > 0">
              <div
                class="process-wrap"
                v-for="(item, index) in scoringTrajectory"
                :key="index"
              >
                <span class="process">{{ item.stepName }}</span>
                <span class="process">{{ item.scoreDate | timeFormatMD }}</span>
              </div>
            </div>
            <p v-else>暂无评分轨迹</p>
          </div>
          <div class="standards_parts recordingPlayMultiple">
            <div class="standards_part">
              <div class="standards_part_title">
                <h2 class="h2">评分模板：{{ modleTitle }}</h2>
                <div class="score">
                  <span class="score_result">{{ totalScoreFun }}</span>
                </div>
              </div>
              <div class="standards_part_title">
                <h3>
                  评分标准
                </h3>
                <div class="score">
                  <span>{{ autoScoreFun }}</span>
                </div>
              </div>
              <div class="standards_detail">
                <div
                  v-for="(standardsList, key) in standardsListWithAutoScoreQa"
                  :key="key"
                >
                  <div class="normalNameClass">{{ key }}</div>
                  <el-table
                    ref="standardsListTable"
                    :data="standardsListWithAutoScoreQa[key]"
                    border
                    tooltip-effect="dark"
                  >
                    <el-table-column prop="normalName" label="质检标准">
                    </el-table-column>
                    <el-table-column
                      prop="judge"
                      :formatter="formatJudge"
                      label="打分方式"
                    >
                    </el-table-column>
                    <el-table-column label="内容" width="120">
                      <template scope="scope">
                        <div v-if="scope.row.judge === 5">
                          <div v-if="scope.row.resultsObject">
                            <div
                              v-for="(item, key) in scope.row.resultsObject"
                              :key="key"
                              :class="{
                                'suffix-semicolon':
                                  key < scope.row.resultsObject.length - 1,
                              }"
                            >
                              <span>{{ item.keywordContext }}</span>
                              <span>{{
                                getKeywordScoreFilter(item, scope.row.judge)
                              }}</span>
                            </div>
                            <el-popover placement="right" width="120" trigger="hover">
                              <template
                                v-if="scope.row.resultsObject[0].deadItem == '1'"
                                slot="reference"
                              >
                                <i class="el-icon-warning" style="color: red"></i>
                              </template>
                              <p>此标准为致命项标准，命中则总分为 0</p>
                            </el-popover>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 4">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 1">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}分<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 2">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <p>
                              {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                                class="defualtScore"
                                ><span v-if="srrt.increaseDeduction === '1'">加</span
                                ><span v-else>减</span
                                >{{ srrt.score.toString().replace('-', ' ') }}分</span
                              >
                            </p>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 11">
                          <div v-if="scope.row.resultsObject">
                            <p v-for="keyValue in scope.row.resultsObject">
                              {{ keyValue.labelName }}
                              <span v-if="keyValue.score !== 0"
                                >{{ +keyValue.increaseDeduction == '2' ? '减' : '加'
                                }}{{ keyValue.score }}分</span
                              >
                            </p>
                            <el-popover placement="right" width="120" trigger="hover">
                              <template
                                v-if="scope.row.resultsObject[0].deadItem == '1'"
                                slot="reference"
                              >
                                <i class="el-icon-warning" style="color: red"></i>
                              </template>
                              <p>此标准为致命项标准，命中则总分为 0</p>
                            </el-popover>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 3">
                          <div
                            v-for="(srrt, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <div v-if="srrt.silenceType === 1">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 2">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 3">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 4">
                              <p>
                                {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                                  class="defualtScore"
                                  ><span v-if="srrt.increaseDeduction === '1'">加</span
                                  ><span v-else>减</span
                                  >{{ srrt.score.toString().replace('-', ' ') }}分</span
                                >
                              </p>
                            </div>
                            <div v-else-if="srrt.silenceType === 5">
                              <span>{{ srrt.keywordContext }}</span>
                              {{ getKeywordScoreFilter(srrt, scope.row.judge) }}
                            </div>
                            <div v-else></div>
                          </div>
                        </div>
                        <div v-else-if="scope.row.judge === 12">
                          <div>
                            {{
                              scope.row.resultsObject[0].firstRoleType == 1
                                ? '坐席:'
                                : '客户:'
                            }}
                            <span
                              v-html="getHtml(scope.row.resultsObject[0].firstContext)"
                            ></span>
                          </div>
                          <div>
                            {{
                              scope.row.resultsObject[0].secondRoleType == 1
                                ? '坐席:'
                                : '客户:'
                            }}
                            <span
                              v-html="getHtml(scope.row.resultsObject[0].secondContext)"
                            ></span>
                          </div>
                          <div>
                            规则:
                            {{
                              `${scope.row.resultsObject[0].sentenceCount}句内，${
                                scope.row.resultsObject[0].isAppear == 1
                                  ? '出现'
                                  : '未出现'
                              } `
                            }}
                            <span
                              v-if="scope.row.resultsObject[0].sentenceDeadItem == '2'"
                              >{{
                                ` ${
                                  scope.row.resultsObject[0].increaseDeduction == 1
                                    ? '加'
                                    : '减'
                                }${scope.row.resultsObject[0].score}分`
                              }}</span
                            >
                          </div>
                          <el-popover placement="right" width="120" trigger="hover">
                            <template
                              v-if="scope.row.resultsObject[0].sentenceDeadItem == '1'"
                              slot="reference"
                            >
                              <i class="el-icon-warning" style="color: red"></i>
                            </template>
                            <p>此标准为致命项标准，命中则总分为 0</p>
                          </el-popover>
                        </div>
                        <div v-else-if="scope.row.judge === 13">
                          <div>
                            意图:
                            <span v-html="getContentHtml(scope.row.faqContent)"></span>
                          </div>
                          <div
                            v-for="(item, index) in scope.row.resultsObject"
                            :key="index"
                          >
                            <div>
                              话术:
                              <span v-html="getContentHtml(item.content)"></span>
                            </div>
                            <div>
                              规则:
                              {{
                                `${item.isAppear == 1 ? '出现' : '未出现'}${
                                  item.addsub == 1 ? '加' : '减'
                                }${item.score}分`
                              }}
                            </div>
                          </div>
                        </div>
                        <div v-else>
                          {{ scope.row.normalContent }}
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="qaScoreType === 1 || qaScoreType === 2"
                      prop="defaultScore"
                      :label="labelName"
                      width="120"
                    >
                      <template scope="scope">
                        <div v-if="qaScoreType === 1">
                          <div v-if="scored">
                            <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                              <span v-if="scope.row.resultsObject">
                                <span
                                  v-if="
                                    (scope.row.resultsObject[0].deadItem === '1') &
                                      (standardsListWithAutoScoreQa[key][scope.$index]
                                        .firstQaScore ==
                                        '2')
                                  "
                                >
                                  非致命
                                </span>
                                <span
                                  v-else-if="
                                    (scope.row.resultsObject[0].deadItem === '1') &
                                      (standardsListWithAutoScoreQa[key][scope.$index]
                                        .firstQaScore ==
                                        '1')
                                  "
                                  >致命</span
                                >
                                <span
                                  v-else-if="scope.row.resultsObject[0].deadItem !== '1'"
                                  >{{
                                    standardsListWithAutoScoreQa[key][scope.$index]
                                      .firstQaScore
                                  }}</span
                                >
                              </span>
                            </span>
                            <span v-else-if="scope.row.judge == 6">{{
                              standardsListWithAutoScoreQa[key][scope.$index].firstQaScore
                            }}</span>
                            <el-select
                              v-else-if="scope.row.judge == 7"
                              disabled="true"
                              v-model="
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .firstQaScore
                              "
                            >
                              <el-option
                                v-for="val in scope.row.resultsObject"
                                :key="val"
                                :label="val"
                                :value="val"
                              >
                              </el-option>
                            </el-select>
                            <span
                              v-else-if="
                                scope.row.judge == 8 &&
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore == '2'
                              "
                            >
                              非致命
                            </span>
                            <span
                              v-else-if="
                                scope.row.judge == 8 &&
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore == '1'
                              "
                            >
                              致命
                            </span>
                            <span
                              v-else-if="
                                scope.row.judge == 12 &&
                                  scope.row.resultsObject[0].sentenceDeadItem === '1'
                              "
                            >
                              <span v-if="scope.row.resultsObject">
                                <span
                                  v-if="
                                    standardsListWithAutoScoreQa[key][scope.$index]
                                      .firstQaScore == '2'
                                  "
                                >
                                  非致命
                                </span>
                                <span
                                  v-else-if="
                                    standardsListWithAutoScoreQa[key][scope.$index]
                                      .firstQaScore == '1'
                                  "
                                >
                                  致命
                                </span>
                              </span>
                            </span>
                            <span
                              v-else-if="
                                (scope.row.judge !== 5) & (scope.row.judge !== 11)
                              "
                              >{{
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .firstQaScore
                              }}</span
                            >
                          </div>
                          <div v-if="!scored">
                            <div v-if="scope.row.judge == 5 || scope.row.judge == 11">
                              <div v-if="scope.row.resultsObject">
                                <el-select
                                  v-if="scope.row.resultsObject[0].deadItem === '1'"
                                  @change="
                                    changeDead(
                                      scope.row.newIndex,
                                      scope.row.judge,
                                      'defaultScore'
                                    )
                                  "
                                  v-model="
                                    currentDistribute[scope.row.newIndex].defaultScore
                                  "
                                  placeholder="请选择"
                                  style="width: 95px;"
                                >
                                  <el-option
                                    v-for="item in deadOptions"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value"
                                  >
                                  </el-option>
                                </el-select>
                                <el-input
                                  v-else
                                  v-model="
                                    currentDistribute[scope.row.newIndex].defaultScore
                                  "
                                  @blur="
                                    !isClose &&
                                      checkNumber(
                                        scope.row.newIndex,
                                        scope.row,
                                        'defaultScore'
                                      )
                                  "
                                ></el-input>
                              </div>
                            </div>
                            <el-input
                              v-else-if="scope.row.judge == 6"
                              v-model="currentDistribute[scope.row.newIndex].defaultScore"
                              @blur="
                                checkRange(
                                  currentDistribute[scope.row.newIndex].defaultScore,
                                  currentDistribute[scope.row.newIndex].minScoreRange,
                                  currentDistribute[scope.row.newIndex].maxScoreRange
                                )
                              "
                            ></el-input>

                            <el-select
                              v-else-if="scope.row.judge == 7"
                              v-model="currentDistribute[scope.row.newIndex].defaultScore"
                            >
                              <el-option
                                v-for="val in scope.row.resultsObject"
                                :key="val"
                                :label="val"
                                :value="val"
                              >
                              </el-option>
                            </el-select>

                            <el-select
                              v-else-if="
                                scope.row.judge == 8 ||
                                  (scope.row.judge == 12 &&
                                    scope.row.resultsObject[0].sentenceDeadItem === '1')
                              "
                              @change="
                                changeDead(
                                  scope.row.newIndex,
                                  scope.row.judge,
                                  'defaultScore'
                                )
                              "
                              v-model="currentDistribute[scope.row.newIndex].defaultScore"
                              placeholder="请选择"
                              style="width: 95px;"
                            >
                              <el-option key="1" label="致命" value="1"></el-option>
                              <el-option key="2" label="非致命" value="2"></el-option>
                            </el-select>
                            <el-input
                              v-else
                              v-model="currentDistribute[scope.row.newIndex].defaultScore"
                              @blur="
                                !isClose &&
                                  checkNumber(
                                    scope.row.newIndex,
                                    scope.row,
                                    'defaultScore'
                                  )
                              "
                            ></el-input>
                          </div>
                        </div>
                        <div v-else-if="qaScoreType === 2">
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .firstQaScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .firstQaScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else>{{
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .firstQaScore
                              }}</span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            :disabled="true"
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].firstQaScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .firstQaScore == '2'
                            "
                          >
                            非致命
                          </span>
                          <span
                            v-else-if="
                              scope.row.judge == 8 &&
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .firstQaScore == '1'
                            "
                          >
                            致命
                          </span>
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .firstQaScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span v-else>{{
                            standardsListWithAutoScoreQa[key][scope.$index].firstQaScore
                          }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="qaScoreType === 2"
                      label="复检得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <div v-if="scored">
                            <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                              <span v-if="scope.row.resultsObject">
                                <span
                                  v-if="
                                    scope.row.resultsObject[0].deadItem === '1' &&
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .secondQaScore == '2'
                                  "
                                >
                                  非致命
                                </span>
                                <span
                                  v-else-if="
                                    scope.row.resultsObject[0].deadItem === '1' &&
                                      standardsListWithAutoScoreQa[key][scope.$index]
                                        .secondQaScore == '1'
                                  "
                                >
                                  致命
                                </span>
                                <span v-else>{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore
                                }}</span>
                              </span>
                            </span>
                            <el-select
                              v-else-if="scope.row.judge == 7"
                              disabled="true"
                              v-model="
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore
                              "
                            >
                              <el-option
                                v-for="val in scope.row.resultsObject"
                                :key="val"
                                :label="val"
                                :value="val"
                              >
                              </el-option>
                            </el-select>
                            <span
                              v-else-if="
                                (scope.row.judge == 8 ||
                                  (scope.row.judge == 12 &&
                                    scope.row.resultsObject[0].sentenceDeadItem ===
                                      '1')) &&
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '2'
                              "
                            >
                              非致命
                            </span>
                            <span
                              v-else-if="
                                (scope.row.judge == 8 ||
                                  (scope.row.judge == 12 &&
                                    scope.row.resultsObject[0].sentenceDeadItem ===
                                      '1')) &&
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '1'
                              "
                            >
                              致命
                            </span>
                            <span
                              v-else-if="scope.row.judge !== 5 && scope.row.judge !== 11"
                              >{{
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore
                              }}</span
                            >
                          </div>
                          <div v-if="!scored">
                            <div v-if="scope.row.judge == 5 || scope.row.judge == 11">
                              <div v-if="scope.row.resultsObject">
                                <el-select
                                  v-if="scope.row.resultsObject[0].deadItem === '1'"
                                  @change="
                                    changeDead(
                                      scope.row.newIndex,
                                      scope.row.judge,
                                      'secondQaScore'
                                    )
                                  "
                                  v-model="
                                    currentDistribute[scope.row.newIndex].secondQaScore
                                  "
                                  placeholder="请选择"
                                  style="width: 95px;"
                                >
                                  <el-option
                                    v-for="item in deadOptions"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value"
                                  >
                                  </el-option>
                                </el-select>
                                <el-input
                                  v-else
                                  v-model="
                                    currentDistribute[scope.row.newIndex].secondQaScore
                                  "
                                  @blur="
                                    !isClose &&
                                      checkNumber(
                                        scope.row.newIndex,
                                        scope.row,
                                        'secondQaScore'
                                      )
                                  "
                                ></el-input>
                              </div>
                            </div>
                            <el-input
                              v-else-if="scope.row.judge == 6"
                              v-model="
                                currentDistribute[scope.row.newIndex].secondQaScore
                              "
                              @blur="
                                checkRange(
                                  currentDistribute[scope.row.newIndex].secondQaScore,
                                  currentDistribute[scope.row.newIndex].minScoreRange,
                                  currentDistribute[scope.row.newIndex].maxScoreRange
                                )
                              "
                            ></el-input>

                            <el-select
                              v-else-if="scope.row.judge == 7"
                              v-model="
                                currentDistribute[scope.row.newIndex].secondQaScore
                              "
                            >
                              <el-option
                                v-for="val in scope.row.resultsObject"
                                :key="val"
                                :label="val"
                                :value="val"
                              >
                              </el-option>
                            </el-select>

                            <el-select
                              v-else-if="
                                scope.row.judge == 8 ||
                                  (scope.row.judge == 12 &&
                                    scope.row.resultsObject[0].sentenceDeadItem === '1')
                              "
                              @change="
                                changeDead(
                                  scope.row.newIndex,
                                  scope.row.judge,
                                  'secondQaScore'
                                )
                              "
                              v-model="
                                currentDistribute[scope.row.newIndex].secondQaScore
                              "
                              placeholder="请选择"
                              style="width: 95px;"
                            >
                              <el-option key="1" label="致命" value="1"></el-option>
                              <el-option key="2" label="非致命" value="2"></el-option>
                            </el-select>
                            <el-input
                              v-else
                              v-model="
                                currentDistribute[scope.row.newIndex].secondQaScore
                              "
                              @blur="
                                !isClose &&
                                  checkNumber(
                                    scope.row.newIndex,
                                    scope.row,
                                    'secondQaScore'
                                  )
                              "
                            ></el-input>
                          </div>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="
                        qaScoreType === 3 &&
                          (roleCodeId.includes('qa_suvs') === false || obj.isCreator != 1)
                      "
                      prop="defaultScore"
                      label="得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else>{{
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore
                              }}</span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            :disabled="true"
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index]
                                .secondQaScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <el-select
                            v-else-if="scope.row.judge == 8"
                            :disabled="true"
                            v-model="currentDistribute[scope.row.newIndex].secondQaScore"
                            placeholder="请选择"
                            style="width: 95px;"
                          >
                            <el-option key="1" label="致命" value="1"></el-option>
                            <el-option key="2" label="非致命" value="2"></el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span
                            v-else-if="scope.row.judge !== 5 && scope.row.judge !== 11"
                            >{{
                              standardsListWithAutoScoreQa[key][scope.$index]
                                .secondQaScore
                            }}</span
                          >
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="
                        fromUrl == 'myQaTasks_reconsider' &&
                          qaScoreType === 3 &&
                          roleCodeId.includes('qa_suvs')
                      "
                      prop="defaultScore"
                      label="得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  scope.row.resultsObject[0].deadItem === '1' &&
                                    standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  scope.row.resultsObject[0].deadItem === '1' &&
                                    standardsListWithAutoScoreQa[key][scope.$index]
                                      .secondQaScore == '1'
                                "
                              >
                                致命
                              </span>
                              <span v-else>{{
                                standardsListWithAutoScoreQa[key][scope.$index]
                                  .secondQaScore
                              }}</span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            :disabled="true"
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index]
                                .secondQaScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <el-select
                            v-else-if="scope.row.judge == 8"
                            :disabled="true"
                            v-model="currentDistribute[scope.row.newIndex].secondQaScore"
                            placeholder="请选择"
                            style="width: 95px;"
                          >
                            <el-option key="1" label="致命" value="1"></el-option>
                            <el-option key="2" label="非致命" value="2"></el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .secondQaScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span
                            v-else-if="scope.row.judge !== 5 && scope.row.judge !== 11"
                            >{{
                              standardsListWithAutoScoreQa[key][scope.$index]
                                .secondQaScore
                            }}</span
                          >
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="
                        qaScoreType === 4 &&
                          (roleCodeId.includes('qa_suvs') === false || obj.isCreator != 1)
                      "
                      prop="defaultScore"
                      label="得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div>
                          <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .threeScore ==
                                      '2')
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  (scope.row.resultsObject[0].deadItem === '1') &
                                    (standardsListWithAutoScoreQa[key][scope.$index]
                                      .threeScore ==
                                      '1')
                                "
                              >
                                致命
                              </span>
                              <span v-else>{{
                                standardsListWithAutoScoreQa[key][scope.$index].threeScore
                              }}</span>
                            </span>
                          </span>
                          <el-select
                            v-else-if="scope.row.judge == 7"
                            :disabled="true"
                            v-model="
                              standardsListWithAutoScoreQa[key][scope.$index].threeScore
                            "
                          >
                            <el-option
                              v-for="val in scope.row.resultsObject"
                              :key="val"
                              :label="val"
                              :value="val"
                            >
                            </el-option>
                          </el-select>
                          <el-select
                            v-else-if="scope.row.judge == 8"
                            :disabled="true"
                            v-model="currentDistribute[scope.row.newIndex].threeScore"
                            placeholder="请选择"
                            style="width: 95px;"
                          >
                            <el-option key="1" label="致命" value="1"></el-option>
                            <el-option key="2" label="非致命" value="2"></el-option>
                          </el-select>
                          <span
                            v-else-if="
                              scope.row.judge == 12 &&
                                scope.row.resultsObject[0].sentenceDeadItem === '1'
                            "
                          >
                            <span v-if="scope.row.resultsObject">
                              <span
                                v-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '2'
                                "
                              >
                                非致命
                              </span>
                              <span
                                v-else-if="
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '1'
                                "
                              >
                                致命
                              </span>
                            </span>
                          </span>
                          <span
                            v-else-if="scope.row.judge !== 5 && scope.row.judge !== 11"
                            >{{
                              standardsListWithAutoScoreQa[key][scope.$index].threeScore
                            }}</span
                          >
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column
                      v-if="
                        fromUrl != 'myQaTasks_reconsider' &&
                          qaScoreType === 3 &&
                          roleCodeId.includes('qa_suvs') &&
                          obj.isCreator != 0
                      "
                      prop="defaultScore"
                      label="复议得分"
                      width="120"
                    >
                      <template scope="scope">
                        <div v-if="qaScoreType === 3">
                          <div v-if="scored">
                            <span v-if="scope.row.judge == 5 || scope.row.judge == 11">
                              <span v-if="scope.row.resultsObject">
                                <span
                                  v-if="
                                    (scope.row.resultsObject[0].deadItem === '1') &
                                      (standardsListWithAutoScoreQa[key][scope.$index]
                                        .threeScore ==
                                        '2')
                                  "
                                >
                                  非致命
                                </span>
                                <span
                                  v-else-if="
                                    (scope.row.resultsObject[0].deadItem === '1') &
                                      (standardsListWithAutoScoreQa[key][scope.$index]
                                        .threeScore ==
                                        '1')
                                  "
                                >
                                  致命
                                </span>
                                <span v-else>{{
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore
                                }}</span>
                              </span>
                            </span>
                            <el-select
                              v-else-if="scope.row.judge == 7"
                              :disabled="true"
                              v-model="
                                standardsListWithAutoScoreQa[key][scope.$index].threeScore
                              "
                            >
                              <el-option
                                v-for="val in scope.row.resultsObject"
                                :key="val"
                                :label="val"
                                :value="val"
                              >
                              </el-option>
                            </el-select>
                            <span
                              v-else-if="
                                scope.row.judge == 8 &&
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '2'
                              "
                            >
                              非致命
                            </span>
                            <span
                              v-else-if="
                                scope.row.judge == 8 &&
                                  standardsListWithAutoScoreQa[key][scope.$index]
                                    .threeScore == '1'
                              "
                            >
                              致命
                            </span>
                            <span
                              v-else-if="
                                scope.row.judge == 12 &&
                                  scope.row.resultsObject[0].sentenceDeadItem === '1'
                              "
                            >
                              <span v-if="scope.row.resultsObject">
                                <span
                                  v-if="
                                    standardsListWithAutoScoreQa[key][scope.$index]
                                      .threeScore == '2'
                                  "
                                >
                                  非致命
                                </span>
                                <span
                                  v-else-if="
                                    standardsListWithAutoScoreQa[key][scope.$index]
                                      .threeScore == '1'
                                  "
                                >
                                  致命
                                </span>
                              </span>
                            </span>
                            <span
                              v-else-if="
                                (scope.row.judge !== 5) & (scope.row.judge !== 11)
                              "
                              >{{
                                standardsListWithAutoScoreQa[key][scope.$index].threeScore
                              }}</span
                            >
                          </div>
                          <div v-if="!scored">
                            <div v-if="scope.row.judge == 5 || scope.row.judge == 11">
                              <div v-if="scope.row.resultsObject">
                                <el-select
                                  v-if="scope.row.resultsObject[0].deadItem === '1'"
                                  @change="
                                    changeDead(
                                      scope.row.newIndex,
                                      scope.row.judge,
                                      'threeScore'
                                    )
                                  "
                                  v-model="
                                    currentDistribute[scope.row.newIndex].threeScore
                                  "
                                  placeholder="请选择"
                                  style="width: 95px;"
                                >
                                  <el-option
                                    v-for="item in deadOptions"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value"
                                  >
                                  </el-option>
                                </el-select>
                                <el-input
                                  v-else
                                  v-model="
                                    currentDistribute[scope.row.newIndex].threeScore
                                  "
                                  @blur="
                                    !isClose &&
                                      checkNumber(
                                        scope.row.newIndex,
                                        scope.row,
                                        'threeScore'
                                      )
                                  "
                                ></el-input>
                              </div>
                            </div>
                            <el-input
                              v-else-if="scope.row.judge == 6"
                              v-model="currentDistribute[scope.row.newIndex].threeScore"
                              @blur="
                                checkRange(
                                  currentDistribute[scope.row.newIndex].threeScore,
                                  currentDistribute[scope.row.newIndex].minScoreRange,
                                  currentDistribute[scope.row.newIndex].maxScoreRange
                                )
                              "
                            ></el-input>

                            <el-select
                              v-else-if="scope.row.judge == 7"
                              v-model="currentDistribute[scope.row.newIndex].threeScore"
                            >
                              <el-option
                                v-for="val in scope.row.resultsObject"
                                :key="val"
                                :label="val"
                                :value="val"
                              >
                              </el-option>
                            </el-select>

                            <el-select
                              v-else-if="
                                scope.row.judge == 8 ||
                                  (scope.row.judge == 12 &&
                                    scope.row.resultsObject[0].sentenceDeadItem === '1')
                              "
                              @change="
                                changeDead(
                                  scope.row.newIndex,
                                  scope.row.judge,
                                  'threeScore'
                                )
                              "
                              v-model="currentDistribute[scope.row.newIndex].threeScore"
                              placeholder="请选择"
                              style="width: 95px;"
                            >
                              <el-option key="1" label="致命" value="1"></el-option>
                              <el-option key="2" label="非致命" value="2"></el-option>
                            </el-select>
                            <el-input
                              v-else
                              v-model="currentDistribute[scope.row.newIndex].threeScore"
                              @blur="
                                !isClose &&
                                  checkNumber(scope.row.newIndex, scope.row, 'threeScore')
                              "
                            ></el-input>
                          </div>
                        </div>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
              </div>
            </div>
            <div class="standards_part">
              <div class="standards_part_title">
                <h3>
                  流程评分
                </h3>
                <div class="score">
                  <span>{{ flowScoreFun }}</span>
                </div>
              </div>
              <div v-if="qaScoreType === 1 || qaScoreType === 2">
                <el-select
                  style="width:200px"
                  multiple
                  v-model="flowValue"
                  @change="changeFlowOption"
                  :disabled="scored"
                  placeholder="请选择流程"
                >
                  <el-option
                    v-for="item in flowoptions"
                    :key="item.processId"
                    :label="item.processName"
                    :value="item.processId"
                  >
                  </el-option>
                </el-select>
              </div>
              <div class="standards_detail">
                <div
                  class="classification_part"
                  v-for="(key, index) in flowListWithScoreQa"
                  :key="index"
                >
                  <h3>
                    {{ key.processName }}
                  </h3>
                  <div class="classification_detail">
                    <el-table
                      ref="standardsListTable"
                      :data="key.processDetail"
                      border
                      max-height="500"
                      tooltip-effect="dark"
                    >
                      <el-table-column prop="intentName" label="意图"> </el-table-column>
                      <el-table-column prop="intentRule" label="规则"> </el-table-column>
                      <el-table-column
                        v-if="qaScoreType === 1 || qaScoreType === 2"
                        prop="firstScore"
                        :label="labelName"
                      >
                        <template scope="scope">
                          <div v-if="qaScoreType === 1">
                            <el-input
                              v-if="
                                !scored &&
                                  (flowListScoreObjs[scope.row.newIndex].scoreMin != 0 ||
                                    flowListScoreObjs[scope.row.newIndex].scoreMax != 0)
                              "
                              v-model="flowListScoreObjs[scope.row.newIndex].firstScore"
                              @blur="checkFlowNumber(scope.row.newIndex, scope.row)"
                            ></el-input>
                            <span
                              v-if="
                                !scored &&
                                  flowListScoreObjs[scope.row.newIndex].scoreMin == 0 &&
                                  flowListScoreObjs[scope.row.newIndex].scoreMax == 0
                              "
                              >--</span
                            >
                            <span v-if="scored">{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                          <div v-if="qaScoreType === 2">
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column v-if="qaScoreType === 2" label="复检得分">
                        <template scope="scope">
                          <div v-if="!scored">
                            <el-input
                              v-if="
                                flowListScoreObjs[scope.row.newIndex].scoreMin != 0 ||
                                  flowListScoreObjs[scope.row.newIndex].scoreMax != 0
                              "
                              v-model="flowListScoreObjs[scope.row.newIndex].secondScore"
                              @blur="checkFlowNumber(scope.row.newIndex, scope.row)"
                            ></el-input>
                            <span
                              v-if="
                                flowListScoreObjs[scope.row.newIndex].scoreMin == 0 &&
                                  flowListScoreObjs[scope.row.newIndex].scoreMax == 0
                              "
                              >--</span
                            >
                          </div>
                          <div v-if="scored">
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty(
                                'secondScore'
                              )
                                ? key.processDetail[scope.$index].secondScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="
                          qaScoreType === 3 &&
                            (roleCodeId.includes('qa_suvs') === false ||
                              obj.isCreator != 1)
                        "
                        label="得分"
                      >
                        <template scope="scope" v-if="qaScoreType === 3">
                          <!--复议页面进来始终是复检得分-->
                          <div v-if="fromUrl == 'myQaTasks_reconsider'">
                            <span
                              v-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                                  ? key.processDetail[scope.$index].secondScore
                                  : '--'
                              }}</span
                            >
                            <span
                              v-else-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'firstScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'firstScore'
                                )
                                  ? key.processDetail[scope.$index].firstScore
                                  : '--'
                              }}</span
                            >
                            <span v-else>{{
                              key.processDetail[scope.$index].hasOwnProperty('thirdScore')
                                ? key.processDetail[scope.$index].thirdScore
                                : '--'
                            }}</span>
                          </div>
                          <!--流程复议页面没有复检得分特殊处理-->
                          <div v-else>
                            <span
                              v-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                                  ? key.processDetail[scope.$index].secondScore
                                  : '--'
                              }}</span
                            >
                            <span v-else>{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="
                          fromUrl == 'myQaTasks_reconsider' &&
                            qaScoreType === 3 &&
                            roleCodeId.includes('qa_suvs')
                        "
                        label="得分"
                      >
                        <template scope="scope">
                          <!--复议页面进来始终是复检得分-->
                          <div v-if="fromUrl == 'myQaTasks_reconsider'">
                            <span
                              v-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                                  ? key.processDetail[scope.$index].secondScore
                                  : '--'
                              }}</span
                            >
                            <span
                              v-else-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'firstScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'firstScore'
                                )
                                  ? key.processDetail[scope.$index].firstScore
                                  : '--'
                              }}</span
                            >
                            <span v-else>{{
                              key.processDetail[scope.$index].hasOwnProperty('thirdScore')
                                ? key.processDetail[scope.$index].thirdScore
                                : '--'
                            }}</span>
                          </div>
                          <!--流程复议页面没有复检得分特殊处理-->
                          <div v-else>
                            <span
                              v-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                                  ? key.processDetail[scope.$index].secondScore
                                  : '--'
                              }}</span
                            >
                            <span v-else>{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="
                          qaScoreType === 4 &&
                            (roleCodeId.includes('qa_suvs') === false ||
                              obj.isCreator != 1)
                        "
                        label="得分"
                      >
                        <template scope="scope" v-if="qaScoreType === 4">
                          <div v-if="fromUrl == 'myQaTasks_reconsider'">
                            <span
                              v-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'thirdScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'thirdScore'
                                )
                                  ? key.processDetail[scope.$index].thirdScore
                                  : '--'
                              }}</span
                            >
                            <span
                              v-else-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                                  ? key.processDetail[scope.$index].secondScore
                                  : '--'
                              }}</span
                            >
                            <span v-else>{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                          <div v-else>
                            <span>{{
                              key.processDetail[scope.$index].hasOwnProperty('thirdScore')
                                ? key.processDetail[scope.$index].thirdScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column
                        v-if="
                          fromUrl != 'myQaTasks_reconsider' &&
                            qaScoreType === 3 &&
                            roleCodeId.includes('qa_suvs') &&
                            obj.isCreator != 0
                        "
                        label="复议得分"
                        width="120"
                      >
                        <template scope="scope">
                          <div v-if="!scored">
                            <el-input
                              v-if="
                                flowListScoreObjs[scope.row.newIndex].scoreMin != 0 ||
                                  flowListScoreObjs[scope.row.newIndex].scoreMax != 0
                              "
                              v-model="flowListScoreObjs[scope.row.newIndex].thirdScore"
                              @blur="checkFlowNumber(scope.row.newIndex, scope.row)"
                            ></el-input>
                            <span
                              v-if="
                                flowListScoreObjs[scope.row.newIndex].scoreMin == 0 &&
                                  flowListScoreObjs[scope.row.newIndex].scoreMax == 0
                              "
                              >--</span
                            >
                          </div>
                          <div v-else>
                            <span
                              v-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'thirdScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'thirdScore'
                                )
                                  ? key.processDetail[scope.$index].thirdScore
                                  : '--'
                              }}</span
                            >
                            <span
                              v-else-if="
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                              "
                              >{{
                                key.processDetail[scope.$index].hasOwnProperty(
                                  'secondScore'
                                )
                                  ? key.processDetail[scope.$index].secondScore
                                  : '--'
                              }}</span
                            >
                            <span v-else>{{
                              key.processDetail[scope.$index].hasOwnProperty('firstScore')
                                ? key.processDetail[scope.$index].firstScore
                                : '--'
                            }}</span>
                          </div>
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </div>
              </div>
            </div>
            <div class="standards_part" v-if="scored">
              <div class="label">评分说明</div>
              <el-collapse class="coll" v-model="activeName" accordion>
                <template v-if="isShowFirst">
                  <el-collapse-item title="初检评分说明" name="1">
                    <div>{{ noteList[0] || '--' }}</div>
                  </el-collapse-item>
                </template>
                <template v-if="isShowSecond">
                  <el-collapse-item title="复检评分说明" name="2">
                    <div>{{ noteList[1] || '--' }}</div>
                  </el-collapse-item>
                </template>
                <template v-if="isShowThird">
                  <el-collapse-item title="一次申诉评分说明" name="3">
                    <div>{{ noteList[2] || '--' }}</div>
                  </el-collapse-item>
                </template>
                <template v-if="isShowFour">
                  <el-collapse-item title="二次申诉评分说明" name="4">
                    <div>{{ noteList[3] || '--' }}</div>
                  </el-collapse-item>
                </template>
              </el-collapse>
            </div>
            <div class="standards_part">
              <div class="standards_detail">
                <div class="classification_part">
                  <div class="classification_detail">
                    <el-form
                      ref="reTaskReasonModel"
                      :model="reTaskReasonModel"
                      label-width="80px"
                      v-if="!scored"
                    >
                      <el-form-item label="评分说明:" prop="note">
                        <el-input
                          type="textarea"
                          placeholder="请输入内容(长度不超过300)"
                          v-model="reTaskReasonModel.note"
                        ></el-input>
                      </el-form-item>
                    </el-form>
                    <el-form
                      ref="reTaskModel"
                      :model="reTaskModel"
                      v-if="
                        (qaScoreType === 3 || qaScoreType === 4) &&
                          (roleCodeId.includes('qa_suvs') === false || obj.isCreator != 1)
                      "
                    >
                      <el-row>
                        <el-col :span="12">
                          <el-form-item>
                            <el-radio-group
                              v-model="reTaskModel.responseResult"
                              :disabled="scored"
                              fill="#97a8be"
                            >
                              <el-radio :label="1">评分有误</el-radio>
                              <el-radio :label="2">评分无误</el-radio>
                            </el-radio-group>
                          </el-form-item>
                        </el-col>
                        <el-col :span="12" v-if="reTaskModel.responseResult == 1">
                          <el-form-item label="复议成绩">
                            <el-input
                              class="w-123"
                              type="number"
                              v-model="reTaskModel.responseScore"
                              placeholder="请输入内容"
                              :disabled="scored"
                            ></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="24">
                          <el-form-item label="评分说明" label-width="69px">
                            <el-input
                              v-model="reTaskModel.responseContent"
                              placeholder="请输入内容"
                              :disabled="scored"
                            ></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </el-form>
                    <!-- 主管双角色（主管，质检员），从我的质检任务-》复议任务进入，主管当做质检员来进行复议打分-->
                    <el-form
                      ref="reTaskModel"
                      :model="reTaskModel"
                      v-if="
                        (qaScoreType === 3 || qaScoreType === 4) &&
                          (fromUrl == 'myQaTasks_reconsider' &&
                            roleCodeId.includes('qa_suvs') &&
                            obj.isCreator != 0)
                      "
                    >
                      <el-row>
                        <el-col :span="12">
                          <el-form-item>
                            <el-radio-group
                              v-model="reTaskModel.responseResult"
                              :disabled="scored"
                              fill="#97a8be"
                            >
                              <el-radio :label="1">评分有误</el-radio>
                              <el-radio :label="2">评分无误</el-radio>
                            </el-radio-group>
                          </el-form-item>
                        </el-col>
                        <el-col :span="12" v-if="reTaskModel.responseResult == 1">
                          <el-form-item label="复议成绩">
                            <el-input
                              class="w-123"
                              type="number"
                              v-model="reTaskModel.responseScore"
                              placeholder="请输入内容"
                              :disabled="scored"
                            ></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                      <el-row>
                        <el-col :span="24">
                          <el-form-item label="评分说明" label-width="69px">
                            <el-input
                              v-model="reTaskModel.responseContent"
                              placeholder="请输入内容"
                              :disabled="scored"
                            ></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </el-form>
                    <div class="btns footer">
                      <div v-if="qaScoreType === 1 || qaScoreType === 2">
                        <el-button
                          :disabled="scored"
                          @click="submitAllScore"
                          type="primary"
                        >
                          提交成绩
                        </el-button>
                      </div>
                      <div
                        v-if="
                          (qaScoreType === 3 || qaScoreType === 4) &&
                            (roleCodeId.includes('qa_suvs') === false ||
                              obj.isCreator != 1)
                        "
                      >
                        <el-button
                          @click="submitzjyAllScore"
                          type="primary"
                          :disabled="scored"
                        >
                          提交
                        </el-button>
                      </div>
                      <!-- 主管双角色（主管和质检员角色），从我的质检任务-》复议任务进入，此时是提交，没有驳回操作 -->
                      <div
                        v-if="
                          fromUrl == 'myQaTasks_reconsider' &&
                            qaScoreType === 3 &&
                            roleCodeId.includes('qa_suvs') &&
                            obj.isCreator != 0
                        "
                      >
                        <el-button
                          @click="submitzjyAllScore"
                          type="primary"
                          :disabled="scored"
                        >
                          提交
                        </el-button>
                      </div>
                      <div
                        v-if="
                          fromUrl !== 'myQaTasks_reconsider' &&
                            qaScoreType === 3 &&
                            roleCodeId.includes('qa_suvs') &&
                            obj.isCreator != 0
                        "
                      >
                        <el-button
                          @click="submitAllScore"
                          type="primary"
                          :disabled="scored"
                        >
                          驳回申诉
                        </el-button>
                        <el-button
                          @click="submitAllScore"
                          type="primary"
                          :disabled="scored"
                        >
                          提交新成绩
                        </el-button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
    <el-dialog
      append-to-body
      title="添加案例"
      :visible.sync="showAddCaseDialog"
      :close-on-click-modal="false"
      :before-close="handleCloseAddCaseDialog"
      class="showDialogHeader"
    >
      <el-form
        :model="AddCaseModel"
        ref="AddCaseModel"
        label-width="70px"
        :rules="addCaseRules"
        label-position="left"
      >
        <div class="contentRight">
          <div class="addCaseReason">
            <el-form-item label="添加到" prop="dataType">
              <el-select v-model="AddCaseModel.dataType" placeholder="请选择">
                <el-option
                  v-for="item in dataTree"
                  :key="item.caseClassId"
                  :label="item.className"
                  :value="item.caseClassId"
                  :disabled="item.disabled"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="理由" prop="addCaseReason">
              <el-input
                type="textarea"
                :rows="12"
                placeholder="请输入添加原因"
                v-model="AddCaseModel.addCaseReason"
              >
              </el-input>
            </el-form-item>
          </div>
        </div>
        <el-form-item>
          <div class="btns addCaseReason_btns">
            <el-button @click="handleCloseAddCaseDialog">取消</el-button>
            <el-button type="primary" @click="hasSameCaseThrottle">添加</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import moment from 'moment'
import global from '../../../global.js'
import qs from 'qs'
import vPlayer from '../../common/player.vue'
import formatdate from '../../../utils/formatdate.js'
import cache from '../../../utils/cache'
import throttledMessage from './throttledMessage'

let qualityUrl = global.qualityUrl
let hrmApi = global.hrmApi

export default {
  name: 'recordingPlayMultiple',
  beforeCreate() {
    this.$message = throttledMessage
  },
  components: {
    vPlayer,
  },
  data() {
    return {
      noteList: [], // 多个评分说明
      activeName: '', // 评分说明
      reTaskReasonModel: {
        note: '',
      },
      isShowPlayInfoTooltip: false,
      isEditPlayInfoList: true,
      isShowrefuse: false,
      isShowadopt: false,
      isShoweditCase: false,
      isShowLook: false,
      isShowdelby: false,
      isShowdelete: false,
      isShowclose: false,
      isShowedit: false,
      isShowplus: false,
      isDisabledEdit: false,
      isDisabledPlus: false,
      isShowAnLiGuanLi: false,
      playInfoVosList: [], // 通话内容列表
      scoringTrajectory: [], // 评分轨迹
      aclOperVo: {},
      value: 4, // 坐席星级
      serviceLabels: [], // 坐席标签
      customInfoModel: {},
      parentModel: {},
      esResultModel: {
        seatStar: 1,
        callSTime: '',
        callETime: '',
        labelContent: '',
      }, // 基本信息
      caseTag: [], // 录音的案例标签
      showQaAppealScore: false,
      showReturnVisitMatchResult: false,
      showQaReconsider: false,
      showCustrmerInfo: false,
      showInitalQaScore: false,
      showQaCalibration: false,
      showQaCalibrationScore: false,
      showInitalQaScoreRead: false,
      showAddCaseDialog: false, // 添加案例
      dataTree: [], // 获取质检员列表
      classifyObject: {}, // 选中的分类
      defaultProps: {
        children: 'listClass',
        label: 'name',
      },
      addClassRules: {
        // 添加案例验证
        name: [
          {
            required: true,
            message: '分类名称不能为空',
            trigger: 'blur',
          },
        ],
      },
      AddCaseModel: {
        dataType: '', // 案例分类
        addCaseReason: '', // 案例弹窗
      },
      addCaseRules: {
        // 添加案例验证
        dataType: [
          {
            required: true,
            message: '请选择分类',
            trigger: 'change',
          },
        ],
        addCaseReason: [
          {
            required: true,
            message: '请输入添加原因',
            trigger: 'blur',
          },
        ],
      },
      returnVisitMatchResult: [],
      minSpeed: 1, // 最慢语速
      maxSpeed: 10, // 最快语速
      times: [], // 对话时间
      editReQaScore: false, // 复检评分
      showReQaScore: false, // 复检得分
      modleTitle: '', // 质检模版名称
      standardsListWithAutoScoreQa: [],
      showQaQualityScore: false,
      showScoringTrajectory: false,
      showItFilter: false,
      currentClass: '', // 当前正在播放的录音内容所在的盒子的class
      color: ['success', 'warning', 'danger', 'gray'],
      hitWords: {
        '1': [],
        '2': [],
        '0': [],
      }, // 智能筛选命中词
      countHasError: false, // 自动打分修改的是否正确
      editCountKey: '',
      handleContent: '',
      modleId: '',
      testData: {
        ad: '0',
      },
      standardsListWithScoreQa: {}, // 手动打分的model
      isAutoDead: '2',
      isDead: '2',
      deadItem: '2',
      deadOptions: [
        {
          value: 1,
          label: '致命',
        },
        {
          value: 2,
          label: '非致命',
        },
      ],
      reTaskModel: {
        responseResult: 1,
        responseContent: '',
        responseScore: '',
      },
      scoreDetails: [], // 人工打分table
      filterFaq: [], // 过滤内容质检话术意图命中项
      currentDistribute: [], // 要保存的当前分数列表,自动打分项
      scored: false, // 默认未打分
      modelId: '', // 模版ID
      roleCodeId: [], // 角色编码
      okToSubmit: true, // 是否可以提交
      errorMessage: {}, // 错误信息
      errorMsg: '', // 错误提示
      flowoptions: [],
      flowValue: [],
      flowValueData: [], // 存储页面的流程的存在状态
      baseScore: 100,
      labelName: '初检得分',
      flowListWithScoreQa: [], // 流程对象存储
      flowListScoreObjs: [], // 要保存的当前分数列表，流程评分
      isClose: false, //关闭
    }
  },
  computed: {
    isShowFirst() {
      return [1, 2].includes(this.qaScoreType)
    },
    isShowSecond() {
      return this.qaScoreType == 2
    },
    isShowThird() {
      return this.qaScoreType == 3
    },
    isShowFour() {
      return this.qaScoreType == 3
    },
    accountId() {
      return this.$store.state.loginUserinfo.accountId
    },
    account() {
      return this.$store.state.loginUserinfo.account
    },
    currentTime() {
      return this.$store.state.playerInfo.currentTime * 1000
    },
    callId() {
      return this.$store.state.recordingPlayPage.callId
    },
    taskId() {
      return this.$store.state.recordingPlayPage.taskId
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
    FuyiTask_EndTime() {
      return this.$store.state.recordingPlayPage.FuyiTask_EndTime
    },
    fromUrl() {
      let name = this.$store.state.recordingPlayPage.from
      return name
    },
    playType() {
      return this.$store.state.recordingPlayPage.playType
    },
    fromPage() {
      return this.$store.state.recordingPlayPage.fromPage
    },
    obj() {
      return this.$store.state.recordingPlayPage
    },
    spanFirst() {
      return this.obj.from === 'artificialSample' ||
        this.obj.from === 'caseManage_new' ||
        this.obj.from === 'myColList'
        ? 10
        : 7
    },
    spanSecond() {
      return this.obj.from === 'artificialSample' ||
        this.obj.from === 'caseManage_new' ||
        this.obj.from === 'myColList'
        ? 14
        : 8
    },
    spanThird() {
      return this.obj.from === 'artificialSample' ||
        this.obj.from === 'caseManage_new' ||
        this.obj.from === 'myColList'
        ? 0
        : 9
    },
    qaScoreType() {
      // 初检还是复检
      return this.$store.state.recordingPlayPage.qaScoreType
    },
    autoScoreFun() {
      let total = 0
      let _this = this
      let flag = true
      console.log(_this.currentDistribute)
      _this.currentDistribute.forEach(function(item) {
        if (_this.qaScoreType === 1) {
          // 初检
          if (item.deadItem !== '1' && item.judge != 8) {
            total += parseInt(item.firstQaScore) || parseInt(item.defaultScore) || 0
          } else if (item.judge == 8 && flag) {
            if (item.firstQaScore == '1') {
              // 如果有一项是致命项则所有的非致命项不能生效
              _this.isDead = '1'
              flag = false
            }
          }
        } else if (_this.qaScoreType === 2) {
          // 复检
          if (item.deadItem !== '1' && item.judge != 8) {
            total += parseInt(item.secondQaScore) || 0
          } else if (item.judge == 8 && flag) {
            if (item.secondQaScore == '1') {
              // 如果有一项是致命项则所有的非致命项不能生效
              _this.isDead = '1'
              flag = false
            }
          }
        } else if (_this.qaScoreType === 3) {
          // 复议一次
          if (item.deadItem !== '1' && item.judge != 8) {
            if (_this.roleCodeId.includes('qa_suvs') && _this.obj.isCreator != 0) {
              total += parseInt(item.threeScore) || 0
            } else {
              total += parseInt(item.secondQaScore) || 0
            }
          } else if (item.judge == 8 && flag) {
            if (_this.roleCodeId.includes('qa_suvs') && _this.obj.isCreator != 0) {
              if (item.threeScore == '1') {
                // 如果有一项是致命项则所有的非致命项不能生效
                _this.isDead = '1'
                flag = false
              } else {
                _this.isDead = '2'
              }
            } else {
              if (item.judge == 8 && flag) {
                if (item.secondQaScore == '1') {
                  // 如果有一项是致命项则所有的非致命项不能生效
                  _this.isDead = '1'
                  flag = false
                } else {
                  _this.isDead = '2'
                }
              }
            }
          }
        } else if (_this.qaScoreType === 4) {
          // 复议二次
          if (item.deadItem !== '1' && item.judge != 8) {
            if (_this.roleCodeId.includes('qa_suvs') && _this.obj.isCreator != 0) {
              total += parseInt(item.fourScore) || 0
            } else {
              total += parseInt(item.threeScore) || 0
            }
          } else if (item.judge == 8 && flag) {
            if (_this.roleCodeId.includes('qa_suvs') && _this.obj.isCreator != 0) {
              if (item.fourScore == '1') {
                // 如果有一项是致命项则所有的非致命项不能生效
                _this.isDead = '1'
                flag = false
              } else {
                _this.isDead = '2'
              }
            } else {
              if (item.judge == 8 && flag) {
                if (item.threeScore == '1') {
                  // 如果有一项是致命项则所有的非致命项不能生效
                  _this.isDead = '1'
                  flag = false
                } else {
                  _this.isDead = '2'
                }
              }
            }
          }
        }
      })
      console.info('2222222222222')
      console.info(total + '   _this.isAutoDead=' + _this.isAutoDead)
      if (_this.isAutoDead == '1' || _this.isDead == '1') {
        return 0
      }
      return total
    },
    flowScoreFun() {
      let total = 0
      let _this = this
      _this.flowListScoreObjs.forEach(function(item) {
        if (_this.qaScoreType === 1) {
          // 初检
          total += parseInt(item.firstScore) || 0
        } else if (_this.qaScoreType === 2) {
          // 复检
          total += parseInt(item.secondScore) || 0
        } else if (_this.qaScoreType === 3) {
          // 复议一次
          if (_this.roleCodeId.includes('qa_suvs') && _this.obj.isCreator != 0) {
            total +=
              parseInt(item.thirdScore) ||
              0 ||
              (parseInt(item.secondScore) || 0) ||
              (parseInt(item.firstScore) || 0)
          } else {
            if (_this.fromUrl == 'myQaTasks_reconsider') {
              // total += (parseInt(item.secondScore) || 0) || (parseInt(item.firstScore) || 0) || (parseInt(item.thirdScore) || 0)
              if (_this.playType == 0) {
                // 判断是否有复检流程 0表示没有，1表示有
                total += parseInt(item.firstScore) || 0
              } else {
                total += parseInt(item.secondScore) || 0
                // total += (parseInt(item.secondScore) || 0) || (parseInt(item.firstScore) || 0)
              }
              // total += (parseInt(item.secondScore) || 0) || (parseInt(item.firstScore) || 0)
            } else {
              total += parseInt(item.secondScore) || 0
            }
          }
        } else if (_this.qaScoreType === 4) {
          // 复议二次
          if (_this.roleCodeId.includes('qa_suvs') && _this.obj.isCreator != 0) {
            if (item.hasOwnProperty('fourScore')) {
              total += parseInt(item.fourScore) || 0
            } else if (item.hasOwnProperty('thirdScore')) {
              total += parseInt(item.thirdScore) || 0
            } else if (item.hasOwnProperty('secondScore')) {
              total += parseInt(item.secondScore) || 0
            } else if (item.hasOwnProperty('firstScore')) {
              total += parseInt(item.firstScore) || 0
            }
          } else {
            if (item.hasOwnProperty('thirdScore')) {
              total += parseInt(item.thirdScore) || 0
            } else if (item.hasOwnProperty('secondScore')) {
              total += parseInt(item.secondScore) || 0
            } else if (item.hasOwnProperty('firstScore')) {
              total += parseInt(item.firstScore) || 0
            }
          }
        }
      })
      return total
    },
    totalScoreFun() {
      if (this.isAutoDead == '1' || this.isDead == '1') {
        this.deadItem = '1'
        return 0
      } else {
        this.deadItem = '2'
      }
      console.info(
        'this.baseScore=' +
          this.baseScore +
          ' this.autoScoreFun=' +
          this.autoScoreFun +
          ' this.flowScoreFun=' +
          this.flowScoreFun
      )
      let totalScore =
        parseInt(this.baseScore) + (this.autoScoreFun + this.flowScoreFun) < 0
          ? 0
          : parseInt(this.baseScore) + (this.autoScoreFun + this.flowScoreFun)
      return totalScore
    },
  },
  async created() {
    this.initActRole() // 获取当前角色
    if (this.fromUrl == 'myQaTasks_reconsider') {
      // this.labelName = '得分'
    }
    if (this.fromUrl !== 'caseManage_new') {
      // 案例管理，不需要取模板和分数
      await this.getConditonScore(this.obj) // 获取评分模版以及分数
      this.getPlayInfo() // 获取录音文本信息（对话内容)
      this.getFlowIds() // 获取流程ids
    } else {
      this.getPlayInfo() // 获取录音文本信息（对话内容)
    }
    this.getCaseTag() // 获取录音案例标签
    this.getProcessList() // 获取模版
  },
  mounted() {
    this.getLocus()
  },
  methods: {
    async init() {
      this.isAutoDead = '2'
      this.isDead = '2'
      this.scored = false
      this.isEditPlayInfoList = true
      this.initScore()
      this.getLocus()
      if (this.fromUrl !== 'caseManage_new') {
        // 案例管理，不需要取模板和分数
        await this.getConditonScore(this.obj)
        this.getFlowIds() // 获取流程ids
      }
      this.getPlayInfo() // 获取录音文本信息（对话内容）
      this.getCaseTag() // 获取录音案例标签
      this.getProcessList() // 获取模版
    },
    formatJudge(row) {
      let objname = {
        '1': '情绪',
        '2': '重叠次数',
        '3': '静默',
        '4': '语速',
        '5': '关键词',
        '6': '自定义输入',
        '7': '自定义选择',
        '8': '自定义致命',
        '11': '标签',
        '12': '上下文质检',
        '13': '内容质检',
      }
      return objname[row.judge]
    },
    getHtml(flag) {
      let arrAll = flag.split(' ')
      for (let i = 0; i < arrAll.length; i++) {
        if (
          this.esResultModel.correctWholeContent &&
          this.esResultModel.correctWholeContent.includes(arrAll[i].replace(/[(|)]/g, ''))
        ) {
          if (arrAll[i].includes('(')) {
            arrAll[i] = `(<span style='color:#409eff;'>${arrAll[i].replace(
              /[(|)]/g,
              ''
            )}</span>`
          } else if (arrAll[i].includes(')')) {
            arrAll[i] = `<span style='color:#409eff;'>${arrAll[i].replace(
              /[(|)]/g,
              ''
            )}</span>)`
          } else {
            arrAll[i] = `<span style='color:#409eff;'>${arrAll[i]}</span>`
          }
        }
      }
      let endStr = arrAll.toString().replace(/,/g, ' ')
      return endStr
    },
    getContentHtml(flag) {
      if (this.filterFaq.includes(flag)) {
        flag = `<span style='color:#409eff;'>${flag}</span>`
      }
      return flag
    },
    initScore: function() {
      this.currentDistribute = []
      this.flowListScoreObjs = []
    },
    // 致命项得分
    getKeywordScoreFilter(rules, judge) {
      const { roleOptions, positionOptions, positionOptionsText } = global
      const {
        increaseDeduction,
        score,
        isAppear,
        deadItem,
        offset,
        position,
        roleType,
        sceneTime,
        silenceTimeMax,
      } = rules
      let str = ''
      if (deadItem !== '1') {
        let offsetValue = judge === 5 && position != 0 ? `${offset} 句` : ''
        judge === 5
          ? (str = ` 在 ${roleOptions[roleType]}侧 在 ${
              positionOptionsText[position]
            } ${offsetValue} ${isAppear == '1' ? '出现' : '未出现'}${
              increaseDeduction == '2' ? '减' : '加'
            }${score}分`)
          : (str = ` 在${roleOptions[roleType]}侧 在静默时间大于 ${silenceTimeMax} 秒 ${
              positionOptions[position]
            } ${sceneTime} 句 ${isAppear == '1' ? '出现' : '未出现'}${
              increaseDeduction == '2' ? '减' : '加'
            }${score}分`)
      }
      return str
    },
    // 获取基准分
    getBaseScore(modelId, callId) {
      let _this = this
      let params = {
        moduleId: modelId,
        callId: callId,
      }
      let url = qualityUrl + '/qaDetail/getBaseScore.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.baseScore = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取基准分失败',
          })
        })
    },
    // 获取模板列表
    getProcessList() {
      let _this = this
      let url = qualityUrl + '/process/getAllProcess.do'
      let params = {
        callId: this.callId,
      }
      _this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.flowoptions = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '流程获取失败',
          })
        })
    },
    // 选择流程模版
    changeFlowOption(val) {
      let valArr = []
      let _this = this
      // this.flowValueData = this.flowValueData.filter(
      //   (itf) => val.includes(itf.processName) || val.includes(itf.processId)
      // )
      for (let i = 0; i < val.length; i++) {
        let itm = val[i]
        let isStatus = _this.flowValueData.some(
          (item) => item.processName == itm || item.processId == itm
        )
        _this.flowoptions.forEach(function(item) {
          if (itm === item.processName) {
            valArr.push({
              processId: item.processId,
              status: isStatus ? 0 : 1,
            })
          } else if (itm === item.processId) {
            valArr.push({
              processId: itm,
              status: isStatus ? 0 : 1,
            })
          }
        })
      }
      this.countHasError = false
      this.errorMsg = ''
      this.flowListScoreObjs = []
      this.flowListWithScoreQa = []
      let url = qualityUrl + '/process/getAllIntentByProcessIds.do'
      let params = {
        processStatusList: JSON.stringify(valArr),
        callId: this.callId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then((res) => {
          if (res.data) {
            let data = res.data
            _this.flowListWithScoreQa = data
            _this.flowValue = []
            data.forEach(function(item) {
              _this.flowValue.push(item.processId)
            })
            let indexT = 0
            for (let i = 0; i < data.length; i++) {
              let obj = _this.flowListWithScoreQa[i].processDetail
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.processId = data[i].processId
                temp.distinctSingle = data[i].distinctSingle
                temp.intentId = item.intentId
                temp.firstScore = item.firstScore === undefined ? '' : item.firstScore
                temp.secondScore = item.secondScore === undefined ? '' : item.secondScore
                temp.thirdScore = item.thirdScore === undefined ? '' : item.thirdScore
                temp.scoreMin = item.scoreMin
                temp.scoreMax = item.scoreMax
                temp.intentName = item.intentName
                temp.intentRule = item.intentRule
                temp.processName = data[i].processName
                _this.$set(_this.flowListScoreObjs, indexT, temp)
                indexT++
              })
            }
          }
        })
        .catch(function(e) {
          console.log(e)
          // _this.$message({
          //   type: 'error',
          //   message: '查询失败',
          // })
        })
    },
    dateFormat: function(date) {
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // 获取分类树
    getTreeData() {
      let _this = this
      let url = qualityUrl + '/caseManage/getEffectiveTreeData.do'
      let params = {
        objectId: this.callId,
        objectType: ' ',
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.dataTree = response.data
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分类获取失败',
          })
        })
    },
    // 获取案例标签
    getCaseTag() {
      let _this = this
      let url = qualityUrl + '/caseManage/showClassName.do'
      let params = {
        objectId: this.callId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.caseTag = response.data.data.length == 0 ? [] : response.data.data
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分类标签获取失败',
          })
        })
    },
    // 致命项
    changeDead(index, judge, type) {
      if (
        (type == 'defaultScore' && this.currentDistribute[index].defaultScore == '1') ||
        (type == 'secondQaScore' && this.currentDistribute[index].secondQaScore == '1') ||
        (type == 'threeScore' && this.currentDistribute[index].threeScore == '1')
      ) {
        judge == 5 || judge == 11 || judge == 12
          ? (this.isAutoDead = '1')
          : (this.isDead = '1')
      } else {
        this.isAutoDead = '2'
        this.isDead = '2'
      }
    },
    // 获取角色与角色ID
    initActRole() {
      let codes = cache.getItem('roleInfo')
      this.roleCodeId = codes.split(',')
      console.log(this.roleCodeId)
    },
    // 时间转化
    fromData: function(data) {
      let newData = new Date(data)
      let m = newData.getMonth()
      let d = newData.getDay()
      return m + '-' + d
    },
    // 获取开始时间和结束时间，保存到vuex中
    playClip(startTime, endTime) {
      let playInfo = {}
      playInfo.timeSection = [startTime, endTime]
      this.$store.commit('setPlayerInfo', playInfo)
    },
    // 检查当前分配输入的是否是数字并且是否输入
    checkFlowNumber(index, row) {
      this.countHasError = false
      this.errorMsg = ''
      if (this.qaScoreType == 1) {
        if (this.flowListScoreObjs[index].firstScore === '') {
          this.countHasError = true
        }
        if (
          typeof +this.flowListScoreObjs[index].firstScore !== 'number' ||
          Number.isNaN(+this.flowListScoreObjs[index].firstScore)
        ) {
          this.$message({
            type: 'error',
            message: '请输入数字',
          })
          event.target.focus()
          this.countHasError = true
          this.errorMsg = '请输入数字'
          return false
        }
        if (
          (this.flowListScoreObjs[index].firstScore !== '' &&
            this.flowListScoreObjs[index].firstScore > row.scoreMax) ||
          (this.flowListScoreObjs[index].firstScore !== '' &&
            this.flowListScoreObjs[index].firstScore < row.scoreMin)
        ) {
          this.$message({
            type: 'error',
            message: '分值范围为' + row.scoreMin + '~' + row.scoreMax,
          })
          event.target.focus()
          this.countHasError = true
          this.errorMsg = '分值范围为' + row.scoreMin + '~' + row.scoreMax
          return false
        }
      }
      if (this.qaScoreType == 2) {
        if (this.flowListScoreObjs[index].secondScore === '') {
          this.countHasError = true
        }
        if (
          typeof +this.flowListScoreObjs[index].secondScore !== 'number' ||
          Number.isNaN(+this.flowListScoreObjs[index].secondScore)
        ) {
          this.$message({
            type: 'error',
            message: '请输入数字',
          })
          event.target.focus()
          this.countHasError = true
          this.errorMsg = '请输入数字'
          return false
        }
        if (
          (this.flowListScoreObjs[index].secondScore !== '' &&
            this.flowListScoreObjs[index].secondScore > row.scoreMax) ||
          (this.flowListScoreObjs[index].secondScore !== '' &&
            this.flowListScoreObjs[index].secondScore < row.scoreMin)
        ) {
          this.$message({
            type: 'error',
            message: '分值范围为' + row.scoreMin + '~' + row.scoreMax,
          })
          event.target.focus()
          this.countHasError = true
          this.errorMsg = '分值范围为' + row.scoreMin + '~' + row.scoreMax
          return false
        }
      }
      if (this.qaScoreType == 3) {
        if (this.flowListScoreObjs[index].thirdScore === '') {
          this.countHasError = true
        }
        if (
          typeof +this.flowListScoreObjs[index].thirdScore !== 'number' ||
          Number.isNaN(+this.flowListScoreObjs[index].thirdScore)
        ) {
          this.$message({
            type: 'error',
            message: '请输入数字',
          })
          event.target.focus()
          this.countHasError = true
          this.errorMsg = '请输入数字'
          return false
        }
        if (
          (this.flowListScoreObjs[index].thirdScore !== '' &&
            this.flowListScoreObjs[index].thirdScore > row.scoreMax) ||
          (this.flowListScoreObjs[index].thirdScore !== '' &&
            this.flowListScoreObjs[index].thirdScore < row.scoreMin)
        ) {
          this.$message({
            type: 'error',
            message: '分值范围为' + row.scoreMin + '~' + row.scoreMax,
          })
          event.target.focus()
          this.countHasError = true
          this.errorMsg = '分值范围为' + row.scoreMin + '~' + row.scoreMax
          return false
        }
      }
    },
    checkNumber(index, obj, type) {
      /*
       * 初检type == 'defalult'
       * 复检type == 'secondQaScore'
       * 复议type == 'threeScore'
       * */
      console.log(index)
      console.log(obj)
      this.countHasError = false
      this.errorMsg = ''
      let arr = []
      if (typeof obj.minScoreRange === 'number' && !Number.isNaN(obj.minScoreRange)) {
        arr.push(obj.minScoreRange)
      } else {
        arr.push(0)
      }
      if (typeof obj.maxScoreRange === 'number' && !Number.isNaN(obj.maxScoreRange)) {
        arr.push(obj.maxScoreRange)
      }
      if (typeof obj.defaultScore === 'number' && !Number.isNaN(obj.defaultScore)) {
        arr.push(obj.defaultScore)
      }
      arr.sort(function(a, b) {
        return a - b
      })
      let min = arr[0] > obj.defaultScore ? obj.defaultScore : arr[0]
      let max =
        arr[arr.length - 1] < obj.defaultScore ? obj.defaultScore : arr[arr.length - 1]
      // 设置自动评分的致命项
      if (obj.resultsObject[0].deadItem == '1') {
        // 致命项只能打分0/1
        min = 0
        max = 1
        if (
          (type == 'defaultScore' &&
            obj.resultsObject[0].deadItem == '1' &&
            this.currentDistribute[index].defaultScore <= 0) ||
          (type == 'defaultScore' &&
            obj.resultsObject[0].deadItem == '1' &&
            this.currentDistribute[index].secondQaScore <= 0) ||
          (type == 'threeScore' &&
            obj.resultsObject[0].deadItem == '1' &&
            this.currentDistribute[index].threeScore <= 0)
        ) {
          this.isAutoDead = '1'
        } else {
          this.isAutoDead = '2'
        }
      }
      if (
        (type == 'defaultScore' && this.currentDistribute[index].defaultScore === '') ||
        (type == 'secondQaScore' && this.currentDistribute[index].secondQaScore === '') ||
        (type == 'threeScore' && this.currentDistribute[index].threeScore === '')
      ) {
        this.countHasError = true
      }
      if (
        (type == 'defaultScore' &&
          typeof +this.currentDistribute[index].defaultScore !== 'number') ||
        (type == 'defaultScore' &&
          Number.isNaN(+this.currentDistribute[index].defaultScore)) ||
        (type == 'secondQaScore' &&
          typeof +this.currentDistribute[index].secondQaScore !== 'number') ||
        (type == 'secondQaScore' &&
          Number.isNaN(+this.currentDistribute[index].secondQaScore)) ||
        (type == 'threeScore' &&
          typeof +this.currentDistribute[index].threeScore !== 'number') ||
        (type == 'threeScore' && Number.isNaN(+this.currentDistribute[index].threeScore))
      ) {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
        this.countHasError = true
        this.errorMsg = '请输入数字'
        return false
      } else if (
        (type == 'defaultScore' &&
          this.currentDistribute[index].defaultScore !== '' &&
          this.currentDistribute[index].defaultScore < min) ||
        (type == 'defaultScore' &&
          this.currentDistribute[index].defaultScore !== '' &&
          this.currentDistribute[index].defaultScore > max) ||
        (type == 'secondQaScore' &&
          this.currentDistribute[index].secondQaScore !== '' &&
          this.currentDistribute[index].secondQaScore < min) ||
        (type == 'secondQaScore' &&
          this.currentDistribute[index].secondQaScore !== '' &&
          this.currentDistribute[index].secondQaScore > max) ||
        (type == 'threeScore' &&
          this.currentDistribute[index].threeScore !== '' &&
          this.currentDistribute[index].threeScore < min) ||
        (type == 'threeScore' &&
          this.currentDistribute[index].threeScore !== '' &&
          this.currentDistribute[index].threeScore > max)
      ) {
        this.$message({
          type: 'error',
          message: '分值范围为' + min + '~' + max,
        })

        event.target.focus()
        this.countHasError = true
        this.errorMsg = '分值范围为' + min + '~' + max
        return false
      } else {
        this.errorMsg = ''
      }
    },
    checkRange(val, min, max) {
      this.countHasError = false
      this.errorMsg = ''
      if (isNaN(val)) {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
        this.errorMsg = '请输入数字'
      } else if (val === '') {
        this.countHasError = true
      } else if (val < min || val > max) {
        this.$message({
          type: 'error',
          message: '分值范围为' + min + '~' + max,
        })
        this.errorMsg = '分值范围为' + min + '~' + max
        event.target.focus()
      } else {
        this.errorMsg = ''
      }
    },
    // 播放器缩小
    minimizePage() {
      this.volumeControl = false
      let playInfo = {}
      playInfo.isMaximization = false
      this.isPlayinfo = playInfo.isclosedialog
      let taskId = this.$store.state.returnVisitConfig.taskId
      let projectId = this.$store.state.returnVisitConfig.projectId
      let matchRecordCount = this.$store.state.returnVisitConfig.matchRecordCount
      let allRecordCount = this.$store.state.returnVisitConfig.allRecordCount
      let matchRatio = this.$store.state.returnVisitConfig.matchRatio
      let obj = {
        taskId: taskId,
        showTaskResult: true,
        showDetailPage: true,
        projectId: projectId,
        matchRecordCount: matchRecordCount,
        allRecordCount: allRecordCount,
        matchRatio: matchRatio,
      }
      this.$store.commit('setTaskResult', obj)
      this.$store.commit('setPlayerInfo', playInfo)
      this.$emit('onminimize', playInfo)
    },
    // 播放器关闭
    closePage() {
      this.isClose = true
      let _this = this
      this.$message.suppress()
      console.log('close')
      this.$confirm('关闭界面将停止录音播放，确定关闭么', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let playInfo = {}
          playInfo.isMaximization = false
          playInfo.exist = false
          // let url = _this.fromPage || 'home'
          let taskId = _this.$store.state.returnVisitConfig.taskId
          let projectId = _this.$store.state.returnVisitConfig.projectId
          let matchRecordCount = _this.$store.state.returnVisitConfig.matchRecordCount
          let allRecordCount = _this.$store.state.returnVisitConfig.allRecordCount
          let matchRatio = _this.$store.state.returnVisitConfig.matchRatio
          let obj = {
            taskId: taskId,
            showTaskResult: true,
            showDetailPage: true,
            projectId: projectId,
            matchRecordCount: matchRecordCount,
            allRecordCount: allRecordCount,
            matchRatio: matchRatio,
          }
          _this.$store.commit('setTaskResult', obj)
          _this.$store.commit('setPlayerInfo', playInfo)
          _this.focusWord = ''
          _this.activeName = ''
          this.$emit('onclose')
          setTimeout(() => {
            this.isClose = false
          }, 500)
        })
        .finally(() => this.$message.suppress())
        .catch(() => {
          this.isClose = false
        })
    },
    test() {
      // 停止正在进行的动画  减少卡顿感
      $('.dialog').stop(true, false)
      if (window.myinterVal) {
        return
      } else {
        window.myinterVal = 5
      }
      setTimeout(function() {
        window.myinterVal = 0
      }, 5000)
      // 清除计时任务
      // 3秒后重新
    },
    // 获取评分轨迹
    getLocus() {
      let _this = this
      let url = qualityUrl + '/scoreView/getLocus.do'
      let params = {}
      params.objectId = this.callId
      params.scoreClass = '1'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.scoringTrajectory = response.data.locus
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取评分轨迹失败',
          })
        })
    },
    // 获取当前流程ID和模版信息
    getFlowIds() {
      let _this = this
      let params = {
        callId: this.callId,
        qaScoreType: this.qaScoreType,
      }
      this.flowListWithScoreQa = []
      let url = ''
      if (this.fromUrl == 'myQaTasks_reconsider') {
        // _this.labelName = '得分'
        url = qualityUrl + '/process/getProDetailByCallIdFromFuyi.do'
      } else {
        url = qualityUrl + '/process/queryProcessDetailByCallId.do'
      }
      this.axios
        .post(url, qs.stringify(params))
        .then((res) => {
          if (res.data) {
            let data = res.data
            _this.flowListWithScoreQa = data
            _this.flowValue = []
            _this.flowValueData = []
            _this.flowListScoreObjs = []
            data.forEach(function(item) {
              _this.flowValue.push(item.processId)
              _this.flowValueData.push({
                processName: item.processName,
                processId: item.processId,
              })
            })
            let indexT = 0
            for (let i = 0; i < data.length; i++) {
              let obj = _this.flowListWithScoreQa[i].processDetail
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.processId = data[i].processId
                temp.distinctSingle = data[i].distinctSingle
                temp.intentId = item.intentId
                temp.firstScore = item.firstScore
                temp.secondScore = item.secondScore
                temp.thirdScore = item.thirdScore
                temp.scoreMin = item.scoreMin
                temp.scoreMax = item.scoreMax
                temp.intentName = item.intentName
                temp.intentRule = item.intentRule
                temp.processName = data[i].processName
                _this.$set(_this.flowListScoreObjs, indexT, temp)
                indexT++
              })
            }
          }
        })
        .catch(function(e) {
          console.log(e)
        })
    },
    // 获取自动人工模版信息
    getConditonScore(obj) {
      let _this = this
      let url = global.qualityUrl + '/scoreView/getAllScore.do'
      let params = {}
      params.objectId = obj.callId
      params.qaScoreType = obj.qaScoreType
      params.taskId = obj.taskId
      return this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.standardsListWithAutoScoreQa = response.data.modleTitle.TempltTA // 有层级关系模版
          _this.standardsListWithScoreQa = response.data.modleTitle.TempltH // 手动打分的模版
          _this.modleTitle = response.data.modleTitle.modleTitle // 模版名称
          _this.noteList = response.data.modleTitle.noteList || [null, null, null, null] // 各项打分时的评分说明(初检/复检/一次申诉/二次申诉)
          _this.modelId =
            response.data.modleTitle.Templt.length > 0
              ? response.data.modleTitle.Templt[0].modleId
              : '' // 模版id
          // 获取内容质检意图与话术的命中词
          _this.filterFaq = []
            .concat(
              ...response.data.scoreDetails.map((item) => {
                return item.contents ? item.contents : []
              })
            )
            .filter((flag) => flag.status === 1)
            .map((val) => val.content)
          console.log(_this.filterFaq)
          _this.getBaseScore(_this.modelId, _this.callId)
          if (response.data.modleTitle.status === 0) {
            // 是否质检状态
            _this.scored = false
          } else {
            _this.scored = true
          }
          if (
            _this.roleCodeId.includes('qa') &&
            _this.fromUrl == 'myQaTasks_reconsider'
          ) {
            console.info('1111111111111111')
            let reconsiderScore = response.data.score[0] && response.data.score[0][0]
            console.info('222222222222222')
            _this.scored = _this.obj.isQaScore
            if (reconsiderScore) {
              for (let item of reconsiderScore) {
                // 判断复议打分的，如果已打分的是当前登录的质检员，则不能进行打分，回显打分内容
                // 后端已对复议内容排序（二次复议的排在前面）
                // 特殊处理从已完成的复议任务页面打开的情况，若当前复议是二次复议未打分，则展示一次复议内容，若是二次复议已打分则展示二次复议内容
                if (
                  item.responseQauserId === _this.account &&
                  _this.obj.assignType == item.assignType &&
                  _this.obj.isQaScore
                ) {
                  _this.scored = true
                  _this.reTaskModel.responseScore = item.responseScore
                  _this.reTaskModel.responseResult = item.responseResult
                  _this.reTaskModel.responseContent = item.responseContent
                  break
                } else if (
                  item.responseQauserId === _this.account &&
                  _this.obj.assignType == 2 &&
                  item.assignType == 1 &&
                  _this.obj.isQaScore
                ) {
                  _this.scored = true
                  _this.reTaskModel.responseScore = item.responseScore
                  _this.reTaskModel.responseResult = item.responseResult
                  _this.reTaskModel.responseContent = item.responseContent
                  break
                } else {
                  _this.reTaskModel.responseScore = ''
                  _this.reTaskModel.responseResult = ''
                  _this.reTaskModel.responseContent = ''
                }
              }
            } else {
              _this.reTaskModel.responseScore = ''
              _this.reTaskModel.responseResult = ''
              _this.reTaskModel.responseContent = ''
            }
            // _this.scored = _this.obj.isQaScore
            // let obj = {
            //   isQaScore: false
            // }
            // _this.$store.commit('setRecordingPlayPage', obj)
          }
          // if (_this.roleCodeId.includes('qa') && _this.scored) {
          //   _this.reTaskModel.responseScore = response.data.score[0] && response.data.score[0][0] && response.data.score[0][0].responseScore
          //   _this.reTaskModel.responseResult = response.data.score[0] && response.data.score[0][0] && response.data.score[0][0].responseResult
          //   _this.reTaskModel.responseContent = response.data.score[0] && response.data.score[0][0] && response.data.score[0][0].responseContent
          // }
          let indexT = 0
          for (let key in _this.standardsListWithAutoScoreQa) {
            let obj = _this.standardsListWithAutoScoreQa[key]
            obj.forEach(function(item, index) {
              item.newIndex = indexT
              let temp = {}
              temp.normalId = item.normalId
              temp.judge = item.judge
              temp.defaultScore = item.defaultScore
              temp.secondQaScore = item.secondQaScore
              temp.threeScore = item.threeScore
              if (item.judge === 5 || item.judge === 11) {
                // 默认分数特殊处理，在建评分模板时，deaditem =1 时，默认是非致命 = 1，故此处要强制把 非致命改成2
                item.defaultScore =
                  item.resultsObject[0].deadItem == '1' &&
                  (item.defaultScore == null || item.defaultScore == 1)
                    ? 2
                    : item.defaultScore
                temp.defaultScore = item.defaultScore
                temp.deadItem = item.resultsObject[0].deadItem
                item.deadItem = item.resultsObject[0].deadItem
              } else if (item.judge === 12) {
                item.defaultScore =
                  item.resultsObject[0].sentenceDeadItem == '1' &&
                  (item.defaultScore == null || item.defaultScore == 1)
                    ? '2'
                    : item.defaultScore + ''
                temp.defaultScore = item.defaultScore
                temp.deadItem = item.resultsObject[0].sentenceDeadItem
                item.deadItem = item.resultsObject[0].sentenceDeadItem
              } else if (item.judge === 7) {
                temp.defaultScore = item.resultsObject[0]
                temp.secondQaScore = item.resultsObject[0]
                temp.threeScore = item.resultsObject[0]
              } else if (item.judge === 8) {
                // 人工打分致命项默认给个非致命项
                item.defaultScore = item.defaultScore || '2'
                temp.defaultScore = item.defaultScore
                if (!temp.secondQaScore) {
                  temp.secondQaScore = item.defaultScore || '2'
                }
                if (!temp.threeScore) {
                  temp.threeScore = item.defaultScore || '2'
                }
              } else {
                temp.deadItem = '2'
                item.deadItem = '2'
              }
              _this.$set(_this.currentDistribute, indexT, temp)
              indexT++
            })
          }
          // 如果获取到了数据则赋值
          if (response.data && response.data.scoreDetails) {
            _this.scoreDetails = response.data.scoreDetails
            // 如果是初检页面，则给编辑界面的值赋值
            _this.changData(response.data.scoreDetails)
            _this.handleContent = response.data.score.comments || ''
          } else if (response.data && response.data.score) {
            _this.handleContent = response.data.score.comments
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数获取失败',
          })
        })
    },
    // 根据获取的分数修改模板内容
    changData(scoreDetails) {
      let _this = this
      scoreDetails.forEach(function(item) {
        for (let key in _this.standardsListWithAutoScoreQa) {
          _this.standardsListWithAutoScoreQa[key].forEach(function(itm) {
            if (itm.normalId == item.normalId) {
              itm.firstQaScore =
                item.firstQaScore == null ? '' : parseInt(item.firstQaScore)
              itm.secondQaScore =
                item.secondQaScore == null ? '' : parseInt(item.secondQaScore)
              itm.threeScore = item.threeScore == null ? '' : parseInt(item.threeScore)
              itm.fourScore = item.fourScore == null ? '' : parseInt(item.fourScore)
              itm.defaultScore = item.defaultScore
              let obj = {}
              if (itm.deadItem === '1') {
                if (_this.qaScoreType == 1 && itm.firstQaScore === 1) {
                  // 已初检
                  _this.isAutoDead = '1'
                } else if (_this.qaScoreType == 2 && itm.secondQaScore === 1) {
                  _this.isAutoDead = '1'
                } else if (_this.qaScoreType == 3 && itm.threeScore === 1) {
                  _this.isAutoDead = '1'
                } else if (_this.qaScoreType == 4 && itm.fourScore === 1) {
                  _this.isAutoDead = '1'
                }
              }
              if (itm.judge === 5 || itm.judge === 11) {
                itm.deadItem = itm.resultsObject[0].deadItem
                // deadItem = 1的情况下，赋予默认值，未致命
                if (itm.deadItem == '1') {
                  itm.firstQaScore = itm.firstQaScore || 2
                  itm.secondQaScore = itm.secondQaScore || 2
                  itm.threeScore = itm.threeScore || 2
                  itm.fourScore = itm.fourScore || 2
                }
              } else if (itm.judge === 12) {
                itm.deadItem = itm.resultsObject[0].sentenceDeadItem
                // deadItem = 1的情况下，赋予默认值，未致命
                if (itm.deadItem == '1') {
                  itm.firstQaScore = itm.firstQaScore || '2'
                  itm.secondQaScore = itm.secondQaScore || '2'
                  itm.threeScore = itm.threeScore || '2'
                  itm.fourScore = itm.fourScore || '2'
                }
                if (_this.qaScoreType == 3 && itm.secondQaScore == 1) {
                  _this.isDead = '1'
                } else if (_this.qaScoreType == 4 && itm.threeScore == 1) {
                  _this.isDead = '1'
                }
              } else if (itm.judge === 7) {
                if (_this.qaScoreType == 1) {
                  if (item.optioniItem !== null && item.optioniItem !== 0) {
                    itm.defaultScore = item.optioniItem
                    itm.firstQaScore = item.optioniItem1 || item.optioniItem
                  } else {
                    itm.defaultScore = item.score
                    itm.firstQaScore = item.firstQaScore
                  }
                  obj.defaultScore = itm.defaultScore || itm.resultsObject[0]
                } else if (_this.qaScoreType == 2) {
                  if (item.optioniItem !== null && item.optioniItem !== 0) {
                    itm.firstQaScore = item.optioniItem
                    itm.secondQaScore = item.optioniItem2 || itm.resultsObject[0]
                  }
                  obj.firstQaScore = itm.firstQaScore || itm.resultsObject[0]
                } else if (_this.qaScoreType == 3) {
                  if (item.optioniItem2 !== null && item.optioniItem2 !== 0) {
                    // console.info('item.optioniItem=' + item.optioniItem)
                    itm.secondQaScore = item.optioniItem2 || ''
                    itm.threeScore = item.optioniItem3 || itm.resultsObject[0]
                  } else {
                    itm.secondQaScore = item.secondQaScore
                    itm.threeScore = item.threeScore
                  }
                  obj.secondQaScore = itm.secondQaScore || itm.resultsObject[0]
                } else if (_this.qaScoreType == 4) {
                  if (item.optioniItem3 !== null && item.optioniItem3 !== 0) {
                    itm.secondQaScore = item.optioniItem2 || ''
                    itm.threeScore = item.optioniItem3 || ''
                  } else {
                    itm.secondQaScore = item.secondQaScore
                    itm.threeScore = item.threeScore
                  }
                  obj.threeScore = itm.threeScore || itm.resultsObject[0]
                }
              } else if (itm.judge === 8) {
                if (_this.qaScoreType == 1) {
                  itm.firstQaScore =
                    itm.firstQaScore || item.optioniItem1 || item.optioniItem || '2'
                  if (item.optioniItem == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '1'
                  }
                } else if (_this.qaScoreType == 2) {
                  // judge == 8时，默认值非致命
                  itm.secondQaScore = item.optioniItem2 || '2'
                  if (item.optioniItem2 == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '1'
                  }
                } else if (_this.qaScoreType == 3) {
                  // judge == 8时，默认值非致命
                  itm.threeScore = item.optioniItem3 || '2'
                  if (item.optioniItem == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '1'
                  }
                } else if (_this.qaScoreType == 4) {
                  // judge == 8时，默认值非致命
                  itm.threeScore = item.optioniItem3 || '2'
                  if (item.optioniItem == '1') {
                    // 致命项时，若值为1则整个得分都应为0，故改变isDead = 1
                    _this.isDead = '1'
                  }
                }
              } else {
                itm.deadItem = '2'
              }
              for (let key in itm) {
                obj[key] = itm[key]
              }
              _this.$set(_this.currentDistribute, itm.newIndex, obj)
            }
          })
        }
      })
    },
    // 判断数组元素是否都可以转为数字
    checkArrayType(arr) {
      return arr.every(function(val, index, arr) {
        let temp = +val
        return typeof temp === 'number' && !Number.isNaN(temp)
      })
    },
    // 质检员 复议成绩提交分数
    submitzjyAllScore() {
      if (!this.reTaskModel.responseResult) {
        this.$message({
          type: 'error',
          message: '请选择质检状态',
        })
        return
      }
      if (this.reTaskModel.responseResult == 1 && this.reTaskModel.responseScore == '') {
        this.$message({
          type: 'error',
          message: '请输入复议成绩',
        })
        return
      }
      let _this = this
      let resultFlow = []
      if (_this.countHasError) {
        _this.$message({
          type: 'error',
          message: _this.errorMsg === '' ? '请将打分项填写完整' : _this.errorMsg,
        })
      } else {
        this.submitZJYScore()
      }
    },
    // 分数提交（我的质检任务/初检or复检提交成绩）
    submitAllScore() {
      if (this.countHasError || this.errorMsg) {
        this.$message({
          type: 'error',
          message: this.errorMsg || '请将打分项填写完整',
        })
        return
      } else {
        let optionCheck = false
        let _this = this
        let result = []
        if (optionCheck) {
          _this.$message({
            type: 'error',
            message: _this.errorMsg || '请将打分项填写完整',
          })
          return false
        }
        this.currentDistribute.forEach(function(temp, index) {
          if (_this.qaScoreType == 1) {
            if (temp.defaultScore !== undefined) {
              _this.isScoreNull(temp.defaultScore)
              temp.defaultScore = temp.defaultScore + ''
              if (temp.judge == 7) {
                temp.optioniItem = temp.defaultScore.trim()
                return
              } else if (temp.judge == 8) {
                temp.optioniItem = temp.defaultScore.trim()
              }
              temp.score = temp.defaultScore.trim()
            } else {
              if (temp.judge == 7) {
                temp.optioniItem = temp.defaultScore
                return
              } else if (temp.judge == 8) {
                temp.optioniItem = temp.defaultScore.trim()
              }
              temp.score = temp.defaultScore
            }
          } else if (_this.qaScoreType == 2) {
            if (temp.secondQaScore !== undefined) {
              _this.isScoreNull(temp.secondQaScore)
              temp.secondQaScore = temp.secondQaScore + ''
              if (temp.judge == 7) {
                temp.optioniItem = temp.secondQaScore.trim()
                return
              } else if (temp.judge == 8) {
                temp.optioniItem = temp.secondQaScore.trim()
              }
              temp.score = temp.secondQaScore.trim()
            } else {
              if (temp.judge == 7) {
                temp.optioniItem = temp.secondQaScore
                return
              } else if (temp.judge == 8) {
                temp.optioniItem = temp.secondQaScore.trim()
              }
              temp.score = temp.secondQaScore
            }
          } else {
            if (temp.threeScore !== undefined) {
              _this.isScoreNull(temp.threeScore)
              temp.threeScore = temp.threeScore + ''
              if (temp.judge == 7) {
                temp.optioniItem = temp.threeScore.trim()
                return
              } else if (temp.judge == 8) {
                temp.optioniItem = temp.threeScore.trim()
              }
              temp.score = temp.threeScore.trim()
            } else {
              if (temp.judge == 7) {
                temp.optioniItem = temp.threeScore
                return
              } else if (temp.judge == 8) {
                temp.optioniItem = temp.threeScore.trim()
              }
              temp.score = temp.threeScore
            }
          }
        })
        result = result.concat(_this.currentDistribute)
        let resultFlow = []
        if (_this.flowValue.length > 0) {
          console.info('44444444444444444')
          _this.flowListScoreObjs.forEach(function(temp, index) {
            let obj = {}
            if (_this.qaScoreType == 1) {
              if (typeof temp.firstScore !== 'undefined') {
                _this.isScoreFlowNull(temp.firstScore, temp.scoreMin, temp.scoreMax)
                temp.firstScore = temp.firstScore + ''
                obj.score = temp.firstScore.trim()
              } else {
                temp.firstScore = ''
                obj.score = temp.firstScore
                _this.isScoreFlowNull(temp.firstScore, temp.scoreMin, temp.scoreMax)
              }
              obj.processId = temp.processId
              obj.distinctSingle = temp.distinctSingle
              obj.intentId = temp.intentId
              obj.intentName = temp.intentName
              obj.intentRule = temp.intentRule
              obj.processName = temp.processName
            } else if (_this.qaScoreType == 2) {
              if (typeof temp.secondScore !== 'undefined') {
                _this.isScoreFlowNull(temp.secondScore, temp.scoreMin, temp.scoreMax)
                temp.secondScore = temp.secondScore + ''
                obj.score = temp.secondScore.trim()
              } else {
                temp.secondScore = ''
                obj.score = temp.secondScore
                _this.isScoreFlowNull(temp.secondScore, temp.scoreMin, temp.scoreMax)
              }
              obj.distinctSingle = temp.distinctSingle
              obj.processId = temp.processId
              obj.intentId = temp.intentId
              obj.intentName = temp.intentName
              obj.intentRule = temp.intentRule
              obj.processName = temp.processName
            } else {
              if (typeof temp.thirdScore !== 'undefined') {
                _this.isScoreFlowNull(temp.thirdScore, temp.scoreMin, temp.scoreMax)
                temp.thirdScore = temp.thirdScore + ''
                obj.score = temp.thirdScore.trim()
              } else {
                temp.thirdScore = ''
                obj.score = temp.thirdScore
                _this.isScoreFlowNull(temp.thirdScore, temp.scoreMin, temp.scoreMax)
              }
              obj.distinctSingle = temp.distinctSingle
              obj.processId = temp.processId
              obj.intentId = temp.intentId
              obj.intentName = temp.intentName
              obj.intentRule = temp.intentRule
              obj.processName = temp.processName
            }
            resultFlow.push(obj)
          })
        }
        if (this.countHasError) {
          this.$message({
            type: 'error',
            message: this.errorMsg || '请将打分项填写完整',
          })
          return false
        }
        const promise = this.submitScore(result) // 1.提交模板分数
        if (_this.flowValue.length > 0) {
          promise.then(() => this.submitFlowScore(resultFlow)) // 2.提交流程评分分数
        }
      }
    },
    // 质检员 复议成绩提交分数
    submitZJYScore() {
      let _this = this
      let url = global.qualityUrl + '/qaDetail/completeRECallScoreByzjy.do'
      let params = {
        FuyiTask_EndTime: formatdate.formatDate(this.FuyiTask_EndTime),
        taskId: this.taskId,
        assignType: this.recordingPlayPage.assignType,
        ResponseScore: this.reTaskModel.responseScore,
        ResponseResult: this.reTaskModel.responseResult,
        ResponseContent: this.reTaskModel.responseContent,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '打分成功',
            })
            // 复议完成后，要把isQaScore重新赋值
            let temobj = {
              isQaScore: true,
            }
            _this.$store.commit('setRecordingPlayPage', temobj)
            _this.getConditonScore(_this.obj)
            _this.scored = true
          } else {
            _this.$message({
              type: 'error',
              message: '打分失败',
            })
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数提交失败',
          })
        })
    },
    // 质检员 初检复检提交分数
    submitScore(result) {
      let _this = this
      let url = global.qualityUrl + '/qaDetail/completeCallScore.do'
      let params = {}
      let deadItem
      if (this.isDead == '2' && this.isAutoDead == '2') {
        deadItem = '2'
      } else {
        deadItem = '1'
      }
      params.jsonStr = JSON.stringify(result)
      params.modelId = this.modelId
      params.taskId = this.taskId
      params.qaScoreType = this.qaScoreType
      params.score = this.totalScoreFun
      params.objectId = this.esResultModel.callId
      params.comments = this.handleContent // 处理内容
      params.qaedUser = this.esResultModel.seatNo
      params.deadItem = deadItem
      params.note = this.reTaskReasonModel.note

      return this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.scored = true
            _this.getConditonScore(_this.obj)
            _this.$message({
              type: 'success',
              message: '打分成功',
            })
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数提交失败',
          })
        })
    },
    // 流程打分提交
    submitFlowScore(result) {
      let _this = this
      if (_this.countHasError) {
        _this.$message({
          type: 'error',
          message: _this.errorMsg === '' ? '请将打分项填写完整' : _this.errorMsg,
        })
      } else {
        let params = {
          scoreType: _this.qaScoreType,
          callId: _this.callId,
          jsonStr: JSON.stringify(result),
        }
        _this.axios
          .post(global.qualityUrl + '/process/addProcessForRecord', qs.stringify(params))
          .then(function(response) {
            if (response.data.flag) {
              _this.$message({
                type: 'success',
                message: '流程打分成功',
              })
              _this.scored = true
              _this.getFlowIds()
            } else {
              return Promise.reject()
            }
          })
          .catch(function(error) {
            console.log(error)
            _this.$message({
              type: 'error',
              message: '分数提交失败',
            })
          })
      }
    },
    // 判断分数是否为空
    isScoreNull(val) {
      val = val + ''
      val = val.trim()
      if (val === null || val === '' || val === undefined) {
        this.countHasError = true
      }
    },
    isScoreFlowNull(val, min, max) {
      if (min == 0 && max == 0) {
        this.countHasError = false
      } else {
        val = val + ''
        val = val.trim()
        if (val === null || val === '') {
          this.countHasError = true
        }
      }
    },
    // 获取录音信息
    getPlayInfo() {
      // 将播放器重置为录音播放器
      let _this = this
      let url = qualityUrl + '/speechFeature/getPlayInfo.do'
      let params = {}
      params.callId = this.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.serviceLabels = response.data.serviceLabels
            _this.customInfoModel = response.data.customerLabels
            _this.playInfoVosList = response.data.playInfoVosList
            _this.judgePlayInfoList(_this.playInfoVosList)
            _this.insertSort(_this.playInfoVosList)
            // 过滤出上下文质检与内容质检的数据 初检和复检不展示
            _this.filterContentData()
            _this.times = []
            _this.playInfoVosList.forEach(function(item) {
              _this.times.push(item.startTime)
              _this.times.push(item.endTime)
            })
            _this.$store.commit('setVoiceDetal', _this.playInfoVosList)
            _this.voiceTotalTime = response.data.voiceTotalTime
            _this.esResultModel = response.data.esResultModel
            _this.aclOperVo = response.data.aclOperVo
            _this.minSpeed = response.data.minSpeead
            _this.maxSpeed = response.data.maxSpeed
            let playInfo = {}
            playInfo.voiceTotalTime = _this.voiceTotalTime
            _this.$nextTick(function() {
              _this.$store.commit('setPlayerInfo', playInfo)
            })
          } else {
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '录音信息获取失败',
          })
        })
    },
    // 录音修改文本 设置toolTip
    playShowToolTip(e, item) {
      var target = e.currentTarget
      if (target) {
        if (!item.originalText) {
          return
        }
        if (item.text.replace(/<[^>]+>/g, '').trim() == item.originalText.trim()) {
          if (item.needCorrect && item.correctText) {
            if (item.text.replace(/<[^>]+>/g, '').trim() !== item.correctText) {
              this.isShowPlayInfoTooltip = false
            } else {
              this.isShowPlayInfoTooltip = true
            }
          } else {
            this.isShowPlayInfoTooltip = true
          }
        } else {
          this.isShowPlayInfoTooltip = false
        }
      } else {
        this.isShowPlayInfoTooltip = true
      }
    },
    // 提交修改文本
    submitPlayInfoList(val) {
      // isEditPlayInfoList===true 修改文本
      // isEditPlayInfoList===false 保存
      if (val == '1') {
        // 点击文本修改
        this.isEditPlayInfoList = !this.isEditPlayInfoList
      } else {
        let newVoiceList = this.playInfoVosList.filter((item) => {
          return item.role != 'UNK'
        })
        for (var i = 0; i < newVoiceList.length; i++) {
          let item = newVoiceList[i]
          item.text = item.changeText
        }
        // 点击保存
        let jsonStr = JSON.stringify(newVoiceList)
        let params = {
          callId: this.callId,
          json: jsonStr,
        }
        this.axios
          .post(qualityUrl + '/speechFeature/updateContent.do', qs.stringify(params))
          .then((res) => {
            if (res.data) {
              this.isEditPlayInfoList = true
              this.getPlayInfo()
            } else {
              this.$message.error('提交失败')
            }
          })
          .catch((err) => console.log(err))
      }
    },
    // 判断文本是否修改
    judgePlayInfoList(data) {
      let _this = this
      for (var i = 0; i < data.length; i++) {
        let item = data[i]
        if (item.role == 'UNK' || !item.originalText) {
          return
        }
        _this.$set(item, 'changeText', item.text)
        if (item.text.trim() == item.originalText.trim()) {
          if (item.needCorrect && item.correctText) {
            if (item.text.trim() !== item.correctText) {
              _this.$set(item, 'changeText', item.correctText)
              item.text =
                '<span style="text-decoration:underline">' + item.correctText + '</span>'
            }
          }
        } else {
          item.text = '<span style="text-decoration:underline">' + item.text + '</span>'
        }
      }
    },
    filterContentData() {
      // 过滤上下文质检关键字
      const conTextList = []
        .concat(...Object.values(this.standardsListWithAutoScoreQa))
        .filter((item) => item.judge == 12)
        .map((item) => {
          return (
            item.resultsObject[0].firstContext + ' ' + item.resultsObject[0].secondContext
          )
        })
      let keyWordContent = conTextList.length == 0 ? [] : conTextList.join(' ').split(' ')
      // 过滤内容质检话术关键词
      console.log(this.scoreDetails)
      const contextObject = [].concat(
        ...this.scoreDetails.map((flag) => {
          return flag.matchDialogs ? flag.matchDialogs : []
        })
      )
      keyWordContent = [...contextObject, ...keyWordContent]
      console.log(keyWordContent)
      this.setPlayInfoList(this.playInfoVosList, keyWordContent)
    },
    setPlayInfoList(data, keyWordContent) {
      for (let i = 0; i < data.length; i++) {
        let item = data[i]
        if (keyWordContent && keyWordContent.length > 0) {
          for (let y = 0; y < keyWordContent.length; y++) {
            item.text = item.text.replace(
              keyWordContent[y].replace(/[(|)]/g, ''),
              `<font style=color:#409eff;>${keyWordContent[y].replace(
                /[(|)]/g,
                ''
              )}</font>`
            )
          }
        }
      }
    },
    isShowSpeedFlag(speed) {
      if (speed == '') {
        return false
      } else {
        if (speed > this.maxSpeed || speed < this.minSpeed) {
          return true
        } else {
          return false
        }
      }
    },
    // 对话列表的class
    classes(role, startTime, endTime) {
      let active = ''
      if (+this.currentClass === +startTime || +this.currentClass === +endTime) {
        active = 'currentClass'
      }
      if (role == 2) {
        return 'custom_content _' + startTime + ' _' + endTime + ' ' + active
      } else if (role == 1) {
        return 'agent_content _' + startTime + ' _' + endTime + ' ' + active
      } else {
        return 'UNK _' + startTime
      }
    },
    // 调整滚动条位置， scrollTop = offsetTop + 偏移
    scrollDialog(seconds) {
      let liClass = '._' + seconds
      let ele = document.querySelector(liClass)
      if (ele) {
        let offsetTop = ele.offsetTop
        if (offsetTop < 20) {
          // dialog有10pxpadding
          document.querySelector('.dialog').scrollTop = 0
        } else {
          // document.querySelector('.dialog').scrollTop = offsetTop + 20
          $('.dialog').animate(
            {
              scrollTop: offsetTop - document.querySelector('.dialog').clientHeight / 3,
            },
            500
          )
        }
      }
    },
    // 查找距离当前时间最近的对话内容所在的区域的class， 二分查找
    findCurrentMessage(seconds) {
      if (this.times.indexOf(seconds) != -1) {
        console.log(seconds)
        return seconds
      } else if (seconds < this.times[0]) {
        return this.times[0]
      } else if (seconds > this.times[this.times.length - 1]) {
        return this.times[this.times.length - 1]
      } else {
        let low = 0
        let high = this.times.length - 1
        let closeData = ''
        let diff = 0
        while (low <= high) {
          let mid = parseInt((high + low) / 2)
          if (seconds > this.times[mid]) {
            low = mid + 1
            if (diff == 0) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            } else if (Math.abs(this.times[mid] - seconds) < Math.abs(diff)) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            }
          } else if (seconds < this.times[mid]) {
            high = mid - 1
            if (diff == 0) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            } else if (Math.abs(this.times[mid] - seconds) < Math.abs(diff)) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            }
          } else {
            return this.times[mid]
          }
        }
        return closeData
      }
    },
    // 插入排序
    insertSort(arr) {
      if (Object.prototype.toString.call(arr) !== '[object Array]') {
        return false
      }
      for (let i = 1; i < arr.length; i++) {
        let j = i
        let temp = arr[i]
        while (j > 0 && parseInt(temp.startTime) < parseInt(arr[j - 1].startTime)) {
          arr[j] = arr[--j]
        }
        arr[j] = temp
      }
    },
    // 添加案例
    addCase_btn() {
      this.getTreeData()
      this.showAddCaseDialog = true
      this.resetForm('AddCaseModel')
    },
    // 关闭添加案例弹出层
    handleCloseAddCaseDialog() {
      this.showAddCaseDialog = false
    },
    // 判断是否重复添加案例
    hasSameCaseThrottle() {
      this.lodashThrottle.throttle(this.hasSameCase, this)
    },
    // 添加案例
    addCase() {
      let _this = this
      this.$refs.AddCaseModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let url = qualityUrl + '/qaDetail/colCase.do'
          let params = {
            objectId: _this.callId,
            apReaSon: _this.AddCaseModel.addCaseReason,
            casClassId: _this.AddCaseModel.dataType,
          }
          if (_this.AddCaseModel.addCaseReason.length > 255) {
            _this.$message({
              type: 'error',
              message: '请填写小于255字符的理由',
            })
            return
          }
          this.axios
            .post(url, qs.stringify(params))
            .then(function(response) {
              if (response.data.status == 'success') {
                _this.$message({
                  type: 'success',
                  message: response.data.data,
                })
                _this.showAddCaseDialog = false
              } else {
                _this.$message({
                  type: 'error',
                  message: response.data.data,
                })
                return Promise.reject()
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        }
      })
    },
    // 添加案例 添加按钮
    hasSameCase() {
      let _this = this
      let url = qualityUrl + '/qaDetail/hasSameCase.do'
      let params = {
        objectId: this.callId,
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.status !== 'success') {
            _this.addCase()
          } else {
            _this.$message({
              type: 'success',
              message: response.data.data,
            })
            _this.showAddCaseDialog = false
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '检查是否重复添加失败',
          })
        })
    },
    // 获取权限按钮
    getFuncId: function() {
      this.axios
        .post(global.hrmApi + '/accountApi/accessible/getFuncIdByAccountId.do')
        .then((res) => {
          for (let i = 0; i < res.data.length; i++) {
            if (res.data[i] == 'alca11') {
              this.isShowedit = true
            }
            if (res.data[i] == 'alca00') {
              this.isShowplus = true
            }
            if (res.data[i] == 'alca22') {
              this.isShowclose = true
            }
            // 删除
            if (res.data[i] == 'alca33') {
              this.isShowdelete = true
            }
            // 编辑
            if (res.data[i] == 'alca44') {
              this.isShoweditCase = true
            }
            // 查看
            if (res.data[i] == 'alca55') {
              this.isShowLook = true
            }
            // 批量删除
            if (res.data[i] == 'alca66') {
              this.isShowdelby = true
            }
            // 通过
            if (res.data[i] == 'alca77') {
              this.isShowadopt = true
            }
            // 拒绝
            if (res.data[i] == 'alca88') {
              this.isShowrefuse = true
            }
          }
        })
    },
    // 重置表单
    resetForm(name) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[name].resetFields()
      })
    },
  },
  watch: {
    currentTime(val) {
      this.currentClass = this.findCurrentMessage(val - 250)
      this.scrollDialog(this.currentClass)
    },
  },
  filters: {
    dealSpeed(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return '过慢'
      } else if (val > maxSpeed) {
        return '过快'
      }
    },
    dealSpeedType(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return 'danger'
      } else if (val > maxSpeed) {
        return 'primary'
      }
    },
    timeFormat(val) {
      if (val === '' || !val) {
        return ''
      }
      return moment(val).format('YYYY-MM-DD HH:mm:ss')
    },
    timeFormatMD(val) {
      if (val === '' || !val) {
        return ''
      }
      let date = moment(val)
        .format('YYYY-MM-DD HH:mm:ss')
        .substring(5, 10)
      let m = date.substring(0, 2)
      if (m.substring(0, 1) == 0) {
        m = m.substring(1, 2)
      } else {
        m = m.substring(0, 2)
      }
      let d = date.substring(3, 5)
      if (d.substring(0, 1) == 0) {
        d = d.substring(1, 2)
      } else {
        d = d.substring(0, 2)
      }
      return m + '-' + d
    },
  },
}
</script>
<style lang="less">
@borderColor: #c3ccd9;
@playerHeight: 50px;
@infoHeight: 220px;
@controlBtnsHeight: 40px;
.recordingPlayContainer {
  width: 100%;
  height: 100%;
  position: relative;
  & > .controller_btns {
    position: absolute;
    width: 100px;
    line-height: 40px;
    top: 0px;
    right: 0px;
    z-index: 999;
    text-align: right;
    padding-right: 10px;
    .controller_btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      line-height: 24px;
      border-radius: 50%;
      margin-left: 5px;
      text-align: center;
      background: #c3ccd9;
      color: #fff;
      &:hover {
        cursor: pointer;
      }
    }
  }
  & > .el-row {
    height: 100%;
    border-top: 1px solid @borderColor;
    & > .el-col {
      height: 100%;
      position: relative;
    }
  }
  // 修改tab组件样式
  .el-tabs__item.is-active {
    color: #1f2d3d !important;
    font-size: 14px;
    font-weight: bold;
  }
  .el-tabs--border-card {
    border: none;
    height: 100%;
    position: relative;
    & > div {
      border: none;
    }
    & > .el-tabs__header {
    }
    & > .el-tabs__content {
      position: absolute;
      top: 40px;
      left: 0;
      right: 0;
      bottom: 0;
      overflow-y: auto;
      & > .el-tab-pane {
        height: 100%;
      }
    }
    & > .el-tabs__header .el-tabs__item {
      border: none;
    }
  }

  // 修改tab组件样式结束
  .leftContainer,
  .rightContainer {
    position: absolute;
    right: 0;
    left: 0;
    top: 0;
    bottom: 0;
  }
  .leftContainer {
    .info-base {
      height: 100%;
      overflow-y: auto;
      .infoContent {
        height: auto;
        float: left;
        width: 100%;
        border-bottom: 1px solid #e4e4e4;
        padding: 20px 0;
        box-sizing: border-box;
        &.infoContent-kehuInfo {
          border: none;
          .tagWrap {
            position: absolute;
            left: 10px;
            bottom: 10px;
            right: 120px;
            .el-tag {
              margin-right: 10px;
              margin-bottom: 10px;
            }
          }
          .btnWrap {
            position: absolute;
            right: 10px;
            bottom: 10px;
          }
        }
        .borderLeft {
          width: 100%;
          height: 30px;
          line-height: 30px;
          overflow: hidden;
          color: #8691a5;
          .borderBlue {
            margin-left: 10px;
            display: inline-block;
            color: #1791ec;
            text-align: center;
            line-height: 8px;
            border-radius: 2px;
            border: 1px solid #9ed9f3;
            padding: 4px 10px;
            color: #1791ec;
            height: 10px;
            background: #d7eeff;
            font-size: 12px;
          }
          .borderGreen {
            margin-left: 10px;
            display: inline-block;
            color: #1791ec;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #6bdec4;
            padding: 4px 10px;
            color: #12a080;
            height: 12px;
            background: #caf7ed;
            font-size: 12px;
          }
        }
        .borderRight {
          width: 50%;
          color: #8691a5;
          display: inline-block;
          height: 30px;
          line-height: 30px;
          .borderPositive {
            display: inline-block;
            font-size: 12px;
            color: #12a080;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #12a037;
            padding: 4px 10px;
            height: 12px;
            padding: 4px 10px;
            color: #12a037;
          }
          .borderNegative {
            display: inline-block;
            font-size: 12px;
            margin-right: 10px;
            color: #12a080;
            text-align: center;
            line-height: 12px;
            border-radius: 4px;
            border: 1px solid #ff0000;
            padding: 4px 10px;
            height: 12px;
            padding: 4px 10px;
            color: #ff0000;
          }
        }
        .info_item {
          min-width: 50%;
          float: left;
          line-height: 30px;
          color: #8691a5;
          font-size: 14px;
          .el-rate {
            display: inline-block;
            margin-left: 5px;
            vertical-align: middle;
          }
          span.el-tag {
            margin-right: 2px;
          }
          &.agentLabel {
            width: 100%;
            .el-tag {
              margin-right: 5px;
            }
          }
        }
      }
    }
    .info {
      height: @infoHeight;
      position: relative;
      .submit-playinfo-list {
        position: absolute;
        right: 10px;
        bottom: 3px;
        height: 30px;
        padding: 7px 10px;
      }
      .infoContent {
        height: 100%;
        .info_item {
          min-width: 50%;
          float: left;
          line-height: 30px;
          color: #8691a5;
          font-size: 14px;
          .el-rate {
            display: inline-block;
            margin-left: 5px;
            vertical-align: middle;
          }
          span.el-tag {
            margin-right: 2px;
          }
          &.agentLabel {
            width: 100%;
            .el-tag {
              margin-right: 5px;
            }
          }
        }
      }
    }
    .dialog {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      top: @infoHeight;
      overflow-y: auto;
      padding: 10px;
      background: #eef1f6;
      & > ul {
        position: relative;
        & > li {
          overflow: hidden;
          margin: 10px 0px;
          .avatar {
            width: 46px;
            height: 46px;
            line-height: 46px;
            border-radius: 23px;
            border: 1px solid @borderColor;
            text-align: center;
            background: #fff;
          }
          .dialog-content {
            background: #fff;
            padding: 10px 15px;
            line-height: 20px;
            border-radius: 5px;
            margin-left: 15px;
            position: relative;
            max-width: 280px;
            margin-top: 5px;
            cursor: pointer;
          }
          .content-tag {
            margin-top: 15px;
          }
          &.custom_content {
            div {
              float: left;
            }
            .dialog-content {
              background: #fff;
              &::before {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #fff;
                position: absolute;
                top: 10px;
                left: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.agent_content {
            div {
              float: right;
            }
            .dialog-content {
              margin-left: 10px;
              margin-right: 15px;
              background: #9eea6a;
              color: #000000;
              &::after {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #9eea6a;
                position: absolute;
                top: 10px;
                right: -6px;
                transform: rotate(45deg);
              }
            }
          }
          // 当前正在播放的对话内容样式
          &.currentClass {
            .dialog-content {
              background: #22b8fe;
              color: #000000;
              &::after {
                background: #22b8fe;
              }
              &::before {
                background: #22b8fe;
              }
            }
          }
          &.UNK {
            div {
              text-align: center;
              display: block;
              color: #97a8be;
            }
            div.line {
              width: 100%;
              height: 15px;
              background: url('../../../assets/img/unk.png') no-repeat;
              background-position: center;
            }
          }
        }
      }
    }
  }
  .rightContainer {
    .lable {
      height: 42px;
      line-height: 42px;
      width: 100%;
      padding-left: 20px;
      box-sizing: border-box;
      font-size: 14px;
      color: #1f2d3d;
      font-weight: bold;
    }
    .process_s {
      height: 36px;
      line-height: 36px;
      background: #eff2f7;
      padding: 0 20px;
      box-sizing: border-box;
      .process-wrap {
        display: inline-block;
        margin-right: 22px;
        position: relative;
        .process {
          color: #1f2d3d;
          font-size: 12px;
        }
      }
    }
    .infoForm {
      height: 100%;
      .detailInfoContents_part {
        border-bottom: 1px dashed @borderColor;
        .detailInfoContentsInputs {
          padding: 10px;
          .el-form-item > label {
            font-size: 14px;
            color: #8691a5;
          }
        }
        h3 {
          padding-left: 10px;
          line-height: 30px;
          font-size: 14px;
          color: #9dadc2;
          font-weight: normal;
        }
      }
    }
    .el-date-editor.el-input {
      width: 100%;
    }
    .el-select {
      width: 100%;
    }
    .operation {
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      padding: 0px 10px 0px 0px;
      border-bottom: 1px dashed @borderColor;
      position: absolute;
      top: 0px;
      left: 10px;
      right: 10px;
      h3 {
        width: 65px;
        float: left;
        font-size: 14px;
        color: #5e6d82;
        font-weight: normal;
      }
    }
    .btns {
      float: right;
      button {
        width: 90px;
      }
      margin-right: 10px;
    }
    .standards_parts.recordingPlayMultiple {
      position: absolute;
      top: 80px;
      right: 0px;
      left: 0px;
      bottom: 0px;
      overflow-y: auto;
      .standards_part {
        position: relative;
        margin-left: 20px;
        h3 {
          line-height: 30px;
          font-size: 14px;
          color: #1f2d3d;
          font-weight: normal;
        }
        .label {
          height: 42px;
          line-height: 42px;
          width: 100%;
          -webkit-box-sizing: border-box;
          box-sizing: border-box;
          font-size: 14px;
          color: #1f2d3d;
          font-weight: bold;
        }
        .coll {
          padding: 0 10px;
        }
        .standards_detail {
          padding: 10px;
          padding-left: 0;
          .classification_part {
            h3 {
              line-height: 30px;
              font-size: 14px;
              color: #9dadc2;
              font-weight: normal;
            }
            .classification_detail {
              padding: 10px 0;
              .el-form-item > label {
                font-size: 14px;
                color: #8691a5;
              }
            }
          }
          .normalNameClass {
            line-height: 30px;
            color: #9dadc2;
            font-size: 14px;
          }
          .hightlightContent_span {
            cursor: pointer;
            color: red;
          }
        }
        &.noBorder {
          border-bottom: none;
          & > p {
            font-size: 14px;
            margin-bottom: 10px;
          }
        }
        .btns {
          margin: 10px;
        }
      }
      .standards_part_title {
        position: relative;
        line-height: 30px;
        font-size: 14px;
        color: #1f2d3d;
        font-weight: normal;
        h2,
        h3 {
          display: inline-block;
        }
        .h2 {
          font-weight: bold;
          font-size: 13px;
          color: #1f2d3d;
          line-height: 17px;
        }
        .score {
          display: inline-block;
          float: right;
          label {
            display: inline-block;
            width: 35px;
            font-size: 13px;
            color: #1f2d3d;
            line-height: 17px;
          }
          span {
            display: inline-block;
            width: 35px;
            font-size: 13px;
            color: #1f2d3d;
            line-height: 17px;
          }
          .score_result {
            width: 35px;
            font-size: 13px;
            color: #20a0ff;
            line-height: 17px;
          }
        }
      }
      .selectInspector {
        width: 120px;
        line-height: 30px;
        position: absolute;
        right: 145px;
        top: 6px;
      }
      &.screening {
        top: 10px;
      }
      &.appealScore {
        h3 {
          color: #9dadc2;
        }
        label {
          color: #8691a5;
        }
      }
    }
  }
  .btns {
    text-align: right;
    button {
      width: 90px;
    }
  }
  .contentLeft,
  .contentRight {
    border: 1px solid @borderColor;
  }
  .el-dialog__body {
    padding-top: 10px;
    .footer {
      margin-top: 10px;
    }
  }
  .dialogTitle {
    color: #8691a5;
    font-size: 14px;
    font-weight: normal;
    box-sizing: border-box;
    height: 50px;
    line-height: 50px;
    padding: 0px 10px;
    border-bottom: 1px dotted @borderColor;
    .btns button {
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      padding: 0px;
    }
  }
  .hidden {
    display: none;
  }
}

.rightContainer {
  .showDialogHeader {
    .el-dialog__header {
      display: block !important;
    }
  }
  .shareReason {
    padding: 10px;
    height: 300px;
    width: 90%;
    overflow-y: auto;
    .el-tree.filter-tree {
      border: none;
    }
  }
  .dialogTitle {
    color: #8691a5;
    font-size: 14px;
    font-weight: normal;
    box-sizing: border-box;
    height: 50px;
    line-height: 50px;
    padding: 0px 10px;
    border-bottom: 1px dotted @borderColor;
    .btns button {
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      padding: 0px;
    }
  }
  .contentLeft,
  .contentRight {
    border: 1px solid @borderColor;
  }
  .el-input.w-123 {
    width: 123px;
  }
  .suffix-semicolon:after {
    content: ';';
  }
  .rightContainer {
    .el-collapse-item__header {
      font-size: 12px;
      font-weight: normal;
      color: #1f2d3d;
    }
    .el-collapse-item__content {
      background-color: #f8f9fb;
      padding: 10px;
      color: #606266;
      font-size: 12px;
    }
  }
}
</style>
