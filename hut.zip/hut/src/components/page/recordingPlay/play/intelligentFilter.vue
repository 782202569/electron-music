<template>
  <div class="standards_parts screening">
    <div class="standards_part noBorder">
      <div class="normalTitle">
        <h2>模板名称：{{ this.scriptName }}</h2>
      </div>
      <h3>
        智能筛选关键字
      </h3>
      <div class="standards_detail">
        <el-table
          ref="standardsListTable"
          :data="keywords"
          border
          tooltip-effect="dark"
          style=""
        >
          <el-table-column
            prop="keywordContext"
            label="关键词内容"
            width="150"
          ></el-table-column>
          <el-table-column prop="type" label="筛选类型" width="150">
            <template scope="scope">
              <span v-if="scope.row.type == 1">关键词</span>
              <span v-if="scope.row.type == 2">静默关键词</span>
              <span v-if="scope.row.type == null">关键词</span>
            </template>
          </el-table-column>
          <el-table-column label="备注" prop="note" width="100"></el-table-column>
          <el-table-column
            prop="fullScriptRole"
            label="角色"
            :formatter="convertRole"
            width="100"
          ></el-table-column>
          <el-table-column prop="targetContent" label="命中场景">
            <template scope="scope">
              <span
                class="playClip_btn"
                v-for="(itemT, index) in scope.row.targetContent"
                @click="playOccurrence_intelligent(itemT)"
              >
                {{ itemT.keyword }}
              </span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="standards_part noBorder">
        <p>{{ scriptSilenceInfo }}</p>
        <p>
          <label>平均语速：</label>
          <span>{{ scriptAvgSpeedInfo }}</span>
        </p>
        <p>
          <label>重叠次数：</label>
          <span>{{ scriptOverlapInfo }}</span>
        </p>
      </div>
    </div>
  </div>
</template>
<script>
import global from '../../../../global.js'
let currentBaseUrl = global.currentBaseUrl
import Qs from 'qs'
export default {
  props: ['parentModel'],
  data() {
    return {
      keywords: [],
      speechFeatureStrs: [],
      filterScript: {},
      scriptName: '',
      playInfoVosList: [], // 通话内容列表
    }
  },
  methods: {
    getScriptKeyName() {
      let _this = this
      let params = {}
      params.projectId = _this.parentModel.projectId
      params.pageNumber = 1
      params.pageSize = 20
      _this.axios
        .post(currentBaseUrl + '/itFilter/queryProject.do', Qs.stringify(params))
        .then(function(res) {
          if (res.data) {
            let paramsScript = {}
            paramsScript.scriptId = res.data.results[0].scriptId
            paramsScript.projectId = _this.parentModel.projectId
            paramsScript.taskId = _this.parentModel.taskId
            paramsScript.callId = _this.parentModel.callId
            let url = currentBaseUrl + '/itFilter/findByFullByScriptIdAndupdateTime.do'
            _this.axios.post(url, Qs.stringify(paramsScript)).then(function(res) {
              if (res.data) {
                _this.filterScript = res.data
                _this.scriptName = res.data.scriptName
              }
            })
          }
        })
    },
    getScriptKeywords() {
      let _this = this
      let params = {
        projectId: _this.parentModel.projectId,
        taskId: _this.parentModel.taskId,
        callId: _this.parentModel.callId,
      }
      let url = currentBaseUrl + '/speechFeature/getPlayInfo.do'
      let paramsRecord = {}
      paramsRecord.callId = _this.parentModel.callId
      _this.axios
        .post(url, Qs.stringify(paramsRecord))
        .then(function(res) {
          if (res.data) {
            _this.playInfoVosList = res.data.playInfoVosList
            _this.$store.commit('setVoiceDetal', _this.playInfoVosList)
            _this.axios
              .post(
                currentBaseUrl + '/itFilter/getFilterKeywords.do',
                Qs.stringify(params)
              )
              .then(function(response) {
                if (response.data) {
                  let key = response.data
                  let reg = /[A-Z()\s]+/
                  for (let i = 0; i < key.length; i++) {
                    if (key[i].targetTime) {
                      let targetTimeStart = key[i].targetTime.split(',')[0]
                      let targetTimeEnd = key[i].targetTime.split(',')[1]
                      key[i].targetTimeStart = targetTimeStart
                      key[i].targetTimeEnd = targetTimeEnd
                      for (let n = 0; n < _this.playInfoVosList.length; n++) {
                        if (
                          parseInt(_this.playInfoVosList[n].startTime) <=
                            parseInt(targetTimeEnd) &&
                          parseInt(_this.playInfoVosList[n].endTime) >=
                            parseInt(targetTimeStart)
                        ) {
                          key[i].Start = n
                          key[i].targetTimeStart = _this.playInfoVosList[n].startTime
                          break
                        }
                      }
                      for (let m = _this.playInfoVosList.length - 1; m >= 0; m--) {
                        if (
                          parseInt(_this.playInfoVosList[m].startTime) <=
                            parseInt(targetTimeEnd) &&
                          parseInt(_this.playInfoVosList[m].endTime) >=
                            parseInt(targetTimeStart)
                        ) {
                          key[i].End = m
                          key[i].targetTimeEnd = _this.playInfoVosList[m].endTime
                          break
                        }
                      }
                    } else {
                      key[i].Start = 0
                      key[i].End = _this.playInfoVosList.length - 1
                      key[i].targetTimeStart = '0'
                      key[i].targetTimeEnd = _this.playInfoVosList[key[i].End].endTime
                    }
                    let keywordContext = key[i].keywordContext
                    let result = keywordContext.replace(reg, ',')
                    while (result.match(reg)) {
                      result = result.replace(reg, ',')
                    }
                    keywordContext = result.trim().split(',')
                    let targetKeyword = []
                    // 单个关键词标准命中关键词数量
                    let o = 0
                    for (let l = 0; l < keywordContext.length; l++) {
                      if (keywordContext[l] != '') {
                        for (let j = key[i].Start; j <= key[i].End; j++) {
                          if (key[i].fullScriptRole === '1') {
                            if (
                              _this.playInfoVosList[j].role == '2' &&
                              _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >=
                                0
                            ) {
                              targetKeyword[o] = keywordContext[l]
                            }
                          } else if (key[i].fullScriptRole === '2') {
                            if (
                              _this.playInfoVosList[j].role == '1' &&
                              _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >=
                                0
                            ) {
                              targetKeyword[o] = keywordContext[l]
                            }
                          } else {
                            if (
                              _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >=
                              0
                            ) {
                              targetKeyword[o] = keywordContext[l]
                            }
                          }
                        }
                        o++
                      }
                    }
                    // 每个关键词的命中之后变成一个字符串
                    key[i].targetContent = []
                    targetKeyword.forEach((item) => {
                      key[i].targetContent.push({
                        keyword: item,
                        clickIndex: 0,
                        fullScriptRole: key[i].fullScriptRole,
                        targetTimeStart: key[i].targetTimeStart,
                        targetTimeEnd: key[i].targetTimeEnd,
                      })
                    })
                  }
                  // 把组装好的数据传给页面
                  _this.keywords = key
                  _this.$emit('highkeywords', _this.keywords)
                }
              })
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '录音信息获取失败',
          })
        })
    },
    convertRole(x, y, cellValue) {
      if (cellValue === '1') {
        return '客户'
      } else if (cellValue === '2') {
        return '客服'
      }
      return '全部'
    },
    playOccurrence_intelligent(keywordItem) {
      this.$emit('clickhighlightwords', keywordItem)
    },
    getRangeInfoStr(min, max) {
      let result = ''
      if (min != null) {
        result += min
      } else {
        result += '无下限'
      }
      result += '-'
      if (max != null) {
        result += max
      } else {
        result += '无上限'
      }
      return result
    },
  },
  computed: {
    scriptOverlapInfo() {
      if (
        this.filterScript['overlapMin'] == null &&
        this.filterScript['overlapMax'] == null
      ) {
        return '无重叠条件'
      }
      return this.getRangeInfoStr(
        this.filterScript['overlapMin'],
        this.filterScript['overlapMax']
      )
    },
    scriptAvgSpeedInfo() {
      if (
        this.filterScript['speedMin'] == null &&
        this.filterScript['speedMax'] == null
      ) {
        return '无语速条件'
      }
      return this.getRangeInfoStr(
        this.filterScript['speedMin'],
        this.filterScript['speedMax']
      )
    },
    scriptSilenceInfo() {
      if (this.filterScript['selienceType']) {
        let silenceType = this.filterScript['selienceType']
        if (silenceType == 1) {
          return (
            '静默时长：' +
            this.getRangeInfoStr(
              this.filterScript['selienceLengthMin'],
              this.filterScript['selienceLengthMax']
            )
          )
        }
        if (silenceType == 2) {
          return (
            '静默次数：' +
            this.getRangeInfoStr(
              this.filterScript['silenceTimeMin'],
              this.filterScript['silenceTimeMax']
            )
          )
        }
        if (silenceType == 3) {
          let ratioMin = this.filterScript['silenceRatioMin']
            ? this.filterScript['silenceRatioMin'] + '%'
            : null
          let ratioMax = this.filterScript['silenceRatioMax']
            ? this.filterScript['silenceRatioMax'] + '%'
            : null
          return '静默占比：' + this.getRangeInfoStr(ratioMin, ratioMax)
        }
      }
      return '无静默条件'
    },
  },
  mounted() {
    this.getScriptKeyName()
    this.getScriptKeywords()
  },
  watch: {
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.callId != undefined) {
          this.keywords = []
          this.filterScript = {}
          this.playInfoVosList = []
          this.getScriptKeywords()
          this.getScriptKeyName()
        }
      },
      deep: true,
    },
  },
}
</script>
<style lang="less" scoped>
.normalTitle {
  h2 {
    padding-left: 10px;
    line-height: 30px;
    font-size: 24px;
    color: #1f2d3d;
    font-weight: normal;
  }
}
.standards_parts {
  &.screening {
    .playClip_btn {
      cursor: pointer;
    }
  }
}
</style>
