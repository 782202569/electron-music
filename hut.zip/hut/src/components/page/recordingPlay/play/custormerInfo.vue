<template>
  <div class="infoForm">
    <el-form label-width="100px">
      <div class="detailInfoContents_part detailInfoContents">
        <h3>
          来电信息
        </h3>
        <div class="detailInfoContentsInputs">
          <el-row>
            <el-col :span="12">
              <el-form-item label="坐席工号" prop="silenceCount">
                <el-input v-model="esResultModel.seatNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="坐席姓名" prop="silenceCount">
                <el-input v-model="esResultModel.seatName" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="坐席星级" prop="seatStar">
                <el-select
                  v-model="esResultModel.seatStar"
                  placeholder="请选择"
                  :disabled="true"
                >
                  <el-option :value="1" label="一星"> </el-option>
                  <el-option :value="2" label="二星"> </el-option>
                  <el-option :value="3" label="三星"> </el-option>
                  <el-option :value="4" label="四星"> </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="录音号" prop="silenceCount">
                <el-input v-model="esResultModel.callId" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="开始时间" prop="callSTime">
                <el-date-picker
                  v-model="esResultModel.callSTime"
                  type="datetime"
                  :disabled="true"
                  placeholder="选择日期时间"
                >
                </el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="结束时间" prop="callETime">
                <el-date-picker
                  v-model="esResultModel.callETime"
                  type="datetime"
                  :disabled="true"
                  placeholder="选择日期时间"
                >
                </el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="通话时长" prop="transformTime">
                <el-input
                  :value="esResultModel.callTime / 1000 + '秒'"
                  :disabled="true"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="主叫号码" prop="callNo">
                <el-input v-model="esResultModel.callNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="被叫号码" prop="calledNo">
                <el-input v-model="esResultModel.calledNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12"> </el-col>
          </el-row>
        </div>
      </div>
      <div class="staffAttrs">
        <h3>
          客户信息
        </h3>
        <div class="detailInfoContentsInputs">
          <el-row>
            <el-col :span="12">
              <el-form-item label="客户姓名" prop="customerName">
                <el-input
                  v-model="esResultModel.customerName"
                  :disabled="true"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="账号" prop="customerNo">
                <el-input v-model="esResultModel.customerNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="证件信息" prop="certType">
                <el-select
                  v-model="esResultModel.certType"
                  placeholder="请选择"
                  :disabled="true"
                >
                  <el-option
                    v-for="item in certTypeList"
                    :key="item.key"
                    :label="item.value"
                    :value="item.key"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="证件号" prop="certNo">
                <el-input v-model="esResultModel.certNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-form-item label="客户标签">
              <el-tag
                :type="color[index % 4]"
                v-for="(item, index) in customInfoModel"
                :key="item"
                class="customLabel"
                >{{ item }}
              </el-tag>
              <el-tag v-if="!customInfoModel || customInfoModel.length === 0"
                >暂无标签</el-tag
              >
            </el-form-item>
          </el-row>
        </div>
      </div>
    </el-form>
  </div>
</template>
<script>
import global from '../../../../global.js'
let currentBaseUrl = global.currentBaseUrl
export default {
  props: ['parentModel', 'customInfoModel', 'esResultModel'], // 页面来的地方
  data() {
    return {
      customerLabels: [], // 客户标签
      color: ['success', 'warning', 'danger', 'gray'],
      certTypeList: [], // 证件类型列表
    }
  },
  watch: {
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.callId != undefined) {
          this.reSetData()
          this.getCertTypeList()
        }
      },
      deep: true,
    },
  },
  methods: {
    reSetData() {
      this.customerLabels = []
      this.certTypeList = []
    },
    getCertTypeList() {
      this.axios
        .post(currentBaseUrl + '/pageConstant/getStandByCode.do?dataCode=certType')
        .then((response) => {
          this.certTypeList = response.data
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('获取证据信息失败')
        })
    },
  },
  mounted() {
    this.getCertTypeList()
  },
}
</script>
