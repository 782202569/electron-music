<template>
  <div>
    <el-table :data="returnVisitMatchResults">
      <el-table-column prop="questionName" label="问题"></el-table-column>
      <el-table-column prop="isValidStr" label="是否匹配"></el-table-column>
      <el-table-column prop="answerOutPuts" label="答案"></el-table-column>
    </el-table>
  </div>
</template>

<script>
import global from '../../../../global.js'
import Qs from 'qs'

export default {
  data() {
    return {
      returnVisitMatchResults: [],
    }
  },
  props: ['parentModel'],
  methods: {
    getMatchResult() {
      let objectId = this.parentModel['returnVisitData']['objectId']
      let detailId = this.parentModel['returnVisitData']['detailId']
      let params = {
        objectId: objectId,
        detailId: detailId,
      }
      let url = global.currentBaseUrl + '/rvt/getMatchResults.do'
      this.axios
        .post(url, Qs.stringify(params))
        .then((response) => {
          this.returnVisitMatchResults = response['data']
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('查询回访话术匹配信息发生异常')
        })
    },
  },
  created() {
    console.log(this.parentModel)
    this.getMatchResult()
  },
  watch: {
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.callId != undefined) {
          this.getMatchResult()
        }
      },
      deep: true,
    },
  },
}
</script>

<style lang="less"></style>
