<template>
  <div>
    <div class="standards_part">
      <h2>评分模板：{{ modleTitle }}</h2>
      <h3>
        自动评分标准
      </h3>
      <div class="score">
        <label>自动质检得分</label>
        <span>{{ showAutoScore }}</span>
      </div>
      <div class="standards_detail">
        <div v-for="(standardsList, key) in standardsLists" :key="key">
          <div class="normalNameClass">{{ key }}</div>
          <el-table
            ref="standardsListTable"
            :data="standardsList"
            border
            tooltip-effect="dark"
            style=""
          >
            <el-table-column prop="normalName" label="质检标准"> </el-table-column>
            <el-table-column label="内容">
              <template scope="scope">
                <div v-if="scope.row.judge === 5">
                  <p v-if="scope.row.resultsObject !== null">
                    <span
                      v-for="(item,
                      index) in scope.row.resultsObject.keywordContext.split(' OR ')"
                      :key="index"
                    >
                      <span
                        class="hightlightContent_span"
                        @click="hightlightContent(item)"
                        >{{ item }}
                      </span>
                      <span
                        v-if="
                          index <
                            scope.row.resultsObject.keywordContext.split(' OR ').length -
                              1
                        "
                        >&nbsp;OR&nbsp;</span
                      >
                    </span>
                    <el-popover placement="right" width="120" trigger="hover">
                      <template
                        v-if="scope.row.resultsObject.deadItem == '1'"
                        slot="reference"
                      >
                        <i class="el-icon-warning" style="color: red"></i>
                      </template>
                      <p>此标准为致命项标准，命中则分数为 0</p>
                    </el-popover>
                  </p>
                </div>
                <div v-else-if="scope.row.judge === 4">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 1">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}分<span
                        class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 2">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                        class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 3">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <div v-if="srrt.silenceType === 1">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div v-else-if="srrt.silenceType === 2">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div v-else-if="srrt.silenceType === 3">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div v-else></div>
                  </div>
                </div>
                <div v-else></div>
              </template>
            </el-table-column>
            <el-table-column prop="defaultScore" label="分数" width="80">
              <template scope="scope">
                <div
                  v-if="
                    (scope.row.judge === 5) &
                      (scope.row.resultsObject.deadItem === '1') &
                      (showCurrentDistribute[scope.row.newIndex].score === 1)
                  "
                >
                  <p>非致命</p>
                </div>
                <div
                  v-else-if="
                    (scope.row.judge === 5) &
                      (scope.row.resultsObject.deadItem === '1') &
                      (showCurrentDistribute[scope.row.newIndex].score === 0)
                  "
                >
                  <p>致命</p>
                </div>
                <span v-else="">{{
                  showCurrentDistribute[scope.row.newIndex].score
                }}</span>
              </template>
            </el-table-column>
            <el-table-column label="命中场景">
              <template scope="scope">
                <span
                  class="playClip_btn"
                  v-for="(word, index) in scope.row.resultsObject.keyword"
                  :key="index"
                  @click="playOccurrence(word)"
                >
                  {{ word.keyword }}
                </span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <el-form ref="form" :model="form" label-width="80px">
      <div class="standards_part">
        <h3>
          人工标准
        </h3>
        <div class="score">
          <label>人工质检得分</label>
          <span>{{ showMenualScore }}</span>
        </div>
        <div class="standards_detail">
          <div
            class="classification_part"
            v-for="(val, key, index) in typelist"
            :key="key"
          >
            <h3>
              {{ key }}
            </h3>
            <div class="classification_detail">
              <el-row>
                <el-col :span="12" v-for="(obj, idx) in showScoreObjs[index]" :key="idx">
                  <el-form-item :label="obj.normalName">
                    <el-input
                      v-model="obj.defaultScore"
                      placeholder="请输入内容"
                      v-if="obj.judge == 6"
                      :disabled="true"
                    ></el-input>
                    <el-radio-group
                      v-model="obj.defaultScore"
                      size="medium"
                      fill="#97a8be"
                      v-if="obj.judge == 7"
                      :disabled="true"
                    >
                      <el-radio-button
                        :label="val"
                        :value="val"
                        v-for="val in obj.resultsObject"
                        :key="val"
                      ></el-radio-button>
                    </el-radio-group>
                    <template v-if="obj.judge == 8">
                      <el-popover placement="right" width="120" trigger="hover">
                        <template slot="reference">
                          <el-radio-group
                            v-model="obj.defaultScore"
                            size="medium"
                            fill="#97a8be"
                            :disabled="true"
                          >
                            <el-radio-button :label="'1'" :value="1"
                              >致命</el-radio-button
                            >
                            <el-radio-button :label="'2'" value="0"
                              >非致命</el-radio-button
                            >
                          </el-radio-group>
                        </template>
                        <p>{{ obj.normalContent || '无' }}</p>
                      </el-popover>
                      <el-popover trigger="hover" placement="right">
                        <template slot="reference">
                          <i class="el-icon-warning" style="color: red"></i>
                        </template>
                        <p>选中致命项则总分为<font color="red"> 零</font></p>
                      </el-popover>
                    </template>
                  </el-form-item>
                </el-col>
              </el-row>
            </div>
          </div>
        </div>
      </div>
      <div class="standards_part">
        <h3>
          &nbsp;
        </h3>
        <div class="score">
          <label>总分</label>
          <span class="result">{{ showTotalScore }}</span>
        </div>
        <div class="standards_detail">
          <div class="classification_part">
            <div class="classification_detail">
              <el-form-item label="质检结果">
                <el-input
                  type="textarea"
                  v-model="showHandleContent"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input>
              </el-form-item>
            </div>
          </div>
        </div>
      </div>
    </el-form>
  </div>
</template>
<script>
import global from '../../../../global.js'
import qs from 'qs'
let currentBaseUrl = global.qualityUrl
export default {
  data() {
    return {
      modleTitle: '',
      standardsLists: [], // 质检评分标准
      typelist: [], // 人工打分标准
      showAddCaseDialog11: false,
      showAddCaseDialog: false,
      ModifyClassDialog: false,
      modelId: '', // 质检模板id
      showHandleContent: '', // 展示质检评分-质检结果
      handleContent: '', // 质检评分-质检结果
      showQualityScore: false, // 是否展示质检评分tab
      isScore: false,
      currentDistribute: [], // 要保存的当前分数列表
      showCurrentDistribute: [], // 当前分数列表
      showScoreObjs: [], // 展示界面的人工质检打分项对象
      isDead: '2', // 手动评分致命项
      isAutoDead: '2', // 自动评分致命项
      scoreObjs: [], // 人工质检打分项对象
      form: {},
      score: '',
      scored: false, // 是否打分完成
    }
  },
  methods: {
    reSetData() {
      this.standardsLists = [] // 质检评分标准
      this.typelist = [] // 人工打分标准
      this.showAddCaseDialog11 = false
      this.showAddCaseDialog = false
      this.ModifyClassDialog = false
      this.modelId = '' // 质检模板id
      this.showHandleContent = '' // 展示质检评分-质检结果
      this.handleContent = '' // 质检评分-质检结果
      this.showQualityScore = false // 是否展示质检评分tab
      this.isScore = false
      this.currentDistribute = [] // 要保存的当前分数列表
      this.showCurrentDistribute = [] // 当前分数列表
      this.showScoreObjs = [] // 展示界面的人工质检打分项对象
      this.scoreObjs = [] // 人工质检打分项对象
      this.isDead = '2' // 手动评分致命项
      this.isAutoDead = '2' // 自动评分致命项
      this.form = {}
      this.score = ''
      this.scored = false // 是否打分完成
    },
    getConditonScore(qaScoreType) {
      let _this = this
      let url = currentBaseUrl + '/scoreView/getConditonScore.do'
      let params = {}
      params.objectId = _this.parentModel.callId
      if (qaScoreType) {
        params.qaScoreType = qaScoreType
      } else {
        params.finalScoreInfo = '1'
      }
      if (_this.parentModel.finalScoreInfo == '1') {
        params.finalScoreInfo = _this.parentModel.finalScoreInfo
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.modleTitle = response.data.modleTitle
          // 如果获取到了数据则赋值
          if (response.data && response.data.scoreDetails) {
            _this.scoreDetails = response.data.scoreDetails
            // 如果是初检页面，则给编辑界面的值赋值
            _this.scored = true
            _this.changData(_this.scoreDetails)
            _this.showHandleContent = response.data.score.comments || ''
          } else if (response.data && response.data.score) {
            _this.showHandleContent = response.data.score.comments
          }
          _this.showKeywordsData()
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数获取失败',
          })
        })
    },
    // 获取模板id
    qamodleScore() {
      let _this = this
      let url = currentBaseUrl + '/scoreView/findModelId.do'
      let params = {}
      params.objectId = this.parentModel.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.modelId = response.data
          if (_this.modelId) {
            _this.yulanModleInfoScore() // 获取模板id之后根据模板id获取模板详情
          } else {
            _this.$message({
              type: 'error',
              message: '未获取到模板id',
            })
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取质检模板id失败',
          })
        })
    },
    // 预览模板（isNeedGetData=》是否需要获取数据，默认为true）
    yulanModleInfoScore(isNeedGetData) {
      let flag = typeof isNeedGetData === 'undefined' ? true : isNeedGetData
      let _this = this
      let url = currentBaseUrl + '/manualQualityAssurance/yulanModleInfoScore.do'
      let params = {}
      params.modleId = this.modelId
      params.objectId = this.parentModel.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.standardsLists = response.data.dataT
            let indexT = 0
            for (let key in _this.standardsLists) {
              let obj = _this.standardsLists[key]
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.normalId = item.normalId
                temp.score = item.defaultScore
                let showtemp = {}
                showtemp.normalId = item.normalId
                showtemp.score = item.defaultScore
                if (item.judge === 5) {
                  if (item.resultsObject.deadItem === '1') {
                    showtemp.deadItem = '1'
                  }
                } else {
                  showtemp.deadItem = '2'
                }
                _this.$set(_this.showCurrentDistribute, indexT, showtemp)
                indexT++
              })
            }
            _this.typelist = response.data.data_hand
            _this.scoreObjs = []
            _this.showScoreObjs = []
            let index = 0
            for (let item in _this.typelist) {
              let scores = []
              _this.typelist[item].forEach(function(temp) {
                let obj = {}
                for (let key in temp) {
                  obj[key] = temp[key]
                }
                if (temp.judge === 7 && _this.checkArrayType(temp.resultsObject)) {
                  obj.defaultScore = temp.resultsObject[0]
                }
                scores.push(obj)
              })
              _this.$set(_this.showScoreObjs, index, JSON.parse(JSON.stringify(scores)))
              index++
            }
            if (flag) {
              _this.getData()
            }
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取模板失败',
          })
        })
    },
    // 不同页面调用不同的方法获取数据
    getData() {
      // 通过qaScoreType判断打分的情况
      this.getConditonScore(this.parentModel.qaScoreType)
    },
    // 根据获取的分数修改模板内容
    changData(scoreDetails) {
      let _this = this
      let currentDistribute = [] // 自动打分
      let scoreObjs = [] // 手动打分
      currentDistribute = _this.showCurrentDistribute
      scoreObjs = _this.showScoreObjs
      scoreDetails.forEach(function(item, index) {
        let isFind = false
        currentDistribute.forEach(function(itm) {
          if (itm.normalId == item.normalId) {
            itm.score = item.score
            if (itm.deadItem === '1' && itm.score === 0) {
              _this.isAutoDead = '1'
            }
            isFind = true
          }
        })
        if (!isFind) {
          scoreObjs.forEach(function(itm) {
            itm.forEach(function(obj) {
              if (obj.normalId == item.normalId) {
                if (item.optioniItem || item.optioniItem == 0) {
                  obj.defaultScore = item.optioniItem
                } else {
                  obj.defaultScore = item.score
                }
              }
            })
          })
        }
      })
    },
    // 判断数组元素是否都可以转为数字
    checkArrayType(arr) {
      return arr.every(function(val, index, arr) {
        let temp = +val
        return typeof temp === 'number' && !Number.isNaN(temp)
      })
    },
    // 命中场景 点击按钮
    playOccurrence(keywordItem) {
      this.$emit('clickhighlightkeys', keywordItem)
    },
    changeTargetTime(key) {
      let _this = this
      for (let j in _this.scoreDetails) {
        if (key.normalId == _this.scoreDetails[j].normalId) {
          key.targetTime = _this.scoreDetails[j].targetTime
        }
      }
    },
    // 关键词展示
    showKeywordsData() {
      let _this = this
      let array = []
      let newobj = {}
      if (_this.playInfoVosList.length <= 0) {
        return false
      }
      for (let k in _this.standardsLists) {
        let newarray = []
        _this.standardsLists[k].forEach(function(normal) {
          let key = normal
          _this.changeTargetTime(key)
          let reg = /[A-Z()\s]+/
          if (key.judge == 5) {
            if (key.targetTime) {
              let targetTime = ''
              targetTime = key.targetTime
              let target = targetTime.split(',')
              let targetTimeStart = target[0]
              let targetTimeEnd = target[1]
              key.targetTimeStart = targetTimeStart
              key.targetTimeEnd = targetTimeEnd
              for (let n = 0; n < _this.playInfoVosList.length; n++) {
                if (
                  parseInt(_this.playInfoVosList[n].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[n].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.Start = n
                  key.targetTimeStart = _this.playInfoVosList[n].startTime
                  break
                }
              }
              for (let m = _this.playInfoVosList.length - 1; m >= 0; m--) {
                if (
                  parseInt(_this.playInfoVosList[m].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[m].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.End = m
                  key.targetTimeEnd = _this.playInfoVosList[m].endTime
                  break
                }
              }
            } else {
              key.Start = 0
              key.End = _this.playInfoVosList.length - 1
              key.targetTimeStart = '0'
              key.targetTimeEnd = _this.playInfoVosList[key.End].endTime
            }
            if (key.targetTime) {
              let keywordContext = key.resultsObject.keywordContext
              let result = keywordContext.replace(reg, ',')
              while (result.match(reg)) {
                result = result.replace(reg, ',')
              }
              keywordContext = result.trim().split(',')
              let keywordContext1 = []
              let o = 0
              for (let l = 0; l < keywordContext.length; l++) {
                if (keywordContext[l] != '') {
                  for (let j = key.Start; j <= key.End; j++) {
                    if (key.resultsObject.roleType == 1) {
                      if (
                        _this.playInfoVosList[j].role == '2' &&
                        _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0
                      ) {
                        keywordContext1[o] = keywordContext[l]
                      }
                    } else if (key.resultsObject.roleType == 2) {
                      if (
                        _this.playInfoVosList[j].role == '1' &&
                        _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0
                      ) {
                        keywordContext1[o] = keywordContext[l]
                      }
                    } else {
                      if (_this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0) {
                        keywordContext1[o] = keywordContext[l]
                      }
                    }
                  }
                  o++
                }
              }
              key.resultsObject.keyword = []
              keywordContext1.forEach((item) => {
                key.resultsObject.keyword.push({
                  keyword: item,
                  clickIndex: 0,
                  fullScriptRole: key.resultsObject.roleType,
                  targetTimeStart: key.targetTimeStart,
                  targetTimeEnd: key.targetTimeEnd,
                })
              })
            }
            // // 从_this.scoreDetails里取关键词
            // let keywords = _this.scoreDetails.filter(function (scoreDetail) {
            //   return scoreDetail.normalId == normal.normalId
            // })
            // keywords.forEach(function (mykeyword) {
            //   if (mykeyword.targetTime != '' && mykeyword.targetTime != null) {
            //     key.resultsObject.keyword = []
            //     let keyWordAndTargetTimes = mykeyword.keyWordAndTargetTimes
            //     keyWordAndTargetTimes.forEach(function (keyAndTime) {
            //       let keywordArr = keyAndTime.split('&&')
            //       let timeArr = keywordArr[1].split('||')
            //       key.resultsObject.keyword.push({
            //         keyword: keywordArr[0],
            //         clickIndex: 0,
            //         fullScriptRole: key.resultsObject.roleType,
            //         targetTimeStart: timeArr[0],
            //         targetTimeEnd: mykeyword.targetTime.split(',')[1]
            //       })
            //       // timeArr.forEach(function (starttime) {
            //       //   key.resultsObject.keyword.push({
            //       //     keyword: keywordArr[0],
            //       //     clickIndex: 0,
            //       //     fullScriptRole: key.resultsObject.roleType,
            //       //     targetTimeStart: starttime,
            //       //     targetTimeEnd: mykeyword.targetTime.split(',')[1]
            //       //   })
            //       // })
            //     })
            //   }
            // })
          } else {
            key.resultsObject.keyword = []
          }
          array.push(key)
          newarray.push(key)
        })
        newobj[k] = newarray
      }
      _this.standardsLists = newobj
      _this.$emit('showhighlightscore', array)
    },
  },
  props: ['parentModel', 'playInfoVosList'],
  created() {
    this.qamodleScore()
  },
  computed: {
    callId() {
      return this.$store.state.recordingPlayPage.callId
    },
    currentTime() {
      return this.$store.state.playerInfo.currentTime * 1000
    },
    showTotalScore() {
      if (this.isDead == '1' || this.isAutoDead == '1') {
        return 0
      }
      let totalScore =
        this.showAutoScore + this.showMenualScore > 0
          ? this.showAutoScore + this.showMenualScore
          : 0
      return totalScore
    },
    showAutoScore() {
      let total = 0
      this.showCurrentDistribute.forEach(function(item) {
        if (item.deadItem !== '1') {
          total += parseInt(item.score) || 0
        }
      })
      if (this.isAutoDead == '1') {
        return 0
      }
      return total > 0 ? total : 0
    },
    showMenualScore() {
      console.log('执行了')
      let total = 0
      let flag = true
      let _this = this
      this.showScoreObjs.forEach(function(item, index) {
        item.forEach(function(temp) {
          if (temp.judge == 6) {
            total += parseInt(temp.defaultScore) || 0
          } else if (temp.judge == 7) {
            if (temp.defaultScore && !isNaN(temp.defaultScore)) {
              total += parseInt(temp.defaultScore) || 0
            }
          } else if (temp.judge == 8 && flag) {
            if (temp.defaultScore == '1') {
              // 如果有一项是致命项则所有的非致命项不能生效
              _this.isDead = '1'
            } else {
              _this.isDead = '2'
            }
            flag = false
          }
        })
      })
      return total > 0 ? total : 0
    },
  },
  watch: {
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.callId != undefined) {
          this.reSetData()
          this.qamodleScore()
        }
      },
      deep: true,
    },
  },
}
</script>

<style lang="less" scoped>
@borderColor: #c3ccd9;

.standards_part {
  border-bottom: 1px dotted @borderColor;
  margin: 0 10px;
  position: relative;
  h3 {
    padding-left: 10px;
    line-height: 30px;
    font-size: 14px;
    color: #1f2d3d;
    font-weight: normal;
  }
  .standards_detail {
    padding: 10px;
    .classification_part {
      margin: 0 10px;
      h3 {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        color: #9dadc2;
        font-weight: normal;
      }
      .classification_detail {
        padding: 10px;
        .el-form-item > label {
          font-size: 14px;
          color: #8691a5;
        }
      }
    }
    .playClip_btn {
      cursor: pointer;
    }
    .normalNameClass {
      line-height: 30px;
      color: #9dadc2;
      font-size: 14px;
    }
  }
  &.noBorder {
    border-bottom: none;
    & > p {
      font-size: 14px;
      margin-bottom: 10px;
    }
  }
  .btns {
    margin: 10px;
  }
}
.score {
  width: 150px;
  line-height: 30px;
  position: absolute;
  right: 10px;
  top: 0px;
  text-align: right;
  label {
    display: inline-block;
    width: 100px;
    font-size: 14px;
    color: #1f2d3d;
    line-height: 30px;
  }
  span {
    display: inline-block;
    width: 35px;
    font-size: 18px;
    color: red;
    line-height: 30px;
  }
  .result {
    color: #85ce61;
  }
}
.selectInspector {
  width: 120px;
  line-height: 30px;
  position: absolute;
  right: 145px;
  top: 6px;
}
&.screening {
  top: 10px;
}
&.appealScore {
  h3 {
    color: #9dadc2;
  }
  label {
    color: #8691a5;
  }
}
</style>
