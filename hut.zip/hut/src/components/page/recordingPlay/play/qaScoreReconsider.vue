<template>
  <div class="standards_parts appealScore">
    <el-form ref="reTaskModel" :model="reTaskModel" label-width="80px">
      <div class="standards_part">
        <h3>
          申诉信息
        </h3>
        <div class="standards_detail">
          <el-row>
            <el-col :span="12">
              <el-form-item label="分配人">
                <el-input
                  v-model="allFuyiVo.assignUsr"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="分配时间">
                <el-input
                  :value="allFuyiVo.assignTime"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="任务开始时间">
                <el-input
                  :value="allFuyiVo.startTime"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="任务截止时间">
                <el-input
                  :value="allFuyiVo.endTime"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="申诉坐席">
                <el-input
                  :value="allFuyiVo.apUser"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="申诉状态">
                <el-input
                  :value="allFuyiVo.appealStatus"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
          </el-row>
        </div>
      </div>
      <div class="standards_part">
        <h3>
          复议裁定
        </h3>
        <div class="standards_detail">
          <el-row>
            <el-col :span="12">
              <el-form-item label="复审裁定">
                <el-input
                  v-model="allFuyiVo.firstCheckText"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="裁定时间">
                <el-input
                  v-model="allFuyiVo.firstCheckTime"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="裁定人员">
                <el-input
                  v-model="allFuyiVo.firstCheckPerson"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="二次申诉内容">
                <el-input
                  v-model="qaAppeal.secondApReason"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="二审时间">
                <el-input
                  v-model="allFuyiVo.secondApTime"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="复议结论">
                <el-input
                  v-model="allFuyiVo.twoCheckText"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="结论人员">
                <el-input
                  v-model="allFuyiVo.twoCheckPerson"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="结论时间">
                <el-input
                  v-model="allFuyiVo.twoCheckTime"
                  placeholder="请输入内容"
                  :disabled="true"
                ></el-input
              ></el-form-item>
            </el-col>
          </el-row>
        </div>
      </div>
      <div class="standards_part">
        <h3>
          复议成绩
        </h3>
        <div class="standards_detail">
          <el-row>
            <el-col :span="12">
              <el-form-item label="复议成绩评定">
                <el-input
                  type="number"
                  v-model="reTaskModel.responseScore"
                  placeholder="请输入内容"
                  :disabled="scored"
                ></el-input
              ></el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="评分说明">
                <el-input
                  v-model="reTaskModel.responseContent"
                  placeholder="请输入内容"
                  :disabled="scored"
                ></el-input
              ></el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="复议">
                <el-radio-group
                  v-model="reTaskModel.responseResult"
                  :disabled="scored"
                  fill="#97a8be"
                >
                  <el-radio-button :label="1">评分有误</el-radio-button>
                  <el-radio-button :label="2">评分无误</el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
      </div>
    </el-form>
    <div class="btns">
      <el-button @click="submitReconsideration" type="primary" v-if="!scored"
        >完成打分</el-button
      >
      <el-button type="primary" :disabled="true" v-if="scored && !due">已完成</el-button>
      <el-button type="primary" :disabled="true" v-if="due">已超时</el-button>
    </div>
  </div>
</template>

<script>
import global from '../../../../global.js'
import moment from 'moment'
import qs from 'qs'
let currentBaseUrl = global.qualityUrl
export default {
  props: ['parentModel'], // 页面来的地方
  data() {
    return {
      reTaskModel: {
        responseResult: 1,
      },
      scored: false, // 是否打分完成
      due: false, // 是否超出复议时间
      qaAppeal: {},
      qaAppealTask: {},
      allFuyiVo: {
        assignTime: '',
        startTime: '',
        endTime: '',
        apUser: '',
        appealStatus: '',
        apReason: '',
        firstApTime: '',
        secondApTime: '',
        twoAppealPerson: '',
        firstCheckPerson: '',
        firstCheckTime: '',
        firstCheckText: '',
        twoCheckPerson: '',
        twoCheckTime: '',
        twoCheckText: '',
      },
    }
  },
  watch: {
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.callId != undefined) {
          this.reSetData()
          this.getPlayTabInfo()
        }
      },
      deep: true,
    },
  },
  mounted() {
    this.getPlayTabInfo()
  },
  methods: {
    reSetData() {
      this.reTaskModel.responseResult = ''
      this.scored = false // 是否打分完成
      this.due = false // 是否打分完成
      this.qaAppeal = {}
      this.qaAppealTask = {}
      this.allFuyiVo.assignTime = ''
      this.allFuyiVo.startTime = ''
      this.allFuyiVo.endTime = ''
      this.allFuyiVo.apUser = ''
      this.allFuyiVo.appealStatus = ''
      this.allFuyiVo.apReason = ''
      this.allFuyiVo.firstApTime = ''
      this.allFuyiVo.secondApTime = ''
      this.allFuyiVo.twoAppealPerson = ''
      this.allFuyiVo.firstCheckPerson = ''
      this.allFuyiVo.firstCheckTime = ''
      this.allFuyiVo.firstCheckText = ''
      this.allFuyiVo.twoCheckPerson = ''
      this.allFuyiVo.twoCheckTime = ''
      this.allFuyiVo.twoCheckText = ''
    },
    getPlayTabInfo() {
      let _this = this
      let url = currentBaseUrl + '/appealsProcess/getPlayTabInfo.do'
      let params = {}
      params.callId = this.parentModel.callId
      params.reTaskId = this.parentModel.reTaskId // 复议id
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            if (response.data.qaAppealTask) {
              _this.qaAppealTask = response.data.qaAppealTask
            }
            if (response.data.qaAppeal) {
              _this.qaAppeal = response.data.qaAppeal
              if (response.data.qaAppeal.apResult === 2) {
                _this.scored = true
              }
            }
            if (response.data.qaAppealResponse) {
              _this.scored = true
              _this.reTaskModel = response.data.qaAppealResponse
            }
            if (response.data.process) {
              _this.process = response.data.process
            }
            // 将所有的信息加入到 allFuyiVo
            _this.allFuyiVo.assignUsr = _this.qaAppealTask.assignUsr
            _this.allFuyiVo.assignTime = _this.qaAppealTask.assignTime
              ? moment(_this.qaAppealTask.assignTime).format('YYYY-MM-DD HH:mm:ss')
              : ''
            _this.allFuyiVo.startTime = _this.qaAppealTask.startTime
              ? moment(_this.qaAppealTask.startTime).format('YYYY-MM-DD HH:mm:ss')
              : '' // 任务开始时间
            _this.allFuyiVo.endTime = moment(
              _this.qaAppealTask.startTime + response.data.fuyiDays * 86400000
            ).format('YYYY-MM-DD HH:mm:ss')
            _this.allFuyiVo.apUser = _this.qaAppeal.apUserName // 申诉人
            _this.allFuyiVo.appealStatus = _this.qaAppeal.secondApTime
              ? '二次申诉'
              : '一次申诉'
            _this.allFuyiVo.apReason = _this.qaAppeal.apReason // 申诉内容
            _this.allFuyiVo.firstApTime = _this.qaAppeal.apTime
              ? moment(_this.qaAppeal.apTime).format('YYYY-MM-DD HH:mm:ss')
              : '' // 申诉时间
            _this.allFuyiVo.secondApTime = _this.qaAppeal.secondApTime
              ? moment(_this.qaAppeal.secondApTime).format('YYYY-MM-DD HH:mm:ss')
              : '' // 二申时间
            _this.allFuyiVo.twoAppealPerson = _this.qaAppeal.apUserName // 二申人

            if (_this.process) {
              for (let i = 0; i < _this.process.length; i++) {
                if (_this.process[i].wfTaskSort == 3) {
                  _this.allFuyiVo.firstCheckPerson = _this.process[i].wfTaskUser // 裁定人员
                  _this.allFuyiVo.firstCheckTime = _this.process[i].wfTaskDoneTime
                    ? moment(_this.process[i].wfTaskDoneTime).format(
                        'YYYY-MM-DD HH:mm:ss'
                      )
                    : ''
                  let parmds = JSON.parse(_this.process[i].wfTaskParam)
                  _this.allFuyiVo.firstCheckText = parmds.ext
                } else if (_this.process[i].wfTaskSort == 5) {
                  _this.allFuyiVo.twoCheckPerson = _this.process[i].wfTaskUser // 裁定人员
                  _this.allFuyiVo.twoCheckTime = _this.process[i].wfTaskDoneTime
                    ? moment(_this.process[i].wfTaskDoneTime).format(
                        'YYYY-MM-DD HH:mm:ss'
                      )
                    : ''
                  let parmds = JSON.parse(_this.process[i].wfTaskParam)
                  _this.allFuyiVo.twoCheckText = parmds.ext
                }
              }
            }
            let now = new Date().getTime()
            let endTime = _this.allFuyiVo.endTime
              ? new Date(_this.allFuyiVo.endTime).getTime()
              : now + 10
            // let firstCheckTime = _this.allFuyiVo.firstCheckTime ? new Date(_this.allFuyiVo.firstCheckTime).getTime() : now + 10
            // let twoCheckTime = _this.allFuyiVo.twoCheckTime ? new Date(_this.allFuyiVo.twoCheckTime).getTime() : now + 10
            console.log(_this.score)
            if (!_this.scored && now > endTime) {
              _this.scored = true
              _this.due = true
            }
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取模板失败',
          })
        })
    },
    // 提交复议结果
    submitReconsideration() {
      let _this = this
      let url = currentBaseUrl + '/appealsProcess/addQauserResponse.do'
      let params = {}
      params.appealId = _this.qaAppeal.appealId // 申诉id
      params.appealTaskId = _this.qaAppealTask.appealTaskId // 申诉任务id
      params.assignType = this.parentModel.assignType // 申诉复议类型
      params.responseScore = this.reTaskModel.responseScore
      params.responseContent = this.reTaskModel.responseContent
      params.responseResult = this.reTaskModel.responseResult
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '复议数据提交成功',
            })
            _this.scored = true
            // 备注： 返回申请复议界面
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '复议数据提交失败',
          })
        })
    },
  },
}
</script>

<style></style>
