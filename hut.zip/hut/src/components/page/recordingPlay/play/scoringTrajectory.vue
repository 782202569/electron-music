<template>
  <div>
    <div class="dialogTitle">
      <div class="score_now">
        <label>当前得分</label>
        <span class="score_result" v-if="scoringTrajectory.length > 0">{{
          scoringTrajectory[scoringTrajectory.length - 1].score
        }}</span>
        <span class="score_result" v-else>0</span>
      </div>
    </div>
    <div class="process_s">
      <el-steps
        direction="vertical"
        :active="scoringTrajectory.length"
        v-if="scoringTrajectory.length > 0"
      >
        <el-step
          :title="item.stepName"
          v-for="item in scoringTrajectory"
          :key="item.stepName"
        >
          <div slot="description">
            <div class="process_score">
              <label>得分</label>
              <span class="score_color">{{ item.score }}</span>
            </div>
            <div class="process_time">
              <label>时间</label>
              <span>{{ item.scoreDate | timeFormat }}</span>
            </div>
          </div>
        </el-step>
      </el-steps>
      <p v-else>暂无评分轨迹</p>
    </div>
  </div>
</template>
<script>
import global from '../../../../global.js'
import qs from 'qs'
import moment from 'moment'
let currentBaseUrl = global.qualityUrl
export default {
  data() {
    return {
      scoringTrajectory: [], // 评分轨迹
      score: '',
    }
  },
  methods: {
    reSetData() {
      this.scoringTrajectory = [] // 评分轨迹
      this.score = ''
    },
    // 获取评分轨迹
    getLocus() {
      let _this = this
      let url = currentBaseUrl + '/scoreView/getLocus.do'
      let params = {}
      params.objectId = this.parentModel.callId
      params.scoreClass = this.parentModel.qaScoreType
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.scoringTrajectory = response.data.locus
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取评分轨迹失败',
          })
        })
    },
  },
  props: ['parentModel'], // 页面来的地方
  created() {
    this.getLocus()
  },
  watch: {
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.callId != undefined) {
          this.reSetData()
          this.getLocus()
        }
      },
      deep: true,
    },
  },
  filters: {
    timeFormat(val) {
      if (val === '' || !val) {
        return ''
      }
      return moment(val).format('YYYY-MM-DD HH:mm:ss')
    },
  },
}
</script>

<style lang="less" scoped>
@borderColor: #c3ccd9;
.dialogTitle {
  color: #8691a5;
  font-size: 14px;
  font-weight: normal;
  box-sizing: border-box;
  height: 50px;
  line-height: 50px;
  padding: 0px 10px;
  border-bottom: 1px dotted @borderColor;
  .btns button {
    width: 30px;
    height: 30px;
    line-height: 30px;
    text-align: center;
    padding: 0px;
  }
  .score_now {
    width: 150px;
    line-height: 30px;
    position: absolute;
    text-align: left;
    label {
      display: inline-block;
      width: 100px;
      font-size: 14px;
      color: #8691a5;
      line-height: 30px;
    }
    span {
      display: inline-block;
      width: 35px;
      font-size: 18px;
      color: #85ce61;
      line-height: 30px;
    }
  }
}
.process_s {
  height: 300px;
  margin: 10px;
  .el-steps {
    height: 300px;
  }
  .process_score,
  .process_time {
    color: #8691a5;
    font-size: 14px;
    line-height: 20px;
    .score_color {
      color: #ff4962;
    }
  }
}
</style>
