<template>
  <div>
    <div class="standards_part">
      <h2>评分模板：{{ modleTitle }}</h2>
      <h3>
        自动评分标准
      </h3>
      <div class="score">
        <label>自动质检得分</label>
        <span>{{ autoScore }}</span>
      </div>
      <div class="standards_detail">
        <div v-for="(standardsList, key) in standardsLists" :key="key">
          <div class="normalNameClass">{{ key }}</div>
          <el-table
            ref="standardsListTable"
            :data="standardsList"
            border
            tooltip-effect="dark"
            style=""
          >
            <el-table-column prop="normalName" label="质检标准"> </el-table-column>
            <el-table-column label="内容">
              <template scope="scope">
                <div v-if="scope.row.judge === 5">
                  <p v-if="scope.row.resultsObject !== null">
                    <span
                      v-for="(item,
                      index) in scope.row.resultsObject.keywordContext.split('OR')"
                      :key="index"
                    >
                      <span
                        class="hightlightContent_span"
                        @click="hightlightContent(item)"
                        >{{ item }}
                      </span>
                      <span
                        v-if="
                          index <
                            scope.row.resultsObject.keywordContext.split('OR').length - 1
                        "
                        >&nbsp;OR&nbsp;</span
                      >
                    </span>
                    <el-popover placement="right" width="120" trigger="hover">
                      <template
                        v-if="scope.row.resultsObject.deadItem == '1'"
                        slot="reference"
                      >
                        <i class="el-icon-warning" style="color: red"></i>
                      </template>
                      <p>此标准为致命项标准，命中则分数为 0</p>
                    </el-popover>
                  </p>
                </div>
                <div v-else-if="scope.row.judge === 4">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 1">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}分<span
                        class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 2">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                        class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 3">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <div v-if="srrt.silenceType === 1">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div v-else-if="srrt.silenceType === 2">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div v-else-if="srrt.silenceType === 3">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div></div>
                  </div>
                </div>
                <div v-else></div>
              </template>
            </el-table-column>
            <el-table-column prop="defaultScore" label="得分" width="120">
              <template scope="scope">
                <span
                  v-if="
                    checkShow(scope.row.newIndex, 'edit') &
                      (scope.row.judge == 5) &
                      (scope.row.resultsObject.deadItem === '1') &
                      (currentDistribute[scope.row.newIndex].score == 1)
                  "
                  class="currentDistributeCount"
                  >非致命</span
                >
                <span
                  v-else-if="
                    checkShow(scope.row.newIndex, 'edit') &
                      (scope.row.judge == 5) &
                      (scope.row.resultsObject.deadItem === '1') &
                      (currentDistribute[scope.row.newIndex].score == 0)
                  "
                  class="currentDistributeCount"
                  >致命</span
                >
                <span
                  v-else-if="checkShow(scope.row.newIndex, 'edit')"
                  class="currentDistributeCount"
                  >{{ currentDistribute[scope.row.newIndex].score }}</span
                >
                <el-button
                  v-if="checkShow(scope.row.newIndex, 'edit') && !scored"
                  @click=""
                  type="text"
                  size="small"
                  icon=""
                ></el-button>
                <el-select
                  v-if="
                    checkShow(scope.row.newIndex, 'save') &
                      (scope.row.judge == 5) &
                      (scope.row.resultsObject.deadItem === '1')
                  "
                  @change="changeDead(scope.row.newIndex)"
                  v-model="currentDistribute[scope.row.newIndex].score"
                  placeholder="请选择"
                  style="width: 95px;"
                >
                  <el-option
                    v-for="item in deadOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
                <el-input
                  v-else-if="checkShow(scope.row.newIndex, 'save')"
                  class="currentDistributeCount"
                  v-model="currentDistribute[scope.row.newIndex].score"
                  placeholder="请输入内容"
                  @blur="checkNumber(scope.row.newIndex, scope.row)"
                ></el-input>
                <el-button
                  v-if="checkShow(scope.row.newIndex, 'save')"
                  @click="editTableCell(scope.row.newIndex, 'save')"
                  type="text"
                  size="small"
                  icon="el-icon-check"
                ></el-button>
              </template>
            </el-table-column>
            <el-table-column prop="times" label="命中场景">
              <template scope="scope">
                <span
                  class="playClip_btn"
                  v-for="(word, index) in scope.row.resultsObject.keyword"
                  :key="index"
                  @click="playOccurrence(word)"
                >
                  {{ word.keyword }}
                </span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <el-form ref="form" :model="form" label-width="80px">
      <div class="standards_part">
        <h3>
          人工标准
        </h3>
        <div class="score">
          <label>人工质检得分</label>
          <span>{{ menualScore }}</span>
        </div>
        <div class="standards_detail">
          <div
            class="classification_part"
            v-for="(val, key, index) in typelist"
            :key="index"
          >
            <h3>
              {{ key }}
            </h3>
            <div class="classification_detail">
              <el-row>
                <el-col :span="12" v-for="(obj, idx) in scoreObjs[index]" :key="idx">
                  <el-form-item :label="obj.normalName">
                    <el-popover
                      v-if="obj.judge == 6 && !scored"
                      placement="right"
                      width="120"
                      trigger="focus"
                    >
                      <el-input
                        v-model="obj.defaultScore"
                        slot="reference"
                        @blur="
                          checkRange(
                            obj.defaultScore,
                            obj.minScoreRange,
                            obj.maxScoreRange
                          )
                        "
                      ></el-input>
                      <p>{{ obj.normalContent || '无' }}</p>
                    </el-popover>
                    <el-input
                      v-model="obj.defaultScore"
                      placeholder="请输入内容"
                      v-if="obj.judge == 6 && scored"
                      :disabled="scored"
                    ></el-input>
                    <el-popover
                      v-if="obj.judge == 7 && !scored"
                      placement="right"
                      width="120"
                      trigger="hover"
                    >
                      <el-radio-group
                        slot="reference"
                        v-model="obj.defaultScore"
                        size="medium"
                        fill="#97a8be"
                        :disabled="scored"
                      >
                        <el-radio-button
                          :label="val"
                          :value="val"
                          v-for="val in obj.resultsObject"
                          :key="val"
                        ></el-radio-button>
                      </el-radio-group>
                      <p>{{ obj.normalContent || '无' }}</p>
                    </el-popover>
                    <el-radio-group
                      v-model="obj.defaultScore"
                      size="medium"
                      fill="#97a8be"
                      v-if="obj.judge == 7 && scored"
                      :disabled="scored"
                    >
                      <el-radio-button
                        :label="val"
                        :value="val"
                        v-for="val in obj.resultsObject"
                        :key="val"
                      ></el-radio-button>
                    </el-radio-group>

                    <template v-if="obj.judge == 8 && !scored">
                      <el-popover placement="right" width="120" trigger="hover">
                        <template slot="reference">
                          <el-radio-group
                            v-model="obj.defaultScore"
                            size="medium"
                            fill="#97a8be"
                          >
                            <el-radio-button :label="'1'">致命</el-radio-button>
                            <el-radio-button :label="'2'">非致命</el-radio-button>
                          </el-radio-group>
                        </template>
                        <p>{{ obj.normalContent || '无' }}</p>
                      </el-popover>
                      <el-popover trigger="hover" placement="right">
                        <template slot="reference">
                          <i class="el-icon-warning" style="color: red"></i>
                        </template>
                        <p>选中致命项则总分为<font color="red"> 零</font></p>
                      </el-popover>
                    </template>
                    <div v-if="obj.judge == 8 && scored">
                      <el-radio-group
                        v-model="obj.defaultScore"
                        :disabled="scored"
                        size="medium"
                        fill="#97a8be"
                      >
                        <el-radio-button :label="'1'">致命</el-radio-button>
                        <el-radio-button :label="'2'">非致命</el-radio-button>
                      </el-radio-group>
                      <el-popover trigger="hover" placement="right">
                        <template slot="reference">
                          <i class="el-icon-warning" style="color: red"></i>
                        </template>
                        <p>选中致命项则总分为<font color="red"> 零</font></p>
                      </el-popover>
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>
            </div>
          </div>
        </div>
      </div>
      <div class="standards_part">
        <h3>
          &nbsp;
        </h3>
        <div class="score">
          <label>总分</label>
          <span class="result">{{ totalScore }}</span>
        </div>
        <div class="standards_detail">
          <div class="classification_part">
            <div class="classification_detail">
              <el-form-item label="质检结果">
                <el-input
                  type="textarea"
                  v-model="handleContent"
                  placeholder="请输入内容"
                  :disabled="scored"
                ></el-input>
              </el-form-item>
            </div>
          </div>
        </div>
      </div>
    </el-form>
    <div class="btns footer" v-show="showCaseBtn">
      <el-button @click="addCase_btn">添加案例</el-button>
      <el-button @click="collectRecord_btn">收藏录音</el-button>
      <el-button type="primary" :disabled="true" v-if="scored">已完成</el-button>
    </div>
    <!-- 收藏录音 -->
    <el-dialog
      :modal="false"
      title="收藏录音"
      :visible.sync="showCollectionDialog"
      :close-on-click-modal="false"
      :before-close="handleCloseCollectionDialog"
      class="collectionRecord"
    >
      <el-form
        :model="saveRecordModel"
        ref="saveRecordModel"
        label-width="0px"
        :rules="saveRecordRules"
      >
        <el-row :gutter="10">
          <el-col :span="8">
            <div class="contentLeft">
              <div class="dialogTitle">
                <div class="btns">
                  <el-button icon="el-icon-plus" @click="addClassbtn"></el-button>
                  <el-button icon="el-icon-edit" @click="editClassbtn"></el-button>
                  <el-button icon="el-icon-close" @click="removeClassbtn"></el-button>
                </div>
              </div>
              <div class="shareReason">
                <el-tree
                  class="filter-tree"
                  :data="dataTree"
                  :props="defaultProps"
                  default-expand-all
                  :expand-on-click-node="false"
                  :highlight-current="true"
                  @node-click="selectClass"
                  ref="selectClassifyTree"
                >
                </el-tree>
              </div>
            </div>
          </el-col>
          <el-col :span="16">
            <div class="contentRight">
              <h3 class="dialogTitle">
                收藏理由
              </h3>
              <div class="shareReason">
                <el-form-item prop="shareReason">
                  <el-input
                    type="textarea"
                    :rows="12"
                    placeholder="请输入收藏理由"
                    v-model="saveRecordModel.shareReason"
                  >
                  </el-input>
                </el-form-item>
              </div>
            </div>
          </el-col>
        </el-row>
        <el-form-item>
          <div class="btns footer">
            <el-button @click="handleCloseCollectionDialog">取消</el-button>
            <el-button type="primary" @click="hasSameRecordThrottle">收藏</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 添加分类弹出框 -->
    <el-dialog
      :modal="false"
      title="添加分类"
      :close-on-click-modal="false"
      :visible.sync="addClassDialog"
      :before-close="handleCloseAddClass"
    >
      <el-form
        label-width="100px"
        :model="AddClassModel"
        ref="AddClassModel"
        :rules="addClassRules"
      >
        <el-form-item label="上级分类标题">
          <el-input v-model="classifyObject.name" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="分类标题" prop="name">
          <el-input v-model="AddClassModel.name" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="addClass">确定</el-button>
          <el-button @click="handleCloseAddClass">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 编辑分类弹出框 -->
    <el-dialog
      :modal="false"
      title="编辑分类"
      :visible.sync="ModifyClassDialog"
      :close-on-click-modal="false"
      :before-close="handleCloseModifyClass"
    >
      <el-form
        label-width="100px"
        :model="ModifyClassModel"
        ref="ModifyClassModel"
        :rules="addClassRules"
      >
        <el-form-item label="原分类标题">
          <el-input v-model="classifyObject.name" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="新分类标题" prop="name">
          <el-input v-model="ModifyClassModel.name" placeholder="请输入"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="modifyClass">确定</el-button>
          <el-button @click="handleCloseModifyClass">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 添加案例弹出层 -->
    <el-dialog
      :modal="false"
      title="添加案例"
      :visible.sync="showAddCaseDialog"
      :close-on-click-modal="false"
      :before-close="handleCloseAddCaseDialog"
      class="addCase"
    >
      <el-form
        :model="AddCaseModel"
        ref="AddCaseModel"
        label-width="0px"
        :rules="addCaseRules"
      >
        <div class="contentRight">
          <h3 class="dialogTitle">
            添加原因
          </h3>
          <div class="addCaseReason">
            <el-form-item prop="addCaseReason">
              <el-input
                type="textarea"
                :rows="12"
                placeholder="请输入添加原因"
                v-model="AddCaseModel.addCaseReason"
              >
              </el-input>
            </el-form-item>
          </div>
        </div>
        <el-form-item>
          <div class="btns addCaseReason_btns">
            <el-button @click="handleCloseAddCaseDialog">取消</el-button>
            <el-button type="primary" @click="hasSameCaseThrottle">添加</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import global from '../../../../global.js'
import qs from 'qs'
let currentBaseUrl = global.qualityUrl
export default {
  data() {
    return {
      modleTitle: '',
      standardsLists: [],
      typelist: [], // 人工打分标准
      showAddCaseDialog: false,
      ModifyClassDialog: false,
      modelId: '', // 质检模板id
      showHandleContent: '', // 展示质检评分-质检结果
      handleContent: '', // 质检评分-质检结果
      showQualityScore: false, // 是否展示质检评分tab
      isScore: false,
      currentDistribute: [], // 要保存的当前分数列表
      scoreObjs: [], // 人工质检打分项对象
      form: {},
      scored: false, // 是否打分完成
      showCurrentDistribute: [], // 当前分数列表
      editCountIndex: '', // 当前编辑的单元格所在的行index
      addClassDialog: false, // 添加分类弹出层
      countHasError: false, // 自动打分修改的是否正确
      showCollectionDialog: false,
      classifyObject: {}, // 选中的分类
      dataTree: [], // 分类树
      isDead: '2', // 手动评分致命项
      isAutoDead: '2', // 自动评分致命项
      showCaseBtn: true,
      AddCaseModel: {
        addCaseReason: '',
      },
      ModifyClassModel: {
        collectShareClassId: '',
        name: '',
      },
      saveRecordModel: {
        shareReason: '', // 收藏理由
      },
      addCaseRules: {
        // 添加案例验证
        addCaseReason: [
          {
            required: true,
            message: '请输入添加原因',
            trigger: 'blur',
          },
        ],
      },
      defaultProps: {
        children: 'listClass',
        label: 'name',
      },
      saveRecordRules: {
        // 收藏验证
        shareReason: [
          {
            required: true,
            message: '请输入收藏理由',
            trigger: 'blur',
          },
        ],
      },
      addClassRules: {
        // 添加案例验证
        name: [
          {
            required: true,
            message: '分类名称不能为空',
            trigger: 'blur',
          },
        ],
      },
      AddClassModel: {
        collectShareClassParentId: '',
        name: '',
      },
      deadOptions: [
        {
          value: 0,
          label: '致命',
        },
        {
          value: 1,
          label: '非致命',
        },
      ],
      returnVisitMatchResult: [],
    }
  },
  methods: {
    reSetData() {
      this.modleTitle = ''
      this.standardsLists = []
      this.typelist = [] // 人工打分标准
      this.showAddCaseDialog = false
      this.ModifyClassDialog = false
      this.modelId = '' // 质检模板id
      this.classifyObject = {} // 选中的分类
      this.showHandleContent = '' // 展示质检评分-质检结果
      this.handleContent = '' // 质检评分-质检结果
      this.showQualityScore = false // 是否展示质检评分tab
      this.isScore = false
      this.currentDistribute = [] // 要保存的当前分数列表
      this.scoreObjs = [] // 人工质检打分项对象
      this.form = {}
      this.scored = false // 是否打分完成
      this.showCurrentDistribute = [] // 当前分数列表
      this.editCountIndex = '' // 当前编辑的单元格所在的行index
      this.countHasError = false // 自动打分修改的是否正确
      this.addClassDialog = false // 添加分类弹出层
      this.showCollectionDialog = false
      this.dataTree = [] // 分类树
      this.isDead = '2' // 手动评分致命项
      this.isAutoDead = '2' // 自动评分致命项
      this.showCaseBtn = true
      this.AddCaseModel.addCaseReason = ''
      this.saveRecordModel.shareReason = '' // 收藏理由
      this.returnVisitMatchResult = []
    },
    // 命中场景 点击按钮
    playOccurrence(keywordItem) {
      this.$emit('clickhighlightkeys', keywordItem)
    },
    // 关键词展示
    showKeywordsData() {
      let _this = this
      let array = []
      let newobj = {}
      if (_this.playInfoVosList.length <= 0) {
        return false
      }
      for (let k in _this.standardsLists) {
        let newarray = []
        _this.standardsLists[k].forEach(function(normal) {
          let key = normal
          let reg = /[A-Z()\s]+/
          if (key.judge == 5) {
            if (key.targetTime) {
              let targetTime = ''
              targetTime = key.targetTime
              let target = targetTime.split(',')
              let targetTimeStart = target[0]
              let targetTimeEnd = target[1]
              key.targetTimeStart = targetTimeStart
              key.targetTimeEnd = targetTimeEnd
              for (let n = 0; n < _this.playInfoVosList.length; n++) {
                if (
                  parseInt(_this.playInfoVosList[n].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[n].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.Start = n
                  key.targetTimeStart = _this.playInfoVosList[n].startTime
                  break
                }
              }
              for (let m = _this.playInfoVosList.length - 1; m >= 0; m--) {
                if (
                  parseInt(_this.playInfoVosList[m].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[m].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.End = m
                  key.targetTimeEnd = _this.playInfoVosList[m].endTime
                  break
                }
              }
            } else {
              key.Start = 0
              key.End = _this.playInfoVosList.length - 1
              key.targetTimeStart = '0'
              key.targetTimeEnd = _this.playInfoVosList[key.End].endTime
            }
            let keywordContext = key.resultsObject.keywordContext
            let result = keywordContext.replace(reg, ',')
            while (result.match(reg)) {
              result = result.replace(reg, ',')
            }
            keywordContext = result.trim().split(',')
            let keywordContext1 = []
            let o = 0
            for (let l = 0; l < keywordContext.length; l++) {
              if (keywordContext[l] != '') {
                for (let j = key.Start; j <= key.End; j++) {
                  if (key.resultsObject.roleType == 1) {
                    if (
                      _this.playInfoVosList[j].role == '2' &&
                      _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0
                    ) {
                      keywordContext1[o] = keywordContext[l]
                    }
                  } else if (key.resultsObject.roleType == 2) {
                    if (
                      _this.playInfoVosList[j].role == '1' &&
                      _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0
                    ) {
                      keywordContext1[o] = keywordContext[l]
                    }
                  } else {
                    if (_this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0) {
                      keywordContext1[o] = keywordContext[l]
                    }
                  }
                }
                o++
              }
            }
            key.resultsObject.keyword = []
            keywordContext1.forEach((item) => {
              key.resultsObject.keyword.push({
                keyword: item,
                clickIndex: 0,
                fullScriptRole: key.resultsObject.roleType,
                targetTimeStart: key.targetTimeStart,
                targetTimeEnd: key.targetTimeEnd,
              })
            })
            // // 从_this.scoreDetails里取关键词
            // let keywords = _this.scoreDetails.filter(function (scoreDetail) {
            //   return scoreDetail.normalId == normal.normalId
            // })
            // keywords.forEach(function (mykeyword) {
            //   if (mykeyword.targetTime != '' && mykeyword.targetTime != null) {
            //     key.resultsObject.keyword = []
            //     let keyWordAndTargetTimes = mykeyword.keyWordAndTargetTimes
            //     keyWordAndTargetTimes.forEach(function (keyAndTime) {
            //       let keywordArr = keyAndTime.split('&&')
            //       let timeArr = keywordArr[1].split('||')
            //       key.resultsObject.keyword.push({
            //         keyword: keywordArr[0],
            //         clickIndex: 0,
            //         fullScriptRole: key.resultsObject.roleType,
            //         targetTimeStart: timeArr[0],
            //         targetTimeEnd: mykeyword.targetTime.split(',')[1]
            //       })
            //       // timeArr.forEach(function (starttime) {
            //       //   key.resultsObject.keyword.push({
            //       //     keyword: keywordArr[0],
            //       //     clickIndex: 0,
            //       //     fullScriptRole: key.resultsObject.roleType,
            //       //     targetTimeStart: starttime,
            //       //     targetTimeEnd: mykeyword.targetTime.split(',')[1]
            //       //   })
            //       // })
            //     })
            //   }
            // })
          } else {
            key.resultsObject.keyword = []
          }
          array.push(key)
          newarray.push(key)
        })
        newobj[k] = newarray
      }
      _this.standardsLists = newobj
      _this.$emit('showhighlightscore', array)
    },
    getConditonScore(qaScoreType) {
      let _this = this
      let url = currentBaseUrl + '/scoreView/getConditonScore.do'
      let params = {}
      params.objectId = _this.parentModel.callId
      if (qaScoreType == '3') {
        params.finalScoreInfo = '1'
      } else {
        params.qaScoreType = qaScoreType
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          // 如果获取到了数据则赋值
          if (response.data && response.data.scoreDetails) {
            _this.scoreDetails = response.data.scoreDetails
            // 如果是初检页面，则给编辑界面的值赋值
            _this.scored = true
            _this.changData(_this.scoreDetails)
            _this.handleContent = response.data.score.comments || ''
          } else if (response.data && response.data.score) {
            _this.handleContent = response.data.score.comments
          }
          _this.showKeywordsData()
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数获取失败',
          })
        })
    },
    // 点击分类树时选择分类
    selectClass(val) {
      this.classifyObject.classifyId = val.collectShareClassId
      this.classifyObject.name = val.name
    },
    // 关闭修改分类弹出层
    handleCloseModifyClass() {
      this.ModifyClassDialog = false
    },
    // 关闭添加分类弹出层
    handleCloseAddClass() {
      this.addClassDialog = false
    },
    checkShow(index, flag) {
      if (flag === 'edit' && this.editCountIndex !== index) {
        return true
      } else if (flag === 'save' && this.editCountIndex !== index) {
        return false
      } else if (flag === 'save' && this.editCountIndex === index) {
        return true
      } else {
        return false
      }
    },
    hasSameRecordThrottle() {
      this.lodashThrottle.throttle(this.hasSameRecord, this)
    },
    // 判断是否重复收藏
    hasSameRecord() {
      let _this = this
      let url = currentBaseUrl + '/qaDetail/hasSameRecord.do'
      let params = {}
      params.objectId = this.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data == false) {
            _this.collectRecord()
          } else {
            _this.$message({
              type: 'error',
              message: '重复收藏',
            })
            _this.showCollectionDialog = false
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '检查是否重复收藏失败',
          })
        })
    },
    // 点击添加分类按钮
    addClassbtn() {
      this.addClassDialog = true
      this.resetForm('AddClassModel')
      this.AddClassModel.collectShareClassParentId = this.classifyObject.classifyId
    },
    // 添加分类方法
    addClass() {
      let _this = this
      this.$refs.AddClassModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          this.axios
            .post(
              currentBaseUrl + '/collectShareClass/save.do',
              qs.stringify(_this.AddClassModel)
            )
            .then(function(response) {
              if (response.data.state == '1') {
                _this.$message({
                  type: 'success',
                  message: '新类添加成功!',
                })
                _this.classifyObject = {}
                _this.addClassDialog = false
                _this.getCaseClassTreeData()
              } else {
                _this.$message({
                  type: 'error',
                  message: response.data.message,
                })
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '新类添加失败',
              })
            })
        }
      })
    },
    // 编辑分类按钮
    editClassbtn() {
      let current = this.classifyObject
      if (!current.classifyId) {
        this.$message({
          message: '请先选择一个分类',
          type: 'warning',
        })
        return false
      }
      this.ModifyClassDialog = true
      this.resetForm('ModifyClassModel')
      this.ModifyClassModel.collectShareClassId = current.classifyId
    },
    removeClassbtn() {
      let current = this.classifyObject
      if (!current.classifyId) {
        this.$message({
          message: '请先选择一个分类',
          type: 'warning',
        })
        return false
      }
      this.$confirm(
        '删除分类会将分类下的子分类同时删除，确定要删除选中的分类么?',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      )
        .then(() => {
          this.removeClass(current.collectShareClassId)
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 删除分类
    removeClass(id) {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/favoritManage/deleteCollectShareClassById.do',
          qs.stringify({
            classId: this.classifyObject.classifyId,
          })
        )
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '删除成功!',
            })
            _this.getCaseClassTreeData()
            _this.classifyObject = {}
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '删除出现问题',
          })
        })
    },
    // 关闭添加案例弹出层
    handleCloseAddCaseDialog() {
      this.showAddCaseDialog = false
    },
    // 点击收藏按钮
    collectRecord_btn() {
      this.showCollectionDialog = true
      this.resetForm('saveRecordModel')
      this.getCaseClassTreeData()
    },
    // 收藏录音方法
    collectRecord() {
      let _this = this
      this.$refs.saveRecordModel.validate((valid) => {
        if (!valid) {
          return false
        } else if (!this.classifyObject.classifyId) {
          _this.$message({
            type: 'error',
            message: '请选择一个分类',
          })
        } else {
          let url = currentBaseUrl + '/qaDetail/colRecord.do'
          let params = {}
          params.shareReason = this.saveRecordModel.shareReason
          params.objectId = this.callId
          params.shareTopicId = this.classifyObject.classifyId
          this.axios
            .post(url, qs.stringify(params))
            .then(function(response) {
              if (response.data) {
                _this.$message({
                  type: 'success',
                  message: '收藏成功',
                })
                _this.showCollectionDialog = false
              } else {
                return Promise.reject()
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '收藏失败',
              })
            })
        }
      })
    },
    // 获取分类
    getCaseClassTreeData() {
      let _this = this
      let url = currentBaseUrl + '/favoritManage/selectAllIvsCollectShareClass.do'
      let params = {}
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.dataTree = response.data.Data
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '录音名称获取失败',
          })
        })
    },
    // 编辑分类
    modifyClass() {
      let _this = this
      this.$refs.ModifyClassModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          this.axios
            .post(
              currentBaseUrl + '/collectShareClass/update.do',
              qs.stringify(_this.ModifyClassModel)
            )
            .then(function(response) {
              if (response.data.state == '1') {
                _this.$message({
                  type: 'success',
                  message: '类别编辑成功!',
                })
                _this.classifyObject = {}
                _this.ModifyClassDialog = false
                _this.getCaseClassTreeData()
              } else {
                _this.$message({
                  type: 'error',
                  message: response.data.message,
                })
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '类别编辑失败！',
              })
            })
        }
      })
    },
    changeDead(index) {
      if (this.currentDistribute[index].score == 0) {
        this.isAutoDead = '1'
      } else {
        this.isAutoDead = '2'
      }
    },
    // 检查当前分配输入的是否是数字
    checkNumber(index, obj) {
      this.countHasError = false
      let arr = []
      if (typeof obj.minScoreRange === 'number' && !Number.isNaN(obj.minScoreRange)) {
        arr.push(obj.minScoreRange)
      } else {
        arr.push(0)
      }
      if (typeof obj.maxScoreRange === 'number' && !Number.isNaN(obj.maxScoreRange)) {
        arr.push(obj.maxScoreRange)
      }
      if (typeof obj.defaultScore === 'number' && !Number.isNaN(obj.defaultScore)) {
        arr.push(obj.defaultScore)
      }
      arr.sort(function(a, b) {
        return a - b
      })
      let min = arr[0] > obj.defaultScore ? obj.defaultScore : arr[0]
      let max =
        arr[arr.length - 1] < obj.defaultScore ? obj.defaultScore : arr[arr.length - 1]
      // 设置自动评分的致命项
      if (obj.resultsObject.deadItem == '1') {
        // 致命项只能打分0/1
        min = 0
        max = 1
        if (
          obj.resultsObject.deadItem == '1' &&
          this.currentDistribute[index].score <= 0
        ) {
          this.isAutoDead = '1'
        } else {
          this.isAutoDead = '2'
        }
      }
      if (
        typeof +this.currentDistribute[index].score !== 'number' ||
        Number.isNaN(+this.currentDistribute[index].score) ||
        this.currentDistribute[index].score === ''
      ) {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
        this.countHasError = true
        return false
      } else if (
        this.currentDistribute[index].score < min ||
        this.currentDistribute[index].score > max
      ) {
        this.$message({
          type: 'error',
          message: '分值范围为' + min + '~' + max,
        })
        event.target.focus()
        this.countHasError = true
        return false
      }
    },
    checkRange(val, min, max) {
      if (isNaN(val) || val === '') {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
      } else if (val < min || val > max) {
        this.$message({
          type: 'error',
          message: '分值范围为' + min + '~' + max,
        })
        event.target.focus()
      }
    },
    // 点击table中编辑和保存按钮时数据状态的变化
    editTableCell(index, flag) {
      if (this.countHasError) {
        return false
      }
      if (flag === 'edit') {
        this.editCountIndex = index
      } else {
        if (
          isNaN(this.currentDistribute[index].score) ||
          this.currentDistribute[index].score === ''
        ) {
          this.countHasError = true
          return false
        } else if (this.currentDistribute[index].score == 0) {
          this.isDead = '1'
        }
        this.editCountIndex = ''
      }
    },
    // 获取模板id
    qamodleScore() {
      if (this.parentModel.qaScoreType == '2') {
        this.showCaseBtn = false
      }
      let _this = this
      let url = currentBaseUrl + '/scoreView/findModelId.do'
      let params = {}
      params.objectId = this.parentModel.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.modelId = response.data
          if (_this.modelId) {
            _this.yulanModleInfoScore() // 获取模板id之后根据模板id获取模板详情
          } else {
            _this.$message({
              type: 'error',
              message: '未获取到模板id',
            })
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取质检模板id失败',
          })
        })
    },
    // 预览模板（isNeedGetData=》是否需要获取数据，默认为true）
    yulanModleInfoScore(isNeedGetData) {
      let flag = typeof isNeedGetData === 'undefined' ? true : isNeedGetData
      let _this = this
      let url = currentBaseUrl + '/manualQualityAssurance/yulanModleInfoScore.do'
      let params = {}
      params.modleId = this.modelId
      params.objectId = this.parentModel.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.modleTitle = response.data.modle.modleTitle
            _this.standardsLists = response.data.dataT
            let indexT = 0
            for (let key in _this.standardsLists) {
              let obj = _this.standardsLists[key]
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.normalId = item.normalId
                temp.score = item.defaultScore
                if (item.judge === 5) {
                  temp.deadItem = item.resultsObject.deadItem
                } else {
                  temp.deadItem = '2'
                }
                let showtemp = {}
                showtemp.normalId = item.normalId
                showtemp.score = item.defaultScore
                _this.$set(_this.currentDistribute, indexT, temp)
                _this.$set(_this.showCurrentDistribute, indexT, showtemp)
                indexT++
              })
            }
            _this.typelist = response.data.data_hand
            _this.showTypelist = response.data.data_hand
            _this.scoreObjs = []
            _this.showScoreObjs = []
            let index = 0
            for (let item in _this.typelist) {
              // _this.$set(_this.scoreObjs, index, _this.typelist[item])
              let scores = []
              _this.typelist[item].forEach(function(temp) {
                let obj = {}
                for (let key in temp) {
                  obj[key] = temp[key]
                }
                if (temp.judge === 7 && _this.checkArrayType(temp.resultsObject)) {
                  obj.defaultScore = temp.resultsObject[0]
                }
                scores.push(obj)
              })
              _this.$set(_this.showScoreObjs, index, JSON.parse(JSON.stringify(scores)))
              _this.$set(_this.scoreObjs, index, JSON.parse(JSON.stringify(scores)))
              index++
            }
            if (flag) {
              _this.getData()
            }
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取模板失败',
          })
        })
    },
    // 添加案例
    addCase_btn() {
      this.showAddCaseDialog = true
      this.resetForm('AddCaseModel')
    },
    // 判断是否重复添加案例
    hasSameCaseThrottle() {
      this.lodashThrottle.throttle(this.hasSameCase, this)
    },
    // 添加案例
    addCase() {
      let _this = this
      this.$refs.AddCaseModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let url = currentBaseUrl + '/qaDetail/colCase.do'
          let params = {}
          params.caseRemark = this.AddCaseModel.addCaseReason
          params.objectId = this.callId
          params.casClassId = '1'
          params.caseName = '案例'
          this.axios
            .post(url, qs.stringify(params))
            .then(function(response) {
              if (response.data) {
                _this.$message({
                  type: 'success',
                  message: '案例添加成功',
                })
                _this.showAddCaseDialog = false
              } else {
                return Promise.reject()
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '案例添加失败',
              })
            })
        }
      })
    },
    hasSameCase() {
      let _this = this
      let url = currentBaseUrl + '/qaDetail/hasSameCase.do'
      let params = {}
      params.objectId = this.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (!response.data) {
            _this.addCase()
          } else {
            _this.$message({
              type: 'error',
              message: '案例重复添加',
            })
            _this.showAddCaseDialog = false
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '检查是否重复添加失败',
          })
        })
    },
    // 重置表单
    resetForm(name) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[name].resetFields()
      })
    },
    // 我的质检任务》提交分数
    submitScore() {
      let _this = this
      let url = ''
      let result = []
      let params = {}
      this.scoreObjs.forEach(function(item, index) {
        item.forEach(function(temp) {
          let obj = {}
          obj.normalId = temp.normalId
          if (temp.judge == 6) {
            obj.score = temp.defaultScore
          } else if (temp.judge == 7) {
            obj.optioniItem = temp.defaultScore
          } else if (temp.judge == 8) {
            obj.optioniItem = _this.isDead
            obj.comments = _this.isDead == '1' ? '致命' : '非致命'
          }
          result.push(obj)
        })
      })
      if (this.editCountIndex !== '') {
        this.$message({
          type: 'warning',
          message: '请确认修改的分数',
        })
        return false
      }
      let deadItem
      if (this.isDead == '2' && this.isAutoDead == '2') {
        deadItem = '2'
      } else {
        deadItem = '1'
      }
      params = {}
      params.modelId = this.modelId
      params.score = this.totalScore
      params.objectId = this.callId
      params.existQuestion = '' // 存在问题
      params.comments = this.handleContent // 处理内容
      params.qaedUser = this.parentModel.seatNo
      params.deadItem = deadItem
      result = result.concat(_this.currentDistribute)
      params.jsonStr = JSON.stringify(result)
      url = currentBaseUrl + '/qaDetail/compltTask.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '打分成功',
            })
            _this.scored = true
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数提交失败',
          })
        })
    },
    // 不同页面调用不同的方法获取数据
    getData() {
      // 如果是初检任务，则只给编辑页面赋值即可，如果有则页面不可编辑，完成打分状态
      // 如果没有，则展示模板中的默认打分
      this.getConditonScore('1')
    },
    // 判断数组元素是否都可以转为数字
    checkArrayType(arr) {
      return arr.every(function(val, index, arr) {
        let temp = +val
        return typeof temp === 'number' && !Number.isNaN(temp)
      })
    },
    // 关闭收藏弹出层
    handleCloseCollectionDialog() {
      this.showCollectionDialog = false
    },

    // 根据获取的分数修改模板内容
    changData(scoreDetails) {
      let _this = this
      let currentDistribute = [] // 自动打分
      let scoreObjs = [] // 手动打分
      currentDistribute = _this.currentDistribute
      scoreObjs = _this.scoreObjs
      scoreDetails.forEach(function(item, index) {
        let isFind = false
        currentDistribute.forEach(function(itm) {
          if (itm.normalId == item.normalId) {
            itm.score = item.score
            if (itm.deadItem === '1' && itm.score === 0) {
              _this.isAutoDead = '1'
            }
            isFind = true
          }
        })
        if (!isFind) {
          scoreObjs.forEach(function(itm) {
            itm.forEach(function(obj) {
              if (obj.normalId == item.normalId) {
                if (item.optioniItem || item.optioniItem == 0) {
                  obj.defaultScore = item.optioniItem
                } else {
                  obj.defaultScore = item.score
                }
              }
              console.log(obj)
            })
          })
        }
      })
    },
  },
  props: ['parentModel', 'playInfoVosList'],
  created() {
    this.qamodleScore()
  },
  computed: {
    callId() {
      return this.$store.state.recordingPlayPage.callId
    },
    currentTime() {
      return this.$store.state.playerInfo.currentTime * 1000
    },
    totalScore() {
      if (this.isDead == '1' || this.isAutoDead == '1') {
        return 0
      }
      let totalScore =
        this.autoScore + this.menualScore > 0 ? this.autoScore + this.menualScore : 0
      return totalScore
    },
    autoScore() {
      let total = 0
      this.currentDistribute.forEach(function(item) {
        if (item.deadItem !== '1') {
          total += parseInt(item.score) || 0
        }
      })
      if (this.isAutoDead == '1') {
        return 0
      }
      return total > 0 ? total : 0
    },
    menualScore() {
      let total = 0
      let _this = this
      let flag = true
      this.scoreObjs.forEach(function(item, index) {
        item.forEach(function(temp) {
          if (temp.judge == 6) {
            total += parseInt(temp.defaultScore) || 0
          } else if (temp.judge == 7) {
            if (temp.defaultScore) {
              total += parseInt(temp.defaultScore) || 0
            }
          } else if (temp.judge == 8 && flag) {
            if (temp.defaultScore == '1') {
              // 如果有一项是致命项则所有的非致命项不能生效
              _this.isDead = '1'
            } else {
              _this.isDead = '2'
            }
            flag = false
          }
        })
      })
      if (this.isDead == '1') {
        return 0
      }
      return total > 0 ? total : 0
    },
  },
  watch: {
    // 如果显示评分轨迹界面
    showScoringTrajectory(val) {
      if (val) {
        this.getLocus()
      }
    },
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.callId != undefined) {
          this.reSetData()
          this.qamodleScore()
          if (this.parentModel.qaScoreType == '2') {
            this.showCaseBtn = false
          }
        }
      },
      deep: true,
    },
  },
}
</script>
<style lang="less">
.collectionRecord {
  .el-dialog__header {
    display: block !important;
  }
}
.addCase {
  .el-dialog__header {
    display: block !important;
  }
}
</style>
<style lang="less" scoped>
@borderColor: #c3ccd9;
.standards_part {
  border-bottom: 1px dotted @borderColor;
  margin: 0 10px;
  position: relative;
  h3 {
    padding-left: 10px;
    line-height: 30px;
    font-size: 14px;
    color: #1f2d3d;
    font-weight: normal;
  }
  .standards_detail {
    padding: 10px;
    .playClip_btn {
      cursor: pointer;
    }
    .classification_part {
      margin: 0 10px;
      h3 {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        color: #9dadc2;
        font-weight: normal;
      }
      .classification_detail {
        padding: 10px;
        .el-form-item > label {
          font-size: 14px;
          color: #8691a5;
        }
      }
    }
    .normalNameClass {
      line-height: 30px;
      color: #9dadc2;
      font-size: 14px;
    }
  }
  &.noBorder {
    border-bottom: none;
    & > p {
      font-size: 14px;
      margin-bottom: 10px;
    }
  }
  .btns {
    margin: 10px;
  }
}
.shareReason {
  padding: 10px;
  height: 300px;
  width: 90%;
  overflow-y: auto;
  .el-tree.filter-tree {
    border: none;
  }
}
.dialogTitle {
  color: #8691a5;
  font-size: 14px;
  font-weight: normal;
  box-sizing: border-box;
  height: 50px;
  line-height: 50px;
  padding: 0px 10px;
  border-bottom: 1px dotted @borderColor;
  .btns button {
    width: 30px;
    height: 30px;
    line-height: 30px;
    text-align: center;
    padding: 0px;
  }
}
.contentLeft,
.contentRight {
  border: 1px solid @borderColor;
}
.score {
  width: 150px;
  line-height: 30px;
  position: absolute;
  right: 10px;
  top: 0px;
  text-align: right;
  label {
    display: inline-block;
    width: 100px;
    font-size: 14px;
    color: #1f2d3d;
    line-height: 30px;
  }
  span {
    display: inline-block;
    width: 35px;
    font-size: 18px;
    color: red;
    line-height: 30px;
  }
  .result {
    color: #85ce61;
  }
}
.selectInspector {
  width: 120px;
  line-height: 30px;
  position: absolute;
  right: 145px;
  top: 6px;
}
&.screening {
  top: 10px;
}
&.appealScore {
  h3 {
    color: #9dadc2;
  }
  label {
    color: #8691a5;
  }
}
</style>
