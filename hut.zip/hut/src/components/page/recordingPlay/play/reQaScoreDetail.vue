<template>
  <div class="standards_parts">
    <div class="standards_part">
      <h2>评分模板：{{ modleTitle }}</h2>
      <h3>
        自动评分标准
      </h3>
      <div class="score">
        <label>自动质检得分</label>
        <span>{{ autoScore }}</span>
      </div>
      <div class="standards_detail">
        <div v-for="(standardsList, key) in standardsLists" :key="key">
          <div class="normalNameClass">{{ key }}</div>
          <el-table
            ref="standardsListTable"
            :data="standardsList"
            border
            tooltip-effect="dark"
            style=""
          >
            <el-table-column prop="normalName" label="质检标准"> </el-table-column>
            <el-table-column label="内容">
              <template scope="scope">
                <div v-if="scope.row.judge === 5">
                  <p v-if="scope.row.resultsObject !== null">
                    <span
                      v-for="(item,
                      index) in scope.row.resultsObject.keywordContext.split('OR')"
                      :key="index"
                    >
                      <span
                        class="hightlightContent_span"
                        @click="hightlightContent(item)"
                        >{{ item }}
                      </span>
                      <span
                        v-if="
                          index <
                            scope.row.resultsObject.keywordContext.split('OR').length - 1
                        "
                        >&nbsp;OR&nbsp;</span
                      >
                    </span>
                    <el-popover placement="right" width="120" trigger="hover">
                      <template
                        v-if="scope.row.resultsObject.deadItem == '1'"
                        slot="reference"
                      >
                        <i class="el-icon-warning" style="color: red"></i>
                      </template>
                      <p>此标准为致命项标准，命中则分数为 0</p>
                    </el-popover>
                  </p>
                </div>
                <div v-else-if="scope.row.judge === 4">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 1">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}分<span
                        class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 2">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                        class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 3">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <div v-if="srrt.silenceType === 1">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div v-else-if="srrt.silenceType === 2">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div v-else-if="srrt.silenceType === 3">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div></div>
                  </div>
                </div>
                <div v-else></div>
              </template>
            </el-table-column>
            <el-table-column prop="defaultScore" label="得分" width="120">
              <template scope="scope">
                <span
                  v-if="
                    (scope.row.judge == 5) &
                      (scope.row.resultsObject.deadItem === '1') &
                      (currentDistribute[scope.row.newIndex].score == 1)
                  "
                  class="currentDistributeCount"
                  >非致命</span
                >
                <span
                  v-else-if="
                    (scope.row.judge == 5) &
                      (scope.row.resultsObject.deadItem === '1') &
                      (currentDistribute[scope.row.newIndex].score == 0)
                  "
                  class="currentDistributeCount"
                  >致命</span
                >
                <span v-else="" class="currentDistributeCount">{{
                  currentDistribute[scope.row.newIndex].score
                }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="times" label="命中场景">
              <template scope="scope">
                <span
                  class="playClip_btn"
                  v-for="(word, index) in scope.row.resultsObject.keyword"
                  :key="index"
                  @click="playOccurrence(word)"
                >
                  {{ word.keyword }}
                </span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <el-form ref="form" :model="form" label-width="80px">
      <div class="standards_part">
        <h3>
          人工标准
        </h3>
        <div class="score">
          <label>人工质检得分</label>
          <span>{{ menualScore }}</span>
        </div>
        <div class="standards_detail">
          <div
            class="classification_part"
            v-for="(val, key, index) in typelist"
            :key="index"
          >
            <h3>
              {{ key }}
            </h3>
            <div class="classification_detail">
              <el-row>
                <el-col :span="12" v-for="(obj, idx) in scoreObjs[index]" :key="idx">
                  <el-form-item :label="obj.normalName">
                    <el-popover
                      v-if="obj.judge == 6 && !scored"
                      placement="right"
                      width="120"
                      trigger="focus"
                    >
                      <el-input
                        v-model="obj.defaultScore"
                        slot="reference"
                        @blur="
                          checkRange(
                            obj.defaultScore,
                            obj.minScoreRange,
                            obj.maxScoreRange
                          )
                        "
                      ></el-input>
                      <p>{{ obj.normalContent || '无' }}</p>
                    </el-popover>
                    <el-input
                      v-model="obj.defaultScore"
                      placeholder="请输入内容"
                      v-if="obj.judge == 6 && scored"
                      :disabled="scored"
                    ></el-input>
                    <el-popover
                      v-if="obj.judge == 7 && !scored"
                      placement="right"
                      width="120"
                      trigger="hover"
                    >
                      <el-radio-group
                        slot="reference"
                        v-model="obj.defaultScore"
                        size="medium"
                        fill="#97a8be"
                        :disabled="scored"
                      >
                        <el-radio-button
                          :label="val"
                          :value="val"
                          v-for="val in obj.resultsObject"
                          :key="val"
                        ></el-radio-button>
                      </el-radio-group>
                      <p>{{ obj.normalContent || '无' }}</p>
                    </el-popover>
                    <el-radio-group
                      v-model="obj.defaultScore"
                      size="medium"
                      fill="#97a8be"
                      v-if="obj.judge == 7 && scored"
                      :disabled="scored"
                    >
                      <el-radio-button
                        :label="val"
                        :value="val"
                        v-for="val in obj.resultsObject"
                        :key="val"
                      ></el-radio-button>
                    </el-radio-group>

                    <template v-if="obj.judge == 8 && !scored">
                      <el-popover placement="right" width="120" trigger="hover">
                        <template slot="reference">
                          <el-radio-group
                            v-model="obj.defaultScore"
                            size="medium"
                            fill="#97a8be"
                          >
                            <el-radio-button :label="'1'">致命</el-radio-button>
                            <el-radio-button :label="'2'">非致命</el-radio-button>
                          </el-radio-group>
                        </template>
                        <p>{{ obj.normalContent || '无' }}</p>
                      </el-popover>
                      <el-popover trigger="hover" placement="right">
                        <template slot="reference">
                          <i class="el-icon-warning" style="color: red"></i>
                        </template>
                        <p>选中致命项则总分为<font color="red"> 零</font></p>
                      </el-popover>
                    </template>
                    <div v-if="obj.judge == 8 && scored">
                      <el-radio-group
                        v-model="obj.defaultScore"
                        :disabled="scored"
                        size="medium"
                        fill="#97a8be"
                      >
                        <el-radio-button :label="'1'">致命</el-radio-button>
                        <el-radio-button :label="'2'">非致命</el-radio-button>
                      </el-radio-group>
                      <i class="el-icon-warning" style="color: red"></i>
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>
            </div>
          </div>
        </div>
      </div>
      <div class="standards_part">
        <h3>
          &nbsp;
        </h3>
        <div class="score">
          <label>总分</label>
          <span class="result">{{ totalScore }}</span>
        </div>
        <div class="standards_detail">
          <div class="classification_part">
            <div class="classification_detail">
              <el-form-item label="质检结果">
                <el-input
                  type="textarea"
                  v-model="handleContent"
                  placeholder="请输入内容"
                  :disabled="scored"
                ></el-input>
              </el-form-item>
            </div>
          </div>
        </div>
      </div>
    </el-form>
  </div>
</template>
<script>
import global from '../../../../global.js'
import qs from 'qs'
let currentBaseUrl = global.qualityUrl
export default {
  props: ['parentModel', 'playInfoVosList'],
  data() {
    return {
      modleTitle: '',
      standardsLists: [],
      typelist: [], // 人工打分标准
      showAddCaseDialog11: false,
      showAddCaseDialog: false,
      ModifyClassDialog: false,
      modelId: '', // 质检模板id
      showHandleContent: '', // 展示质检评分-质检结果
      handleContent: '', // 质检评分-质检结果
      showQualityScore: false, // 是否展示质检评分tab
      isScore: false,
      currentDistribute: [], // 要保存的当前分数列表
      showCurrentDistribute: [], // 当前分数列表
      showScoreObjs: [], // 展示界面的人工质检打分项对象
      scoreObjs: [], // 人工质检打分项对象
      isDead: '2', // 手动评分致命项
      isAutoDead: '2', // 自动评分致命项
      form: {},
      score: '',
      scored: false, // 是否打分完成
      returnVisitMatchResult: [],
    }
  },
  watch: {
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.callId != undefined) {
          this.reSetData()
          this.qamodleScore()
        }
      },
      deep: true,
    },
  },
  computed: {
    autoScore() {
      let total = 0
      this.currentDistribute.forEach(function(item) {
        if (item.deadItem !== '1') {
          total += parseInt(item.score) || 0
        }
      })
      if (this.isAutoDead == '1') {
        return 0
      }
      return total > 0 ? total : 0
    },
    menualScore() {
      let total = 0
      let _this = this
      let flag = true
      this.scoreObjs.forEach(function(item, index) {
        item.forEach(function(temp) {
          if (temp.judge == 6) {
            total += parseInt(temp.defaultScore) || 0
          } else if (temp.judge == 7) {
            if (temp.defaultScore) {
              total += parseInt(temp.defaultScore) || 0
            }
          } else if (temp.judge == 8 && flag) {
            if (temp.defaultScore == '1') {
              // 如果有一项是致命项则所有的非致命项不能生效
              _this.isDead = '1'
            } else {
              _this.isDead = '2'
            }
            flag = false
          }
        })
      })
      if (this.isDead == '1') {
        return 0
      }
      return total > 0 ? total : 0
    },
    totalScore() {
      if (this.isDead == '1' || this.isAutoDead == '1') {
        return 0
      }
      let totalScore =
        this.autoScore + this.menualScore > 0 ? this.autoScore + this.menualScore : 0
      return totalScore
    },
  },
  methods: {
    reSetData() {
      this.standardsLists = []
      this.typelist = [] // 人工打分标准
      this.showAddCaseDialog11 = false
      this.showAddCaseDialog = false
      this.ModifyClassDialog = false
      this.modelId = '' // 质检模板id
      this.showHandleContent = '' // 展示质检评分-质检结果
      this.handleContent = '' // 质检评分-质检结果
      this.showQualityScore = false // 是否展示质检评分tab
      this.isScore = false
      this.currentDistribute = [] // 要保存的当前分数列表
      this.showCurrentDistribute = [] // 当前分数列表
      this.showScoreObjs = [] // 展示界面的人工质检打分项对象
      this.scoreObjs = [] // 人工质检打分项对象
      this.form = {}
      this.score = ''
      this.scored = false // 是否打分完成
      this.returnVisitMatchResult = []
    },
    // 命中场景 点击按钮
    playOccurrence(keywordItem) {
      this.$emit('clickhighlightkeys', keywordItem)
    },
    changeTargetTime(key) {
      let _this = this
      for (let j in _this.scoreDetails) {
        if (key.normalId == _this.scoreDetails[j].normalId) {
          key.targetTime = _this.scoreDetails[j].targetTime
        }
      }
    },
    // 关键词展示
    showKeywordsData() {
      let _this = this
      let array = []
      let newobj = {}
      if (_this.playInfoVosList.length <= 0) {
        return false
      }
      for (let k in _this.standardsLists) {
        let newarray = []
        _this.standardsLists[k].forEach(function(normal) {
          let key = normal
          _this.changeTargetTime(key)
          let reg = /[A-Z()\s]+/
          if (key.judge == 5) {
            if (key.targetTime) {
              let targetTime = ''
              targetTime = key.targetTime
              let target = targetTime.split(',')
              let targetTimeStart = target[0]
              let targetTimeEnd = target[1]
              key.targetTimeStart = targetTimeStart
              key.targetTimeEnd = targetTimeEnd
              for (let n = 0; n < _this.playInfoVosList.length; n++) {
                if (
                  parseInt(_this.playInfoVosList[n].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[n].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.Start = n
                  key.targetTimeStart = _this.playInfoVosList[n].startTime
                  break
                }
              }
              for (let m = _this.playInfoVosList.length - 1; m >= 0; m--) {
                if (
                  parseInt(_this.playInfoVosList[m].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[m].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.End = m
                  key.targetTimeEnd = _this.playInfoVosList[m].endTime
                  break
                }
              }
            } else {
              key.Start = 0
              key.End = _this.playInfoVosList.length - 1
              key.targetTimeStart = '0'
              key.targetTimeEnd = _this.playInfoVosList[key.End].endTime
            }
            let keywordContext = key.resultsObject.keywordContext
            let result = keywordContext.replace(reg, ',')
            while (result.match(reg)) {
              result = result.replace(reg, ',')
            }
            keywordContext = result.trim().split(',')
            let keywordContext1 = []
            let o = 0
            for (let l = 0; l < keywordContext.length; l++) {
              if (keywordContext[l] != '') {
                for (let j = key.Start; j <= key.End; j++) {
                  if (key.resultsObject.roleType == 1) {
                    if (
                      _this.playInfoVosList[j].role == '2' &&
                      _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0
                    ) {
                      keywordContext1[o] = keywordContext[l]
                    }
                  } else if (key.resultsObject.roleType == 2) {
                    if (
                      _this.playInfoVosList[j].role == '1' &&
                      _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0
                    ) {
                      keywordContext1[o] = keywordContext[l]
                    }
                  } else {
                    if (_this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0) {
                      keywordContext1[o] = keywordContext[l]
                    }
                  }
                }
                o++
              }
            }
            key.resultsObject.keyword = []
            keywordContext1.forEach((item) => {
              key.resultsObject.keyword.push({
                keyword: item,
                clickIndex: 0,
                fullScriptRole: key.resultsObject.roleType,
                targetTimeStart: key.targetTimeStart,
                targetTimeEnd: key.targetTimeEnd,
              })
            })
            // // 从_this.scoreDetails里取关键词
            // let keywords = _this.scoreDetails.filter(function (scoreDetail) {
            //   return scoreDetail.normalId == normal.normalId
            // })
            // keywords.forEach(function (mykeyword) {
            //   if (mykeyword.targetTime != '' && mykeyword.targetTime != null) {
            //     key.resultsObject.keyword = []
            //     let keyWordAndTargetTimes = mykeyword.keyWordAndTargetTimes
            //     keyWordAndTargetTimes.forEach(function (keyAndTime) {
            //       let keywordArr = keyAndTime.split('&&')
            //       let timeArr = keywordArr[1].split('||')
            //       key.resultsObject.keyword.push({
            //         keyword: keywordArr[0],
            //         clickIndex: 0,
            //         fullScriptRole: key.resultsObject.roleType,
            //         targetTimeStart: timeArr[0],
            //         targetTimeEnd: mykeyword.targetTime.split(',')[1]
            //       })
            //       // timeArr.forEach(function (starttime) {
            //       //   key.resultsObject.keyword.push({
            //       //     keyword: keywordArr[0],
            //       //     clickIndex: 0,
            //       //     fullScriptRole: key.resultsObject.roleType,
            //       //     targetTimeStart: starttime,
            //       //     targetTimeEnd: mykeyword.targetTime.split(',')[1]
            //       //   })
            //       // })
            //     })
            //   }
            // })
          } else {
            key.resultsObject.keyword = []
          }
          array.push(key)
          newarray.push(key)
        })
        newobj[k] = newarray
      }
      _this.standardsLists = newobj
      _this.$emit('showhighlightscore', array)
    },
    // 获取模板id
    qamodleScore() {
      let _this = this
      let url = currentBaseUrl + '/scoreView/findModelId.do'
      let params = {}
      params.objectId = this.parentModel.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.modelId = response.data
          if (_this.modelId) {
            _this.yulanModleInfoScore() // 获取模板id之后根据模板id获取模板详情
          } else {
            _this.$message({
              type: 'error',
              message: '未获取到模板id',
            })
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取质检模板id失败',
          })
        })
    },
    yulanModleInfoScore(isNeedGetData) {
      let flag = typeof isNeedGetData === 'undefined' ? true : isNeedGetData
      let _this = this
      let url = currentBaseUrl + '/manualQualityAssurance/yulanModleInfoScore.do'
      let params = {}
      params.modleId = this.modelId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.modleTitle = response.data.modle.modleTitle
            _this.standardsLists = response.data.dataT
            let indexT = 0
            for (let key in _this.standardsLists) {
              let obj = _this.standardsLists[key]
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.normalId = item.normalId
                temp.score = item.defaultScore
                if (item.judge === 5) {
                  temp.deadItem = item.resultsObject.deadItem
                } else {
                  temp.deadItem = '2'
                }
                let showtemp = {}
                showtemp.normalId = item.normalId
                showtemp.score = item.defaultScore
                _this.$set(_this.currentDistribute, indexT, temp)
                _this.$set(_this.showCurrentDistribute, indexT, showtemp)
                indexT++
              })
            }
            _this.typelist = response.data.data_hand
            _this.showTypelist = response.data.data_hand
            _this.scoreObjs = []
            _this.showScoreObjs = []
            let index = 0
            for (let item in _this.typelist) {
              // _this.$set(_this.scoreObjs, index, _this.typelist[item])
              let scores = []
              _this.typelist[item].forEach(function(temp) {
                let obj = {}
                for (let key in temp) {
                  obj[key] = temp[key]
                }
                if (temp.judge === 7 && _this.checkArrayType(temp.resultsObject)) {
                  obj.defaultScore = temp.resultsObject[0]
                }
                scores.push(obj)
              })
              _this.$set(_this.showScoreObjs, index, JSON.parse(JSON.stringify(scores)))
              _this.$set(_this.scoreObjs, index, JSON.parse(JSON.stringify(scores)))
              index++
            }
            if (flag) {
              _this.getData()
            }
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取模板失败',
          })
        })
    },
    // 不同页面调用不同的方法获取数据
    getData() {
      // 如果是初检任务，则只给编辑页面赋值即可，如果有则页面不可编辑，完成打分状态
      // 如果没有，则展示模板中的默认打分
      this.getConditonScore(this.parentModel.qaScoreType)
    },
    // 判断数组元素是否都可以转为数字
    checkArrayType(arr) {
      return arr.every(function(val, index, arr) {
        let temp = +val
        return typeof temp === 'number' && !Number.isNaN(temp)
      })
    },
    getConditonScore(qaScoreType) {
      let _this = this
      let url = currentBaseUrl + '/scoreView/getConditonScore.do'
      let params = {}
      params.objectId = _this.parentModel.callId
      // if (qaScoreType == '3') {
      //   params.finalScoreInfo = '1'
      // } else {
      //   params.qaScoreType = qaScoreType
      // }
      if (_this.parentModel.taskStatus == '2') {
        params.qaScoreType = '1'
      } else {
        params.qaScoreType = qaScoreType
      }
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          // 如果获取到了数据则赋值
          if (response.data && response.data.scoreDetails) {
            _this.scoreDetails = response.data.scoreDetails
            // 如果是初检页面，则给编辑界面的值赋值
            _this.scored = true
            _this.changData(_this.scoreDetails)
            _this.handleContent = response.data.score.comments || ''
          } else if (response.data && response.data.score) {
            _this.handleContent = response.data.score.comments
          }
          _this.showKeywordsData()
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数获取失败',
          })
        })
    },
    // 根据获取的分数修改模板内容
    changData(scoreDetails) {
      let _this = this
      let currentDistribute = [] // 自动打分
      let scoreObjs = [] // 手动打分
      currentDistribute = _this.currentDistribute
      scoreObjs = _this.scoreObjs
      scoreDetails.forEach(function(item, index) {
        let isFind = false
        currentDistribute.forEach(function(itm) {
          if (itm.normalId == item.normalId) {
            itm.score = item.score
            isFind = true
          }
        })
        if (!isFind) {
          scoreObjs.forEach(function(itm) {
            itm.forEach(function(obj) {
              if (obj.normalId == item.normalId) {
                if (item.optioniItem || item.optioniItem == 0) {
                  obj.defaultScore = item.optioniItem
                } else {
                  obj.defaultScore = item.score
                }
              }
              console.log(obj)
            })
          })
        }
      })
    },
  },
  created: function() {
    // 根据父页面的参数来回去不同的数据  并产生不同的行为
    this.qamodleScore()
  },
}
</script>
<style lang="less" scoped>
.playClip_btn {
  cursor: pointer;
}
</style>
