import elementMessage from 'element-ui/packages/message'
import throttle from 'lodash/throttle'

let suppressed = false
const noop = () => {}

const throttledMessage = throttle((...args) => {
  console.log(suppressed)

  if (suppressed) {
    noop()
  } else {
    elementMessage(...args)
  }
}, 1000)
;[
  // prettier-ignore

  'success',
  'warning',
  'info',
  'error',
].forEach((type) => {
  throttledMessage[type] = throttle((...args) => {
    console.log(suppressed)
    if (suppressed) {
      noop()
    } else {
      elementMessage[type](...args)
    }
  }, 1000)
})

throttledMessage.suppress = () => (suppressed = !suppressed)

export default throttledMessage
