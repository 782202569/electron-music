<template>
  <div class="recordingPlayContainer">
    <div class="controller_btns">
      <div class="controller_btn" @click="minimizePage">
        <i class="el-icon-minus"></i>
      </div>
      <div class="controller_btn" @click="closePage"><i class="el-icon-close"></i></div>
    </div>
    <el-row>
      <el-col :span="10">
        <div class="leftContainer">
          <div class="info">
            <el-tabs type="border-card">
              <el-tab-pane label="基本信息">
                <div class="infoContent">
                  <div class="info_item">
                    <label>录音编号:</label>
                    <span>{{ esResultModel.callId }}</span>
                  </div>
                  <div class="info_item">
                    <label>坐席工号:</label>
                    <span>{{ esResultModel.seatNo }}</span>
                  </div>
                  <div class="info_item">
                    <label>坐席姓名:</label>
                    <span>{{ esResultModel.seatName }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属角色:</label>
                    <span>{{
                      aclOperVo.roleNames != null ? aclOperVo.roleNames.join(',') : ''
                    }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属部门:</label>
                    <span>{{ aclOperVo.deptName }}</span>
                  </div>
                  <div class="info_item">
                    <label>坐席星级:</label>
                    <span>
                      <el-rate
                        v-model="esResultModel.seatStar"
                        disabled
                        text-color="#ff9900"
                      >
                      </el-rate
                    ></span>
                  </div>
                  <div class="info_item agentLabel">
                    <label>坐席标签:</label>
                    <el-tag
                      :type="color[index % 4]"
                      v-if="item.trim()"
                      v-for="(item, index) in serviceLabels"
                      :key="item"
                      >{{ item }}
                    </el-tag>
                    <el-tag v-if="!serviceLabels || serviceLabels.length == 0"
                      >暂无标签</el-tag
                    >
                  </div>
                </div>
              </el-tab-pane>
              <el-tab-pane label="语音特征">
                <div class="infoContent">
                  <div class="info_item">
                    <label>静默次数:</label>
                    <span>{{ esResultModel.silenceCount }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默时长:</label>
                    <span>{{ esResultModel.silenceLong / 1000 || 0 }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默占比:</label>
                    <span
                      >{{ Math.round(esResultModel.silencePer * 1000) / 10 || 0 }}%</span
                    >
                  </div>
                  <div class="info_item">
                    <label>语音重叠次数:</label>
                    <span>{{ esResultModel.overLap }}</span>
                  </div>
                  <div class="info_item">
                    <label>情绪分值:</label>
                    <span>{{ esResultModel.moodScore }}</span>
                  </div>
                  <div class="info_item">
                    <label>平均语速:</label>
                    <span>{{ Math.round(esResultModel.avgSpeed * 100) / 100 }}字/秒</span>
                  </div>
                  <div class="info_item">
                    <label>最快语速:</label>
                    <span>{{ Math.round(esResultModel.maxSpeed * 100) / 100 }}字/秒</span>
                  </div>
                  <div class="info_item">
                    <label>最长静默:</label>
                    <span>{{ Math.round(esResultModel.maxSilenceLong / 10) / 100 }}</span>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
          <div class="dialog" @mousewheel="test">
            <ul>
              <li
                :class="classes(item.role, item.startTime, item.endTime)"
                v-for="item in playInfoVosList"
                :key="item.startTime"
              >
                <div v-if="item.role == '1'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/seat.png"
                  />
                </div>
                <div v-if="item.role == '2'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/customer.png"
                  />
                </div>
                <div
                  class="dialog-content"
                  v-if="item.role != 'UNK'"
                  @click="playClip(item.startTime)"
                >
                  {{ item.text }}
                </div>
                <div
                  class="content-tag"
                  v-if="item.role == 1 && isShowSpeedFlag(item.speed)"
                >
                  <el-tag :type="item.speed | dealSpeedType(minSpeed, maxSpeed)">
                    {{ item.speed | dealSpeed(minSpeed, maxSpeed) }}
                  </el-tag>
                </div>
                <div v-if="item.role == 'UNK'" class="UNK_text">
                  <el-row>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                    <el-col :span="4">{{ item.text }}</el-col>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                  </el-row>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </el-col>
      <el-col :span="14">
        <div class="rightContainer">
          <el-tabs type="border-card" v-model="activeName">
            <el-tab-pane label="申诉审批" v-if="showQaAppealScore" name="qaappealscore">
              <qaAppealScore
                :parentModel="parentModel"
                :playInfoVosList="playInfoVosList"
                @showhighlightscore="showhighlightscore"
                @clickhighlightkeys="playOccurrence_intelligent"
              ></qaAppealScore>
            </el-tab-pane>
            <el-tab-pane label="申诉评分" v-if="showQaReconsider" name="qareconsider">
              <qaReconsider :parentModel="parentModel"></qaReconsider>
            </el-tab-pane>
            <el-tab-pane
              label="标准分数"
              v-if="showQaCalibrationScore"
              name="qacalibrationscore"
            >
              <qaCalibrationScore :parentModel="parentModel"></qaCalibrationScore>
            </el-tab-pane>
            <el-tab-pane label="校准评分" v-if="showQaCalibration" name="qacalibration">
              <qaCalibration :parentModel="parentModel"></qaCalibration>
            </el-tab-pane>
            <el-tab-pane label="复检评分" v-if="editReQaScore" name="reqascore">
              <reQaScore
                :parentModel="parentModel"
                :playInfoVosList="playInfoVosList"
                @showhighlightscore="showhighlightscore"
                @clickhighlightkeys="playOccurrence_intelligent"
              ></reQaScore>
            </el-tab-pane>
            <el-tab-pane label="质检得分" v-if="showQaQualityScore" name="qaqualityscore">
              <qaQualityScore
                :parentModel="parentModel"
                :playInfoVosList="playInfoVosList"
                @showhighlightscore="showhighlightscore"
                @clickhighlightkeys="playOccurrence_intelligent"
              ></qaQualityScore>
            </el-tab-pane>
            <el-tab-pane label="筛选结果" v-if="showItFilter" name="itfilter">
              <it-filter
                :parentModel="parentModel"
                @highkeywords="getKeyWordsAndHighLight"
                @clickhighlightwords="playOccurrence_intelligent"
              ></it-filter>
            </el-tab-pane>
            <el-tab-pane
              label="匹配结果"
              v-if="showReturnVisitMatchResult"
              name="qamatchresult"
            >
              <qamatchresult :parentModel="parentModel"></qamatchresult>
            </el-tab-pane>
            <el-tab-pane label="复检成绩" v-if="showReQaScore" name="reqascoredetail">
              <reQaScoreDetail
                :parentModel="parentModel"
                :playInfoVosList="playInfoVosList"
                @showhighlightscore="showhighlightscore"
                @clickhighlightkeys="playOccurrence_intelligent"
              ></reQaScoreDetail>
            </el-tab-pane>
            <el-tab-pane label="初检评分" v-if="showInitalQaScore" name="initalqascore">
              <initalQaScore
                :parentModel="parentModel"
                :playInfoVosList="playInfoVosList"
                @showhighlightscore="showhighlightscore"
                @clickhighlightkeys="playOccurrence_intelligent"
              ></initalQaScore>
            </el-tab-pane>
            <el-tab-pane
              label="初检得分"
              v-if="showInitalQaScoreRead"
              name="initalqascoreRead"
            >
              <initalQaScoreRead
                :parentModel="parentModel"
                :playInfoVosList="playInfoVosList"
                @showhighlightscore="showhighlightscore"
                @clickhighlightkeys="playOccurrence_intelligent"
              ></initalQaScoreRead>
            </el-tab-pane>
            <el-tab-pane label="评分轨迹" v-if="showScoringTrajectory">
              <scoringTrajectory :parentModel="parentModel"></scoringTrajectory>
            </el-tab-pane>
            <el-tab-pane label="客户信息" name="custormerinfo">
              <custormerInfo
                :parentModel="parentModel"
                :customInfoModel="customInfoModel"
                :esResultModel="esResultModel"
              ></custormerInfo>
            </el-tab-pane>
          </el-tabs>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import $ from 'jquery'
import global from '../../../global.js'
import qs from 'qs'
import vPlayer from '../../common/player.vue'
import qamatchresult from './play/qaMatchresult.vue'
import custormerInfo from './play/custormerInfo.vue'
import qaReconsider from './play/qaScoreReconsider.vue'
import reQaScore from './play/reQaScore.vue'
import initalQaScore from './play/initalQualityScore.vue'
import initalQaScoreRead from './play/initalQualityScoreRead.vue'
import qaQualityScore from './play/qaQualityScore.vue'
import reQaScoreDetail from './play/reQaScoreDetail.vue'
import scoringTrajectory from './play/scoringTrajectory.vue'
import qaCalibration from './play/qaCalibration.vue'
import qaCalibrationScore from './play/qaCalibrationScore.vue'
import qaAppealScore from './play/qaScoreAppeal.vue'
import itFilter from './play/intelligentFilter.vue'
import throttledMessage from './throttledMessage'

let qualityUrl = global.qualityUrl
let currentBaseUrl = global.currentBaseUrl

export default {
  name: 'recordingPlayNew',
  beforeCreate() {
    this.$message = throttledMessage
  },
  components: {
    vPlayer,
    custormerInfo,
    qamatchresult,
    reQaScore,
    reQaScoreDetail,
    qaReconsider, // 复议-申诉评分
    initalQaScore,
    initalQaScoreRead,
    qaQualityScore,
    scoringTrajectory,
    currentClass: '', // 当前选中录音
    qaCalibration, // 校准会评分
    qaCalibrationScore, // 校准会标准评分
    qaAppealScore,
    itFilter,
  },
  data() {
    return {
      activeName: '',
      playInfoVosList: [], // 通话内容列表
      aclOperVo: {},
      value: 4, // 坐席星级
      serviceLabels: [], // 坐席标签
      customInfoModel: {},
      parentModel: {},
      esResultModel: {
        seatStar: 1,
        callSTime: '',
        callETime: '',
      }, // 基本信息
      showQaAppealScore: false,
      showReturnVisitMatchResult: false,
      showQaReconsider: false,
      showCustrmerInfo: false,
      showInitalQaScore: false,
      showQaCalibration: false,
      showQaCalibrationScore: false,
      showInitalQaScoreRead: false,
      returnVisitMatchResult: [],
      minSpeed: 1, // 最慢语速
      maxSpeed: 10, // 最快语速
      times: [], // 对话时间
      editReQaScore: false, // 复检评分
      showReQaScore: false, // 复检得分
      showQaQualityScore: false,
      showScoringTrajectory: false,
      showItFilter: false,
      focusWord: '', // 要高亮显示的词
      // 智能筛选高亮词
      focusWordIntell: {
        keyword: '',
        clickIndex: 0,
        fullScriptRole: '',
        targetTimeStart: '',
        targetTimeEnd: '',
      },
      // 智能筛选命中词
      keywordCollection: new Set(),
      keywords: [],
      keys: [], // 其他质检评分的命中关键词
      // 是否第一次点击
      isFirst: true,
      currentClass: '', // 当前正在播放的录音内容所在的盒子的class
      color: ['success', 'warning', 'danger', 'gray'],
      hitWords: {
        '1': [],
        '2': [],
        '0': [],
      }, // 智能筛选命中词
    }
  },
  computed: {
    keywordsHigh() {
      if (this.$store.state.keywordsHigh == null) {
        return ''
      } else {
        return this.$store.state.keywordsHigh.keywords
      }
    },
    currentTime() {
      return this.$store.state.playerInfo.currentTime * 1000
    },
    callId() {
      return this.$store.state.recordingPlayPage.callId
    },
    fromUrl() {
      let name = this.$store.state.recordingPlayPage.from
      return name
    },
    fromPage() {
      return this.$store.state.recordingPlayPage.fromPage
    },
    obj() {
      return this.$store.state.recordingPlayPage
    },
    qaScoreType() {
      // 初检还是复检
      return this.$store.state.recordingPlayPage.qaScoreType
    },
  },
  created() {
    this.resetOrderFlag()
    this.setTab(this.obj)
  },
  mounted() {
    this.getPlayInfo() // 获取录音文本信息（对话内容)
  },
  methods: {
    init: function() {
      this.getPlayInfo() // 获取录音文本信息（对话内容）
      this.setTab(this.obj)
    },
    showhighlightscore(keys) {
      this.keys = keys
    },
    getKeyWordsAndHighLight(keywords) {
      this.keywords = keywords
    },
    // 获取开始时间和结束时间，保存到vuex中
    playClip(startTime, endTime) {
      let playInfo = {}
      playInfo.timeSection = [startTime, endTime]
      this.$store.commit('setPlayerInfo', playInfo)
    },
    // 高亮关键词
    hightlightContent(word) {
      this.focusWord = word
    },
    hightlightContentIntell(word) {
      this.focusWordIntell = word
    },
    // 智能筛选的质检分数中设置高亮词 role为custom=>客户，agent=> 客服
    highlightWord(val, oldval, fullScriptRole) {
      let selector = ''
      if (parseInt(fullScriptRole) === 2) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(fullScriptRole) === 1) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let _this = this
      val = val.trim()
      oldval = oldval.trim() || ''
      let elesSelector = document.querySelectorAll(selector)
      if (elesSelector.length === 0) {
        return
      } else {
        elesSelector.forEach(function(item) {
          // 当要高亮显示的文字变化时，先清空原来的高亮
          if (oldval) {
            // 去掉原先的高亮，不能直接用oldval替换，oldval的值有可能是查询条件的值，比如‘你好 or 您好’
            item.innerHTML = item.innerText
            // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, oldval)
          }
          if (val) {
            // 多个高亮
            let keywordArray = val.split(' ')
            keywordArray.forEach(function(keyword) {
              if (keyword != '' && item.innerHTML.indexOf(keyword) != -1) {
                item.innerHTML = item.innerHTML.replace(
                  new RegExp(keyword, 'gm'),
                  '<span style="color: red">' + keyword + '</span>'
                )
                if (
                  _this.hitWords[fullScriptRole] &&
                  _this.hitWords[fullScriptRole].indexOf(keyword) <= 0
                ) {
                  _this.hitWords[fullScriptRole].push(keyword)
                }
              }
            })
          }
        })
      }
    },
    // 智能筛选页面刚刚进来的时候要把所有符合条件的关键词都标红
    highlightWordAll(val) {
      let selector = ''
      if (parseInt(val.fullScriptRole) === 2) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 1) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let eles = document.querySelectorAll(selector)
      if (!eles || eles.length === 0) {
        return
      } else {
        eles.forEach(function(item) {
          let className = item.parentElement.className.split(' ')
          let startTime = parseInt(className[1].substr(1).trim())
          let endTime = parseInt(className[2].substr(1).trim())
          if (!(startTime <= val.targetTimeEnd && endTime >= val.targetTimeStart)) {
            return
          }
          if (item.innerHTML.indexOf(val.keyword) != -1) {
            item.innerHTML = item.innerHTML.replace(
              new RegExp(val.keyword, 'gm'),
              '<span style="color: red">' + val.keyword + '</span>'
            )
          }
        })
      }
    },
    // 播放器缩小
    minimizePage() {
      this.volumeControl = false
      let playInfo = {}
      playInfo.isMaximization = false
      this.isPlayinfo = playInfo.isclosedialog
      let taskId = this.$store.state.returnVisitConfig.taskId
      let projectId = this.$store.state.returnVisitConfig.projectId
      let matchRecordCount = this.$store.state.returnVisitConfig.matchRecordCount
      let allRecordCount = this.$store.state.returnVisitConfig.allRecordCount
      let matchRatio = this.$store.state.returnVisitConfig.matchRatio
      let obj = {
        taskId: taskId,
        showTaskResult: true,
        showDetailPage: true,
        projectId: projectId,
        matchRecordCount: matchRecordCount,
        allRecordCount: allRecordCount,
        matchRatio: matchRatio,
      }
      this.$store.commit('setTaskResult', obj)
      this.$store.commit('setPlayerInfo', playInfo)
      this.$emit('onminimize', playInfo)
    },
    // 播放器关闭
    closePage() {
      let _this = this
      this.$confirm('关闭界面将停止录音播放，确定关闭么', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let playInfo = {}
          playInfo.isMaximization = false
          playInfo.exist = false
          // let url = _this.fromPage || 'home'
          let taskId = _this.$store.state.returnVisitConfig.taskId
          let projectId = _this.$store.state.returnVisitConfig.projectId
          let matchRecordCount = _this.$store.state.returnVisitConfig.matchRecordCount
          let allRecordCount = _this.$store.state.returnVisitConfig.allRecordCount
          let matchRatio = _this.$store.state.returnVisitConfig.matchRatio
          let obj = {
            taskId: taskId,
            showTaskResult: true,
            showDetailPage: true,
            projectId: projectId,
            matchRecordCount: matchRecordCount,
            allRecordCount: allRecordCount,
            matchRatio: matchRatio,
          }
          _this.$store.commit('setTaskResult', obj)
          _this.$store.commit('setPlayerInfo', playInfo)
          _this.focusWord = ''
          _this.keywords = []
          _this.keys = []
          _this.parentModel = {}
          this.$emit('onclose')
        })
        .catch(() => {})
    },
    test() {
      // 停止正在进行的动画  减少卡顿感
      $('.dialog').stop(true, false)
      if (window.myinterVal) {
        return
      } else {
        window.myinterVal = 5
      }
      setTimeout(function() {
        window.myinterVal = 0
      }, 5000)
      // 清除计时任务
      // 3秒后重新
    },
    // 控制tab页显示
    setTab(obj) {
      let parentModel = obj
      this.parentModel = parentModel
      if (obj.from === 'returnVisitConfig') {
        // 回访话术配置
        this.showReturnVisitMatchResult = true
        this.activeName = 'qamatchresult'
      } else if (obj.from === 'myQaTasks') {
        // 我的质检任务
        if (this.qaScoreType == '1') {
          // 初检，均可编辑
          let params = {}
          params.callId = this.callId
          let url = qualityUrl + '/scoreView/isQaed.do'
          let _this = this
          this.axios.post(url, qs.stringify(params)).then(function(response) {
            if (response.data.isQaed) {
              _this.activeName = 'initalqascoreRead'
              _this.showInitalQaScoreRead = true
              _this.showInitalQaScore = false
            } else {
              _this.activeName = 'initalqascore'
              _this.showInitalQaScore = true
              _this.showInitalQaScoreRead = false
            }
          })
          let parentModel = {}
          parentModel.callId = this.callId
          parentModel.seatNo = this.esResultModel.seatNo
          parentModel.fromUrl = 'myQaTasks'
          this.parentModel = parentModel
        } else if (this.qaScoreType == '2') {
          // 复检，初检成绩展示》不可编辑，复检评分》可以编辑
          this.activeName = 'reqascore'
          this.showInitalQaScoreRead = true // 初检成绩展示
          this.editReQaScore = true // 是否显示可编辑的表格
          let parentModel = {}
          parentModel.callId = obj.callId
          parentModel.qaScoreType = 2
          // parentModel.seatNo = this.esResultModel.seatNo
          parentModel.seatNo = obj.seatNo
          parentModel.fromUrl = 'myQaTasks'
          this.parentModel = parentModel
        } else if (this.qaScoreType == '3') {
          // 复议
          this.activeName = 'qareconsider'
          this.parentModel.fromUrl = obj.from
          this.parentModel.callId = obj.callId
          this.parentModel.reTaskId = obj.reTaskId
          this.parentModel.qaScoreType = obj.qaScoreType
          this.showQaReconsider = true
          this.showQaQualityScore = true
        }
        this.showScoringTrajectory = true // 是否显示评分轨迹
      } else if (obj.from === 'taskMonitor') {
        // 任务监控
        if (this.qaScoreType == '2') {
          this.showReQaScore = true // 是否显示可编辑的表格
          this.showInitalQaScoreRead = true
          let parentModel = {}
          parentModel.callId = this.callId
          parentModel.qaScoreType = 2
          parentModel.taskStatus = obj.taskStatus
          parentModel.seatNo = this.esResultModel.seatNo
          parentModel.fromUrl = 'taskMonitor'
          this.parentModel = parentModel
          this.activeName = 'reqascoredetail'
        } else {
          this.activeName = 'initalqascoreRead'
          this.showReQaScore = false
          this.showInitalQaScoreRead = true
        }
        this.showScoringTrajectory = true // 是否显示评分轨迹
      } else if (obj.from === 'scoreResultInfo') {
        // 质检结果查看
        this.parentModel.fromUrl = obj.from
        this.parentModel.callId = obj.callId
        this.parentModel.finalScoreInfo = 1
        this.parentModel.qaScoreType = ''
        this.activeName = 'qaqualityscore'
        this.showQaQualityScore = true
      } else if (obj.from === 'IVSshensuguanli') {
        // 申诉管理
        // this.parentModel = obj
        this.parentModel.fromUrl = obj.from
        this.parentModel.callId = obj.callId
        this.parentModel.qaScoreType = obj.qaScoreType
        this.parentModel.finalScoreInfo = ''
        this.isQa11()
      } else if (obj.from === 'qaCalibration') {
        // 质检校准会
        this.showQaCalibration = true
        this.showQaCalibrationScore = true
        this.activeName = 'qacalibration'
      } else if (obj.from === 'reInspectionSampling') {
        // 复检抽样
        let parentModel = {}
        parentModel.callId = this.callId
        parentModel.qaScoreType = 2
        parentModel.fromUrl = 'reInspectionSampling'
        this.parentModel = parentModel
        this.activeName = 'initalqascore'
        this.showInitalQaScore = true // 初检成绩展示
      } else if (obj.from === 'sysAutoScoringInCallResult') {
        // 系统自动评分
        this.showQaQualityScore = true
        let parentModel = {}
        parentModel.callId = this.callId
        parentModel.qaScoreType = 1
        parentModel.vQaUser = 'system'
        parentModel.fromUrl = 'sysAutoScoringInCallResult'
        this.parentModel = parentModel
        this.activeName = 'qaqualityscore'
      } else if (obj.from === 'task_result') {
        // 智能筛选
        this.activeName = 'itfilter'
        this.showItFilter = true
      } else {
        // 其余模块进来，只有客户信息一个签页 （快速筛选、聚类规则、语音特征统计、人工抽样、样本池、案例管理、我的收藏）
        this.activeName = 'custormerinfo'
      }
    },
    // 重置orderFlag字段
    resetOrderFlag() {
      let obj = {}
      obj.orderId = 'call'
      this.$store.commit('setOrderRecordingPlayPage', obj)
    },
    // 判断是否是质检主管
    isQa11() {
      let _this = this
      let url = qualityUrl + '/csc/isQa.do'
      let params = {}
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.chargeCalibration = !response.data
          if (_this.chargeCalibration) {
            _this.activeName = 'qaqualityscore'
            _this.showQaQualityScore = true // 是否展示质检评分tab
          } else {
            _this.activeName = 'qaappealscore'
            _this.showQaQualityScore = true // 是否展示校准评分tab
            _this.showQaAppealScore = true // 是否展示质检评分tab
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '角色判断失败',
          })
        })
    },
    // 获取录音信息
    getPlayInfo() {
      // 将播放器重置为录音播放器
      let _this = this
      let url = currentBaseUrl + '/speechFeature/getPlayInfo.do'
      let params = {}
      params.callId = this.callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.serviceLabels = response.data.serviceLabels
            _this.customInfoModel = response.data.customerLabels
            _this.playInfoVosList = response.data.playInfoVosList
            _this.insertSort(_this.playInfoVosList)
            _this.times = []
            _this.playInfoVosList.forEach(function(item) {
              _this.times.push(item.startTime)
              _this.times.push(item.endTime)
            })
            _this.$store.commit('setVoiceDetal', _this.playInfoVosList)
            _this.voiceTotalTime = response.data.voiceTotalTime
            _this.esResultModel = response.data.esResultModel
            _this.aclOperVo = response.data.aclOperVo
            _this.minSpeed = response.data.minSpeead
            _this.maxSpeed = response.data.maxSpeed
            let playInfo = {}
            playInfo.voiceTotalTime = _this.voiceTotalTime
            _this.$nextTick(function() {
              _this.$store.commit('setPlayerInfo', playInfo)
              _this.hightlightContent(_this.keywordsHigh) // 获取高亮文本
            })
          } else {
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '录音信息获取失败',
          })
        })
    },
    isShowSpeedFlag(speed) {
      if (speed == '') {
        return false
      } else {
        if (speed > this.maxSpeed || speed < this.minSpeed) {
          return true
        } else {
          return false
        }
      }
    },
    // 对话列表的class
    classes(role, startTime, endTime) {
      let active = ''
      if (+this.currentClass === +startTime || +this.currentClass === +endTime) {
        active = 'currentClass'
      }
      if (role == 2) {
        return 'custom_content _' + startTime + ' _' + endTime + ' ' + active
      } else if (role == 1) {
        return 'agent_content _' + startTime + ' _' + endTime + ' ' + active
      } else {
        return 'UNK _' + startTime
      }
    },
    // 调整滚动条位置， scrollTop = offsetTop + 偏移
    scrollDialog(seconds) {
      let liClass = '._' + seconds
      let ele = document.querySelector(liClass)
      if (ele) {
        let offsetTop = ele.offsetTop
        if (offsetTop < 20) {
          // dialog有10pxpadding
          document.querySelector('.dialog').scrollTop = 0
        } else {
          // document.querySelector('.dialog').scrollTop = offsetTop + 20
          $('.dialog').animate(
            {
              scrollTop: offsetTop - document.querySelector('.dialog').clientHeight / 3,
            },
            500
          )
        }
      }
    },
    // 查找距离当前时间最近的对话内容所在的区域的class， 二分查找
    findCurrentMessage(seconds) {
      if (this.times.indexOf(seconds) != -1) {
        console.log(seconds)
        return seconds
      } else if (seconds < this.times[0]) {
        return this.times[0]
      } else if (seconds > this.times[this.times.length - 1]) {
        return this.times[this.times.length - 1]
      } else {
        let low = 0
        let high = this.times.length - 1
        let closeData = ''
        let diff = 0
        while (low <= high) {
          let mid = parseInt((high + low) / 2)
          if (seconds > this.times[mid]) {
            low = mid + 1
            if (diff == 0) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            } else if (Math.abs(this.times[mid] - seconds) < Math.abs(diff)) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            }
          } else if (seconds < this.times[mid]) {
            high = mid - 1
            if (diff == 0) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            } else if (Math.abs(this.times[mid] - seconds) < Math.abs(diff)) {
              diff = this.times[mid] - seconds
              closeData = this.times[mid]
            }
          } else {
            return this.times[mid]
          }
        }
        return closeData
      }
    },
    // 插入排序
    insertSort(arr) {
      if (Object.prototype.toString.call(arr) !== '[object Array]') {
        return false
      }
      for (let i = 1; i < arr.length; i++) {
        let j = i
        let temp = arr[i]
        while (j > 0 && parseInt(temp.startTime) < parseInt(arr[j - 1].startTime)) {
          arr[j] = arr[--j]
        }
        arr[j] = temp
      }
    },
    playOccurrence_intelligent(keywordItem) {
      // console.log(keywordItem)
      // 单独高亮显示本次关键词的结果
      this.hightlightContentIntell(keywordItem)
      let self = this
      let selectedMsg = null // 当前消息
      let selectedIndex = 0 // 当前匹配的消息数
      let pipeiMsgCount = 0 // 可匹配的消息总数

      // 1.获取此关键字所有的消息数
      self.playInfoVosList.forEach((item) => {
        if (
          parseInt(item.startTime) <= parseInt(keywordItem.targetTimeEnd) &&
          parseInt(item.endTime) >= parseInt(keywordItem.targetTimeStart)
        ) {
          if (parseInt(keywordItem.fullScriptRole) === 1) {
            if (item.role == '2' && item.text.indexOf(keywordItem.keyword) >= 0) {
              pipeiMsgCount++
            }
          } else if (parseInt(keywordItem.fullScriptRole) === 2) {
            if (item.role == '1' && item.text.indexOf(keywordItem.keyword) >= 0) {
              pipeiMsgCount++
            }
          } else {
            if (item.text.indexOf(keywordItem.keyword) >= 0) {
              pipeiMsgCount++
            }
          }
        }
      })

      // 2.获取已选中的消息
      for (let i = 0; i < self.playInfoVosList.length; i++) {
        let item = self.playInfoVosList[i]
        if (
          parseInt(item.startTime) <= parseInt(keywordItem.targetTimeEnd) &&
          parseInt(item.endTime) >= parseInt(keywordItem.targetTimeStart)
        ) {
          if (parseInt(keywordItem.fullScriptRole) === 1) {
            if (item.role == '2' && item.text.indexOf(keywordItem.keyword) >= 0) {
              if (selectedIndex == keywordItem.clickIndex) {
                keywordItem.clickIndex++
                selectedMsg = item
                break
              }
              selectedIndex++
            }
          } else if (parseInt(keywordItem.fullScriptRole) === 2) {
            if (item.role == '1' && item.text.indexOf(keywordItem.keyword) >= 0) {
              if (selectedIndex == keywordItem.clickIndex) {
                keywordItem.clickIndex++
                selectedMsg = item
                break
              }
              selectedIndex++
            }
          } else {
            if (item.text.indexOf(keywordItem.keyword) >= 0) {
              if (selectedIndex == keywordItem.clickIndex) {
                keywordItem.clickIndex++
                selectedMsg = item
                break
              }
              selectedIndex++
            }
          }
        }
      }

      // 3.重制点击数
      if (keywordItem.clickIndex == pipeiMsgCount) {
        keywordItem.clickIndex = 0
      }
      if (selectedMsg != null) {
        self.playClip(selectedMsg.startTime)
      }
    },
    // 智能筛选命中词点击
    highlightWordIntell(val, oldval) {
      let selector = ''
      if (parseInt(val.fullScriptRole) === 2) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 1) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let _this = this
      let eles = document.querySelectorAll(selector)
      if (!eles || eles.length === 0) {
        return
      } else {
        // 第一次点击的时候先把全部的关键词都替换掉
        if (_this.isFirst) {
          console.log(_this.keywordCollection)
          document
            .querySelectorAll('div.dialog ul li .dialog-content')
            .forEach(function(item) {
              for (let i of _this.keywordCollection) {
                if (item.innerHTML.indexOf(i.keyword) != -1) {
                  // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, i.keyword)
                  item.innerHTML = item.innerHTML
                    .replace(/<span style="color: red">/g, '')
                    .replace(/<\/span>/g, '')
                }
              }
            })
          _this.isFirst = false
        } else {
          // 如果不是第一次点击关键词的时候把上次的关键词红色去除
          if (oldval) {
            // 当要高亮显示的文字变化时，先清空原来所有的高亮
            document
              .querySelectorAll('div.dialog ul li .dialog-content')
              .forEach(function(item) {
                // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, oldval.keyword)
                item.innerHTML = item.innerHTML
                  .replace(/<span style="color: red">/g, '')
                  .replace(/<\/span>/g, '')
              })
          }
        }
        eles.forEach(function(item) {
          let className = item.parentElement.className.split(' ')
          let startTime = parseInt(className[1].substr(1).trim())
          let endTime = parseInt(className[2].substr(1).trim())
          if (!(startTime <= val.targetTimeEnd && endTime >= val.targetTimeStart)) {
            return
          }
          if (item.innerHTML.indexOf(val.keyword) != -1) {
            item.innerHTML = item.innerHTML.replace(
              new RegExp(val.keyword, 'gm'),
              '<span style="color: red">' + val.keyword + '</span>'
            )
          }
        })
      }
    },
  },
  watch: {
    currentTime(val) {
      this.currentClass = this.findCurrentMessage(val - 250)
      this.scrollDialog(this.currentClass)
    },
    focusWord(val, oldval) {
      this.highlightWord(val, oldval, '0')
    },
    focusWordIntell: {
      handler: function(val, oldval) {
        this.highlightWordIntell(val, oldval)
      },
      deep: true, // 对象内部的属性监听，也叫深度监听
    },
    playInfoVosList() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.fromUrl == 'task_result' && this.keywords && this.keywords.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keywords.forEach(function(item, index) {
            if (item.keywordContext.indexOf('NOT') == -1) {
              let temp = item.keywordContext.replace(/([\\(\\)])*(AND)*(OR)*/g, '')
              temp.split(' ').forEach(function(i) {
                if (i) {
                  // self.highlightWord(i, '', item.fullScriptRole)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      }
    },
    keywords() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.fromUrl == 'task_result' && this.keywords && this.keywords.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keywords.forEach(function(item, index) {
            if (item.keywordContext.indexOf('NOT') == -1) {
              item.targetContent.forEach(function(i) {
                if (i) {
                  self.keywordCollection.add(i)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      }
    },
    keys() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.keys && this.keys.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keys.forEach(function(item, index) {
            if (
              item.judge == 5 &&
              item.resultsObject.keywordContext.indexOf('NOT') == -1
            ) {
              item.resultsObject.keyword.forEach(function(i) {
                if (i) {
                  self.keywordCollection.add(i)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      }
    },
  },
  filters: {
    dealSpeed(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return '过慢'
      } else if (val > maxSpeed) {
        return '过快'
      }
    },
    dealSpeedType(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return 'danger'
      } else if (val > maxSpeed) {
        return 'primary'
      }
    },
  },
}
</script>
<style lang="less">
@borderColor: #c3ccd9;
@playerHeight: 50px;
@infoHeight: 190px;
@controlBtnsHeight: 40px;
.recordingPlayContainer {
  width: 100%;
  height: 100%;
  position: relative;
  & > .controller_btns {
    position: absolute;
    width: 100px;
    line-height: 40px;
    top: 0px;
    right: 0px;
    z-index: 999;
    text-align: right;
    padding-right: 10px;
    .controller_btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      line-height: 24px;
      border-radius: 50%;
      margin-left: 5px;
      text-align: center;
      background: #c3ccd9;
      color: #fff;
      &:hover {
        cursor: pointer;
      }
    }
  }
  & > .el-row {
    height: 100%;
    border-top: 1px solid @borderColor;
    & > .el-col {
      height: 100%;
      position: relative;
    }
  }
  // 修改tab组件样式
  .el-tabs__item.is-active {
    color: #1f2d3d !important;
    font-size: 14px;
    font-weight: bold;
  }
  .el-tabs--border-card {
    border: none;
    height: 100%;
    position: relative;
    & > div {
      border: none;
    }
    & > .el-tabs__header {
    }
    & > .el-tabs__content {
      position: absolute;
      top: 40px;
      left: 0;
      right: 0;
      bottom: 0;
      overflow-y: auto;
      & > .el-tab-pane {
        height: 100%;
      }
    }
    & > .el-tabs__header .el-tabs__item {
      border: none;
    }
  }

  // 修改tab组件样式结束
  .leftContainer,
  .rightContainer {
    position: absolute;
    right: 0;
    left: 0;
    top: 0;
    bottom: 0;
  }
  .leftContainer {
    .info {
      height: @infoHeight;
      .infoContent {
        height: 100%;
        .info_item {
          width: 50%;
          float: left;
          line-height: 30px;
          color: #8691a5;
          font-size: 14px;
          .el-rate {
            display: inline-block;
            margin-left: 5px;
            vertical-align: middle;
          }
          span.el-tag {
            margin-right: 2px;
          }
          &.agentLabel {
            width: 100%;
            .el-tag {
              margin-right: 5px;
            }
          }
        }
      }
    }
    .dialog {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      top: @infoHeight;
      overflow-y: auto;
      padding: 10px;
      background: #eef1f6;
      & > ul {
        position: relative;
        & > li {
          overflow: hidden;
          margin: 10px 0px;
          .avatar {
            width: 46px;
            height: 46px;
            line-height: 46px;
            border-radius: 23px;
            border: 1px solid @borderColor;
            text-align: center;
            background: #fff;
          }
          .dialog-content {
            background: #fff;
            padding: 10px 15px;
            line-height: 20px;
            border-radius: 5px;
            margin-left: 15px;
            position: relative;
            max-width: 280px;
            margin-top: 5px;
            cursor: pointer;
          }
          .content-tag {
            margin-top: 15px;
          }
          &.custom_content {
            div {
              float: left;
            }
            .dialog-content {
              background: #fff;
              &::before {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #fff;
                position: absolute;
                top: 10px;
                left: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.agent_content {
            div {
              float: right;
            }
            .dialog-content {
              margin-left: 10px;
              margin-right: 15px;
              background: #9eea6a;
              color: #000000;
              &::after {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #9eea6a;
                position: absolute;
                top: 10px;
                right: -6px;
                transform: rotate(45deg);
              }
            }
          }
          // 当前正在播放的对话内容样式
          &.currentClass {
            .dialog-content {
              background: #22b8fe;
              color: #000000;
              &::after {
                background: #22b8fe;
              }
              &::before {
                background: #22b8fe;
              }
            }
          }
          &.UNK {
            div {
              text-align: center;
              display: block;
              color: #97a8be;
            }
            div.line {
              width: 100%;
              height: 15px;
              background: url('../../../assets/img/unk.png') no-repeat;
              background-position: center;
            }
          }
        }
      }
    }
    #lrc_list {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      top: @infoHeight;
      overflow-y: auto;
      padding: 10px;
      background: #eef1f6;
      & > ul {
        position: relative;
        & > li {
          overflow: hidden;
          margin: 10px 0px;
          .avatar {
            width: 46px;
            height: 46px;
            line-height: 46px;
            border-radius: 23px;
            border: 1px solid @borderColor;
            text-align: center;
            background: #fff;
          }
          .dialog-content {
            background: #fff;
            padding: 10px 15px;
            line-height: 20px;
            border-radius: 5px;
            margin-left: 15px;
            position: relative;
            max-width: 280px;
            margin-top: 5px;
          }
          .content-tag {
            margin-top: 15px;
          }
          &.custom_content {
            div {
              float: left;
            }
            .dialog-content {
              background: #fff;
              &::before {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #fff;
                position: absolute;
                top: 10px;
                left: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.agent_content {
            div {
              float: right;
            }
            .dialog-content {
              margin-left: 10px;
              margin-right: 15px;
              background: #9eea6a;
              color: #000000;
              &::after {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #9eea6a;
                position: absolute;
                top: 10px;
                right: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.UNK {
            div {
              text-align: center;
              display: block;
              color: #97a8be;
            }
            div.line {
              width: 100%;
              height: 15px;
              background: url('../../../assets/img/unk.png') no-repeat;
              background-position: center;
            }
          }
        }
      }
    }
  }
  .rightContainer {
    .infoForm {
      height: 100%;
      .detailInfoContents_part {
        border-bottom: 1px dashed @borderColor;
        .detailInfoContentsInputs {
          padding: 10px;
          .el-form-item > label {
            font-size: 14px;
            color: #8691a5;
          }
        }
        h3 {
          padding-left: 10px;
          line-height: 30px;
          font-size: 14px;
          color: #9dadc2;
          font-weight: normal;
        }
      }
    }
    .el-date-editor.el-input {
      width: 100%;
    }
    .el-select {
      width: 100%;
    }
    .operation {
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      padding: 0px 10px 0px 0px;
      border-bottom: 1px dashed @borderColor;
      position: absolute;
      top: 0px;
      left: 10px;
      right: 10px;
      h3 {
        width: 65px;
        float: left;
        font-size: 14px;
        color: #5e6d82;
        font-weight: normal;
      }
    }
    .btns {
      float: right;
      button {
        width: 90px;
      }
      margin: 10px;
    }
    .standards_parts {
      position: absolute;
      top: 10px;
      right: 0px;
      left: 0px;
      bottom: 0px;
      overflow-y: auto;
      .standards_part {
        border-bottom: 1px dotted @borderColor;
        margin: 0 10px;
        position: relative;
        h3 {
          padding-left: 10px;
          line-height: 30px;
          font-size: 14px;
          color: #1f2d3d;
          font-weight: normal;
        }
        .standards_detail {
          padding: 10px;
          .classification_part {
            margin: 0 10px;
            h3 {
              padding-left: 10px;
              line-height: 30px;
              font-size: 14px;
              color: #9dadc2;
              font-weight: normal;
            }
            .classification_detail {
              padding: 10px;
              .el-form-item > label {
                font-size: 14px;
                color: #8691a5;
              }
            }
          }
          .normalNameClass {
            line-height: 30px;
            color: #9dadc2;
            font-size: 14px;
          }
        }
        &.noBorder {
          border-bottom: none;
          & > p {
            font-size: 14px;
            margin-bottom: 10px;
          }
        }
        .btns {
          margin: 10px;
        }
      }
      .score {
        width: 150px;
        line-height: 30px;
        position: absolute;
        right: 10px;
        top: 0px;
        text-align: right;
        label {
          display: inline-block;
          width: 100px;
          font-size: 14px;
          color: #1f2d3d;
          line-height: 30px;
        }
        span {
          display: inline-block;
          width: 35px;
          font-size: 18px;
          color: red;
          line-height: 30px;
        }
        .result {
          color: #85ce61;
        }
      }
      .selectInspector {
        width: 120px;
        line-height: 30px;
        position: absolute;
        right: 145px;
        top: 6px;
      }
      &.screening {
        top: 10px;
      }
      &.appealScore {
        h3 {
          color: #9dadc2;
        }
        label {
          color: #8691a5;
        }
      }
    }
  }
  .score_result {
    width: 35px;
    font-size: 18px;
    color: #85ce61;
    line-height: 30px;
  }
  .btns {
    text-align: right;
    button {
      width: 90px;
    }
  }
  .contentLeft,
  .contentRight {
    border: 1px solid @borderColor;
  }
  .el-dialog__body {
    padding-top: 10px;
    .footer {
      margin-top: 10px;
    }
  }
  .dialogTitle {
    color: #8691a5;
    font-size: 14px;
    font-weight: normal;
    box-sizing: border-box;
    height: 50px;
    line-height: 50px;
    padding: 0px 10px;
    border-bottom: 1px dotted @borderColor;
    .btns button {
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      padding: 0px;
    }
  }
  .hidden {
    display: none;
  }
}
</style>
