<template>
  <el-dialog
    title="查看词相关"
    :visible.sync="lookWordModal"
    @close="close"
    :close-on-click-modal="false"
  >
    <div style="height: 500px;">
      <div id="ciChart" style="width: 100%; height: 100%;"></div>
    </div>
  </el-dialog>
</template>
<script>
import global from '@/global'
let currentBaseUrl = global.currentBaseUrl
import Qs from 'qs'
let myChartCi
export default {
  data() {
    return {
      lookWordModal: false,
      cioption: {
        title: {
          text: '', // 标题
        },
        label: {
          normal: {
            show: true,
            textStyle: {
              fontSize: 12,
            },
          },
        },
        // 全局颜色，图例、节点、边的颜色都是从这里取，按照之前划分的种类依序选取
        // color: ['rgb(194,53,49)', 'rgb(178,144,137)', 'rgb(97,160,168)'],
        // sereis的数据: 用于设置图表数据之用
        series: [
          {
            name: '', // 系列名称
            type: 'graph', // 图表类型
            layout: 'force', // echarts3的变化，force是力向图，circular是和弦图
            symbolSize: 45,
            // focusNodeAdjacency: true,  // 突出相关
            force: {
              // gravity: 0.1,
              // symbol: 'pin',
              edgeLength: [100, 10], // 线的长度，这个距离也会受 repulsion，支持设置成数组表达边长的范围
              repulsion: 200, // 节点之间的斥力因子。值越大则斥力越大
            },
            // draggable: true, // 指示节点是否可以拖动
            roam: true, // 是否开启鼠标缩放和平移漫游。默认不开启。如果只想要开启缩放或者平移，可以设置成 'scale' 或者 'move'。设置成 true 为都开启
            label: {
              // 图形上的文本标签，可用于说明图形的一些数据信息
              normal: {
                show: true, // 显示
                color: '#fff',
                position: 'inside', // 相对于节点标签的位置
                // 回调函数，你期望节点标签上显示什么
                formatter: function(params) {
                  return params.data.label
                },
              },
            },
            // 节点的style
            itemStyle: {
              normal: {
                label: { show: true },
                nodeStyle: {
                  brushType: 'both',
                  borderColor: 'rgba(255,215,0,0.4)',
                  borderWidth: 1,
                },
              },
            },
            // 关系边的公用线条样式
            lineStyle: {
              normal: {
                width: 3,
                type: 'solid',
                show: true,
                color: 'target', // 决定边的颜色是与起点相同还是与终点相同
                curveness: 0.3, // 边的曲度，支持从 0 到 1 的值，值越大曲度越大。
              },
            },
            categories: [],
            nodes: [],
            links: [],
          },
        ],
      },
    }
  },
  props: ['keys', 'links', 'categories', 'nodesData'],
  /* props: {
    keys: {
      type: String,
      required: true
    },
    links: {
      type: Array,
      required: true
    },
    categories: {
      type: Array,
      required: true
    },
    nodesData: {
      type: Array,
      required: true
    }
  }, */
  computed: {
    loadData() {
      console.log(this.keys)
    },
    address() {
      const { links, categories, nodesData } = this
      return {
        links,
        categories,
        nodesData,
      }
    },
  },
  watch: {
    loadData(val, oldval) {},
    address: {
      handler: function(newval, oldval) {
        if (this.keys !== '' && this.keys !== undefined) {
          this.getci(this.keys)
        }
      },
      deep: true,
    },
  },
  methods: {
    close() {
      this.showWordModal = false
    },
    // 点击热词 展开相关词语
    getci(word) {
      let _this = this
      // 词相关数据画布渲染
      setTimeout(function() {
        myChartCi = _this.$echarts.init(document.getElementById('ciChart'))
        _this.cioption.series[0].nodes = _this.nodesData
        _this.cioption.series[0].categories = _this.categories
        _this.cioption.series[0].links = _this.links
        myChartCi.setOption(_this.cioption)
        myChartCi.off('click')
        myChartCi.on('click', function(params) {
          let paramsList = params
          _this.getClick(paramsList)
        })
      }, 300)
    },
    // 词 点击事件
    getClick: function(paramsList) {
      let dataP = paramsList.data
      if (dataP != null && dataP != undefined) {
        let cid = dataP.category
        let pid = dataP.id
        let params = {}
        params.word = paramsList.data.label
        this.axios
          .post(currentBaseUrl + '/hotAnlys/getRelatedWords.do', Qs.stringify(params))
          .then((res) => {
            if (res.data.length > 0) {
              if (dataP.ignore == true) {
                console.log('重复')
                return
              }
              // 得到links最后一个target
              let tcount = myChartCi.getOption().series[0].links.pop().target
              let ncount = myChartCi.getOption().series[0].nodes.pop().id
              // let ssize = paramsList.data.symbolSize
              let catCount = myChartCi.getOption().series[0].nodes.pop().id

              let nums
              if (res.data.length >= 15) {
                nums = 15
              } else {
                nums = res.data.length
              }
              // 重组数组
              let word = []
              if (cid === 0) {
                for (let i = 0; i < nums; i++) {
                  word[i] = {
                    id: i + 1,
                    category: cid + 1,
                    label: res.data[i].name,
                    name: i + 1,
                    symbolSize: res.data[i].score * 90,
                    ignore: false,
                    flag: true,
                  }
                }
              } else {
                let wAdd
                wAdd = ncount + 1
                for (let i = 0; i < nums; i++) {
                  word[i] = {
                    id: wAdd,
                    category: cid + 1,
                    label: res.data[i].name,
                    name: wAdd,
                    symbolSize: res.data[i].score * 90,
                    ignore: false,
                    flag: true,
                  }
                  wAdd = wAdd + 1
                }
              }
              // 设置点击过得词语不能再次查询
              let worddata = myChartCi.getOption().series[0].nodes.concat(word)
              worddata[pid].ignore = true
              // links
              let links = []
              // let sid = 0
              if (cid === 0) {
                // sid = 0
                for (let i = 0; i < nums; i++) {
                  links[i] = {
                    source: pid,
                    target: i + 1,
                  }
                }
              } else {
                // sid = sid + 1
                let lAdd
                lAdd = tcount + 1
                for (let i = 0; i < nums; i++) {
                  links[i] = {
                    source: pid,
                    target: lAdd,
                  }
                  lAdd = lAdd + 1
                }
              }
              let linksdata = myChartCi.getOption().series[0].links.concat(links)
              // categories
              let categories = []
              if (cid === 0) {
                for (let i = 0; i < nums; i++) {
                  categories[i] = {
                    id: i + 1,
                    name: i + 1 + '层',
                  }
                }
              } else {
                let cAdd
                cAdd = catCount + 1
                for (let i = 0; i < nums; i++) {
                  categories[i] = {
                    id: cAdd,
                    name: cAdd + '层',
                  }
                  cAdd = cAdd + 1
                }
              }
              let cdata = myChartCi.getOption().series[0].categories.concat(categories)
              myChartCi.setOption({
                series: [
                  {
                    links: linksdata,
                    nodes: worddata,
                    categories: cdata,
                  },
                ],
              })
            } else {
              console.log(null)
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
  },
}
</script>
<style lang="less" scoped></style>
