<!--
 - 用于添加关键词录音标签的通用组件
 - 使用说明
 - 需要的props请看props
 - close、open、closed事件对应dialog的事件
 - submited事件为用户成功提交数据后的事件
 -->
<template>
  <el-dialog
    :visible="showDialog"
    :title="dialogTitle"
    :close-on-click-modal="false"
    :width="'1000px'"
    @close="$emit('close')"
    @open="onOpen"
    @closed="$emit('closed')"
  >
    <div class="container" style="height: 500px; overflow-y: auto;">
      <div class="container" v-loading="loadingCount > 0">
        <el-form :rules="rules" ref="form" label-position="left" :model="form">
          <div style="height: 20px"></div>
          <div class="form-row">
            <el-row>
              <el-col :span="12">
                <el-form-item label="标签名称" prop="labelName">
                  <el-input style="width: 180px" v-model.trim="form.labelName"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="所属分类" prop="selectedOptions3">
                  <el-cascader
                    :options="options"
                    :change-on-select="true"
                    :show-all-levels="false"
                    @change="casCaderChange"
                    v-model="form.selectedOptions3"
                  ></el-cascader>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
          <div class="line"></div>

          <div class="section-title">
            周期（天）
          </div>
          <el-form-item label="首次执行时间" prop="startLabelDateRange">
            <el-date-picker
              v-model="form.startLabelDateRange"
              type="datetime"
              placeholder="选择首次执行时间范围"
            >
            </el-date-picker>
          </el-form-item>
        </el-form>
        <div class="line"></div>

        <div class="section-title">
          语音特征
        </div>
        <el-form :inline="true">
          <el-row>
            <el-col :span="12">
              <el-form-item style="margin-top: 10px" label="重叠次数">
                <el-input
                  style="width: 70px"
                  v-model="form.overlapMin"
                  placeholder="次"
                ></el-input>
                <span>-</span>
                <el-input
                  style="width: 70px"
                  v-model="form.overlapMax"
                  placeholder="次"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                label-width="120px"
                label-position="left"
                style="margin-top: 10px;"
                label="坐席平均语速"
              >
                <el-input
                  style="width: 70px"
                  v-model="form.avgSpeedMin"
                  placeholder="字/秒"
                ></el-input>
                <span>-</span>
                <el-input
                  style="width: 70px"
                  v-model="form.avgSpeedMax"
                  placeholder="字/秒"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item style="margin-top: 10px;" label="静默特征">
                <el-select
                  v-model="form.silenceType"
                  clearable
                  placeholder="请选择"
                  style="width: 100px"
                >
                  <el-option
                    v-for="item in silenceTypeList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                label="时长"
                v-if="form.silenceType === '1'"
                label-width="120px"
                label-position="left"
                style="margin-top: 10px;"
              >
                <el-input
                  style="width: 70px"
                  v-model="form.silenceLongMin"
                  placeholder="秒"
                ></el-input>
                <span>-</span>
                <el-input
                  style="width: 70px"
                  v-model="form.silenceLongMax"
                  placeholder="秒"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                label="次数"
                v-if="form.silenceType === '2'"
                style="margin-top: 10px;margin-left: 80px"
              >
                <el-input-number
                  style="width: 70px"
                  controls-position="right"
                  class="urty-ui__number"
                  v-model="form.silenceTimeMin"
                  :min="1"
                  :max="999"
                ></el-input-number>
                <span>-</span>
                <el-input-number
                  style="width: 70px"
                  controls-position="right"
                  class="urty-ui__number"
                  v-model="form.silenceTimeMax"
                  :min="1"
                  :max="999"
                ></el-input-number>
                <span>次</span>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                label="占比"
                v-if="form.silenceType === '3'"
                style="margin-top: 10px;margin-left: 80px"
              >
                <el-input style="width: 70px" v-model="form.silencePerMin"></el-input>
                <span>-</span>
                <el-input style="width: 70px" v-model="form.silencePerMax"></el-input>
                <span>%</span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div class="line"></div>

        <div class="section-title">
          关键词 &nbsp; &nbsp;

          <el-popover placement="right" width="400" trigger="click">
            <div class="rules" style="background: #fff">
              1."AND"关键字表示"与"的关系，可以匹配到同时存在关键字左右两个关键词<br />
              2."OR"关键字表示"或"的关系，可以匹配到存在关键字左右其中至少一个关键词<br />
              3."NOT"关键字表示"非"的关系，可以匹配到存在不存在关键字右侧的关键词<br />
              4."BEFORE"关键字表示有先后顺序"临近"的关系，可以匹配到存在关键字右侧的关键词且之前的n个词内会存在关键字左侧的关键词<br />
              5."AFTER"关键字表示有先后顺序"临近"的关系，可以匹配到存在关键字右侧的关键词且之前的n个词内会存在关键字左侧的关键词<br />
              6."NEAR"关键词表示有临近关系<br />
              7."()"可以在括号中使用以上关键字并提高关键字的匹配优先级<br />
            </div>
            <a
              slot="reference"
              href="javascript: void(0);"
              style="text-decoration: underline"
            >
              术语规则
            </a>
          </el-popover>
        </div>
        <br />

        <div class="keyWords">
          <div v-if="this.editType === 'edit'">
            <div
              style="overflow: hidden; width: 100%;"
              v-for="word in form.keyWords"
              :key="word.scriptKeywordId"
            >
              <div class="content">
                <span v-if="word.fullScriptRole === '0'">出自全部</span>
                <span v-if="word.fullScriptRole === '1'">出自客服</span>
                <span v-if="word.fullScriptRole === '2'">出自客户</span>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <span>{{ word.keywordContext }}</span>
              </div>
              <div class="operations">
                <el-button type="text" @click="editKeyWord(word.scriptKeywordId)"
                  >编辑</el-button
                >
                &nbsp;
                <el-button type="text" @click="deleteKeyWord(word.scriptKeywordId)"
                  >删除</el-button
                >
              </div>
            </div>
          </div>
          <div v-else>
            <div
              style="overflow: hidden; width: 100%;"
              v-for="word in form.keyWords"
              :key="word.scriptKeywordId"
            >
              <div class="content">
                <span
                  >出自{{
                    fullScriptRoleList.find((item) => item.value === word.fullScriptRole)
                      .label
                  }}</span
                >
                &nbsp;&nbsp;&nbsp;&nbsp;
                <span>{{ word.keywordContext }}</span>
              </div>
              <div class="operations">
                <el-button type="text" @click="editKeyWord(word.scriptKeywordId)"
                  >编辑</el-button
                >
                &nbsp;
                <el-button type="text" @click="deleteKeyWord(word.scriptKeywordId)"
                  >删除</el-button
                >
              </div>
            </div>
          </div>
        </div>

        <el-button
          @click="addKeyWordFormShow = true"
          :disabled="addKeyWordFormShow"
          plain
          style="width: 88px; height: 36px;"
        >
          <i class="el-icon-plus"></i>
        </el-button>
        <div class="addKeyWordPlane" v-if="addKeyWordFormShow">
          <el-form :model="keyWordForm" ref="keyWordForm" :rules="keyWordFormRules">
            <el-form-item
              label="关键词出自"
              style="width: 186px; margin-top: 10px;margin-left: 10px"
            >
              <el-select
                v-model="keyWordForm.fullScriptRole"
                placeholder="请选择"
                style="width: 100px"
              >
                <el-option
                  v-for="item in fullScriptRoleList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>

            <a
              href="javascript: void(0)"
              v-show="!addKeyWordShow"
              @click.prevent="showAddKeyWordForm"
              >+添加静默条件</a
            >

            <div v-if="addKeyWordShow" class="demo-ruleForm">
              <div>
                <el-form-item label="静默类型">
                  <el-select
                    @change="selectChange"
                    v-model="keyWordForm.silenceType"
                    placeholder="请选择"
                  >
                    <el-option
                      v-for="item in keyWordForm.silenceList"
                      :label="item.label"
                      :key="item.value"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item
                  class="w-218"
                  label="目标静默时长"
                  prop="silenceTime"
                  v-show="this.selectVaule === false"
                >
                  <el-input-number
                    style="width: 70px"
                    controls-position="right"
                    class="urty-ui__number"
                    v-model="keyWordForm.silenceTimeMin"
                    :min="1"
                    :max="999"
                  ></el-input-number>
                  ~
                  <el-input-number
                    style="width: 70px"
                    controls-position="right"
                    class="urty-ui__number"
                    v-model="keyWordForm.silenceTimeMax"
                    :min="1"
                    :max="999"
                  ></el-input-number>
                </el-form-item>
              </div>
              <div style="overflow: hidden">
                <el-form-item prop="sceneTime">
                  第
                  <el-input-number
                    style="width: 70px"
                    controls-position="right"
                    class="urty-ui__number"
                    v-model="keyWordForm.sceneTime"
                    :min="1"
                    :max="999"
                  ></el-input-number>
                  次静默
                  <el-select style="width: 80px;" v-model="keyWordForm.sceneType">
                    <el-option
                      v-for="(item, index) in sceneTypes"
                      :label="item.label"
                      :key="index"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                  <el-input-number
                    style="width: 70px"
                    controls-position="right"
                    class="urty-ui__number"
                    v-model="keyWordForm.sceneValue"
                    :min="1"
                    :max="999"
                  ></el-input-number>
                  <el-select style="width: 73px;" v-model="keyWordForm.sceneValueType">
                    <el-option
                      v-for="(item, index) in sceneNumTimes"
                      :label="item.label"
                      :key="index"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                  处出现关键词
                </el-form-item>
                <a
                  href="javascript: void(0)"
                  @click="deleteKeyWordOption"
                  style="float: right;"
                  >删除条件</a
                >
              </div>
            </div>
            <div v-if="this.existTopicData.length > 0">
              <div class="tuijianCi">推荐关键词</div>
              <div class="addKey">
                <div class="keyWorldpos">
                  <div
                    plain
                    class="spanStyle"
                    :key="index"
                    v-for="(item, index) in existTopicData"
                    @click="insertAtCursor(item)"
                  >
                    {{ item }}
                  </div>
                </div>
              </div>
            </div>
            <div class="addKey">
              <el-form-item prop="keywordContext">
                <div class="keyWorld">
                  <textarea
                    id="keywordZuhe"
                    ref="keywordContextTextarea"
                    style="resize: none;width:100%;height:140px;border:1px solid #ddd;border-radius:4px;padding-left:10px;padding-top:10px;box-sizing:border-box;padding-bottom:50px"
                    v-model="keyWordForm.keywordContext"
                  ></textarea>
                  <div class="keyWorldpos">
                    <div plain class="spanStyle" @click="insertAtCursor('OR')">OR</div>
                    <div plain class="spanStyle" @click="insertAtCursor('AND')">AND</div>
                    <div plain class="spanStyle" @click="insertAtCursor('NOT')">NOT</div>
                    <div plain class="spanStyle" @click="insertAtCursor('NEAR')">
                      NEAR
                    </div>
                    <div plain class="spanStyle" @click="insertAtCursor('BEFORE')">
                      BEFORE
                    </div>
                    <div plain class="spanStyle" @click="insertAtCursor('AFTER')">
                      AFTER
                    </div>
                    <div plain class="spanStyle" @click="insertAtCursor('()')">()</div>
                  </div>
                </div>
              </el-form-item>
            </div>
          </el-form>
          <div class="btns">
            <el-button type="primary" @click="addKeywordSubmit">提交</el-button>
            <el-button @click="cancelKeywordSubmit">取消</el-button>
          </div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer" style="float: right; margin-top: 10px;">
        <el-button @click="cancelAddRecordLabel">取消</el-button>
        <el-button
          type="primary"
          @click="submitRecordLabel"
          :disabled="addKeyWordFormShow"
          >确定</el-button
        >
      </span>
    </div>
  </el-dialog>
</template>
<script>
import $ from 'jquery'
import global from '@/global'
import Qs from 'qs'
import commonUtil from '@/utils/commonUtil.js'
import { validModelTrim } from '@/utry-sdk/common/constants'
const deleteEmptyChildren = function deleteEmptyChildren(treeArr) {
  if (!treeArr) {
    return
  }
  treeArr.forEach((item) => {
    if (item.children && item.children instanceof Array && item.children.length > 0) {
      deleteEmptyChildren(item.children)
    } else {
      delete item.children
    }
  })
}

const requestUrls = {
  getAllDataByLabelIdUrl: global.currentBaseUrl + '/recordLabel/findByLabelId.do',
  getAllDataByTemplateId: global.currentBaseUrl + '/recordLabel/findByTemplateId.do',
  getTemplatesUrl: global.currentBaseUrl + '/pageConstant/getValue.do?keys=fullModel',
  saveLabelUrl: global.currentBaseUrl + '/recordLabel/addRecordLabel.do',
  copyTemplateUrl: global.currentBaseUrl + '/recordLabel/copyTemplate.do',
  getTreeDataUrl: global.currentBaseUrl + '/recordLabelClass/getRecordLabelClassTree.do',
  checkName: global.currentBaseUrl + '/recordLabel/checkName',
  getExistTopic: global.currentBaseUrl + '/ivsClusterRule/getExistTopic', // 关键词list
  getTopicClusterTreeData:
    global.currentBaseUrl + '/ivsClusterRule/getTopicClusterTreeData',
}

const sceneTimeRule = (rule, value, callback) => {
  if (ruleThis.addKeyWordShow) {
    let errorMsg = '请填写完整此行信息或删除条件'
    if (ruleThis.keyWordForm.sceneTime == null || ruleThis.keyWordForm.sceneTime == '') {
      callback(new Error(errorMsg))
    }
    if (ruleThis.keyWordForm.sceneType == null) {
      callback(new Error(errorMsg))
    }
    if (
      ruleThis.keyWordForm.sceneValue == null ||
      ruleThis.keyWordForm.sceneValue == ''
    ) {
      callback(new Error(errorMsg))
    }
    if (ruleThis.keyWordForm.sceneValueType == null) {
      callback(new Error(errorMsg))
    }
  }
  callback()
}
const silenceTimeRule = (rule, value, callback) => {
  if (ruleThis.addKeyWordShow && ruleThis.selectVaule === false) {
    if (
      ruleThis.keyWordForm.silenceTimeMin == null ||
      ruleThis.keyWordForm.silenceTimeMax == ''
    ) {
      callback(new Error('目标静默时长不能为空'))
    }
  }
  callback()
}

let ruleThis

export default {
  computed: {
    loadData() {
      return this.loadData
    },
  },
  watch: {
    loadData(val, oldval) {},
  },
  directives: {
    'click-outside': {
      bind: function(el, binding, vNode) {
        // Provided expression must evaluate to a function.
        if (typeof binding.value !== 'function') {
          const compName = vNode.context.name
          let warn = `[Vue-click-outside:] provided expression '${
            binding.expression
          }' is not a function, but has to be`
          if (compName) {
            warn += `Found in component '${compName}'`
          }

          console.warn(warn)
        }
        // Define Handler and cache it on the element
        const bubble = binding.modifiers.bubble
        const handler = (e) => {
          if (bubble || (!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },
      unbind: function(el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      },
    },
  },
  data() {
    return {
      defaultPropsTree: {
        id: 'recordLabelClassId',
        label: 'recordLabelClassName',
      },
      defaultProps: {
        value: 'id',
        children: 'child',
        label: 'name',
      },
      treeMenu: [], // 树菜单
      typeName: '',
      typeTitle: '',
      options: [],
      optionsList: [],
      resultOptions: [],
      allLevels: false,
      cID: [],
      dialogTitle: '',
      showDialog: false,
      isOnSelect: true,
      classIds: [],
      treeTypeList: [],
      loadingCount: 0,
      showRule: false,
      addKeyWordFormShow: false,
      sceneTypes: [{ value: 1, label: '之前' }, { value: 2, label: '之后' }],
      sceneNumTimes: [{ value: 1, label: '秒' }, { value: 2, label: '句' }],
      addKeyWordShow: false,
      // 未完成的编辑历史栈
      keyWordEditStack: [],
      keyWordForm: {
        edit: false,
        keywordContext: '',
        fullScriptRole: '0',
        type: 1,
        silenceType: '1',
        silenceList: [{ value: '1', label: '时长' }, { value: '2', label: '次数' }],
      },
      silenceTypeList: [
        { value: '1', label: '时长' },
        { value: '2', label: '次数' },
        { value: '3', label: '占比' },
      ],
      fullScriptRoleList: [
        { value: '0', label: '全部' },
        { value: '1', label: '客户' },
        { value: '2', label: '坐席' },
      ],
      form: {
        silenceType: '1',
        labelName: '',
        startLabelDateRange: '',
        keyWords: [],
        overlapMin: '',
        overlapMax: '',
        avgSpeedMin: '',
        avgSpeedMax: '',
        silenceLongMin: '',
        silenceLongMax: '',
        selectedOptions3: [],
      },
      rules: {
        labelName: [{ required: true, validator: validModelTrim, trigger: 'blur' }],
        selectedOptions3: [
          { required: true, message: '所属分类不能为空', trigger: 'blur' },
        ],
        startLabelDateRange: [
          { required: true, message: '首次执行时间不能为空', trigger: 'blur' },
        ],
      },
      classId: '',
      className: '',
      keyWordFormRules: {
        fullScriptRole: [{ required: true, message: '不能为空', trigger: 'blur' }],
        keywordContext: [{ required: true, message: '关键词不能为空', trigger: 'blur' }],
        sceneTime: [{ validator: sceneTimeRule }],
        silenceTime: [{ validator: silenceTimeRule }],
      },
      showTree: false,
      selectVaule: false,
      treeName: '',
      showTreeList: false,
      existTopicData: [],
      topicClusterId: null,
    }
  },
  methods: {
    handleNodeClickTree(data) {
      console.log(data)
      this.treeName = data.recordLabelClassName
      this.classId = data.recordLabelClassId
      this.className = data.recordLabelClassName
    },
    // 点击自己 还是除了自己以外的元素
    outside: function(e) {
      this.showTreeList = false
    },
    inside: function() {
      this.showTreeList = true
      $('.is-focusable .el-checkbox__input span').removeClass('el-checkbox__inner')
      $('.is-focusable .el-checkbox__input span').addClass('el-radio__inner')
    },
    // 静默类型 时长/次数
    selectChange(value) {
      if (value === '1') {
        this.selectVaule = false
      } else {
        this.selectVaule = true
      }
    },
    clickDin: function() {
      let fouyt = this.$refs.keyWordsMenu.getCheckedNodes()
      if (fouyt.length != 0) {
        this.typeName = fouyt[0].name
      } else {
        this.typeName = ''
      }
      this.handleChange()
      this.showTree = false
    },
    fillAddForm(data) {
      this.form = Object.assign({ startLabelDateRange: '' }, data)
      if (data['firstRecordTimeMin']) {
        this.form.startLabelDateRange = new Date(data['firstRecordTimeMin'])
      }
      if (data['firstRecordTimeMax']) {
        this.form.startLabelDateRange = new Date(data['firstRecordTimeMax'])
      }
    },
    getLabelData(labelID) {
      this.loadingCount++
      this.isSelectTemplate = false
      const params = {
        labelId: labelID,
      }
      this.axios
        .post(requestUrls.getAllDataByLabelIdUrl, Qs.stringify(params))
        .then((response) => {
          if (response.data['state'] === '1') {
            const data = response['data']['results'][0] || []
            this.fillAddForm(data)
          }
        })
        .catch()
        .then(() => {
          this.loadingCount--
        })
    },
    getExistTopicList() {
      if (this.topicClusterId != null && this.topicClusterId != '') {
        let that = this
        let params = { topicClusterId: that.topicClusterId }
        that.axios
          .post(requestUrls['getTopicClusterTreeData'], Qs.stringify(params))
          .then(function(res) {
            let existTopicData = []
            if (
              res.data.data &&
              res.data.data.topicKeyWord != null &&
              res.data.data.topicKeyWord != ''
            ) {
              let words = res.data.data.topicKeyWord.split(' ')
              for (let j = 0; j < words.length; j++) {
                if (existTopicData.indexOf(words[j]) == -1) {
                  existTopicData.push(words[j])
                }
              }
            }
            if (res.data.children && res.data.children.length > 0) {
              for (let i = 0; i < res.data.children.length; i++) {
                let words = res.data.children[i].label.split(' ')
                for (let j = 0; j < words.length; j++) {
                  if (existTopicData.indexOf(words[j]) == -1) {
                    existTopicData.push(words[j])
                  }
                }
              }
            }
            that.existTopicData = existTopicData
          })
          .catch(() => {})
      } else {
        this.existTopicData = []
      }
    },
    digui(array, cid) {
      if (typeof array != 'undefined') {
        for (let i = 0; i < array.length; i++) {
          if (cid == array[i].recordLabelClassId) {
            console.log(
              array[i].recordLabelClassId + '####' + array[i].parentLabelClassId
            )
            this.resultOptions.splice(0, 0, cid)
            this.digui(this.optionsList, array[i].parentLabelClassId)
          } else {
            this.digui(array[i].children, cid)
          }
        }
      }
    },
    onOpen() {
      console.log(this.editNewLabelItem)
      if (this.editType === 'edit') {
        this.dialogTitle = '编辑'
        if (this.editNewLabelItem) {
          this.form.overlapMin = this.editNewLabelItem.overlapMin
          this.form.overlapMax = this.editNewLabelItem.overlapMax
          this.form.avgSpeedMin = this.editNewLabelItem.avgSpeedMin
          this.form.avgSpeedMax = this.editNewLabelItem.avgSpeedMax
          this.form.silenceLongMin = this.editNewLabelItem.silenceLongMin
          this.form.silenceLongMax = this.editNewLabelItem.silenceLongMax
          this.form.startLabelDateRange = this.editNewLabelItem.firstRecordTimeMax
          this.form.labelName = this.editNewLabelItem.labelName
          if (this.editNewLabelItem.keyWords !== null) {
            this.form.keyWords = this.editNewLabelItem.keyWords
          } else {
            this.form.keyWords = []
          }
        }
      } else {
        this.form.selectedOptions3 = []
        this.form.keyWords = []
        this.dialogTitle = '新建'
        this.form.overlapMin = ''
        this.form.overlapMax = ''
        this.form.avgSpeedMin = ''
        this.form.avgSpeedMax = ''
        this.form.silenceLongMin = ''
        this.form.silenceLongMax = ''
        this.form.labelName = ''
        this.form.startLabelDateRange = ''
        this.treeName = ''
        this.keyWordForm.keywordContext = ''
      }
      this.refreshTree()
      this.loadingCount = 0
      this.getExistTopicList()
      this.$emit('open')
    },
    validateParams(params) {
      if (commonUtil.isBlank(params['labelName'])) {
        return { msg: '标签名称不能为空!', flag: false }
      }
      if (
        commonUtil.isNotBlank(params['overlapMin']) &&
        commonUtil.isNotBlank(params['overlapMax'])
      ) {
        if (parseFloat(params['overlapMin']) > parseFloat(params['overlapMax'])) {
          return { msg: '重叠次数低值不能大于重叠次数高值!', flag: false }
        }
      }
      if (
        commonUtil.isNotBlank(params['moodScoreMin']) &&
        commonUtil.isNotBlank(params['moodScoreMax'])
      ) {
        if (parseFloat(params['moodScoreMin']) > parseFloat(params['moodScoreMax'])) {
          return { msg: '情绪分值低值不能大于情绪分值高值!', flag: false }
        }
      }
      if (
        commonUtil.isNotBlank(params['avgSpeedMin']) &&
        commonUtil.isNotBlank(params['avgSpeedMax'])
      ) {
        if (parseFloat(params['avgSpeedMin']) > parseFloat(params['avgSpeedMax'])) {
          return { msg: '平均语速低值不能大于平均语速高值!', flag: false }
        }
      }
      if (commonUtil.isNotBlank(params['silenceType'])) {
        if (
          commonUtil.isNotBlank(params['silenceLongMin']) &&
          commonUtil.isNotBlank(params['silenceLongMax'])
        ) {
          if (
            parseFloat(params['silenceLongMin']) > parseFloat(params['silenceLongMax'])
          ) {
            return { msg: '静默时长低值不能大于平均语速高值!', flag: false }
          }
        }
        if (
          commonUtil.isNotBlank(params['silenceTimeMin']) &&
          commonUtil.isNotBlank(params['silenceTimeMax'])
        ) {
          if (
            parseFloat(params['silenceTimeMin']) > parseFloat(params['silenceTimeMax'])
          ) {
            return { msg: '静默次数低值不能大于静默次数高值!', flag: false }
          }
        }
        if (
          commonUtil.isNotBlank(params['silencePerMin']) &&
          commonUtil.isNotBlank(params['silencePerMax'])
        ) {
          if (parseFloat(params['silencePerMin']) > parseFloat(params['silencePerMax'])) {
            return { msg: '静默占比低值不能大于静默占比高值!', flag: false }
          }
        }
      }
      return { msg: '', flag: true }
    },
    submitRecordLabel() {
      let audio = {}
      let that = this
      this.$refs.form.validate().then((result) => {
        if (!result) {
          return
        }
        if (this.classId === '') {
          this.$message.error('请选择所属分类')
          return
        }
        let params2 = Object.assign({}, that.form)
        let validateResult = this.validateParams(params2)
        if (!validateResult['flag']) {
          that.$message.error(validateResult['msg'])
          return
        }
        params2['firstRecordTimeMax'] = that.form.startLabelDateRange
        params2['keyWordJsonStr'] = JSON.stringify(that.form.keyWords)
        params2['classId'] = that.classId // 判断
        params2['relation'] = 'OR'
        params2['add'] = true
        params2['labelId'] = ''
        params2['className'] = that.className
        delete params2.startLabelDateRange
        delete params2.keyWords
        delete params2.createTime
        audio = params2
        let params = {
          labelName: that.form.labelName,
        }
        if (this.pageName === 'audio') {
          that.axios.get(requestUrls['checkName'], { params }).then((response) => {
            if (response.data.data === true) {
              that.$emit('formData', audio)
            } else {
              that.$message.info('标签名称已经存在！请重新输入！')
            }
          })
        } else {
          that.axios
            .post(requestUrls['saveLabelUrl'], Qs.stringify(params2))
            .then((response) => {
              let data = response['data']
              if (data['state'] === '1') {
                that.$message.success('保存成功!')
                that.$emit('submitted', response.data.other.recordLabelId)
              } else {
                this.$message.error(data['message'])
              }
              this.refreshTree()
            })
            .catch()
            .then(() => {
              that.loadingCount--
            })
        }
      })
    },
    close() {
      this.form.selectedOptions3 = []
    },
    cancelAddRecordLabel() {
      this.showDialog = false
      this.$refs.form.resetFields()
    },
    cancelKeywordSubmit() {
      this.addKeyWordFormShow = false
      this.keyWordForm = {
        edit: false,
        keywordContext: '',
        fullScriptRole: '0',
        type: 1,
        silenceType: '1',
        silenceList: [{ value: '1', label: '时长' }, { value: '2', label: '次数' }],
      }
    },
    resetKeywordForm(stackFlag) {
      if (!stackFlag || this.keyWordEditStack.length === 0) {
        this.keyWordForm = {
          edit: false,
          keywordContext: '',
          fullScriptRole: '0',
          type: 1,
          silenceType: '1',
          silenceList: [{ value: '1', label: '时长' }, { value: '2', label: '次数' }],
        }
        if (this.$refs.keyWordForm) {
          this.$refs.keyWordForm.clearValidate()
        }
        return false
      }

      this.keyWordForm = this.keyWordEditStack.pop()
      if (this.$refs.keyWordForm) {
        this.$refs.keyWordForm.validate()
      }
      return true
    },
    editKeyWord(scriptKeywordId) {
      const editKeyWord = this.form.keyWords.find(
        (item) => item.scriptKeywordId === scriptKeywordId
      )
      // 保存历史信息
      if (
        this.keyWordForm.keywordContext ||
        (this.keyWordForm.fullScriptRole !== '0' && !this.keyWordForm.edit)
      ) {
        this.keyWordEditStack.push(this.keyWordForm)
      }
      this.resetKeywordForm()

      this.keyWordForm = Object.assign(this.keyWordForm, editKeyWord)
      this.keyWordForm.edit = true
      this.addKeyWordFormShow = true
    },
    deleteKeyWord(scriptKeywordId) {
      this.form.keyWords = this.form.keyWords.filter(
        (item) => item.scriptKeywordId !== scriptKeywordId
      )
    },
    addKeywordSubmit() {
      this.$refs.keyWordForm.validate().then((result) => {
        if (!result) {
          return
        }
        if (this.addKeyWordShow === true) {
          if (
            parseInt(this.keyWordForm.silenceTimeMin) &&
            parseInt(this.keyWordForm.silenceTimeMax)
          ) {
            if (this.keyWordForm.silenceTimeMin > this.keyWordForm.silenceTimeMax) {
              this.$message.error('目标静默时长最小值要小于最大值！')
              return
            }
          } else {
            this.$message.error('目标静默时长需要填写整数！')
            return
          }
        }
        // scriptKeywordId仅用于新增时前端编辑使用
        let scriptKeywordId = this.keyWordForm.edit
          ? this.keyWordForm.scriptKeywordId
          : this.getUUID()

        this.deleteKeyWord(scriptKeywordId)

        this.form.keyWords.push(Object.assign({ scriptKeywordId }, this.keyWordForm))

        // 回复表单数据和校验状态
        if (!this.resetKeywordForm(true)) {
          this.addKeyWordFormShow = false
        }
      })
    },
    deleteKeyWordOption() {
      this.addKeyWordShow = false
      this.keyWordForm.type = 2
      this.keyWordForm = {
        edit: false,
        keywordContext: '',
        fullScriptRole: '0',
        type: 1,
        silenceType: '1',
        silenceList: [{ value: '1', label: '时长' }, { value: '2', label: '次数' }],
      }
    },
    insertAtCursor(signature) {
      if (signature !== '()') {
        this.keyWordForm.keywordContext += ' ' + signature + ' '
      } else {
        this.keyWordForm.keywordContext = '(' + this.keyWordForm.keywordContext + ')'
      }
      // focus到 textarea 上，方便继续输入
      this.$refs.keywordContextTextarea.focus()
    },
    showAddKeyWordForm() {
      this.addKeyWordShow = true
      this.keyWordForm.type = 2
    },
    getUUID() {
      return Number(
        Math.random()
          .toString()
          .substr(3, length) + Date.now()
      ).toString(36)
    },
    handleChange(event) {
      console.log(event)
    },
    // 给级联选择器重新赋值
    regroupTree: function(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        if (value[i].children === null) {
          treeList[i] = {
            label: value[i].recordLabelClassName,
            value: value[i].recordLabelClassId,
          }
        } else {
          treeList[i] = {
            label: value[i].recordLabelClassName,
            value: value[i].recordLabelClassId,
            children: this.regroupTree(value[i].children, []),
          }
        }
      }
      return treeList
    },
    casCaderChange(item) {
      console.info(item)
      if (item.length === 1) {
        this.classId = item[0]
      }
      if (item.length > 1) {
        for (let p = 0; p < item.length; p++) {
          if (p === item.length - 1) {
            this.classId = item[p]
          }
        }
      }
    },
    refreshTree() {
      this.loadingCount++
      this.axios
        .post(requestUrls.getTreeDataUrl)
        .then((response) => {
          if (response.data) {
            if (this.editType === 'edit') {
              let optionsList = JSON.parse(JSON.stringify(response.data))
              this.digui(optionsList, this.editNewLabelItem.classId)
              this.form.selectedOptions3 = this.resultOptions
            }
            let cascaderList = []
            for (let l = 0; l < response.data.length; l++) {
              if (
                response.data[l].children === [] ||
                response.data[l].children === undefined
              ) {
                cascaderList[l] = {
                  label: response.data[l].recordLabelClassName,
                  value: response.data[l].recordLabelClassId,
                  children: [],
                }
              } else {
                cascaderList[l] = {
                  label: response.data[l].recordLabelClassName,
                  value: response.data[l].recordLabelClassId,
                  children: this.regroupTree(response.data[l].children, []),
                }
              }
            }
            this.options = cascaderList
            deleteEmptyChildren(this.options)
          }
        })
        .catch(() => {})
        .then(() => {
          this.loadingCount--
        })
    },
  },
  props: {
    labelId: {
      type: String,
    },
    treeid: {
      type: String,
    },
    editNewLabelItem: {
      type: Object,
    },
    treeSelectName: {
      type: String,
    },
    editNewBiaoIndex: {
      type: Number,
    },
    classID: {
      type: String,
    },
    labelID: {
      type: String,
    },
    editType: {
      type: String,
    },
    classIdsTwo: {
      type: String,
    },
    typeHide: {
      type: Boolean,
    },
    pageName: {
      type: String,
    },
  },
  created() {
    ruleThis = this
  },
}
</script>
<style lang="less" scoped>
.tuijianCi {
  margin: 10px;
}
.contentLeft {
  width: 220px;
  top: 0px;
  left: 80px;
  position: relative;
  z-index: 3000;
  .treeMenu {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    .el-tree {
      max-height: 200px;
      min-height: 80px;
      overflow-y: auto;
      border: 1px solid #ccc;
    }
    .btns {
      width: 99%;
      height: 36px;
      border: 1px solid #ccc;
      border-top: 0;
      background: #fff;
      .el-button {
        float: right;
        width: 52px;
        height: 30px;
        margin-top: 2px;
        font-size: 12px;
        margin-right: 10px;
      }
    }
  }
}
.container {
  padding: 0 15px;
  overflow: hidden;
  .hide {
    display: none;
  }
  .select-width {
    width: 200px;
    margin-top: 3px;
  }
  .contentLeft {
    left: 70px;
    width: 220px;
    top: 45px;
    /* right: 0; */
    position: absolute;
    z-index: 3000;
    .treeMenu {
      position: absolute;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      .el-tree {
        max-height: 200px;
        min-height: 80px;
        overflow-y: auto;
        border: 1px solid #ccc;
      }
      .btns {
        width: 99%;
        height: 36px;
        border: 1px solid #ccc;
        border-top: 0;
        background: #fff;
        .el-button {
          float: right;
          width: 52px;
          height: 30px;
          margin-top: 2px;
          font-size: 12px;
          margin-right: 10px;
        }
      }
    }
  }
  .form-row {
    & > * {
      /*display: inline-block;*/
      &:not(:last-child) {
        margin-right: 10px;
      }
    }
  }

  .keyWords {
    .content {
      float: left;
    }
    .operations {
      float: right;
    }
    margin-bottom: 10px;
    overflow: hidden;
  }

  a {
    line-height: 19px;
    color: rgba(32, 160, 255, 1);
    font-size: 14px;
    text-align: left;
    font-family: MicrosoftYaHei;
  }

  .addKeyWordPlane {
    background-color: rgba(239, 242, 247, 1);
    padding: 10px 20px;
    margin-top: 20px;
    .addKey {
      margin-top: 10px;
      .keyWorldpos {
        display: flex;

        .spanStyle {
          border: 1px solid #ddd;
          text-align: center !important;
          margin-left: 6px;
          border-radius: 4px;
          cursor: pointer;
          display: inline-block;
          width: 68px;
          height: 36px;
          line-height: 36px;
          background: #fff;
        }
      }
    }

    .btns {
      width: 100%;
      overflow: hidden;
      margin-top: 30px;
      * {
        float: right;
        margin-left: 5px;
      }
    }
  }

  .line {
    height: 1px;
    width: 100%;
    background-color: rgba(209, 217, 226, 1);
  }

  .section-title {
    display: inline-block;
    line-height: 60px;
    color: #666666;
    font-size: 14px;
    font-family: 'MicrosoftYaHei-Bold', 'Microsoft YaHei Bold', 'Microsoft YaHei';
    font-weight: 700;

    .keyRules {
      position: relative;
      .rules {
        padding: 20px 25px 30px 18px;
        box-sizing: border-box;
      }
    }
  }
}
</style>
