<template>
  <el-dialog
    title="编辑"
    :visible.sync="dialogVisible"
    :width="'540px'"
    :close-on-click-modal="closeOnClickModal"
    @open="onOpen"
    @close="close"
  >
    <el-form :model="treeForm" ref="treeForm">
      <el-form-item
        :rules="[{ required: true, message: '名称不能为空' }]"
        label="分类树名称"
        prop="name"
        label-width="100px"
      >
        <el-input v-model="treeForm.name"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" :loading="loading" @click="save">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
import global from '@/global'
export default {
  data() {
    return {
      loading: false,
      dialogVisible: false,
      treeForm: {
        name: '',
      },
      closeOnClickModal: false, // 点击modal可以关闭弹框?
    }
  },
  computed: {
    // loadData() {},
  },
  watch: {
    // loadData(val, oldval) {},
  },
  props: {
    tName: {
      type: String,
    },
    tID: {
      type: String,
    },
  },
  methods: {
    onOpen() {
      const name = this.tName
      this.treeForm.name = name
      this.oldName = name
    },
    close() {
      this.$emit('editTreeNameReturn')
    },
    save() {
      const id = this.tID
      let name = this.treeForm.name
      if (!name || !(name = name.trim())) {
        this.$message.error('名称不能为空!')
        return
      }
      if (name === this.oldName) {
        // 名称没有改变
        this.$emit('editTreeNameReturn')
        return
      }
      if (name.length > 10) {
        this.$message.error('名称不能超过十个字符!')
        return
      }
      let regx = /^[\u4E00-\u9FA5A-Za-z0-9]+$/
      if (!regx.test(name)) {
        this.$message.error('名称只能是数字、汉字、英文字符!')
        return
      }
      this.loading = true;
      let url = global.currentBaseUrl+'/recordSort/trees/name';
      let data = {
        "sortName":name,
        "sortID":id
      };
      this.axios.post(url,data,{
        headers: {
          'Content-Type':'application/json; charset=UTF-8',
          accessToken: this.$store.state.token,
        }
      }).then((res) => {
        if (res.data.message == '') {
          this.loading = false
          this.$message.success('修改成功！')
          this.$emit('editTreeNameReturn', { name, id })
        } else {
          this.loading = false
          this.$message.error(res.data.message)
          if (res.data.message = '该分类已被删除') {
            name = '1'
            this.$emit('editTreeNameReturn', { name, id })
          }
        }
      })
        .catch(({ response }) => {
          const { data = {} } = response || {}
          this.loading = false
          this.$message.error(data.message || '保存失败，请稍后重试！')
        })
      /*this.axios
        .put(
          `${global.currentBaseUrl}/recordSort/trees/${id}/name?sortName=${name}`,
          {
            headers: {
              'Content-Type': 'application/json; charset=UTF-8',
              accessToken: this.$store.state.token,
            },
          }
        )
        .then((res) => {
          if (res.data.message == '') {
            this.loading = false
            this.$message.success('修改成功！')
            this.$emit('editTreeNameReturn', { name, id })
          } else {
            this.loading = false
            this.$message.error(res.data.message)
            if (res.data.message = '该分类已被删除') {
              name = '1'
              this.$emit('editTreeNameReturn', { name, id })
            }
          }
        })
        .catch(({ response }) => {
          const { data = {} } = response || {}
          this.loading = false
          this.$message.error(data.message || '保存失败，请稍后重试！')
        })*/
    },
  },
}
</script>
<style></style>
