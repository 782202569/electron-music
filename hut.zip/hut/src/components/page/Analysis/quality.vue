<!-- 质差分析 -->
<template>
  <div class="quality-wrapper">
  <div v-show="!showDetail">
    <header>
      <span>智能分析——质差分析</span>
    </header>

    <section class="quality-search">
      <div style="margin-bottom: 20px;">
          <label>业务</label>
          <business-tree
            ref="businessTree"
            @saveSubjectClassId="saveSubjectClassId"
          ></business-tree>
          <dateComponent ref="dateComponent" @changeDate="getChildChangeDate"></dateComponent>
      </div>
      <div class="u-flex">
        <div class="u-flex-item">
          <label>质检模板</label>
          <el-select v-model="selectedModel" placeholder="请选择">
            <el-option
              v-for="item in models"
              :key="item.modelId"
              :label="item.modelName"
              :value="item.modelId + ',' + item.modelUpdateTime"
            ></el-option>
          </el-select>
        </div>
        <el-button @click="onSearch" style="margin-left: 10px" type="primary">查询</el-button>
      </div>
    </section>

    <div class="header-tab">
      <el-radio-group v-model="selectTab" @change="changeTab">
        <el-radio-button label="0">服务质差分析</el-radio-button>
        <el-radio-button label="1">业务质差分析</el-radio-button>
      </el-radio-group>
    </div>

    <div v-show="selectTab==0">
      <div class="u-flex">
        <span class="quality-title">服务质差情况</span>
        <el-button type="text"
          icon="el-icon-document" class="gray"
          style="margin-left: 10px;"
          @click="serviceVoiceSrc"
        >(录音源)</el-button>
      </div>
      <el-row>
        <div id="serviceBar" style="width:100%;height:400px;"></div>
      </el-row>
      <div class="u-flex">
        <span class="quality-title">高频扣分点</span>
        <span class="gray">（点击击每行任意位置可查看扣分点关联的录音）</span>
      </div>
      <el-table
        :data="serviceTbData"
        style="width: 100%"
        @row-click="highPointClick"
        :row-style="rowStyle"
      >
        <el-table-column type="index" label="排位" width="180"></el-table-column>
        <el-table-column prop="normalName" label="扣分点"></el-table-column>
        <el-table-column prop="seatCount" label="扣分人数(人)" sortable width="180"></el-table-column>
        <el-table-column sort-by="recordCount" label="扣分录音(通)" sortable width="180">
          <template slot-scope="scope">
            {{scope.row.recordCount}}
            <span style="color:red;" v-if="scope.row.floatRatio>0">↑</span>
            <span style="color:green;" v-else-if="scope.row.floatRatio < 0">↓</span>
          </template>
        </el-table-column>
        <el-table-column label width="180" align="center">
          <template slot-scope="scope">
            <el-button @click="showNothing(scope.row)" type="text" size="small">录音源</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div v-show="selectTab==1">
      <div class="u-flex">
        <div class="u-flex-item">
          <div class="u-flex">
            <span class="quality-title">低分业务分布</span>
            <el-button type="text"
              icon="el-icon-document" class="gray"
              style="margin-left: 10px;"
              @click="scoreVoiceSrc"
            >(录音源)</el-button>
          </div>
          <div id="businessChart" style="width:100%;height:400px;"></div>
        </div>
        <div class="score-table-wrapper">
          <div class="quality-title">低分总占比</div>
          <div class="score-table">
            <ul>
              <li
                class="score-item u-flex"
                v-for="(item,index) in lowScoreData"
                :key="item.sortId"
                :class="{green: item.state==='down'}"
                @click="onItemClick(item)"
              >
                <span class="score-num">{{index + 1}}.</span>
                <span class="u-flex-item">{{item.sortName}}</span>
                <span class="score-percent">
                  {{item.lowScoreRatio}}%
                  <span style="color:red;" v-if="item.floatRatio>0">↑</span>
                  <span v-else-if="item.floatRatio < 0">↓</span>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="u-flex">
        <span class="quality-title">业务高频扣分点</span>
        <span class="gray">（点击击每行任意位置可查看扣分点关联的录音）</span>
      </div>
      <el-table
        :data="businessTbData"
        style="width: 100%"
        @row-click="scoreRowClick"
        :row-style="rowStyle"
      >
        <el-table-column type="index" label="排位" width="120"></el-table-column>
        <el-table-column prop="seatIntentName" label="扣分点"></el-table-column>
        <el-table-column prop="seatCount" label="扣分人数(人)" sortable width="180"></el-table-column>
        <el-table-column label="扣分录音(通)" sort-by="recordCount" sortable width="180">
          <template slot-scope="scope">
            {{scope.row.recordCount}}
          </template>
        </el-table-column>
        <el-table-column label="环比" width="120">
          <template slot-scope="scope">
            {{scope.row.preRecordCount? scope.row.floatRatio + '%' : '--'}}
            <template v-if="scope.row.preRecordCount">
              <span style="color:red;" v-if="scope.row.floatRatio>0">↑</span>
              <span style="color:green;" v-else-if="scope.row.floatRatio < 0">↓</span>
            </template>
          </template>
        </el-table-column>
        <el-table-column label width="180" align="center">
          <template slot-scope="scope">
            <el-button @click="showNothing(scope.row)" type="text" size="small">录音源</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
    <section v-show="showDetail" class="quality-detail-wrapper u-flex u-flex-column">
      <header>
        <el-button @click="back" type="text">&lt; 返回</el-button>
        <el-button @click="exportList">导出</el-button>
      </header>
      <div class="u-flex-item table-content">
        <el-table
          :data="callList"
          v-loading="callLoading"
          style="width: 100%"
        >
          <el-table-column type="index" label="序号" :index="indexMethod"></el-table-column>
          <el-table-column prop="callId" label="录音编号" width="150"></el-table-column>
          <el-table-column prop="callSTime" label="录音时间" width="180"></el-table-column>
          <el-table-column prop="callETime" label="通话时长" width="150"></el-table-column>
          <el-table-column prop="seatNo" label="坐席ID"></el-table-column>
          <el-table-column prop="sortName" label="业务分类">
          </el-table-column>
          <el-table-column prop="status" label="状态"></el-table-column>
          <el-table-column prop="score" label="系统评分" width="120"></el-table-column>
          <el-table-column label="操作" width="100">
            <template slot-scope="scope">
              <el-button @click="showVoice(scope.row)" type="text" size="small">查看</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="page">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="pageSizes"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
        >
        </el-pagination>
      </div>
    </section>
  <el-dialog
    class="single"
    title="录音播放页面"
    :visible.sync="recordDialogVisible"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
  >
    <div class="recordingplayWrap">
      <recording-play
        ref="recordPlay"
        @onclose="recordPlayCloseHandler"
        @onminimize="recordPlayMinimizeHandler"
      ></recording-play>
    </div>
  </el-dialog>
  </div>
</template>

<script>
import moment from 'moment'
import qs from 'qs'
import dateComponent from '../reportForms/dateComponent'
import businessTree from '../reportForms/businessTree'
import recordingPlay from '../recordingPlay/recordingPlayResultScore'
import bus from '../../common/bus'
import global from '../../../global'
import commonUtil from '../../../utils/commonUtil.js'
const currentBaseUrl = global.currentBaseUrl

export default {
  components: {
    businessTree,
    dateComponent,
    recordingPlay
  },
  data() {
    return {
      statisticsSize: '', // 统计粒度
      startTime: '',  // 开始时间
      endTime: '', // 结束时间
      businessType: '', // 业务类型
      modelId: '', // 模板id
      serviceData: [], // 服务质差分布情况
      serviceTbData: [], // 服务高频扣分点
      businessData: [], // 业务低分分布情况
      showDetail: false,
      recordDialogVisible: false,
      models: [], // 质检模板
      selectedModel: '',
      selectTab: '0',
      businessTbData: [], // 业务高频扣分点
      callList: [], // 录音源列表
      lowScoreData: [], // 低分总占比
      rowStyle: {cursor: 'pointer'},
      currentPage: 1, // 当前页码
      total: 0, // 记录总条数
      pageSize: 10, // 每页显示的记录条数
      pageSizes: [10, 15, 20, 25],
      params: {}, // 请求参数
      callLoading: true, // 录音源列表是否显示loading
    }
  },
  watch:{
    selectedModel(val){
      if (val) {
        [this.modelId, this.modelUpdateTime] = val.split(',');
        this.params.modelId = this.modelId;
        this.params.modelUpdateTime = this.modelUpdateTime;
      }
    }
  },
  methods: {
    getChildChangeDate(val) {
      const arr = val.split(',')
      this.startTime = arr[1]
      this.endTime = arr[2]
      this.statisticsSize = arr[0]
    },
    saveSubjectClassId(val) {
      if (this.businessType === '') {
        this.businessType = val
        this.init()
        return;
      }
      this.businessType = val
    },
    changeTab(val) {
      if (val == 1) {
        // 如果已经请求过数据，直接显示
        if (this.reqTwo) {
          this.initBarChart()
        } else {
          this.getTabTwo();
        }
      } else {
        if (this.reqOne) {
          this.initServiceBar();
        } else {
          this.getTabOne();
        }
      }
    },
    back() {
      this.showDetail ^= true;
    },
    // 服务质差分布情况
    initServiceBar() {
      const dataKey = this.serviceData.map(item => item.normalName);
      const dataValue = this.serviceData.map(item => {
        return {
          value: item.recordCount,
          id: item.normalId
        }
      });
      const errorLevel = this.errorLevel.data || {};
      const option = {
        title: [
          {
            text: '服务质差项分布情况',
            x: 'center',
          },
          {
            text: ' ', // 空字符，占位
            textStyle: {
              lineHeight: 30,
            },
            right: '25%',
            subtext: '错误等级分布',
            subtextStyle: {
              color: '#333',
              fontSize: 16,
            },
          },
        ],
        grid: {
          left: '40px', // default 10%
          right: '40px',
        },
        tooltip: {},
        toolbox: this.getToolbox(this.exportService),
        xAxis: [{ type: 'category', gridIndex: 0, data: dataKey }],
        yAxis: { gridIndex: 0 },
        series: [
          {
            type: 'bar',
            name: '服务质差项',
            barWidth: '60%',
            data: dataValue,
            itemStyle: {
              color: ['#3398DB'],
            },
            label: {
              normal: {
                show: true,
                position: 'top',
              },
            },
          },
          {
            type: 'pie',
            id: 'pie',
            radius: '30%',
            center: ['80%', '25%'],
            label: {
              formatter: '{b}: {d}%',
            },
            data: [{ value: errorLevel.deadCount, name: '致命错误', id: 1 }, { value: errorLevel.noDeadCount, name: '非致命错误', id: 2 }],
            tooltip: {
              formatter: '{b}: {d}%',
            },
          },
        ],
      }
      this.$nextTick(() => {
        const myChart = this.$echarts.init(document.getElementById('serviceBar'))
        myChart.clear()
        myChart.setOption(option)
        // 查看详情
        myChart.off('click');
        myChart.on('click', (params) => {
          this.currentPage = 1;
          this.callParams = {
            startTime: this.params.startTime,
            endTime: this.params.endTime,
            modelId: this.params.modelId,
            modelUpdateTime: this.params.modelUpdateTime,
            businessType: this.params.businessType,
            pageSize: this.pageSize,
            pageNumber: this.currentPage - 1,
          }
          // 错误等级分布点击
          if (params.seriesType === 'pie') {
            this.callParams.deadItem = params.data.id;
          } else {
            this.callParams.normalId = params.data.id;
          }
          this.getCallList(this.callParams)
          this.showDetail = true;
        })
      })
    },
    // 业务低分分布情况
    initBarChart() {
      // const categoryData = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      // const valueData = [10, 52, 200, 334, 390, 330, 220];
      const categoryData = this.businessData.map(item => item.sortName);
      const valueData = this.businessData.map(item => {
        return {
          value: item.avgScore,
          id: item.sortId
        }
      });
      const option = {
        color: ['#3398DB'],
        title: {
          text: '质检评分低分业务排行',
          x: 'center',
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        toolbox: this.getToolbox(this.exportBar),
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            data: categoryData,
            axisTick: {
              alignWithLabel: true,
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
          },
        ],
        series: [
          {
            name: '评分',
            type: 'bar',
            barWidth: '60%',
            data: valueData,
          },
        ],
      }
      this.$nextTick(() => {
        let myChart = this.$echarts.init(document.getElementById('businessChart'))
        myChart.clear()
        myChart.setOption(option)
        // 查看详情
        myChart.off('click');
        myChart.on('click', (params) => {
          console.log(params);
          this.currentPage = 1;
          this.callParams = {
            startTime: this.params.startTime,
            endTime: this.params.endTime,
            // modelId: this.params.modelId,
            // modelUpdateTime: this.params.modelUpdateTime,
            businessType: this.params.businessType,
            sortId: params.data.id,
            pageSize: this.pageSize,
            pageNumber: this.currentPage - 1,
          }
          this.getCallList(this.callParams)
          this.showDetail = true;
        })
      })
    },
    getToolbox(cb) {
      return {
        show: true,
        right: 15,
        top: 0,
        itemSize: 18,
        feature: {
          saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
          myExcel: {
            show: true,
            title: '导出Excel',
            icon: 'image://static/img/excelReport.png',
            z: '999',
            left: 'center',
            onclick: () => {
              cb && cb()
            },
          },
        },
      }
    },
    // 服务质差录音源
    serviceVoiceSrc() {
      this.currentPage = 1;
      this.callParams = {
        startTime: this.params.startTime,
        endTime: this.params.endTime,
        modelId: this.params.modelId,
        modelUpdateTime: this.params.modelUpdateTime,
        businessType: this.params.businessType,
        pageSize: this.pageSize,
        pageNumber: 0,
      }
      this.getCallList(this.callParams)
      this.showDetail = true;
    },
    // 低分录音源
    scoreVoiceSrc() {
      this.currentPage = 1;
      this.callParams = {
        startTime: this.params.startTime,
        endTime: this.params.endTime,
        // modelId: this.params.modelId,
        // modelUpdateTime: this.params.modelUpdateTime,
        businessType: this.params.businessType,
        pageSize: this.pageSize,
        pageNumber: 0,
      }
      this.getCallList(this.callParams)
      this.showDetail = true;
    },
    // 导出低分业务分布
    exportBar() {
      // let params = {
      //   businessType: this.params.businessType,
      //   statisticsSize: this.statisticsSize,
      //   startTime: this.startTime,
      //   endTime: this.endTime,
      // }
      this.params.businessType = '';
      const url = `${currentBaseUrl}/qualityCompare/excel/lowBusiness`;
      commonUtil.doExport(url, this.params, global.jsonHeader)
    },
    // 导出服务质差分析
    exportService() {
      // let params = {
      //   businessType: this.businessType,
      //   statisticsSize: this.statisticsSize,
      //   startTime: this.startTime,
      //   endTime: this.endTime,
      // }
      this.params.businessType = '';
      // const url = `${currentBaseUrl}/qualityCompare/excel/lowBusiness`;
      const url = `${currentBaseUrl}/qualityCompare/excel/busFrequencyDeduction`;
      commonUtil.doExport(url, this.params, global.jsonHeader)
    },
    // 导出录音源列表
    exportList() {
      const url = `${currentBaseUrl}/qualityCompare/excel/recordSources`;
      commonUtil.doExport(url, this.callParams, global.jsonHeader)
    },
    onSearch() {
      // this.params.businessType = this.businessType;
      this.params.businessType = '';
      this.params.modelId = this.modelId;
      this.params.modelUpdateTime = this.formatTime(+this.modelUpdateTime);
      this.params.startTime = this.startTime;
      this.params.endTime = this.endTime;
      this.params.statisticsSize = this.statisticsSize;
      // 根据当前在哪个tab请求，重置其他tab请求
      if (this.selectTab == 0) {
        this.reqTwo = false;
        this.getTabOne();
      } else {
        this.reqOne = false;
        this.getTabTwo();
      }
    },
    // 高频扣分点
    highPointClick(row) {
      console.log(row);
      this.currentPage = 1;
      this.callParams = {
        startTime: this.params.startTime,
        endTime: this.params.endTime,
        modelId: this.params.modelId,
        modelUpdateTime: this.params.modelUpdateTime,
        businessType: this.businessType,
        normalId: row.normalId,
        pageSize: this.pageSize,
        pageNumber: this.currentPage - 1,
      }
      this.getCallList(this.callParams)
      this.showDetail = true;
    },
    // 业务高频扣分点
    scoreRowClick(row) {
      this.currentPage = 1;
      this.callParams = {
        startTime: this.params.startTime,
        endTime: this.params.endTime,
        businessType: this.businessType,
        seatIntentId: row.seatIntentId,
        pageSize: this.pageSize,
        pageNumber: this.currentPage - 1,
      }
      this.getCallList(this.callParams)
      this.showDetail = true;
    },
    // 调到录音播放页
    showVoice(row) {
      let { callId, isSampled, callSTime, callNo, mblNo, recordFileURL } = row
      let obj = {}
      obj.from = 'recordingpoll'
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.isSampled = isSampled
      obj.callSTime = callSTime
      obj.mblNo = mblNo ? mblNo : ''
      obj.callNo = callNo ? callNo : ''
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    recordPlayCloseHandler() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val
      this.currentPage = 1;
      this.callParams.pageSize = val;
      this.getCallList(this.callParams);
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.callParams.pageNumber = val - 1;
      this.getCallList(this.callParams);
    },
    // 表格序号显示
    indexMethod(idx) {
      return (this.currentPage - 1) * this.pageSize + idx + 1;
    },
    // 业务质差低分占比列表点击
    onItemClick(item) {
      this.currentPage = 1;
      this.callParams = {
        startTime: this.params.startTime,
        endTime: this.params.endTime,
        businessType: this.businessType,
        sortId: item.sortId,
        pageSize: this.pageSize,
        pageNumber: this.currentPage - 1,
      }
      this.getCallList(this.callParams)
      this.showDetail = true;
    },
    // 获取服务质差情况
    getServiceQuality() {
      console.log(this.params)
      const req = this.axios.post(`${currentBaseUrl}/qualityCompare/qualityItems`, qs.stringify(this.params));
      req.then(({data}) => {
        if (data.code === 0) {
          this.serviceData = data.data;
        }
      });
      return req;
    },
    // 获取致命错误分布
    getError() {
      const req = this.axios.post(`${currentBaseUrl}/qualityCompare/errorLevel`, qs.stringify(this.params));
      req.then(({data}) => {
        if (data.code === 0) {
          this.errorLevel = data.data || {};
        }
      });
      return req;
    },
    // 服务高频扣分点Top N
    getServiceTop() {
      const req = this.axios.post(`${currentBaseUrl}/qualityCompare/highFreQuencyTop`, qs.stringify(this.params));
      req.then(({ data }) => {
        if (data.code === '500' && data.message) {
          this.$message.error(data.message);
          return;
        }
        this.serviceTbData = data.data;
      })
    },
    // 低分业务分布
    getBusinessData() {
      const req = this.axios.post(`${currentBaseUrl}/qualityCompare/lowBusiness`, qs.stringify(this.params));
      req.then(({ data }) => {
        if (data.code === '500' && data.message) {
          this.$message.error(data.message);
          return;
        }
        this.businessData = data.data;
        this.initBarChart();
      })
    },
    // 低分业务总占比Top
    getBusinessPercent() {
      const req = this.axios.post(`${currentBaseUrl}/qualityCompare/lowProportion`, qs.stringify(this.params));
      req.then(({ data }) => {
        this.lowScoreData = data.data;
      })
    },
    // 业务高频扣分点Top N
    getBusinessTop() {
      // delete this.params.businessType
      const req = this.axios.post(`${currentBaseUrl}/qualityCompare/busFrequencyDeduction`, qs.stringify(this.params));
      req.then(({ data }) => {
        if (data.code === '500' && data.message) {
          this.$message.error(data.message);
          return;
        }
        this.businessTbData = data.data;
      })
    },
    // 获取tab 0 的数据
    getTabOne() {
      const p1 = this.getServiceQuality()
      const p2 = this.getError()
      // 分布情况和错误等级都获取数据了，才展示柱状图和饼图
      Promise.all([p1, p2]).then(() => {
        setTimeout(() => {
          this.initServiceBar();
        }, 50);
      });
      Promise.all([p1, p2, this.getServiceTop()]).then(() => {
        this.reqOne = true; // one请求了，后续如果没有点击查询，切换tab时不会重新请求
        this.hideLoading();
      }).catch(() => {
        this.hideLoading();
      })
    },
    // 获取tab 1的数据
    getTabTwo() {
      this.getBusinessData();
      this.getBusinessPercent();
      this.getBusinessTop();
      this.reqTwo = true;
    },
    // 获取质检模板
    getModel() {
      const req = this.axios.post(`${currentBaseUrl}/qualityCompare/getModelList`);
      req.then(({ data }) => {
        this.models = data.data;
        const first = this.models[0] || {};
        this.selectedModel = `${first.modelId},${first.modelUpdateTime}`
        setTimeout(() => {
          this.init();
        }, 40)
      }).catch(() => {
        this.hideLoading()
      })
    },
    // 获取录音源列表
    getCallList(params) {
      this.callLoading = true;
      const req = this.axios.post(`${currentBaseUrl}/qualityCompare/recordSources`, qs.stringify(params));
      req.then(({ data }) => {
        this.callList = (data.data && data.data.data) || [];
        this.total = data.data && data.data.count;
        this.callLoading = false;
      }).catch(() => {
        this.callLoading = false;
      })
    },
    init() {
      if (this.businessType && this.modelId && this.modelUpdateTime) {
        // 第一次请求的数据都是默认值
        // this.params.businessType = this.businessType;
        this.params.modelId = this.modelId;
        this.params.modelUpdateTime = this.formatTime(+this.modelUpdateTime);
        this.params.startTime = this.startTime;
        this.params.endTime = this.endTime;
        this.params.statisticsSize = this.statisticsSize;
        this.getTabOne();
      }
    },
    showLoading() {
      this.loading = this.$loading({
        lock: true,
        text: '加载中',
        spinner: 'el-icon-loading',
        // background: 'rgba(0, 0, 0, 0.7)'
      });
    },
    hideLoading() {
      this.loading.close();
    },
    formatTime(ts) {
      return moment(ts).format('YYYY-MM-DD HH:mm:ss')
    },
    showNothing() {}
  },
  mounted() {
    document.oncontextmenu = function() {
      return false
    }
    this.showLoading();
    this.getModel();
    console.log(this.startTime);
    // !this.showDetail && this.initServiceBar()
    this.recordPlayCloseHandler();
  },
}
</script>

<style lang="less">
.quality-wrapper {
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 0px 0px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
}
</style>
<style lang="less" scoped>
.quality-wrapper {
  width: 100%;
  height: 100%;
  padding: 0 20px 10px;
  box-sizing: border-box;

  header {
    width: 100%;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;

    span {
      font-size: 14px;
    }
  }

  .quality-search {
    border: 1px solid #ccc;
    padding: 20px 10px;

    label {
      margin: 0 10px;
    }
  }

  .header-tab {
    margin: 20px 0;
  }

  .quality-title {
    font-size: 14px;
  }
  .gray {
    color: #ccc;
  }

  .score-table-wrapper {
    width: 300px;
    margin-left: 10px;

    .score-table {
      border: 1px solid #ccc;
      height: 400px;
      box-sizing: border-box;
      padding: 0 10px;
      overflow-y: scroll;

      .score-item {
        cursor: pointer;
        height: 40px;
        border-bottom: 1px dashed #ccc;
        &:last-child {
          border-bottom: none;
        }

        &:hover{
          background: #eee;
        }

        &.green{
          color: green;
        }
      }

      .score-num {
        width: 40px;
      }
      .score-percent {
        width: 60px;
      }
    }
  }

  .quality-detail-wrapper{
    align-items: flex-start;
    height: 100%;

    .table-content{
      width: 100%;
      overflow-y: scroll;
    }

    .page{
      align-self: flex-end;
    }
  }
}
</style>
