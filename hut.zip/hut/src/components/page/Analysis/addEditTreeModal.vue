<template>
  <el-dialog
    :title="dialogTitle"
    :visible.sync="dialogVisible"
    :width="'740px'"
    :close-on-click-modal="closeOnClickModal"
    @open="onOpen"
    @close="canel"
  >
    <el-form :model="treeForm" ref="treeForm" :rules="treeFormRules" :inline="true">
      <el-form-item label="分类名称" prop="name">
        <!--<el-select @visible-change="bindCategoryFilter" :filter-method="existTopicData.length?null:onCategoryFilter" v-model="treeForm.name" placeholder="请选择" filterable >
          <el-option
            @queryChange="onCategoryFilter"
            :key='index'
            v-for="(item, index) in existTopicData"
            :props="existProps"
            :label="item"
            :value="item">
          </el-option>
        </el-select>-->
        <el-input v-model="treeForm.name"></el-input>
      </el-form-item>
      <el-form-item label="所属层级" prop="type">
        <el-input maxlength="10" disabled v-model="treeForm.type"></el-input>
      </el-form-item>
      <div class="martop">调用标签</div>
      <div class="flex-box">
        <el-form-item
          class="flex-box-list"
          v-for="(domain, index) in treeForm.domains"
          :key="index"
          prop="domains"
        >
          <el-select
            v-model="domain.relation"
            style="width: 112px; margin-right: 10px;"
            v-if="index > 0"
          >
            <el-option
              v-for="item in logicList"
              :key="item.label"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
          <el-select
            v-model="domain.labelId"
            :props="selectDefaultProps"
            filterable
            placeholder="请选择"
          >
            <el-option
              v-for="item in labelList"
              :key="item.labelId"
              :label="getLabelName(item)"
              :value="item.labelId"
            >
              <el-popover
                v-if="item.keyWords && item.keyWords.length"
                placement="right"
                :open-delay="delay"
                trigger="hover"
              >
                <div
                  v-for="word in item.keyWords"
                  style="max-width:400px;margin:5px 0;line-height:1.25em;"
                >
                  {{ getKeywordLabel(word) }}
                </div>
                <div slot="reference">{{ getLabelName(item) }}</div>
              </el-popover>
            </el-option>
          </el-select>
          <i
            class="el-icon-remove iconDomain"
            v-if="treeForm.domains.length > 1"
            @click.prevent="removeDomain(domain)"
          ></i>
          <i
            class="el-icon-circle-plus iconDomain"
            @click="addDomain"
            v-if="index === treeForm.domains.length - 1"
          ></i>
        </el-form-item>
      </div>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="canel">取 消</el-button>
      <el-button type="primary" @click="saveTree">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
const deleteEmptyChildren = function deleteEmptyChildren(treeArr) {
  if (!treeArr) {
    return
  }
  treeArr.forEach((item) => {
    if (item.children && item.children instanceof Array && item.children.length > 0) {
      deleteEmptyChildren(item.children)
    } else {
      delete item.children
    }
  })
}
import global from '@/global'
import { validModelTrim } from '@/utry-sdk/common/constants'
let currentBaseUrl = global.currentBaseUrl
let requestUrls = {
  getAllRecordLabel: currentBaseUrl + '/recordLabel/all',
  getExistTopic: currentBaseUrl + '/ivsClusterRule/getExistTopic', // 分类名称下拉list
}
export default {
  props: {
    editTreeData: {
      type: Object,
    },
    parentSortName: {
      type: String,
    },
    parentSortID: {
      type: String,
    },
    sortIDPID: {
      type: String,
    },
    addEditTreeName: {
      type: String,
    },
    typeName: {
      type: String,
    },
    typeSortID: {
      type: String,
    },
  },
  data() {
    return {
      editData: [],
      delay: 500,
      existProps: {
        value: 'topicName',
        label: 'topicName',
      },
      existTopicData: [],
      existTopicDataMap: {},
      selectDefaultProps: {
        value: 'labelId',
        label: 'labelName',
      },
      labelList: [],
      logicList: [
        {
          value: 'OR',
          label: 'OR',
        },
        {
          value: 'AND',
          label: 'AND',
        },
      ],
      treeForm: {
        name: '',
        type: '无',
        domains: [
          {
            relation: 'OR',
            add: false,
            labelName: '',
            labelId: '',
          },
        ],
      },
      treeFormRules: {
        name: [{ validator: validModelTrim, required: true, trigger: 'blur' }],
      },
      dialogTitle: '新建分类',
      dialogVisible: false,
      closeOnClickModal: false, // 点击modal可以关闭弹框?
    }
  },

  watch: {
    // loadData(val, oldval) {},
  },
  methods: {
    getKeywordLabel(word) {
      const { keywordContext, fullScriptRole } = word
      const map = {
        '0': '全部',
        '1': '客户',
        '2': '客服',
      }
      const role = map[fullScriptRole] || ''
      return `${role ? `${role}：` : ''}${(keywordContext || '').trim()}`
    },
    bindCategoryFilter(visible) {
      this.categoryFilterAllowed = !!visible
    },
    // 分类搜索中
    onCategoryFilter(value) {
      if (this.categoryFilterAllowed) {
        const form = this.treeForm
        const prevValue = form.name
        const currValue = (value || '').trim()
        if (currValue !== prevValue) {
          form.name = currValue
        }
      }
    },
    canel() {
      this.treeForm.name = ''
      this.treeForm.type = ''
      this.treeForm.domains = [
        {
          relation: 'OR',
          add: false,
          labelName: '',
          labelId: '',
        },
      ]
      this.$emit('close')
      this.$refs.treeForm.clearValidate()
    },
    saveTree() {
      if (this.treeForm.name == '其他') {
        this.$message.error('分类名称不可为其他！')
        return
      }
      this.$refs['treeForm'].validate((valid) => {
        if (valid) {
          // 判断标签
          if (this.treeForm.domains == null || this.treeForm.domains.length == 0) {
            this.treeForm.domains = [
              { add: false, labelId: '', labelName: '', relation: 'OR' },
            ]
          }
          let domainsDb = true
          let msg = '调用标签不能重复'
          if (this.treeForm.domains[0].lableId !== '') {
            this.treeForm.domains.forEach((val, i) => {
              let domains = JSON.parse(JSON.stringify(this.treeForm.domains))
              if (val.labelId) {
                domains.splice(i, 1)
                let domainsString = domains.map((item) => item.labelId).join('||')
                if (domainsString.indexOf(val.labelId) >= 0) {
                  domainsDb = false
                }
              } else {
                if (this.treeForm.domains.length > 1) {
                  this.treeForm.domains.forEach((val, i) => {
                    if (val.labelId === '') {
                      domainsDb = false
                      msg = '调用标签不能为空'
                    }
                  })
                }
              }
            })
          }
          // 调用标签异常判断
          if (!domainsDb) {
            this.$message({
              type: 'info',
              message: msg,
            })
            return
          }
          // 添加树接口
          let params = {
            labels: this.treeForm.domains,
            sortName: this.treeForm.name,
            parentSortID: this.parentSortID == '' ? null : this.parentSortID,
          }
          let tid
          if (this.typeSortID === '') {
            tid = this.sortIDPID
          } else {
            tid = this.typeSortID
          }
          let url
          if (this.addEditTreeName === '修改分类') {
            url = currentBaseUrl + '/recordSort/trees/' + tid
            this.axios
              .put(url, params, {
                headers: {
                  'Content-Type': 'application/json;charset=UTF-8',
                },
              })
              .then((response) => {
                if (response.data.code == 0) {
                  this.$message.success('修改成功！')
                  this.$refs.treeForm.clearValidate()
                  this.$emit('addEditFormData')
                } else {
                  var message = response.data.message + ''
                  if (message.indexOf('未找到分类节点') >= 0) {
                    this.$message.error('此分类节点已被删除!')
                    this.$refs.treeForm.clearValidate()
                    this.$emit('addEditFormData')
                  } else if (message.indexOf('标签') >= 0) {
                    this.$message.error(message)
                  } else {
                    this.$message.error('修改分类名称失败！')
                    this.$refs.treeForm.clearValidate()
                    this.$emit('addEditFormData')
                  }
                }
              })
              .catch((err) => {
                console.log(err)
              })
          } else {
            url = currentBaseUrl + '/recordSort/trees/' + tid + '/children'
            this.axios
              .post(url, params, {
                headers: {
                  'Content-Type': 'application/json;charset=UTF-8',
                },
              })
              .then((response) => {
                if (response.data.code == 0) {
                  this.$message.success('添加成功！')
                  this.$emit('addEditFormData')
                } else {
                  var message = response.data.message + ''
                  if (message.indexOf('标签') >= 0) {
                    this.$message.error(message)
                    // this.$emit('addEditFormData')
                  } else {
                    this.$message.error('新建分类名称不能重复！')
                  }
                }
                this.$refs.treeForm.clearValidate()
              })
              .catch((error) => {
                console.log(error.message)
              })
          }
        }
      })
    },
    getLabelName(item) {
      return item.executeState == '1' ? item.labelName : item.labelName + '（停用中）'
    },
    addDomain() {
      this.treeForm.domains.push({
        relation: 'OR',
        add: false,
        labelId: '',
        labelName: '',
      })
    },
    removeDomain(item) {
      let that = this
      let index = that.treeForm.domains.indexOf(item)
      if (index !== -1) {
        that.treeForm.domains.splice(index, 1)
      }
      if (that.treeForm.domains.length === 0) {
        that.treeForm.domains = [
          {
            relation: 'OR',
            add: false,
            labelName: '',
            labelId: '',
          },
        ]
      }
    },
    // 获取所有录音标签
    getAllRecordLabel() {
      this.axios
        .get(requestUrls['getAllRecordLabel'])
        .then((res) => {
          this.labelList = res.data.data
        })
        .catch(() => {})
    },
    getExistTopic() {
      this.axios
        .post(requestUrls['getExistTopic'])
        .then((res) => {
          if (res.data) {
            let existTopicDataMap = {}
            if (res.data != null && res.data.length > 0) {
              for (let i = 0; i < res.data.length; i++) {
                let topicName = res.data[i].topicName
                if (topicName !== '') {
                  existTopicDataMap[topicName] = res.data[i].topicClusterId
                }
              }
            }
            let newArr = []
            for (let i = 0; i < res.data.length; i++) {
              if (newArr.indexOf(res.data[i].topicName) == -1) {
                newArr.push(res.data[i].topicName)
              }
              this.existTopicData = newArr
            }
            this.existTopicDataMap = existTopicDataMap
          }
        })
        .catch(() => {})
    },
    onOpen() {
      this.getAllRecordLabel()
      this.getExistTopic()
      if (this.addEditTreeName !== '') {
        this.dialogTitle = this.addEditTreeName
      }
      if (this.addEditTreeName === '修改分类') {
        this.treeForm.name = this.editTreeData.sortName
        this.treeForm.type = this.parentSortName
        if (this.editTreeData.labels.length > 0) {
          this.treeForm.domains = this.editTreeData.labels
        }
        if (this.sortIDPID == this.editTreeData.parentSortID) {
          this.treeForm.type = '无'
        } else {
          this.treeForm.type = this.editTreeData.parentSortName
        }
      } else {
        if (this.typeSortID == '') {
          this.treeForm.type = '无'
        } else {
          this.treeForm.type = this.editTreeData.sortName
        }
      }
    },
  },
}
</script>
<style lang="less" scoped>
.martop {
  margin-bottom: 10px;
  margin-top: 10px;
}
.flex-box {
  display: flex;
  flex-flow: row wrap;
  width: 700px;
  .iconDomain {
    font-size: 16px;
    cursor: pointer;
    margin-left: 10px;
  }
  .flex-box-list {
    width: 100%;
  }
}
</style>
