<template>
  <div class="algorithmTree" id="algorithmTree">
    <div class="container">
      <div class="layout-box">
        <div class="top">
          <div class="leftTreeBox">
            <el-tabs v-model="activeName">
              <el-tab-pane
                :label="this.algorithmName"
                :key="this.algorithmId"
                name="first"
              ></el-tab-pane>
            </el-tabs>
          </div>
          <div class="rightButton">
            <!--<i  :class='["el-icon-remove editIcon", {
              "disabled": treeList.length <= 0
              }]' @click=""></i>
            <i :class='["el-icon-circle-plus editIcon",
              {
                "disabled": treeList.length >= 5
              }]' @click="" style="margin-right: 20px;"></i>-->
          </div>
        </div>
        <div class="content">
          <div class="leftTree">
            <div class="itemBox">
              <div class="saveBotton">
                <div class="switch" @click="switchTree">
                  <el-badge>切换关键词模式</el-badge>
                </div>
                <div class="toolTop">
                  <el-tooltip
                    ref="$dateTooltip"
                    class=""
                    effect="dark"
                    content="录音时间筛选"
                    placement="bottom-start"
                  >
                    <el-popover
                      placement="bottom-start"
                      width="400"
                      v-model="visible3"
                      trigger="click"
                    >
                      <el-date-picker
                        :default-time="['00:00:00', '23:59:59']"
                        v-model="value4"
                        :clearable="clearable"
                        type="datetimerange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期"
                        @change="dateChange"
                      >
                      </el-date-picker>
                      <el-button
                        slot="reference"
                        size="small"
                        icon="iconfont icon-shijianshaixuan"
                      ></el-button>
                    </el-popover>
                  </el-tooltip>
                </div>
                <div class="itemAll">
                  <div @click="clickAllClass" style="cursor: pointer">
                    全部 (共{{ this.count }}通录音)
                  </div>
                </div>
              </div>
            </div>
            <div class="treeBox-scroll">
              <div class="treeBox">
                <el-tree
                  ref="rData"
                  :data="algorithmData"
                  default-expand-all
                  node-key="sortID"
                  :props="defaultProps"
                  :expand-on-click-node="false"
                  @node-click="nodeClick"
                >
                </el-tree>
              </div>
            </div>
          </div>
          <div class="rightContent">
            <div class="layout-box">
              <div class="tabsContent">
                <nAudioList
                  v-show="this.audioIsResult === 'audio'"
                  :algorithmOther="algorithmOther"
                  :isAlgorithm="isAlgorithm"
                  :hotWordSizeNew="hotWordSizeNew"
                  :topicID="topicID"
                  :clearShow="clearShow"
                  :sortID="sortID"
                  :taskBeginTime="taskBeginTime"
                  :taskEndTime="taskEndTime"
                ></nAudioList>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import global from '@/global'
import formatdate from '../../../utils/formatdate.js'
import nAudioList from './audioList.vue'
let currentBaseUrl = global.currentBaseUrl
export default {
  components: {
    nAudioList,
  },
  data() {
    return {
      algorithmOther: true,
      isAlgorithm: true,
      clearShow: true,
      defaultProps: {
        children: 'children',
        label: 'name',
      },
      taskBeginTime: '',
      taskEndTime: '',
      algorithmData: [],
      clearable: false,
      value4: [],
      visible3: false,
      count: '',
      audioIsResult: 'audio',
      activeName: 'first',
      algorithmId: '',
      algorithmName: '',
      treeId: '',
      hotWordSizeNew: 0,
      sortID: '',
    }
  },
  mounted() {
    let sortid = this.$store.state.algorithmTreeId.sortid // 拿到存在VUEX里的sortID
    if (sortid) {
      this.getAWeekTime()
      this.getTreeChildsBySortId()
    }
  },
  methods: {
    // 默认一个月时间
    getAWeekTime() {
      let that = this
      let fromTime = ''
      let toTime = ''
      this.value4 = []
      if (this.value4.length == 0) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        if (this.value4[0] != undefined && this.value4[0] != '') {
          fromTime = formatdate.formatDate(this.value4[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (this.value4[1] != undefined && this.value4[1] != '') {
          toTime = formatdate.formatDate(this.value4[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      that.value4 = [fromTime, toTime]
      that.taskBeginTime = fromTime
      that.taskEndTime = toTime
    },
    nodeClick(data) {
      console.log(data)
      this.sortID = data.id
    },
    dateChange(item) {
      console.log(item)
      if (item !== null) {
        let times1 = formatdate.formatDate(item[0])
        console.log(times1)
        let times2 = formatdate.formatDate(item[1])
        this.taskBeginTime = times1
        this.taskEndTime = times2
      } else {
        this.taskBeginTime = ''
        this.taskEndTime = ''
      }
      this.visible3 = false
      this.clearShow = true
      // this.getTreeListBySortID()
    },
    clickAllClass() {
      this.getTreeChildsBySortId()
    },
    getTreeChildsBySortId() {
      let params = {
        callId: '',
      }
      this.axios
        .get(
          currentBaseUrl + '/recordSortAlg/trees/' + this.sortIDPID + '/treeID',
          params
        )
        .then((response) => {
          console.log(response.data)
          this.algorithmId = response.data.data.id
          this.algorithmName = response.data.data.name
          this.count = response.data.data.count
          this.sortID = response.data.data.id
          this.topicID = response.data.data.id
          this.algorithmData = response.data.data.children
          this.getRadioByTreeId()
        })
        .catch(() => {})
    },
    // 获取某一个分类下的录音
    getRadioByTreeId() {
      let params = {
        callId: '',
      }
      this.axios
        .get(currentBaseUrl + '/recordSortAlg/' + this.algorithmId + '/records', params)
        .then((response) => {
          console.log(response.data)
        })
        .catch(() => {})
    },
    switchTree() {
      this.$router.push({ path: '/audioClassification' }) // 获取路由并导到目标页面
      // this.$emit('algorithmData')
    },
  },
}
</script>
<style lang="less" scoped>
.algorithmTree {
  height: 100%;
  width: 100%;
  z-index: 0;
  box-sizing: border-box;
  overflow: hidden;
  .container {
    overflow: hidden;
    height: 100%;
    position: relative;
    .top {
      border-bottom: 1px solid #e4e4e4;
      overflow: hidden;
      .rightButton {
        float: right;
        padding: 10px 10px 10px 0px;
      }
      .leftTreeBox {
        float: left;
        padding-left: 10px;
      }
    }
    .content {
      position: absolute;
      top: 61px;
      left: 0;
      bottom: 1px;
      width: 100%;
      .rightContent {
        margin-left: 260px;
        height: 100%;
        position: relative;
      }
      .leftTree {
        float: left;
        width: 260px;
        height: 100%;
        position: relative;
        border-right: 1px solid #e4e4e4;
        .itemBox {
          position: relative;
          height: 140px;
        }
        .treeBox-scroll {
          width: 260px;
          overflow-x: scroll;
          position: absolute;
          top: 140px;
          bottom: 0px;
          overflow-y: auto;
        }
        .treeBox {
          margin: 0 auto;
          width: 96%;
          top: 0;
          overflow-x: hidden;
          overflow-y: auto;
        }
        .saveBotton {
          overflow: hidden;
          text-align: right;
          .toolTop {
            margin: 10px;
          }
          .switch {
            margin: 10px;
            text-align: right;
            cursor: pointer;
          }
          .itemAll {
            text-align: center;
            margin: 10px;
            background: #f2f2f2;
            height: 46px;
            line-height: 46px;
            font-size: 14px;
          }
        }
      }
    }
  }
}
</style>
<style lang="less">
#algorithmTree {
  .layout-box {
    overflow: hidden;
    height: 100%;
    position: relative;
  }
  .el-tree {
    width: 100%;
  }
}
</style>
