<template>
  <div id="topicClusterShow" class="topicClusterShow">
    <div class="content">
      <div class="back">
        <p @click="backToHome()"><i>&lt;</i>返回</p>
        <el-button type="primary" :disabled="!submittable" @click="radioLeftclick"
          >确定训练</el-button
        >
      </div>
      <el-form :model="task2Form" ref="threeForm" :rules="formRules" label-width="100px">
        <el-form-item label="模型名称" prop="name">
          <el-input
            v-model="task2Form.name"
            placeholder="请输入模型名称"
            style="width: 300px;"
          ></el-input>
        </el-form-item>
      </el-form>
      <div class="teCi">
        <span class="title">启用主题词</span>
      </div>
      <div class="ciBox">
        <div class="leftWordBox">
          <div class="leftWordTop">
            全部 <span>(样本里全部特征词)</span>
            <div class="leftNum">{{ seletedNum.length }}/{{ allNums }}</div>
          </div>
          <div class="searchCon">
            <el-input
              placeholder="主题词查询"
              ref="keyWordLeft"
              class="searchInput"
              clearable
              v-model="leftKeyword"
              prefix-icon="el-icon-search"
            ></el-input>
            <el-cascader
              placeholder="用关键词词库筛选"
              :clearable="clearable"
              :options="options"
              :change-on-select="true"
              :show-all-levels="false"
              @change="handleLibWordChange"
            ></el-cascader>
            <el-tooltip placement="right-start" style="margin-left: 10px;" effect="light">
              <div slot="content">
                基于提前导入通用关键词词库的行业特征词, <br />
                快速筛选出样本里的行业特征词.
              </div>
              <i class="icon el-icon-question" style="font-size: 20px;"></i>
            </el-tooltip>
            <!--词频逻辑-->
            <el-button
              type="primary"
              style="margin-left: 10px;"
              @click="dialogVisible = true"
              plain
              >{{ megs }}</el-button
            >
            <el-dialog
              :visible.sync="dialogVisible"
              :close-on-click-modal="false"
              width="350px"
            >
              <!--滑块-->
              <div class="block" style="width: 300px;margin: 0 auto">
                <el-slider v-model="score" :max="audioCount"></el-slider>
                词频为 {{ this.score }} 以上
              </div>
              <span slot="footer" class="dialog-footer">
                <el-button plain class="leftBtn" @click="clearMegs">清空</el-button>
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="filterScore">确 定</el-button>
              </span>
            </el-dialog>
          </div>
          <div class="searchBox" v-if="leftWords.length > 0">
            <el-checkbox
              v-show="showCheckAll"
              :indeterminate="isIndeterminate"
              v-model="checkAll"
              @change="handleCheckAllChange"
              >全选</el-checkbox
            >
            <div style="margin: 15px 0;"></div>
            <div id="checkbox">
              <template v-for="word in leftWords">
                <el-checkbox
                  v-show="!word.excluded"
                  v-model="word.checked"
                  @change="onLeftWordCheckStateChange(word, arguments[0])"
                  >{{ word.element }} {{ word.score }}</el-checkbox
                >
              </template>
            </div>
            <div v-show="showEmptyHint">
              <!--壹-->
              <div style="text-align: center">
                无筛选结果，依旧
                <el-button type="text" @click="addTopic">选择为主题词</el-button>
              </div>
              <!--贰-->
              <div v-show="isCome">
                <!-- 在水词 || 在关键词-->
                <div v-if="isExist" style="text-align: center">
                  该词在聚类水词库中，在本词表中会被自动过滤 <br />
                  <el-button type="text" @click="waterDelete"
                    >从聚类水词库中移除</el-button
                  >
                  <el-tooltip
                    placement="right-start"
                    style="margin-left: 10px;"
                    effect="light"
                  >
                    <div slot="content">
                      移除之后刷新页面，再次搜索 <br />
                      可检验样本中是否出现该词
                    </div>
                    <i class="icon el-icon-question" style="font-size: 20px;"></i>
                  </el-tooltip>
                </div>
                <!-- 不在水词 && 不在关键词-->
                <div v-if="!isExist" style="text-align: center">
                  该词不在通用关键词库中 <br />
                  <el-button type="text" @click="dialogFormVisible = true"
                    >加入通用关键词库</el-button
                  >
                  <el-dialog
                    title="添加关键词库"
                    style="text-align: left"
                    width="400px"
                    top="35vh"
                    :visible.sync="dialogFormVisible"
                    :close-on-click-modal="false"
                  >
                    <el-cascader
                      placeholder="请添加"
                      :clearable="clearable"
                      :options="options"
                      :change-on-select="true"
                      :show-all-levels="false"
                      @change="selectId"
                    ></el-cascader>
                    <div slot="footer" class="dialog-footer">
                      <el-button @click="dialogFormVisible = false">取 消</el-button>
                      <el-button type="primary" @click="addKeyWordList">确 定</el-button>
                    </div>
                  </el-dialog>
                </div>
              </div>
              <!--叁-->
              <div style="text-align: center" v-show="isSimilar">
                相似词：
                <div id="checkbox" style="display: inline">
                  <el-checkbox
                    v-model="word.checked"
                    @change="onLeftWordCheckStateChange(word, arguments[0])"
                    v-for="(word, index) in similarList"
                    :key="index"
                  >
                    {{ word.element }} {{ word.score }}
                  </el-checkbox>
                </div>
              </div>
            </div>
          </div>
          <div class="searchBox" v-else>
            <div style="margin: 15px 0;"></div>
            <div v-show="!showEmptyHint" style="text-align: center">无筛选结果</div>
            <div v-show="showEmptyHint">
              <!--壹-->
              <div style="text-align: center">
                无筛选结果，依旧
                <el-button type="text" @click="addTopic">选择为主题词</el-button>
              </div>
              <!--贰-->
              <div v-show="isCome">
                <!-- 在水词 || 在关键词-->
                <div v-if="isExist" style="text-align: center">
                  该词在聚类水词库中，在本词表中会被自动过滤 <br />
                  <el-button type="text" @click="waterDelete"
                    >从聚类水词库中移除</el-button
                  >
                  <el-tooltip
                    placement="right-start"
                    style="margin-left: 10px;"
                    effect="light"
                  >
                    <div slot="content">
                      移除之后刷新页面，再次搜索 <br />
                      可检验样本中是否出现该词
                    </div>
                    <i class="icon el-icon-question" style="font-size: 20px;"></i>
                  </el-tooltip>
                </div>
                <!-- 不在水词 && 不在关键词-->
                <div v-if="!isExist" style="text-align: center">
                  该词不在通用关键词库中 <br />
                  <el-button type="text" @click="dialogFormVisible = true"
                    >加入通用关键词库</el-button
                  >
                  <el-dialog
                    title="添加关键词库"
                    style="text-align: left"
                    width="400px"
                    top="35vh"
                    :visible.sync="dialogFormVisible"
                    :close-on-click-modal="false"
                  >
                    <el-cascader
                      placeholder="请添加"
                      :clearable="clearable"
                      :options="options"
                      :change-on-select="true"
                      :show-all-levels="false"
                      @change="selectId"
                    ></el-cascader>
                    <div slot="footer" class="dialog-footer">
                      <el-button @click="dialogFormVisible = false">取 消</el-button>
                      <el-button type="primary" @click="addKeyWordList">确 定</el-button>
                    </div>
                  </el-dialog>
                </div>
              </div>
              <!--叁-->
              <div style="text-align: center" v-show="isSimilar">
                相似词：
                <div id="checkbox" style="display: inline">
                  <el-checkbox
                    v-model="word.checked"
                    @change="onLeftWordCheckStateChange(word, arguments[0])"
                    v-for="(word, index) in similarList"
                    :key="index"
                  >
                    {{ word.element }} {{ word.score }}
                  </el-checkbox>
                </div>
              </div>
            </div>
          </div>
          <div class="loading" v-if="showMoreBox">
            <el-button
              type="primary"
              @click="more"
              :disabled="buttonDisabled"
              v-if="showMore"
              >加载更多</el-button
            >
            <el-button type="primary" :loading="true" v-if="!showMore">加载中</el-button>
          </div>
        </div>
        <div class="rightWordBox">
          <div class="rightWordTop">
            已选择主题词 <span>不得少于200个</span>
            <div class="leftNum">{{ this.tags.length }}</div>
          </div>
          <el-input
            placeholder="主题词查询"
            clearable
            v-model="rightKeyword"
            prefix-icon="el-icon-search"
          ></el-input>
          <div class="rightWordContent">
            <template v-for="word in rightWords">
              <el-tag
                v-show="word.checked && !word.selectExcluded"
                @close="onRightWordRemoved(word)"
                :key="word.binaryElement"
                :disable-transitions="true"
                closable
                type="info"
              >
                {{ word.element }} {{ word.score }}
              </el-tag>
            </template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Qs from 'qs'
import global from '@/global.js'

let currentBaseUrl = global.currentBaseUrl
let qualityUrl = global.qualityUrl
let pageNumber = 1
let sortOrder = 0
export default {
  data() {
    let checkName = (rule, valueOne, callback) => {
      if (!valueOne) {
        return callback(new Error('请输入模型名称'))
      }
      let reg = new RegExp(/^\s+$/)
      if (reg.test(valueOne)) {
        callback(new Error('请勿输入空格'))
      }
      callback()
    }
    return {
      submittable: false,
      keyListId: '', //关键词库的菜单ID
      dialogFormVisible: false,
      audioCount: 0, //词频最大数量
      toDeleteWaterWord: '',
      isCome: false, // 是否显示提示词
      isSimilar: false, // 是否在相似词库
      isKeyword: true, // 是否在通用关键词库
      isWater: true, // 是否在聚类水词库
      newTopic: [], //新添加到右侧的主题词
      score: 0, //词频数
      dialogVisible: false, //词频逻辑的对话框
      showMoreBox: true,
      clearable: true,
      buttonDisabled: false,
      showMore: true,
      showSearchBox: false, // 已选择搜索结果显示
      isCanAddTwo: true,
      isCanAdd: true,
      wordList: [],
      wordKu: [],
      // tags: [],
      tagsSearch: [],
      result: false,
      checkboxGroup1: [],
      checkAll: false,
      checkedWords: [],
      leftWords: [], //左侧词
      rightWords: [], //右侧词
      // isIndeterminate: true,
      value: '',
      options: [],
      // 左侧搜索输入内容
      leftKeyword: '',
      // 右侧搜索输入内容
      rightKeyword: '',
      //相似词参数数据
      similarWordsData: [],
      similarList: [],
      valuethree: '',
      ciNum: '',
      newCopy: true,
      pageNum: [
        {
          value: '10',
          label: '10条/页',
        },
        {
          value: '50',
          label: '50条/页',
        },
        {
          value: '100',
          label: '100条/页',
        },
        {
          value: '500',
          label: '500条/页',
        },
      ],
      pageWide: '10条/页',
      treeNum: 0,
      lastPage: 1,
      lastSize: 10,
      inputShow: false,
      clickModalTwo: false,
      dataValue: [],
      topicClusteringShowDialog: false,
      task2Form: {
        name: '',
      },
      formRules: {
        name: [
          { min: 1, max: 10, message: '长度在 1 到 10 个字符', trigger: 'blur' },
          { required: true, validator: checkName, trigger: 'blur' },
        ],
      },
      modelSeat: {
        chModel: '',
      },
      modelList: [],
      goodNice: [],
      goodNices: [],
      value4: [],
      megs: '词频',
      mScore: 0,
      deleteData: [],
      NoVlue: 0,
    }
  },
  mounted() {
    let msg = this.$route.params
    console.log(msg)
    if (msg.sortIDPID) {
      let msgData = {
        sortId: this.$route.params.sortIDPID,
        startTime: this.$route.params.taskBeginTime,
        endTime: this.$route.params.taskEndTime,
        tName: this.$route.params.tName,
      }
      let newData = JSON.stringify(msgData)
      localStorage.setItem('backHomeData', newData) // 保存树的id和时间，点击返回的时候回到点击之前的状态
      this.saveClusterKeywordByTreeId() // 存储特征词列表信息
      this.getTrees() // 词库引用的数据
      this.getSimilar() //获取相似词库
    } else {
      this.$router.push({ path: '/audioClassification' }) // 获取路由并导到目标页面
      const loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)',
      })
      loading.close()
    }
    //关闭浏览器或者刷新重载页面时提示用户
    this.mywindow.onbeforeunload = function(e) {
      e = e || window.event
      // 兼容IE8和Firefox 4之前的版本
      if (e) {
        e.returnValue = '关闭提示'
      }
      // Chrome, Safari, Firefox 4+, Opera 12+ , IE 9+
      return '关闭提示'
    }
  },
  destroyed() {
    this.mywindow.onbeforeunload = null
  },
  watch: {
    leftKeyword() {
      this.leftKeyword !== ''
        ? (this.showMoreBox = true)
        : ((this.showMoreBox = true), this.getClusterWordByTreeId())
      this.isSimilar = false
      this.similarList = []
      this.filterLeftWords()
    },
    rightKeyword(val) {
      this.filterRightWords(val)
    },
    isIndeterminate() {
      this.checkAll = !this.leftWords
        .filter((word) => !word.excluded)
        .some((word) => !word.checked)
    },
    training: {
      handler: function(newVal) {
        let name = newVal.name
        if (name && name.trim() && this.tags.length >= 200) {
          this.submittable = true
        } else {
          this.submittable = false
        }
      },
      deep: true,
    },
  },
  //判断用户是否跳转路由
  beforeRouteLeave(to, from, next) {
    if (to.path === '/audioClassification') {
      next()
    } else {
      this.$confirm('关闭将失此页面数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          next()
        })
        .catch(() => {
          next(false)
        })
    }
  },
  computed: {
    training() {
      const { rightWords } = this
      const name = this.task2Form.name
      return {
        rightWords,
        name,
      }
    },
    showCheckAll() {
      const leftWords = this.leftWords
      return leftWords.filter((word) => !word.excluded).length > 1
    },
    isIndeterminate() {
      const leftWords = this.leftWords.filter((word) => !word.excluded)
      const checkedCount = leftWords.filter((word) => !!word.checked).length
      return checkedCount === 0 ? undefined : checkedCount !== leftWords.length
    },
    tags() {
      return this.rightWords
    },
    allNums() {
      return this.leftWords.length
    },
    seletedNum() {
      return this.leftWords.filter((word) => !!word.checked)
    },
    showEmptyHint() {
      return (
        !this.leftWords.filter((word) => !word.excluded).length && this.leftKeyword.trim()
      )
    },
    isExist() {
      this.isCome = true
      let valBool = true
      if (this.isWater === false && this.isKeyword === false) {
        valBool = false
      } else if (this.isWater === true) {
        //既在水词又在关键词&在水词
        //找出这个水词
        this.toDeleteWaterWord = this.leftKeyword
      } else {
        this.isCome = false
      }
      return valBool
    },
  },
  methods: {
    //传值
    filterScore() {
      this.dialogVisible = false
      //获取通过词频过滤之后的特征词
      this.getClusterWordByTreeId()
      this.setWordCheckStateInLeft()
      if (this.score > 0) {
        this.megs = `${this.score} 词频以上`
      } else {
        this.megs = '词频'
      }
    },
    //清空词频
    clearMegs() {
      this.score = 0
    },
    //添加新词到右侧主题词
    addTopic() {
      const { leftKeyword } = this
      const beforeTopic = this.newTopic || []
      for (let index in beforeTopic) {
        if (leftKeyword === beforeTopic[index].element) {
          this.$message({
            message: '该关键词已存在',
            type: 'warning',
          })
          return
        }
      }
      const newTopic = {
        element: leftKeyword,
        checked: true,
        selectExcluded: false,
        sortOrder: ++sortOrder,
      }
      this.newTopic.push(newTopic)
      this.leftKeyword = ''
      this.rightWords.push(newTopic)
      this.rightWords.sort((a, b) => {
        return b.sortOrder - a.sortOrder
      })
    },
    // 左侧词checked状态改变，同步左右两侧
    onLeftWordCheckStateChange(word, checked) {
      const rightWords = this.rightWords
      // 在右侧
      let rightArr = []
      for (let i = 0; i < rightWords.length; i++) {
        rightArr.push(rightWords[i].element)
      }
      const idx = rightArr.indexOf(word.element)
      if (checked && idx === -1) {
        // 选中操作
        rightWords.push(word)
      }
      if (!checked && idx !== -1) {
        // 取消选中
        rightWords.splice(idx, 1)
      }
      word.sortOrder = checked ? ++sortOrder : 0
      rightWords.sort((a, b) => {
        return b.sortOrder - a.sortOrder
      })
    },
    // 将右侧存在的词，同步选中到左侧（左侧词重新加载时）
    setWordCheckStateInLeft() {
      const leftWords = this.leftWords
      const rightWords = this.rightWords
      leftWords.forEach((word) => {
        // 如果在右边，则选中，否则取消选中
        word.checked = rightWords.some((item) => item.element === word.element)
      })
    },
    // 右侧词库取消选中，取消左侧选中的状态
    onRightWordRemoved(word) {
      const leftWords = this.leftWords
      const rightWords = this.rightWords
      const newTopic = this.newTopic
      // 在左侧找
      let leftArr = []
      for (let i = 0; i < leftWords.length; i++) {
        leftArr.push(leftWords[i].element)
      }
      const idx = leftArr.indexOf(word.element)
      if (idx !== -1) {
        leftWords.forEach((words) => {
          if (words.element === word.element) {
            words.checked = false
          }
        })
        rightWords.splice(rightWords.indexOf(word), 1)
      } else {
        newTopic.forEach((topic) => {
          if (topic.element === word.element) {
            rightWords.splice(rightWords.indexOf(word), 1)
            newTopic.splice(newTopic.indexOf(word), 1)
          }
        })
      }
      this.setWordCheckStateInLeft()
    },
    handleLibWordChange(item) {
      if (item.length) {
        let nums = item.length
        let id
        let lastnums
        if (nums === 1) {
          id = item[0]
        } else {
          lastnums = nums - 1
          id = item[lastnums]
        }
        this.id = id
      } else {
        this.id = ''
      }
      this.getClusterWordByTreeId()
    },
    // 过滤左侧待选词列表
    filterLeftWords() {
      const leftKeyword = (this.leftKeyword || '').trim().toLowerCase()
      //过滤特征词库
      this.leftWords.forEach((leftWord) => {
        const word = leftWord.element
        // 模糊关键字查找
        leftWord.excluded = leftKeyword ? word.indexOf(leftKeyword) === -1 : false
      })
      //如果在特征词库中，则不去发请求
      if (this.leftWords.filter((word) => !word.excluded).length) {
        return
      }
      //过滤关键词库
      let keywordModel = {
        wordId: 4535,
        wordlibType: 1,
        wordName: leftKeyword,
      }
      this.axios
        .post(
          qualityUrl + '/vocabulary/checkKeyWordisExist.do',
          Qs.stringify(keywordModel)
        )
        .then((res) => {
          this.isKeyword = res.data
        })
      //过滤水词库
      let waterModel = {
        wordId: 4535,
        wordlibType: 5,
        wordName: leftKeyword,
      }
      this.axios
        .post(qualityUrl + '/vocabulary/checkKeyWordisExist.do', Qs.stringify(waterModel))
        .then((res) => {
          this.isWater = res.data
        })
      //过滤相似词库
      let similarModel = {
        wordId: 4535,
        wordlibType: 4,
        wordName: leftKeyword,
      }
      this.axios
        .post(
          qualityUrl + '/vocabulary/checkKeyWordisExist.do',
          Qs.stringify(similarModel)
        )
        .then((res) => {
          if (res.data === true && leftKeyword) {
            const sVal = this.similarWordsData.filter((val) => {
              return val.wordName === this.leftKeyword
            })
            if (sVal.length) {
              let listArr = sVal[0].wordNames.split(',')
              const leftWords = this.leftWords
              leftWords.forEach((word) => {
                let element = word.element
                for (let i = 0; i < listArr.length; i++) {
                  if (listArr[i] === element) {
                    this.similarList.push(word)
                    this.isSimilar = true
                  }
                }
              })
            }
          }
        })
    },
    // 过滤右侧已选词列表
    filterRightWords(val) {
      const rightWords = this.rightWords
      if (!Array.isArray(rightWords)) {
        return
      }
      const keyword = val ? val.trim().toLowerCase() : ''
      const prop = 'selectExcluded'
      if (val) {
        for (let i = 0; i < rightWords.length; i++) {
          const word = rightWords[i]
          word[prop] = `${word.element}`.toLowerCase().indexOf(keyword) === -1
        }
      } else {
        rightWords.forEach((word) => {
          word[prop] = false
        })
      }
    },
    //获取关键词分类
    getTrees() {
      let searchModel = {
        classId: 0,
        classType: 1,
      }
      this.axios
        .post(qualityUrl + '/vocabulary/getTrees.do', Qs.stringify(searchModel))
        .then((response) => {
          if (response.data.length > 0) {
            let newData = []
            for (let p = 0; p < response.data.length; p++) {
              if (response.data[p].childIqc !== null) {
                newData[p] = {
                  label: response.data[p].classTitle,
                  value: response.data[p].classId,
                  children: this.getChild(response.data[p].childIqc, []),
                }
              } else {
                newData[p] = {
                  label: response.data[p].classTitle,
                  value: response.data[p].classId,
                }
              }
            }
            this.options = newData
          }
        })
        .catch(function() {})
    },
    //获取相似词库
    getSimilar() {
      let params = {
        wordlibType: 5,
        pageSize: 500,
        currentPage: 1,
        classId: 0,
      }
      this.axios
        .post(qualityUrl + '/vocabulary/queryPage.do', Qs.stringify(params))
        .then((response) => {
          this.similarWordsData = response.data.Data
        })
        .catch((error) => {
          console.log(error)
        })
    },
    //获取关键词库ID
    selectId(item) {
      console.log(item)
      if (item.length > 0) {
        let nums = item.length
        let id
        let lastNums
        if (nums === 1) {
          id = item[0]
        } else {
          lastNums = nums - 1
          id = item[lastNums]
        }
        this.keyListId = id
      } else {
        this.keyListId = ''
      }
    },
    //添加到通用关键词库中
    addKeyWordList() {
      let _this = this
      let params = {}
      params.wordNames = _this.leftKeyword
      if (_this.keyListId) {
        //操作日志分类
        params.classId = _this.keyListId
        //添加进关键词
        params.wordlibType = 1
        _this.axios
          .post(qualityUrl + '/vocabulary/addMoreWords.do', Qs.stringify(params))
          .then((res) => {
            if (!res.data || res.data == null) {
              _this.$message({
                type: 'error',
                message: '添加失败！',
              })
            } else if (res.data.length == 0) {
              _this.$message({
                type: 'success',
                message: '添加成功！',
              })
            } else {
              _this.$message({
                type: 'warning',
                message: '重复关键词：' + res.data,
              })
            }
            _this.leftKeyword = ''
          })
          .catch(() => {
            _this.$message({
              type: 'error',
              message: '添加失败！',
            })
          })
        _this.dialogFormVisible = false
        _this.keyListId = ''
      } else {
        _this.$message({
          type: 'warning',
          message: '请先选择分类',
        })
      }
    },
    //移除提示
    waterDelete() {
      const name = this.toDeleteWaterWord
      this.$confirm('确定要删除聚类水词' + '[' + name + ']吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.deteleWords(name)
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    //从水词库中移除
    deteleWords(name) {
      this.axios
        .post(
          qualityUrl + '/vocabulary/clusterWaterWord',
          Qs.stringify({ wordName: name })
        )
        .then((res) => {
          this.$message({
            type: 'success',
            message: '删除成功!',
          })
        })
        .catch((err) => {
          console.log(err)
          this.$message({
            type: 'error',
            message: '删除出现问题',
          })
        })
    },
    getChild(value, treeList) {
      for (let i = 0; i < value.length; i++) {
        if (value[i].childIqc !== null) {
          treeList[i] = {
            label: value[i].classTitle,
            value: value[i].classId,
            children: this.getChild(value[i].childIqc, []),
          }
        } else {
          treeList[i] = {
            label: value[i].classTitle,
            value: value[i].classId,
          }
        }
      }
      return treeList
    },
    more() {
      if (this.allNums < this.treeNum) {
        this.showMore = false
        pageNumber = pageNumber + 1
        const params = this.getQueryParams()
        this.fetchWords(params)
          .then((res) => {
            if (res.Data.length > 0) {
              const leftWords = res.Data
              this.showMore = true
              // 由于是分页加载，直接追加数据
              this.leftWords.push(...leftWords)
              // 追加数据，就不需要同步check状态了，因为追加进去的数据，肯定都是没有被checked的
            } else {
              this.$message('没有更多了')
              this.showMore = true
            }
          })
          .catch(() => {})
      } else {
        this.$message('没有更多了')
      }
    },
    // 获得随机id
    getID(length) {
      return Number(
        Math.random()
          .toString()
          .substr(3, length) + Date.now()
      ).toString(36)
    },
    handleCheckAllChange(checked) {
      this.leftWords
        .filter((word) => !word.excluded)
        .forEach((word) => {
          word.checked = !!checked
          this.onLeftWordCheckStateChange(word, checked)
          word.sortOrder = checked ? ++sortOrder : 0
        })
      this.saveClusterKeywordByTreeId()
    },
    backToHome() {
      this.$confirm('返回将丢失此页面数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$router.push({ path: '/audioClassification' }) // 获取路由并导到目标页面
        })
        .catch(() => {})
    },
    radioLeftclick(strateObject) {
      let _this = this
      let firty = this
      _this.submittable = false
      firty.$refs['threeForm'].validate(function(validate) {
        if (validate) {
          _this.addClusterRule(_this)
        }
      })
    },
    addClusterRule(_this) {
      const loading = this.$loading({
        lock: true,
        text: '提交中',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)',
      })
      let searchModel = {}
      let stringInput = ''
      let tagslist = []
      for (let o = 0; o < this.tags.length; o++) {
        tagslist.push(this.tags[o].element)
      }
      let stringArr = tagslist.join(',')
      /*
        for (let c = 0; c < this.addMake.domains.length; c++) {
          if (this.addMake.domains[c].value != '') {
            stringInput = stringInput + ',' + this.addMake.domains[c].value
          }
        }
        stringInput = this.addMake.count + stringInput*/
      searchModel.clusterRuleName = this.task2Form.name
      if (this.$route.params.topicShowID.endsWith('_other')) {
        searchModel.belongClass = this.$route.params.topicShowID.split('_other')[0]
        // searchModel.isOther = 1
      } else {
        searchModel.belongClass = this.$route.params.topicShowID
      }
      // searchModel.createMode = this.clusterRuleId
      searchModel.createMode = 0
      // searchModel.limitMutualNum = this.cellMake.everyCount
      // searchModel.showThemeWord = this.cellMake.count
      // searchModel.effectStrength = this.addMake.everyCount
      searchModel.startKeyword = stringArr
      searchModel.themeWord = stringInput

      searchModel.isOther = !!this.$route.params.isOtherZhu
      searchModel.sampleSource = '业务分类'
      searchModel.monitoringMode = this.NoVlue
      searchModel.keyWords = this.$route.params.keyWords
      searchModel.callId = this.$route.params.callId
      if (this.$route.params.labelIDs != null && this.$route.params.labelIDs.length > 0) {
        searchModel.labelIDs = this.$route.params.labelIDs.join(',')
      }
      switch (this.$route.params.sentimentRole) {
        case '全部':
          searchModel.sentimentRole = '0'
          break
        case '客户':
          searchModel.sentimentRole = '1'
          break
        case '客服':
          searchModel.sentimentRole = '2'
          break
      }
      switch (this.$route.params.sentimentLabel) {
        case '积极':
          searchModel.sentimentLabel = '0'
          break
        case '正常':
          searchModel.sentimentLabel = '1'
          break
        case '消极':
          searchModel.sentimentLabel = '2'
          break
      }
      searchModel.callSTimeMin = this.$route.params.callSTime_Min
      searchModel.callSTimeMax = this.$route.params.callSTime_Max
      searchModel.isSortAlg = !!this.$route.params.isAlgorithm
      // searchModel.baseModel = 1
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/addClusterRule.do',
          Qs.stringify(searchModel)
        )
        .then(function(response) {
          console.log(response)
          if (response.data.success === true) {
            _this.$message({
              type: 'success',
              message: '新建成功',
            })
            _this.topicClusteringShowDialog = false
            _this.$router.push({ path: '/audioClassification' }) // 获取路由并导到目标页面
          } else {
            _this.$message.error(response.data.message)
            this.topicClusteringShowDialog = false
            this.submittable = true
          }
        })
        .catch(function() {})
      loading.close()
    },
    /*radioLeftclickThrottle() {
      this.submittable = false
      this.lodashThrottle.throttle(this.radioLeftclick, this)
    },*/
    notChange: function() {
      this.topicClusteringShowDialog = false
    },
    removeDomain(item) {
      let index = this.addMake.domains.indexOf(item)
      if (index !== -1) {
        this.addMake.domains.splice(index, 1)
      }
    },
    close() {},
    onOpen() {
      this.resetSearchForm()
    },
    //存储特征词列表，只请求一次
    saveClusterKeywordByTreeId() {
      let bid
      if (this.$route.params.topicShowID !== null) {
        if (this.$route.params.topicShowID.endsWith('_other')) {
          bid = this.$route.params.topicShowID.split('_other')[0]
        } else {
          bid = this.$route.params.topicShowID
        }
      } else {
        bid = ''
      }
      let params = {
        belongClass: bid,
        isOther: !!this.$route.params.isOtherZhu,
        startWords: '',
        keyWords: this.$route.params.keyWords,
        callId: this.$route.params.callId,
        labelIDs: this.$route.params.labelIDs,
        sentimentRole: this.$route.params.sentimentRole,
        sentimentLabel: this.$route.params.sentimentLabel,
        callSTimeMin: this.$route.params.callSTime_Min,
        callSTimeMax: this.$route.params.callSTime_Max,
        keywordName: this.leftKeyword,
        isSortAlg: !!this.$route.params.isAlgorithm,
      }
      this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/saveClusterKeywordByTreeId',
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data.data === true) {
            this.getClusterWordByTreeId()
          }
        })
        .catch(function() {})
    },
    getQueryParams() {
      let bid
      if (this.$route.params.topicShowID !== null) {
        if (this.$route.params.topicShowID.endsWith('_other')) {
          bid = this.$route.params.topicShowID.split('_other')[0]
        } else {
          bid = this.$route.params.topicShowID
        }
      } else {
        bid = ''
      }
      let params = {
        isOther: !!this.$route.params.isOtherZhu,
        pageSize: 500,
        pageNumber: pageNumber,
        belongClass: bid,
        keywordName: this.leftKeyword,
        scoreMin: this.score, //多少词频以上
        scoreMax: this.audioCount || '', //最大词频数
        'ivsKeywordVo.wordlibType': 1,
        'ivsKeywordVo.classId': this.id,
      }
      if (!params['ivsKeywordVo.classId']) {
        delete params['ivsKeywordVo.wordlibType']
      }
      return params
    },
    //查询三个过滤条件的交集
    getClusterWordByTreeId() {
      const params = this.getQueryParams()
      params.pageNumber = 1
      this.treeNum = 0
      this.fetchWords(params)
        .then((res) => {
          if (res.Data.length > 0) {
            const leftWords = res.Data
            if (params.scoreMax === '') {
              //返回的最大词频
              this.audioCount = leftWords[0].score
            }
            leftWords.forEach((word) => {
              this.$set(word, 'checked', false)
              this.$set(word, 'excluded', false)
              this.$set(word, 'selectExcluded', false)
            })
            this.leftWords = leftWords
            this.showMore = true
            this.treeNum = res.Count
          }
          this.setWordCheckStateInLeft()
        })
        .catch(() => {
          this.leftWords = []
        })
    },
    fetchWords(params) {
      return this.axios
        .post(
          currentBaseUrl + '/ivsClusterRule/getClusterWordByTreeId',
          Qs.stringify(params)
        )
        .then((res) => {
          return res.data
        })
    },
    resetSearchForm: function() {
      this.value4 = []
      this.NoVlue = 0
    },
  },
}
</script>
<style lang="less">
#topicClusterShow .searchCon {
  .el-dialog__header {
    display: none;
  }
  .el-dialog__footer {
    border: 0;
  }
}
#topicClusterShow {
  .el-dialog__body {
    padding: 28px !important;
  }
  #checkbox {
    .el-checkbox__label {
      padding-left: 0 !important;
      font-size: 12px;
      color: #909399;
    }
    .el-checkbox__input.is-checked + .el-checkbox__label {
      color: #fff !important;
    }
    .el-checkbox__input {
      display: none !important;
    }
    .el-checkbox {
      border: 1px solid #ccc;
      background-color: #fff;
      text-align: center;
      margin: 4px;
      padding: 4px 10px;
      border-radius: 4px;
      font-size: 12px;

      &.is-checked {
        color: #fff;
        border: 1px solid #3d9bf8;
        background-color: #409eff;
      }
    }
  }
  .el-form--inline .el-form-item {
    margin-right: 0px !important;

    .el-form--inline .el-form-item {
      margin-right: 0px !important;
      width: 45%;
    }

    .el-checkbox-button__inner {
      border: none !important;
      padding: 5px !important;
      font-size: 12px !important;
      margin-right: 0px !important;
    }

    .el-checkbox-button:first-child .el-checkbox-button__inner {
      border-left: none !important;
    }

    .el-checkbox-button,
    .el-checkbox-button__inner {
      border: 1px solid #cccccc;
      border-radius: 5px;
      margin-right: 10px;
    }

    .el-tag--info {
      margin-right: 10px;
      margin-bottom: 10px;
    }

    .el-checkbox-group {
      label {
        margin-bottom: 10px;
      }
    }
  }
  .el-tag {
    margin: 0 8px 8px 0;
    line-height: 29px;
    height: 29px;
    box-sizing: border-box;
    background-color: #fff;
    border: 1px solid #ccc;
  }
}
</style>
<style scoped lang="less">
.topicClusterShow {
  width: 100%;
  height: 100%;
  overflow: hidden;
  .pageChangeNo {
    padding: 5px 30px;
    text-align: center;
  }
  .findBorder .el-transfer-panel {
    width: 288px;
  }
  .content {
    padding: 20px;
    height: calc(100% - 40px);
    overflow: auto;
    .addName {
      padding-left: 10px;
      i {
        font-size: 18px;
      }
    }
    .box {
      margin: 20px;
    }
    .teCi {
      overflow: hidden;
      margin: 20px;
      .title {
        font-size: 18px;
        font-weight: bold;
      }
      .info {
        padding-left: 10px;
        font-size: 14px;
        i {
          color: #cc3300;
          font-weight: bold;
        }
      }
    }
    .ciBox {
      margin: 20px;
      border-top: 1px solid #cccccc;
      display: flex;
      .leftNum {
        text-align: right;
        float: right;
        font-weight: normal;
        line-height: 40px;
      }
      flex: 1;
      .leftWordBox {
        flex: 6;
        border-right: 1px solid #cccccc;
        .searchCon {
          margin-top: 10px;
          margin-bottom: 10px;
          .searchInput {
            float: left;
            width: 200px;
            margin-right: 10px;
          }
          .el-dialog__header {
            display: none;
          }
        }
        .leftWordTop {
          border-bottom: 1px solid #cccccc;
          font-weight: bold;
          font-size: 18px;
          padding: 10px;
          span {
            font-size: 16px;
            font-weight: normal;
          }
        }
        .searchBox {
          padding: 10px;
          max-height: 400px;
          overflow: auto;
        }
        .wordList {
          padding: 10px;
          max-height: 400px;
          overflow: auto;
        }
        .loading {
          text-align: center;
          font-size: 14px;
          margin-top: 20px;
          span {
            color: #3399ff;
            text-decoration: underline;
          }
        }
      }
      .rightWordBox {
        flex: 4;
        .rightWordTop {
          border-bottom: 1px solid #cccccc;
          font-weight: bold;
          font-size: 18px;
          padding: 10px;
          span {
            font-weight: normal;
            font-size: 16px;
          }
        }
        .el-input {
          margin: 10px;
          display: block;
          width: 226px;
        }
        .rightWordContent {
          margin: 10px;
          max-height: 458px;
          overflow: auto;
        }
      }
    }
    .boxSecond {
      clear: both;
      padding-left: 30px;
      font-size: 14px;
      height: 45px;
      line-height: 45px;
    }
    .back {
      cursor: pointer;
      overflow: hidden;
      p {
        font-size: 14px;
        color: #3399ff;
        float: left;
        width: 100px;
      }
      .el-button {
        float: right;
      }
    }
  }
  .pageChangeNo .el-select {
    width: 110px;
    .el-input__inner {
      height: 36px;
      line-height: 36px;
    }
  }
}
</style>
