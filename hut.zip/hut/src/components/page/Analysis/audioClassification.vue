<template>
  <div class="audioClassification" id="audioClassification">
    <div class="container" v-if="!switchShow" v-loading="loading">
      <div class="layout-box">
        <div class="top">
          <div class="leftTreeBox">
            <el-tabs
              v-if="treeList.length > 0"
              v-model="activeName"
              @tab-click="handleClick"
            >
              <el-tab-pane
                v-for="item in treeList"
                :label="item.sortName"
                :key="item.sortID"
                :name="item.sortID"
              ></el-tab-pane>
            </el-tabs>
          </div>
          <div class="rightButton">
            <i
              :class="[
                'el-icon-remove editIcon',
                {
                  disabled: treeList.length <= 0,
                },
              ]"
              @click="deleteTree"
            ></i>
            <i
              :class="[
                'el-icon-circle-plus editIcon',
                {
                  disabled: treeList.length >= 5,
                },
              ]"
              @click="addTree"
              style="margin-right: 20px;"
            ></i>
          </div>
        </div>
        <div class="content">
          <div class="layout-box">
            <div class="leftTree">
              <div class="itemBox">
                <div class="treeName">
                  <p v-if="this.treeButton === 'gjc'">
                    {{ this.tName
                    }}<i class="iconfont icon-bianjishu" @click="editTreeName"></i>
                  </p>
                  <div
                    class="moshi"
                    v-show="this.algorithmType === true"
                    @click="switchTree('sfs')"
                  >
                    <el-badge :is-dot="isdot">切换到算法树模式</el-badge>
                  </div>
                  <div
                    class="moshi"
                    v-show="this.algorithmTypeT === true"
                    @click="switchTree('gjc')"
                  >
                    <el-badge>切换到关键词模式</el-badge>
                  </div>
                </div>
                <div class="saveBotton">
                  <div class="toolTop" id="toolTop" v-show="this.treeList.length > 0">
                    <el-button-group>
                      <el-button
                        v-if="addDide"
                        icon="el-icon-plus"
                        @click="addTreeType('add')"
                      ></el-button>
                      <el-button
                        v-if="hideEdit"
                        icon="el-icon-edit"
                        @click="addTreeType('edit')"
                      ></el-button>
                      <el-button
                        v-if="hideEdit"
                        icon="el-icon-delete"
                        @click="deleteTreeType"
                      ></el-button>
                      <el-tooltip
                        effect="dark"
                        content="录音时间筛选"
                        placement="bottom-start"
                      >
                        <el-popover
                          placement="bottom-start"
                          width="400"
                          v-model="visible3"
                          trigger="click"
                        >
                          <el-date-picker
                            :default-time="['00:00:00', '23:59:59']"
                            v-model="value4"
                            :clearable="false"
                            type="datetimerange"
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            @change="dateChange"
                          >
                          </el-date-picker>
                          <el-button
                            slot="reference"
                            size="small"
                            icon="iconfont icon-shijianshaixuan"
                          ></el-button>
                        </el-popover>
                      </el-tooltip>
                      <el-button
                        v-show="dropSuccess"
                        size="small"
                        @click="saveDrop"
                        icon="iconfont icon-iconset0237"
                      ></el-button>
                    </el-button-group>
                  </div>
                  <div v-if="this.treeType === 'gjc'">
                    <div v-if="this.showCopyTree === true" class="rightTop">
                      <div class="toolTopRight">
                        <el-tooltip
                          class="item"
                          effect="dark"
                          content="复制分类树进行算法分类"
                          placement="bottom-start"
                        >
                          <el-button
                            @click="copyTree"
                            :disabled="copyTreeButtonDisabled"
                            icon="iconfont icon-fuzhi"
                          ></el-button>
                        </el-tooltip>
                      </div>
                    </div>
                    <div v-else-if="this.showCopyTree === false" class="rightTop">
                      <div class="toolTopRight">
                        <el-tooltip
                          class="item"
                          effect="dark"
                          content="算法训练中"
                          placement="bottom-start"
                        >
                          <el-button icon="iconfont icon-fuzhi" type="info"></el-button>
                        </el-tooltip>
                      </div>
                    </div>
                  </div>
                  <div v-else="" class="rightTop">
                    <div class="toolTopRight"></div>
                  </div>
                </div>
                <div style="clear: both"></div>
                <div class="itemAll">
                  <div @click="clickAllClass" style="cursor: pointer">
                    全部 (共{{ this.counts }}通录音)
                  </div>
                </div>
              </div>
              <div class="treeBox-scroll">
                <div class="treeBox">
                  <el-tree
                    ref="rData"
                    :data="tDataAddOtherChild"
                    default-expand-all
                    node-key="sortID"
                    :props="defaultProps"
                    :expand-on-click-node="false"
                    :draggable="draggable"
                    @node-drag-start="nodeDragStart"
                    @node-drag-end="nodeDragEnd"
                    @node-click="nodeClick"
                  >
                    <span class="custom-tree-node" slot-scope="{ node, data }">
                      <span v-if="data.calculating === true"
                        >{{ node.label }} (计算中...)</span
                      >
                      <span v-else="">{{ node.label }} ({{ data.count }})</span>
                    </span>
                  </el-tree>
                </div>
              </div>
            </div>
            <div class="rightContent">
              <div class="layout-box">
                <div class="tabsContent">
                  <nAudioList
                    ref="nAudioList"
                    :treeType="treeType"
                    :isAlgorithm="isAlgorithm"
                    :hotWordSizeNew="hotWordSizeNew"
                    @searchData="searchData"
                    @returnData="returnData"
                    :clearShow="clearShow"
                    :taskBeginTime="taskBeginTime"
                    :taskEndTime="taskEndTime"
                    :acount="acount"
                    :isOther="isOther"
                    :isOtherAlgo="isOtherAlgo"
                    :resultLabelId="resultLabelId"
                    :topicCount="topicCount"
                    :biaoqianList="biaoqianList"
                    :topicID="topicID"
                    :sortID="sortID"
                    :sortIDPID="sortIDPID"
                    :tName="tName"
                    :nextHot="nextHot"
                  ></nAudioList>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <vTraining
      v-if="copyTreeModalShow"
      ref="copyTreeModalContent"
      :formParams="formParams"
      @trainingClose="trainingClose"
      @trainingData="trainingData"
      @close="closeModal"
      :taskBeginTime="taskBeginTime"
      :taskEndTime="taskEndTime"
      :sortIDPID="sortIDPID"
    ></vTraining>
    <vAddEditTreeModal
      :addEditTreeName="addEditTreeName"
      :typeName="typeName"
      :sortIDPID="sortIDPID"
      :typeSortID="typeSortID"
      :parentSortID="parentSortID"
      :editTreeData="editTreeData"
      @addEditFormData="addEditFormData"
      @close="treeModalClose"
      v-if="addEditTreeModalShow"
      ref="addEditTreeModalComponent"
    >
    </vAddEditTreeModal>
    <vEditTreeName
      :tName="tName"
      :tID="sortIDPID"
      @editTreeNameReturn="editTreeNameReturn"
      v-if="editTreeNameShow"
      ref="editTreeNameComponent"
    >
    </vEditTreeName>
    <vAddTree
      :tree-list="treeList"
      @addTreeReturn="addTreeReturn"
      ref="addTreeConponent"
      v-if="addTreeShow"
    >
    </vAddTree>
  </div>
</template>
<script>
import Qs from 'qs'
import formatdate from '../../../utils/formatdate.js'
import { validModelTrim } from '@/utry-sdk/common/constants'
// import cache from '../../../utils/cache.js' // 热点分析开始
// let CASTGC = cache.getItem('tgt_id')
import nAudioList from './audioList.vue'
import vAddEditTreeModal from './addEditTreeModal.vue' // 编辑、添加节点弹框
import vEditTreeName from './editTreeName.vue' // 编辑树名称弹框
import vAddTree from './addTree.vue' // 添加树弹框
import store from '@/store/index.js'
import global from '@/global.js'
import vTraining from './training.vue'
import { SimMessageClient } from '../../../utils/socket/utrywebsocket.js'

function createMessageClient(op = {}) {
  let simMessageClient = new SimMessageClient(op.url, op.businessID, op.store)
  simMessageClient.connect(op.callback, op.errCallBack)
  return simMessageClient
}
let currentBaseUrl = global.currentBaseUrl
let requestUrls = {
  getTreeDataUrl: currentBaseUrl + '/recordLabelClass/getRecordLabelClassTree.do',
  getTreeType: currentBaseUrl + '/recordSort/trees',
  getTreeListBySortID: currentBaseUrl + '/recordSort/trees',
  deleteTree: currentBaseUrl + '/recordSort/trees',
  deleteClassify: currentBaseUrl + '/recordSort/sorts/',
  addTree: currentBaseUrl + '/recordSort/trees',
  getRadioBySortID: currentBaseUrl + '/recordSort/',
  getAllRecordLabel: currentBaseUrl + '/recordLabel/all',
  getExistTopic: currentBaseUrl + '/ivsClusterRule/getExistTopic', // 分类名称下拉list
}
const deleteEmptyChildren = function deleteEmptyChildren(treeArr) {
  if (!treeArr) {
    return
  }
  treeArr.forEach((item) => {
    if (item.children && item.children instanceof Array && item.children.length > 0) {
      deleteEmptyChildren(item.children)
    } else {
      delete item.children
    }
  })
}
export default {
  components: {
    nAudioList,
    vTraining,
    vAddEditTreeModal,
    vEditTreeName,
    vAddTree,
  },
  data() {
    return {
      draggable: true,
      biaoqianList: [],
      addTreeShow: false,
      editTreeNameShow: false,
      delay: 500,
      editTreeData: {},
      addEditTreeModalShow: false,
      typeSortID: '',
      typeName: '',
      addEditTreeName: '',
      algorithmTypeT: false,
      isdot: false,
      parentSortName: '',
      parentSortID: '',
      algorithmType: false,
      isAlgorithm: false,
      copyTreeModalShow: false,
      algorDisabled: true,
      isShowCopy: 0,
      treeType: 'gjc',
      treeButton: 'gjc',
      visible3: false,
      clearable: false,
      value4: [],
      hotWordSizeNew: 0,
      clearShow: true,
      taskBeginTime: '',
      taskEndTime: '',
      pageNumber: 1,
      pageSize: 10,
      isOther: 0,
      isOtherAlgo: 0,
      acount: 0,
      loading: false,
      treeBoxTitle: '新建分类',
      existTopicData: [],
      existTopicDataMap: {},
      dropYes: false,
      nextHot: false, // 控制子组件相关热词数据
      counts: '',
      data: [],
      labelId: '',
      selectedOptions3: [],
      tData: [],
      tDataAddOtherChild: [],
      aloneData: '', // 拖拽分类树临时数据存放
      topicID: '',
      clickTreeName: '',
      topicCount: 0,
      resultLabelId: '', // 传到聚类结果的id
      isDot: false,
      activeName: '',
      firstName: '',
      tName: '',
      existProps: {
        value: 'topicName',
        label: 'topicName',
      },
      selectDefaultProps: {
        value: 'labelId',
        label: 'labelName',
      },
      defaultProps: {
        children: 'children',
        label: 'sortName',
      },
      defaultPropsTwo: {
        children: 'children',
        label: 'sortName',
      },
      currentPage4: 4,
      sortIDPID: '',
      deleteSoretid: '', // 这是单独删除id
      algSortIDPID: '',
      sortID: '',
      treelistId: '',
      currentTree: {},
      dIndex: 0,
      labelIds: [],
      sortLabel: '',
      eidtTreeData: [],
      hideEdit: true,
      addDide: true,
      dropSuccess: false,
      number: 1,
      switchShow: false,
      treeList: [],
      showCopyTree: true,
      startNode: {},
      endNode: {},
      treeTimer: null,
      trainingTimer: null,
      formParams: {},
      copyTreeButtonDisabled: false,
    }
  },
  watch: {
    visible3(visible) {
      // 显示日期选择浮层时，隐藏tooltip
      if (visible) {
        const tooltip = this.$refs.$dateTooltip
        if (tooltip) {
          tooltip.hide()
        }
      }
    },
  },
  destroyed: function() {
    console.log('销毁')
    localStorage.removeItem('backHomeData')
  },
  mounted() {
    let that = this
    let themeData = JSON.parse(localStorage.getItem('backHomeData')) // 这里的数据判断为了在聚类页面点击返回的时候保留树的状态，如果存在数据那么展现之前树的状态，反之展示第一个树的数据
    console.log(themeData)
    if (themeData === null || themeData === Object || themeData === {}) {
      console.log('themeData')
      this.getAWeekTime()
    } else {
      that.value4 = [themeData.startTime, themeData.endTime]
      that.taskBeginTime = themeData.startTime
      that.taskEndTime = themeData.endTime
    }
    this.getTreeType()
    this.getExistTopic()
    this.getAllRecordLabel()
    this.messageClient = createMessageClient({
      businessID: 'sortTreeTrain',
      url: global.hrmApi,
      store: store,
      callback: (msg) => {
        console.log('开始++++++++++++++++')
        console.log(JSON.parse(msg.body))
        console.log('结束++++++++++++++++')
        let msgBack = JSON.parse(msg.body)
        this.showCopyTree = true
        if (this.algorithmTypeT == true && this.sortIDPID == msgBack.content) {
          this.$message({
            type: 'success',
            message: '算法树有更新，请刷新页面！',
          })
        }
        if (
          this.sortIDPID == msgBack.content &&
          msgBack.remark == null &&
          this.algorithmTypeT == false
        ) {
          this.algorithmType = true // 切换到算法树模式显示
          this.redPointShow()
        }
        if (msgBack.remark != null) {
          this.isdot = false
          this.$message.error('算法树训练失败，请重新训练~')
        }
      },
      errCallback: (error) => {
        console.error(error)
      },
    })
  },
  methods: {
    addTreeReturn(refresh) {
      this.addTreeShow = false
      if (refresh) {
        this.getTreeType()
      }
    },
    // 编辑树名称返回
    editTreeNameReturn(object) {
      this.editTreeNameShow = false
      if (object) {
        if (object.name == '1') {
          this.getTreeType()
        } else {
          const { name, id } = object
          const trees = this.treeList || []
          this.tName = name
          for (const tree of trees) {
            if (tree.sortID === id) {
              tree.sortName = name
              break
            }
          }
        }
      }
    },
    // 关键词模式点击编辑树的名称
    editTreeName() {
      let that = this
      this.$nextTick(() => {
        this.editTreeNameShow = true
        setTimeout(() => {
          that.$refs.editTreeNameComponent.dialogVisible = true
        }, 30)
      })
    },
    addEditFormData() {
      let that = this
      that.typeSortID = ''
      that.$refs.addEditTreeModalComponent.dialogVisible = false
      that.getTreeListBySortID(this.sortIDPID)
    },
    treeModalClose() {
      let that = this
      that.typeSortID = ''
      that.$refs.addEditTreeModalComponent.dialogVisible = false
    },
    deleteTreeType() {
      let that = this
      if (this.clickTreeName == '其他') {
        return
      }
      if (this.typeSortID == '') {
        this.$message.warning('请选择一个分类！')
      } else {
        this.$confirm('确认要删除' + this.clickTreeName + '么?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
          .then(() => {
            for (let i = 0; i < that.tData.length; i++) {
              if (that.tData[i].sortID === this.typeSortID) {
                that.tData[i].labels = []
                that.tData.splice(i, 1)
              } else {
                if (that.tData[i].children.length > 0) {
                  this.getChildRemove(that.tData[i].children, this.editTreeData)
                }
              }
            }
            this.$forceUpdate()
            this.axios
              .delete(requestUrls['deleteClassify'] + this.deleteSoretid, {
                headers: {
                  'Content-Type': 'application/json',
                  accessToken: this.$store.state.token,
                },
              })
              .then((response) => {
                if (response.data.code == 0) {
                  this.$message({
                    type: 'success',
                    message: '删除成功!',
                  })
                  this.getTreeListBySortID(this.sortIDPID)
                } else {
                  var message = response.data.message + ''
                  if (message.indexOf('未能查到id') >= 0) {
                    this.$message.error('此分类节点已删除!')
                    this.addEditFormData()
                  } else {
                    this.$message.error('删除子类分类失败！')
                  }
                }
              })
            this.typeSortID = ''
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除',
            })
          })
      }
    },
    // 添加分类
    addTreeType(type) {
      let that = this
      if (this.clickTreeName === '其他') {
        return
      }
      this.$nextTick(() => {
        this.addEditTreeModalShow = true
        setTimeout(() => {
          if (type == 'add') {
            that.addEditTreeName = '添加分类'
            that.$refs.addEditTreeModalComponent.dialogVisible = true // hack写法，强制清除数据
          } else {
            if (that.typeSortID !== '') {
              that.addEditTreeName = '修改分类'
              that.$refs.addEditTreeModalComponent.dialogVisible = true // hack写法，强制清除数据
            } else {
              this.$message.warning('请选择一个分类！')
            }
          }
        }, 30)
      })
    },
    getTreeChildsByCheck() {
      this.axios
        .get(currentBaseUrl + '/recordSortAlg/trees/' + this.sortIDPID + '/treeID/exist')
        .then((response) => {
          if (response.data.data == true) {
            this.algorithmType = true
            this.redPointShow() // 判断是否显示小红点
          } else {
            this.algorithmType = false
            this.algorithmTypeT = false
          }
        })
    },
    getTreeChildsBySortId() {
      let that = this
      let params = {}
      if (this.taskBeginTime) {
        params.callSTimeMin = new Date(
          this.taskBeginTime.replace(new RegExp('-', 'gm'), '/')
        ).getTime()
      }
      if (this.taskEndTime) {
        params.callSTimeMax = new Date(
          this.taskEndTime.replace(new RegExp('-', 'gm'), '/')
        ).getTime()
      }
      this.axios
        .get(currentBaseUrl + '/recordSortAlg/trees/' + this.sortIDPID + '/treeID', {
          params,
        })
        .then((response) => {
          if (response.data.data !== null) {
            that.counts = response.data.data.count
            that.sortID = response.data.data.id
            that.algSortIDPID = response.data.data.id
            let childs = response.data.data.children
            let shuzuList = []
            if (childs.length > 0) {
              for (let i = 0; i < childs.length; i++) {
                shuzuList[i] = {
                  sortName: childs[i].name,
                  sortID: childs[i].id,
                  calculating: childs[i].calculating,
                  count: childs[i].count,
                  labels: childs[i].labels,
                  otherCount: childs[i].otherCount,
                  parentSortID: childs[i].parentSortID,
                  children: this.getChildCopyTree(childs[i].children, [], childs[i]),
                }
              }
              if (response.data.data.otherCount > 0) {
                shuzuList[childs.length] = {
                  sortName: '其他',
                  sortID: response.data.data.id + '_other',
                  calculating: response.data.data.calculating,
                  count: response.data.data.otherCount,
                  labels: null,
                  otherCount: 0,
                  parentSortID: response.data.data.id,
                  children: [],
                }
              }
            }
            this.tDataAddOtherChild = Object.assign(shuzuList)
          } else {
            this.tDataAddOtherChild = []
            that.clearShow = true
            that.counts = 0
            that.sortID = ''
          }
        })
    },
    switchTree(type) {
      let that = this
      if (type === 'gjc') {
        this.addDide = true
        this.algorithmType = true
        this.hideEdit = true
        that.isShowCopy = 0
        this.treeType = 'gjc'
        this.treeButton = 'gjc'
        this.algorithmTypeT = false
        this.draggable = true
        that.isAlgorithm = false
        that.sortID = that.sortIDPID
        that.topicID = that.sortIDPID
        that.clearShow = true
        that.getTreeListBySortID(this.sortIDPID)
        this.getTreeChildsByCheck() // 检查是否显示切换到算法树模式
      } else {
        this.addDide = false
        this.treeType = 'sfs'
        this.treeButton = 'sfs'
        this.draggable = false
        this.hideEdit = false
        this.algorithmTypeT = true
        this.algorithmType = false
        that.isAlgorithm = true
        that.isShowCopy = 2
        if (this.isdot === true) {
          this.isdot = false
          this.deleteRedPoint() // 删除小红点
        }
        // 获得算法树模式的左侧tree
        this.getTreeChildsBySortId()
      }
      // 清除子组件的筛选条件
      this.$refs.nAudioList.closeModal()
      this.$refs.nAudioList.clear()
    },
    deleteRedPoint() {
      let params = {
        flag: 0,
        sortId: this.sortIDPID,
      }
      this.axios
        .get(currentBaseUrl + '/sortTreeAlgorithm/redPointShow', { params })
        .then((res) => {})
        .catch(() => {})
    },
    getKeywordLabel(word) {
      const { keywordContext, fullScriptRole } = word
      const map = {
        '0': '全部',
        '1': '客户',
        '2': '客服',
      }
      const role = map[fullScriptRole] || ''
      return `${role ? `${role}：` : ''}${(keywordContext || '').trim()}`
    },

    getLabelName(item) {
      return item.executeState == '1' ? item.labelName : item.labelName + '（停用中）'
    },

    bindCategoryFilter(visible) {
      this.categoryFilterAllowed = !!visible
    },

    // 分类搜索中
    onCategoryFilter(value) {
      if (this.categoryFilterAllowed) {
        const form = this.treeForm
        const prevValue = form.typename
        const currValue = (value || '').trim()
        if (currValue !== prevValue) {
          form.typename = currValue
        }
      }
    },
    // 检查当前编辑树节点的选中状态
    checkEditTreeSelectStatus(value) {
      if (value === '无') {
        // 清空树节点选取
        this.childrenName = []
        const tree = this.$refs.ttData
        if (tree) {
          tree.setCurrentKey(null)
        }
      }
    },
    // 清空新建节点的临时属性（ID）
    // 不清楚前端添加的ID是否会对服务的接口造成影响，故清除该ID值
    clearNodeProperty(tree) {
      if (Array.isArray(tree)) {
        for (let i = 0; i < tree.length; i++) {
          this.clearNodeProperty(tree[i])
        }
      } else if (tree) {
        const children = tree.children
        if (tree.__sortID === tree.sortID) {
          const id = tree.sortID
          // 新增的节点
          delete tree.sortID
          delete tree.__sortID
          if (Array.isArray(children)) {
            children.forEach((child) => {
              if (child.parentSortID === id) {
                delete child.parentSortID
              }
            })
          }
        }
        this.clearNodeProperty(children)
      }
    },
    // 默认一个月时间
    getAWeekTime() {
      let that = this
      let fromTime = ''
      let toTime = ''
      this.value4 = []
      if (this.value4.length == 0) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        if (this.value4[0] != undefined && this.value4[0] != '') {
          fromTime = formatdate.formatDate(this.value4[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (this.value4[1] != undefined && this.value4[1] != '') {
          toTime = formatdate.formatDate(this.value4[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      that.value4 = [fromTime, toTime]
      that.taskBeginTime = fromTime
      that.taskEndTime = toTime
    },
    diaoselectChange() {
      console.info(this.treeForm.domains)
    },
    /*
     * 录音时间筛选录音列表
     * 时间选择后列表及时更新
     * 更新后隐藏时间选择器
     * */
    dateChange(item) {
      if (item !== null) {
        let times1 = formatdate.formatDate(item[0])
        let times2 = formatdate.formatDate(item[1])
        this.taskBeginTime = times1
        this.taskEndTime = times2
      } else {
        // 当点击清空按钮的时候默认回填当月的数据
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        this.taskBeginTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        this.taskEndTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        this.value4 = [this.taskBeginTime, this.taskEndTime]
      }
      this.visible3 = false
      this.clearShow = true
      if (this.treeType === 'sfs') {
        this.getTreeChildsBySortId()
      } else {
        this.getTreeListBySortID(this.sortIDPID)
      }
      // this.getTreeListBySortID(this.sortID)
    },
    // 鼠标放到录音内容上时展示播放按钮
    showPlay() {
      event.target.querySelector('.play').style.display = 'block'
    },
    // 鼠标移出录音内容上时展示播放按钮
    hidePlay() {
      event.target.querySelector('.play').style.display = 'none'
    },
    getShowCopyTree() {
      let params = {
        treeId: this.sortIDPID,
      }
      this.axios
        .get(currentBaseUrl + '/sortTreeAlgorithm/checkTrain/', { params })
        .then((res) => {
          if (res.data === false) {
            this.showCopyTree = true
          } else {
            this.showCopyTree = false
          }
        })
        .catch(() => {})
    },
    // 检查末级节点数量是否大于5000通
    checkTreeNum() {
      let that = this
      let params = {
        // callId: this.formParams.callId,
        callSTimeMin: this.formParams.callSTimeMin,
        callSTimeMax: this.formParams.callSTimeMax,
        labelIDs: this.formParams.labelIDs,
        pageNumber: this.formParams.pageNumber,
        pageSize: this.formParams.pageSize,
        sentimentLabel: this.formParams.sentimentLabel,
        sentimentRole: this.formParams.sentimentRole,
      }
      this.axios
        .get(
          currentBaseUrl + '/sortTreeAlgorithm/checkCount/' + this.sortID,
          Qs.stringify(params)
        )
        .then((res) => {
          if (res.data == true) {
            this.$nextTick(function() {
              that.copyTreeModalShow = true
              setTimeout(() => {
                that.$refs.copyTreeModalContent.copyTreeModal = true
              }, 30)
            })
          } else {
            this.$message({
              type: 'info',
              message: '录音数量要大于5000通！',
            })
          }
        })
        .catch(() => {})
    },
    searchData(params) {
      this.formParams = params
    },
    /*
     * 复制分类树进行计算
     * */
    copyTree() {
      let that = this
      this.$nextTick(function() {
        that.copyTreeModalShow = true
        that.copyTreeButtonDisabled = true
        setTimeout(() => {
          that.$refs.copyTreeModalContent.copyTreeModal = true
        }, 30)
      })
      // this.checkTreeNum()
    },
    // 是否回显小红点
    redPointShow() {
      let params = {
        flag: 1,
        sortId: this.sortIDPID,
      }
      this.axios
        .get(currentBaseUrl + '/sortTreeAlgorithm/redPointShow', { params })
        .then((res) => {
          if (res.data === true) {
            this.isdot = true
          } else {
            this.isdot = false
          }
        })
        .catch(() => {})
    },
    getExistTopic() {
      this.axios
        .post(requestUrls['getExistTopic'])
        .then((res) => {
          if (res.data) {
            // this.existTopicData = res.data
            let existTopicDataMap = {}
            if (res.data != null && res.data.length > 0) {
              for (let i = 0; i < res.data.length; i++) {
                let topicName = res.data[i].topicName
                if (topicName != null && topicName != '') {
                  existTopicDataMap[topicName] = res.data[i].topicClusterId
                }
              }
            }
            let newArr = []
            for (let i = 0; i < res.data.length; i++) {
              if (newArr.indexOf(res.data[i].topicName) == -1) {
                newArr.push(res.data[i].topicName)
              }
              this.existTopicData = newArr
            }
            this.existTopicDataMap = existTopicDataMap
          }
        })
        .catch(() => {})
    },
    selectChange() {},
    // 获取所有录音标签
    getAllRecordLabel() {
      this.axios
        .get(requestUrls['getAllRecordLabel'])
        .then((res) => {
          if (res.data.data.length > 0) {
            this.biaoqianList = res.data.data
          }
        })
        .catch(() => {})
    },
    closeModal() {
      this.$refs.copyTreeModal.copyTreeModalContent = false
      // this.getTreeListBySortID()
    },
    // 关闭标签弹框
    close() {
      let that = this
      that.$refs.addRecordLabelComponent.showDialog = false
    },
    returnData(item) {
      this.clearShow = item
    },
    trainingClose() {
      this.$nextTick(() => {
        this.copyTreeModalShow = false
        this.copyTreeButtonDisabled = false
      })
    },
    trainingData(data) {
      let that = this
      that.isShowCopy = 1
      that.showCopyTree = false
      //this.getShowCopyTree() // 是否显示可以算法训练
      this.getTreeChildsByCheck() // 是否显示切换到算法树模式
    },
    submitted(data) {
      let that = this
      that.$refs.addRecordLabelComponent.showDialog = false
    },
    getParentId(childrenData) {
      let that = this
      for (let i = 0; i < childrenData.length; i++) {
        if (childrenData[i].children === undefined || childrenData[i].children === null) {
          let jj = []
          jj[0] = childrenData[i].id
          that.selectedOptions3.concat(jj)
        } else {
          that.selectedOptions3.push(childrenData[i].id)
          that.getParentId(childrenData[i].children)
        }
      }
    },
    // 获得随机id
    getID(length) {
      return Number(
        Math.random()
          .toString()
          .substr(3, length) + Date.now()
      ).toString(36)
    },
    getChildRemove(children, data) {
      let that = this
      for (let i = 0; i < children.length; i++) {
        if (children[i].sortID === data.sortID) {
          children[i].labels = []
          children.splice(i, 1)
        } else {
          if (children[i].children.length > 0) {
            that.getChildRemove(children[i].children, data)
          }
        }
      }
    },
    getChild(children, object) {
      for (let i = 0; i < children.length; i++) {
        if (children[i].sortID === this.treeDataEdit.sortID) {
          children[i].children.push(object)
        } else {
          if (children[i].children.length > 0) {
            this.getChild(children[i].children)
          }
        }
      }
    },
    removeByValue(arr, val) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].id === val) {
          arr.splice(i, 1)
          break
        }
      }
    },
    getUUID() {
      return Number(
        Math.random()
          .toString()
          .substr(3, length) + Date.now()
      ).toString(36)
    },
    // 删除树
    deleteTree() {
      if (this.treeList <= 0) {
        return
      }
      this.$confirm(
        '确认要删除 ' + this.tName + ' 树结构么？之前建立的所有分类规则将被移除！',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      ).then(() => {
        let that = this
        that
          .axios({
            method: 'DELETE',
            url: requestUrls['deleteTree'] + '/' + that.sortIDPID,
          })
          .then((response) => {
            that.childrenName = []
            that.treeSelectOptions.splice(parseInt(this.dIndex), 1)
            that.$message({
              type: 'success',
              message: '删除成功!',
            })
            that.getTreeType()
          })
      })
    },
    // 保存拖拽之后的数据
    saveDrop() {
      let that = this
      console.log(that.tDataAddOtherChild)
      let treeAfterDrop = JSON.parse(JSON.stringify(that.tDataAddOtherChild))
      console.log(treeAfterDrop)
      let treeAfterDropWithoutOther = that.excludeOtherChild(treeAfterDrop)
      console.log(treeAfterDropWithoutOther)
      let paramsList = {
        sortName: that.tName,
        parentSortID: '0',
        children: treeAfterDropWithoutOther,
        sortID: that.treelistId,
      }
      that.axios
        .put(requestUrls['getTreeType'], paramsList, {
          headers: {
            'Content-Type': 'application/json',
            accessToken: this.$store.state.token,
          },
        })
        .then((response) => {
          if (response.data.code === 0) {
            that.$message.success('分类树编辑成功')
          } else {
            that.$message.error(response.data.message)
          }
          this.getTreeListBySortID(this.sortIDPID)
          this.dropSuccess = false
        })
    },
    excludeOtherChild: function(children) {
      let childrenWithoutOther = []
      for (let i = 0; i < children.length; i++) {
        if (!children[i].sortID.endsWith('_other')) {
          if (children[i].children != null && children[i].children.length > 0) {
            children[i].children = this.excludeOtherChild(children[i].children)
          }
          childrenWithoutOther.push(children[i])
        }
      }
      return childrenWithoutOther
    },
    nodeDragEnd(before, after, inner) {
      this.endNode = after
      if (before.data.sortName === '其他') {
        this.$message.error('其他 分类不可拖拽！')
        this.getTreeListBySortID(this.sortIDPID)
        // this.getTreeType()
      } else {
        let sname = this.startNode.data.sortName
        // console.log(this.startNode)
        // console.log(before)
        // console.log(after)
        // console.log(inner)
        // console.log(after.parent.childNodes)
        let nums = 0
        for (let i = 0; i < after.parent.childNodes.length; i++) {
          if (after.parent.childNodes[i].data.sortName === sname) {
            nums = nums + 1
            if (nums > 1) {
              this.$message.error('同级之间不能存在相同节点名称!')
              this.dropSuccess = false
              this.getTreeListBySortID(this.sortIDPID)
              return
            } else {
              this.dropSuccess = true
            }
          } else {
            this.dropSuccess = true
          }
        }
        if (inner == inner) {
          let numt = 0
          for (let y = 0; y < after.childNodes.length; y++) {
            if (after.childNodes[y].parent.data.sortName === '其他') {
              this.$message.error('其他 分类不可拖拽！')
              this.getTreeListBySortID(this.sortIDPID)
              return
            }
            if (after.childNodes[y].data.sortName === sname) {
              numt = numt + 1
              if (numt > 1) {
                this.$message.error('同级之间不能存在相同节点名称!')
                this.dropSuccess = false
                this.getTreeListBySortID(this.sortIDPID)
                return
              } else {
                this.dropSuccess = true
              }
            } else {
              this.dropSuccess = true
            }
          }
        } /* else {
          let aloneAray
          aloneAray = JSON.parse(this.aloneData)
          for (let n = 0; n < aloneAray.length; n++) {
            if (aloneAray[n].sortName === before.data.sortName && before.level != after.level) {
              this.$message.error('同级之间不能存在相同节点名称!')
              this.dropSuccess = false
              this.getTreeListBySortID(this.sortIDPID)
            } else {
              this.dropSuccess = true
            }
          }
          console.log('拖拽到一级节点了')
        } */
        /* if (after.data.children.length > 0) {
          let nums = 0
          for (let i = 0; i < after.data.children.length; i++) {
            if (after.data.children[i].sortName === sname) {
              nums = nums + 1
              if (nums > 1) {
                this.$message.error('同级之间不能存在相同节点名称!')
                this.dropSuccess = false
                this.getTreeListBySortID(this.sortIDPID)
              } else {
                this.dropSuccess = true */
        /* if (before.level != 1) {
                  after.data.children.forEach((item) => {
                    if (item.sortName === sname) {
                      this.$message.error('同级33之间不能存在相同节点名称!')
                      this.dropSuccess = false
                      this.getTreeListBySortID(this.sortIDPID)
                    }
                  })
                } else {
                  before.data.children.forEach((item) => {
                    if (item.sortName === sname) {
                      this.$message.error('同级44之间不能存在相同节点名称!')
                      this.dropSuccess = false
                      this.getTreeListBySortID(this.sortIDPID)
                    }
                  })
                } */

        /* let aloneAray1
                aloneAray1 = JSON.parse(this.aloneData)
                console.log(aloneAray1)
                for (let n = 0; n < aloneAray1.length; n++) {
                  if (aloneAray1[n].sortName === sname) {
                    this.$message.error('同级33之间不能存在相同节点名称!')
                    this.dropSuccess = false
                    this.getTreeListBySortID(this.sortIDPID)
                  } else {
                    this.dropSuccess = true
                  }
                } */
        /* }
            } else {
              this.dropSuccess = true
            }
          }
          nums++
        } */
      }
    },
    nodeDragStart(node) {
      console.info('开始拖拽')
      let _this = this
      _this.aloneData = JSON.stringify(_this.tDataAddOtherChild)
      _this.startNode = node
    },
    // 节点被点击
    nodeClick(data) {
      let that = this
      that.editTreeData = data
      that.deleteSoretid = data.sortID
      that.sortID = data.sortID // 添加 分类的时候 当前是 无 的时候 sortID会乱入
      that.labelIds = data.labels
      that.resultLabelId = data.sortID
      that.typeSortID = data.sortID
      that.parentSortID = data.parentSortID
      that.parentSortName = data.parentSortName
      that.topicID = data.sortID
      that.topicCount = data.count
      that.clickTreeName = data.sortName
      // 这个参数是控制子组件相关热词数据的
      that.nextHot = true
      if (data.labels == null) {
        that.labelIds = []
      } else {
        that.labelIds = data.labels
      }
      if (data.sortName === '其他') {
        that.isOther = 1
        that.isOtherAlgo = 1
      } else {
        that.isOther = 0
        that.isOtherAlgo = 0
      }
      this.queryAudioList(data.sortID)
    },
    queryAudioList: function(sortID) {
      this.topicID = sortID
      this.$refs['nAudioList'].sortID = sortID // 本父组件为什么会用子组件的sortID呢这句代码会导致vue提示警告报错
      this.$refs['nAudioList'].pageNumber = 1
      this.$refs['nAudioList'].getRecord()
      this.$nextTick(() => {
        this.$refs['nAudioList'].getCategoryWord()
      })
    },
    // 获取某个分类树下面的tree结构
    getTreeListBySortID(sortid) {
      // 清除定时
      if (this.treeTimer) {
        clearTimeout(this.treeTimer)
        this.treeTimer = null
      }

      let that = this
      this.loading = true
      let params = {}
      if (this.taskBeginTime) {
        params.callSTimeMin = new Date(
          this.taskBeginTime.replace(new RegExp('-', 'gm'), '/')
        ).getTime()
      }
      if (this.taskEndTime) {
        params.callSTimeMax = new Date(
          this.taskEndTime.replace(new RegExp('-', 'gm'), '/')
        ).getTime()
      }
      this.axios
        .get(requestUrls['getTreeListBySortID'] + '/' + sortid, { params })
        .then(function(res) {
          // 复制成功 给 显示tree节点
          that.sortLabel = res.data.data.sortName
          that.counts = res.data.data.count
          that.topicID = res.data.data.sortID
          that.childrenName = res.data.data.children
          that.childrenName.length > 0
            ? (that.treeType = 'gjc')
            : (that.treeType = 'dataZero')
          if (res.data.data.calculating) {
            that.treeTimer = setTimeout(() => {
              that.getTreeListBySortID(sortid)
            }, 10000)
          }
          // that.childrenNameOld = res.data.data.children
          let childs = res.data.data.children
          let shuzuList = []
          if (childs.length > 0) {
            for (let i = 0; i < childs.length; i++) {
              shuzuList[i] = {
                sortName: childs[i].sortName,
                sortID: childs[i].sortID,
                calculating: childs[i].calculating,
                count: childs[i].count,
                parentSortName: childs[i].parentSortName,
                labels: childs[i].labels,
                otherCount: childs[i].otherCount,
                parentSortID: childs[i].parentSortID,
                children: that.getChildS(childs[i].children, [], childs[i]),
              }
            }
            if (res.data.data.otherCount > 0) {
              shuzuList[childs.length] = {
                sortName: '其他',
                sortID: res.data.data.sortID + '_other',
                calculating: res.data.data.calculating,
                parentSortName: res.data.data.parentSortName,
                count: res.data.data.otherCount,
                labels: null,
                otherCount: 0,
                parentSortID: res.data.data.sortID,
                children: [],
              }
            }
            that.tDataAddOtherChild = Object.assign(shuzuList)
            that.tData = Object.assign(childs) // 获取下面的tree结构
            that.hideEdit = true
          } else {
            that.tDataAddOtherChild = []
            that.tData = []
            that.hideEdit = false
          }
          this.loading = false
        })
        .catch(() => {
          this.loading = false
        })
    },
    getChildCopyTree(value, treeList, parent) {
      for (let i = 0; i < value.length; i++) {
        treeList[i] = {
          sortName: value[i].name,
          sortID: value[i].id,
          count: value[i].count,
          labels: value[i].labels,
          calculating: value[i].calculating,
          otherCount: value[i].otherCount,
          parentSortName: value[i].parentSortName,
          parentSortID: value[i].parentSortID,
          children: this.getChildCopyTree(value[i].children, [], value[i]),
        }
      }
      if (parent.otherCount > 0) {
        treeList[value.length] = {
          sortName: '其他',
          sortID: parent.id + '_other',
          count: parent.otherCount,
          calculating: parent.calculating,
          labels: null,
          otherCount: 0,
          parentSortName: parent.parentSortName,
          parentSortID: parent.sortID,
          children: [],
        }
      }
      return treeList
    },
    getChildS(value, treeList, parent) {
      for (let i = 0; i < value.length; i++) {
        treeList[i] = {
          sortName: value[i].sortName,
          sortID: value[i].sortID,
          count: value[i].count,
          labels: value[i].labels,
          calculating: value[i].calculating,
          otherCount: value[i].otherCount,
          parentSortName: value[i].parentSortName,
          parentSortID: value[i].parentSortID,
          children: this.getChildS(value[i].children, [], value[i]),
        }
      }
      if (parent.otherCount > 0) {
        treeList[value.length] = {
          sortName: '其他',
          sortID: parent.sortID + '_other',
          count: parent.otherCount,
          calculating: parent.calculating,
          labels: null,
          otherCount: 0,
          parentSortName: parent.parentSortName,
          parentSortID: parent.sortID,
          children: [],
        }
      }
      return treeList
    },
    // 获取分类树
    getTreeType() {
      let that = this
      this.axios({
        method: 'get',
        url: requestUrls['getTreeType'],
        headers: { accessToken: this.$store.state.token },
      })
        .then((response) => {
          if (response.data.data.length > 0) {
            let themeData = JSON.parse(localStorage.getItem('backHomeData'))
            if (themeData === null || themeData === {} || themeData === Object) {
              that.sortIDPID = response.data.data[0].sortID
              that.sortID = response.data.data[0].sortID
              that.resultLabelId = response.data.data[0].sortID
              that.activeName = response.data.data[0].sortID
              that.treelistId = response.data.data[0].sortID // 拖拽所需id
              this.firstName = response.data.data[0].sortName
              that.tName = response.data.data[0].sortName
            } else {
              this.$nextTick(() => {
                that.sortIDPID = themeData.sortId
                that.sortID = themeData.sortId
                that.resultLabelId = themeData.sortId
                that.activeName = themeData.sortId
                that.firstName = themeData.tName
                that.tName = themeData.tName
                that.treelistId = themeData.sortId // 拖拽所需id
              })
            }
            let themeDatacell = JSON.parse(localStorage.getItem('backHomeData')) // 这里的数据判断为了在聚类页面点击返回的时候保留树的状态，如果存在数据那么展现之前树的状态，反之展示第一个树的数据
            if (
              themeDatacell === null ||
              themeDatacell === Object ||
              themeDatacell === {}
            ) {
              that.sortIDPID = response.data.data[0].sortID
            } else {
              that.sortIDPID = themeDatacell.sortId
            }
            that.sortID = response.data.data[0].sortID
            that.resultLabelId = response.data.data[0].sortID
            that.activeName = response.data.data[0].sortID
            this.firstName = response.data.data[0].sortName
            that.tName = response.data.data[0].sortName
            that.treeList = response.data.data
            that.currentTree = {
              index: '0',
              id: response.data.data[0].sortID,
              label: response.data.data[0].sortName,
            }
            let dataNew = that.treeList
            that.treeSelectOptions = []
            that.acount = response.data.count
            for (let i = 0; i < dataNew.length; i++) {
              let dataH = {}
              dataH.value = dataNew[i].sortID
              dataH.label = dataNew[i].sortName
              that.treeSelectOptions.push(dataH)
            }
            that.treeType = 'gjc'
            that.treeButton = 'gjc'
            that.getShowCopyTree() // 是否显示算法训练
            that.getTreeListBySortID(that.sortIDPID)
            that.getTreeChildsByCheck()
          } else {
            that.counts = 0
            that.tDataAddOtherChild = []
            that.treeList = []
            that.sortID = ''
            that.treeType = 'dataZero' // dataZero是没有树结构时按钮的显示状态
            that.treeButton = 'dataZero'
          }
        })
        .catch(() => {})
    },
    // 添加分类树
    addTree() {
      if (this.treeList.length >= 5) {
        return
      }
      let that = this
      this.$nextTick(() => {
        this.addTreeShow = true
        setTimeout(() => {
          that.$refs.addTreeConponent.showDialog = true // hack写法，强制清除数据
        }, 30)
      })
    },
    /*
     * 切换分类树tabs
     * */
    handleClick(tab) {
      console.log(tab)
      let that = this
      this.addDide = true
      this.hotWordSizeNew = 0
      that.typeSortID = ''
      this.algorithmTypeT = false
      this.algorithmType = true
      this.treelistId = tab.name
      this.firstName = tab.label
      this.treeType = 'gjc'
      this.treeButton = 'gjc'
      if (this.dropSuccess) {
        this.$confirm('有树未保存，需要保存吗?', '提示', {
          confirmButtonText: '保存',
          cancelButtonText: '放弃',
          type: 'warning',
        })
          .then(() => {
            this.saveDrop()
            this.treeListChange(tab)
          })
          .catch(() => {
            this.treeListChange(tab)
            this.dropSuccess = false
          })
      } else {
        // 设置录音时间默认当前月份
        this.getAWeekTime()
        // 相关热词重置
        this.$refs.nAudioList.checkboxGroup1 = []
        this.treeListChange(tab)
      }
      this.isOther = 0
      // 清除子组件的筛选条件
      this.$refs.nAudioList.closeModal()
      this.$refs.nAudioList.clear()
      this.endNode = {}
      this.startNode = {}
      this.clearShow = true
    },
    /*
     * 切换分类树
     * 重新给页面赋值
     * */
    treeListChange(tab) {
      let that = this
      that.dIndex = tab.index
      that.sortID = tab.name
      that.topicID = tab.name
      that.sortIDPID = tab.name
      that.resultLabelId = tab.name
      that.sortLabel = tab.label
      that.tName = tab.label
      that.treeData = []
      that.isAlgorithm = false
      this.getShowCopyTree() // 是否显示可以算法训练
      this.getTreeChildsByCheck() // 是否 显示切换到算法树模式
      that.currentTree = { index: tab.index, id: tab.name, label: tab.label }
      this.getTreeListBySortID(this.sortIDPID)
      //
    },
    /*
     * 点击 全部录音
     * */
    clickAllClass() {
      if (this.sortID === undefined || this.sortID === '' || this.sortID === null) {
        return
      } else {
        this.dIndex = this.currentTree.index
        if (this.isAlgorithm) {
          this.sortID = this.algSortIDPID
        } else {
          this.sortID = this.currentTree.id
        }
        this.sortIDPID = this.currentTree.id
        this.resultLabelId = this.currentTree.id
        this.sortLabel = this.currentTree.label
        this.tName = this.currentTree.label
        if (this.algorithmTypeT === true) {
          this.getTreeChildsBySortId()
        } else {
          this.getTreeListBySortID(this.sortIDPID)
        }
        this.queryAudioList(this.sortID)
      }
    },
  },
  beforeDestroy() {
    if (this.treeTimer) {
      clearTimeout(this.treeTimer)
    }
    if (this.trainingTimer) {
      clearTimeout(this.trainingTimer)
    }
    const socketClient = this.messageClient
    if (socketClient) {
      socketClient.disconnect()
    }
  },
}
</script>
<style lang="less" scoped>
.flex-box {
  display: flex;
  flex-flow: row wrap;
  width: 700px;
  .flex-box-list {
    width: 100%;
  }
}
.fn-bor-b-c {
  border-bottom: 1px solid #d1d9e2;
  padding-bottom: 10px;
}
.fn-bor-t-c {
  border-top: 1px solid #d1d9e2;
  padding-top: 10px;
}
.audioClassification {
  height: 100%;
  width: 100%;
  z-index: 0;
  box-sizing: border-box;
  overflow: hidden;
  .container {
    overflow: hidden;
    height: 100%;
    position: relative;
    .content {
      position: absolute;
      top: 61px;
      left: 0;
      bottom: 1px;
      width: 100%;
      .leftTree {
        float: left;
        display: flex;
        flex-direction: column;
        width: 260px;
        height: 100%;
        position: relative;
        border-right: 1px solid #e4e4e4;
        .itemBox {
          margin-top: 10px;
          position: relative;
          height: 140px;
          .treeName {
            font-size: 14px;
            padding: 6px 0px 6px 0px;
            cursor: pointer;
            overflow: hidden;
            p {
              padding-left: 10px;
              display: inline;
            }
            .moshi {
              padding-right: 10px;
              text-align: right;
              float: right;
            }
          }
        }
        .treeBox-scroll {
          width: 260px;
          height: 100%;
          overflow-x: scroll;
          // position: absolute;
          // top: 140px;
          // bottom: 0px;
          overflow-y: auto;
        }
        .treeBox {
          // position: absolute;

          // top: 0;
          // width: 100%;
          overflow-x: hidden;
          overflow-y: auto;
        }
        .saveBotton {
          padding-right: 10px;
          text-align: right;
          .rightTop {
            float: right;
          }
          .moshi {
            margin-bottom: 10px;
            width: 100%;
            float: left;
            text-align: right;
            cursor: pointer;
          }
          .toolTop {
            float: left;
            margin-left: 10px;
          }
          .toolTopRight {
            float: right;
          }
        }
      }
      .itemAll {
        margin: 10px;
        padding-left: 10px;
        background: #f2f2f2;
        height: 46px;
        line-height: 46px;
        font-size: 14px;
      }
    }
    .rightContent {
      margin-left: 260px;
      height: 100%;
      position: relative;
      .search {
        height: 50px;
        border-bottom: 1px solid #f4f4f4;
        padding: 10px 10px 0px 10px;
        a {
          color: #20a0ff;
          font-size: 14px;
          text-decoration: underline;
        }
        .import {
          float: right;
        }
      }
      .searchResult {
        position: absolute;
        top: 70px;
        left: 0;
        bottom: 0px;
        width: 100%;
        .searchResultBox {
          padding-left: 10px;
          font-size: 14px;
        }
        .table {
          position: absolute;
          top: 60px;
          bottom: 50px;
          width: 100%;
          overflow-y: auto;
        }
        .pages {
          text-align: right;
          right: 10px;
          border-top: none;
          position: absolute;
          bottom: 0px;
          width: 100%;
        }
      }
    }
    .top {
      border-bottom: 1px solid #e4e4e4;
      overflow: hidden;
      .rightButton {
        float: right;
        padding: 10px 10px 10px 0px;
      }
      .leftTreeBox {
        float: left;
        padding-left: 10px;
      }
    }
  }
}
</style>
<style>
#audioClassification #toolTop .iconfont {
  font-size: 14px;
}
#audioClassification .rightTop .iconfont {
  font-size: 14px;
}
#audioClassification .rightTop .el-button {
  padding: 10px !important;
}
#audioClassification #toolTop .el-button {
  padding: 10px !important;
}
#audioClassification .el-button--small,
.el-button--small.is-round {
  padding: 10px !important;
}
#audioClassification .custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
  flex-basis: auto;
}
#audioClassification .el-dropdown-box {
  margin: 10px 0 18px 0px;
}
#audioClassification .editIcon {
  float: right;
  margin-top: 7px;
  margin-right: 5px;
  font-size: 26px;
  cursor: pointer;
}
#audioClassification .editIcon.disabled {
  color: #e3e3e3;
}
#audioClassification .el-dialog-box-clor {
  background: #eff2f7;
  padding: 15px;
}
#audioClassification .add-type {
  margin: 18px 0 10px 10px;
  font-size: 14px;
  display: block;
  cursor: pointer;
}
#audioClassification .add-type.add-type-disabled {
  color: #eee;
}
#audioClassification #old .el-form-item__content {
  margin-left: 0px !important;
}
#audioClassification .el-tabs__nav {
  margin-left: 10px;
}
/* #audioClassification .el-tabs__item {
  height: 60px !important;
  line-height: 60px;
} */
#audioClassification .el-tabs__nav-wrap::after {
  background-color: #fff;
}
#audioClassification .rightContent .el-tabs__nav-wrap::after {
  background-color: #f4f4f4;
}
/*  #audioClassification .el-badge__content.is-fixed.is-dot{top:15px;}*/
#audioClassification .rightContent .tabsTop {
  height: 40px;
  line-height: 40px;
  overflow: hidden;
  border-bottom: 2px solid #f4f4f4;
}
#audioClassification .rightContent .tabsTop .item {
  font-size: 14px;
  margin-left: 10px;
  line-height: 50px;
  height: 58px;
  cursor: pointer;
}
#audioClassification .rightContent .tabsContent {
  position: absolute;
  top: 2px;
  left: 0;
  bottom: 1px;
  width: 100%;
}
#audioClassification .rightContent .active {
  color: #409eff;
  border-bottom: 2px solid #409eff;
}
#audioClassification .ml20 {
  margin-left: 20px !important;
}
#audioClassification .layout-box {
  overflow: hidden;
  height: 100%;
  position: relative;
}
#audioClassification .el-tabs__header {
  margin: 0px 0px 0px !important;
}
#audioClassification .rightContent .el-tabs--top {
  height: 100% !important;
}
#audioClassification .rightContent .el-tabs__content {
  height: calc(100% - 60px);
}
#audioClassification .rightContent .el-tab-pane {
  height: 100%;
}
#audioClassification .el-col-8 {
  width: 30% !important;
}
#audioClassification #keywordZuhe {
  width: 100%;
  height: 100px;
  border: 1px solid #ddd;
  border-radius: 4px;
  padding-left: 10px;
  padding-top: 10px;
  box-sizing: border-box;
  padding-bottom: 50px;
}
#audioClassification .keywords {
  padding-top: 3px;
  background: #fff;
  border-radio: 3px;
}
#audioClassification .footer {
  text-align: right;
}
#audioClassification .labelform {
  height: 360px;
  overflow-y: auto;
}
#audioClassification .newBiaoQian {
  width: 100%;
  float: left;
}
#audioClassification .newBiaoQian .lists {
  margin: 10px;
}
#audioClassification .newBiaoQian span {
  float: right;
  display: inline;
  padding-right: 10px;
  color: #20a0ff;
  cursor: pointer;
}
#audioClassification .newBiaoQian p {
  display: inline;
  float: left;
  font-size: 14px;
  color: #222;
}
#audioClassification .spanStyle {
  display: inline-block;
  border: 1px solid #ddd;
  text-align: center !important;
  width: 55px !important;
  margin-left: 3px;
  border-radius: 4px;
  cursor: pointer;
}
.button-margin {
  margin-right: 4px;
}
</style>
