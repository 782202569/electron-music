<template>
  <div class="audioList" id="audioList">
    <div class="container">
      <div class="layout-box">
        <div class="audioTop">
          <div class="audioLeft">
            <div style="float: left" @click="addSearch">
              <span style="float: left">{{ sxTitle }}</span>
              <div class="content-trigon-zhijiao" style="float: left">
                <span><i></i></span>
              </div>
            </div>
          </div>
          <div class="audioRight">
            <div class="mr10">
              <el-button
                @click="clickTopicClustering"
                size="mini"
                :disabled="haveSortID"
                :loading="checking"
                >聚类</el-button
              >
              <export-file
                v-if="this.isAlgorithm === false"
                style="margin-left: 4px"
                :disabled="!sortID"
                :action="showIsOther ? exportUrlT : exportUrl"
                :params="exportFileParams"
                >导出</export-file
              >
              <export-file
                v-else=""
                style="margin-left: 4px"
                :disabled="!sortID"
                :action="showOtherAlgo ? algortihmExportUrlOther : algortihmExportUrl"
                :params="exportFileParams"
                >导出</export-file
              >
            </div>
          </div>
        </div>
        <div class="audioContent">
          <div class="rightAudio">
            <div class="layout-box">
              <div v-show="this.count" class="rightTop">
                <div class="termsMain">
                  <div class="hotterms">
                    <el-checkbox-group
                      class="hot-words"
                      v-model="checkboxGroup1"
                      @change="checkboxChange"
                    >
                      <span class="hots">相关热词：</span>
                      <span v-for="city in cities">
                        <el-checkbox-button :label="city.keyword" :key="city.keyword">
                          {{ `${city.keyword}(${city.times})` }}
                        </el-checkbox-button>
                      </span>
                      <div class="hotTotal">
                        <el-dropdown
                          trigger="click"
                          style="cursor: pointer;"
                          v-if="cities.length > 0"
                        >
                          <span class="el-dropdown-link">
                            <i class="iconfont icon-sangecaozuo"></i>
                            <span class="el-dropdown-span" v-if="this.hotCardNum > 0">{{
                              hotCardNum
                            }}</span>
                          </span>
                          <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item
                              ><p @click="lookWord">查看词相关</p></el-dropdown-item
                            >
                            <el-dropdown-item
                              ><p @click="saveKeyWord(1)">存为关键词</p></el-dropdown-item
                            >
                            <el-dropdown-item
                              ><p @click="saveKeyWord(2)">存为水词</p></el-dropdown-item
                            >
                          </el-dropdown-menu>
                        </el-dropdown>
                      </div>
                    </el-checkbox-group>
                  </div>
                  <div class="totalRadio">共{{ this.count }}通录音</div>
                </div>
              </div>
              <div class="searchModal" id="modal" style="display: none">
                <div class="searchContent">
                  <div class="hotterms">
                    <el-checkbox-group
                      class="hot-words"
                      v-model="checkboxGroup2"
                      @change="checkboxChangeTwo"
                    >
                      <span class="hots">相关热词：</span>
                      <div style="margin-left: 90px;">
                        <span v-for="city in cities">
                          <el-checkbox-button :label="city.keyword" :key="city.keyword">
                            {{ `${city.keyword}(${city.times})` }}
                          </el-checkbox-button>
                        </span>
                      </div>
                    </el-checkbox-group>
                  </div>
                  <div
                    style="width: 100%; overflow: hidden; margin-top: 20px;float: left;"
                  >
                    <el-form
                      id="ruleForm"
                      :model="ruleForm"
                      ref="ruleForm"
                      style="margin-top: 10px;"
                      label-width="100px"
                    >
                      <el-form-item label="编号" style="margin-left: -50px;">
                        <el-input
                          v-model="ruleForm.code"
                          style="width: 400px; margin-left: 50px"
                        ></el-input>
                      </el-form-item>
                      <el-form-item label="录音时长" style="margin-left: -23px;">
                        <el-input
                          v-model="ruleForm.time"
                          style="width:200px; margin-left: 23px; margin-right: 10px;"
                          placeholder="请输入数字"
                        ></el-input
                        ><i>秒以上</i>
                      </el-form-item>
                      <el-form-item label="关键词标签" style="margin-left: -9px;">
                        <el-col class="line" :span="20">
                          <div v-if="this.showTwo === true">
                            <el-select
                              v-model="gjcIds"
                              ref="gjcIds"
                              style="width: 400px; margin-left: 9px"
                              placeholder="请选择"
                              multiple
                              @change="guanjianciChange"
                            >
                              <el-option
                                v-for="(one, index) in guanjianciIds"
                                :key="index"
                                :label="getLabelName(one)"
                                :value="one.labelId"
                              >
                              </el-option>
                            </el-select>
                          </div>
                        </el-col>
                      </el-form-item>
                      <el-form-item label="情绪标签" style="margin-left: -23px;">
                        <el-col class="line" :span="5" style="margin-left: 23px;">
                          <el-select v-model="ruleForm.qxList" value-key="0">
                            <el-option label="全部" value="全部"></el-option>
                            <el-option label="客户" value="客户"></el-option>
                            <el-option label="坐席" value="坐席"></el-option>
                          </el-select>
                        </el-col>
                        <el-col class="line" :span="1">&nbsp;</el-col>
                        <el-col class="line" :span="10" style="margin-left: 1px;">
                          <el-select v-model="ruleForm.sentimentLabel" value-key="0">
                            <el-option label="积极" value="积极"></el-option>
                            <el-option label="正常" value="正常"></el-option>
                            <el-option label="消极" value="消极"></el-option>
                          </el-select>
                        </el-col>
                      </el-form-item>
                    </el-form>
                    <div class="clearInfo" @click="clear">
                      <el-button :disabled="haveSortID" size="small">清空</el-button>
                    </div>
                    <div slot="footer" class="dialog-footer">
                      <el-button @click="closeModal" size="small">关 闭</el-button>
                      <el-button
                        type="primary"
                        @click="searchAudioList"
                        size="small"
                        :disabled="haveSortID"
                        >查 询</el-button
                      >
                    </div>
                  </div>
                </div>
              </div>
              <div class="rightTable">
                <div style="height: 100%; overflow: hidden;" v-if="tableData5.length > 0">
                  <el-collapse
                    v-model="activeNames"
                    style="height: 100%; overflow: auto;"
                  >
                    <div
                      v-for="(item, index) in tableData5"
                      :key="index"
                      style="margin: 15px 20px 20px 20px;border: 1px solid #E0E6ED;font-size: 14px;border-radius: 5px;background: #9ED9F3;"
                    >
                      <el-collapse-item>
                        <template slot="title">
                          <div
                            class="nextDiv"
                            style="padding: 0px 20px;background: #E0E6ED;"
                            @click="tabClick(index, $event)"
                          >
                            <span>编号:</span
                            ><span
                              style="color: #20A0FF;"
                              @click="showDetail(item.callID, item.recordFileURL)"
                              >&nbsp;{{ item.callID }}</span
                            >
                            <!-- <span style="margin-left: 25px;">坐席姓名:</span><span>&nbsp;{{item.seatName}}</span>
                            <span style="margin-left: 25px;">录音时长:</span><span>&nbsp;{{commonUtil(item.callTime)}}</span> -->
                            <span style="float: right;color: #20A0FF;cursor: pointer;">{{
                              item.expand ? '收起详情' : '展开详情'
                            }}</span>
                            <span
                              style="font-size: 14px;float: right;color: #20A0FF;margin-right: 5px;"
                              :class="[
                                item.expand
                                  ? 'iconfont icon-zhanshixiangqing secondBox'
                                  : 'iconfont icon-zhanshixiangqing startBox',
                              ]"
                            ></span>
                          </div>
                          <div
                            class="parentDic"
                            style="padding: 0px 10px 0px 0px;background: #E0E6ED;"
                            @click="tabClick(index, $event)"
                          >
                            <div style="width: 70%;display: inline-block;">
                              <span
                                v-for="(list, indextwo) in tableData5[index]
                                  .labelContentList"
                                :key="indextwo"
                                style="margin-left: 10px;display: inline-block;color: #1791EC;text-align:center;line-height:17px;border-radius:4px;border: 1px solid #9ED9F3;padding: 5px 10px;height: 17px;background: #9ED9F3;"
                                >{{ list }}</span
                              >
                              <span
                                v-for="(list, indexdoen) in tableData5[index]
                                  .algLabelContentList"
                                :key="indexdoen"
                                style="display: inline-block;margin-left: 10px;color: #12A080;text-align:center;line-height:17px;border-radius:4px;border: 1px solid #6BDEC4;padding: 5px 10px;height: 17px;background: #CAF7ED;"
                                >{{ list }}</span
                              >
                            </div>
                            <div
                              style="width: 30%;float: right;text-align: right;display: inline-block;"
                            >
                              <span
                                v-if="
                                  item.sentimentWhole != null &&
                                    item.sentimentWhole.indexOf('消极') != -1
                                "
                                style="display: inline-block;margin-left: 10px;color: #12A080;text-align:center;line-height:17px;border-radius:4px;border: 1px solid red;padding: 5px 10px;height: 17px;padding: 5px 10px;color: red;"
                                >{{ item.sentimentWhole }}</span
                              >
                              <span
                                v-if="
                                  item.sentimentWhole != null &&
                                    item.sentimentWhole.indexOf('积极') != -1
                                "
                                style="display: inline-block;margin-left: 10px;color: #12A080;text-align:center;line-height:17px;border-radius:4px;border: 1px solid #6BDEC4;padding: 5px 10px;height: 17px;padding: 5px 10px;color: #12A080;"
                                >{{ item.sentimentWhole }}</span
                              >
                            </div>
                          </div>
                        </template>
                        <div
                          @mouseenter="showPlay(index)"
                          @mouseleave="hidePlay(index)"
                          style="position: relative"
                        >
                          <div
                            style="height: 70px; padding: 20px 20px 0px 20px; overflow: hidden;"
                          >
                            <p v-html="item.highlightContent"></p>
                          </div>
                          <div
                            class="play"
                            v-show="item.display"
                            @click="showDetail(item.callID, item.recordFileURL)"
                          >
                            <img src="../../../assets/img/u493.png" />
                          </div>
                        </div>
                      </el-collapse-item>
                    </div>
                  </el-collapse>
                </div>
                <div class="noneData" v-else="">
                  <div>暂无数据</div>
                </div>
              </div>
              <div class="rightPage">
                <el-pagination
                  small
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page="pageNumber"
                  :page-sizes="[20, 50, 100, 200]"
                  :page-size="pageSize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="this.count"
                >
                </el-pagination>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <vWord
      v-show="showWordModal"
      ref="wordModal"
      :keys="keys"
      :links="links"
      :categories="categories"
      :nodesData="nodesData"
    ></vWord>
    <vKeyWords
      v-if="showKeyWordsModal"
      ref="keyWords"
      :selectKeyWord="selectKeyWord"
      :wordtype="wordtype"
      @addWordModalVisible="addWordModalVisible"
    ></vKeyWords>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import global from '@/global'
import Qs from 'qs'
import recordingplay from '../recordingPlay/recordingPlayResultScore.vue'
import vPlayer from '../../common/player.vue'
import bus from '../../common/bus.js'
import vtopicClustering from './themeClustering.vue'
import vWord from './word.vue'
import ExportFile from '../../common/export-file'
import vKeyWords from './keyWords.vue'
let currentBaseUrl = global.currentBaseUrl
let myChartCi
let requestUrls = {
  getRadioBySortID: currentBaseUrl + '/recordSort/',
  getRecordAlgLabel: currentBaseUrl + '/recordAlgLabel/all',
  getAllRecordLabel: currentBaseUrl + '/recordLabel/all',
  clusterResultExport: currentBaseUrl + '/ivsClusterRule/clusterResultExport',
  getKeyWord: currentBaseUrl + '/hotAnlys/type/keyword',
  getAllInProgress: currentBaseUrl + '/recordLabel/allInProgress',
}
export default {
  components: {
    ExportFile,
    recordingplay,
    vPlayer,
    vtopicClustering,
    vWord,
    vKeyWords,
  },
  data() {
    const generateData = (_) => {
      const data = []
      for (let i = 1; i <= 15; i++) {
        data.push({
          key: i,
          label: '备选项' + i,
          disabled: i % 4 === 0,
        })
      }
      return data
    }
    return {
      wordtype: 1,
      showKeyWordsModal: false,
      showWordModal: false,
      importUrl: '',
      importUrlT: '',
      topicShowID: '',
      topicClusteringShow: true,
      recordDialogVisible: false,
      suanfaIds: '',
      showThree: false,
      suanfaLabelIds: [],
      gjcIds: [],
      guanjianciIds: [],
      show: false,
      showTwo: true,
      allIds: [],
      keyWords: [],
      callId: '',
      sentimentRole: '',
      sentimentLabel: '',
      alllabelIDs: [],
      labelIDs: [],
      cities: [],
      citiesTwo: [],
      checkboxGroup1: [],
      checkboxGroup2: [],
      nextShow: [], // 热词回填使用
      count: 0,
      options: [],
      value: '',
      data: generateData(),
      value1: [1, 4],
      tableData5: [],
      ruleForm: {
        seatName: '',
        region: '0',
        date1: '',
        date2: '',
        code: '',
        time: '',
        biaoqian: '',
        qxList: '',
        sentimentLabel: '',
        labelIDs: [],
        algLabelIDs: [],
      },
      allChange: {
        audioNumber: '',
        audioTime: '',
        audioImportant: [],
        audioEmotionleft: '',
        audioEmotionright: '',
      },
      rules: {
        name: [
          { required: true, message: '请输入活动名称', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' },
        ],
        region: [{ required: true, message: '请选择活动区域', trigger: 'change' }],
        date1: [
          { type: 'date', required: true, message: '请选择日期', trigger: 'change' },
        ],
        date2: [
          { type: 'date', required: true, message: '请选择时间', trigger: 'change' },
        ],
        type: [
          {
            type: 'array',
            required: true,
            message: '请至少选择一个活动性质',
            trigger: 'change',
          },
        ],
        resource: [{ required: true, message: '请选择活动资源', trigger: 'change' }],
        desc: [{ required: true, message: '请填写活动形式', trigger: 'blur' }],
      },
      formLabelWidth: '100px',
      searchForm: {
        juese: '0',
      },
      keys: '',
      links: [],
      categories: [],
      nodesData: [],
      startEndTime: '',
      multipleSelection: [],
      multipleSelectionNew: '',
      currentPage4: 4,
      isHaveMoXing: 1,
      haveMonitor: 1,
      pageNumber: 1,
      pageSize: 20,
      doClearShow: false,
      selectProps: {
        value: 'clusterRuleName',
        label: 'clusterRuleName',
      },
      pulicLabelIds: [],
      guanjianciData: [],
      suanfaData: [],
      gjcRemoveData: [],
      suanfaRemoveData: [],
      modelList: [],
      ghlString: [],
      clusterRuleId: '',
      sxTitle: '添加筛选',
      moreRules: {
        chModel: [{ required: true, message: '请选择基本模型', trigger: 'change' }],
      },
      modelSeat: {
        chModel: '',
      },
      isOtherZhu: 0,
      showOtherAlgo: false,
      showIsOther: false,
      checkedRecordList: [],
      haveSortID: false,
      activeNames: ['0'],
      hotWordSize: 0,
      checking: false,
    }
  },
  props: {
    tName: {
      type: String,
    },
    treeType: {
      type: String,
    },
    topicCount: {
      type: Number,
    },
    algorithmOther: {
      type: Boolean,
    },
    isAlgorithm: {
      type: Boolean,
    },
    hotWordSizeNew: {
      type: Number,
    },
    clearShow: {
      type: Boolean,
    },
    nextHot: {
      type: Boolean,
    },
    taskBeginTime: {
      type: String,
    },
    taskEndTime: {
      type: String,
    },
    topicID: {
      type: String,
    },
    isOtherAlgo: {
      type: Number,
    },
    isOther: {
      type: Number,
    },
    sortID: {
      type: String,
    },
    biaoqianList: {
      type: Array,
    },
    sortIDPID: {
      type: String,
    },
    resultLabelId: {
      type: String,
    },
  },
  computed: {
    /* sxTitle() {
      if (
        this.ruleForm.code !== '' ||
        this.gjcIds.length > 0 ||
        this.checkboxGroup2.length > 0 ||
        this.ruleForm.sentimentLabel !== ''
      ) {
        return '查看筛选'
      }
      return '添加筛选'
    }, */
    hotCardNum() {
      return this.checkboxGroup1 ? this.checkboxGroup1.length : 0
    },
    callSTime_Max() {
      if (this.taskEndTime) {
        return JSON.stringify(
          new Date(this.taskEndTime.replace(new RegExp('-', 'gm'), '/')).getTime()
        )
      }
      return ''
    },
    callSTime_Min() {
      if (this.taskBeginTime) {
        return JSON.stringify(
          new Date(this.taskBeginTime.replace(new RegExp('-', 'gm'), '/')).getTime()
        )
      }
      return ''
    },
    algortihmExportUrl() {
      return currentBaseUrl + '/recordSortAlg/' + this.sortID + '/records/excel'
    },
    algortihmExportUrlOther() {
      return (
        currentBaseUrl +
        '/recordSortAlg/' +
        this.sortID.split('_other')[0] +
        '/records/excel/other'
      )
    },
    exportUrlT() {
      return (
        currentBaseUrl +
        '/recordSort/' +
        this.sortID.split('_other')[0] +
        '/records/excel/other'
      )
    },
    exportUrl() {
      return currentBaseUrl + '/recordSort/' + this.sortID + '/records/excel'
    },
    exportFileParams() {
      return {
        sortID: this.sortID,
        callSTimeMin: this.callSTime_Min,
        callSTimeMax: this.callSTime_Max,
        accessToken: this.$store.state.token,
      }
    },
    clusterRole() {
      return this.$store.state.StringData.clusterRole
    },
    loadData() {
      this.doClearShow = this.clearShow
      this.hotWordSize = this.hotWordSizeNew
      if (this.isOther === 1) {
        this.isOtherZhu = 1
        this.showIsOther = true
      } else {
        this.isOtherZhu = 0
        this.showIsOther = false
      }
      if (this.isOtherAlgo === 1) {
        this.showOtherAlgo = true
      } else {
        this.showOtherAlgo = false
      }
      if (this.topicID === '') {
        this.topicShowID = this.sortID
      } else {
        this.topicShowID = this.topicID
      }
      if (
        this.ruleForm.code !== '' ||
        this.gjcIds.length > 0 ||
        this.ruleForm.qxList !== '' ||
        this.ruleForm.time !== '' ||
        this.ruleForm.sentimentLabel !== ''
      ) {
        this.doClearShow = false
        this.$emit('returnData', false)
      }
      if (this.doClearShow === true) {
        // 判断doClearShow=true
        if (this.sortID === undefined || this.sortID === '') {
          this.haveSortID = true
          this.count = 0
          this.tableData5 = []
          this.cities = []
          this.guanjianciIds = []
        } else {
          this.pageNumber = 1
          this.getRecord() // 录音列表
          this.getRecordAlgLabel()
          // 热词列表
          this.getCategoryWord()
          this.getKeyWord() // 角色列表
          this.getAllInProgress() // 关键词标签
          this.getAllRecordLabel()
          this.haveSortID = false
          this.$emit('returnData', false) // 设置clearShow=false 防止监听到查询条件有变化的时候自动调用接口
        }
      }
    },
    eUrl() {
      return (
        requestUrls['clusterResultExport'] +
        '?clusterRuleId=' +
        this.resultLabelId +
        '&accessToken=' +
        this.$store.state.token
      )
    },
    selectKeyWord() {
      return this.checkboxGroup1.join(',')
    },
  },
  watch: {
    loadData(val, oldval) {},
  },
  methods: {
    // 重新请求热词数据
    addWordModalVisible(bol) {
      if (bol === false) {
        this.getCategoryWord()
        this.checkboxGroup1 = []
      }
    },
    // 树节点点击
    handleNodeClick(data) {
      this.currentNode = data
      this.classId = data.classId
      // this.getKeyWords()
    },
    // 获取所有启用标签
    getAllInProgress() {
      this.axios
        .get(requestUrls['getAllInProgress'])
        .then((res) => {
          let shuzu = []
          if (res.data.data.length > 0) {
            for (let n = 0; n < res.data.data.length; n++) {
              shuzu[n] = {
                label: res.data.data[n].labelName,
                value: {
                  label: res.data.data[n].labelName,
                  type: 'gjc',
                  id: res.data.data[n].labelId,
                },
              }
            }
            this.pulicLabelIds = shuzu
            // this.guanjianciIds = this.pulicLabelIds
          }
        })
        .catch(() => {})
    },
    // 获取所有录音标签
    getAllRecordLabel() {
      this.axios
        .get(requestUrls['getAllRecordLabel'])
        .then((res) => {
          this.guanjianciIds = res.data.data
        })
        .catch(() => {})
    },
    getLabelName(item) {
      return item.executeState == '1' ? item.labelName : item.labelName + '（停用中）'
    },
    /*
     * 查看词相关
     * */
    lookWord() {
      if (this.hotWordSize < 1) {
        this.$message.error('请选择一个热词')
        return
      } else if (this.hotWordSize > 1) {
        this.$message.error('只能选择一个热词进行查看词相关')
        return
      }
      let _this = this
      let ciparams = {}
      let wordData = []
      ciparams.word = _this.keys
      // 词相关数据画布渲染
      this.axios
        .post(currentBaseUrl + '/hotAnlys/getRelatedWords.do', Qs.stringify(ciparams))
        .then((res) => {
          if (res.data.length > 0) {
            let dataLength
            if (res.data.length >= 15) {
              dataLength = 15
            } else {
              dataLength = res.data.length
            }
            for (let i = 0; i < dataLength; i++) {
              wordData[i] = {
                id: i + 1,
                category: 1,
                label: res.data[i].name,
                name: i + 1,
                symbolSize: res.data[i].score * 90,
                ignore: false,
                flag: true,
              }
            }
            let links = []
            for (let i = 0; i < dataLength; i++) {
              links[i] = {
                source: 0,
                target: i + 1,
              }
            }
            let categories = []
            for (let i = 0; i < dataLength; i++) {
              categories[i] = {
                id: i + 1,
                name: i + 1 + '层',
              }
            }
            let nodesData = [
              {
                id: 0,
                category: 0,
                label: _this.keys,
                name: 0,
                symbolSize: 60,
                ignore: false,
                flag: true,
              },
            ]
            _this.links = links
            _this.categories = categories
            _this.nodesData = nodesData.concat(wordData)
            _this.$nextTick(function() {
              _this.showWordModal = true
              setTimeout(() => {
                _this.$refs.wordModal.lookWordModal = true // hack写法，强制清除数据
              }, 30)
            })
          } else {
            _this.$message('该词无词相关')
          }
        })
        .catch(function() {})
    },
    /*
     * 存为关键词
     * */
    saveKeyWord(value) {
      if (this.hotWordSize < 1) {
        this.$message.error('请选择一个或多个热词')
        return
      }
      let that = this
      that.wordtype = value
      this.$nextTick(function() {
        that.showKeyWordsModal = true
        setTimeout(() => {
          that.$refs.keyWords.addWordModalVisible = true // hack写法，强制清除数据
        }, 30)
      })
      // this.getWordClass(1)
    },
    // 添加筛选里面的热词勾选
    checkboxChangeTwo(val) {
      this.$emit('returnData', false)
      let obj = []
      if (val.length > 0) {
        for (let i = 0; i < val.length; i++) {
          obj[i] = val[i]
        }
      }
      this.multipleSelectionNew = obj.join(', ')
    },
    /*
     * 1、相关热词数据和数量统计
     * 2、选中的词数量大于1，查看词相关为禁用状态
     * 3、取消选中热词，全部为禁用状态
     * */
    // 热词勾选
    checkboxChange(item) {
      let that = this
      that.keys = item[0]
      this.hotWordSize = item.length
      myChartCi && myChartCi.dispose()
    },
    commonUtil(cellValue) {
      cellValue = cellValue / 1000
      let theTime = parseInt(cellValue) // 秒
      let theTime1 = 0 // 分
      let theTime2 = 0 // 小时
      if (theTime > 60) {
        theTime1 = parseInt(theTime / 60)
        theTime = parseInt(theTime % 60)
        if (theTime1 > 60) {
          theTime2 = parseInt(theTime1 / 60)
          theTime1 = parseInt(theTime1 % 60)
        }
      }
      let result = '' + parseInt(theTime) + '秒'
      if (theTime1 > 0) {
        result = '' + parseInt(theTime1) + '分' + result
      }
      if (theTime2 > 0) {
        result = '' + parseInt(theTime2) + '小时' + result
      }
      return result
    },
    // 录音列表展开、收起
    tabClick(index, flag) {
      this.num = index
      if (
        this.tableData5[index].expand != null &&
        this.tableData5[index].expand == true
      ) {
        this.tableData5[index].expand = false
      } else {
        this.tableData5[index].expand = true
      }
    },
    getKeyWord() {
      this.axios
        .get(requestUrls['getKeyWord'])
        .then((res) => {
          // let kData = JSON.parse(res.data.data)
        })
        .catch(() => {})
    },
    // 获得相关热词
    getCategoryWord() {
      let params = {
        callSTimeMin: this.callSTime_Min,
        callSTimeMax: this.callSTime_Max,
      }
      let setId = ''
      if (!this.topicID) {
        // 首次加载进来获取树的id
        setId = this.sortID
      } else {
        setId = this.topicID
      }
      let url
      if (this.isAlgorithm) {
        url = currentBaseUrl + '/hotAnlys/alg/' + setId + '/' + 0 + '/categoryWord'
      } else {
        url = currentBaseUrl + '/hotAnlys/' + setId + '/' + 0 + '/categoryWord'
      }
      this.axios
        .get(url, {
          params,
        })
        .then((res) => {
          if (res.data.data.keywords.length > 0) {
            let datas = []
            for (let i = 0; i < res.data.data.keywords.length; i++) {
              datas[i] = res.data.data.keywords[i].keyword
            }
            this.cities = res.data.data.keywords
            this.hotWordSize = 0
            this.citiesTwo = datas
            if (this.nextHot == true) {
              this.checkboxGroup1 = []
            }
          } else {
            this.cities = []
            this.citiesTwo = []
          }
        })
        .catch(() => {})
    },
    // 关闭标签弹框
    close() {
      let that = this
      that.$refs.topicClustering.topicClusteringShowDialog = false
    },
    submittedTwo(data) {
      let that = this
      that.$refs.topicClustering.topicClusteringShowDialog = false
    },
    // 点击主题聚类
    clickTopicClustering() {
      let params = {
        keyWords: this.checkboxGroup2,
        callId: this.ruleForm.code,
        callTimeMin: this.ruleForm.time,
        labelIDs: this.guanjianciData,
        sentimentRole: this.ruleForm.qxList,
        sentimentLabel: this.ruleForm.sentimentLabel,
        callSTime_Min: this.callSTime_Min,
        callSTime_Max: this.callSTime_Max,
        isOtherZhu: this.isOtherZhu,
        topicShowID: this.topicShowID,
        sortIDPID: this.sortIDPID,
        taskBeginTime: this.taskBeginTime,
        taskEndTime: this.taskEndTime,
        tName: this.tName,
        isAlgorithm: this.isAlgorithm,
      }
      if (this.count >= 50) {
        this.checking = true
        this.axios
          .get(
            currentBaseUrl +
              '/ivsClusterRule/checkClusterTrain?companyId=' +
              this.$store.state.loginUserinfo.companyId
          )
          .then((res) => {
            this.checking = false
            if (res.data === true) {
              this.$router.push({
                path: '/themeClustering',
                name: '聚类',
                params: params,
              }) // 获取路由并导到目标页面
            } else {
              this.$message({
                type: 'info',
                message: '不能聚类训练，上次聚类还没有训练完成！',
              })
            }
          })
          .catch(() => {
            this.checking = false
          })
      } else {
        this.$message({
          type: 'info',
          message: '训练样本数量不得少于50条',
        })
      }
    },
    recordPlayCloseHandler() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 添加筛选
    addSearch() {
      this.sxTitle = '添加筛选'
      this.checkboxGroup2 = this.nextShow // 查询条件关闭时热词数据回填
      this.ruleForm.code = this.allChange.audioNumber
      this.ruleForm.time = this.allChange.audioTime
      this.gjcIds = this.allChange.audioImportant
      this.ruleForm.qxList = this.allChange.audioEmotionleft
      this.ruleForm.sentimentLabel = this.allChange.audioEmotionright
      if (document.getElementById('modal').style.display === 'none') {
        document.getElementById('modal').style.display = 'block'
      } else {
        this.sxTitle = '查看筛选'
        document.getElementById('modal').style.display = 'none'
      }
    },
    showDetail(callID, recordFileURL) {
      let obj = {}
      obj.from = 'audioClassification'
      obj.callId = callID
      obj.recordFileURL = recordFileURL
      obj.pageNumber = this.pageNumber
      obj.pageSize = this.pageSize
      obj.sortID = this.sortID
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    getGuanJianCi(item) {
      let nums = 0
      let gdata = []
      for (let a = 0; a < item.length; a++) {
        for (let b = 0; b < this.pulicLabelIds.length; b++) {
          if (item[a] === this.pulicLabelIds[b].value.id) {
            gdata[nums] = this.pulicLabelIds[b]
            nums = nums + 1
            nums++
          }
        }
      }
      for (let c = 0; c < gdata.length; c++) {
        if (gdata[c] === undefined) {
          gdata.splice(c, 1)
        }
      }
      let ggDataT = []
      for (let d = 0; d < gdata.length; d++) {
        ggDataT[d] = gdata[d].value.id
      }
      this.guanjianciData = ggDataT
      this.gjcRemoveData = gdata
      let joinMData = ggDataT.join(', ')
      this.multipleSelectionNew = joinMData
    },
    /*
     * 关键词标签勾选
     * */
    guanjianciChange(item) {
      console.info(item)
      if (item.length === 0) {
        this.gjcRemoveData = []
        this.guanjianciData = []
        this.multipleSelectionNew = ''
      } else {
        this.suanfaData = []
        this.getGuanJianCi(item)
      }
    },
    // 算法标签
    getRecordAlgLabel() {
      this.axios
        .get(requestUrls['getRecordAlgLabel'])
        .then(function(res) {
          let shuzu = []
          if (res.data.length) {
            for (let h = 0; h < res.data.length; h++) {
              if (res.data[h].add === false) {
                shuzu[h] = {
                  label: res.data[h].labelName,
                  value: {
                    type: 'suanfa',
                    id: this.biaoqianList[h].labelId,
                  },
                }
              }
            }
            this.suanfaLabelIds = shuzu
          }
        })
        .catch(() => {})
    },
    /*
     * 关闭筛选 条件弹框
     * */
    closeModal() {
      this.checkboxGroup2 = this.nextShow // 查询条件关闭时热词数据回填
      this.ruleForm.code = this.allChange.audioNumber
      this.ruleForm.time = this.allChange.audioTime
      this.gjcIds = this.allChange.audioImportant
      this.ruleForm.qxList = this.allChange.audioEmotionleft
      this.ruleForm.sentimentLabel = this.allChange.audioEmotionright
      document.getElementById('modal').style.display = 'none'
      if (
        this.ruleForm.code !== '' ||
        this.ruleForm.time !== '' ||
        this.gjcIds.length > 0 ||
        this.checkboxGroup2.length > 0 ||
        this.ruleForm.sentimentLabel !== ''
      ) {
        this.sxTitle = '查看筛选'
      } else {
        this.sxTitle = '添加筛选'
      }
    },
    /*
     * 清空筛选条件
     * */
    clear() {
      this.$emit('returnData', false)
      this.ruleForm = {
        seatName: '',
        region: '0',
        date1: '',
        date2: '',
        code: '',
        time: '',
        biaoqian: '',
        qxList: '',
        sentimentLabel: '',
        xMin: '',
        xMax: '',
      }
      // 数据回填的被清空
      this.allChange = {
        audioNumber: '',
        audioTime: '',
        audioImportant: [],
        audioEmotionleft: '',
        audioEmotionright: '',
      }
      this.gjcIds = []
      this.multipleSelectionNew = ''
      this.guanjianciData = []
      this.checkboxGroup2 = []
      this.nextShow = []
    },
    getRadioListBySortID() {
      let that = this
      let url
      if (that.sortID.endsWith('_other')) {
        url =
          requestUrls['getRadioBySortID'] +
          that.sortID.split('_other')[0] +
          '/records/other'
      } else {
        url = requestUrls['getRadioBySortID'] + that.sortID + '/records'
      }
      that.axios
        .get(url)
        .then((res) => {
          that.tableData5 = res.data.results
          that.count = res.data.count
        })
        .catch(() => {})
    },
    getRecord() {
      let that = this
      if (this.sortID === '') {
      } else {
        let params = {
          // sortID: this.sortID,
          keyWords: this.checkboxGroup2,
          pageNumber: this.pageNumber,
          pageSize: this.pageSize,
          callId: this.ruleForm.code,
          callTimeMin: this.ruleForm.time,
          labelIDs: this.gjcIds,
          sentimentRole: this.ruleForm.qxList,
          sentimentLabel: this.ruleForm.sentimentLabel,
          callSTimeMin: this.callSTime_Min,
          callSTimeMax: this.callSTime_Max,
        }
        // 获取相关热词给查询框关闭时使用
        this.nextShow = this.checkboxGroup2
        this.allChange.audioNumber = this.ruleForm.code
        this.allChange.audioTime = this.ruleForm.time
        this.allChange.audioImportant = this.gjcIds
        this.allChange.audioEmotionleft = this.ruleForm.qxList
        this.allChange.audioEmotionright = this.ruleForm.sentimentLabel
        if (this.ruleForm.qxList) {
          switch (this.ruleForm.qxList) {
            case '全部':
              params.sentimentRole = '0'
              break
            case '客户':
              params.sentimentRole = '1'
              break
            default:
              params.sentimentRole = '2'
          }
        }
        if (this.ruleForm.sentimentLabel) {
          switch (this.ruleForm.sentimentLabel) {
            case '积极':
              params.sentimentLabel = '0'
              break
            case '正常':
              params.sentimentLabel = '1'
              break
            default:
              params.sentimentLabel = '2'
          }
        }

        switch (this.ruleForm.region) {
          case '0':
            params.callTimeMax = params.callTimeMax
              ? params.callTimeMax * 1000
              : undefined
            params.callTimeMin = params.callTimeMin
              ? params.callTimeMin * 1000
              : undefined
            break
          case '1':
            params.callTimeMax = params.callTimeMax
              ? params.callTimeMax * 1000 * 60
              : undefined
            params.callTimeMin = params.callTimeMin
              ? params.callTimeMin * 1000 * 60
              : undefined
            break
          default:
            params.callTimeMax = params.callTimeMax
              ? params.callTimeMax * 1000 * 60 * 60
              : undefined
            params.callTimeMin = params.callTimeMin
              ? params.callTimeMin * 1000 * 60 * 60
              : undefined
        }
        let url
        if (this.treeType === 'gjc') {
          if (that.sortID.endsWith('_other')) {
            url =
              requestUrls['getRadioBySortID'] +
              that.sortID.split('_other')[0] +
              '/records/other'
          } else {
            url = requestUrls['getRadioBySortID'] + this.sortID + '/records'
          }
        } else {
          if (that.sortID.endsWith('_other')) {
            url =
              currentBaseUrl +
              '/recordSortAlg/' +
              that.sortID.split('_other')[0] +
              '/records/other'
          } else {
            url = currentBaseUrl + '/recordSortAlg/' + this.sortID + '/records'
          }
        }
        // 查询的参数传给父组件页面
        this.$emit('searchData', params)
        this.axios
          .get(url, {
            params: params,
            paramsSerializer: function(params) {
              return Qs.stringify(params, { arrayFormat: 'repeat' })
            },
          })
          .then((response) => {
            let { results, other } = response.data
            if (results.length > 0) {
              if (this.treeType === 'gjc') {
                if (other && other.keywords) {
                  other && other.keywords ? other.keywords : []
                  let recordKeywords = other.keywords
                  for (let i = 0; i < results.length; i++) {
                    let content =
                      results[i].wholeContent && results[i].wholeContent.slice(0, 140)
                    if (!recordKeywords) {
                      for (let j = 0; j < recordKeywords.length; j++) {
                        let highlightKeywords =
                          '<span style="color: rgb(32, 160, 255);">' +
                          recordKeywords[j] +
                          '</span>'
                        content = content.split(recordKeywords[j]).join(highlightKeywords)
                      }
                    }
                    results[i].highlightContent = content
                    results[i].display = false
                  }
                }
              } else {
                for (let i = 0; i < results.length; i++) {
                  let content =
                    results[i].wholeContent && results[i].wholeContent.slice(0, 140)
                  results[i].highlightContent = content
                  results[i].display = false
                }
              }

              that.tableData5 = results
              that.count = response.data.count
              this.activeNames = ['0']
            } else {
              that.tableData5 = []
              that.count = 0
            }
          })
      }
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let str = year + '-' + month + '-' + day
      return str
    },
    searchWord() {
      this.getCategoryWord()
    },
    handleChange(value) {},
    removeDomain(item) {
      let index = this.addMake.domains.indexOf(item)
      if (index !== -1) {
        this.addMake.domains.splice(index, 1)
      }
    },
    addShow() {
      this.inputShow = true
    },
    addDomain() {
      if (this.addMake.domains.length < this.cellMake.count) {
        this.addMake.domains.push({
          value: '',
          key: Date.now(),
        })
      } else {
        this.$message({
          type: 'error',
          message: '不能超过主题个数',
        })
      }
    },
    // 监控模式
    radioChangeTwo(val) {
      let that = this
      if (val === '1') {
        that.haveMonitor = 1
      } else {
        that.haveMonitor = 2
      }
    },
    // 鼠标放到录音内容上时展示播放按钮
    showPlay(index) {
      this.tableData5[index].display = true
    },
    // 鼠标移出录音内容上时展示播放按钮
    hidePlay(index) {
      this.tableData5[index].display = false
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.pageSize = val
      this.pageNumber = 1
      this.getRecord()
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.pageNumber = val
      this.getRecord()
    },
    // 点击查询录音列表
    searchAudioList() {
      document.getElementById('modal').style.display = 'none'
      this.sxTitle = '查看筛选'
      this.getRecord()
    },
  },
}
</script>
<style lang="less" scoped>
.startBox {
  transition: all 0.5s;
}
.secondBox {
  transform: rotate(-180deg);
  transition: all 0.5s;
}
.audioList {
  height: 100%;
  width: 100%;
  z-index: 0;
  box-sizing: border-box;
  overflow: hidden;
  .container {
    overflow: hidden;
    height: 100%;
    position: relative;
    .audioTop {
      position: relative;
      height: 40px;
      padding-left: 10px;
      line-height: 40px;
      border-bottom: 1px solid #e4e4e4;
      .export {
        display: inline-block;
        line-height: 1;
        white-space: nowrap;
        cursor: pointer;
        background: #fff;
        border: 1px solid #dcdfe6;
        color: #606266;
        -webkit-appearance: none;
        text-align: center;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
        outline: 0;
        margin: 0;
        -webkit-transition: 0.1s;
        transition: 0.1s;
        font-weight: 500;
        padding: 7px 15px;
        font-size: 12px;
        border-radius: 3px;
      }
      .audioLeft {
        position: absolute;
        left: 10px;
        cursor: pointer;
        color: #20a0ff;
        font-size: 12px;
      }
      .content-trigon-zhijiao {
        width: 0px;
        height: 0px;
        margin: 17px 0px 0px 3px;
        border-color: white #20a0ff #20a0ff white;
        border-width: 4px 4px 4px 4px;
        border-style: solid;
      }
      .audioRight {
        position: absolute;
        right: 10px;
        .mr10 {
          margin-right: 10px;
        }
        div {
          float: left;
        }
      }
    }
    .audioContent {
      position: absolute;
      top: 40px;
      bottom: 0;
      width: 100%;
      overflow: hidden;
    }
    .leftSearch {
      float: left;
      width: 277px;
      height: 100%;
      border-right: 1px solid #e4e4e4;
      overflow: auto;
      .searchHeader {
        right: 0;
        top: 0;
        width: 100%;
        text-align: right;
      }
      .searchCenter {
        box-sizing: border-box;
        width: 100%;
        height: 300px;
      }
      .searchBottom {
        height: 230px;
        overflow: auto;
        width: 100%;
        .moreSearch {
          font-size: 14px;
          text-align: left;
          color: #409eff;
          padding-left: 10px;
          text-decoration: underline;
          cursor: pointer;
        }
        .shaixuan {
          text-align: left;
          padding: 10px;
          overflow: hidden;
          cursor: pointer;
        }
        .span1 {
          float: left;
          display: inline-block;
          font-size: 14px;
        }
        .span2 {
          float: right;
          display: inline-block;
          color: #409eff;
        }
      }
      .searchForm {
        margin: 10px 10px 0px 10px;
      }
      .ci {
        color: #409eff;
        text-align: left;
        font-size: 12px;
        float: left;
        padding-left: 3px;
      }
    }
    .rightAudio {
      height: 100%;
      position: relative;
      .searchModal {
        position: absolute;
        top: 1px;
        width: 100%;
        height: 340px;
        border-bottom: 1px solid #e4e4e4;
        z-index: 99;
        background: #ffffff;
        .searchContent {
          width: 100%;
          position: absolute;
          padding: 20px;
          height: 300px;
          overflow-y: auto;
        }

        #ruleForm > * {
          margin-top: -10px;
        }
      }
      .hotterms {
        width: 100%;
        float: left;
        padding-left: 10px;

        .hot-words {
          span {
            font-size: 14px;
            float: left;
          }
        }
        .hots {
          padding-top: 4px;
          font-size: 14px;
          font-weight: bold;
          color: #1f2d3d;
          float: left;
        }
      }
      .rightTop {
        position: absolute;
        top: 0px;
        width: 100%;
        overflow: hidden;
        border-top: 1px solid #ebeef5;
        .termsMain {
          height: 62px;
          width: 100%;
          padding-top: 20px;
          margin-bottom: 18px;
          overflow-x: hidden;
          overflow-y: auto;
          .hotTotal {
            float: right;
            width: 80px;
          }
          .el-dropdown-span {
            position: absolute;
            top: -10px;
            left: 10px;
            color: #ffffff;
            background: #ff0000;
            text-align: center;
            width: 20px;
            height: 20px;
            border-radius: 50%;
          }
        }
        .rightExpost {
          float: right;
          margin-right: 10px;
        }
        .totalRadio {
          position: absolute;
          bottom: 0;
          float: left;
          padding-left: 10px;
          width: calc(100% - 20px);
          display: block;
        }
        /*div{padding:10px 0px 0px 10px;}*/
      }
      .rightTable {
        padding-top: 100px;
        padding-bottom: 60px;
        box-sizing: border-box;
        width: 100%;
        height: 100%;
        .noneData {
          height: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          overflow: auto;
          font-size: 14px;
        }
      }
      .rightPage {
        position: absolute;
        bottom: 10px;
        right: 20px;
        overflow: hidden;
        height: 32px;
        width: 100%;
        text-align: right;
      }
    }
  }
}
</style>
<style lang="less">
#audioList .clearInfo {
  text-align: left;
  cursor: pointer;
  padding-left: 10px;
  font-size: 14px;
  color: #20a0ff;
  float: left;
  width: 100px;
}
#audioList .el-collapse-item__arrow {
  display: none !important;
}
#audioList .dialog-footer {
  text-align: right;
  padding-right: 30px;
  float: right;
}
#audioList .el-checkbox-button.is-checked:first-child .el-checkbox-button__inner {
  border-left-color: #ffffff !important;
}
#audioList .el-checkbox-button.is-checked .el-checkbox-button__inner {
  background: #ffffff !important;
  color: #409eff;
  box-shadow: -1px 0 0 0 #ffffff;
}
#audioList .el-checkbox-button__inner {
  border: none !important;
  padding: 0px !important;
  border-left: none !important;
}
#audioList .el-checkbox-button:first-child .el-checkbox-button__inner {
  /* border-left: 1px solid #dcdfe6; */
  /* border-radius: 4px 0 0 4px; */
  -webkit-box-shadow: none !important;
  box-shadow: none !important;
}
#audioList .el-checkbox-button,
.el-checkbox-button__inner {
  margin-right: 10px;
  position: relative;
  display: inline-block;
  padding-top: 4px;
}
#audioList .searchForm .el-form-item__label {
  padding: 0px 6px 0px 0px !important;
}
#audioList .searchForm .el-button--mini,
.el-button--mini.is-round {
  padding: 4px;
  margin-top: 10px;
  float: left;
}
#audioList .play {
  position: absolute;
  height: 120px;
  // display: none;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  background: rgba(00, 00, 00, 0.4);
  text-align: center;
  line-height: 145px;
}
#audioList .play img {
  display: inline;
  width: 51px;
  height: 51px;
}
#audioList .el-collapse-item__header {
  height: auto !important;
  display: block !important;
}
#audioList .el-collapse {
  border-bottom: 0px solid #ebeef5;
}
#audioList .recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
.single {
  &.el-dialog__wrapper {
    position: fixed;
    top: 106px;
    left: 20px;
    right: 20px;
    bottom: 12px;
    .el-dialog {
      width: 100%;
      height: 100%;
      margin: 0 !important;
    }
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}
#audioList .findBorder .el-transfer-panel {
  width: 288px;
}
#audioList #block .el-pagination {
  text-align: center;
  .el-pager li {
    margin: 0;
    min-width: 0px;
    height: 28px;
    line-height: 28px;
    border: 1px solid #e0e6ed;
  }
  button {
    height: 28px;
    line-height: 28px;
    border: 1px solid #e0e6ed;
    margin: 0;
    min-width: 20px;
  }
}
#audioList .addName {
  margin-top: 5px;
  display: block;
  float: left;
  margin-left: 10px;
}
#audioList .addName i {
  font-size: 30px;
}
/*  #audioList .el-form-item__content{margin-left: 10px!important;}*/
/*  #audioList .el-dialog__body{padding: 0px 0px!important;}*/
#audioList .layout-box {
  overflow: hidden;
  height: 100%;
  position: relative;
}
#audioList .el-table--fit {
  height: 100%;
}
#audioList .el-table__body-wrapper {
  height: calc(100% - 50px);
  overflow-y: auto;
  overflow-x: hidden;
}
#audioList .el-range-editor.el-input__inner {
  width: 98%;
}
#audioList .el-table::before {
  left: 0;
  bottom: 0;
  width: 100%;
  height: 0px !important;
}
#audioList .el-tag {
  margin-bottom: 10px;
}
.firstAll {
  display: inline-block;
  margin-left: 10px;
  color: #12a080;
  text-align: center;
  line-height: 17px;
  border-radius: 4px;
  border: 1px solid red;
  padding: 5px 10px;
  height: 17px;
  padding: 5px 10px;
  color: red;
}
.secondAll {
  display: inline-block;
  margin-left: 10px;
  color: #12a080;
  text-align: center;
  line-height: 17px;
  border-radius: 4px;
  border: 1px solid #6bdec4;
  padding: 5px 10px;
  height: 17px;
  padding: 5px 10px;
  color: #12a080;
}
</style>
