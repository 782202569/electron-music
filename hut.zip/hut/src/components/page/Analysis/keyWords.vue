<template>
  <div id="keywords">
    <el-dialog
      :title="addTitle"
      :visible.sync="addWordModalVisible"
      size="small"
      @open="onOpen"
      :close-on-click-modal="false"
      width="700px"
    >
      <div class="radioList">
        <div style="width: 50%;float: left; padding-left: 10px;">{{ wordTitle }}</div>
        <div style="float: left;">{{ wordTitleRight }}</div>
      </div>
      <div style="margin: 20px;overflow: hidden;">
        <div style="float: left;width: 48%; height:300px;border: 1px solid #d1dbe5">
          <el-tree
            :data="smallTreeData"
            :props="wordDefaultProps"
            ref="keyWordMenu"
            node-key="classId"
            @node-click="handleNodeClick"
            check-strictly
            highlight-current
            :expand-on-click-node="expandOnClick"
          >
          </el-tree>
        </div>
        <div style="float: right;width: 48%;height:300px;border: 1px solid #d1dbe5">
          <el-tree
            :data="smallTreeDataRight"
            :props="wordDefaultProps"
            ref="keyWordMenuRight"
            node-key="classId"
            @node-click="handleNodeClickRight"
            check-strictly
            highlight-current
            :expand-on-click-node="expandOnClick"
          >
          </el-tree>
          <!--<div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">关键词描述</div>
        <el-input type="textarea" v-model="wordDescribe" :rows="10"
                  style="width: 90%; margin: 10px 0px 0px 10px;"></el-input>-->
        </div>
        <div slot="footer" style="float: right; margin-top: 10px">
          <el-button @click="cancelAdd">取 消</el-button>
          <el-button type="primary" @click="handleAddKeyWordThrottle">确 定</el-button>
        </div>
      </div>
    </el-dialog>
    <el-dialog title="提示" :visible.sync="dialog" width="30%">
      <div style="margin: 10px;" v-if="showDialog">{{ content }}</div>
      <div style="margin: 10px;" v-if="showDialogT">{{ contentTwo }}</div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogSave">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import global from '@/global'
let currentBaseUrl = global.currentBaseUrl
let qualityUrl = global.qualityUrl
import Qs from 'qs'
export default {
  data() {
    return {
      wordTitleRight: '添加到文本纠错关键词库',
      wordTitle: '添加到通用关键词库',
      showDialog: false,
      showDialogT: false,
      contentTwo: '',
      dialog: false,
      content: '',
      expandOnClick: false,
      radio: '1',
      addWordModalVisible: false,
      wordDescribe: '',
      currentNode: '',
      classId: '',
      classIdRight: '',
      wordDefaultProps: {
        children: 'childIqc',
        label: 'classTitle',
      },
      smallTreeDataRight: [],
      smallTreeData: [],
      addTitle: '',
    }
  },
  props: {
    selectKeyWord: {
      type: String,
    },
    wordtype: {
      type: Number,
    },
  },
  computed: {
    loadData() {
      console.log(this.selectKeyWord)
      console.log(this.wordtype)
    },
  },
  watch: {
    loadData(val, oldval) {},
  },
  methods: {
    dialogSave() {
      this.dialog = false
      this.showDialogT = false
      this.showDialog = false
    },
    onOpen() {
      if (this.wordtype == 1) {
        this.getWordTrees()
        this.getWordTreesRight()
        this.addTitle = '存为关键词'
        this.wordTitleRight = '添加到文本纠错关键词库'
        this.wordTitle = '添加到通用关键词库'
      } else {
        this.wordTitleRight = '添加到聚类水词库'
        this.wordTitle = '添加到通用水词库'
        this.getWaterTrees()
        this.getWaterTreesRight()
        this.addTitle = '存为水词'
      }
    },
    getWaterTrees() {
      let params = {
        classType: 2,
        classId: 0,
      }
      let url = qualityUrl + '/vocabulary/getTrees.do'
      this.axios.post(url, Qs.stringify(params)).then((response) => {
        this.smallTreeData = response.data
        console.log(response.data)
      })
    },
    getWaterTreesRight() {
      let params = {
        classType: 5,
        classId: 0,
      }
      let url = qualityUrl + '/vocabulary/getTrees.do'
      this.axios.post(url, Qs.stringify(params)).then((response) => {
        this.smallTreeDataRight = response.data
      })
    },
    // 获得通用关键词库
    getWordTrees() {
      let params = {
        classType: 1,
        classId: 0,
      }
      let url = qualityUrl + '/vocabulary/getTrees.do'
      this.axios.post(url, Qs.stringify(params)).then((response) => {
        this.smallTreeData = response.data
      })
    },
    // 获得文本纠错关键词库
    getWordTreesRight() {
      let params = {
        classType: 7,
        classId: 0,
      }
      let url = qualityUrl + '/vocabulary/getTrees.do'
      this.axios.post(url, Qs.stringify(params)).then((response) => {
        this.smallTreeDataRight = response.data
      })
    },
    handleAddKeyWord() {
      if (this.currentNode == '') {
        this.$message({
          type: 'error',
          message: '添加关键词失败,分类不能为空',
        })
      } else {
        let _this = this
        let params = {
          wordlibType: 1,
          wordName: _this.selectKeyWord,
          keywordClass: 3,
          wordType: 1,
          wordDescribe: _this.wordDescribe,
          classId: _this.currentNode.classId,
        }
        let url =
          currentBaseUrl +
          '/vocabulary/addManyKeyword.do?accessToken=' +
          this.$store.state.token
        _this.axios.post(url, Qs.stringify(params)).then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '添加关键词成功',
            })
            _this.checkboxGroup1 = []
            _this.wordDescribe = ''
          } else {
            _this.$message({
              type: 'error',
              message: '关键词已存在',
            })
          }
          _this.addWordModalVisible = false
          _this.$emit('addWordModalVisible', false)
          // _this.getCategoryWord()
        })
      }
    },
    // 添加关键词
    handleAddKeyWordThrottle() {
      let that = this
      if (this.classId == '' && this.classIdRight == '') {
        return
      } else {
        if (this.classId !== '') {
          let wordlibType
          let mess
          let wordStart
          if (this.wordtype == 1) {
            wordlibType = 1
            mess = '添加到通用关键词库成功！'
            wordStart = '通用关键词库：'
          } else {
            wordlibType = 2
            mess = '添加到通用水词库成功！'
            wordStart = '通用水词库：'
          }
          let params = {
            wordlibType: wordlibType,
            wordNames: this.selectKeyWord,
            classId: this.classId,
          }
          let url = qualityUrl + '/vocabulary/addMoreWords.do'
          this.axios.post(url, Qs.stringify(params)).then((response) => {
            if (response.data.length == 0) {
              that.$message({
                message: wordStart + mess,
                type: 'success',
              })
              this.addWordModalVisible = false
              this.$emit('addWordModalVisible', false)
            }
            if (response.data.length > 0) {
              this.showDialog = true
              this.dialog = true
              this.content = wordStart + '[' + response.data + ']' + '已添加过！'
            }
            this.classId = ''
            this.$refs.keyWordMenu.setCurrentKey(null)
          })
        }
        if (this.classIdRight !== '') {
          let wordlibTypeT
          let messT
          let wordStartT
          if (this.wordtype == 1) {
            wordlibTypeT = 7
            messT = '添加到文本纠错关键词库成功！'
            wordStartT = '文本纠错关键词库：'
          } else {
            wordlibTypeT = 5
            messT = '添加到聚类水词库成功！'
            wordStartT = '聚类水词库：'
          }
          let paramsR = {
            wordlibType: wordlibTypeT,
            wordNames: this.selectKeyWord,
            classId: this.classIdRight,
          }
          let urlT = qualityUrl + '/vocabulary/addMoreWords.do'
          that.axios.post(urlT, Qs.stringify(paramsR)).then((res) => {
            if (res.data.length == 0) {
              that.$message({
                message: wordStartT + messT,
                type: 'success',
              })
              this.addWordModalVisible = false
              this.$emit('addWordModalVisible', false)
            }
            if (res.data.length > 0) {
              this.showDialogT = true
              this.dialog = true
              this.contentTwo = wordStartT + '[' + res.data + ']' + '已添加过！'
            }
            this.$refs.keyWordMenuRight.setCurrentKey(null)
            this.classIdRight = ''
          })
        }
      }
    },
    // 取消添加关键词
    cancelAdd() {
      this.addWordModalVisible = false
    },
    handleNodeClickRight(data) {
      this.classIdRight = data.classId
    },
    // 树节点点击
    handleNodeClick(data) {
      this.currentNode = data
      this.classId = data.classId
      // this.getKeyWords()
    },
    // 获取关键词、水词分类
    getWordClass(val) {
      let _this = this
      let url =
        currentBaseUrl + '/vocabulary/getTrees.do?accessToken=' + this.$store.state.token
      let params = {
        classId: 0,
        classType: val,
      }
      _this.axios.post(url, Qs.stringify(params)).then(function(response) {
        _this.smallTreeData = response['data']
        _this.smallTreeDataRight = response['data']
      })
    },
  },
}
</script>
<style lang="less" scoped>
.radioList {
  margin: 10px 10px 0px 10px;
  overflow: hidden;
  .el-radio + .el-radio {
    margin-left: 10px !important;
  }
}
</style>
<style lang="less">
#keywords {
  .el-dialog__footer {
    padding: 10px 20px 50px !important;
  }
}
</style>
