<template>
  <div class="repeat-call-wrapper">
    <div v-show="!showCallList" class="rp-container">
      <header>
        <span>智能分析——重复来电分析</span>
      </header>

      <section class="repeat-call-search">
        <div>
          <label>业务</label>
          <business-tree
            ref="businessTree"
            @saveSubjectClassId="saveSubjectClassId"
          ></business-tree>
          <dateComponent
            ref="dateComponent"
            @changeDate="getChildChangeDate"
          ></dateComponent>
        </div>
        <div class="search-row">
          <div style="flex:1;">
            <label for>区域</label>
            <el-select v-model="custArea" clearable placeholder="请选择">
              <el-option
                v-for="item in province"
                :key="item.proCode"
                :label="item.proName"
                :value="item.proName"
              ></el-option>
            </el-select>
            <label for style="margin-left: 20px;">来电次数</label>
            <el-input
              v-model="callNum"
              type="number"
              @blur="onBlur"
              style="width:90px;"
              placeholder
              min="2"
            ></el-input>
            <!--<label for>来电号码</label>-->
            <!--<el-input v-model="keyword" placeholder="请输入内容"></el-input>-->
          </div>
          <el-button @click="onSearch" style="margin-left: 10px" type="primary"
            >查询</el-button
          >
        </div>
      </section>

      <!--<div class="header-tab u-flex">-->
      <!--<el-radio-group v-model="selectTab" @change="changeTab">-->
      <!--<el-radio-button label="0">分析情况</el-radio-button>-->
      <!--<el-radio-button label="1">录音列表</el-radio-button>-->
      <!--</el-radio-group>-->
      <!--<el-button>导出</el-button>-->
      <!--</div>-->
      <section class="chart-wrapper">
        <div id="barChart" style="width:100%;height:400px;"></div>
      </section>
      <section class="u-flex" style="padding-bottom:10px;">
        <div class="u-flex-item bd">
          <div id="pieChart" style="width:100%;height:400px;"></div>
        </div>
        <div class="u-flex-item bd">
          <div id="mapChart" style="width:100%;height:400px;"></div>
        </div>
      </section>
      <div class="call-table-wrapper">
        <div class="table-content">
          <el-table :data="repeatList" v-loading="listLoading" style="width: 100%">
            <el-table-column
              type="index"
              label="序号"
              :index="indexMethod"
              width="80"
            ></el-table-column>
            <el-table-column label="用户号码" prop="callNo" width="150"></el-table-column>
            <el-table-column
              prop="callNum"
              label="来电次数"
              width="180"
            ></el-table-column>
            <el-table-column prop="custArea" label="区域" width="180"></el-table-column>
            <el-table-column prop="sortName" label="业务分类"></el-table-column>
            <el-table-column prop="callSTime" label="最后来电时间">
              <template slot-scope="scope">{{
                scope.row.callSTime | formatTime
              }}</template>
            </el-table-column>
            <el-table-column label="操作" width="100">
              <template slot-scope="scope">
                <el-button @click="showCall(scope.row)" type="text" size="small"
                  >详情</el-button
                >
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <section v-show="showCallList" class="u-flex u-flex-column call-list-wrapper">
      <header>
        <el-button @click="back" type="text">&lt; 返回</el-button>
        <el-button @click="exportList">导出</el-button>
      </header>
      <div class="u-flex-item table-content">
        <el-table :data="callList" v-loading="callLoading" style="width: 100%">
          <el-table-column
            type="index"
            label="序号"
            width="80"
            :index="indexCallMethod"
          ></el-table-column>
          <el-table-column prop="callId" label="录音编号" width="150"></el-table-column>
          <el-table-column prop="callSTime" label="录音时间" width="180">
            <template slot-scope="scope">{{ scope.row.callSTime | formatTime }}</template>
          </el-table-column>
          <el-table-column prop="callTime" label="通话时长" width="150">
            <template slot-scope="scope">{{
              scope.row.callTime | filterCallTime
            }}</template>
          </el-table-column>
          <el-table-column prop="seatNo" label="坐席ID"></el-table-column>
          <el-table-column prop="sortName" label="业务分类"> </el-table-column>
          <el-table-column prop="dataState" label="状态"></el-table-column>
          <el-table-column
            prop="systemScore"
            label="系统评分"
            width="120"
          ></el-table-column>
          <el-table-column label="操作" width="100">
            <template slot-scope="scope">
              <el-button @click="showVoice(scope.row)" type="text" size="small"
                >查看</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="page">
        <el-pagination
          @size-change="handleCallSizeChange"
          @current-change="handleCallCurrentChange"
          :current-page="callPage.currentPage"
          :page-sizes="pageSizes"
          :page-size="callPage.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="callPage.total"
        >
        </el-pagination>
      </div>
    </section>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import qs from 'qs'
import moment from 'moment'
import dateComponent from '../reportForms/dateComponent'
import businessTree from '../reportForms/businessTree'
import recordingplay from '../recordingPlay/recordingPlayResultScore'
import bus from '../../common/bus'
import province from '../../common/province'
import global from '../../../global'
import commonUtil from '../../../utils/commonUtil.js'
const currentBaseUrl = global.currentBaseUrl

export default {
  name: 'repeatedCall',
  components: {
    dateComponent,
    recordingplay,
    businessTree,
  },
  data() {
    return {
      showCallList: false, // 是否显示录音源列表
      province, // 省份列表
      custArea: '', // 选中的区域（省份）
      keyword: '',
      callNum: '', // 来电次数
      startTime: '', // 开始时间
      endTime: '', // 结束时间
      statisticsSize: '', // 统计粒度
      // selectTab: '0',
      businessType: '', // 业务
      recordDialogVisible: false,
      repeatList: [], // 重复来电列表
      currentPage: 1, // 当前页码
      total: 0, // 记录总条数
      pageSize: 10, // 每页显示的记录条数
      pageSizes: [10, 15, 20, 25],
      callPage: {
        currentPage: 1, // 当前页码
        total: 0, // 记录总条数
        pageSize: 10, // 每页显示的记录条数
      },
      repeatBusiness: [], // 重复来电业务分布
      repeatPeople: [], // 重复来电人数分布
      repeatMap: [], // 区域分布
      callList: [], // 录音源列表
      params: {}, // 请求参数
      listLoading: false, // 重复来电列表loading
      callLoading: false, // 录音列表loading
    }
  },
  methods: {
    back() {
      this.showCallList = false
    },
    getChildChangeDate(val) {
      const arr = val.split(',')
      this.startTime = arr[1]
      this.endTime = arr[2]
      this.statisticsSize = arr[0]
    },
    onSearch() {
      this.params.businessType = this.businessType
      this.params.startTime = this.startTime
      this.params.endTime = this.endTime
      this.params.statisticsSize = this.statisticsSize
      this.params.custArea = this.custArea
      this.params.callNum = this.callNum
      this.getTabOne()
    },
    // 获取树当前选中节点
    saveSubjectClassId(val) {
      if (this.businessType === '') {
        this.businessType = val
        this.init()
        return
      }
      this.businessType = val
    },
    // 控制重复来电人数大于等于2
    onBlur(v) {
      if (v.target.value && v.target.value < 2) {
        this.callNum = 2
      }
    },
    // changeTab(val) {
    //   if (val == 0) {
    //     this.initBarChart();
    //     this.initPieChart();
    //     this.initMapChart();
    //   }
    // },
    // 重复来电业务分布
    initBarChart() {
      const categoryData = this.repeatBusiness.map((item) => item.sortName)
      const valueData = this.repeatBusiness.map((item) => {
        return {
          value: item.sortNum,
          name: item.sortName,
          id: item.sortId,
        }
      })
      const option = {
        color: ['#3398DB'],
        title: {
          text: '重复来电业务分布',
          x: 'center',
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        toolbox: this.getToolbox(this.exportBar),
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            data: categoryData,
            axisTick: {
              alignWithLabel: true,
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
          },
        ],
        series: [
          {
            name: '录音条数',
            type: 'bar',
            barWidth: '60%',
            data: valueData,
          },
        ],
      }
      this.$nextTick(() => {
        let myChart = this.$echarts.init(document.getElementById('barChart'))
        myChart.clear()
        myChart.setOption(option)
        // 查看详情
        myChart.off('click')
        myChart.on('click', (params) => {
          this.currentPage = 1
          this.repeatParams = {
            custArea: this.params.custArea,
            callNum: this.params.callNum,
            sortId: params.data.id,
            sortName: params.data.name,
            pageSize: this.pageSize,
            currentPage: this.currentPage,
          }
          this.getRepeatedList(this.repeatParams)
        })
      })
    },
    getToolbox(cb) {
      return {
        show: true,
        right: 15,
        top: 0,
        itemSize: 18,
        feature: {
          saveAsImage: { show: true, icon: 'image://static/img/downLoad.png' },
          myExcel: {
            show: true,
            title: '导出Excel',
            icon: 'image://static/img/excelReport.png',
            z: '999',
            left: 'center',
            onclick: () => {
              cb && cb()
            },
          },
        },
      }
    },
    // 重复来电人数分布
    initPieChart() {
      const pieData = this.repeatPeople.map((item) => {
        return {
          value: item.callCount,
          name: item.callNumName,
          num: item.callNum,
        }
      })
      // const pieData = [
      //   { value: 335, name: '二次' },
      //   { value: 310, name: '三次' },
      //   { value: 234, name: '四次' },
      //   { value: 135, name: '五次' },
      //   { value: 548, name: '六次' },
      // ];
      const legendData = pieData.map((item) => {
        return item.name
      })
      let total = 0
      for (let i in pieData) {
        total += +pieData[i].value
      }
      const option = {
        title: {
          text: '重复来电人数分布',
        },
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)',
        },
        legend: {
          orient: 'vertical',
          right: 15,
          bottom: 30,
          data: legendData,
          formatter: (name) => {
            // 显示百分比和数据
            const v = pieData.filter((item) => item.name == name)
            const value = +v[0].value
            const p = ((value / total) * 100).toFixed(2)
            return `${name}  ${value}，${p}%`
          },
        },
        toolbox: this.getToolbox(this.exportPie),
        series: [
          {
            name: '重复来电人数',
            type: 'pie',
            radius: '70%',
            center: ['40%', '60%'],
            data: pieData,
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
              },
            },
            label: {
              formatter: '{b} {d}%',
            },
          },
        ],
      }
      this.$nextTick(() => {
        let myChart = this.$echarts.init(document.getElementById('pieChart'))
        myChart.clear()
        myChart.setOption(option)
        myChart.off('click')
        myChart.on('click', (params) => {
          this.currentPage = 1
          this.repeatParams = {
            custArea: this.params.custArea,
            callNum: params.data.num,
            pageSize: this.pageSize,
            currentPage: this.currentPage,
          }
          this.getRepeatedList(this.repeatParams)
        })
      })
    },
    // 区域分布
    initMapChart() {
      let myData = this.repeatMap.map((item) => {
        return {
          name: item.custArea,
          value: item.custAreaNum,
        }
      })
      let prov = province.filter((item) => {
        return !myData.some((d) => d.name == item.proName)
      })
      prov = prov.map((item) => {
        return {
          name: item.proName,
          value: '-',
        }
      })
      myData = [...myData, ...prov]
      // const mydata = [
      //   { name: '北京', value: '100' },
      //   { name: '天津', value: 30 },
      //   { name: '上海', value: 36 },
      //   { name: '重庆', value: 39 },
      //   { name: '河北', value: 36 },
      //   { name: '陕西', value: 66 },
      //   { name: '吉林', value: 36 },
      //   { name: '福建', value: 36 },
      //   { name: '贵州', value: 36 },
      //   { name: '广东', value: 36 },
      //   { name: '青海', value: 36 },
      //   { name: '西藏', value: 36 },
      //   { name: '四川', value: 36 },
      //   { name: '宁夏', value: 36 },
      //   { name: '海南', value: 36 },
      //   { name: '台湾', value: 36 },
      //   { name: '香港', value: 36 },
      //   { name: '澳门', value: 36 },
      // ]
      const option = {
        title: {
          text: '区域分布',
        },
        toolbox: this.getToolbox(this.exportLine),
        tooltip: {
          trigger: 'item',
          formatter: (params) => {
            const v = isNaN(params.value) ? '0' : params.value
            return `来电人数 <br/>${params.name} : ${v}`
          },
        },
        visualMap: {
          min: 0,
          max: 2500,
          show: false,
        },
        series: [
          {
            name: '来电人数',
            type: 'map',
            mapType: 'china',
            roam: true,
            label: {
              normal: {
                show: true, //省份名称
              },
              emphasis: {
                show: false,
              },
            },
            data: myData, //数据
          },
        ],
      }
      this.$nextTick(() => {
        let myChart = this.$echarts.init(document.getElementById('mapChart'))
        myChart.clear()
        myChart.setOption(option)
        myChart.off('click')
        myChart.on('click', (params) => {
          if (!params.data) return
          this.currentPage = 1
          this.repeatParams = {
            custArea: params.data.name,
            pageSize: this.pageSize,
            currentPage: this.currentPage,
          }
          this.getRepeatedList(this.repeatParams)
        })
      })
    },
    // 导出重复来电业务分布
    exportBar() {
      const url = `${currentBaseUrl}/report/repeatedCalls/distribution/excel`
      commonUtil.doExport(url, this.params, global.jsonHeader)
    },
    // 导出区域分布
    exportLine() {
      const url = `${currentBaseUrl}/report/repeatedCalls/CallsArea/excel`
      commonUtil.doExport(url, this.params, global.jsonHeader)
    },
    // 导出重复来电人数分布
    exportPie() {
      const url = `${currentBaseUrl}/report/repeatedCalls/callsNum/excel`
      commonUtil.doExport(url, this.params, global.jsonHeader)
    },
    // 导出录音源列表
    exportList() {
      const url = `${currentBaseUrl}/report/repeatedCalls/records/excel`
      commonUtil.doExport(url, this.callParams, global.jsonHeader)
    },
    recordPlayCloseHandler() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 显示录音源列表
    showCall(row) {
      this.callPage.currentPage = 1
      this.callParams = {
        sortId: row.sortId,
        sortName: row.sortName,
        cityName: row.cityName,
        callNo: row.callNo,
        pageSize: this.callPage.pageSize,
        startTime: this.params.startTime,
        statisticsSize: this.params.statisticsSize,
        endTime: this.params.endTime,
        currentPage: 1, // 从1开始
      }
      this.getCallList(this.callParams)
      this.showCallList = true
    },
    // 获取录音源列表
    getCallList(params) {
      this.callLoading = true
      const req = this.axios.post(
        `${currentBaseUrl}/report/repeatedCalls/getRecordsList`,
        qs.stringify(params)
      )
      req
        .then(({ data }) => {
          this.callList = data.results || []
          this.callPage.total = data.count
          this.callLoading = false
        })
        .catch(() => {
          this.callLoading = false
        })
    },
    // 调到录音播放页
    showVoice(row) {
      let { callId, isSampled, callSTime, callNo, mblNo, recordFileURL } = row
      let obj = {}
      obj.from = 'recordingpoll'
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.isSampled = isSampled
      obj.callSTime = callSTime
      obj.mblNo = mblNo ? mblNo : ''
      obj.callNo = callNo ? callNo : ''
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 分页
    handleSizeChange(val) {
      this.pageSize = val
      this.repeatParams.pageSize = val
      this.getRepeatedList(this.repeatParams)
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.repeatParams.currentPage = val
      this.getRepeatedList(this.repeatParams)
    },
    // 录音源分页
    handleCallSizeChange(val) {
      this.callPage.pageSize = val
      this.callParams.pageSize = val
      this.getCallList(this.callParams)
    },
    handleCallCurrentChange(val) {
      this.callPage.currentPage = val
      this.callParams.currentPage = val
      this.getCallList(this.callParams)
    },
    // 表格序号显示
    indexMethod(idx) {
      return (this.currentPage - 1) * this.pageSize + idx + 1
    },
    // 录音源表格序号显示
    indexCallMethod(idx) {
      return (this.callPage.currentPage - 1) * this.callPage.pageSize + idx + 1
    },
    // 重复来电业务分布
    getRepeatedDist() {
      const req = this.axios.post(
        `${currentBaseUrl}/report/repeatedCalls/getRepeatedCallsDistribution`,
        qs.stringify(this.params)
      )
      req
        .then(({ data }) => {
          this.repeatBusiness = data.data || []
          this.initBarChart()
        })
        .catch(() => {})
    },
    // 重复来电人数分布
    getRepeatedPeople() {
      const req = this.axios.post(
        `${currentBaseUrl}/report/repeatedCalls/getRepeatedCallsNumDistribution`,
        qs.stringify(this.params)
      )
      req
        .then(({ data }) => {
          this.repeatPeople = data.data || []
          this.initPieChart()
        })
        .catch(() => {})
    },
    // 区域分布
    getRepeatedArea() {
      const req = this.axios.post(
        `${currentBaseUrl}/report/repeatedCalls/getRepeatedCallsAreaDistribution`,
        qs.stringify(this.params)
      )
      req
        .then(({ data }) => {
          this.repeatMap = data.data || []
          this.initMapChart()
        })
        .catch(() => {})
    },
    // 重复列表
    getRepeatedList(params) {
      this.listLoading = true
      const req = this.axios.post(
        `${currentBaseUrl}/report/repeatedCalls/getRepeatedCallsLists`,
        qs.stringify(params)
      )
      req
        .then(({ data }) => {
          this.repeatList = data.results || []
          this.total = data.count || 0
          this.listLoading = false
        })
        .catch(() => {
          this.listLoading = false
        })
    },
    // 预处理数据
    getPreData() {
      const req = this.axios.get(
        `${currentBaseUrl}/report/repeatedCalls/pretreatmentRepeatedCalls`,
        {
          params: this.params,
        }
      )
      // req.then(({ data }) => {
      //   console.log(data);
      //   // this.callLoading = false;
      // }).catch(() => {
      //   // this.callLoading = false;
      // })
      return req
    },
    // tab 0
    getTabOne() {
      this.currentPage = 1
      this.repeatParams = {
        custArea: this.params.custArea,
        callNum: this.params.callNum,
        pageSize: this.pageSize,
        currentPage: this.currentPage,
      }
      // 获取图表数据
      this.getPreData().then(({ data }) => {
        if (data.data) {
          // 返回true时才能继续处理
          this.getRepeatedDist()
          this.getRepeatedPeople()
          this.getRepeatedArea()
          this.getRepeatedList(this.repeatParams)
        } else {
          // 没有数据
          this.repeatBusiness = []
          this.repeatPeople = []
          this.repeatMap = []
          this.repeatList = []
          this.total = 0
          this.initBarChart()
          this.initPieChart()
          this.initMapChart()
          this.$message.error('请求数据为空')
        }
      })
    },

    init() {
      this.params.businessType = this.businessType
      this.params.startTime = this.startTime
      this.params.endTime = this.endTime
      this.params.statisticsSize = this.statisticsSize
      this.params.custArea = this.custArea
      this.getTabOne()
    },
  },
  mounted() {
    this.initBarChart()
    this.initPieChart()
    this.initMapChart()
    this.recordPlayCloseHandler()
  },
  filters: {
    formatTime(val) {
      if (val) {
        return moment(val).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    filterCallTime(val) {
      if (val) {
        let time = parseInt(val / 1000)
        return time
      }
    },
  },
}
</script>
<style lang="less">
.repeat-call-wrapper {
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 0px 0px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
  // .repeat-tab{
  //   margin-top: 20px;

  //   &.el-tabs--card{
  //     >.el-tabs__header{
  //       border-bottom: none;
  //     }
  //   }

  //   .el-tabs__item{
  //     border-bottom: 1px solid  #E4E7ED;
  //     transition-duration: 0s;
  //     cursor: pointer;

  //     &.is-active{
  //       color: #FFF;
  //       background-color: #409EFF;
  //       border-color: #409EFF;
  //       box-shadow: -1px 0 0 0 #409EFF;
  //       border:none;
  //     }
  //   }
  // }
}
</style>
<style lang="less" scoped>
.repeat-call-wrapper {
  width: 100%;
  height: 100%;
  padding: 0 20px 10px;
  box-sizing: border-box;

  header {
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;

    span {
      font-size: 14px;
    }
  }
  .repeat-call-search {
    border: 1px solid #ccc;
    padding: 20px 10px;

    label {
      margin: 0 10px;
    }

    .search-row {
      display: flex;
      align-items: center;
      margin-top: 20px;

      .el-input {
        width: 200px;
      }
      .right {
        flex: 1;
        text-align: right;
      }
    }
  }

  .header-tab {
    height: 75px;
    justify-content: space-between;
  }

  // // 谷歌
  // input[type=number]::-webkit-outer-spin-button,
  // input[type=number]::-webkit-inner-spin-button {
  //   -webkit-appearance: none!important;
  //   appearance: none!important;
  //   margin: 0;
  // }
  // // 火狐
  // input[type=number]{
  //   -moz-appearance:textfield;
  // }

  .chart-wrapper {
    border: 1px solid #ccc;
    margin-bottom: 10px;
    margin-top: 10px;
  }

  .call-table-wrapper {
    .table-content {
      min-height: 100px;
      max-height: 600px;
      overflow-y: scroll;
    }

    > div {
      width: 100%;
    }

    .page {
      height: 40px;
      margin-top: 10px;
      text-align: right;
    }
  }

  .bd {
    border: 1px solid #ccc;

    &:not(:first-child) {
      margin-left: 10px;
    }
  }

  .call-list-wrapper {
    height: 100%;
    header {
      width: 100%;
    }
    .table-content {
      width: 100%;
    }
    .page {
      width: 100%;
      margin-top: 10px;
      text-align: right;
    }
  }
}
</style>
