<template>
  <el-dialog
    title="新建分类树"
    :visible.sync="showDialog"
    :width="'540px'"
    :close-on-click-modal="closeOnClickModal"
    @open="onOpen"
    @close="close"
  >
    <el-form :model="treeForm" ref="treeForm">
      <el-form-item :rules="rules" label="分类树名称" prop="name" label-width="100px">
        <el-input v-model="treeForm.name" style="width:90%"></el-input>
      </el-form-item>
      <el-form-item label="复制分类树" prop="copyName" label-width="100px">
        <el-select
          v-model="treeForm.copyTreeId"
          clearable
          v-loading="treeLoading"
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgba(255, 255, 255, 0.8)"
          style="width:90%"
          placeholder="请选择分类树"
        >
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="save" :loading="loading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
import global from '@/global'
import uuid from '@/utils/uuid'
let currentBaseUrl = global.currentBaseUrl
let requestUrls = {
  getTreeType: currentBaseUrl + '/recordSort/trees',
  getTreeListBySortID: currentBaseUrl + '/recordSort/trees',
}
export default {
  props: {
    treeList: {
      type: Array,
      default: () => [],
    },
  },

  data() {
    return {
      rules: [
        { required: true, message: '名称不能为空' },
        {
          validator: (rule, value, callback) => {
            const errors = []
            value = value.trim()
            if (!value) {
              errors.push('名称不能为空')
            } else if ((this.treeList || []).some((tree) => tree.sortName === value)) {
              errors.push('分类名称重复')
            } else if (value.length > 10) {
              errors.push('树的名称不能超过10个字符')
            }
            callback(errors)
          },
        },
      ],
      showDialog: false,
      loading: false,
      treeLoading: false,
      options: [],
      treeForm: {
        name: '',
        copyTreeId: '',
      },
      closeOnClickModal: false,
    }
  },

  methods: {
    // 获取可复制树列表
    getTreeList() {
      this.treeLoading = true
      this.axios({
        method: 'get',
        url: requestUrls['getTreeType'],
        headers: { accessToken: this.$store.state.token },
      })
        .then((response) => {
          const { data } = response || {}
          const { data: trees } = data || {}
          return trees
        })
        .catch(() => this.treeList)
        .then((trees) => {
          this.treeLoading = false
          if (Array.isArray(trees)) {
            const options = this.options
            for (const tree of trees) {
              options.push({
                value: tree.sortID,
                label: tree.sortName,
              })
            }
          }
        })
    },

    // 获取拷贝树的节点
    getCopyTree() {
      const { copyTreeId } = this.treeForm
      if (copyTreeId) {
        return this.axios
          .get(`${requestUrls['getTreeListBySortID']}/${copyTreeId}`)
          .then((res) => {
            const nodes = res.data.data.children
            return Array.isArray(nodes) ? nodes : []
          })
          .catch(() => {
            throw '分类树复制失败，请稍后重试！'
          })
      }
      return Promise.resolve([])
    },

    // 提交数据
    submit(copied) {
      const { name } = this.treeForm
      // 发送请求保存数据
      return this.axios
        .post(
          requestUrls['getTreeType'],
          {
            sortName: name.trim(),
            parentSortID: '0',
            children: copied,
            sortID: uuid.getUUid(),
          },
          {
            headers: {
              'Content-Type': 'application/json',
              accessToken: this.$store.state.token,
            },
          }
        )
        .catch((response) => {
          const { data = {} } = response || {}
          throw data.message
        })
    },

    // 保存
    save() {
      this.$refs.treeForm.validate((valid) => {
        if (valid) {
          this.loading = true
          // 获取拷贝树的节点数据
          this.getCopyTree()
            .then((data) => {
              // 提交数据
              return this.submit(data)
            })
            .then((response) => {
              const { data } = response || {}
              const { code, message } = data || {}
              if (`${code}` !== '0') {
                throw message
              }
              this.loading = false
              this.$message.success('分类树添加成功！')
              this.$emit('addTreeReturn', true)
            })
            .catch((error) => {
              this.loading = false
              this.$message.error(error || '保存失败，请稍后重试！')
            })
        }
      })
    },

    onOpen() {
      this.getTreeList()
    },

    close() {
      this.$emit('addTreeReturn', false)
    },
  },
}
</script>
<style></style>
