<template>
  <div id="copyRecordingList">
    <el-dialog
      @open="onOpen"
      title="复制分类树进行算法分类"
      :visible.sync="copyTreeModal"
      @closed="closeCopyTreeModal"
      width="70%"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="training" id="training" style="height: 500px;">
        <div class="container">
          <div class="layout-box">
            <div class="copyTreeContent">
              <div class="layout-box">
                <div class="copyLeftTree" style="overflow: auto">
                  <el-tree
                    :data="copyLeftdata"
                    :props="defaultProps"
                    node-key="sortID"
                    :highlight-current="true"
                    :expand-on-click-node="false"
                    :default-checked-keys="defaultCheckedKeys"
                    default-expand-all
                    @node-click="leftNodeClick"
                  >
                    <span class="custom-tree-node" slot-scope="{ node, data }">
                      <span>{{ node.label }} ({{ data.count }})</span>
                    </span>
                  </el-tree>
                </div>
                <div class="copyRightContent">
                  <div class="layout-box">
                    <div class="copyTop">
                      <div class="copyAll">
                        <span>共{{ allAccount }}通录音</span>
                        <el-popover
                          v-model="visible2"
                          placement="bottom-end"
                          width="400"
                          style="float: right"
                          trigger="click"
                        >
                          <div style="max-height: 450px; overflow: auto">
                            <el-tree
                              :data="copyLeftdata"
                              :props="defaultProps"
                              :expand-on-click-node="false"
                              default-expand-all
                              @node-click="rightNodeClick"
                            ></el-tree>
                          </div>
                          <div class="dialog-footer" style="text-align: right;">
                            <el-button size="small" @click="moveCanel">取 消</el-button>
                            <el-button type="primary" size="small" @click="moveSure"
                              >确 定</el-button
                            >
                          </div>
                          <el-button slot="reference" size="small">移动至</el-button>
                        </el-popover>
                      </div>
                    </div>
                    <div class="copyTable" id="copyTable">
                      <el-collapse
                        v-model="activeNames"
                        style="height: 100%; overflow: auto;"
                      >
                        <el-checkbox-group
                          v-model="checkedRecordList"
                          style="height: 100%; overflow: auto;"
                          @change="checkboxChange"
                        >
                          <div
                            v-for="(item, index) in recordData"
                            :key="index"
                            style="margin: 15px 20px 20px 20px;border: 1px solid #E0E6ED;font-size: 14px;border-radius: 5px;background: #9ED9F3;"
                          >
                            <el-collapse-item>
                              <template slot="title">
                                <div
                                  class="nextDiv"
                                  style="padding: 0px 20px;background: #E0E6ED;width: 100%"
                                  @click="tabClick(index, $event)"
                                >
                                  <el-checkbox :label="item.callID"></el-checkbox>
                                  <span>编号:</span
                                  ><span
                                    @click="showDetail(item.callID, item.recordFileURL)"
                                    >&nbsp;{{ item.callID }}</span
                                  >
                                  <span style="margin-left: 25px;">录音时长:</span
                                  ><span>&nbsp;{{ commonUtil(item.callTime) }}</span>
                                  <span
                                    class="shi"
                                    style="float: right;color: #20A0FF;cursor: pointer;"
                                    >{{ item.expand ? '收起详情' : '展开详情' }}</span
                                  >
                                  <span
                                    style="font-size: 14px;float: right;color: #20A0FF;margin-right: 5px;"
                                    :class="[
                                      item.expand
                                        ? 'iconfont icon-zhanshixiangqing secondBox'
                                        : 'iconfont icon-zhanshixiangqing startBox',
                                    ]"
                                  ></span>
                                </div>
                                <div
                                  class="parentDic"
                                  style="padding: 0px 10px 0px 0px;background: #E0E6ED;"
                                  @click="tabClick(index, $event)"
                                ></div>
                              </template>
                              <div
                                @mouseenter="showPlay(index)"
                                @mouseleave="hidePlay(index)"
                                style="position: relative"
                              >
                                <div
                                  style="height: 70px; padding: 20px 20px 0px 20px; overflow: hidden;"
                                >
                                  {{ item.wholeContent.slice(0, 140) }}
                                </div>
                                <div
                                  class="play"
                                  v-show="item.isShowPlay"
                                  @click="showDetail(item.callID, item.recordFileURL)"
                                >
                                  <img src="../../../assets/img/u493.png" />
                                </div>
                              </div>
                            </el-collapse-item>
                          </div>
                        </el-checkbox-group>
                      </el-collapse>
                    </div>
                    <div class="copyBottom">
                      <div class="rightPage">
                        <el-pagination
                          small
                          @size-change="handleSizeChange"
                          @current-change="handleCurrentChange"
                          :current-page="currentPage"
                          :page-sizes="[20, 50, 100, 200]"
                          :page-size="tdPageSize"
                          layout="total, sizes, prev, pager, next, jumper"
                          :total="this.copyCount"
                        >
                        </el-pagination>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="copyTreeBottom">
              <div class="copyFootleft">注:最末级节点的录音数据总和建议在5000以上。</div>
              <div slot="footer" class="dialog-footer copyFootright">
                <el-button @click="closeCopyTreeModal">关 闭</el-button>
                <el-button type="primary" @click="save">确 定</el-button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </el-dialog>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        >
        </recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import global from '@/global'
import Qs from 'qs'
let currentBaseUrl = global.currentBaseUrl
import recordingplay from '../recordingPlay/recordingPlayResultScore.vue'
import bus from '../../common/bus.js'
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      isDelete: true,
      recordDialogVisible: false,
      firstTreeId: '',
      endTreeId: '',
      copyCount: 0,
      tdPageSize: 20,
      currentPage: 1,
      checkedRecordList: [],
      callIdsStr: '',
      visible2: false,
      activeNames: ['0'],
      allAccount: 0,
      recordData: [],
      defaultCheckedKeys: [],
      defaultProps: {
        children: 'children',
        label: 'sortName',
      },
      copyLeftdata: [],
      copyTreeModal: false,
    }
  },
  methods: {
    recordPlayCloseHandler() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    showDetail(callID, recordFileURL) {
      let obj = {}
      obj.from = 'audioClassification'
      obj.callId = callID
      obj.recordFileURL = recordFileURL
      obj.pageNumber = this.currentPage
      obj.pageSize = this.tdPageSize
      obj.sortID = this.sortIDPID
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 鼠标放到录音内容上时展示播放按钮
    showPlay(index) {
      this.recordData[index].isShowPlay = true
      this.$forceUpdate()
    },
    // 鼠标移出录音内容上时展示播放按钮
    hidePlay(index) {
      this.recordData[index].isShowPlay = false
      this.$forceUpdate()
    },
    /*
     * 勾选 复制分类树 里面的table数据
     * */
    checkboxChange(item) {
      let datas = item.join(',')
      this.callIdsStr = datas
    },
    onOpen() {
      this.setTreeAlg()
    },
    // 取消移动
    moveCanel() {
      this.visible2 = false
    },
    // 确定移动录音到其他节点
    moveSure() {
      this.visible2 = false
      if (this.endTreeId === '') {
        this.$message.error('请选择一个分类进行移动！')
      }
      if (this.callIdsStr === '') {
        this.$message.error('请勾选录音列表！')
        return
      }
      let params = {
        srcSortId: this.firstTreeId,
        tarSortId: this.endTreeId,
        callIdsStr: this.callIdsStr,
      }
      let url = currentBaseUrl + '/sortTreeAlgorithm/sortTreeAlg'
      this.axios.post(url, Qs.stringify(params)).then((response) => {
        if (response.data === true) {
          this.$message.success('操作成功！')
          this.getCopyTree()
          this.checkedRecordList = [] // 请求成功以后清楚所有选项
          this.callIdsStr = ''
        } else {
          this.$message.error('操作失败！')
        }
      })
    },
    getNewTreeList() {
      let params = {
        currentPage: this.currentPage,
        pageSize: this.tdPageSize,
      }
      this.axios
        .get(currentBaseUrl + '/sortTreeAlgorithm/sortTreeAlg/' + this.firstTreeId, {
          params,
        })
        .then((res) => {
          if (res.data) {
            let data = res.data.Data
            data.forEach((item) => {
              this.$set(item, 'isShowPlay', false)
            })
            this.recordData = data
            console.log(this.recordData)
            this.copyCount = res.data.Count
            this.allAccount = res.data.Count
          }
        })
        .catch(() => {})
    },
    // 获得复制分类树弹框左侧的tree
    getCopyTree() {
      this.axios
        .get(currentBaseUrl + '/sortTreeAlgorithm/sortTreeAlgWithCall/' + this.sortIDPID)
        .then((res) => {
          if (res.data.children.length > 0) {
            this.copyLeftdata = res.data.children
            this.firstTreeId = res.data.children[0].sortID
            this.defaultCheckedKeys[0] = this.firstTreeId
            if (this.firstTreeId !== '') {
              this.getSaveDeleteTree()
            }
            setTimeout(function() {
              $('.copyLeftTree .el-tree-node')
                .eq(0)
                .addClass('is-current') // 更改组件样式默认进来第一条展示底色
            }, 300)
          }
        })
        .catch(() => {})
    },
    // 算法弹框刚打开存储分类算法数据
    setTreeAlg() {
      let params = {
        callId: this.formParams.callId,
        callSTimeMin: this.formParams.callSTimeMin,
        callSTimeMax: this.formParams.callSTimeMax,
        labelIDs: this.formParams.labelIDs,
        pageNumber: this.formParams.pageNumber,
        pageSize: this.formParams.pageSize,
        sentimentLabel: this.formParams.sentimentLabel,
        sentimentRole: this.formParams.sentimentRole,
      }
      let url = currentBaseUrl + '/sortTreeAlgorithm/' + this.sortIDPID
      this.axios
        .get(url, {
          params: params,
          paramsSerializer: function(params) {
            return Qs.stringify(params, {
              arrayFormat: 'repeat',
            })
          },
        })
        .then((response) => {
          this.getCopyTree()
        })
    },
    closeCopyTreeModal() {
      if (this.isDelete === true) {
        // 删除算法分类树缓存
        this.deleteTreeAlg()
        this.copyTreeModal = false
        this.$emit('trainingClose', false)
      } else {
        this.copyTreeModal = false
        this.$emit('trainingClose', false)
      }
    },
    /*
     * 设置录音列表每页显示多少条数
     * 选择后录音列表更新显示数量
     * */
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
      this.tdPageSize = val
      this.currentPage = 1
      this.getSaveDeleteTree()
    },
    /*
     * 设置录音列表当前显示页数
     * 点击切换改页数，并且数据更新
     * */
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.currentPage = val
      this.getSaveDeleteTree()
    },
    // 算法弹框中点击左侧tree节点
    // 点击后录音列表相应变化
    leftNodeClick(node) {
      this.firstTreeId = node.sortID
      this.currentPage = 1
      if (this.firstTreeId !== '') {
        this.getSaveDeleteTree()
      }
      this.callIdsStr = ''
      $('.copyLeftTree .el-tree-node')
        .eq(0)
        .removeClass('is-current')
    },
    // 根据sortID 查询录音列表
    getSaveDeleteTree() {
      let params = {
        currentPage: this.currentPage,
        pageSize: this.tdPageSize,
      }
      this.axios
        .get(currentBaseUrl + '/sortTreeAlgorithm/sortTreeAlg/' + this.firstTreeId, {
          params,
        })
        .then((res) => {
          this.recordData = res.data.Data
          this.recordData.forEach((item) => {
            item.isShowPlay = false
          })
          this.copyCount = res.data.Count
          this.allAccount = res.data.Count
        })
        .catch(() => {})
    },
    /*
     * 复制分类树进行算法分类 里面的table展开和收起
     * */
    tabClick(index, flag) {
      this.num = index
      if (
        this.recordData[index].expand != null &&
        this.recordData[index].expand == true
      ) {
        this.recordData[index].expand = false
      } else {
        this.recordData[index].expand = true
      }
    },
    // 算法弹框中点击移动中的tree节点
    rightNodeClick(node) {
      this.endTreeId = node.sortID
    },
    /*
     * 将数字时间(333秒)转换为具体时间（12分钟）
     * */
    commonUtil(cellValue) {
      cellValue = cellValue / 1000
      let theTime = parseInt(cellValue) // 秒
      let theTime1 = 0 // 分
      let theTime2 = 0 // 小时
      if (theTime > 60) {
        theTime1 = parseInt(theTime / 60)
        theTime = parseInt(theTime % 60)
        if (theTime1 > 60) {
          theTime2 = parseInt(theTime1 / 60)
          theTime1 = parseInt(theTime1 % 60)
        }
      }
      let result = '' + parseInt(theTime) + '秒'
      if (theTime1 > 0) {
        result = '' + parseInt(theTime1) + '分' + result
      }
      if (theTime2 > 0) {
        result = '' + parseInt(theTime2) + '小时' + result
      }
      return result
    },
    // 调用分类树算法进行算法训练
    callSortTreeAlg() {
      let that = this
      this.axios
        .get(currentBaseUrl + '/sortTreeAlgorithm/callSortTreeAlg/' + this.sortIDPID)
        .then((res) => {
          if (res.data == true) {
            this.$message({
              type: 'success',
              message: '算法树开始训练！',
            })
            that.$emit('trainingData', false)
          }
        })
    },
    deleteTreeAlg() {
      this.axios
        .delete(currentBaseUrl + '/sortTreeAlgorithm/sortTreeAlg/' + this.sortIDPID)
        .then((response) => {})
        .catch(() => {})
    },
    save() {
      this.isDelete = false
      this.callSortTreeAlg()
      this.copyTreeModal = false
    },
  },
  props: {
    formParams: {
      type: Object,
    },
    sortIDPID: {
      type: String,
    },
    taskEndTime: {
      type: String,
    },
    taskBeginTime: {
      type: String,
    },
  },
  computed: {},
  watch: {
    loadData(val, oldval) {},
  },
}
</script>
<style lang="less" scoped>
.startBox {
  transition: all 0.5s;
}

.secondBox {
  transform: rotate(-180deg);
  transition: all 0.5s;
}

.training {
  height: 100%;
  width: 100%;
  z-index: 0;
  box-sizing: border-box;
  overflow: hidden;

  .container {
    overflow: hidden;
    height: 100%;
    position: relative;

    .copyRightContent {
      margin-left: 260px;
      height: 100%;
      position: relative;

      .copyBottom {
        position: absolute;
        bottom: 10px;
        overflow: hidden;
        height: 32px;
        width: 100%;
        text-align: right;
      }

      .copyTop {
        position: absolute;
        width: 100%;
        height: 45px;
        padding-left: 10px;
        line-height: 45px;

        .copyAll {
          float: left;
          width: 100%;

          span {
            float: left;
            display: inline-block;
          }

          button {
            float: right;
            margin-right: 20px;
            margin-top: 10px;
          }
        }
      }
    }
  }

  .copyTreeBottom {
    position: absolute;
    bottom: 0px;
    overflow: hidden;
    width: 100%;
    text-align: right;

    .copyFootleft {
      width: 50%;
      display: inline-block;
      text-align: left;
    }

    .copyFootright {
      width: 50%;
      display: inline-block;
    }
  }

  .copyTable {
    padding-top: 50px;
    padding-bottom: 60px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }

  .copyLeftTree {
    float: left;
    width: 260px;
    height: 100%;
    position: relative;
    border-right: 1px solid #e4e4e4;
  }

  .copyTreeContent {
    position: absolute;
    top: 10px;
    left: 0;
    bottom: 60px;
    width: 100%;
  }

  .layout-box {
    overflow: hidden;
    height: 100%;
    position: relative;
  }
}
</style>
<style lang="less">
#training .el-collapse-item__arrow {
  display: none !important;
}

#copyRecordingList .recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}

#training {
  #copyTable {
    .el-checkbox__label {
      display: none !important;
    }
  }

  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;

      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }

    .el-dialog__header {
      display: none;
    }

    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }

  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }

  .play {
    position: absolute;
    height: 120px;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 10;
    background: rgba(00, 00, 00, 0.4);
    text-align: center;
    line-height: 145px;

    img {
      display: inline;
      width: 51px;
      height: 51px;
    }
  }

  .el-collapse-item__header {
    height: auto !important;
    background: #e0e6ed;
  }
}
</style>
