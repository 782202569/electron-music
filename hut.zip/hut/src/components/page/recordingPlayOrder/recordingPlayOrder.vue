<!--订单录音模版-->
<template>
  <div class="recordingPlayContainer">
    <div class="controller_btns">
      <div class="controller_btn" @click="minimizePage">
        <i class="el-icon-minus"></i>
      </div>
      <div class="controller_btn" @click="closePage"><i class="el-icon-close"></i></div>
    </div>
    <el-row>
      <el-col :span="10">
        <div class="leftContainer">
          <div class="info">
            <el-tabs type="border-card">
              <el-tab-pane label="基本信息">
                <div class="infoContent">
                  <div class="info_item">
                    <label>录音编号:</label>
                    <span>{{ esResultModel.callId }}</span>
                  </div>
                  <div class="info_item">
                    <label>坐席工号:</label>
                    <span>{{ esResultModel.seatNo }}</span>
                  </div>
                  <div class="info_item">
                    <label>坐席姓名:</label>
                    <span>{{ esResultModel.seatName }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属角色:</label>
                    <span>{{
                      aclOperVo.roleNames != null ? aclOperVo.roleNames.join(',') : ''
                    }}</span>
                  </div>
                  <div class="info_item">
                    <label>所属部门:</label>
                    <span>{{ aclOperVo.deptName }}</span>
                  </div>
                  <div class="info_item">
                    <label>坐席星级:</label>
                    <span>
                      <el-rate
                        v-model="esResultModel.seatStar"
                        disabled
                        text-color="#ff9900"
                      >
                      </el-rate
                    ></span>
                  </div>
                  <div class="info_item agentLabel">
                    <label>坐席标签:</label>
                    <el-tag
                      :type="color[index % 4]"
                      v-if="item.trim()"
                      v-for="(item, index) in serviceLabels"
                      :key="item"
                      >{{ item }}
                    </el-tag>
                    <el-tag v-if="!serviceLabels || serviceLabels.length == 0"
                      >暂无标签</el-tag
                    >
                  </div>
                </div>
              </el-tab-pane>
              <el-tab-pane label="语音特征">
                <div class="infoContent">
                  <div class="info_item">
                    <label>静默次数:</label>
                    <span>{{ esResultModel.silenceCount }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默时长:</label>
                    <span>{{ esResultModel.silenceLong / 1000 || 0 }}</span>
                  </div>
                  <div class="info_item">
                    <label>静默占比:</label>
                    <span
                      >{{ Math.round(esResultModel.silencePer * 1000) / 10 || 0 }}%</span
                    >
                  </div>
                  <div class="info_item">
                    <label>语音重叠次数:</label>
                    <span>{{ esResultModel.overLap }}</span>
                  </div>
                  <div class="info_item">
                    <label>情绪分值:</label>
                    <span>{{ esResultModel.moodScore }}</span>
                  </div>
                  <div class="info_item">
                    <label>平均语速:</label>
                    <span>{{ Math.round(esResultModel.avgSpeed * 100) / 100 }}字/秒</span>
                  </div>
                  <div class="info_item">
                    <label>最快语速:</label>
                    <span>{{ Math.round(esResultModel.maxSpeed * 100) / 100 }}字/秒</span>
                  </div>
                  <div class="info_item">
                    <label>最长静默:</label>
                    <span>{{ Math.round(esResultModel.maxSilenceLong / 10) / 100 }}</span>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
          <div class="dialog" @mousewheel="test">
            <ul>
              <li
                :class="classes(item.role, item.startTime, item.endTime)"
                v-for="item in playInfoVosList"
                :key="item.startTime"
              >
                <div v-if="item.role == '1'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/seat.png"
                  />
                </div>
                <div v-if="item.role == '2'">
                  <img
                    style="width:50px;height:50px;border-radius:25px"
                    src="../../../assets/img/customer.png"
                  />
                </div>
                <div
                  class="dialog-content"
                  v-if="item.role != 'UNK'"
                  @click="playClip(item.startTime)"
                >
                  {{ item.text }}
                </div>
                <div
                  class="content-tag"
                  v-if="item.role == 1 && isShowSpeedFlag(item.speed)"
                >
                  <el-tag :type="item.speed | dealSpeedType(minSpeed, maxSpeed)">
                    {{ item.speed | dealSpeed(minSpeed, maxSpeed) }}
                  </el-tag>
                </div>
                <div v-if="item.role == 'UNK'" class="UNK_text">
                  <el-row>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                    <el-col :span="4">{{ item.text }}</el-col>
                    <el-col :span="10">
                      <div class="line"></div>
                    </el-col>
                  </el-row>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </el-col>
      <el-col :span="14">
        <div class="rightContainer">
          <div class="tabs">
            <el-tabs type="card" v-model="activeName">
              <el-tab-pane
                label="质检得分-提交人"
                v-if="showQualityScoreSubmitter"
                name="orderQualityScoreSubmitter"
              >
                <orderQualityScoreSubmitter
                  :parentModel="parentModel"
                  :playInfoVosList="playInfoVosList"
                  @showhighlightscore="showhighlightscore"
                  @clickhighlightkeys="playOccurrence_intelligent"
                ></orderQualityScoreSubmitter>
              </el-tab-pane>
              <el-tab-pane
                label="初检评分-提交人"
                v-if="showQualityScoreS"
                name="qualityScoreS"
              >
                <qualityScoreS
                  :parentModel="parentModel"
                  :playInfoVosList="playInfoVosList"
                  @showhighlightscore="showhighlightscore"
                  @clickhighlightkeys="playOccurrence_intelligent"
                ></qualityScoreS>
              </el-tab-pane>
              <el-tab-pane
                label="初检评分-拨打人"
                v-if="showQualityScoreC"
                name="qualityScoreC"
              >
                <qualityScoreC
                  :parentModel="parentModel"
                  :playInfoVosList="playInfoVosList"
                  @showhighlightscore="showhighlightscore"
                  @clickhighlightkeys="playOccurrence_intelligent"
                ></qualityScoreC>
              </el-tab-pane>
              <el-tab-pane
                label="复检评分-提交人"
                v-if="showSecQualityScore"
                name="secQualityScore"
              >
                <secQualityScore
                  :parentModel="parentModel"
                  :playInfoVosList="playInfoVosList"
                  @showhighlightscore="showhighlightscore"
                  @clickhighlightkeys="playOccurrence_intelligent"
                ></secQualityScore>
              </el-tab-pane>
              <el-tab-pane
                label="复检评分-拨打人"
                v-if="showRecSecQualityScore"
                name="secRecQualityScore"
              >
                <secRecQualityScore
                  :parentModel="parentModel"
                  :playInfoVosList="playInfoVosList"
                  @showhighlightscore="showhighlightscore"
                  @clickhighlightkeys="playOccurrence_intelligent"
                ></secRecQualityScore>
              </el-tab-pane>
              <el-tab-pane
                label="初检得分-提交人"
                v-if="showQualityScoreResultS"
                name="qualityScoreResultS"
              >
                <qualityScoreS
                  :parentModel="parentModel"
                  :playInfoVosList="playInfoVosList"
                  @showhighlightscore="showhighlightscore"
                  @clickhighlightkeys="playOccurrence_intelligent"
                ></qualityScoreS>
              </el-tab-pane>
              <el-tab-pane
                label="初检得分-拨打人"
                v-if="showQualityScoreResultC"
                name="qualityScoreResultC"
              >
                <qualityScoreC
                  :parentModel="parentModel"
                  :playInfoVosList="playInfoVosList"
                  @showhighlightscore="showhighlightscore"
                  @clickhighlightkeys="playOccurrence_intelligent"
                ></qualityScoreC>
              </el-tab-pane>
              <el-tab-pane
                label="质检得分-拨打人"
                v-if="showQualityScoreCaller"
                name="orderQualityScoreCaller"
              >
                <orderQualityScoreCaller
                  :parentModel="parentModel"
                  :playInfoVosList="playInfoVosList"
                  @showhighlightscore="showhighlightscore"
                  @clickhighlightkeys="playOccurrence_intelligent"
                ></orderQualityScoreCaller>
              </el-tab-pane>
              <el-tab-pane label="评分轨迹" v-if="showOrderScoreContrail">
                <orderScoreContrail :parentModel="parentModel"></orderScoreContrail>
              </el-tab-pane>
              <el-tab-pane label="管理者信息" v-if="showadmin">
                <orderadmin :parentModel="parentModel"></orderadmin>
              </el-tab-pane>
              <el-tab-pane label="订单详情" v-if="showAppealOrderInfo">
                <appealOrderInfo :parentModel="parentModel"></appealOrderInfo>
              </el-tab-pane>
              <!-- <el-tab-pane label="客户信息" v-if="showkehu">
                <orderkehuinfo :parentModel="parentModel"></orderkehuinfo>
              </el-tab-pane> -->
              <el-tab-pane label="订单信息" v-if="showOrderDeatil" name="orderDetail">
                <orderDetail
                  :parentModel="parentModel"
                  @childMessage="activeNameMethod"
                  @jumpToCall="callQualityScore"
                  @recordMessage="jumpRecord"
                ></orderDetail>
              </el-tab-pane>
              <el-tab-pane
                label="客户信息"
                v-if="showCustomerDetail"
                name="customerDetail"
              >
                <customerDetail
                  :parentModel="parentModel"
                  :custormInfo="custormInfo"
                ></customerDetail>
              </el-tab-pane>
              <el-tab-pane label="校准评分" v-if="showOrderQaCalibration">
                <orderQaCalibration :parentModel="parentModel"></orderQaCalibration>
              </el-tab-pane>
              <el-tab-pane label="标准分数" v-if="showorderQaCalibrationScore">
                <orderQaCalibrationScore
                  :parentModel="parentModel"
                ></orderQaCalibrationScore>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import $ from 'jquery'
import orderkehuinfo from './play/orderCustomInfo.vue' // 引入模块
import orderadmin from './play/orderAdmin.vue'
import customerDetail from './play/customerDetail.vue'
import orderDetail from './play/orderDetail.vue'
import qualityScoreS from './play/orderInitalQualityScoreS.vue'
import qualityScoreC from './play/orderInitalQualityScoreC.vue'
import secQualityScore from './play/orderSecQaScore.vue'
import secRecQualityScore from './play/orderRecordSecQaScore.vue'
import orderQualityScoreSubmitter from './play/orderQualityScoreSubmitter.vue'
import orderQualityScoreCaller from './play/orderQualityScoreCaller.vue'
import orderQaCalibration from './play/orderQaCalibration.vue'
import orderQaCalibrationScore from './play/orderQaCalibrationScore.vue'
import appealOrderInfo from './play/orderInfo.vue'
import orderScoreContrail from './play/orderScoreContrail.vue' // 评分轨迹
import qs from 'qs'
import global from '../../../global.js'
import formatdate from '../../../utils/formatdate.js'
let qualityUrl = global.qualityUrl
let currentBaseUrl = global.currentBaseUrl

export default {
  components: {
    orderkehuinfo, // 模块组件化
    orderadmin,
    customerDetail,
    orderDetail,
    qualityScoreS,
    qualityScoreC,
    secQualityScore,
    secRecQualityScore,
    orderQualityScoreSubmitter, // 质检得分提交人
    orderQualityScoreCaller, // 质检得分拨打人
    appealOrderInfo, // 申诉订单详情（入口）
    orderQaCalibration,
    orderQaCalibrationScore,
    orderScoreContrail, // 录音轨迹
  },
  data() {
    return {
      form: {
        code: '',
        time: '',
        statu: '',
        submitMan: '',
      },
      playInfoVosList: [], // 通话内容列表
      aclOperVo: {},
      esResultModel: {},
      serviceLabels: [], // 坐席标签
      tableData: [],
      parentModel: {},
      showadmin: false, // 管理者信息
      showOrderDeatil: true,
      showCustomerDetail: true,
      showQualityScoreS: false,
      showQualityScoreC: false,
      showSecQualityScore: false,
      showQualityScoreSubmitter: false,
      showQualityScoreCaller: false,
      showQualityScoreResultS: false,
      showQualityScoreResultC: false,
      showRecSecQualityScore: false,
      showAppealOrderInfo: false,
      showOrderScoreContrail: false,
      showOrderQaCalibration: false, //  校准评分
      showorderQaCalibrationScore: false, // 校准评分
      activeName: 'orderDetail',
      activeTab: 0,
      color: ['success', 'warning', 'danger', 'gray'],
      keys: [], // 其他质检评分的命中关键词
      // 智能筛选高亮词
      focusWordIntell: {
        keyword: '',
        clickIndex: 0,
        fullScriptRole: '',
        targetTimeStart: '',
        targetTimeEnd: '',
      },
      // 智能筛选命中词
      keywordCollection: new Set(),
      keywords: [],
      custormInfo: {},
    }
  },
  created() {
    this.getCallList(this.obj.orderNo)
    this.setTab(this.obj)
  },
  computed: {
    keywordsHigh() {
      if (this.$store.state.keywordsHigh == null) {
        return ''
      } else {
        return this.$store.state.keywordsHigh.keywords
      }
    },
    pageId() {
      return this.$store.state.recordingPlayPage.pageId
    },
    fromPage() {
      return this.$store.state.recordingPlayPage.fromPage
    },
    callId() {
      return this.$store.state.recordingPlayPage.callId
    },
    orderFlag() {
      return this.$store.state.recordingPlayPage.orderFlag
    },
    obj() {
      return this.$store.state.recordingPlayPage
    },
  },
  methods: {
    init: function() {
      this.getCallList(this.obj.orderNo) // 获取录音文本信息（对话内容）
      this.setTab(this.obj)
    },
    showhighlightscore(keys) {
      console.log('keys:' + keys)
      this.keys = keys
    },
    test() {
      // 停止正在进行的动画  减少卡顿感
      $('.dialog').stop(true, false)
      if (window.myinterVal) {
        return
      } else {
        window.myinterVal = 5
      }
      setTimeout(function() {
        window.myinterVal = 0
      }, 5000)
      // 清除计时任务
      // 3秒后重新
    },
    activeNameMethod: function(data) {
      console.log(data)
      if (
        this.obj.pageId !== 'samplepollOrder' &&
        this.obj.pageId !== 'artificialSampleOrder'
      ) {
        this.activeName = data
      }
    },
    callQualityScore: function(data) {
      console.log(data)
      console.log(this.obj.pageId)
      if (
        this.obj.pageId !== 'samplepollOrder' &&
        this.obj.pageId !== 'artificialSampleOrder'
      ) {
        this.getPlayInfo(data.callId)
        let parentModel = {}
        parentModel.callId = data.callId
        parentModel.seatName = data.seatName
        parentModel.seatNo = data.seatNo
        parentModel.orderNo = this.parentModel.orderNo
        parentModel.objectId = this.parentModel.orderNo
        parentModel.scoreClass = this.parentModel.scoreClass
        parentModel.qaScoreType = this.parentModel.qaScoreType
        parentModel.fromUrl = this.parentModel.fromUrl
        parentModel.submiterName = this.parentModel.submiterName
        parentModel.submiter = this.parentModel.submiter
        this.parentModel = parentModel
        if (data.qaScoreType == 1) {
          if (this.obj.pageId == 'taskOrderMonitor') {
            this.showQualityScoreResultC = true
            this.activeName = 'qualityScoreResultC'
          } else if (this.obj.pageId == 'reInspectionSamplingOrder') {
            this.showQualityScoreCaller = true
            this.activeName = 'orderQualityScoreCaller'
          } else {
            this.showQualityScoreC = true
            this.activeName = 'qualityScoreC'
          }
        } else if (data.qaScoreType == 2) {
          this.showRecSecQualityScore = true
          this.activeName = 'secRecQualityScore'
        }
      }
    },
    jumpRecord: function(data) {
      this.getPlayInfo(data)
    },
    // 控制tab页显示
    setTab(obj) {
      let parentModel = obj
      this.parentModel = parentModel
      this.activeName = 'orderDetail'
      if (obj.pageId === 'caseManage_order') {
        this.showSecQualityScore = false
      }
      if (obj.pageId === 'myQaTasksOrder') {
        // 初检评分-提交人
        this.showQualityScoreS = true
        //  this.showQualityScoreC = true
        this.activeName = 'qualityScoreS'
        this.showCustomerDetail = true
        this.showOrderScoreContrail = true
        let parentModel = {}
        parentModel.orderNo = obj.orderNo
        parentModel.objectId = obj.orderNo
        parentModel.scoreClass = 2
        parentModel.qaScoreType = 1
        parentModel.fromUrl = obj.pageId
        parentModel.submiterName = obj.submiterName
        parentModel.submiter = obj.submiter
        //  parentModel.callId = '0843116'
        this.parentModel = parentModel
      }
      if (obj.pageId === 'sysAutoScoringInCallOrderResult') {
        // 系统自动评分
        this.showQualityScoreSubmitter = true
        //  this.showQualityScoreC = true
        this.activeName = 'orderQualityScoreSubmitter'
        this.showCustomerDetail = true
        this.showOrderScoreContrail = true
        let parentModel = {}
        parentModel.orderNo = obj.orderNo
        parentModel.objectId = obj.orderNo
        parentModel.scoreClass = 2
        parentModel.qaScoreType = 1
        parentModel.fromUrl = obj.pageId
        parentModel.submiterName = obj.submiterName
        parentModel.submiter = obj.submiter
        //  parentModel.callId = '0843116'
        this.parentModel = parentModel
      }
      if (obj.pageId === 'taskOrderMonitor') {
        // 订单质检任务监控
        let qaScoreType = obj.qaScoreType
        console.log('qaScoreType' + qaScoreType)
        if (qaScoreType === 1) {
          console.log('初检')
          this.showQualityScoreS = true
          this.activeName = 'qualityScoreS'
        } else {
          console.log('复检')
          this.showSecQualityScore = true
          this.showQualityScoreResultS = true
          this.activeName = 'secQualityScore'
        }
        this.showCustomerDetail = true
        this.showOrderScoreContrail = true
        let parentModel = {}
        parentModel.orderNo = obj.orderNo
        parentModel.objectId = obj.orderNo
        parentModel.scoreClass = 2
        parentModel.qaScoreType = qaScoreType
        parentModel.fromUrl = obj.pageId
        parentModel.submiterName = obj.submiterName
        parentModel.submiter = obj.submiter
        //  parentModel.callId = '0843116'
        this.parentModel = parentModel
      }
      if (obj.pageId === 'orderSecQualityScore') {
        this.activeName = 'secQualityScore'
        this.showSecQualityScore = true
        this.showQualityScoreResultS = true
        this.showCustomerDetail = true
        this.showOrderScoreContrail = true
        let parentModel = {}
        parentModel.orderNo = obj.orderNo
        parentModel.qaScoreType = 2
        parentModel.fromUrl = obj.pageId
        parentModel.submiterName = obj.submiterName
        parentModel.objectId = obj.orderNo
        parentModel.scoreClass = 2
        parentModel.submiter = obj.submiter
        this.parentModel = parentModel
      }
      if (obj.pageId === 'samplepollOrder') {
        // 样本池(订单)
        this.showCustomerDetail = true
        let parentModel = {}
        parentModel.orderNo = obj.orderNo
        parentModel.fromUrl = obj.pageId
        this.parentModel = parentModel
      }
      if (obj.pageId === 'artificialSampleOrder') {
        // 快速抽样(订单)
        this.showCustomerDetail = true
        let parentModel = {}
        parentModel.orderNo = obj.orderNo
        parentModel.fromUrl = obj.pageId
        this.parentModel = parentModel
      }
      if (obj.pageId === 'reInspectionSamplingOrder') {
        // 复检抽样(订单)
        this.activeName = 'qualityScoreS'
        this.showCustomerDetail = true
        let parentModel = {}
        parentModel.qaScoreType = 1
        parentModel.orderNo = obj.orderNo
        parentModel.objectId = obj.orderNo
        parentModel.scoreClass = 2
        parentModel.fromUrl = obj.pageId
        parentModel.submiterName = obj.submiterName
        parentModel.submiter = obj.submiter
        this.parentModel = parentModel
        this.showQualityScoreS = true // 质检评分
      }
      if (obj.pageId === 'appealOrderInfo') {
        // 申诉订单详情
        this.showAppealOrderInfo = true
        this.showCustomerDetail = true
        this.parentModel = obj
      }
      if (obj.pageId === 'qaCalibrationOrder') {
        let parentModel = {}
        parentModel.callId = obj.callId
        this.parentModel = parentModel
        this.showOrderQaCalibration = true
        this.showorderQaCalibrationScore = true
        this.showOrderDeatil = true
        this.showCustomerDetail = true
      }
      if (obj.pageId === 'scoreResultInfoOrder') {
        // 质检结果查看
        this.activeName = 'orderQualityScoreSubmitter'
        this.showCustomerDetail = true
        this.showQualityScoreSubmitter = true
        let parentModel = {}
        parentModel.orderNo = obj.orderNo
        parentModel.objectId = obj.orderNo
        parentModel.fromUrl = obj.pageId
        parentModel.submiterName = obj.submiterName
        parentModel.submiter = obj.submiter
        parentModel.scoreClass = 2
        parentModel.finalScoreInfo = 1
        parentModel.qaScoreType = ''
        this.parentModel = parentModel
      }
    },
    getCallList: function(orderNo) {
      this.axios
        .post(qualityUrl + '/order/getRecords.do?orderNo=' + orderNo)
        .then((res) => {
          if (res.data instanceof Array) {
            this.esResultModel = res.data[0]
            this.getPlayInfo(res.data[0].callId)
            // 添加提交人是否已质检判断
            let obj = {}
            obj.callId = res.data[0].callId
            obj.orderFlag = 'order'
            this.$store.commit('setOrderRecordingPlayPage', obj)
            this.custormInfo = res.data[0]
            this.custormInfo.callSTime = this.timeFormatter(this.custormInfo.callSTime)
            this.custormInfo.callETime = this.timeFormatter(this.custormInfo.callETime)
            this.tableData = res.data
            this.getPlayInfo(this.tableData[0].callId) // 获取录音文本信息（对话内容）
          }
        })
    },
    timeFormat: function(row, column) {
      let date = row[column.property]
      if (!date) {
        return ''
      }
      let fdate = formatdate.formatDate(parseInt(date))
      console.log(fdate)
      return fdate
    },
    timeFormatter: function(date) {
      let fdate = formatdate.formatDate(parseInt(date))
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    hightlightContentIntell(word) {
      this.focusWordIntell = word
    },
    // 获取开始时间和结束时间，保存到vuex中
    playClip(startTime, endTime) {
      let playInfo = {}
      playInfo.timeSection = [startTime, endTime]
      this.$store.commit('setPlayerInfo', playInfo)
    },
    playOccurrence_intelligent(keywordItem) {
      // console.log(keywordItem)
      // 单独高亮显示本次关键词的结果
      this.hightlightContentIntell(keywordItem)
      let self = this
      let selectedMsg = null // 当前消息
      let selectedIndex = 0 // 当前匹配的消息数
      let pipeiMsgCount = 0 // 可匹配的消息总数

      // 1.获取此关键字所有的消息数
      self.playInfoVosList.forEach((item) => {
        if (
          parseInt(item.startTime) <= parseInt(keywordItem.targetTimeEnd) &&
          parseInt(item.endTime) >= parseInt(keywordItem.targetTimeStart)
        ) {
          if (parseInt(keywordItem.fullScriptRole) === 1) {
            if (item.role == '2' && item.text.indexOf(keywordItem.keyword) >= 0) {
              pipeiMsgCount++
            }
          } else if (parseInt(keywordItem.fullScriptRole) === 2) {
            if (item.role == '1' && item.text.indexOf(keywordItem.keyword) >= 0) {
              pipeiMsgCount++
            }
          } else {
            if (item.text.indexOf(keywordItem.keyword) >= 0) {
              pipeiMsgCount++
            }
          }
        }
      })

      // 2.获取已选中的消息
      for (let i = 0; i < self.playInfoVosList.length; i++) {
        let item = self.playInfoVosList[i]
        if (
          parseInt(item.startTime) <= parseInt(keywordItem.targetTimeEnd) &&
          parseInt(item.endTime) >= parseInt(keywordItem.targetTimeStart)
        ) {
          if (parseInt(keywordItem.fullScriptRole) === 1) {
            if (item.role == '2' && item.text.indexOf(keywordItem.keyword) >= 0) {
              if (selectedIndex == keywordItem.clickIndex) {
                keywordItem.clickIndex++
                selectedMsg = item
                break
              }
              selectedIndex++
            }
          } else if (parseInt(keywordItem.fullScriptRole) === 2) {
            if (item.role == '1' && item.text.indexOf(keywordItem.keyword) >= 0) {
              if (selectedIndex == keywordItem.clickIndex) {
                keywordItem.clickIndex++
                selectedMsg = item
                break
              }
              selectedIndex++
            }
          } else {
            if (item.text.indexOf(keywordItem.keyword) >= 0) {
              if (selectedIndex == keywordItem.clickIndex) {
                keywordItem.clickIndex++
                selectedMsg = item
                break
              }
              selectedIndex++
            }
          }
        }
      }

      // 3.重制点击数
      if (keywordItem.clickIndex == pipeiMsgCount) {
        keywordItem.clickIndex = 0
      }
      if (selectedMsg != null) {
        self.playClip(selectedMsg.startTime)
      }
    },
    // 最小化页面
    minimizePage() {
      this.volumeControl = false
      let playInfo = {}
      playInfo.isMaximization = false
      let taskId = this.$store.state.returnVisitConfig.taskId
      let projectId = this.$store.state.returnVisitConfig.projectId
      let matchRecordCount = this.$store.state.returnVisitConfig.matchRecordCount
      let allRecordCount = this.$store.state.returnVisitConfig.allRecordCount
      let matchRatio = this.$store.state.returnVisitConfig.matchRatio
      let obj = {
        taskId: taskId,
        showTaskResult: true,
        showDetailPage: true,
        projectId: projectId,
        matchRecordCount: matchRecordCount,
        allRecordCount: allRecordCount,
        matchRatio: matchRatio,
      }
      this.$store.commit('setTaskResult', obj)
      this.$store.commit('setPlayerInfo', playInfo)
      this.$emit('onminimize', playInfo)
    },
    getPlayInfo(callId) {
      let _this = this
      let url = currentBaseUrl + '/speechFeature/getOrderPlayInfo.do'
      let params = {}
      params.callId = callId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.serviceLabels = response.data.serviceLabels
            _this.playInfoVosList = response.data.playInfoVosList
            _this.insertSort(_this.playInfoVosList)
            _this.times = []
            _this.playInfoVosList.forEach(function(item) {
              _this.times.push(item.startTime)
              _this.times.push(item.endTime)
            })
            _this.$store.commit('setVoiceDetal', _this.playInfoVosList)
            _this.voiceTotalTime = response.data.voiceTotalTime
            _this.esResultModel = response.data.esResultModel
            _this.aclOperVo = response.data.aclOperVo
            _this.minSpeed = response.data.minSpeead
            _this.maxSpeed = response.data.maxSpeed
            let playInfo = {}
            playInfo.voiceTotalTime = _this.voiceTotalTime
            _this.$nextTick(function() {
              _this.$store.commit('setPlayerInfo', playInfo)
              _this.hightlightContent(_this.keywordsHigh) // 获取高亮文本
            })
          } else {
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '录音信息获取失败',
          })
        })
    },
    // 高亮关键词
    hightlightContent(word) {
      console.log('word:' + word)
      this.focusWord = word
    },
    // 智能筛选页面刚刚进来的时候要把所有符合条件的关键词都标红
    highlightWordAll(val) {
      let selector = ''
      if (parseInt(val.fullScriptRole) === 2) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 1) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let eles = document.querySelectorAll(selector)
      if (!eles || eles.length === 0) {
        return
      } else {
        eles.forEach(function(item) {
          let className = item.parentElement.className.split(' ')
          let startTime = parseInt(className[1].substr(1).trim())
          let endTime = parseInt(className[2].substr(1).trim())
          if (!(startTime <= val.targetTimeEnd && endTime >= val.targetTimeStart)) {
            return
          }
          if (item.innerHTML.indexOf(val.keyword) != -1) {
            item.innerHTML = item.innerHTML.replace(
              new RegExp(val.keyword, 'gm'),
              '<span style="color: red">' + val.keyword + '</span>'
            )
          }
        })
      }
    },
    isShowSpeedFlag(speed) {
      if (speed > this.maxSpeed || speed < this.minSpeed) {
        return true
      } else {
        return false
      }
    },
    // 智能筛选命中词点击
    highlightWordIntell(val, oldval) {
      let selector = ''
      if (parseInt(val.fullScriptRole) === 2) {
        selector = 'div.dialog ul li.agent_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 1) {
        selector = 'div.dialog ul li.custom_content .dialog-content'
      } else if (parseInt(val.fullScriptRole) === 0) {
        selector = 'div.dialog ul li .dialog-content'
      } else {
        // 其他值时都默认是全部
        selector = 'div.dialog ul li .dialog-content'
      }
      let _this = this
      let eles = document.querySelectorAll(selector)
      if (!eles || eles.length === 0) {
        return
      } else {
        // 第一次点击的时候先把全部的关键词都替换掉
        if (_this.isFirst) {
          console.log(_this.keywordCollection)
          document
            .querySelectorAll('div.dialog ul li .dialog-content')
            .forEach(function(item) {
              for (let i of _this.keywordCollection) {
                if (item.innerHTML.indexOf(i.keyword) != -1) {
                  // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, i.keyword)
                  item.innerHTML = item.innerHTML
                    .replace(/<span style="color: red">/g, '')
                    .replace(/<\/span>/g, '')
                }
              }
            })
          _this.isFirst = false
        } else {
          // 如果不是第一次点击关键词的时候把上次的关键词红色去除
          if (oldval) {
            // 当要高亮显示的文字变化时，先清空原来所有的高亮
            document
              .querySelectorAll('div.dialog ul li .dialog-content')
              .forEach(function(item) {
                // item.innerHTML = item.innerHTML.replace(/<span(.*)>/, oldval.keyword)
                item.innerHTML = item.innerHTML
                  .replace(/<span style="color: red">/g, '')
                  .replace(/<\/span>/g, '')
              })
          }
        }
        eles.forEach(function(item) {
          let className = item.parentElement.className.split(' ')
          let startTime = parseInt(className[1].substr(1).trim())
          let endTime = parseInt(className[2].substr(1).trim())
          if (!(startTime <= val.targetTimeEnd && endTime >= val.targetTimeStart)) {
            return
          }
          if (item.innerHTML.indexOf(val.keyword) != -1) {
            item.innerHTML = item.innerHTML.replace(
              new RegExp(val.keyword, 'gm'),
              '<span style="color: red">' + val.keyword + '</span>'
            )
          }
        })
      }
    },
    // 对话列表的class
    classes(role, startTime, endTime) {
      let active = ''
      if (+this.currentClass === +startTime || +this.currentClass === +endTime) {
        active = 'currentClass'
      }
      if (role == 2) {
        return 'custom_content _' + startTime + ' _' + endTime + ' ' + active
      } else if (role == 1) {
        return 'agent_content _' + startTime + ' _' + endTime + ' ' + active
      } else {
        return 'UNK _' + startTime
      }
    },
    insertSort(arr) {
      if (Object.prototype.toString.call(arr) !== '[object Array]') {
        return false
      }
      for (let i = 1; i < arr.length; i++) {
        let j = i
        let temp = arr[i]
        while (j > 0 && parseInt(temp.startTime) < parseInt(arr[j - 1].startTime)) {
          arr[j] = arr[--j]
        }
        arr[j] = temp
      }
    },
    // 关闭页面
    closePage() {
      let _this = this
      this.$confirm('关闭界面将停止录音播放，确定关闭么', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          // let url = _this.pageId || 'home'
          let taskId = _this.$store.state.returnVisitConfig.taskId
          let projectId = _this.$store.state.returnVisitConfig.projectId
          let matchRecordCount = _this.$store.state.returnVisitConfig.matchRecordCount
          let allRecordCount = _this.$store.state.returnVisitConfig.allRecordCount
          let matchRatio = _this.$store.state.returnVisitConfig.matchRatio
          let obj = {
            taskId: taskId,
            showTaskResult: true,
            showDetailPage: true,
            projectId: projectId,
            matchRecordCount: matchRecordCount,
            allRecordCount: allRecordCount,
            matchRatio: matchRatio,
          }
          _this.$store.commit('setTaskResult', obj)
          _this.$store.commit('setPlayerInfo', null)
          _this.focusWord = ''
          _this.keywords = []
          _this.keys = []
          _this.parentModel = {}
          this.$emit('onclose')
        })
        .catch(() => {})
    },
  },
  watch: {
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.orderNo != undefined && newValue.callId == undefined) {
          this.showQualityScoreC = false
          this.showQualityScoreCaller = false
          this.showQualityScoreResultC = false
          this.showRecSecQualityScore = false
        }
      },
      deep: true,
    },
    currentTime(val) {
      this.currentClass = this.findCurrentMessage(val - 250)
      this.scrollDialog(this.currentClass)
    },
    focusWord(val, oldval) {
      this.highlightWord(val, oldval, '0')
    },
    focusWordIntell: {
      handler: function(val, oldval) {
        this.highlightWordIntell(val, oldval)
      },
      deep: true, // 对象内部的属性监听，也叫深度监听
    },
    playInfoVosList() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.fromUrl == 'task_result' && this.keywords && this.keywords.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keywords.forEach(function(item, index) {
            if (item.keywordContext.indexOf('NOT') == -1) {
              let temp = item.keywordContext.replace(/([\\(\\)])*(AND)*(OR)*/g, '')
              temp.split(' ').forEach(function(i) {
                if (i) {
                  // self.highlightWord(i, '', item.fullScriptRole)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      }
    },
    keywords() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.fromUrl == 'task_result' && this.keywords && this.keywords.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keywords.forEach(function(item, index) {
            if (item.keywordContext.indexOf('NOT') == -1) {
              item.targetContent.forEach(function(i) {
                if (i) {
                  self.keywordCollection.add(i)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      }
    },
    keys() {
      // 如果是智能筛选页面跳过来，则要先设置命中词
      if (this.keys && this.keys.length > 0) {
        let self = this
        self.$nextTick(function() {
          self.keys.forEach(function(item, index) {
            if (
              item.judge == 5 &&
              item.resultsObject.keywordContext.indexOf('NOT') == -1
            ) {
              item.resultsObject.keyword.forEach(function(i) {
                if (i) {
                  self.keywordCollection.add(i)
                  self.highlightWordAll(i)
                }
              })
            }
          })
        })
      }
    },
  },
  filters: {
    dealSpeed(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return '过慢'
      } else if (val > maxSpeed) {
        return '过快'
      }
    },
    dealSpeedType(val, minSpeed, maxSpeed) {
      if (val < minSpeed) {
        return 'danger'
      } else if (val > maxSpeed) {
        return 'primary'
      }
    },
  },
}
</script>
<style lang="less">
.initialITask {
  .operation {
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
  .recordingplay {
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
}
</style>
<style lang="less">
@borderColor: #c3ccd9;
@playerHeight: 50px;
@infoHeight: 190px;
@controlBtnsHeight: 40px;
.recordingPlayContainer {
  width: 100%;
  height: 100%;
  position: relative;
  & > .controller_btns {
    position: absolute;
    width: 100px;
    line-height: 40px;
    top: 0px;
    right: 0px;
    z-index: 999;
    text-align: right;
    padding-right: 10px;
    .controller_btn {
      display: inline-block;
      width: 24px;
      height: 24px;
      line-height: 24px;
      border-radius: 50%;
      margin-left: 5px;
      text-align: center;
      background: #c3ccd9;
      color: #fff;
      &:hover {
        cursor: pointer;
      }
    }
  }
  & > .el-row {
    height: 100%;
    border-top: 2px solid @borderColor;
    & > .el-col {
      height: 100%;
      border-right: 1px solid @borderColor;
      position: relative;
    }
  }
  // 修改tab组件样式
  .el-tabs__item.is-active {
    color: #1f2d3d;
    font-size: 14px;
    font-weight: bold;
  }
  .el-tabs--border-card {
    border: none;
    height: 100%;
    position: relative;
    & > div {
      border: none;
    }
    & > .el-tabs__header {
    }
    & > .el-tabs__content {
      position: absolute;
      top: 40px;
      left: 0;
      right: 0;
      bottom: 0;
      overflow-y: auto;
      & > .el-tab-pane {
        height: 100%;
      }
    }
    & > .el-tabs__header .el-tabs__item {
      border: none;
    }
  }

  // 修改tab组件样式结束
  .leftContainer,
  .rightContainer {
    position: absolute;
    right: 0;
    left: 0;
    top: 0;
    bottom: 0;
  }
  .leftContainer {
    .info {
      height: @infoHeight;
      .infoContent {
        height: 100%;
        .info_item {
          width: 50%;
          float: left;
          line-height: 30px;
          color: #8691a5;
          font-size: 14px;
          .el-rate {
            display: inline-block;
            margin-left: 5px;
            vertical-align: middle;
          }
          span.el-tag {
            margin-right: 2px;
          }
          &.agentLabel {
            width: 100%;
            .el-tag {
              margin-right: 5px;
            }
          }
        }
      }
    }
    .dialog {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      top: @infoHeight;
      overflow-y: auto;
      padding: 10px;
      background: #eef1f6;
      & > ul {
        position: relative;
        & > li {
          overflow: hidden;
          margin: 10px 0px;
          .avatar {
            width: 46px;
            height: 46px;
            line-height: 46px;
            border-radius: 23px;
            border: 1px solid @borderColor;
            text-align: center;
            background: #fff;
          }
          .dialog-content {
            background: #fff;
            padding: 10px 15px;
            line-height: 20px;
            border-radius: 5px;
            margin-left: 15px;
            position: relative;
            max-width: 280px;
            margin-top: 5px;
            cursor: pointer;
          }
          .content-tag {
            margin-top: 15px;
          }
          &.custom_content {
            div {
              float: left;
            }
            .dialog-content {
              background: #fff;
              &::before {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #fff;
                position: absolute;
                top: 10px;
                left: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.agent_content {
            div {
              float: right;
            }
            .dialog-content {
              margin-left: 10px;
              margin-right: 15px;
              background: #9eea6a;
              color: #000000;
              &::after {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #9eea6a;
                position: absolute;
                top: 10px;
                right: -6px;
                transform: rotate(45deg);
              }
            }
          }
          // 当前正在播放的对话内容样式
          &.currentClass {
            .dialog-content {
              background: #22b8fe;
              color: #000000;
              &::after {
                background: #22b8fe;
              }
              &::before {
                background: #22b8fe;
              }
            }
          }
          &.UNK {
            div {
              text-align: center;
              display: block;
              color: #97a8be;
            }
            div.line {
              width: 100%;
              height: 15px;
              background: url('../../../assets/img/unk.png') no-repeat;
              background-position: center;
            }
          }
        }
      }
    }
    #lrc_list {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      top: @infoHeight;
      overflow-y: auto;
      padding: 10px;
      background: #eef1f6;
      & > ul {
        position: relative;
        & > li {
          overflow: hidden;
          margin: 10px 0px;
          .avatar {
            width: 46px;
            height: 46px;
            line-height: 46px;
            border-radius: 23px;
            border: 1px solid @borderColor;
            text-align: center;
            background: #fff;
          }
          .dialog-content {
            background: #fff;
            padding: 10px 15px;
            line-height: 20px;
            border-radius: 5px;
            margin-left: 15px;
            position: relative;
            max-width: 280px;
            margin-top: 5px;
          }
          .content-tag {
            margin-top: 15px;
          }
          &.custom_content {
            div {
              float: left;
            }
            .dialog-content {
              background: #fff;
              &::before {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #fff;
                position: absolute;
                top: 10px;
                left: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.agent_content {
            div {
              float: right;
            }
            .dialog-content {
              margin-left: 10px;
              margin-right: 15px;
              background: #9eea6a;
              color: #000000;
              &::after {
                content: '';
                display: block;
                width: 15px;
                height: 15px;
                background: #9eea6a;
                position: absolute;
                top: 10px;
                right: -6px;
                transform: rotate(45deg);
              }
            }
          }
          &.UNK {
            div {
              text-align: center;
              display: block;
              color: #97a8be;
            }
            div.line {
              width: 100%;
              height: 15px;
              background: url('../../../assets/img/unk.png') no-repeat;
              background-position: center;
            }
          }
        }
      }
    }
  }
  .rightContainer {
    .tabs {
      width: 100%;
      height: 100%;
      overflow-y: auto;
    }
    .tables {
      width: 100%;
      height: 50%;
      overflow-y: auto;
    }
    .infoForm {
      height: 100%;
      .detailInfoContents_part {
        border-bottom: 1px dashed @borderColor;
        .detailInfoContentsInputs {
          padding: 10px;
          .el-form-item > label {
            font-size: 14px;
            color: #8691a5;
          }
        }
        h3 {
          padding-left: 10px;
          line-height: 30px;
          font-size: 14px;
          color: #9dadc2;
          font-weight: normal;
        }
      }
    }
    .el-date-editor.el-input {
      width: 100%;
    }
    .el-select {
      width: 100%;
    }
    .operation {
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      padding: 0px 10px 0px 0px;
      border-bottom: 1px dashed @borderColor;
      position: absolute;
      top: 0px;
      left: 10px;
      right: 10px;
      h3 {
        width: 65px;
        float: left;
        font-size: 14px;
        color: #5e6d82;
        font-weight: normal;
      }
    }
    .btns {
      float: right;
      button {
        width: 90px;
      }
      margin: 10px;
    }
    .standards_parts {
      position: absolute;
      top: 10px;
      right: 0px;
      left: 0px;
      bottom: 0px;
      overflow-y: auto;
      .standards_part {
        border-bottom: 1px dotted @borderColor;
        margin: 0 10px;
        position: relative;
        h3 {
          padding-left: 10px;
          line-height: 30px;
          font-size: 14px;
          color: #1f2d3d;
          font-weight: normal;
        }
        .standards_detail {
          padding: 10px;
          .classification_part {
            margin: 0 10px;
            h3 {
              padding-left: 10px;
              line-height: 30px;
              font-size: 14px;
              color: #9dadc2;
              font-weight: normal;
            }
            .classification_detail {
              padding: 10px;
              .el-form-item > label {
                font-size: 14px;
                color: #8691a5;
              }
            }
          }
          .normalNameClass {
            line-height: 30px;
            color: #9dadc2;
            font-size: 14px;
          }
        }
        &.noBorder {
          border-bottom: none;
          & > p {
            font-size: 14px;
            margin-bottom: 10px;
          }
        }
        .btns {
          margin: 10px;
        }
      }
      .score {
        width: 150px;
        line-height: 30px;
        position: absolute;
        right: 10px;
        top: 0px;
        text-align: right;
        label {
          display: inline-block;
          width: 100px;
          font-size: 14px;
          color: #1f2d3d;
          line-height: 30px;
        }
        span {
          display: inline-block;
          width: 35px;
          font-size: 18px;
          color: red;
          line-height: 30px;
        }
        .result {
          color: #85ce61;
        }
      }
      .selectInspector {
        width: 120px;
        line-height: 30px;
        position: absolute;
        right: 145px;
        top: 6px;
      }
      &.screening {
        top: 10px;
      }
      &.appealScore {
        h3 {
          color: #9dadc2;
        }
        label {
          color: #8691a5;
        }
      }
    }
  }
  .score_result {
    width: 35px;
    font-size: 18px;
    color: #85ce61;
    line-height: 30px;
  }
  .btns {
    text-align: right;
    button {
      width: 90px;
    }
  }
  .contentLeft,
  .contentRight {
    border: 1px solid @borderColor;
  }
  .el-dialog__body {
    padding-top: 10px;
    .footer {
      margin-top: 10px;
    }
  }
  .dialogTitle {
    color: #8691a5;
    font-size: 14px;
    font-weight: normal;
    box-sizing: border-box;
    height: 50px;
    line-height: 50px;
    padding: 0px 10px;
    border-bottom: 1px dotted @borderColor;
    .btns button {
      width: 30px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      padding: 0px;
    }
  }
  .shareReason {
    padding: 10px;
    height: 300px;
    overflow-y: auto;
    .el-tree.filter-tree {
      border: none;
    }
  }
  .addCaseReason {
    padding: 10px 10px 0px;
  }
  .addCaseReason_btns {
    margin-top: 10px;
  }
  .process {
    height: 300px;
    margin: 10px;
    .el-steps {
      height: 300px;
    }
    .process_score,
    .process_time {
      color: #8691a5;
      font-size: 14px;
      line-height: 20px;
      .score {
        color: #ff4962;
      }
    }
  }
  .hightlightContent_span,
  .playClip_btn {
    cursor: pointer;
  }
  .currentDistributeCount {
    display: inline-block;
    width: 50px;
  }
  .hidden {
    display: none;
  }
  span.defualtScore {
    float: right;
  }
  .customLabel {
    display: inline-block;
    margin-right: 5px;
  }
}
</style>
