<template>
  <div>
    <div class="infoForm">
      <el-form ref="formOrderInfo" :model="formOrderInfo" label-width="80px">
        <div class="detailInfoContents_part">
          <h3>
            订单信息
          </h3>
          <div class="detailInfoContentsInputs">
            <el-form-item prop="code" label="订单编号">
              <el-input v-model="formOrderInfo.orderNo" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item prop="from" label="下单时间">
              <el-input v-model="formOrderInfo.orderTime" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item prop="from" label="订单状态">
              <el-input v-model="formOrderInfo.orderState" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item prop="from" label="提交人">
              <el-input v-model="formOrderInfo.submiterName" :disabled="true"></el-input>
            </el-form-item>
          </div>
        </div>
      </el-form>
    </div>
    <div class="table" style="width: 100% ; height: auto">
      <el-table :data="tableData" border highlight-current-row style="width: 100%">
        <el-table-column fixed="left" prop="callId" label="录音编号"> </el-table-column>
        <el-table-column fixed="left" prop="callSTime" label="拨打时间">
        </el-table-column>
        <el-table-column fixed="left" prop="seatName" label="拨打人"> </el-table-column>
        <el-table-column fixed="left" prop="calledNo" label="拨打电话"> </el-table-column>
        <el-table-column fixed="left" prop="objectId" label="外呼阶段"> </el-table-column>
        <el-table-column fixed="left" prop="objectId" label="备注"> </el-table-column>
        <el-table-column fixed="left" prop="objectId" label="得分"> </el-table-column>
        <el-table-column fixed="left" prop="objectId" label="操作"> </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import global from '../../../../global.js'
import formatdate from '../../../../utils/formatdate.js'
let qualityUrl = global.qualityUrl
export default {
  data() {
    return {
      formOrderInfo: {
        orderNo: '',
        orderTime: '',
        orderState: '',
        submiterName: '',
      },
      tableData: [],
    }
  },
  mounted() {
    this.getOrderDetail()
    this.getTapeInfo()
  },
  methods: {
    getOrderDetail: function() {
      let _this = this
      this.axios
        .post(
          qualityUrl + '/orderAppeal/getOrderInfo.do?orderNo=' + this.parentModel.orderNo
        )
        .then((res) => {
          _this.formOrderInfo = res.data.results[0]
        })
    },
    getTapeInfo: function() {
      let _this = this
      this.axios
        .post(
          qualityUrl + '/orderAppeal/getTapeInfo.do?orderNo=' + this.parentModel.orderNo
        )
        .then((res) => {
          _this.tableData = res.data.results
        })
    },
    timeFormat: function(date) {
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
  },
  props: ['parentModel'],
}
</script>

<style lang="less" scope="scoped">
@borderColor: #c3ccd9;
.customLabel {
  display: inline-block;
  margin-right: 5px;
}

.infoForm {
  height: 100%;
  .detailInfoContents_part {
    border-bottom: 1px dashed @borderColor;
    .detailInfoContentsInputs {
      padding: 10px;
      .el-form-item > label {
        font-size: 14px;
        color: #8691a5;
      }
    }
    h3 {
      padding-left: 10px;
      line-height: 30px;
      font-size: 14px;
      color: #9dadc2;
      font-weight: normal;
    }
  }
}

.el-date-editor.el-input {
  width: 100%;
}

.el-select {
  width: 100%;
}
</style>
