<template>
  <div>
    <div class="title">
      <h2>质检模板 {{ this.modelTile }}</h2>
      <h3>对提交人 {{ this.parentModel.submiterName }} 质检</h3>
    </div>
    <div class="standards_part">
      <h3>
        自动评分标准
      </h3>
      <div class="score">
        <label>自动质检得分</label>
        <span>{{ autoScore }}</span>
      </div>
      <div class="standards_detail">
        <div v-for="(standardsList, key) in standardsLists" :key="key">
          <div class="normalNameClass">{{ key }}</div>
          <el-table
            ref="standardsListTable"
            :data="standardsList"
            border
            tooltip-effect="dark"
            style=""
          >
            <el-table-column prop="normalName" label="质检标准"> </el-table-column>
            <el-table-column label="内容">
              <template scope="scope">
                <div v-if="scope.row.judge === 5">
                  <p v-if="scope.row.resultsObject !== null">
                    <span
                      v-for="(item,
                      index) in scope.row.resultsObject.keywordContext.split('OR')"
                      :key="index"
                    >
                      <span
                        class="hightlightContent_span"
                        @click="hightlightContent(item)"
                        >{{ item }}
                      </span>
                      <span
                        v-if="
                          index <
                            scope.row.resultsObject.keywordContext.split('OR').length - 1
                        "
                        >&nbsp;OR&nbsp;</span
                      >
                    </span>
                    <el-popover placement="right" width="120" trigger="hover">
                      <template
                        v-if="scope.row.resultsObject.deadItem == '1'"
                        slot="reference"
                      >
                        <i class="el-icon-warning" style="color: red"></i>
                      </template>
                      <p>此标准为致命项标准，命中则分数为 0</p>
                    </el-popover>
                  </p>
                </div>
                <div v-else-if="scope.row.judge === 4">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.minWord }}-{{ srrt.maxWord }}字/秒<span class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 1">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}分<span
                        class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 2">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <p>
                      {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                        class="defualtScore"
                        >得{{ srrt.score }}分</span
                      >
                    </p>
                  </div>
                </div>
                <div v-else-if="scope.row.judge === 3">
                  <div v-for="(srrt, index) in scope.row.resultsObject" :key="index">
                    <div v-if="srrt.silenceType === 1">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}次<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div v-else-if="srrt.silenceType === 2">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}秒<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div v-else-if="srrt.silenceType === 3">
                      <p>
                        {{ srrt.silenceTimeMin }}-{{ srrt.silenceTimeMax }}%<span
                          class="defualtScore"
                          >得{{ srrt.score }}分</span
                        >
                      </p>
                    </div>
                    <div></div>
                  </div>
                </div>
                <div v-else></div>
              </template>
            </el-table-column>
            <el-table-column prop="defaultScore" label="得分" width="120">
              <template scope="scope">
                <span
                  v-if="
                    checkShow(scope.row.newIndex, 'edit') &
                      (scope.row.judge == 5) &
                      (scope.row.resultsObject.deadItem === '1') &
                      (currentDistribute[scope.row.newIndex].score == 1)
                  "
                  class="currentDistributeCount"
                  >非致命</span
                >
                <span
                  v-else-if="
                    checkShow(scope.row.newIndex, 'edit') &
                      (scope.row.judge == 5) &
                      (scope.row.resultsObject.deadItem === '1') &
                      (currentDistribute[scope.row.newIndex].score == 0)
                  "
                  class="currentDistributeCount"
                  >致命</span
                >
                <span
                  v-else-if="checkShow(scope.row.newIndex, 'edit')"
                  class="currentDistributeCount"
                  >{{ currentDistribute[scope.row.newIndex].score }}</span
                >
                <el-button
                  v-if="checkShow(scope.row.newIndex, 'edit') && !scored"
                  @click="editTableCell(scope.row.newIndex, 'edit')"
                  type="text"
                  size="small"
                  icon="edit"
                ></el-button>
                <el-select
                  v-if="
                    checkShow(scope.row.newIndex, 'save') &
                      (scope.row.judge == 5) &
                      (scope.row.resultsObject.deadItem === '1')
                  "
                  @change="changeDead(scope.row.newIndex)"
                  v-model="currentDistribute[scope.row.newIndex].score"
                  placeholder="请选择"
                  style="width: 95px;"
                >
                  <el-option
                    v-for="item in deadOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
                <el-input
                  v-else-if="checkShow(scope.row.newIndex, 'save')"
                  class="currentDistributeCount"
                  v-model="currentDistribute[scope.row.newIndex].score"
                  placeholder="请输入内容"
                  @blur="checkNumber(scope.row.newIndex, scope.row)"
                ></el-input>
                <el-button
                  v-if="checkShow(scope.row.newIndex, 'save')"
                  @click="editTableCell(scope.row.newIndex, 'save')"
                  type="text"
                  size="small"
                  icon="check"
                ></el-button>
              </template>
            </el-table-column>
            <el-table-column prop="times" label="命中场景">
              <template scope="scope">
                <span
                  class="playClip_btn"
                  v-for="(word, index) in scope.row.resultsObject.keyword"
                  :key="index"
                  @click="playOccurrence(word)"
                >
                  {{ word.keyword }}
                </span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
    <el-form ref="form" :model="form" label-width="80px">
      <div class="standards_part">
        <h3>
          人工标准
        </h3>
        <div class="score">
          <label>人工质检得分</label>
          <span>{{ menualScore }}</span>
        </div>
        <div class="standards_detail">
          <div
            class="classification_part"
            v-for="(val, key, index) in typelist"
            :key="index"
          >
            <h3>
              {{ key }}
            </h3>
            <div class="classification_detail">
              <el-row>
                <el-col :span="12" v-for="(obj, idx) in scoreObjs[index]" :key="idx">
                  <el-form-item :label="obj.normalName">
                    <el-popover
                      v-if="obj.judge == 6 && !scored"
                      placement="right"
                      width="120"
                      trigger="focus"
                    >
                      <el-input
                        v-model="obj.defaultScore"
                        slot="reference"
                        @blur="
                          checkRange(
                            obj.defaultScore,
                            obj.minScoreRange,
                            obj.maxScoreRange
                          )
                        "
                      ></el-input>
                      <p>{{ obj.normalContent || '无' }}</p>
                    </el-popover>
                    <el-input
                      v-model="obj.defaultScore"
                      placeholder="请输入内容"
                      v-if="obj.judge == 6 && scored"
                      :disabled="scored"
                    ></el-input>
                    <el-popover
                      v-if="obj.judge == 7 && !scored"
                      placement="right"
                      width="120"
                      trigger="hover"
                    >
                      <el-radio-group
                        slot="reference"
                        v-model="obj.defaultScore"
                        size="medium"
                        fill="#97a8be"
                        :disabled="scored"
                      >
                        <el-radio-button
                          :label="val"
                          :value="val"
                          v-for="val in obj.resultsObject"
                          :key="val"
                        ></el-radio-button>
                      </el-radio-group>
                      <p>{{ obj.normalContent || '无' }}</p>
                    </el-popover>
                    <el-radio-group
                      v-model="obj.defaultScore"
                      size="medium"
                      fill="#97a8be"
                      v-if="obj.judge == 7 && scored"
                      :disabled="scored"
                    >
                      <el-radio-button
                        :label="val"
                        :value="val"
                        v-for="val in obj.resultsObject"
                        :key="val"
                      ></el-radio-button>
                    </el-radio-group>

                    <template v-if="obj.judge == 8 && !scored">
                      <el-popover placement="right" width="120" trigger="hover">
                        <template slot="reference">
                          <el-radio-group
                            v-model="obj.defaultScore"
                            size="medium"
                            fill="#97a8be"
                          >
                            <el-radio-button :label="'1'">致命</el-radio-button>
                            <el-radio-button :label="'2'">非致命</el-radio-button>
                          </el-radio-group>
                        </template>
                        <p>{{ obj.normalContent || '无' }}</p>
                      </el-popover>
                      <el-popover trigger="hover" placement="right">
                        <template slot="reference">
                          <i class="el-icon-warning" style="color: red"></i>
                        </template>
                        <p>选中致命项则总分为<font color="red"> 零</font></p>
                      </el-popover>
                    </template>
                    <div v-if="obj.judge == 8 && scored">
                      <el-radio-group
                        v-model="obj.defaultScore"
                        :disabled="scored"
                        size="medium"
                        fill="#97a8be"
                      >
                        <el-radio-button :label="'1'">致命</el-radio-button>
                        <el-radio-button :label="'2'">非致命</el-radio-button>
                      </el-radio-group>
                      <i class="el-icon-warning" style="color: red"></i>
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>
            </div>
          </div>
        </div>
      </div>
      <div class="standards_part">
        <h3>
          &nbsp;
        </h3>
        <div class="score">
          <label>总分</label>
          <span class="result">{{ totalScore }}</span>
        </div>
        <div class="standards_detail">
          <div class="classification_part">
            <div class="classification_detail">
              <el-form-item label="质检结果">
                <el-input
                  type="textarea"
                  v-model="handleContent"
                  placeholder="请输入内容"
                  :disabled="scored"
                ></el-input>
              </el-form-item>
            </div>
          </div>
        </div>
      </div>
    </el-form>
    <div class="btns footer" v-show="showCaseBtn">
      <el-button @click="addCase_btn">添加案例</el-button>
      <el-button @click="submitScore" type="primary" v-if="!scored">
        完成打分
      </el-button>
      <el-button type="primary" :disabled="true" v-if="scored">已完成</el-button>
    </div>
    <!-- 添加案例弹出层 -->
    <el-dialog
      :modal="false"
      title="添加案例"
      :visible.sync="showAddCaseDialog"
      :close-on-click-modal="false"
      :before-close="handleCloseAddCaseDialog"
    >
      <el-form
        :model="AddCaseModel"
        ref="AddCaseModel"
        label-width="0px"
        :rules="addCaseRules"
      >
        <div class="contentRight">
          <h3 class="dialogTitle">
            添加原因
          </h3>
          <div class="addCaseReason">
            <el-form-item prop="addCaseReason">
              <el-input
                type="textarea"
                :rows="12"
                placeholder="请输入添加原因"
                v-model="AddCaseModel.addCaseReason"
              >
              </el-input>
            </el-form-item>
          </div>
        </div>
        <el-form-item>
          <div class="btns addCaseReason_btns">
            <el-button @click="handleCloseAddCaseDialog">取消</el-button>
            <el-button type="primary" @click="hasSameCaseThrottle">添加</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import global from '../../../../global.js'
import qs from 'qs'
let currentBaseUrl = global.qualityUrl
export default {
  components: {},
  data() {
    return {
      standardsList: [], // 质检评分标准
      standardsLists: [],
      typelist: [], // 人工打分标准
      showAddCaseDialog: false,
      ModifyClassDialog: false,
      modelId: '', // 质检模板id
      showHandleContent: '', // 展示质检评分-质检结果
      handleContent: '', // 质检评分-质检结果
      showQualityScore: false, // 是否展示质检评分tab
      isScore: false,
      currentDistribute: [], // 要保存的当前分数列表
      scoreObjs: [], // 人工质检打分项对象
      form: {},
      scored: false, // 是否打分完成
      showCurrentDistribute: [], // 当前分数列表
      editCountIndex: '', // 当前编辑的单元格所在的行index
      countHasError: false, // 自动打分修改的是否正确
      isDead: '2', // 手动评分致命项
      isAutoDead: '2', // 自动评分致命项
      showCaseBtn: true,
      modelTile: '',
      deadOptions: [
        {
          value: 0,
          label: '致命',
        },
        {
          value: 1,
          label: '非致命',
        },
      ],
      AddCaseModel: {
        addCaseReason: '',
      },
      addCaseRules: {
        // 添加案例验证
        addCaseReason: [
          {
            required: true,
            message: '请输入添加原因',
            trigger: 'blur',
          },
        ],
      },
      returnVisitMatchResult: [],
    }
  },
  methods: {
    reSetData() {
      this.standardsLists = []
      this.typelist = [] // 人工打分标准
      this.showAddCaseDialog = false
      this.ModifyClassDialog = false
      this.modelId = '' // 质检模板id
      this.showHandleContent = '' // 展示质检评分-质检结果
      this.handleContent = '' // 质检评分-质检结果
      this.showQualityScore = false // 是否展示质检评分tab
      this.isScore = false
      this.currentDistribute = [] // 要保存的当前分数列表
      this.scoreObjs = [] // 人工质检打分项对象
      this.form = {}
      this.scored = false // 是否打分完成
      this.showCurrentDistribute = [] // 当前分数列表
      this.editCountIndex = '' // 当前编辑的单元格所在的行index
      this.countHasError = false // 自动打分修改的是否正确
      this.isDead = '2' // 手动评分致命项
      this.isAutoDead = '2' // 自动评分致命项
      this.showCaseBtn = true
      this.AddCaseModel.addCaseReason = ''
      //   this.saveRecordModel.shareReason = '' // 收藏理由
      this.returnVisitMatchResult = []
    },
    getConditonScore(qaScoreType) {
      let _this = this
      let url = currentBaseUrl + '/scoreView/getOrderConditonScore.do'
      let params = {}
      params.objectId = _this.parentModel.orderNo
      params.qaScoreType = qaScoreType
      params.scoreClass = '2'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          // 如果获取到了数据则赋值
          if (response.data && response.data.scoreDetails) {
            _this.scoreDetails = response.data.scoreDetails
            // 如果是初检页面，则给编辑界面的值赋值
            if (qaScoreType === '2') {
              _this.scored = true
            }
            _this.changData(_this.scoreDetails)
            _this.handleContent = response.data.score.comments || ''
          } else if (response.data && response.data.score) {
            _this.handleContent = response.data.score.comments
          } else {
            if (qaScoreType === '2') {
              console.log('检查初检是否打分')
              _this.getConditonScore('1')
            }
          }
          _this.showKeywordsData()
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数获取失败',
          })
        })
    },
    // 关闭添加案例弹出层
    handleCloseAddCaseDialog() {
      this.showAddCaseDialog = false
    },
    checkShow(index, flag) {
      if (flag === 'edit' && this.editCountIndex !== index) {
        return true
      } else if (flag === 'save' && this.editCountIndex !== index) {
        return false
      } else if (flag === 'save' && this.editCountIndex === index) {
        return true
      } else {
        return false
      }
    },
    // 获取开始时间和结束时间，保存到vuex中
    playClip(startTime, endTime) {
      let playInfo = {}
      playInfo.timeSection = [startTime, endTime]
      this.$store.commit('setPlayerInfo', playInfo)
    },
    // 检查当前分配输入的是否是数字
    checkNumber(index, obj) {
      this.countHasError = false
      let arr = []
      if (typeof obj.minScoreRange === 'number' && !Number.isNaN(obj.minScoreRange)) {
        arr.push(obj.minScoreRange)
      } else {
        arr.push(0)
      }
      if (typeof obj.maxScoreRange === 'number' && !Number.isNaN(obj.maxScoreRange)) {
        arr.push(obj.maxScoreRange)
      }
      if (typeof obj.defaultScore === 'number' && !Number.isNaN(obj.defaultScore)) {
        arr.push(obj.defaultScore)
      }
      arr.sort(function(a, b) {
        return a - b
      })
      let min = arr[0] > obj.defaultScore ? obj.defaultScore : arr[0]
      let max =
        arr[arr.length - 1] < obj.defaultScore ? obj.defaultScore : arr[arr.length - 1]
      // 设置自动评分的致命项
      if (obj.resultsObject.deadItem == '1' && this.currentDistribute[index].score <= 0) {
        this.isAutoDead = '1'
      } else {
        this.isAutoDead = '2'
      }
      if (obj.resultsObject.deadItem == '1') {
        // 致命项只能打分0/1
        min = 0
        max = 1
      }
      if (
        typeof +this.currentDistribute[index].score !== 'number' ||
        Number.isNaN(+this.currentDistribute[index].score) ||
        this.currentDistribute[index].score === ''
      ) {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
        this.countHasError = true
        return false
      } else if (
        this.currentDistribute[index].score < min ||
        this.currentDistribute[index].score > max
      ) {
        this.$message({
          type: 'error',
          message: '分值范围为' + min + '~' + max,
        })
        event.target.focus()
        this.countHasError = true
        return false
      }
    },
    checkRange(val, min, max) {
      if (isNaN(val) || val === '') {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
      } else if (val < min || val > max) {
        this.$message({
          type: 'error',
          message: '分值范围为' + min + '~' + max,
        })
        event.target.focus()
      }
    },
    // 关键词展示
    showKeywordsData() {
      console.log('showKeywordsData' + 1111111)
      let _this = this
      let array = []
      let newobj = {}
      if (_this.playInfoVosList.length <= 0) {
        return false
      }
      for (let k in _this.standardsLists) {
        let newarray = []
        _this.standardsLists[k].forEach(function(normal) {
          let key = normal
          let reg = /[A-Z()\s]+/
          if (key.judge == 5) {
            if (key.targetTime) {
              let targetTime = ''
              targetTime = key.targetTime
              let target = targetTime.split(',')
              let targetTimeStart = target[0]
              let targetTimeEnd = target[1]
              key.targetTimeStart = targetTimeStart
              key.targetTimeEnd = targetTimeEnd
              for (let n = 0; n < _this.playInfoVosList.length; n++) {
                if (
                  parseInt(_this.playInfoVosList[n].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[n].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.Start = n
                  key.targetTimeStart = _this.playInfoVosList[n].startTime
                  break
                }
              }
              for (let m = _this.playInfoVosList.length - 1; m >= 0; m--) {
                if (
                  parseInt(_this.playInfoVosList[m].startTime) <=
                    parseInt(targetTimeEnd) &&
                  parseInt(_this.playInfoVosList[m].endTime) >= parseInt(targetTimeStart)
                ) {
                  key.End = m
                  key.targetTimeEnd = _this.playInfoVosList[m].endTime
                  break
                }
              }
            } else {
              key.Start = 0
              key.End = _this.playInfoVosList.length - 1
              key.targetTimeStart = '0'
              key.targetTimeEnd = _this.playInfoVosList[key.End].endTime
            }
            let keywordContext = key.resultsObject.keywordContext
            let result = keywordContext.replace(reg, ',')
            while (result.match(reg)) {
              result = result.replace(reg, ',')
            }
            keywordContext = result.trim().split(',')
            let keywordContext1 = []
            let o = 0
            for (let l = 0; l < keywordContext.length; l++) {
              if (keywordContext[l] != '') {
                for (let j = key.Start; j <= key.End; j++) {
                  if (key.resultsObject.roleType == 1) {
                    if (
                      _this.playInfoVosList[j].role == '2' &&
                      _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0
                    ) {
                      keywordContext1[o] = keywordContext[l]
                    }
                  } else if (key.resultsObject.roleType == 2) {
                    if (
                      _this.playInfoVosList[j].role == '1' &&
                      _this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0
                    ) {
                      keywordContext1[o] = keywordContext[l]
                    }
                  } else {
                    if (_this.playInfoVosList[j].text.indexOf(keywordContext[l]) >= 0) {
                      keywordContext1[o] = keywordContext[l]
                    }
                  }
                }
                o++
              }
            }
            key.resultsObject.keyword = []
            keywordContext1.forEach((item) => {
              key.resultsObject.keyword.push({
                keyword: item,
                clickIndex: 0,
                fullScriptRole: key.resultsObject.roleType,
                targetTimeStart: key.targetTimeStart,
                targetTimeEnd: key.targetTimeEnd,
              })
            })
          } else {
            key.resultsObject.keyword = []
          }
          array.push(key)
          newarray.push(key)
        })
        newobj[k] = newarray
      }
      _this.standardsLists = newobj
      console.log('newobj:' + newobj)
      _this.$emit('showhighlightscore', array)
    },
    // 命中场景 点击按钮
    playOccurrence(keywordItem) {
      this.$emit('clickhighlightkeys', keywordItem)
    },
    // 点击table中编辑和保存按钮时数据状态的变化
    editTableCell(index, flag) {
      if (this.countHasError) {
        return false
      }
      if (flag === 'edit') {
        this.editCountIndex = index
      } else {
        if (
          isNaN(this.currentDistribute[index].score) ||
          this.currentDistribute[index].score === ''
        ) {
          this.countHasError = true
          return false
        }
        this.editCountIndex = ''
      }
    },
    getModelTitle(modelId) {
      let _this = this
      let url =
        currentBaseUrl +
        'qualityInspectionSystem/orderManualSample/getModelTitleByModelId.do'
      let params = {
        modelId: modelId,
      }
      this.axios.post(url, qs.stringify(params)).then(function(res) {
        if (res.data) {
          _this.modelTile = res.data.modelTile
        }
      })
    },
    changeDead(index) {
      if (this.currentDistribute[index].score == 0) {
        this.isAutoDead = '1'
      } else {
        this.isAutoDead = '2'
      }
    },
    // 获取模板id
    qamodleScore() {
      let _this = this
      let url = currentBaseUrl + '/scoreView/findOrderModelId.do'
      let params = {}
      params.objectId = this.parentModel.orderNo
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.modelId = response.data
          if (_this.modelId) {
            _this.yulanModleInfoScore() // 获取模板id之后根据模板id获取模板详情
            _this.getModelTitle(_this.modelId)
          } else {
            _this.$message({
              type: 'error',
              message: '未获取到模板id',
            })
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取质检模板id失败',
          })
        })
    },
    // 预览模板（isNeedGetData=》是否需要获取数据，默认为true）
    yulanModleInfoScore(isNeedGetData) {
      let flag = typeof isNeedGetData === 'undefined' ? true : isNeedGetData
      let _this = this
      let url = currentBaseUrl + '/manualOrderQualityAssurance/yulanModleInfoScore.do'
      let params = {}
      params.modleId = this.modelId
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.standardsLists = response.data.dataT
            let indexT = 0
            for (let key in _this.standardsLists) {
              let obj = _this.standardsLists[key]
              obj.forEach(function(item, index) {
                item.newIndex = indexT
                let temp = {}
                temp.normalId = item.normalId
                temp.score = item.defaultScore
                if (item.judge === 5) {
                  if (item.resultsObject.deadItem === '1') {
                    temp.deadItem = '1'
                  }
                } else {
                  temp.deadItem = '2'
                }
                _this.$set(_this.currentDistribute, indexT, temp)
                indexT++
              })
            }
            _this.typelist = response.data.data_hand
            _this.showTypelist = response.data.data_hand
            _this.scoreObjs = []
            _this.showScoreObjs = []
            let index = 0
            for (let item in _this.typelist) {
              // _this.$set(_this.scoreObjs, index, _this.typelist[item])
              let scores = []
              _this.typelist[item].forEach(function(temp) {
                let obj = {}
                for (let key in temp) {
                  obj[key] = temp[key]
                }
                if (temp.judge === 7 && _this.checkArrayType(temp.resultsObject)) {
                  obj.defaultScore = temp.resultsObject[0]
                }
                scores.push(obj)
              })
              // _this.$set(_this.showScoreObjs, index, JSON.parse(JSON.stringify(scores)))
              _this.$set(_this.scoreObjs, index, JSON.parse(JSON.stringify(scores)))
              index++
            }
            if (flag) {
              console.log(11111111)
              _this.getData()
            }
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取模板失败',
          })
        })
    },
    // 添加案例
    addCase_btn() {
      this.showAddCaseDialog = true
      this.resetForm('AddCaseModel')
    },
    // 判断是否重复添加案例
    hasSameCaseThrottle() {
      this.lodashThrottle.throttle(this.hasSameCase, this)
    },
    hasSameCase() {
      let _this = this
      let url = currentBaseUrl + 'qualityInspectionSystem/caseDetailOrder/hasSameCase.do'
      let params = {}
      params.objectId = this.parentModel.orderNo
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (!response.data) {
            _this.addCase()
          } else {
            _this.$message({
              type: 'error',
              message: '案例重复添加',
            })
            _this.showAddCaseDialog = false
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '检查是否重复添加失败',
          })
        })
    },
    // 添加案例
    addCase() {
      let _this = this
      this.$refs.AddCaseModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let url = currentBaseUrl + 'qualityInspectionSystem/caseDetailOrder/colCase.do'
          let params = {}
          params.caseRemark = this.AddCaseModel.addCaseReason
          params.orderNo = this.parentModel.orderNo
          params.caseClassId = '1'
          params.caseName = '案例'
          this.axios
            .post(url, qs.stringify(params))
            .then(function(response) {
              if (response.data) {
                _this.$message({
                  type: 'success',
                  message: '案例添加成功',
                })
                _this.showAddCaseDialog = false
              } else {
                return Promise.reject()
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '案例添加失败',
              })
            })
        }
      })
    },
    // 重置表单
    resetForm(name) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[name].resetFields()
      })
    },
    // 我的质检任务》提交分数
    submitScore() {
      let _this = this
      let url = ''
      let result = []
      let params = {}
      this.scoreObjs.forEach(function(item, index) {
        item.forEach(function(temp) {
          let obj = {}
          obj.normalId = temp.normalId
          if (temp.judge == 6) {
            obj.score = temp.defaultScore
          } else if (temp.judge == 7) {
            obj.optioniItem = temp.defaultScore
          } else if (temp.judge == 8) {
            obj.optioniItem = _this.isDead
            obj.comments = _this.isDead == '1' ? '致命' : '非致命'
          }
          result.push(obj)
        })
      })
      if (this.editCountIndex !== '') {
        this.$message({
          type: 'warning',
          message: '请确认修改的分数',
        })
        return false
      }
      let deadItem
      if (this.isDead == '2' && this.isAutoDead == '2') {
        deadItem = '2'
      } else {
        deadItem = '1'
      }
      params = {}
      params.modelId = this.modelId
      params.score = this.totalScore
      params.objectId = this.orderNo
      params.existQuestion = '' // 存在问题
      params.comments = this.handleContent // 处理内容
      params.qaedUser = this.parentModel.submiter
      params.deadItem = deadItem
      params.scoreClass = '2'
      params.qaScoreType = '1'
      result = result.concat(_this.currentDistribute)
      params.jsonStr = JSON.stringify(result)
      url = currentBaseUrl + 'qualityInspectionSystem/qaDetail/orderUpdateScoreAgainHr.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '打分成功',
            })
            _this.scored = true
          } else {
            return Promise.reject()
          }
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '分数提交失败',
          })
        })
    },
    // 不同页面调用不同的方法获取数据
    getData() {
      // 如果是初检任务，则只给编辑页面赋值即可，如果有则页面不可编辑，完成打分状态
      // 如果没有，则展示模板中的默认打分
      this.getConditonScore('2')
    },
    // 判断数组元素是否都可以转为数字
    checkArrayType(arr) {
      return arr.every(function(val, index, arr) {
        let temp = +val
        return typeof temp === 'number' && !Number.isNaN(temp)
      })
    },
    // 根据获取的分数修改模板内容
    changData(scoreDetails) {
      let _this = this
      let currentDistribute = [] // 自动打分
      let scoreObjs = [] // 手动打分
      currentDistribute = _this.currentDistribute
      scoreObjs = _this.scoreObjs
      scoreDetails.forEach(function(item, index) {
        let isFind = false
        currentDistribute.forEach(function(itm) {
          if (itm.normalId == item.normalId) {
            itm.score = item.score
            console.log(item)
            if (itm.deadItem === '1' && itm.score === 0) {
              _this.isAutoDead = '1'
            }
            isFind = true
          }
        })
        if (!isFind) {
          scoreObjs.forEach(function(itm) {
            itm.forEach(function(obj) {
              if (obj.normalId == item.normalId) {
                if (item.optioniItem || item.optioniItem == 0) {
                  obj.defaultScore = item.optioniItem
                } else {
                  obj.defaultScore = item.score
                }
              }
              console.log(obj)
            })
          })
        }

        // standardsList
        _this.$data.standardsList.forEach((subItem) => {
          if (subItem.normalId == item.normalId) {
            if (item.resultsObject) {
              subItem.resultsObject.keywordList = []
              item.resultsObject.keyword.forEach((keyword) => {
                subItem.resultsObject.keywordList.push({
                  keyword: keyword,
                  clickIndex: 0,
                })
              })
              console.log(item.resultsObject.keyword)
            } else {
              console.log('item.resultsObject 为空!')
            }
          }
        })
      })
    },
  },
  props: ['parentModel', 'playInfoVosList'],
  created() {
    console.log('yffromurl:' + this.parentModel.fromUrl)
    this.qamodleScore()
  },
  mounted() {},
  computed: {
    orderNo() {
      return this.$store.state.recordingPlayPage.orderNo
    },
    currentTime() {
      return this.$store.state.playerInfo.currentTime * 1000
    },
    totalScore() {
      if (this.isDead == '1' || this.isAutoDead == '1') {
        return 0
      }
      let totalScore =
        this.autoScore + this.menualScore > 0 ? this.autoScore + this.menualScore : 0
      return totalScore
    },
    autoScore() {
      let total = 0
      this.currentDistribute.forEach(function(item) {
        if (item.deadItem !== '1') {
          total += parseInt(item.score) || 0
        }
      })
      if (this.isAutoDead == '1') {
        return 0
      }
      return total > 0 ? total : 0
    },
    menualScore() {
      let total = 0
      let _this = this
      let flag = true
      this.scoreObjs.forEach(function(item, index) {
        item.forEach(function(temp) {
          if (temp.judge == 6) {
            total += parseInt(temp.defaultScore) || 0
          } else if (temp.judge == 7) {
            if (temp.defaultScore) {
              total += parseInt(temp.defaultScore) || 0
            }
          } else if (temp.judge == 8 && flag) {
            if (temp.defaultScore == '1') {
              // 如果有一项是致命项则所有的非致命项不能生效
              _this.isDead = '1'
            } else {
              _this.isDead = '2'
            }
            flag = false
          }
        })
      })
      if (this.isDead == '1') {
        return 0
      }
      return total > 0 ? total : 0
    },
  },
  watch: {
    currentTime(val) {
      this.currentClass = this.findCurrentMessage(val - 250)
      this.scrollDialog(this.currentClass)
    },
    focusWord(val, oldval) {
      this.highlightWord(val, oldval, '0')
    },
    focusWordIntell: {
      handler: function(val, oldval) {
        this.highlightWordIntell(val, oldval)
      },
      deep: true, // 对象内部的属性监听，也叫深度监听
    },
    // 如果显示评分轨迹界面
    showScoringTrajectory(val) {
      if (val) {
        this.getLocus()
      }
    },
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.orderNo != undefined) {
          console.log('parentModel变化了')
          this.reSetData()
          this.qamodleScore()
        }
      },
      deep: true,
    },
  },
}
</script>

<style lang="less">
@borderColor: #c3ccd9;
.title {
  h2 {
    padding-left: 10px;
    line-height: 30px;
    font-size: 24px;
    color: #1f2d3d;
    font-weight: normal;
  }
  h3 {
    padding-left: 10px;
    line-height: 30px;
    font-size: 15px;
    color: #1f2d3d;
    font-weight: normal;
  }
}
.standards_part {
  border-bottom: 1px dotted @borderColor;
  margin: 0 10px;
  position: relative;
  h3 {
    padding-left: 10px;
    line-height: 30px;
    font-size: 14px;
    color: #1f2d3d;
    font-weight: normal;
  }
  .standards_detail {
    padding: 10px;
    .classification_part {
      margin: 0 10px;
      h3 {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        color: #9dadc2;
        font-weight: normal;
      }
      .classification_detail {
        padding: 10px;
        .el-form-item > label {
          font-size: 14px;
          color: #8691a5;
        }
      }
    }
    .normalNameClass {
      line-height: 30px;
      color: #9dadc2;
      font-size: 14px;
    }
  }
  &.noBorder {
    border-bottom: none;
    & > p {
      font-size: 14px;
      margin-bottom: 10px;
    }
  }
  .btns {
    margin: 10px;
  }
}
.score {
  width: 150px;
  line-height: 30px;
  position: absolute;
  right: 10px;
  top: 0px;
  text-align: right;
  label {
    display: inline-block;
    width: 100px;
    font-size: 14px;
    color: #1f2d3d;
    line-height: 30px;
  }
  span {
    display: inline-block;
    width: 35px;
    font-size: 18px;
    color: red;
    line-height: 30px;
  }
  .result {
    color: #85ce61;
  }
}
.selectInspector {
  width: 120px;
  line-height: 30px;
  position: absolute;
  right: 145px;
  top: 6px;
}
&.screening {
  top: 10px;
}
&.appealScore {
  h3 {
    color: #9dadc2;
  }
  label {
    color: #8691a5;
  }
}
.hightlightContent_span,
.playClip_btn {
  cursor: pointer;
}
</style>
