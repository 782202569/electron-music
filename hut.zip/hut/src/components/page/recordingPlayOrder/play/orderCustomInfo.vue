<template>
  <div class="customInfo">
    <el-form ref="formCustom" :model="formCustom" label-width="100px">
      <div class="standards_part">
        <h3>
          客户信息
        </h3>
      </div>
      <el-form-item prop="code" label="订单编号">
        <el-input v-model="formCustom.code"></el-input>
      </el-form-item>
      <el-form-item prop="from" label="下单时间">
        <el-input v-model="formCustom.from"></el-input>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      formCustom: {
        code: '',
        from: '',
      },
    }
  },
  created() {
    this.initCustom()
  },
  methods: {
    initCustom: function() {
      this.formCustom.code = this.parentModel.vQaUser
      this.formCustom.from = this.parentModel.fromUrl
    },
  },
  props: ['parentModel'], // 页面来的地方
}
</script>
