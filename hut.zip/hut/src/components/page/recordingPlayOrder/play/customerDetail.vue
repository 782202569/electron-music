<template>
  <div class="infoForm">
    <el-form label-width="100px" :model="esResultModel" ref="esResultModel">
      <div class="detailInfoContents_part">
        <h3>
          来电信息
        </h3>
        <div class="detailInfoContentsInputs">
          <el-row>
            <el-col :span="12">
              <el-form-item label="坐席工号">
                <el-input v-model="esResultModel.seatNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="坐席姓名">
                <el-input v-model="esResultModel.seatName" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="坐席星级">
                <el-input v-model="esResultModel.seatStar" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="录音号">
                <el-input v-model="esResultModel.callId" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="开始时间" prop="callSTime">
                <el-input v-model="esResultModel.callSTime" :disabled="true"> </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="结束时间" prop="callETime">
                <el-input v-model="esResultModel.callETime" :disabled="true"> </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="通话时长" prop="transformTime">
                <el-input
                  :value="esResultModel.callTime / 1000 + '秒'"
                  :disabled="true"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="主叫号码" prop="callNo">
                <el-input v-model="esResultModel.callNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="被叫号码" prop="calledNo">
                <el-input v-model="esResultModel.calledNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12"> </el-col>
          </el-row>
        </div>
      </div>
      <div class="detailInfoContents_part">
        <h3>
          客户信息
        </h3>
        <div class="detailInfoContentsInputs">
          <el-row>
            <el-col :span="12">
              <el-form-item label="客户姓名">
                <el-input
                  v-model="esResultModel.customerName"
                  :disabled="true"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="账号">
                <el-input v-model="esResultModel.customerNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="证件信息">
                <el-input v-model="esResultModel.certType" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="证件号">
                <el-input v-model="esResultModel.certNo" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-form-item label="客户标签">
              <el-tag
                type="primary"
                v-for="(item, index) in customerLabels"
                :key="index"
                class="customLabel"
                >{{ item }}
              </el-tag>
              <el-tag v-if="!customerLabels || customerLabels.length === 0"
                >暂无标签</el-tag
              >
            </el-form-item>
          </el-row>
        </div>
      </div>
    </el-form>
  </div>
</template>
<script>
import global from '../../../../global.js'
let qualityUrl = global.qualityUrl
export default {
  data() {
    return {
      esResultModel: {},
      customerLabels: [],
      certTypeList: [],
      tableData: [],
    }
  },
  watch: {
    custormInfo(val) {
      this.esResultModel = val
    },
  },
  created() {
    this.esResultModel = this.custormInfo
  },
  computed: {},
  methods: {
    getOrderDetail: function() {
      this.axios
        .post(qualityUrl + '/order/getCall.do?orderNo=' + this.parentModel.orderNo)
        .then((res) => {
          this.esResultModel = res.data
        })
    },
  },
  props: ['parentModel', 'custormInfo'],
}
</script>
<style lang="less" scope="scoped">
@borderColor: #c3ccd9;
.customLabel {
  display: inline-block;
  margin-right: 5px;
}

.infoForm {
  height: 100%;
  .detailInfoContents_part {
    border-bottom: 1px dashed @borderColor;
    .detailInfoContentsInputs {
      padding: 10px;
      .el-form-item > label {
        font-size: 14px;
        color: #8691a5;
      }
    }
    h3 {
      padding-left: 10px;
      line-height: 30px;
      font-size: 14px;
      color: #9dadc2;
      font-weight: normal;
    }
  }
}

.el-date-editor.el-input {
  width: 100%;
}

.el-select {
  width: 100%;
}
</style>
