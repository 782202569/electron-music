<!-- 进入某菜单 默认有的tab -->
<template>
  <div class="customInfo">
    <el-form ref="formCustom" :model="formCustom" label-width="100px">
      <div class="standards_part">
        <h3>
          管理者信息
        </h3>
      </div>
      <el-form-item prop="code" label="管理者编号">
        <el-input v-model="formCustom.code"></el-input>
      </el-form-item>
      <el-form-item prop="from" label="管理者">
        <el-input v-model="formCustom.from"></el-input>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      formCustom: {
        code: '',
        from: '',
      },
    }
  },
  created() {
    this.initCustom()
  },
  methods: {
    initCustom: function() {
      this.formCustom.code = this.parentModel.vQaUser
      this.formCustom.from = this.parentModel.fromUrl
    },
  },
  props: ['parentModel'], // 页面来的地方
}
</script>
