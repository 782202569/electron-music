<template>
  <div class="recordingPlayContainer">
    <div>
      <el-form ref="form" :model="form" label-width="80px">
        <el-form-item label="订单编号">
          <el-input :disabled="true" v-model="form.orderNo"></el-input>
        </el-form-item>
        <el-form-item label="下单时间">
          <el-input :disabled="true" v-model="form.orderTime"></el-input>
        </el-form-item>
        <el-form-item label="订单状态">
          <el-input :disabled="true" v-model="form.orderState"></el-input>
        </el-form-item>
        <el-form-item label="提交人">
          <el-input
            v-model="form.submiterName"
            @focus="jumpToSubmiter(form.orderNo)"
            readonly
          ></el-input>
        </el-form-item>
      </el-form>
    </div>
    <div style="width: 100% ; height: auto">
      <el-table :data="recordLists" border highlight-current-row>
        <el-table-column prop="callId" label="录音编号">
          <template scope="scope">
            <el-button type="text" @click="jumpToRecord(scope.row.callId)">{{
              scope.row.callId
            }}</el-button>
          </template>
        </el-table-column>
        <el-table-column
          :formatter="timeFormatter"
          prop="callSTime"
          label="拨打时间"
        ></el-table-column>
        <el-table-column prop="seatName" label="拨打人">
          <template scope="scope">
            <el-button
              type="text"
              @click="jumpToCall(scope.row.callId, scope.row.seatName, scope.row.seatNo)"
            >
              {{ scope.row.seatName }}
            </el-button>
          </template>
        </el-table-column>
        <el-table-column prop="calledNo" label="拨打号码"></el-table-column>
        <el-table-column prop="listenState" label="外呼阶段"></el-table-column>
        <el-table-column prop="note" label="备注"></el-table-column>
      </el-table>
    </div>
    <div class="page">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pageindex"
        :page-sizes="[5, 10, 20, 30]"
        :page-size="pagesize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalCount"
      >
      </el-pagination>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import global from '../../../../global.js'
import formatdate from '../../../../utils/formatdate.js'
let qualityUrl = global.qualityUrl
export default {
  data() {
    return {
      form: {
        orderNo: '',
        orderTime: '',
        orderState: '',
        submiterName: '',
      },
      recordList: [],
      recordLists: [],
      pageindex: 1,
      pagesize: 5,
      totalCount: 0,
    }
  },
  created() {
    this.getOrderDetail()
    this.getOrderRecord()
  },
  methods: {
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.getOrderRecord()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.getOrderRecord()
    },
    reSetData() {
      this.form = {}
      this.recordList = []
      this.recordLists = []
      this.pageindex = 1
      this.pagesize = 5
      this.totalCount = 0
    },
    getOrderDetail: function() {
      let _this = this
      this.axios
        .post(qualityUrl + '/order/getOrder.do?orderNo=' + this.parentModel.orderNo)
        .then((res) => {
          _this.form = res.data
          _this.form.orderTime = _this.timeFormat(_this.form.orderTime)
        })
    },
    getOrderRecord: function() {
      let _this = this
      this.axios
        .post(
          qualityUrl +
            '/order/getRecordsPage.do?orderNo=' +
            this.parentModel.orderNo +
            '&pagesize=' +
            this.pagesize +
            '&pageindex=' +
            this.pageindex
        )
        .then((res) => {
          if (res.data) {
            _this.recordLists = res.data.Data
            _this.totalCount = res.data.Count
          }
          // console.log(_this.recordLists)
        })
    },
    jumpToSubmiter: function(orderNo) {
      console.log(orderNo)
      if (this.parentModel.qaScoreType === 1) {
        if (
          this.parentModel.fromUrl == 'reInspectionSamplingOrder' ||
          this.parentModel.fromUrl == 'taskOrderMonitor' ||
          this.parentModel.fromUrl == 'myQaTasksOrder'
        ) {
          this.$emit('childMessage', 'qualityScoreS')
        } else {
          this.$emit('childMessage', 'orderQualityScoreSubmitter')
        }
      } else {
        this.$emit('childMessage', 'secQualityScore')
      }
    },
    jumpToRecord: function(callId) {
      this.$emit('recordMessage', callId)
    },
    jumpToCall: function(callId, seatName, seatNo) {
      console.log(callId)
      let call = {}
      call.callId = callId
      call.seatName = seatName
      call.seatNo = seatNo
      call.qaScoreType = this.parentModel.qaScoreType
      this.$emit('jumpToCall', call)
    },
    timeFormatter: function(row, column) {
      let date = row[column.property]
      if (date == undefined) {
        return ''
      }
      let fdate = formatdate.formatDate(parseInt(date))
      return fdate
    },
    clickCallColumn: function(row, event, column) {
      this.activeName = 'customerDetail'
      this.custormInfo = row
      this.esResultModel = row
      this.getPlayInfo(row.callId)
      this.custormInfo.callSTime = this.timeFormatter(this.custormInfo.callSTime)
      this.custormInfo.callETime = this.timeFormatter(this.custormInfo.callETime)
    },
    timeFormat: function(date) {
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
  },
  props: ['parentModel'],
  watch: {
    parentModel: {
      handler(newValue, oldValue) {
        if (newValue.orderNo != undefined) {
          console.log('parentModel变化了')
          this.reSetData()
          this.getOrderDetail()
          this.getOrderRecord()
        }
      },
      deep: true,
    },
  },
}
</script>
<style lang="less" scope="scoped">
.el-input {
  width: 200px;
}
.el-select-dropdown {
  z-index: 100000 !important;
}
.page-recording {
  text-align: right;
  position: fixed;
  bottom: 15px;
  right: 30px;
}
</style>
