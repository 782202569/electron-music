<template>
  <div class="tagManageContainer" id="tagManageContainer">
    <el-tabs v-model="activeName" @tab-click="changeTab">
      <el-tab-pane label="客户标签" name="1">
        <div class="contents">
          <div class="operation">
            <div class="searchForm">
              <el-form :inline="true">
                <el-form-item>
                  <el-button type="primary" @click="newTag">新建</el-button>
                </el-form-item>
                <el-form-item>
                  <el-button @click="batchDelete">批量删除</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
          <div class="tableContent">
            <el-table
              ref="multipleTable"
              :data="customTableData"
              border
              tooltip-effect="dark"
              style="width: 100%;"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column label="标签名称" prop="labelName" width="180">
              </el-table-column>
              <el-table-column prop="filterCount" label="筛选数量" width="120">
              </el-table-column>
              <el-table-column prop="linkRelativeRatio" width="150" label="环比">
              </el-table-column>
              <el-table-column prop="keyword" label="关键词 "> </el-table-column>
              <el-table-column
                prop="executeTime"
                :formatter="createTimeFilter"
                label="执行时间"
              >
              </el-table-column>
              <el-table-column prop="teloperate" width="250" label="操作">
                <template scope="scope">
                  <i
                    class="operate-btn el-icon-document"
                    @click="showDetailCustom(scope.row.labelConfigId)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;">查看</i></i
                  >
                  <i class="operate-btn el-icon-edit" @click="customTagEdit(scope.row)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;">编辑</i></i
                  >
                  <i
                    class="operate-btn el-icon-close"
                    @click="deleteTag(scope.row.labelName, scope.row.labelConfigId)"
                    ><i style="font-family: '微软雅黑';margin-left:5px;font-size:14px;"
                      >删除</i
                    ></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="客服标签" name="2">
        <div class="contents">
          <div class="operation">
            <div class="searchForm">
              <el-form :inline="true">
                <el-form-item>
                  <el-button type="primary" @click="newTag">新建</el-button>
                </el-form-item>
                <el-form-item>
                  <el-button @click="batchDelete">批量删除</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
          <div class="tableContent">
            <el-table
              ref="multipleTable"
              :data="agentTableData"
              border
              tooltip-effect="dark"
              style="width: 100%;"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column label="标签名称" prop="labelName" width="180">
              </el-table-column>
              <el-table-column prop="filterCount" label="筛选数量" width="120">
              </el-table-column>
              <el-table-column prop="linkRelativeRatio" width="150" label="环比">
              </el-table-column>
              <el-table-column prop="keyword" label="关键词 "> </el-table-column>
              <el-table-column
                prop="executeTime"
                :formatter="createTimeFilter"
                label="执行时间"
              >
              </el-table-column>
              <el-table-column prop="teloperate" width="250" label="操作">
                <template scope="scope">
                  <i
                    class="operate-btn el-icon-document"
                    @click="showDetailAgent(scope.row.labelConfigId)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;">查看</i></i
                  >
                  <i class="operate-btn el-icon-edit" @click="agentTagEdit(scope.row)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;">编辑</i></i
                  >
                  <i
                    class="operate-btn el-icon-close"
                    @click="deleteTag(scope.row.labelName, scope.row.labelConfigId)"
                    ><i style="font-family: '微软雅黑';margin-left:5px;font-size:14px;"
                      >删除</i
                    ></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </el-tab-pane>
    </el-tabs>
    <!--新建客户标签-->
    <el-dialog
      :title="dialogTitle"
      :close-on-click-modal="false"
      :visible.sync="dialogVisibleCustom"
    >
      <div class="dialogContainer">
        <el-form
          :model="customTagform"
          label-width="150px"
          ref="customTagform"
          :rules="customTagformRule"
        >
          <el-form-item label="标签名称" prop="labelName">
            <el-input v-model="customTagform.labelName"></el-input>
          </el-form-item>
          <el-form-item label="客户来电次数">
            <el-col :span="11">
              <el-form-item prop="incomingCountMin">
                <el-input v-model="customTagform.incomingCountMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="incomingCountMax">
                <el-input v-model="customTagform.incomingCountMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item label="通话平均回合占比(%)">
            <el-col :span="11">
              <el-form-item prop="callTurnRatioMin">
                <el-input v-model="customTagform.callTurnRatioMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="callTurnRatioMax">
                <el-input v-model="customTagform.callTurnRatioMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item label="通话平均时长占比(%)">
            <el-col :span="11">
              <el-form-item prop="longDurationCallMin">
                <el-input v-model="customTagform.longDurationCallMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="longDurationCallMax">
                <el-input v-model="customTagform.longDurationCallMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item label="平均通话时长(秒)">
            <el-col :span="11">
              <el-form-item prop="talkTimeMin">
                <el-input v-model="customTagform.talkTimeMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="talkTimeMax">
                <el-input v-model="customTagform.talkTimeMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item prop="keyword" label="关键词组合">
            <el-input
              type="textarea"
              v-model="customTagform.keyword"
              id="customKeywordZuhe"
              :rows="10"
            ></el-input>
          </el-form-item>
          <div class="keywordstyle">
            <span class="spanStyle" @click="insertAtCursor('OR', 'custom')">OR</span>
            <span class="spanStyle" @click="insertAtCursor('AND', 'custom')">AND</span>
            <span class="spanStyle" @click="insertAtCursor('NOT', 'custom')">NOT</span>
            <span class="spanStyle" @click="insertAtCursor('NEAR', 'custom')">NEAR</span>
            <span class="spanStyle" @click="insertAtCursor('BEFORE', 'custom')"
              >BEFORE</span
            >
            <span class="spanStyle" @click="insertAtCursor('AFTER', 'custom')"
              >AFTER</span
            >
            <span class="spanStyle" @click="insertAtCursor('()', 'custom')">()</span>
            <el-form-item prop="role" class="roleClass" label-width="10px">
              <el-radio-group v-model="customTagform.role" style="display:inline-block;">
                <el-radio label="2">客服</el-radio>
                <el-radio label="1">客户</el-radio>
                <el-radio label="0">全部</el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisibleCustom = false">取 消</el-button>
        <el-button type="primary" @click="saveCustomerLabelThrottle">确 定</el-button>
      </span>
    </el-dialog>
    <!--新建客服标签-->
    <el-dialog
      :title="dialogTitle"
      :close-on-click-modal="false"
      :visible.sync="dialogVisibleAgent"
    >
      <div class="dialogContainer">
        <el-form
          :model="agentTagform"
          label-width="150px"
          ref="agentTagform"
          :rules="customTagformRule"
        >
          <el-form-item label="标签名称" prop="labelName">
            <el-input v-model="agentTagform.labelName"></el-input>
          </el-form-item>
          <el-form-item label="平均语速(秒)">
            <el-col :span="11">
              <el-form-item prop="averageSpeedMin">
                <el-input v-model="agentTagform.averageSpeedMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="averageSpeedMax">
                <el-input v-model="agentTagform.averageSpeedMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item label="通话平均回合占比(%)">
            <el-col :span="11">
              <el-form-item prop="callTurnRatioMin">
                <el-input v-model="agentTagform.callTurnRatioMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="callTurnRatioMax">
                <el-input v-model="agentTagform.callTurnRatioMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item label="通话平均时长占比(%)">
            <el-col :span="11">
              <el-form-item prop="longDurationCallMin">
                <el-input v-model="agentTagform.longDurationCallMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="longDurationCallMax">
                <el-input v-model="agentTagform.longDurationCallMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item label="成功单数量">
            <el-col :span="11">
              <el-form-item prop="successOrderNumMin">
                <el-input v-model="agentTagform.successOrderNumMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="successOrderNumMax">
                <el-input v-model="agentTagform.successOrderNumMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item label="成功单平均通话次数">
            <el-col :span="11">
              <el-form-item prop="successOrderRatioMin">
                <el-input v-model="agentTagform.successOrderRatioMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="successOrderRatioMax">
                <el-input v-model="agentTagform.successOrderRatioMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item label="成功率">
            <el-col :span="11">
              <el-form-item prop="successRateMin">
                <el-input v-model="agentTagform.successRateMin"></el-input>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="successRateMax">
                <el-input v-model="agentTagform.successRateMax"></el-input>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item prop="keyword" label="关键词组合">
            <el-input
              type="textarea"
              v-model="agentTagform.keyword"
              id="agentKeywordZuhe"
              :rows="10"
            ></el-input>
          </el-form-item>
          <div class="keywordstyle">
            <span class="spanStyle" @click="insertAtCursor('OR', 'agent')">OR</span>
            <span class="spanStyle" @click="insertAtCursor('AND', 'agent')">AND</span>
            <span class="spanStyle" @click="insertAtCursor('NOT', 'agent')">NOT</span>
            <span class="spanStyle" @click="insertAtCursor('NEAR', 'agent')">NEAR</span>
            <span class="spanStyle" @click="insertAtCursor('BEFORE', 'agent')"
              >BEFORE</span
            >
            <span class="spanStyle" @click="insertAtCursor('AFTER', 'agent')">AFTER</span>
            <span class="spanStyle" @click="insertAtCursor('()', 'agent')">()</span>
            <el-form-item prop="role" class="roleClass" label-width="10px">
              <el-radio-group v-model="agentTagform.role" style="display:inline-block;">
                <el-radio label="2">客服</el-radio>
                <el-radio label="1">客户</el-radio>
                <el-radio label="0">全部</el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisibleAgent = false">取 消</el-button>
        <el-button type="primary" @click="saveAgentLabelThrottle">确 定</el-button>
      </span>
    </el-dialog>
    <!--查看客户标签结果-->
    <el-dialog
      title="查看标签结果"
      :close-on-click-modal="false"
      :visible.sync="dialogVisibleDetailCustom"
    >
      <div class="details">
        <el-table
          ref="multipleTable"
          :data="detailDataCustom"
          border
          tooltip-effect="dark"
          style="width: 100%;"
          @selection-change="handleSelectionChange"
        >
          <el-table-column label="客户电话号码" prop="customerId" width="200">
          </el-table-column>
          <el-table-column prop="labelName" label="标签名称">
            <template scope="scope">
              <el-tag type="primary">{{ scope.row.labelName }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="callCount" width="180" label="客户来电次数">
          </el-table-column>
          <el-table-column
            prop="custCallRoundPerAvg"
            width="180"
            :formatter="toPercentage"
            label="通话平均回合占比"
          >
          </el-table-column>
          <el-table-column
            prop="callTimeAvg"
            width="180"
            :formatter="toSeconds"
            label="平均通话时长"
          >
          </el-table-column>
          <el-table-column
            prop="custCallTimePerAvg"
            :formatter="toPercentage"
            width="180"
            label="通话平均时长占比"
          >
          </el-table-column>
        </el-table>
        <el-pagination
          @size-change="detailSizeChange"
          @current-change="detailCurrentChange"
          :current-page="currentDetailPage"
          :page-sizes="pageSizes"
          :page-size="detailPageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="detailTotal"
        >
        </el-pagination>
      </div>
    </el-dialog>
    <!--查看客服标签结果-->
    <el-dialog
      title="查看标签结果"
      :close-on-click-modal="false"
      :visible.sync="dialogVisibleDetailAgent"
    >
      <div class="details">
        <el-table
          ref="multipleTable"
          :data="detailDataAgent"
          border
          tooltip-effect="dark"
          style="width: 100%;"
          @selection-change="handleSelectionChange"
        >
          <el-table-column label="客服姓名" prop="seatName" width="200">
          </el-table-column>
          <el-table-column label="标签名称">
            <template scope="scope">
              <el-tag type="primary">{{ scope.row.labelName }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column
            prop="callTimeAvg"
            width="180"
            :formatter="toSeconds"
            label="平均通话时长"
          >
          </el-table-column>
          <el-table-column
            prop="seatCallRoundPerAvg"
            width="180"
            :formatter="toPercentage"
            label="通话平均回合占比"
          >
          </el-table-column>
          <el-table-column
            prop="seatCallTimePerAvg"
            width="180"
            :formatter="toPercentage"
            label="通话平均时长占比"
          >
          </el-table-column>
          <el-table-column
            prop="avgSpeedAvg"
            width="180"
            :formatter="setDecimals"
            label="平均语速"
          >
          </el-table-column>
        </el-table>
        <el-pagination
          @size-change="detailSizeChange"
          @current-change="detailCurrentChange"
          :current-page="currentDetailPage"
          :page-sizes="pageSizes"
          :page-size="detailPageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="detailTotal"
        >
        </el-pagination>
      </div>
    </el-dialog>
  </div>
</template>
<script type="text/ecmascript-6">
import qs from 'qs'
import moment from 'moment'
import CommonUtil from '../../../utils/commonUtil.js'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl

export default {
  data() {
    let validateLabelName = (rule, value, callback) => {
      if (value.replace(/\s/g, '') === '') {
        callback(new Error('标签名称不能全为空格'))
      } else {
        callback()
      }
    }
    return {
      activeName: '1',
      currentPage: 1,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      customTagformRule: {
        labelName: [
          { required: true, message: '标签名称不能为空', trigger: 'blur' },
          { min: 1, max: 30, message: '标签名称不能超过30个字', trigger: 'blur' },
          { validator: validateLabelName, trigger: 'blur' },
        ],
        keyword: [
          { min: 0, max: 250, message: '长度在 0 到 250 个字符之间', trigger: 'blur' },
        ],
      },
      agentTableData: [], // 客服标签
      customTableData: [], // 客户标签
      dialogVisibleAgent: false,
      dialogVisibleCustom: false,
      customTagform: {
        // 客户标签的数据
        labelName: '', // 标签名称
        incomingCountMax: '', // 客户当月来电次数MAX
        incomingCountMin: '', // 客户当月来电次数MIN
        callTurnRatioMax: '', // 客户通话平均回合占比MAX
        callTurnRatioMin: '', // 客户通话平均回合占比MIN
        longDurationCallMax: '', // 客户通话平均时长占比MAX
        longDurationCallMin: '', // 客户通话平均时长占比MIN
        talkTimeMax: '', // 客户当月平均通话时长MAX
        talkTimeMin: '', // 客户当月平均通话时长MIN
        role: '1',
        keyword: '',
      },
      agentTagform: {
        labelName: '', // 标签名称
        averageSpeedMax: '', // 平均语速MAX
        averageSpeedMin: '', // 平均语速MIN
        callTurnRatioMax: '', // 客服通话平均回合占比MAX
        callTurnRatioMin: '', // 客服通话平均回合占比MIN
        longDurationCallMax: '', // 客服通话平均时长占比MAX
        longDurationCallMin: '', // 客服通话平均时长占比MIN
        talkTimeMax: '', // 客服当月平均通话时长MAX
        talkTimeMin: '', // 客服平均通话时长MIN
        successOrderNumMax: '', // 成功单数量MAX
        successOrderNumMin: '', // 成功单数量MIN
        successOrderRatioMax: '', // 成功单平均通话次数MAX
        successOrderRatioMin: '', // 成功单平均通话次数MIN
        successRateMax: '', // 成功率MAX
        successRateMin: '', // 成功率MIN
        role: '2',
        keyword: '',
      },
      tagScriptRole: '1', // 新建标签的默认角色
      keywordContextagent: '', // 客服组合关键词的内容
      keywordContextcustom: '', // 客户组合关键词的内容
      checkedItems: [], // 选中的列表
      dialogTitle: '新建标签',
      currentDetailPage: 1,
      detailPageSize: 20,
      detailTotal: 0,
      detailDataCustom: [],
      detailDataAgent: [],
      dialogVisibleDetailCustom: false,
      dialogVisibleDetailAgent: false,
      currentRecordId: '',
    }
  },
  methods: {
    changeTab(tab, event) {
      this.activeName = tab.name
      this.checkedItems = []
      if (tab.name === '1') {
        // 获取客户标签
        this.getAllIvsCustomerLabel()
      } else {
        // 获取客服标签
        this.getAllIvsServiceLabel()
      }
      this.currentPage = 1
    },
    // 获取客服标签
    getAllIvsServiceLabel() {
      let _this = this
      let params = {}
      params.pagesize = this.pageSize
      params.pageindex = this.currentPage
      this.axios
        .post(
          currentBaseUrl + '/serviceLabel/getAllIvsServiceLabel.do',
          qs.stringify(params)
        )
        .then(function(response) {
          _this.agentTableData = response.data.Data
          _this.total = response.data.Count
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取客服标签出现问题',
          })
        })
    },
    // 获取客户标签
    getAllIvsCustomerLabel() {
      let _this = this
      let params = {}
      params.pagesize = this.pageSize
      params.pageindex = this.currentPage
      this.axios
        .post(
          currentBaseUrl + '/serviceLabel/getAllIvsCustomerLabel.do',
          qs.stringify(params)
        )
        .then(function(response) {
          _this.customTableData = response.data.Data
          _this.total = response.data.Count
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取客户标签出现问题',
          })
        })
    },
    saveCustomerLabelThrottle() {
      this.lodashThrottle.throttle(this.saveCustomerLabel, this)
    },
    // 保存客户标签
    saveCustomerLabel() {
      this.$refs.customTagform.validate((valid) => {
        if (!valid) {
          return false
        } else {
          if (!this.checkCustomerLabel()) {
            return false
          }
          let _this = this
          let params = {}
          this.customTagform.labelName = this.customTagform.labelName.replace(
            /(^\s+) | (\s+$)/g,
            ''
          )
          params.customerTableObjValString = JSON.stringify(this.customTagform)
          this.axios
            .post(
              currentBaseUrl + '/serviceLabel/saveCustomerLabel.do',
              qs.stringify(params)
            )
            .then(function(response) {
              if (response.data && response.data.result === 1) {
                _this.$message({
                  type: 'success',
                  message: '标签保存成功',
                })
                _this.dialogVisibleCustom = false
                _this.getAllIvsCustomerLabel()
              } else if (response.data && response.data.result === -1) {
                _this.$message({
                  type: 'error',
                  message: response.data.message,
                })
              } else {
                return Promise.reject()
              }
            })
            .catch(function() {
              _this.$message({
                type: 'error',
                message: '标签保存失败',
              })
            })
        }
      })
    },
    // 检查输入的客户条件是否符合要求
    checkCustomerLabel() {
      if (
        !this.customTagform.incomingCountMax &&
        !this.customTagform.incomingCountMin &&
        !this.customTagform.callTurnRatioMax &&
        !this.customTagform.callTurnRatioMin &&
        !this.customTagform.longDurationCallMax &&
        !this.customTagform.longDurationCallMin &&
        !this.customTagform.talkTimeMax &&
        !this.customTagform.talkTimeMin &&
        !this.customTagform.keyword
      ) {
        this.$message({
          type: 'error',
          message: '除标签名称与角色外，其他内容至少选填一项',
        })
        return false
      } else if (
        !this.checkMinAndMax('incomingCount', 'customTagform') ||
        !this.checkMinAndMax('callTurnRatio', 'customTagform') ||
        !this.checkMinAndMax('longDurationCall', 'customTagform') ||
        !this.checkMinAndMax('talkTime', 'customTagform')
      ) {
        this.$message({
          type: 'error',
          message: '条件最小值应该小于最大值',
        })
        return false
      } else {
        return true
      }
    },
    // 判断最大值是否大于最小值
    checkMinAndMax(labelName, obj) {
      let min = labelName + 'Min'
      let max = labelName + 'Max'
      if (this[obj][min] && this[obj][max] && this[obj][max] - this[obj][min] < 0) {
        return false
      } else {
        return true
      }
    },
    // 检查输入的客服条件是否符合要求
    checkAgentLabel() {
      if (
        !this.agentTagform.averageSpeedMax &&
        !this.agentTagform.averageSpeedMin &&
        !this.agentTagform.callTurnRatioMax &&
        !this.agentTagform.callTurnRatioMin &&
        !this.agentTagform.longDurationCallMax &&
        !this.agentTagform.longDurationCallMin &&
        !this.agentTagform.talkTimeMax &&
        !this.agentTagform.talkTimeMin &&
        !this.agentTagform.successOrderNumMax &&
        !this.agentTagform.successOrderNumMin &&
        !this.agentTagform.successOrderRatioMax &&
        !this.agentTagform.successOrderRatioMin &&
        !this.agentTagform.successRateMax &&
        !this.agentTagform.successRateMin &&
        !this.agentTagform.keyword
      ) {
        this.$message({
          type: 'error',
          message: '除标签名称与角色外，其他内容至少选填一项',
        })
        return false
      } else if (
        !this.checkMinAndMax('averageSpeed', 'agentTagform') ||
        !this.checkMinAndMax('callTurnRatio', 'agentTagform') ||
        !this.checkMinAndMax('longDurationCall', 'agentTagform') ||
        !this.checkMinAndMax('talkTime', 'agentTagform') ||
        !this.checkMinAndMax('successOrderNum', 'agentTagform') ||
        !this.checkMinAndMax('successOrderRatio', 'agentTagform') ||
        !this.checkMinAndMax('successRate', 'agentTagform')
      ) {
        this.$message({
          type: 'error',
          message: '条件最小值应该小于最大值',
        })
        return false
      } else {
        return true
      }
    },
    // 保存客服标签
    saveAgentLabelThrottle() {
      this.lodashThrottle.throttle(this.saveAgentLabel, this)
    },
    saveAgentLabel() {
      this.$refs.agentTagform.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let _this = this
          if (!this.checkAgentLabel()) {
            return false
          }
          let params = {}
          this.customTagform.labelName = this.customTagform.labelName.replace(
            /(^\s+) | (\s+$)/g,
            ''
          )
          params.ivsServiceLabelString = JSON.stringify(this.agentTagform)
          this.axios
            .post(
              currentBaseUrl + '/serviceLabel/saveIServiceLabel.do',
              qs.stringify(params)
            )
            .then(function(response) {
              if (response.data && response.data.result === 1) {
                _this.$message({
                  type: 'success',
                  message: '标签保存成功',
                })
                _this.dialogVisibleAgent = false
                _this.getAllIvsServiceLabel()
              } else if (response.data && response.data.result === -1) {
                _this.$message({
                  type: 'error',
                  message: response.data['message'],
                })
              } else {
                return Promise.reject()
              }
            })
            .catch(function() {
              _this.$message({
                type: 'error',
                message: '标签保存失败',
              })
            })
        }
      })
    },
    // 点击编辑客户标签按钮
    customTagEdit(obj) {
      this.dialogVisibleCustom = true
      this.$nextTick(() => {
        this.$refs.customTagform.resetFields()
        let temp = JSON.stringify(obj)
        this.customTagform = JSON.parse(temp)
        this.dialogTitle = '编辑标签'
      })
    },
    // 点击编辑客户标签按钮
    agentTagEdit(obj) {
      let temp = JSON.stringify(obj)
      this.agentTagform = JSON.parse(temp)
      this.dialogTitle = '编辑标签'
      this.dialogVisibleAgent = true
      this.$nextTick(() => {
        this.$refs.agentTagform.resetFields()
        let temp = JSON.stringify(obj)
        this.agentTagform = JSON.parse(temp)
        this.dialogTitle = '编辑标签'
      })
    },
    // 删除提示
    deleteTag(name, id) {
      let _this = this
      this.$confirm('确定要删除标签' + '[' + name + ']吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          if (_this.activeName === '1') {
            _this.deleteCustomerLabel(id)
          } else if (_this.activeName === '2') {
            _this.deleteServiceLabel(id)
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 批量删除提示
    batchDelete() {
      let _this = this
      let len = this.checkedItems.length
      if (len < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择要删除的记录',
        })
        return false
      }
      let ids = []
      let names = []
      for (let i = 0; i < len; i++) {
        ids.push(this.checkedItems[i].labelConfigId)
        if (i < 3) {
          names.push(this.checkedItems[i].labelName)
        }
      }
      this.$confirm('确定要删除[' + names.join(',') + ']等' + len + '个标签?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          if (_this.activeName === '1') {
            _this.deleteCustomerLabel(ids.join(','))
          } else if (_this.activeName === '2') {
            _this.deleteServiceLabel(ids.join(','))
          }
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 删除客户标签
    deleteCustomerLabel(ids) {
      let _this = this
      let params = {}
      params.ivsCustomerLabel = {}
      params.ivsCustomerLabel.labelConfigId = ids
      params.ivsCustomerLabel = JSON.stringify(params.ivsCustomerLabel)
      this.axios
        .post(
          currentBaseUrl + '/serviceLabel/deleteCustomerLabel.do',
          qs.stringify(params)
        )
        .then(function(response) {
          _this.$message({
            type: 'success',
            message: '删除成功!',
          })
          _this.getAllIvsCustomerLabel()
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '删除出现问题',
          })
        })
    },
    // 删除客服标签
    deleteServiceLabel(ids) {
      let _this = this
      let params = {}
      params.labelIds = ids
      this.axios
        .post(
          currentBaseUrl + '/serviceLabel/deleteServiceLabels.do',
          qs.stringify(params)
        )
        .then(function(response) {
          _this.$message({
            type: 'success',
            message: '删除成功!',
          })
          _this.getAllIvsServiceLabel()
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '删除出现问题',
          })
        })
    },
    createTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
      return ''
    },
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    detailSizeChange(val) {
      this.detailPageSize = val
    },
    detailCurrentChange(val) {
      this.currentDetailPage = val
    },
    handleSelectionChange(val) {
      this.checkedItems = val
    },
    newTag() {
      // 新建标签
      this.dialogTitle = '新建标签'
      if (this.activeName === '1') {
        this.dialogVisibleCustom = true
        this.$nextTick(() => {
          this.$refs.customTagform.resetFields()
          this.customTagform = { role: '1' }
        })
      } else {
        this.dialogVisibleAgent = true
        this.$nextTick(() => {
          this.$refs.agentTagform.resetFields()
          this.agentTagform = { role: '2' }
        })
      }
    },
    insertAtCursor(myValue, role) {
      let selector = '#' + role + 'KeywordZuhe textarea'
      let myField = document.querySelector(selector)
      // IE 浏览器
      if (document.selection) {
        myField.focus()
        let sel = document.selection.createRange()
        sel.text = myValue
        sel.select()
        // FireFox、Chrome等
      } else if (myField.selectionStart || myField.selectionStart == '0') {
        let startPos = myField.selectionStart
        let endPos = myField.selectionEnd
        // 保存滚动条
        let restoreTop = myField.scrollTop
        myField.value =
          myField.value.substring(0, startPos) +
          ' ' +
          myValue +
          ' ' +
          myField.value.substring(endPos, myField.value.length)
        if (restoreTop > 0) {
          myField.scrollTop = restoreTop
        }
        myField.focus()
        myField.selectionStart = startPos + myValue.length + 2
        myField.selectionEnd = startPos + myValue.length + 2
      } else {
        myField.value += myValue
        myField.focus()
      }
      if (role === 'agent') {
        this.agentTagform.keyword = myField.value
      } else {
        this.customTagform.keyword = myField.value
      }
    },
    showDetailCustom(id) {
      // 获取标签数据
      this.getCustomerLabelResults(id)
      this.currentDetailPage = 1
      this.detailPageSize = 20
      this.dialogVisibleDetailCustom = true
      this.currentRecordId = id
    },
    showDetailAgent(id) {
      // 获取标签数据
      this.getSeatLabelResults(id)
      this.currentDetailPage = 1
      this.detailPageSize = 20
      this.dialogVisibleDetailAgent = true
      this.currentRecordId = id
    },
    // 获取客户标签详情
    getCustomerLabelResults(id) {
      let _this = this
      let params = {}
      params.pageSize = this.detailPageSize
      params.pageNumber = this.currentDetailPage
      params.labelConfigId = id
      let url = ''
      url = currentBaseUrl + '/serviceLabel/getCustomerLabelResults.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.state === '1') {
            _this.detailDataCustom = response.data.results
            _this.detailTotal = response.data.count
          } else {
            return Promise.reject()
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取标签结果失败',
          })
        })
    },
    // 获取客服标签详情
    getSeatLabelResults(id) {
      let _this = this
      let params = {}
      params.pageSize = this.detailPageSize
      params.pageNumber = this.currentDetailPage
      params.labelConfigId = id
      let url = currentBaseUrl + '/serviceLabel/getSeatLabelResults.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.state === '1') {
            _this.detailDataAgent = response.data.results
            _this.detailTotal = response.data.count
          } else {
            return Promise.reject()
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取标签结果失败',
          })
        })
    },
    toSeconds(row, column, cellValue) {
      let time = CommonUtil.formateTime(cellValue / 1000)
      return time
    },
    toPercentage(row, column, cellValue) {
      return (cellValue * 100).toFixed(2) + '%'
    },
    setDecimals(row, column, cellValue) {
      return cellValue.toFixed(2)
    },
  },
  created() {
    this.getAllIvsCustomerLabel()
  },
  watch: {
    pageSize() {
      if (this.activeName == 1) {
        this.getAllIvsCustomerLabel()
      } else {
        this.getAllIvsServiceLabel()
      }
    },
    currentPage() {
      if (this.activeName === '1') {
        // 获取客户标签
        this.getAllIvsCustomerLabel()
      } else {
        // 获取客服标签
        this.getAllIvsServiceLabel()
      }
    },
    detailPageSize() {
      if (this.activeName === '1') {
        // 获取客户标签详情
        this.getCustomerLabelResults(this.currentRecordId)
      } else {
        // 获取客服标签详情
        this.getSeatLabelResults(this.currentRecordId)
      }
    },
    currentDetailPage() {
      if (this.activeName === '1') {
        // 获取客户标签详情
        this.getCustomerLabelResults(this.currentRecordId)
      } else {
        // 获取客服标签详情
        this.getSeatLabelResults(this.currentRecordId)
      }
    },
  },
}
</script>
<style lang="less">
@border-color: #d1dbe5;
// 修改组件样式
.tagManageContainer {
  .el-tabs__header {
    margin: 0px;
  }
  .operation .el-form-item {
    margin-bottom: 0px;
    .el-form-item__content {
      line-height: 55px;
    }
  }
  .el-tabs {
    height: 100%;
    width: 100%;
    .el-tabs__content {
      width: 100%;
      position: absolute;
      top: 40px;
      left: 0;
      bottom: 0;
      right: 0;
      .el-tab-pane {
        width: 100%;
        height: 100%;
      }
    }
  }
  .el-tabs__header {
    background-color: #eef1f6;
  }
  .el-tabs__active-bar {
    display: none;
  }
  .contents {
    .el-pagination {
      position: absolute;
      bottom: 0;
      left: 10px;
      right: 10px;
      text-align: right;
      height: 40px;
      padding-top: 6px;
    }
  }
  .el-select {
    width: 100%;
  }
  .el-dialog__body {
    padding: 10px 20px;
  }
}
// 页面样式
.tagManageContainer {
  padding: 3px 0 0;
  height: 100%;
  position: relative;
  box-sizing: border-box;
  div {
    box-sizing: border-box;
  }
  .line {
    text-align: center;
  }
  .operation {
    position: absolute;
    height: 55px;
    line-height: 55px;
    top: 0px;
    left: 0;
    right: 10px;
    border-bottom: 1px dashed @border-color;
  }
  .contents {
    position: absolute;
    width: 100%;
    height: 100%;
    padding: 0px 10px;
    .operation > div {
      display: inline-block;
      text-align: right;
      button {
        width: 90px;
      }
      &.searchForm {
        position: absolute;
        right: -10px;
      }
    }
    .tableContent {
      padding: 10px 0px 10px 10px;
      position: absolute;
      top: 60px;
      left: 0;
      right: 10px;
      bottom: 40px;
      overflow-y: auto;
    }
  }
  .contentRight {
    border-left: 1px solid @border-color;
  }
  .btns {
    text-align: right;
  }
  .dialogContainer {
    padding: 20px;
    position: relative;
  }
  .el-dialog__footer {
    margin-right: 20px;
  }
  .spanStyle {
    display: inline-block;
    border: 1px solid #ddd;
    text-align: center !important;
    width: 60px !important;
    margin-right: 5px;
    margin-left: 5px;
    border-radius: 4px;
    cursor: pointer;
    line-height: 20px;
  }
  @media screen and (min-width: 1366px) and (max-width: 1919px) {
    .keywordstyle {
      position: absolute;
      bottom: -40px;
      left: 170px;
    }
    .el-dialog__footer {
      margin-top: 15px;
    }
  }
  @media screen and (min-width: 1920px) {
    .keywordstyle {
      position: absolute;
      bottom: -10px;
      left: 170px;
    }
  }
  .roleClass {
    display: inline-block;
    text-align: left;
    margin-bottom: 0px;
  }
  .operate-btn {
    cursor: pointer;
    margin-right: 10px;
  }
  .details {
    .el-pagination {
      text-align: right;
      margin: 10px 0px;
    }
    .footer {
      text-align: right;
    }
  }
}
</style>
