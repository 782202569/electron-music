<template>
  <div>
    <div @click="allClick">
      <div class="themTitle">
        <div class="themLeft">
          专题分析
        </div>
        <div class="themRight" style="position: relative;">
          <el-form :inline="true" class="themFrom">
            <div id="treeSpan" v-show="hideTree" @click="etreeShow">
              <el-tree
                :data="data"
                :props="defaultProps"
                :expand-on-click-node="false"
                :check-on-click-node="true"
                :highlight-current="true"
                @node-click="allChangetu"
                ref="keyWordsMenu"
                node-key="id"
                :check-strictly="true"
                @node-expand="nodeCase(data)"
              >
              </el-tree>
            </div>
            <el-tooltip placement="top">
              <div slot="content">{{ treeValue }}</div>
              <div @click="deopShow" style="display: inline-block;">
                <el-input
                  v-model="treeValue"
                  ref="content"
                  class="newSetall"
                  style="width: 200px;cursor: pointer;"
                ></el-input>
              </div>
            </el-tooltip>
            <div v-show="treeDiv" class="treeCell" @click="changActiveall">
              <ul>
                <li
                  @click="changActive(index, item.label)"
                  class="newSetcss"
                  v-for="(item, index) in options"
                  :key="index"
                >
                  {{ item.label }}
                </li>
              </ul>
            </div>
            <el-date-picker
              v-model="formRight.times"
              type="datetimerange"
              :editable="false"
              :clearable="false"
              @change="treeChance"
              align="right"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :default-time="['00:00:00', '23:59:59']"
              style="width: 375px;"
            >
            </el-date-picker>
          </el-form>
          <el-popover placement="top" width="360" v-model="visible2">
            <el-checkbox-group v-model="checkFieldList" id="spellCheck">
              <el-checkbox
                v-for="item in fieldList"
                :label="item.field"
                :key="item.field"
                >{{ item.fieldName }}</el-checkbox
              >
            </el-checkbox-group>
            <div class="btnSet">
              <el-button size="mini" type="text" @click="visible2 = false"
                >取消</el-button
              >
              <el-button
                type="primary"
                size="mini"
                @click="checkFields"
                style="margin-right: 10px;"
                >确定</el-button
              >
            </div>
            <span class="show_fields themShow" slot="reference">自定义显示</span>
          </el-popover>
        </div>
      </div>
      <div class="lineTitle" v-show="callReason || callProvin">
        <div class="thematicTitleLeft" v-show="callReason">
          来电原因分析
        </div>
        <div class="thematicTitleRight" v-show="callProvin">
          <span>各地来电量分析</span>
          <span
            class="shCity"
            v-for="(item, index) in tabCitys"
            :class="{ changeActiveces: index == numCity }"
            :key="index"
            @click="tabCity(index)"
            >{{ item }}</span
          >
        </div>
      </div>
      <div
        id="diagram"
        v-show="callReason"
        class="soundfeature-pos-content"
        style="display: inline-block;width: 50%;height:400px;"
      ></div>
      <div v-show="callProvin" style="display: inline-block;width: 49%;height:400px;">
        <div
          id="shMap"
          v-show="cityChange"
          class="soundfeature-pos-content"
          style="display: inline-block;width: 100%;height:400px;"
        ></div>
        <div
          id="chinaMap"
          v-show="!cityChange"
          class="soundfeature-pos-content"
          style="display: inline-block;width: 100%;height:400px;"
        ></div>
      </div>
      <!-- <div v-show="crossAnsy">
        <div style="height: 50px;line-height: 50px;border-top: 1px solid #E4E4E4;">
          <div style="padding-left: 30px;font-size: 14px;color: #1F2D3D;font-weight: bold;">交叉分析</div>
        </div>
        <div style="padding-left: 30px;">
          <span style="font-size: 14px;">主维度</span>
          <el-select v-model="topValue" disabled placeholder="请选择" style="padding-left: 18px;">
          </el-select>
          <span style="padding-left: 97px;font-size: 14px;">副维度</span>
          <el-select v-model="groupName" placeholder="请选择" @change="changeDu" style="padding-left: 18px;">
            <el-option
              v-for="item in groupTime"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <el-select v-model="secondModel" ref="mySelect" placeholder="请选择" style="padding-left: 18px;">
            <div class="treePtionabc">
              <el-option :value="item.value">
                <el-tree
                  :data="groupData"
                  :props="groupProps"
                  ref="treeMenu"
                  :expand-on-click-node="false"
                  @node-click="handleNodeClick">
                </el-tree>
            </el-option>
            </div>
          </el-select>
        </div>
        <div id="cyDraw" class="soundfeature-pos-content" style="display: inline-block;width: 100%;height:320px;">
        </div>
      </div>
      <div style="border-top: 1px solid #E4E4E4;font-size: 14px;height: 500px;" v-show="hotSpot">
        <div style="width: 30%;height: 500px;overflow: hidden;border-right: 1px solid #E4E4E4;padding: 15px 30px;display: inline-block;float: left;">
          <div style="width: 100%;font-size: 14px;color: #1F2D3D;font-weight: bold;height: 35px;">热点分析</div>
          <div style="height: 50px;line-height: 50px;">
            <span>角色</span>
            <el-select v-model="searchModel.wordRole" @change="getQuShiCharts" placeholder="请选择" style="margin-left: 40px;width: 250px;">
              <el-option
                v-for="item in valuePeo"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </div>
          <div style="height: 50px;line-height: 50px;margin-bottom: 10px;">
            <span>热词统计</span>
            <el-button @click="removeKeyWord" style="margin-top:5px;margin-right: 20px;float: right;">存为水词</el-button>
            <el-button @click="addKeyWord" style="margin-top:5px;margin-right: 20px;float: right;">存为关键词</el-button>
          </div>
          <div class="drawTable" style="overflow: scroll;height: 100%;">
            <div class="scrollTable" style="overflow-y: auto;padding-bottom: 120px;">
              <el-table
                ref="multipleTable"
                highlight-current-row
                :data="tableCiData"
                border
                @selection-change="selectionChange"
                style="width: 100%">
                <el-table-column
                  type="selection"
                  width="55">
                </el-table-column>
                <el-table-column
                  type="index"
                  label="序号"
                  width="70">
                </el-table-column>
                <el-table-column
                  prop="keyword"
                  label="词语">
                </el-table-column>
                <el-table-column
                  prop="times"
                  label="热度"
                  show-overflow-tooltip>
                </el-table-column>
              </el-table>
            </div>
          </div>
        </div>
        <div style="width: 64%;display: inline-block;height: 480px;">
          <div class="pageChange">
            <ul>
              <li v-for="(item,index) in tabs" :class="{changeActive:index == num}" @click="tab(index)">{{item}}</li>
            </ul>
          </div>
          <div class="hotanalyseRight" style="clear: both;height: 100%;width: 100%;">
            <div class="hotBox" style="height: 100%;width: 100%;">
              <div id="trendChart" style="width: 100%; height: 100%;"></div>
              <div id="ciChart" style="width: 100%; height: 100%; display: none"></div>
              <div id="placeChart" style="width: 100%; height: 100%;display: none"></div>
            </div>
          </div>
        </div>
      </div>-->
      <div
        style="height: 50px;line-height: 50px;border-top: 1px solid #E4E4E4;clear: both;"
        v-show="recordingTime"
      >
        <div style="padding-left: 30px;font-size: 14px;color: #1F2D3D;font-weight: bold;">
          录音时段分析
        </div>
      </div>
      <div class="timeanalyse" v-show="recordingTime">
        <div class="timeanalyse-content" id="timeAnalyse"></div>
      </div>
    </div>
    <add-keyword
      :visible="addWordModalVisible"
      @cancel="addWordModalVisible = false"
      @success="addWordModalVisible = false"
      :title="addTitle"
      :words="keyword"
    />
    <add-waterword
      :visible="addWalterWordModalVisible"
      @cancel="addWalterWordModalVisible = false"
      @success="addWalterWordModalVisible = false"
      :title="addWalterTitle"
      :words="keyword"
    />
  </div>
</template>
<script>
import global from '@/global'
import $ from 'jquery'
import qs from 'qs'
import geoCoordMap from './geoCoordMap.js'
let currentBaseUrl = global.currentBaseUrl
let CASTGC = cache.getItem('tgt_id')
import cache from '../../../utils/cache.js' // 热点分析开始
import formatdate from '../../../utils/formatdate.js'
import addKeyword from '@/components/page/businessConfig/add_keyword_componnet.vue'
import addWaterword from '@/components/page/businessConfig/add_waterword_componnet.vue'
let myChartCi
export default {
  components: {
    addKeyword,
    addWaterword,
  },
  data() {
    return {
      addTitle: '',
      addWalterTitle: '',
      addWalterWordModalVisible: false,
      addWordModalVisible: false,
      visible2: false,
      treeDiv: false,
      hideTree: false,
      cityChange: true,
      callReason: true,
      callProvin: true,
      crossAnsy: true,
      hotSpot: true,
      recordingTime: true,
      topValue: '',
      naextID: '',
      secondModel: '',
      tableCiData: [],
      qushiVal: 0, // 热点分析那个图表展示
      qushiEchartsOption: {
        title: {
          text: '',
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: [],
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            boundaryGap: false,
            data: [],
            splitLine: {
              show: true,
            },
            axisLine: {
              show: false,
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: {
              show: true,
            },
            axisLine: {
              show: false,
            },
          },
        ],
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        series: [],
      }, // 热点分析 开始
      item: {
        value: '',
      },
      keyword: '',
      selectKeyWord: '',
      ghlgood: [],
      tabCitys: ['市区', '省份'],
      tabs: ['趋势图', '词相关', '区域图'],
      num: 0,
      numCity: 1,
      treeValue: '',
      searchModel: {
        buss_wordType: '1', // 词汇类型
        function: '1', // 统计的单位，1为录音量，2为平均时长，3为总通话时长
        wordRole: '0', // 角色 0为全部 1为客户 2为客服
      },
      groupData: [],
      groupProps: {
        children: 'children',
        label: 'label',
      },
      groupTime: [
        {
          value: 'seatGroup',
          label: '坐席组',
        },
        {
          value: 'area',
          label: '区域',
        },
        {
          value: 'sentiment',
          label: '情绪',
        },
      ],
      groupName: '',
      valuePeo: [
        {
          value: '0',
          label: '全部',
        },
        {
          value: '1',
          label: '客户',
        },
        {
          value: '2',
          label: '客服',
        },
      ],
      checkFieldList: [
        'callReason',
        'callProvin',
        'crossAnsy',
        'hotSpot',
        'recordingTime',
      ],
      fieldList: [
        {
          field: 'callReason',
          fieldName: '来电原因分析',
        },
        {
          field: 'callProvin',
          fieldName: '各省来电分析',
        },
        {
          field: 'crossAnsy',
          fieldName: '交叉分析',
        },
        {
          field: 'hotSpot',
          fieldName: '热点分析',
        },
        {
          field: 'recordingTime',
          fieldName: '录音时段分析',
        },
      ],
      data: [],
      datawer: [],
      defaultProps: {
        children: 'children',
        label: 'label',
      },
      options: [],
      formRight: {
        times: [],
        region: '',
      },
      treeMenu: [],
      option: {
        tooltip: {
          trigger: 'axis',
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        calculable: true,
        xAxis: [
          {
            name: '',
            show: true,
            splitLine: {
              show: true,
            },
            type: 'category',
            boundaryGap: false,
            data: [],
          },
        ],
        yAxis: [
          {
            type: 'value',
            show: true,
          },
        ],
        series: [],
      },
      cyfind: {
        color: ['#3398DB'],
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '15%',
          containLabel: true,
        },
        dataZoom: [
          {
            type: 'slider',
            show: true,
            xAxisIndex: [0],
            start: 1,
            end: 30,
            height: '5%',
            showDetail: false,
            bottom: 30,
          },
          {
            type: 'inside',
            xAxisIndex: [0],
            start: 1,
            end: 30,
            height: '5%',
          },
        ],
        xAxis: [
          {
            type: 'category',
            data: [],
            axisTick: {
              alignWithLabel: true,
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
          },
        ],
        series: [],
      },
      cioption: {
        title: {
          text: '', // 标题
        },
        label: {
          normal: {
            show: true,
            textStyle: {
              fontSize: 12,
            },
          },
        },
        // 全局颜色，图例、节点、边的颜色都是从这里取，按照之前划分的种类依序选取
        // color: ['rgb(194,53,49)', 'rgb(178,144,137)', 'rgb(97,160,168)'],
        // sereis的数据: 用于设置图表数据之用
        series: [
          {
            name: '', // 系列名称
            type: 'graph', // 图表类型
            layout: 'force', // echarts3的变化，force是力向图，circular是和弦图
            symbolSize: 45,
            // focusNodeAdjacency: true,  // 突出相关
            force: {
              // gravity: 0.1,
              // symbol: 'pin',
              edgeLength: [100, 10], // 线的长度，这个距离也会受 repulsion，支持设置成数组表达边长的范围
              repulsion: 200, // 节点之间的斥力因子。值越大则斥力越大
            },
            // draggable: true, // 指示节点是否可以拖动
            roam: true, // 是否开启鼠标缩放和平移漫游。默认不开启。如果只想要开启缩放或者平移，可以设置成 'scale' 或者 'move'。设置成 true 为都开启
            label: {
              // 图形上的文本标签，可用于说明图形的一些数据信息
              normal: {
                show: true, // 显示
                color: '#fff',
                position: 'inside', // 相对于节点标签的位置
                // 回调函数，你期望节点标签上显示什么
                formatter: function(params) {
                  return params.data.label
                },
              },
            },
            // 节点的style
            itemStyle: {
              normal: {
                label: { show: true },
                nodeStyle: {
                  brushType: 'both',
                  borderColor: 'rgba(255,215,0,0.4)',
                  borderWidth: 1,
                },
              },
            },
            // 关系边的公用线条样式
            lineStyle: {
              normal: {
                width: 3,
                type: 'solid',
                show: true,
                color: 'target', // 决定边的颜色是与起点相同还是与终点相同
                curveness: 0.3, // 边的曲度，支持从 0 到 1 的值，值越大曲度越大。
              },
            },
            categories: [],
            nodes: [],
            links: [],
          },
        ],
      },
      absf: [],
      opCity: {
        tooltip: {
          trigger: 'item',
          formatter: function(params) {
            let value = (params.value + '').split('.')
            value =
              value[0].replace(/(\d{1,3})(?=(?:\d{3})+(?!\d))/g, '$1,') + '.' + value[1]
            return params.seriesName + '<br/>' + params.name + ': ' + value
          },
        },
        visualMap: {
          type: 'continuous',
          min: 0,
          max: 100000,
          align: 'right',
          text: ['High', 'Low'],
          realtime: false,
          calculable: true,
          color: ['orangered', 'yellow', 'lightskyblue'],
        },
        series: [
          {
            name: 'World Population (2010)',
            type: 'map',
            mapType: 'china',
            roam: false,
            itemStyle: {
              emphasis: { label: { show: true } },
            },
            data: [
              { name: '陕西', value: 28397.812 },
              { name: '浙江', value: 19549.124 },
              { name: '新疆', value: 3150.143 },
            ],
          },
        ],
      },
      shCity: {
        tooltip: {
          trigger: 'item',
          formatter: function(params) {
            let arrghl = ''
            for (let i = 0; i < params.data.keyName.length; i++) {
              arrghl =
                arrghl + params.data.keyName[i] + ' : ' + params.data.values[i] + '<br/>'
            }
            return (
              '<span style="display:inline-block;border-radius:50%;background:lightskyblue;height:8px;width:8px;margin-right:5px;"></span>' +
              params.name +
              '<br/>' +
              arrghl
            )
          },
        },
        visualMap: {
          type: 'continuous',
          min: 0,
          max: 20,
          left: 'right',
          top: 'bottom',
          text: ['高', '低'],
          realtime: false,
          calculable: true,
          color: ['orangered', 'yellow', 'lightskyblue'],
        },
        series: [
          {
            name: 'World Population (2010)',
            type: 'map',
            mapType: 'china',
            roam: false,
            itemStyle: {
              emphasis: { label: { show: true } },
            },
            data: [],
          },
        ],
      },
    }
  },
  computed: {
    /* 专题ID */
    getThenaticAnalysisId() {
      return this.$store.state.thenaticAnalysisId.subjectId
    },
  },
  methods: {
    // 点击确定保存选择字段
    checkFields(val) {
      let _this = this
      let fieldNames = []
      _this.fieldList.forEach(function(item) {
        _this.checkFieldList.forEach(function(key) {
          if (item.field == key) {
            fieldNames.push(item.field)
          }
        })
      })
      this.checkFieldList = fieldNames
      this.callReason = false
      this.callProvin = false
      this.crossAnsy = false
      this.hotSpot = false
      this.recordingTime = false
      for (let i = 0; i < fieldNames.length; i++) {
        if (fieldNames[i] == 'callReason') {
          this.callReason = true
        }
        if (fieldNames[i] == 'callProvin') {
          this.callProvin = true
        }
        if (fieldNames[i] == 'crossAnsy') {
          this.crossAnsy = true
        }
        if (fieldNames[i] == 'hotSpot') {
          this.hotSpot = true
        }
        if (fieldNames[i] == 'recordingTime') {
          this.recordingTime = true
        }
      }
      this.visible2 = false
    },
    handleNodeClick(data) {
      this.$refs.mySelect.handleClose()
      if (this.$refs.treeMenu.getCurrentNode() == null) {
        this.secondModel = ''
      } else {
        this.secondModel = this.$refs.treeMenu.getCurrentNode().label
      }
      let fromTime = ''
      let toTime = ''
      if (this.formRight.times == null) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        fromTime = this.formRight.times[0]
        toTime = this.formRight.times[1]
      }
      let subjectClassId = ''
      let secondCheckbox = ''
      let secondValue = ''
      subjectClassId = this.naextID
      secondCheckbox = this.groupName
      if (this.$refs.treeMenu.getCurrentNode() == null) {
        secondValue = ''
      } else {
        secondValue = this.$refs.treeMenu.getCurrentNode().value
      }
      let params = {
        viceMdType: secondCheckbox,
        star: fromTime,
        end: toTime,
        subjectClassId: subjectClassId,
        viceMdValue: secondValue,
      }
      this.axios
        .post(currentBaseUrl + '/thematicView/getCrossAnalysis.do', qs.stringify(params))
        .then((res) => {
          this.cyfind.xAxis[0].data = res.data.abscissa
          let series = []
          series.push({
            name: '次数',
            type: 'bar',
            barWidth: '60%',
            data: res.data.data,
          })
          this.cyfind.series = series
          document.getElementById('cyDraw').setAttribute('_echarts_instance_', '')
          let myChartmap = this.$echarts.init(document.getElementById('cyDraw'))
          myChartmap.setOption(this.cyfind)
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    deopShow: function(e) {
      this.$refs.content.blur()
      this.$refs.keyWordsMenu.setCheckedKeys([])
      e.stopPropagation()
      if (this.treeDiv == false) {
        this.treeDiv = true
      } else {
        this.treeDiv = false
        this.hideTree = false
      }
    },
    changActiveall: function(event) {
      event.stopPropagation()
    },
    changeDu: function() {
      let params = {
        viceMdType: this.groupName,
      }
      this.axios
        .post(currentBaseUrl + '/thematicView/getViceMdTree.do', qs.stringify(params))
        .then((res) => {
          this.groupData = res.data
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 树节点被选中画图
    allChangetu: function() {
      this.treeNode() // 绘制来电原因分析图 绘制省级地图
      this.handleNodeClick() // 绘制交叉分析图
      this.getQuShiCharts() // 绘制热词统计图
      this.getTimeAnalusisList() // 绘制录音时段分析图
    },
    // 树节点被点击
    treeNode: function() {
      let fromTime = ''
      let toTime = ''
      if (this.formRight.times == null) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        if (this.formRight.times[0] != undefined && this.formRight.times[0] != '') {
          fromTime = formatdate.formatDate(this.formRight.times[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (this.formRight.times[1] != undefined && this.formRight.times[1] != '') {
          toTime = formatdate.formatDate(this.formRight.times[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
        this.formRight.times = [fromTime, toTime]
      }
      // this.treeValue = flag
      let regions = this.$refs.keyWordsMenu.getCheckedNodes()
      let arr = []
      let stringSize = ''
      let subjectClassId = ''
      if (this.$refs.keyWordsMenu.getCurrentNode() == null) {
        this.treeValue = this.options[0].label
        this.topValue = this.treeValue
        subjectClassId = this.datawer[0][0].subjectClassId
      } else {
        if (this.$refs.keyWordsMenu.getCurrentNode().name > 2) {
          arr.push('...')
        }
        for (let i = 0; i < regions.length; i++) {
          arr.push(regions[i].label)
        }
        for (let y = 0; y < this.ghlgood.length; y++) {
          if (
            regions[0].text == this.ghlgood[y].text &&
            regions[0].label != this.ghlgood[y].label
          ) {
            arr.unshift(this.ghlgood[y].label)
          }
        }
        stringSize = arr.join('/')
        if (this.treeValue.indexOf(stringSize) != -1) {
          this.treeValue = this.treeValue
        } else {
          this.treeValue = this.treeValue + '/' + stringSize
        }
        this.topValue = this.treeValue
        subjectClassId = this.$refs.keyWordsMenu.getCurrentNode().subjectClassId
      }
      this.naextID = subjectClassId
      this.treeDiv = false
      this.hideTree = false
      let params = {
        subjectClassId: subjectClassId,
        star: fromTime,
        end: toTime,
      }
      this.axios
        .post(currentBaseUrl + '/thematicView/getReasonAnalysis.do', qs.stringify(params))
        .then((res) => {
          let series = []
          for (let i = 0; i < res.data.lines.length; i++) {
            if (res.data.lines.length == 0) {
              series.push({
                name: res.data.lines[i].name,
                type: 'line',
                data: [],
              })
            } else {
              series.push({
                name: res.data.lines[i].name,
                type: 'line',
                data: res.data.lines[i].data,
              })
            }
          }
          this.option.series = series
          this.option.xAxis[0].data = res.data.dates
          document.getElementById('diagram').setAttribute('_echarts_instance_', '')
          let myChartAll = this.$echarts.init(document.getElementById('diagram'))
          myChartAll.setOption(this.option)
        })
        .catch(function(error) {
          console.log(error)
        })
      this.axios
        .post(currentBaseUrl + '/thematicView/getAreaData.do', qs.stringify(params))
        .then((res) => {
          this.absf = res.data.cityData
          let seriesNext = []
          if (res.data.provinceData.length == 0) {
            seriesNext = []
          } else {
            seriesNext.push({
              name: 'China Population (2010)',
              type: 'map',
              mapType: 'china',
              roam: false,
              itemStyle: {
                emphasis: { label: { show: true } },
              },
              data: res.data.provinceData,
            })
          }
          // 获取数据最大值
          let arrMax = []
          for (let i = 0; i < res.data.provinceData.length; i++) {
            arrMax = arrMax.concat(res.data.provinceData[i].values)
          }
          if (Math.max.apply(Math, arrMax) == 0) {
            this.shCity.visualMap.max = 20
          } else {
            this.shCity.visualMap.max = Math.max.apply(Math, arrMax)
          }
          this.shCity.visualMap.min = Math.min.apply(Math, arrMax)
          this.shCity.series = seriesNext
          document.getElementById('shMap').setAttribute('_echarts_instance_', '')
          let myChartmap1 = this.$echarts.init(document.getElementById('shMap'))
          myChartmap1.setOption(this.shCity)
          this.createAreaStatsChart()
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    nodeCase(index) {
      this.ghlgood = index
    },
    // 时间控件改变全部画图
    treeChance: function() {
      this.treeNode() // 绘制来电原因分析图 绘制省级地图
      this.handleNodeClick() // 绘制交叉分析图
      this.getQuShiCharts() // 绘制热词统计图
      this.getTimeAnalusisList() // 绘制录音时段分析图
    },
    changActive: function(index, flag) {
      $('.treeCell ul li').removeClass('featureActive')
      $(event.target).addClass('featureActive')
      this.data = this.datawer[index]
      this.treeValue = ''
      this.$refs.keyWordsMenu.setCheckedKeys([])
      this.treeValue = flag
      this.hideTree = true
    },
    allClick: function() {
      this.treeDiv = false
      this.hideTree = false
    },
    etreeShow: function(e) {
      e.stopPropagation()
    },
    tab(index) {
      this.num = index
      if (index === 0) {
        this.qushiVal = 1
        $('#trendChart').show()
        $('#ciChart').hide()
        $('#placeChart').hide()
      } else if (index === 1) {
        this.qushiVal = 1
        $('#trendChart').hide()
        $('#ciChart').show()
        $('#placeChart').hide()
        myChartCi = this.$echarts.init(document.getElementById('ciChart'))
        myChartCi.resize()
      } else {
        this.qushiVal = 2
        $('#trendChart').hide()
        $('#ciChart').hide()
        $('#placeChart').show()
        let myChartPlace = this.$echarts.init(document.getElementById('placeChart'))
        myChartPlace.resize()
      }
    },
    tabCity(index) {
      this.numCity = index
      let _this = this
      if (index == 0) {
        this.cityChange = false
        setTimeout(function() {
          _this.createAreaStatsChart()
        }, 300)
      } else {
        setTimeout(function() {
          _this.treeNode()
        }, 300)
        this.cityChange = true
      }
    },
    // 默认一个月时间
    getAWeekTime: function() {
      let fromTime = ''
      let toTime = ''
      if (this.formRight.times.length == 0) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        if (this.formRight.timesr[0] != undefined && this.formRight.times[0] != '') {
          fromTime = formatdate.formatDate(this.formRight.times[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (this.formRight.times[1] != undefined && this.formRight.times[1] != '') {
          toTime = formatdate.formatDate(this.formRight.times[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.formRight.times = [fromTime, toTime]
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let str = year + '-' + month + '-' + day
      return str
    },
    getQuShiCharts() {
      let _this = this
      let fromTime = ''
      let toTime = ''
      if (this.formRight.times == null) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        if (this.formRight.times[0] != undefined && this.formRight.times[0] != '') {
          fromTime = formatdate.formatDate(this.formRight.times[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (this.formRight.times[1] != undefined && this.formRight.times[1] != '') {
          toTime = formatdate.formatDate(this.formRight.times[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
        this.formRight.times = [fromTime, toTime]
      }
      let params = {}
      params.beginDate = fromTime
      params.endDate = toTime
      params.wordRole = _this.searchModel.wordRole || '-1'
      params.buss_wordType = _this.searchModel.buss_wordType
      params.keyWord = _this.keyword
      params.subjectClassIds = _this.naextID // 分类id，多个时以逗号分隔
      params.subjectId = _this.getThenaticAnalysisId
      let urlQs = currentBaseUrl + '/hotAnlys/getTrendData.do'
      _this.axios.post(urlQs, qs.stringify(params)).then(function(response) {
        if (response.data.dateList.length > 0 && response.data.trendData.length > 0) {
          let dateList = response.data.dateList
          let trendData = response.data.trendData
          let dateData = []
          let trend = []
          let nums
          if (trendData.length <= 5) {
            nums = trendData.length
          } else {
            nums = 5
          }
          for (let i = 0; i < dateList.length; i++) {
            dateData[i] = dateList[i][0]
          }
          // series
          for (let j = 0; j < nums; j++) {
            trend[j] = {
              name: trendData[j].keyword,
              type: 'line',
              data: trendData[j].timesList,
            }
          }
          // legend data
          let legendData = []
          for (let p = 0; p < nums; p++) {
            legendData[p] = trendData[p].keyword
          }
          // xAxis
          let xAxisData = []
          for (let a = 0; a < dateList.length; a++) {
            xAxisData[a] = dateList[a]
          }
          _this.qushiEchartsOption.legend.data = legendData
          _this.qushiEchartsOption.xAxis[0].data = xAxisData
          _this.qushiEchartsOption.series = trend
          let myQushiChart = _this.$echarts.init(document.getElementById('trendChart'))
          myQushiChart.setOption(_this.qushiEchartsOption, true)
          myQushiChart.on('contextmenu', function(params) {
            _this.timetype = '2'
            _this.exportData = {
              subjectId: _this.getThenaticAnalysisId,
              keyWords: params.seriesName,
              roleType: _this.searchModel.wordRole || '-1',
              star: params.name,
              end: params.name + ' ' + '23:59:59',
            }
            _this.showMoremodel(_this.exportData)
          })
          _this.getci(trendData[0].keyword)
          let times = dateList[0]
          _this.getMap(trendData[0].keyword, times)
          let paramsd = {}
          paramsd.beginDate = times
          paramsd.endDate = _this.callSTime_Max
          paramsd.wordRole = _this.searchModel.wordRole || '-1'
          paramsd.buss_wordType = _this.searchModel.buss_wordType
          paramsd.keyWord = _this.keyword
          paramsd.subjectId = _this.getThenaticAnalysisId
          paramsd.subjectClassIds = _this.naextID // 分类id，多个时以逗号分隔
          let urld = currentBaseUrl + '/hotAnlys/getAllkey.do?accessToken=' + CASTGC
          _this.axios
            .post(urld, qs.stringify(paramsd))
            .then(function(response) {
              if (response.data) {
                _this.loading = false
              }
              // _this.formRight.times = [times, _this.callSTime_Max]
              _this.tableCiData = response.data.keyword
              _this.keyword = ''
            })
            .catch(function(error) {
              alert(error)
              _this.tableCiData = []
              _this.$message({
                type: 'error',
                message: '获取热点数据值失败',
              })
            })
        } else {
          // 没有数据
        }
      })
    },
    // 增加关键词
    addKeyWord() {
      if (this.selectKeyWord == '') {
        this.$message({
          type: 'error',
          message: '请选择关键词',
        })
      } else {
        let _this = this
        _this.addWordModalVisible = true
        _this.addTitle = '添加关键词 [' + this.selectKeyWord + ']'
      }
      this.roleType = ''
    },
    // 获取关键词、水词分类
    getWordClass(val) {
      let _this = this
      let url = currentBaseUrl + '/vocabulary/getTrees.do?accessToken=' + CASTGC
      let params = {
        classId: 0,
        classType: val,
      }
      _this.axios.post(url, qs.stringify(params)).then(function(response) {
        _this.treeData = response['data']
      })
    },
    // 增加水词
    removeKeyWord() {
      let _this = this
      if (this.selectKeyWord == '') {
        this.$message({
          type: 'error',
          message: '请选择水词',
        })
      } else {
        _this.addWalterWordModalVisible = true
        _this.addWalterTitle = '添加水词 [' + this.selectKeyWord + ']'
      }
      this.roleType = _this.roleType
    },
    // 获取树列表信息
    getTreelist: function() {
      let _this = this
      this.axios.post(currentBaseUrl + '/thematicView/getClassTree.do').then((res) => {
        _this.options = res.data.options
        _this.datawer = res.data.data
        this.treeNode()
        this.getTimeAnalusisList() // 绘制录音时段分析图
        this.handleNodeClick() // 绘制交叉分析图
        this.getQuShiCharts() // 绘制热词统计图
      })
    },
    // 获取时段分析列表
    getTimeAnalusisList: function() {
      let that = this
      let fromTime = ''
      let toTime = ''
      if (this.formRight.times == null) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        if (this.formRight.times[0] != undefined && this.formRight.times[0] != '') {
          fromTime = formatdate.formatDate(this.formRight.times[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (this.formRight.times[1] != undefined && this.formRight.times[1] != '') {
          toTime = formatdate.formatDate(this.formRight.times[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
        this.formRight.times = [fromTime, toTime]
      }
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        this.timeparames = {
          subjectId: this.getThenaticAnalysisId, // 专题id
          subjectClassId: this.naextID, // 分类id，多个时以逗号分隔
          star: fromTime,
          end: toTime, // 查询条件结束时间
        }
      } else {
        this.timeparames = {
          subjectId: this.getThenaticAnalysisId, // 专题id
          subjectClassId: this.naextID, // 分类id，多个时以逗号分隔
          star: fromTime,
          end: toTime, // 查询条件结束时间
        }
      }
      this.axios
        .post(
          currentBaseUrl + '/thematicView/timeInterval.do',
          qs.stringify(this.timeparames)
        )
        .then((res) => {
          let timeData = res.data
          let everyData = []
          for (let i = 0; i < timeData.length; i++) {
            let Ydata = timeData[i].ordinateCount
            for (let j in Ydata) {
              let XYdata = []
              XYdata.push(timeData[i].abscissa * 1)
              XYdata.push(j)
              // 数据为0时处理
              /* let jj = j * 1 + 1
                 if ((jj % 5) == 0) {
                 XYdata.push(Ydata[j] * 1 + jj)
                 } else {
                 XYdata.push(Ydata[j] * 1)
                 } */
              XYdata.push(Ydata[j] * 1)
              everyData.push(XYdata)
            }
          }
          that.getTimeAnalysis(everyData)
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 时段分析图添加
    getTimeAnalysis: function(timeData) {
      let hours = [
        '0',
        '1',
        '2',
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9',
        '10',
        '11',
        '12',
        '13',
        '14',
        '15',
        '16',
        '17',
        '18',
        '19',
        '20',
        '21',
        '22',
        '23',
      ]
      let days = ['周六', '周五', '周四', '周三', '周二', '周一', '周日']
      let data = timeData
      let maxV = 10
      data = data.map(function(item) {
        if (item[2] > maxV) {
          maxV = Math.ceil(item[2] / 10) * 10
        }
        return [item[1], item[0], item[2] || '-']
      })
      let timeAnalyse = this.$echarts.init(document.getElementById('timeAnalyse'))
      let timeAnalyseOption = {
        backgroundColor: '#fff',
        tooltip: {
          position: 'top',
          trigger: 'item',
        },
        animation: false,
        grid: {
          height: '70%',
          y: '10%',
        },
        xAxis: {
          type: 'category',
          data: hours,
          splitArea: {
            show: true,
          },
        },
        yAxis: {
          type: 'category',
          data: days,
          splitArea: {
            show: true,
          },
        },
        visualMap: {
          min: 0,
          max: maxV,
          type: 'continuous',
          realtime: false,
          calculable: true,
          orient: 'horizontal',
          left: 'center',
          bottom: '0%',
          color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        },
        series: [
          {
            name: '',
            type: 'heatmap',
            data: data,
            label: {
              normal: {
                show: true,
              },
            },
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
              },
            },
          },
        ],
      }
      let that = this
      timeAnalyse.setOption(timeAnalyseOption)
      document.oncontextmenu = function() {
        return false
      }
      timeAnalyse.on('contextmenu', function(params) {
        that.timetype = '1'
        that.exportData = {
          subjectId: that.getThenaticAnalysisId,
          subjectClassId: that.formRight.region,
          star:
            that.formRight.times == undefined ||
            that.formRight.times == '' ||
            that.formRight.times.length <= 0
              ? that.Week
              : that.gettimeform(that.formRight.times[0]),
          end:
            that.formRight.times == undefined ||
            that.formRight.times == '' ||
            that.formRight.times.length <= 0
              ? that.Today
              : that.gettimeform(that.formRight.times[1]),
          cols: params.value[1],
          row: params.value[0],
        }
        that.showmodal(that.exportData)
      })
    },
    // 时间详情弹窗
    showmodal: function(params) {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/thematicView/getTimeIntervalRecordList.do',
          qs.stringify(params)
        )
        .then((res) => {
          _this.currentAll = res.data
          _this.recordingtotal = _this.currentAll.length
          // 获取当前页的数据
          _this.handleCurrentChange(1)
          if (_this.recordinglist.length > 0) {
          }
          _this.dialogTableRecorVisible = true
        })
    },
    handleCurrentChange(val) {
      this.currentPagerecord = val
      this.offset = (val - 1) * this.limit // 上一页结束的数 + 1 就是 当前页第一个数组
      let firstoffset = this.offset
      let lastoffset = this.offset + this.limit
      /*
       * 数据过滤
       * */
      let _this = this
      _this.recordinglist = []
      for (let i = firstoffset; i < lastoffset; i++) {
        if (_this.recordingtotal > i) {
          _this.recordinglist.push(_this.currentAll[i])
        }
      }
    },
    getQuShiTu() {
      let _this = this
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        _this.callSTime_Min = _this.Week
        _this.callSTime_Max = _this.Today
      } else {
        _this.callSTime_Min = this.gettimeform(this.formRight.times[0])
        _this.callSTime_Max = this.gettimeform(this.formRight.times[1])
      }
      let params = {}
      params.beginDate = _this.callSTime_Min
      params.endDate = _this.callSTime_Max
      params.wordRole = this.searchModel.wordRole || '-1'
      params.buss_wordType = this.searchModel.buss_wordType
      params.keyWord = this.keyword
      params.subjectClassIds = this.formRight.region // 分类id，多个时以逗号分隔
      let urlQs = currentBaseUrl + '/hotAnlys/getTrendData.do'
      this.axios.post(urlQs, qs.stringify(params)).then(function(response) {
        if (response.data.dateList.length > 0 && response.data.trendData.length > 0) {
          let dateList = response.data.dateList
          let trendData = response.data.trendData
          let dateData = []
          let trend = []
          let nums
          let keywords = _this.keyword
          if (keywords != null && keywords != undefined && keywords != '') {
            let keywordArr = keywords.split(',')
            nums = keywordArr.length
          } else {
            if (trendData.length <= 5) {
              nums = trendData.length
            } else {
              nums = 5
            }
          }
          for (let i = 0; i < dateList.length; i++) {
            dateData[i] = dateList[i][0]
          }
          // series
          for (let j = 0; j < nums; j++) {
            trend[j] = {
              name: trendData[j].keyword,
              type: 'line',
              // stack: '总量',
              // areaStyle: {normal: {}},
              data: trendData[j].timesList,
            }
          }
          // legend data
          let legendData = []
          for (let p = 0; p < nums; p++) {
            legendData[p] = trendData[p].keyword
          }
          // xAxis
          let xAxisData = []
          for (let a = 0; a < dateList.length; a++) {
            xAxisData[a] = dateList[a]
          }
          let option = {
            title: {
              text: '',
              textStyle: {
                color: '#5e6d82',
                fontSize: 14,
                fontWieght: 'normal',
              },
            },
            tooltip: {
              trigger: 'axis',
            },
            legend: {
              data: [],
            },

            grid: {
              left: '3%',
              right: '4%',
              bottom: '3%',
              containLabel: true,
            },
            xAxis: [
              {
                type: 'category',
                boundaryGap: false,
                data: [],
                splitLine: {
                  show: true,
                },
                axisLine: {
                  show: false,
                },
              },
            ],
            yAxis: [
              {
                type: 'value',
                splitLine: {
                  show: true,
                },
                axisLine: {
                  show: false,
                },
              },
            ],
            color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
            series: [],
          }
          option.legend.data = legendData
          option.xAxis[0].data = xAxisData
          option.series = trend
          let myQushiChart = _this.$echarts.init(document.getElementById('trendChart'))
          myQushiChart.setOption(option, true)
          myQushiChart.on('contextmenu', function(params) {
            _this.timetype = '2'
            _this.exportData = {
              subjectId: _this.getThenaticAnalysisId,
              keyWords: params.seriesName,
              roleType: _this.searchModel.wordRole || '-1',
              star: params.name,
              end: params.name + ' ' + '23:59:59',
            }
            _this.showMoremodel(_this.exportData)
          })
        } else {
          // 没有数据
        }
      })
    },
    selectionChange(row) {
      let keyword = row
        .map((it) => {
          return it.keyword
        })
        .reduce((acc, cur) => {
          if (acc) {
            return cur ? `${acc},${cur}` : acc
          }
          return cur || ''
        }, '')
      this.selectKeyWord = keyword
      this.keyword = keyword
      myChartCi && myChartCi.dispose()
      let _this = this
      // 趋势图
      _this.getQuShiTu()
      // 地图
      let times = ''
      _this.getMap(keyword, times)
      // 词相关
      _this.getci(keyword)
    },
    getci(word) {
      let _this = this
      let ciparams = {}
      let wordData = []
      ciparams.word = word
      this.axios
        .post(currentBaseUrl + '/hotAnlys/getRelatedWords.do', qs.stringify(ciparams))
        .then((res) => {
          if (res.data.length > 0) {
            let dataLength
            if (res.data.length >= 15) {
              dataLength = 15
            } else {
              dataLength = res.data.length
            }
            for (let i = 0; i < dataLength; i++) {
              wordData[i] = {
                id: i + 1,
                category: 1,
                label: res.data[i].name,
                name: i + 1,
                symbolSize: res.data[i].score * 90,
                ignore: false,
                flag: true,
              }
            }
            let links = []
            for (let i = 0; i < dataLength; i++) {
              links[i] = {
                source: 0,
                target: i + 1,
              }
            }
            let categories = []
            for (let i = 0; i < dataLength; i++) {
              categories[i] = {
                id: i + 1,
                name: i + 1 + '层',
              }
            }
            // 词相关数据画布渲染
            myChartCi = this.$echarts.init(document.getElementById('ciChart'))
            /* let categoriesList = [{id: 0, name: '根'}]
              let linksList = [{source: 0, target: 0}] */
            let nodesData = [
              {
                id: 0,
                category: 0,
                label: word,
                name: 0,
                symbolSize: 60,
                ignore: false,
                flag: true,
              },
            ]
            _this.cioption.series[0].nodes = nodesData.concat(wordData)
            _this.cioption.series[0].categories = categories
            _this.cioption.series[0].links = links
            myChartCi.setOption(_this.cioption)
            myChartCi.on('click', function(params) {
              let paramsList = params
              _this.getClick(paramsList)
            })
          } else {
            /* _this.cioption.series[0].nodes = nodesData
              _this.cioption.series[0].categories = categoriesList
              _this.cioption.series[0].links = linksList
              myChartCi.setOption(_this.cioption) */
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 词 点击事件
    getClick: function(paramsList) {
      let dataP = paramsList.data
      if (dataP != null && dataP != undefined) {
        let cid = dataP.category
        let pid = dataP.id
        let params = {}
        params.word = paramsList.data.label
        this.axios
          .post(currentBaseUrl + '/hotAnlys/getRelatedWords.do', qs.stringify(params))
          .then((res) => {
            if (res.data.length > 0) {
              if (dataP.ignore == true) {
                // 重复
                return
              }
              // 得到links最后一个target
              let tcount = myChartCi.getOption().series[0].links.pop().target
              let ncount = myChartCi.getOption().series[0].nodes.pop().id
              // let ssize = paramsList.data.symbolSize
              let catCount = myChartCi.getOption().series[0].nodes.pop().id

              let nums
              if (res.data.length >= 15) {
                nums = 15
              } else {
                nums = res.data.length
              }
              // 重组数组
              let word = []
              if (cid === 0) {
                for (let i = 0; i < nums; i++) {
                  word[i] = {
                    id: i + 1,
                    category: cid + 1,
                    label: res.data[i].name,
                    name: i + 1,
                    symbolSize: res.data[i].score * 90,
                    ignore: false,
                    flag: true,
                  }
                }
              } else {
                let wAdd
                wAdd = ncount + 1
                for (let i = 0; i < nums; i++) {
                  word[i] = {
                    id: wAdd,
                    category: cid + 1,
                    label: res.data[i].name,
                    name: wAdd,
                    symbolSize: res.data[i].score * 90,
                    ignore: false,
                    flag: true,
                  }
                  wAdd = wAdd + 1
                }
              }
              // 设置点击过得词语不能再次查询
              let worddata = myChartCi.getOption().series[0].nodes.concat(word)
              worddata[pid].ignore = true
              // links
              let links = []
              // let sid = 0
              if (cid === 0) {
                // sid = 0
                for (let i = 0; i < nums; i++) {
                  links[i] = {
                    source: pid,
                    target: i + 1,
                  }
                }
              } else {
                // sid = sid + 1
                let lAdd
                lAdd = tcount + 1
                for (let i = 0; i < nums; i++) {
                  links[i] = {
                    source: pid,
                    target: lAdd,
                  }
                  lAdd = lAdd + 1
                }
              }
              let linksdata = myChartCi.getOption().series[0].links.concat(links)
              // categories
              let categories = []
              if (cid === 0) {
                for (let i = 0; i < nums; i++) {
                  categories[i] = {
                    id: i + 1,
                    name: i + 1 + '层',
                  }
                }
              } else {
                let cAdd
                cAdd = catCount + 1
                for (let i = 0; i < nums; i++) {
                  categories[i] = {
                    id: cAdd,
                    name: cAdd + '层',
                  }
                  cAdd = cAdd + 1
                }
              }
              let cdata = myChartCi.getOption().series[0].categories.concat(categories)
              myChartCi.setOption({
                series: [
                  {
                    links: linksdata,
                    nodes: worddata,
                    categories: cdata,
                  },
                ],
              })
            } else {
              // null
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    getMap(keyword, times) {
      let params = {}
      let _this = this
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        _this.callSTime_Min = _this.Week
        _this.callSTime_Max = _this.Today
      } else {
        _this.callSTime_Min = this.gettimeform(this.formRight.times[0])
        _this.callSTime_Max = this.gettimeform(this.formRight.times[1])
      }
      params.beginDate = _this.callSTime_Min
      params.endDate = _this.callSTime_Max
      params.wordRole = this.searchModel.wordRole || '-1'
      params.buss_wordType = this.searchModel.buss_wordType
      params.keyWord = keyword
      params.subjectClassId = this.naextID // 分类id，多个时以逗号分隔
      params.subjectId = _this.getThenaticAnalysisId
      let url = currentBaseUrl + '/hotAnlys/getAreaData.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.area != null) {
            // let mdata = []
            let mmdata = response.data.area
            /* for (let i = 0; i < mmdata.length; i++) {
               mdata[i] = {
               name: mmdata[i].city,
               value: Object.values(mmdata[i].keywords)[0]
               }
               } */
            let legenddata = []
            for (let j = 0; j < mmdata.length; j++) {
              legenddata[j] = mmdata[j].city
            }
            let convertData = function(data) {
              let res = []
              for (let i = 0; i < data.length; i++) {
                let geoCoord = geoCoordMap[data[i].name]
                if (geoCoord) {
                  res.push({
                    name: data[i].name,
                    value: geoCoord.concat(data[i].value),
                  })
                }
              }
              return res
            }
            let seriesdata = []
            for (let m = 0; m < mmdata.length; m++) {
              seriesdata[m] = {
                name: mmdata[m].city,
                mapType: 'china',
                type: 'scatter',
                // symbolSize: 5,
                /* symbolSize: function (val) {
                   return val[2] * 10
                   }, */
                coordinateSystem: 'geo',
                label: {
                  normal: {
                    color: '#fff',
                    show: false,
                  },
                },
                itemStyle: {
                  normal: { label: { show: true } },
                  emphasis: { label: { show: true } },
                },
                data: convertData([
                  { name: mmdata[m].city, value: Object.values(mmdata[m].keywords)[0] },
                ]),
              }
            }
            let myPlaceChart = _this.$echarts.init(document.getElementById('placeChart'))
            myPlaceChart.setOption({
              tooltip: {
                formatter: function(params) {
                  return params.name + '(词频):' + params.value[2]
                },
                trigger: 'item',
              },
              legend: {
                left: 0,
                bottom: 20,
                top: 20,
                data: legenddata,
              },
              geo: [
                {
                  show: true,
                  map: 'china',
                  roam: true,
                },
              ],
              visualMap: {
                min: 0,
                max: 200,
                color: ['#d94e5d', '#eac736', '#50a3ba'],
                symbolSize: [10, 20],
                splitNumber: 5,
              },
              series: seriesdata,
            })
          }
        })
        .catch(function(error) {
          alert(error)
        })
    },
    createAreaStatsChart() {
      let mmdata = this.absf
      if (mmdata == []) {
        let _this = this
        document.getElementById('chinaMap').setAttribute('_echarts_instance_', '')
        this.areaChart = _this.$echarts.init(document.getElementById('chinaMap'))
        this.areaChart.setOption({
          tooltip: {
            formatter: function(params) {
              let cellDate = ''
              for (let y = 0; y < params.data.keyName.length; y++) {
                cellDate =
                  cellDate +
                  params.data.keyName[y] +
                  ' : ' +
                  params.data.valueSize[y] +
                  '<br/>'
              }
              return (
                '<span style="display:inline-block;border-radius:8px;background:lightskyblue;height:8px;width:8px;margin-right:5px;"></span>' +
                params.name +
                '<br/>' +
                cellDate
              )
            },
            trigger: 'item',
          },
          /* legend: {
              left: 100,
              bottom: 20,
              top: 20,
              data: legenddata
            }, */
          geo: [
            {
              show: true,
              map: 'china',
              roam: true,
            },
          ],
          visualMap: {
            show: false,
            left: 480,
            top: 220,
            inRange: {
              color: ['lightskyblue'],
              symbolSize: [20, 20],
            },
            min: 0,
            max: 10000,
            /* max: convertMaxCount(this.maxCount), */
            calculable: true,
            realtime: false,
          },
          series: [],
        })
      }
      // 区域图最大值获取
      let legenddata = []
      for (let j = 0; j < mmdata.length; j++) {
        legenddata[j] = mmdata[j]['city_name']
      }
      let convertData = function(data) {
        let res = []
        for (let i = 0; i < data.length; i++) {
          let geoCoord = geoCoordMap[data[i].name]
          if (geoCoord) {
            let valueSum = 0
            for (let j = 0; j < data[i].valueSize.length; j++) {
              valueSum += data[i].valueSize[j]
            }
            res.push({
              name: data[i].name,
              value: [geoCoord[0], geoCoord[1], valueSum],
              keyName: data[i].keyName,
              valueSize: data[i].valueSize,
            })
          }
        }
        return res
      }
      /* let convertMaxCount = function (maxCount) {
          if (maxCount % 5 != 0) {
            for (; ; maxCount++) {
              if (maxCount % 5 == 0) break
            }
          }
          return maxCount
        } */
      let seriesdata = []
      for (let m = 0; m < mmdata.length; m++) {
        seriesdata[m] = {
          name: mmdata[m]['city_name'],
          mapType: 'china',
          type: 'scatter',
          coordinateSystem: 'geo',
          label: {
            normal: {
              color: '#fff',
              show: false,
            },
          },
          itemStyle: {
            normal: { label: { show: true } },
            emphasis: { label: { show: true } },
          },
          data: convertData([
            {
              name: mmdata[m]['city_name'],
              keyName: mmdata[m]['keyName'],
              valueSize: mmdata[m]['valueSize'],
            },
          ]),
        }
      }
      let _this = this
      document.getElementById('chinaMap').setAttribute('_echarts_instance_', '')
      this.areaChart = _this.$echarts.init(document.getElementById('chinaMap'))
      this.areaChart.setOption({
        tooltip: {
          formatter: function(params) {
            let cellDate = ''
            for (let y = 0; y < params.data.keyName.length; y++) {
              cellDate =
                cellDate +
                params.data.keyName[y] +
                ' : ' +
                params.data.valueSize[y] +
                '<br/>'
            }
            return (
              '<span style="display:inline-block;border-radius:50%;background:lightskyblue;height:10px;width:10px;margin-right:5px;"></span>' +
              params.name +
              '<br/>' +
              cellDate
            )
          },
          trigger: 'item',
        },
        /* legend: {
            left: 100,
            bottom: 20,
            top: 20,
            data: legenddata
          }, */
        geo: [
          {
            show: true,
            map: 'china',
            roam: true,
          },
        ],
        visualMap: {
          show: false,
          left: 480,
          top: 220,
          inRange: {
            color: ['lightskyblue'],
            symbolSize: [30, 30],
          },
          min: 0,
          max: 10000,
          /* max: convertMaxCount(this.maxCount), */
          calculable: true,
          realtime: false,
        },
        series: seriesdata,
      })
    },
  },
  mounted: function() {
    // 页面一加载就画出折线图的横坐标与纵坐标
    document.getElementById('diagram').setAttribute('_echarts_instance_', '')
    let myChartAll = this.$echarts.init(document.getElementById('diagram'))
    myChartAll.setOption(this.option)
    this.getTreelist() // 获取树控件的列表 绘制来电原因分析图 绘制省级地图
    this.getAWeekTime() // 请求时间的接口
  },
}
</script>
<style lang="less" scoped="scoped">
.shCity {
  display: inline-block;
  padding: 0 16px;
  cursor: pointer;
  color: #96a2b2;
  font-weight: normal;
  float: right;
}
.changeActiveces {
  color: #21a2ff;
  border-bottom: 2px solid #21a2ff;
}
.themTitle {
  height: 55px;
  line-height: 55px;
  .themLeft {
    display: inline-block;
    font-size: 14px;
    color: #1f2d3d;
    margin-left: 21px;
  }
  .themRight {
    display: inline-block;
    float: right;
    .themFrom {
      float: left;
    }
    .themShow {
      display: inline-block;
      float: right;
      margin: 0 20px;
      color: #20a0ff;
      font-size: 14px;
    }
  }
}
.lineTitle {
  padding: 10px 20px 0 30px;
  height: 50px;
  line-height: 50px;
  border-top: 1px solid #e4e4e4;
  .thematicTitleLeft {
    font-size: 14px;
    font-weight: bold;
    display: inline-block;
    width: 50%;
  }
  .thematicTitleRight {
    font-size: 14px;
    font-weight: bold;
    display: inline-block;
    width: 49%;
  }
}
.show_fields {
  color: #20a0ff;
  cursor: pointer;
  margin: 0 20px;
}
.treeCell {
  width: 200px;
  height: 200px;
  border: 1px solid #e4e7ed;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 2px;
  position: absolute;
  top: 84%;
  z-index: 3000;
  background: #fff;
  overflow: hidden;
  overflow-y: auto;
}
.featureActive {
  color: #409eff;
}
.btnSet {
  text-align: right;
  margin: 10px 0 0 0;
  padding-top: 10px;
  border-top: 1px solid #e4e4e4;
}
.pageChange {
  float: left;
  width: 100%;
  height: 48px;
  line-height: 48px;
  background: #eef1f6;
  border-bottom: 1px solid #d1dbe4;
  background: #ffffff;
  .changeActive {
    color: #21a2ff;
    border-bottom: 2px solid #21a2ff;
  }
  ul {
    width: 100%;
    box-sizing: border-box;
    li {
      float: left;
      padding: 0 16px;
      box-sizing: border-box;
      font-size: 14px;
      color: #96a2b2;
      cursor: pointer;
    }
  }
}
.timeanalyse {
  width: 100%;
  height: 420px;
  .timeanalyse-content {
    width: 100%;
    height: 90%;
  }
}
</style>
<style lang="less">
.themFrom {
  .el-input__inner {
    cursor: pointer;
    height: 36px;
    line-height: 36px;
    width: 190px;
    overflow: hidden;
    padding: 0 20px;
  }
  .el-range-editor {
    padding: 1px 10px;
  }
}
#spellCheck .el-checkbox {
  width: 40%;
  margin-left: 15px;
  margin-right: 20px;
  margin-bottom: 5px;
}
.newSetcss {
  font-size: 14px;
  padding: 8px 20px;
  position: relative;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #606266;
  height: 34px;
  line-height: 1.5;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  cursor: pointer;
  outline: 0;
  list-style-type: none;
}
.newSetcss:after {
  font-family: element-icons;
  content: '\E604';
  font-size: 14px;
  color: #bfcbd9;
  position: absolute;
  right: 15px;
}
.newSetall:after {
  font-family: element-icons;
  content: '\E603';
  font-size: 14px;
  color: #bfcbd9;
  position: absolute;
  right: 15px;
}
#treeSpan .el-tree {
  position: absolute;
  left: 29%;
  width: 200px;
  height: 194px;
  border: 1px solid #e4e7ed;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 2px;
  position: absolute;
  top: 84%;
  z-index: 3000;
  background: #fff;
  padding-top: 6px;
  overflow: hidden;
  overflow-y: auto;
}
.drawTable .scrollTable th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}
.newSetall {
  input.el-input__inner {
    color: #fff;
  }
  input.el-input__inner::first-line {
    color: #333;
  }
}
.treePtionabc {
  min-height: 200px;
  .el-select-dropdown__item {
    padding: 0;
    overflow: visible;
  }
}
</style>
