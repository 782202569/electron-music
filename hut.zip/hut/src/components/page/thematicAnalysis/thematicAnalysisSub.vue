<template>
  <div class="thematicAnalysisSub">
    <div class="wraper">
      <div class="header">
        <div class="fl">来电原因分析（共{{ totalNumberOfRecordings }}条录音)</div>
        <div class="fr">
          <el-button size="mini" @click="goBackList">返回列表</el-button>
        </div>
      </div>
      <div class="content">
        <el-form class="fr" ref="formRight" :model="formRight" :inline="true">
          <el-form-item>
            <template>
              <el-input class="select-width hide" v-model="formRight.region"></el-input>
              <el-input
                class="select-width"
                v-click-outside="outside"
                @focus="inside"
                ref="regionInput"
                placeholder="请选择范围"
                clearable
                v-model="formRight.regionName"
              ></el-input>
              <div class="contentLeft" v-show="this.showTree == true">
                <div class="treeMenu">
                  <el-tree
                    :data="treeMenu"
                    :props="defaultProps"
                    @node-click="handleNodeClick"
                    ref="keyWordsMenu"
                    show-checkbox
                    node-key="subjectClassId"
                    :check-strictly="true"
                  >
                  </el-tree>
                  <div class="btns">
                    <el-button @click="resetChecked">清空</el-button>
                    <el-button type="primary" @click="getCheckedKeys">确定</el-button>
                  </div>
                </div>
              </div>
            </template>
          </el-form-item>
          <el-form-item>
            <el-date-picker
              v-model="formRight.times"
              type="daterange"
              align="right"
              placeholder="选择日期范围"
              :picker-options="pickerOptions2"
            >
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="searchByName">查询</el-button>
          </el-form-item>
        </el-form>
        <div class="commen">
          <div class="commen-block fl m-r-10">
            <div class="aw-45 fl">
              <p class="p1">今日新增</p>
              <p class="p2">{{ todayTotal }}</p>
            </div>
            <div class="aw-50 fl" id="recordingsToday"></div>
          </div>
          <div class="commen-block fl m-r-10">
            <div class="aw-45 fl">
              <p class="p1">本周新增</p>
              <p class="p2">{{ weekTotal }}</p>
            </div>
            <div class="aw-50 fl" id="recordingsWeek"></div>
          </div>
          <div class="commen-block fl">
            <div class="aw-45 fl">
              <p class="p1">本月新增</p>
              <p class="p2">{{ monthTotal }}</p>
            </div>
            <div class="aw-50 fl" id="recordingsMonth"></div>
          </div>
        </div>
        <div class="occupationRatio">
          <div class="block ratio-block fl">
            <div class="header">
              <p class="fl">占比分析</p>
              <p class="fr">
                <el-button @click="goBackUp" class="btn">返回</el-button>
              </p>
            </div>
            <div class="occupationRatio-block" id="occupationRatio"></div>
          </div>
          <div class="block fl trend-block">
            <div class="header"><p class="fl">走势分析</p></div>
            <div class="occupationRatio-block" id="trendOfOccupation"></div>
          </div>
        </div>
      </div>
      <div id="hotanalyse">
        <div class="hotanalyse-header">
          <div style="width:100%;height:100%;" class="hotanalyse-header-pos">
            <div class="title">热点分析</div>
            <el-form :model="searchModel" ref="searchModel" :inline="true">
              <div style="width:100%;height:36px;margin-left:-20px;margin-bottom:10px;">
                <el-form-item
                  v-show="false"
                  label="词汇类型："
                  style="margin-left: 20px"
                ></el-form-item>
                <el-form-item prop="buss_wordType">
                  <el-radio-group
                    v-show="false"
                    v-model="searchModel.buss_wordType"
                    @change="radioChangeBussType"
                    style="margin-top: 9px;"
                  >
                    <!-- <el-radio label="0">全部</el-radio> -->
                    <el-radio label="1">热词</el-radio>
                    <el-radio label="2">新词</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="角色：" style="margin-left: 20px"></el-form-item>
                <el-form-item prop="wordRole">
                  <el-radio-group
                    v-model="searchModel.wordRole"
                    @change="radioChange"
                    style="margin-top: 9px;"
                  >
                    <el-radio label="0">全部</el-radio>
                    <el-radio label="1">客户</el-radio>
                    <el-radio label="2">客服</el-radio>
                  </el-radio-group>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </div>
        <el-dialog :title="addTitle" :visible.sync="addWordModalVisible">
          <div style="width:100%;overflow: hidden;">
            <div style="float: left;width: 30%; height:320px;border: 1px solid #d1dbe5">
              <!-- <el-tree check-strictly :data="treeData"  node-key="classId"
                        highlight-current :expand-on-click-node="false"  default-expand-all ref="editTree"
                        show-checkbox>
               </el-tree>-->
              <el-tree
                :data="treeData"
                :props="wordDefaultProps"
                ref="keyWordMenu"
                node-key="classId"
                @node-click="handleNodeClick"
                check-strictly
              >
              </el-tree>
            </div>
            <div style="float: right;width: 68%;height:320px;border: 1px solid #d1dbe5">
              <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">
                关键词描述
              </div>
              <el-input
                type="textarea"
                v-model="wordDescribe"
                :rows="10"
                style="width: 90%; margin: 10px 0px 0px 10px;"
              ></el-input>
            </div>
            <div slot="footer" style="float: right; margin-top: 10px">
              <el-button @click="cancelAdd">取 消</el-button>
              <el-button type="primary" @click="handleAddKeyWordThrottle"
                >确 定</el-button
              >
            </div>
          </div>
        </el-dialog>
        <el-dialog
          :title="addWalterTitle"
          :visible.sync="addWalterWordModalVisible"
        >
          <div style="width:100%;overflow: hidden;">
            <div style="float: left;width: 30%; height:320px;border: 1px solid #d1dbe5">
              <!-- <el-tree check-strictly :data="treeData"  node-key="classId"
                        highlight-current :expand-on-click-node="false"  default-expand-all ref="editTree"
                        show-checkbox>
               </el-tree>-->
              <el-tree
                :data="treeData"
                :props="wordDefaultProps"
                ref="keyWordMenu"
                node-key="classId"
                @node-click="handleNodeClick"
                check-strictly
              >
              </el-tree>
            </div>
            <div style="float: right;width: 68%;height:320px;border: 1px solid #d1dbe5">
              <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">
                角色类型
                <el-select v-model="roleType" style="margin-left: 5px;margin-top: 1px;">
                  <el-option label="客户" value="1"></el-option>
                  <el-option label="客服" value="2"></el-option>
                  <el-option label="全部" value="0"></el-option>
                </el-select>
              </div>

              <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">水词描述</div>
              <el-input
                type="textarea"
                v-model="wordDescribe"
                :rows="9"
                style="width: 90%; margin: 10px 0px 0px 10px;"
              ></el-input>
            </div>
            <div slot="footer" style="float: right; margin-top: 10px">
              <el-button @click="cancelWalterAdd">取 消</el-button>
              <el-button type="primary" @click="handleWalterAddKeyWordThrottle"
                >确 定</el-button
              >
            </div>
          </div>
        </el-dialog>

        <div class="hotanalyse-content">
          <div class="hotanalyse-content-pos clearfix">
            <div class="hotanalyse-content-left fl" style="position: relative;">
              <div class="hotanalyseLeft-header clearfix" style="position: absolute;">
                <span
                  style="font-size:14px;display: inline-block;height:46px;line-height: 46px;"
                  >热词统计</span
                >
                <el-button
                  class="fr"
                  style="margin-top:10px;margin-right: 20px;"
                  @click="removeKeyWord"
                  >移入水词
                </el-button>
                <el-button
                  class="fr"
                  style="margin-top:10px;margin-right: 20px;"
                  @click="addKeyWord"
                  >添加关键词</el-button
                >
              </div>
              <div class="hotanalyseLeft-content">
                <div class="hotanalyseLeft-content-pos" style="overflow-y: auto;">
                  <el-table
                    ref="multipleTable"
                    highlight-current-row
                    :data="tableCiData"
                    border
                    @row-click="rowClick"
                    style="width: 100%"
                  >
                    <el-table-column type="selection" width="55"> </el-table-column>
                    <el-table-column type="index" label="序号" width="70">
                    </el-table-column>
                    <el-table-column prop="keyword" label="词语"> </el-table-column>
                    <el-table-column prop="times" label="热度" show-overflow-tooltip>
                    </el-table-column>
                    <!-- <el-table-column
                      prop="ratio"
                      label="环比">

                    </el-table-column> -->
                  </el-table>
                </div>
              </div>
            </div>
            <div class="hotanalyse-content-right fl">
              <div class="box">
                <div class="hotTop">
                  <ul>
                    <li @click="quShiTu(1)" class="activeQu" id="qushi">趋势图</li>
                    <li @click="quShiTu(2)" id="ci">词相关</li>
                    <li @click="quShiTu(3)" id="place">区域图</li>
                  </ul>
                </div>
                <div class="hotanalyseRight">
                  <div class="hotBox">
                    <div id="trendChart" style="width: 100%; height: 100%"></div>
                    <div
                      id="ciChart"
                      style="width: 100%; height: 100%; display: none"
                    ></div>
                    <div
                      id="placeChart"
                      style="width: 100%; height: 100%;display: none"
                    ></div>
                  </div>
                </div>
              </div>
              <!--<div class="hotanalyseRight">
                <span>趋势图</span>
                <div id="trendImage" style="height:90%; overflow: scroll;">

                </div>
              </div>-->
              <!--<div class="hotanalyseRightbottom">
                <span>词表图</span>
                <div id="wordImage"  style="height:200px;">

                </div>
              </div>-->
            </div>
          </div>
        </div>
      </div>
      <div class="timeanalyse">
        <div class="title">时段分析</div>
        <div class="timeanalyse-content" id="timeAnalyse"></div>
      </div>
      <el-dialog
        title="录音列表"
        :visible.sync="dialogTableRecorVisible"
        @close="closeRecord"
      >
        <el-button @click="exportExcel" class="out-btn" type="primary">导出</el-button>
        <el-table
          ref="multipleTable"
          :data="recordinglist"
          tooltip-effect="dark"
          style="width: 100%"
        >
          <el-table-column type="index" width="50"> </el-table-column>
          <el-table-column prop="callId" label="录音编号"> </el-table-column>
          <el-table-column
            prop="callSTime"
            label="录音开始时间"
            show-overflow-tooltip
            :formatter="dateFormat"
            width="120"
          >
          </el-table-column>
          <el-table-column prop="callTime" label="录音时长" :formatter="timeFormat">
          </el-table-column>
          <el-table-column prop="mblNo" label="电话号码"> </el-table-column>
          <el-table-column prop="seatName" label="坐席姓名"> </el-table-column>
          <el-table-column prop="deptId" label="坐席组"> </el-table-column>
        </el-table>
        <div class="fr m-tb-10">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPagerecord"
            :page-sizes="[10, 20, 30]"
            :page-size="limit"
            layout="total, sizes, prev, pager, next"
            :total="this.recordingtotal"
          >
          </el-pagination>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import $ from 'jquery'
import qs from 'qs'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
import cache from '../../../utils/cache.js' // 热点分析开始
import formatDate from '../../../utils/formatdate.js'
let CASTGC = cache.getItem('tgt_id')
let myChartCi
export default {
  data() {
    return {
      exportData: {},
      timetype: '', // 时段分析点击弹出详情
      recordinglist: [],
      currentAll: [], // 分页要过滤的所有数组
      offset: 0,
      limit: 10,
      currentPagerecord: 1, // 录音分页
      recordingtotal: 0, // 总页数
      dialogTableRecorVisible: false, // 弹出框
      showTree: false, // 树的显示隐藏
      totalNumberOfRecordings: 0,
      totalCountTwo: 0,
      todayTotal: 0,
      WeekData: [],
      occupationData: [], // 占比分析图的数据
      weekTotal: 0,
      monthTotal: 0,
      Today: '', // 默认时间 今天
      Week: '', // 默认时间 一周后
      Month: '', //  默认一个月
      recordingsTodayOption: {},
      trendOfOccupationOption: {},
      formRight: {
        region: '',
        times: [],
      },
      parames: {},
      timeparames: {},
      rateparmes: {},
      treeMenu: [], // 树菜单
      defaultProps: {
        children: 'children',
        label: 'className',
      },
      wordDefaultProps: {
        children: 'children',
        label: 'classTitle',
      },
      pickerOptions2: {
        shortcuts: [
          {
            text: '近一天',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 1)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      qushiVal: 1, // 热点分析那个图表展示
      qushiEchartsOption: {
        title: {
          text: '',
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: [],
        },

        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            boundaryGap: false,
            data: [],
            splitLine: {
              show: true,
            },
            axisLine: {
              show: false,
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: {
              show: true,
            },
            axisLine: {
              show: false,
            },
          },
        ],
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        series: [],
      }, // 热点分析 开始
      loading: false,
      activeName2: 'first',
      checkboxGroup1: ['上海'],
      checkboxGroup2: ['北京'],
      checkboxGroup3: ['广州'],
      cities: ['上海', '北京', '广州', '深圳'],
      mapOption: {
        series: [
          {
            type: 'map',
            data: [
              { name: '北京', value: Math.round(Math.random() * 1000) },
              { name: '天津', value: Math.round(Math.random() * 1000) },
              { name: '上海', value: Math.round(Math.random() * 1000) },
              { name: '重庆', value: Math.round(Math.random() * 1000) },
              { name: '河北', value: Math.round(Math.random() * 1000) },
              { name: '河南', value: Math.round(Math.random() * 1000) },
              { name: '云南', value: Math.round(Math.random() * 1000) },
              { name: '辽宁', value: Math.round(Math.random() * 1000) },
              { name: '黑龙江', value: Math.round(Math.random() * 1000) },
              { name: '湖南', value: Math.round(Math.random() * 1000) },
              { name: '安徽', value: Math.round(Math.random() * 1000) },
              { name: '山东', value: Math.round(Math.random() * 1000) },
              { name: '新疆', value: Math.round(Math.random() * 1000) },
              { name: '江苏', value: Math.round(Math.random() * 1000) },
              { name: '浙江', value: Math.round(Math.random() * 1000) },
              { name: '江西', value: Math.round(Math.random() * 1000) },
              { name: '湖北', value: Math.round(Math.random() * 1000) },
              { name: '广西', value: Math.round(Math.random() * 1000) },
              { name: '甘肃', value: Math.round(Math.random() * 1000) },
              { name: '山西', value: Math.round(Math.random() * 1000) },
              { name: '内蒙古', value: Math.round(Math.random() * 1000) },
              { name: '陕西', value: Math.round(Math.random() * 1000) },
              { name: '吉林', value: Math.round(Math.random() * 1000) },
              { name: '福建', value: Math.round(Math.random() * 1000) },
              { name: '贵州', value: Math.round(Math.random() * 1000) },
              { name: '广东', value: Math.round(Math.random() * 1000) },
              { name: '青海', value: Math.round(Math.random() * 1000) },
              { name: '西藏', value: Math.round(Math.random() * 1000) },
              { name: '四川', value: Math.round(Math.random() * 1000) },
              { name: '宁夏', value: Math.round(Math.random() * 1000) },
              { name: '海南', value: Math.round(Math.random() * 1000) },
              { name: '台湾', value: Math.round(Math.random() * 1000) },
              { name: '香港', value: Math.round(Math.random() * 1000) },
              { name: '澳门', value: Math.round(Math.random() * 1000) },
            ],
          },
        ],
      },
      optionRate: {
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          show: true,
          data: [],
          // right: 10,
          // top: '45%',
          // orient: 'vertical'
        },
        xAxis: [
          {
            data: [],
          },
        ],
        yAxis: {},
        series: [
          {
            name: '',
            type: 'line',
            stack: '广告',
            data: [],
            itemStyle: {
              normal: {
                color: '#50b4ff',
              },
            },
          },
        ],
      },
      roleType: '0',
      addTitle: '添加关键词',
      addWalterTitle: '添加水词',
      currentNode: '',
      addWordModalVisible: false,
      addWalterWordModalVisible: false,
      wordDescribe: '',
      classId: 0,
      treeData: [],
      treeWalterData: [],
      selectKeyWord: '',
      callSTime_Min: '',
      callSTime_Max: '',
      searchModel: {
        buss_wordType: '1', // 词汇类型
        function: '1', // 统计的单位，1为录音量，2为平均时长，3为总通话时长
        wordRole: '0', // 角色 0为全部 1为客户 2为客服
      },
      yType: '1', // 纵坐标
      xAx: '2', // 横坐标
      groupBy: '', // groupBy字段，统计主副维度数据时使用
      mainSubDimentionValue: '', // 主维度的二级维度下拉框Value
      mainSubDimentionLabel: '', // 主维度的二级维度下拉框Label
      viceSubDimentionValue: '', // 副维度的二级维度下拉框Value
      viceSubDimentionLabel: '', // 副维度的二级维度下拉框Label
      value1: '', //
      value4: '',
      currentPage3: 1,
      tableCiData: [],
      option1: {
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: '',
        },
        toolbox: {
          show: true,
          feature: {
            saveAsImage: {
              show: false,
            },
          },
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        calculable: true,
        grid: {
          top: 80,
          bottom: 50,
        },
        xAxis: [
          {
            type: 'category',
            boundaryGap: false,
            data: [],
          },
        ],
        yAxis: [
          {
            type: 'value',
          },
        ],
        series: [],
      },
      option2: {
        title: {
          text: ' ',
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        tooltip: {
          show: true,
          formatter: function(params) {
            return '词语信息：' + params.name + '<br>词频：' + params.value / 10
          },
        },
        series: [
          {
            name: '词语',
            type: 'wordCloud',
            size: ['80%', '80%'],
            textRotation: [0, 0],
            textPadding: 10,
            autoSize: {
              enable: true,
              minSize: 14,
            },
            data: [],
          },
        ],
      },
      fullscreenLoading: false,
      keyword: '',
      mapData: [],
      cioption: {
        title: {
          text: '', // 标题
        },
        label: {
          normal: {
            show: true,
            textStyle: {
              fontSize: 12,
            },
          },
        },
        // 全局颜色，图例、节点、边的颜色都是从这里取，按照之前划分的种类依序选取
        // color: ['rgb(194,53,49)', 'rgb(178,144,137)', 'rgb(97,160,168)'],
        // sereis的数据: 用于设置图表数据之用
        series: [
          {
            name: '', // 系列名称
            type: 'graph', // 图表类型
            layout: 'force', // echarts3的变化，force是力向图，circular是和弦图
            symbolSize: 45,
            // focusNodeAdjacency: true,  // 突出相关
            force: {
              // gravity: 0.1,
              // symbol: 'pin',
              edgeLength: [100, 10], // 线的长度，这个距离也会受 repulsion，支持设置成数组表达边长的范围
              repulsion: 200, // 节点之间的斥力因子。值越大则斥力越大
            },
            // draggable: true, // 指示节点是否可以拖动
            roam: true, // 是否开启鼠标缩放和平移漫游。默认不开启。如果只想要开启缩放或者平移，可以设置成 'scale' 或者 'move'。设置成 true 为都开启
            label: {
              // 图形上的文本标签，可用于说明图形的一些数据信息
              normal: {
                show: true, // 显示
                color: '#fff',
                position: 'inside', // 相对于节点标签的位置
                // 回调函数，你期望节点标签上显示什么
                formatter: function(params) {
                  return params.data.label
                },
              },
            },
            // 节点的style
            itemStyle: {
              normal: {
                label: { show: true },
                nodeStyle: {
                  brushType: 'both',
                  borderColor: 'rgba(255,215,0,0.4)',
                  borderWidth: 1,
                },
              },
            },
            // 关系边的公用线条样式
            lineStyle: {
              normal: {
                width: 3,
                type: 'solid',
                show: true,
                color: 'target', // 决定边的颜色是与起点相同还是与终点相同
                curveness: 0.3, // 边的曲度，支持从 0 到 1 的值，值越大曲度越大。
              },
            },
            categories: [],
            nodes: [],
            links: [],
          },
        ],
      },
    }
  },
  computed: {
    /* 专题ID */
    getThenaticAnalysisId() {
      console.log(this.$store.state.thenaticAnalysisId.subjectId)
      return this.$store.state.thenaticAnalysisId.subjectId
    },
  },
  methods: {
    /**
     *时间戳
     */
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatDate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    /**
     *时间long转为秒
     */
    timeFormat: function(row, column) {
      let time = row[column.property]
      let ftime = time / 1000
      if (ftime == undefined) {
        return ''
      }
      return ftime + '秒'
    },
    // 点击自己 还是除了自己以外的元素
    outside: function(e) {
      this.showTree = false
    },
    inside: function(e) {
      this.showTree = true
    },
    // 分页
    handleSizeChange(val) {
      console.log(val)
      this.limit = val
      this.handleCurrentChange(1)
    },
    handleCurrentChange(val) {
      this.currentPagerecord = val
      this.offset = (val - 1) * this.limit // 上一页结束的数 + 1 就是 当前页第一个数组
      let firstoffset = this.offset
      let lastoffset = this.offset + this.limit
      /*
       * 数据过滤
       * */
      let _this = this
      _this.recordinglist = []
      for (let i = firstoffset; i < lastoffset; i++) {
        if (_this.recordingtotal > i) {
          _this.recordinglist.push(_this.currentAll[i])
        }
      }
    },
    rowClick(row) {
      let keyword = row.keyWord
      this.selectKeyWord = keyword
      this.keyword = keyword
      myChartCi && myChartCi.dispose()
      let _this = this
      // 趋势图
      _this.getQuShiTu()
      // 地图
      let times = ''
      _this.getMap(keyword, times)
      // 词相关
      _this.getci(keyword)
    },
    // 概览占比走势图以及时段分析等导出
    exportExcel: function() {
      let params = this.exportData
      params.accessToken = cache.getItem('tgt_id')
      let form = document.createElement('form')
      form.method = 'post'
      form.target = '_blank'
      for (let key in params) {
        let input = document.createElement('input')
        input.name = key
        input.value = params[key]
        form.appendChild(input)
      }
      if (this.timetype == '1') {
        form.action = currentBaseUrl + '/thematicView/exportTimeIntervalRecordList.do'
      } else {
        form.action = currentBaseUrl + '/thematicView/exportRecordList.do'
      }
      document.querySelector('body').appendChild(form)
      form.submit()
      document.querySelector('body').removeChild(form)
    },
    // 获取得到分类树
    getTreeMenu() {
      let _this = this
      let params = {
        specialSubjectId: _this.getThenaticAnalysisId,
      }
      this.axios
        .post(
          currentBaseUrl + '/specialSubject/getSpecialSubjectFullData.do',
          qs.stringify(params)
        )
        .then(function(response) {
          _this.treeMenu = response.data.specialSubjectClassTree
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取菜单出现问题',
          })
        })
    },
    // 树节点点击
    handleNodeClick(data) {
      this.currentNode = data
      this.classId = data.classId
      this.getKeyWords()
    },
    // 选中的node节点
    getCheckedKeys() {
      let regions = this.$refs.keyWordsMenu.getCheckedNodes()
      let regionArr = []
      let regionIdArr = []
      // let regionIds = ''
      regions.forEach(function(item) {
        regionArr.push(item.className)
        regionIdArr.push(item.subjectClassId)
      })
      this.formRight.region = regionIdArr.toString()
      this.formRight.regionName = regionArr.toString()
    },
    // 清空树
    resetChecked() {
      this.$refs.keyWordsMenu.setCheckedKeys([])
      this.formRight.regionName = ''
      this.formRight.region = ''
    },
    getKeyWords() {
      let _this = this
      let params = {}
      params.wordlibType = this.wordlibType
      params.pagesize = this.pageSize
      params.pageindex = this.currentPage
      params.wordName = this.wordName
      params.classId = this.classId
      params.begin = 1
      params.end = 1
      this.axios
        .post(currentBaseUrl + '/vocabulary/queryPage.do', qs.stringify(params))
        .then(function(response) {
          _this.total = response.data.Count
          _this.keyWords = response.data.Data
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 默认一周时间
    getAWeekTime: function() {
      let myDate = new Date()
      let myWeekDate = new Date()
      let myMonthDate = new Date()
      let weekmm = myWeekDate.getTime() - 7 * 24 * 3600 * 1000
      let monthmm = myMonthDate.getTime() - 30 * 24 * 3600 * 1000
      this.Today = this.gettimeform(myDate.getTime())
      this.Week = this.gettimeform(weekmm)
      this.Month = this.gettimeform(monthmm)
      this.formRight.times = [this.Week, this.Today]
    },
    // 今天录音数图表
    getTodayRecording: function(TodayData) {
      let recordingsToday = this.$echarts.init(document.getElementById('recordingsToday'))
      this.recordingsTodayOption = {
        backgroundColor: '#fff',
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        tooltip: {
          trigger: 'item',
        },
        title: {
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        legend: {
          show: false,
          orient: 'vertical',
          x: 'left',
          data: ['直接访问', '邮件营销', '联盟广告', '视频广告', '搜索引擎'],
        },
        series: [
          {
            type: 'pie',
            radius: ['30%', '90%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: 'center',
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: '12',
                  fontWeight: 'bold',
                },
              },
            },
            labelLine: {
              normal: {
                show: false,
              },
            },
            data: TodayData,
          },
        ],
      }
      recordingsToday.setOption(this.recordingsTodayOption)
      document.oncontextmenu = function() {
        return false
      }
      let that = this
      recordingsToday.on('contextmenu', function(params) {
        that.timetype = '2'
        that.exportData = {
          subjectId: that.getThenaticAnalysisId,
          subjectClassId: params.data.id,
          star: params.data.star,
          end: params.data.end + ' ' + '23:59:59',
        }
        that.showMoremodel(that.exportData)
      })
    },
    // 本周录音数图表
    getWeekRecording: function(WeekData) {
      let recordingsWeek = this.$echarts.init(document.getElementById('recordingsWeek'))
      let recordingsWeekOption = {
        backgroundColor: '#fff',
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        tooltip: {
          trigger: 'item',
        },
        title: {
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        legend: {
          show: false,
          orient: 'vertical',
          x: 'left',
          data: ['直接访问', '邮件营销', '联盟广告', '视频广告', '搜索引擎'],
        },
        series: [
          {
            type: 'pie',
            radius: ['30%', '90%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: 'center',
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: '12',
                  fontWeight: 'bold',
                },
              },
            },
            labelLine: {
              normal: {
                show: false,
              },
            },
            data: WeekData,
          },
        ],
      }
      recordingsWeek.setOption(recordingsWeekOption)
      let that = this
      recordingsWeek.on('contextmenu', function(params) {
        that.timetype = '2'
        that.exportData = {
          subjectId: that.getThenaticAnalysisId,
          subjectClassId: params.data.id,
          star: that.Week,
          end: that.Today + ' ' + '23:59:59',
        }
        that.showMoremodel(that.exportData)
      })
    },
    // 本月录音数图表
    getMonthRecording: function(MonthData) {
      let recordingsMonth = this.$echarts.init(document.getElementById('recordingsMonth'))
      let recordingsMonthOption = {
        backgroundColor: '#fff',
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        tooltip: {
          trigger: 'item',
        },
        title: {
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        legend: {
          show: false,
          orient: 'vertical',
          x: 'left',
          data: ['直接访问', '邮件营销', '联盟广告', '视频广告', '搜索引擎'],
        },
        series: [
          {
            type: 'pie',
            radius: ['30%', '90%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: 'center',
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: '12',
                  fontWeight: 'bold',
                },
              },
            },
            labelLine: {
              normal: {
                show: false,
              },
            },
            data: MonthData,
          },
        ],
      }
      recordingsMonth.setOption(recordingsMonthOption)
      let that = this
      recordingsMonth.on('contextmenu', function(params) {
        that.timetype = '2'
        that.exportData = {
          subjectId: that.getThenaticAnalysisId,
          subjectClassId: params.data.id,
          star: that.Month,
          end: that.Today + ' ' + '23:59:59',
        }
        that.showMoremodel(that.exportData)
      })
    },
    // 占比分析图表
    getOccupationRatioAnalysis: function(OccupationRatioData) {
      let occupationRatio = this.$echarts.init(document.getElementById('occupationRatio'))
      let occupationRatioOption = {
        backgroundColor: '#fff',
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        tooltip: {
          trigger: 'item',
        },
        title: {
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        legend: {
          show: false,
          orient: 'vertical',
          x: 'left',
          data: ['直接访问', '邮件营销', '联盟广告', '视频广告', '搜索引擎'],
        },
        series: [
          {
            type: 'pie',
            radius: ['30%', '90%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: 'center',
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: '12',
                  fontWeight: 'bold',
                },
              },
            },
            labelLine: {
              normal: {
                show: false,
              },
            },
            data: OccupationRatioData,
          },
        ],
      }
      occupationRatio.setOption(occupationRatioOption)
      let _this = this
      occupationRatio.on('click', function(params) {
        let paramsId = params.data.id
        // 进入子集前，先存储当前占比数据，方便返回时直接调用 (修改：调整到获取子集再存储当前占比，以防没有子集的情况下多次点击)
        // _this.occupationData = OccupationRatioData
        // 采用节流方式，防止多次提交
        _this.lodashThrottle.throttle(
          _this.getoccupationRatioChild(paramsId, OccupationRatioData),
          _this
        )
        // _this.getoccupationRatioChild(paramsId, OccupationRatioData)
      })
      occupationRatio.on('contextmenu', function(params) {
        _this.timetype = '2'
        _this.exportData = {
          subjectId: _this.getThenaticAnalysisId,
          subjectClassId: params.data.id,
          star:
            _this.formRight.times == undefined ||
            _this.formRight.times == '' ||
            _this.formRight.times.length <= 0
              ? _this.Week
              : _this.gettimeform(_this.formRight.times[0]),
          end:
            _this.formRight.times == undefined ||
            _this.formRight.times == '' ||
            _this.formRight.times.length <= 0
              ? _this.Today
              : _this.gettimeform(_this.formRight.times[1]) + ' ' + '23:59:59',
        }
        _this.showMoremodel(_this.exportData)
      })
    },
    // 占比单机 进入子集占比图
    getoccupationRatioChild: function(paramsId, OccupationRatioData) {
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        this.rateparmes = {
          subjectId: this.getThenaticAnalysisId,
          subjectClassId: paramsId,
          star: this.Week,
          end: this.Today, // 查询条件结束时间
        }
      } else {
        this.rateparmes = {
          subjectId: this.getThenaticAnalysisId,
          subjectClassId: paramsId,
          star: this.gettimeform(this.formRight.times[0]), // 查询条件开始时间
          end: this.gettimeform(this.formRight.times[1]) + ' ' + '23:59:59', // 查询条件结束时间
        }
      }
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/thematicView/proportionate.do',
          qs.stringify(_this.rateparmes)
        )
        .then((res) => {
          if (res.data != '') {
            let childOccupationRatioData = res.data.countList
            let childData = []
            for (let i = 0; i < childOccupationRatioData.length; i++) {
              childData.push({
                name: childOccupationRatioData[i].className,
                value: childOccupationRatioData[i].classCount,
                id: childOccupationRatioData[i].subjectClassId,
              })
            }
            // 如果没有传子类id（paramsId），表示是从查询来的，需要记住查询后的占比数据，点返回按钮时用到该数据
            if (paramsId == null || paramsId == '' || paramsId == undefined) {
              _this.occupationData = childData
            } else {
              _this.occupationData = OccupationRatioData
            }
            _this.getOccupationRatioAnalysis(childData)
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 占比分析 返回父层
    goBackUp: function() {
      this.getOccupationRatioAnalysis(this.occupationData)
    },
    // 走势图分析图表
    getTrendOfAnalysis: function(xarr, dataArr) {
      let trendOfOccupation = this.$echarts.init(
        document.getElementById('trendOfOccupation')
      )
      if (trendOfOccupation && trendOfOccupation.dispose) {
        trendOfOccupation.dispose()
      }
      trendOfOccupation = this.$echarts.init(document.getElementById('trendOfOccupation'))
      this.trendOfOccupationOption = {
        backgroundColor: '#fff',
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: dataArr.map(function(d) {
            return d.name
          }),
        },
        calculable: true,
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: xarr,
          axisTick: {
            interval: 'auto',
          },
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            formatter: '{value}',
          },
        },
        series: [],
      }
      let that = this
      dataArr.forEach(function(d, i) {
        that.trendOfOccupationOption.series.push({
          type: 'line',
          markPoint: {
            data: [{ type: 'max', name: '最大值', id: d.id }],
          },
          name: d.name,
          data: d.values,
          id: d.id,
        })
      })
      trendOfOccupation.on('click', function(params) {
        let paramsId = params.data.id
        that.getTrendOfAnalysisList(paramsId)
      })
      trendOfOccupation.on('contextmenu', function(params) {
        that.timetype = '2'
        if (params.name != '最大值') {
          that.exportData = {
            subjectId: that.getThenaticAnalysisId,
            subjectClassId: params.seriesId,
            star: params.name,
            end: params.name + ' ' + '23:59:59',
          }
          that.showMoremodel(that.exportData)
        }
      })
      trendOfOccupation.setOption(this.trendOfOccupationOption)
    },
    // 时段分析图添加
    getTimeAnalysis: function(timeData) {
      let hours = [
        '0',
        '1',
        '2',
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9',
        '10',
        '11',
        '12',
        '13',
        '14',
        '15',
        '16',
        '17',
        '18',
        '19',
        '20',
        '21',
        '22',
        '23',
      ]
      let days = ['周六', '周五', '周四', '周三', '周二', '周一', '周日']
      // let data = [[0, 0, 0], [0, 1, 1], [0, 2, 0], [0, 3, 0], [0, 4, 0], [0, 5, 0], [0, 6, 0], [0, 7, 0], [0, 8, 0], [0, 9, 0], [0, 10, 0], [0, 11, 2], [0, 12, 4], [0, 13, 1], [0, 14, 1], [0, 15, 3], [0, 16, 4], [0, 17, 6], [0, 18, 4], [0, 19, 4], [0, 20, 3], [0, 21, 3], [0, 22, 2], [0, 23, 5], [1, 0, 7], [1, 1, 0], [1, 2, 0], [1, 3, 0], [1, 4, 0], [1, 5, 0], [1, 6, 0], [1, 7, 0], [1, 8, 0], [1, 9, 0], [1, 10, 5], [1, 11, 2], [1, 12, 2], [1, 13, 6], [1, 14, 9], [1, 15, 11], [1, 16, 6], [1, 17, 7], [1, 18, 8], [1, 19, 12], [1, 20, 5], [1, 21, 5], [1, 22, 7], [1, 23, 2], [2, 0, 1], [2, 1, 1], [2, 2, 0], [2, 3, 0], [2, 4, 0], [2, 5, 0], [2, 6, 0], [2, 7, 0], [2, 8, 0], [2, 9, 0], [2, 10, 3], [2, 11, 2], [2, 12, 1], [2, 13, 9], [2, 14, 8], [2, 15, 10], [2, 16, 6], [2, 17, 5], [2, 18, 5], [2, 19, 5], [2, 20, 7], [2, 21, 4], [2, 22, 2], [2, 23, 4], [3, 0, 7], [3, 1, 3], [3, 2, 0], [3, 3, 0], [3, 4, 0], [3, 5, 0], [3, 6, 0], [3, 7, 0], [3, 8, 1], [3, 9, 0], [3, 10, 5], [3, 11, 4], [3, 12, 7], [3, 13, 14], [3, 14, 13], [3, 15, 12], [3, 16, 9], [3, 17, 5], [3, 18, 5], [3, 19, 10], [3, 20, 6], [3, 21, 4], [3, 22, 4], [3, 23, 1], [4, 0, 1], [4, 1, 3], [4, 2, 0], [4, 3, 0], [4, 4, 0], [4, 5, 1], [4, 6, 0], [4, 7, 0], [4, 8, 0], [4, 9, 2], [4, 10, 4], [4, 11, 4], [4, 12, 2], [4, 13, 4], [4, 14, 4], [4, 15, 14], [4, 16, 12], [4, 17, 1], [4, 18, 8], [4, 19, 5], [4, 20, 3], [4, 21, 7], [4, 22, 3], [4, 23, 0], [5, 0, 2], [5, 1, 1], [5, 2, 0], [5, 3, 3], [5, 4, 0], [5, 5, 0], [5, 6, 0], [5, 7, 0], [5, 8, 2], [5, 9, 0], [5, 10, 4], [5, 11, 1], [5, 12, 5], [5, 13, 10], [5, 14, 5], [5, 15, 7], [5, 16, 11], [5, 17, 6], [5, 18, 0], [5, 19, 5], [5, 20, 3], [5, 21, 4], [5, 22, 2], [5, 23, 0], [6, 0, 1], [6, 1, 0], [6, 2, 0], [6, 3, 0], [6, 4, 0], [6, 5, 0], [6, 6, 0], [6, 7, 0], [6, 8, 0], [6, 9, 0], [6, 10, 1], [6, 11, 0], [6, 12, 2], [6, 13, 1], [6, 14, 3], [6, 15, 4], [6, 16, 0], [6, 17, 0], [6, 18, 0], [6, 19, 0], [6, 20, 1], [6, 21, 2], [6, 22, 2], [6, 23, 6]]
      let data = timeData
      let maxV = 10
      data = data.map(function(item) {
        if (item[2] > maxV) {
          maxV = Math.ceil(item[2] / 10) * 10
        }
        return [item[1], item[0], item[2] || '-']
      })
      let timeAnalyse = this.$echarts.init(document.getElementById('timeAnalyse'))
      let timeAnalyseOption = {
        backgroundColor: '#fff',
        tooltip: {
          position: 'top',
          trigger: 'item',
        },
        animation: false,
        grid: {
          height: '80%',
          y: '10%',
        },
        xAxis: {
          type: 'category',
          data: hours,
          splitArea: {
            show: true,
          },
        },
        yAxis: {
          type: 'category',
          data: days,
          splitArea: {
            show: true,
          },
        },
        visualMap: {
          min: 0,
          max: maxV,
          type: 'continuous',
          realtime: false,
          calculable: true,
          left: '2%',
          top: '20%',
          color: ['#4dacd3', '#b2e8fe'],
        },
        series: [
          {
            name: '',
            type: 'heatmap',
            data: data,
            label: {
              normal: {
                show: true,
              },
            },
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
              },
            },
          },
        ],
      }
      let that = this
      timeAnalyse.setOption(timeAnalyseOption)
      document.oncontextmenu = function() {
        return false
      }
      timeAnalyse.on('contextmenu', function(params) {
        that.timetype = '1'
        that.exportData = {
          subjectId: that.getThenaticAnalysisId,
          subjectClassId: that.formRight.region,
          star:
            that.formRight.times == undefined ||
            that.formRight.times == '' ||
            that.formRight.times.length <= 0
              ? that.Week
              : that.gettimeform(that.formRight.times[0]),
          end:
            that.formRight.times == undefined ||
            that.formRight.times == '' ||
            that.formRight.times.length <= 0
              ? that.Today
              : that.gettimeform(that.formRight.times[1]),
          cols: params.value[1],
          row: params.value[0],
        }
        that.showmodal(that.exportData)
      })
    },
    // 时间详情弹窗
    showmodal: function(params) {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/thematicView/getTimeIntervalRecordList.do',
          qs.stringify(params)
        )
        .then((res) => {
          _this.currentAll = res.data
          _this.recordingtotal = _this.currentAll.length
          // 获取当前页的数据
          _this.handleCurrentChange(1)
          if (_this.recordinglist.length > 0) {
          }
          _this.dialogTableRecorVisible = true
        })
    },
    // 概览 占比 走势录音清单公用封装
    showMoremodel: function(parmes) {
      let _this = this
      this.axios
        .post(currentBaseUrl + '/thematicView/getRecordList.do', qs.stringify(parmes))
        .then((res) => {
          _this.currentAll = res.data.Data
          _this.recordingtotal = res.data.Count
          // 获取当前页的数据
          _this.handleCurrentChange(1)
          if (_this.$data.recordinglist.length > 0) {
          }
          _this.dialogTableRecorVisible = true
        })
    },
    // 查找
    searchByName: function() {
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        this.$message({
          message: '请选择日期范围',
          type: 'warning',
        })
      }
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times[0] == null ||
        this.formRight.times[1] == null ||
        this.formRight.times.length <= 0
      ) {
        this.formRight.times = undefined
        this.$message({
          message: '请选择日期范围',
          type: 'warning',
        })
        this.callSTime_Min = this.Today
        this.callSTime_Max = this.Week
      } else {
        this.callSTime_Min = this.gettimeform(this.formRight.times[0])
        this.callSTime_Max = this.gettimeform(this.formRight.times[1]) // 查询条件结束时间
      }
      this.keyword = ''
      this.selectKeyWord = ''
      this.getQuShiCharts()
      // this.getTreeMenu()
      this.getoccupationRatioChild()
      this.getTrendOfAnalysisList()
      this.getTimeAnalusisList()
      this.searchHot() // 热点分析查找
    },
    // 获得列表概览
    getOverviewlist: function() {
      let _this = this
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        this.pageListparams = {
          subjectId: this.getThenaticAnalysisId,
          star: _this.Week,
          end: _this.Today, // 查询条件结束时间
        }
      } else {
        this.pageListparams = {
          subjectId: this.getThenaticAnalysisId,
          star: _this.gettimeform(_this.formRight.times[0]),
          end: _this.gettimeform(_this.formRight.times[1]), // 查询条件结束时间
        }
      }
      this.axios
        .post(
          currentBaseUrl + '/thematicView/overview.do',
          qs.stringify(_this.pageListparams)
        )
        .then((res) => {
          _this.todayTotal = res.data.day.totalCount
          _this.weekTotal = res.data.week.totalCount
          _this.monthTotal = res.data.month.totalCount
          _this.totalNumberOfRecordings = res.data.totalCount
          let TodaySeriesdata = res.data.day.countList
          let WeekSeriesdata = res.data.week.countList
          let MonthSeriesdata = res.data.month.countList
          let TodayData = []
          let WeekData = []
          let MonthData = []
          // 今天获取
          for (let i = 0; i < TodaySeriesdata.length; i++) {
            TodayData.push({
              name: TodaySeriesdata[i].className,
              value: TodaySeriesdata[i].classCount,
              id: TodaySeriesdata[i].subjectClassId,
              star: _this.Today,
              end: _this.Today,
            })
          }
          _this.getTodayRecording(TodayData)
          // 本周获取
          for (let w = 0; w < WeekSeriesdata.length; w++) {
            WeekData.push({
              name: WeekSeriesdata[w].className,
              value: WeekSeriesdata[w].classCount,
              id: WeekSeriesdata[w].subjectClassId,
              star: _this.Today,
              end: _this.Week,
            })
          }
          _this.WeekData = WeekData
          _this.getWeekRecording(WeekData)
          _this.occupationData = WeekData
          _this.getOccupationRatioAnalysis(_this.occupationData)
          // 本月获取
          for (let m = 0; m < MonthSeriesdata.length; m++) {
            MonthData.push({
              name: MonthSeriesdata[m].className,
              value: MonthSeriesdata[m].classCount,
              id: WeekSeriesdata[m].subjectClassId,
              star: _this.Today,
              end: _this.Month,
            })
          }
          _this.getMonthRecording(MonthData)
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 获取走势分析列表
    getTrendOfAnalysisList: function() {
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        this.parames = {
          subjectId: this.getThenaticAnalysisId, // 专题id
          subjectClassId: this.formRight.region, // 分类id，多个时以逗号分隔
          star: this.Week,
          end: this.Today, // 查询条件结束时间
        }
      } else {
        this.parames = {
          subjectId: this.getThenaticAnalysisId, // 专题id
          subjectClassId: this.formRight.region, // 分类id，多个时以逗号分隔
          star: this.gettimeform(this.formRight.times[0]),
          end: this.gettimeform(this.formRight.times[1]), // 查询条件结束时间
        }
      }
      this.axios
        .post(currentBaseUrl + '/thematicView/trendCount.do', qs.stringify(this.parames))
        .then((res) => {
          let trendData = res.data
          let dataArr = []
          let Xdata = []
          let xarr = []
          Xdata = trendData[0].countMap
          for (let i in Xdata) {
            xarr.push(i)
          }
          trendData.forEach(function(d) {
            let data = {
              name: d.className,
              id: d.subjectClassId,
              keys: [],
              values: [],
            }
            for (const [key, value] of Object.entries(d.countMap)) {
              data.keys.push(key)
              data.values.push(value)
            }
            dataArr.push(data)
          })
          this.getTrendOfAnalysis(xarr, dataArr)
        })
    },
    // 获取时段分析列表
    getTimeAnalusisList: function() {
      let that = this
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        this.timeparames = {
          subjectId: this.getThenaticAnalysisId, // 专题id
          subjectClassId: this.formRight.region, // 分类id，多个时以逗号分隔
          star: that.Week,
          end: that.Today, // 查询条件结束时间
        }
      } else {
        this.timeparames = {
          subjectId: this.getThenaticAnalysisId, // 专题id
          subjectClassId: this.formRight.region, // 分类id，多个时以逗号分隔
          star: that.gettimeform(that.formRight.times[0]),
          end: that.gettimeform(that.formRight.times[1]), // 查询条件结束时间
        }
      }
      this.axios
        .post(
          currentBaseUrl + '/thematicView/timeInterval.do',
          qs.stringify(this.timeparames)
        )
        .then((res) => {
          let timeData = res.data
          let everyData = []
          for (let i = 0; i < timeData.length; i++) {
            let Ydata = timeData[i].ordinateCount
            for (let j in Ydata) {
              let XYdata = []
              XYdata.push(timeData[i].abscissa * 1)
              XYdata.push(j)
              // 数据为0时处理
              /* let jj = j * 1 + 1
                 if ((jj % 5) == 0) {
                 XYdata.push(Ydata[j] * 1 + jj)
                 } else {
                 XYdata.push(Ydata[j] * 1)
                 } */
              XYdata.push(Ydata[j] * 1)
              everyData.push(XYdata)
            }
          }
          that.getTimeAnalysis(everyData)
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    goBackList: function() {
      this.$router.push('/thematicAnalysis')
    },
    /*
     * 热点分析 开始的地方
     * */
    quShiTu: function(val) {
      if (val === 1) {
        this.qushiVal = 1
        $('#trendChart').show()
        $('#ciChart').hide()
        $('#placeChart').hide()
        $('#qushi').addClass('activeQu')
        $('#ci').removeClass('activeQu')
        $('#place').removeClass('activeQu')
      } else if (val === 2) {
        this.qushiVal = 2
        $('#trendChart').hide()
        $('#ciChart').show()
        $('#placeChart').hide()
        $('#qushi').removeClass('activeQu')
        $('#ci').addClass('activeQu')
        $('#place').removeClass('activeQu')
        myChartCi = this.$echarts.init(document.getElementById('ciChart'))
        myChartCi.resize()
      } else {
        this.qushiVal = 3
        $('#trendChart').hide()
        $('#ciChart').hide()
        $('#placeChart').show()
        $('#qushi').removeClass('activeQu')
        $('#ci').removeClass('activeQu')
        $('#place').addClass('activeQu')
        let myChartPlace = this.$echarts.init(document.getElementById('placeChart'))
        myChartPlace.resize()
      }
    },
    getQuShiTu() {
      let _this = this
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        _this.callSTime_Min = _this.Week
        _this.callSTime_Max = _this.Today
      } else {
        _this.callSTime_Min = this.gettimeform(this.formRight.times[0])
        _this.callSTime_Max = this.gettimeform(this.formRight.times[1])
      }
      let params = {}
      params.beginDate = _this.callSTime_Min
      params.endDate = _this.callSTime_Max
      params.wordRole = this.searchModel.wordRole || '-1'
      params.buss_wordType = this.searchModel.buss_wordType
      params.keyWord = this.keyword
      params.subjectClassIds = this.formRight.region // 分类id，多个时以逗号分隔
      let urlQs = currentBaseUrl + '/hotAnlys/getTrendData.do'
      this.axios.post(urlQs, qs.stringify(params)).then(function(response) {
        if (response.data.dateList.length > 0 && response.data.trendData.length > 0) {
          let dateList = response.data.dateList
          let trendData = response.data.trendData
          let dateData = []
          let trend = []
          let nums
          let keywords = _this.keyword
          if (keywords != null && keywords != undefined && keywords != '') {
            let keywordArr = keywords.split(',')
            nums = keywordArr.length
          } else {
            if (trendData.length <= 5) {
              nums = trendData.length
            } else {
              nums = 5
            }
          }
          for (let i = 0; i < dateList.length; i++) {
            dateData[i] = dateList[i][0]
          }
          // series
          for (let j = 0; j < nums; j++) {
            trend[j] = {
              name: trendData[j].keyword,
              type: 'line',
              // stack: '总量',
              // areaStyle: {normal: {}},
              data: trendData[j].timesList,
            }
          }
          // legend data
          let legendData = []
          for (let p = 0; p < nums; p++) {
            legendData[p] = trendData[p].keyword
          }
          // xAxis
          let xAxisData = []
          for (let a = 0; a < dateList.length; a++) {
            xAxisData[a] = dateList[a]
          }
          let option = {
            title: {
              text: '',
              textStyle: {
                color: '#5e6d82',
                fontSize: 14,
                fontWieght: 'normal',
              },
            },
            tooltip: {
              trigger: 'axis',
            },
            legend: {
              data: [],
            },

            grid: {
              left: '3%',
              right: '4%',
              bottom: '3%',
              containLabel: true,
            },
            xAxis: [
              {
                type: 'category',
                boundaryGap: false,
                data: [],
                splitLine: {
                  show: true,
                },
                axisLine: {
                  show: false,
                },
              },
            ],
            yAxis: [
              {
                type: 'value',
                splitLine: {
                  show: true,
                },
                axisLine: {
                  show: false,
                },
              },
            ],
            color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
            series: [],
          }
          option.legend.data = legendData
          option.xAxis[0].data = xAxisData
          option.series = trend
          let myQushiChart = _this.$echarts.init(document.getElementById('trendChart'))
          myQushiChart.setOption(option, true)
          myQushiChart.on('contextmenu', function(params) {
            _this.timetype = '2'
            _this.exportData = {
              subjectId: _this.getThenaticAnalysisId,
              keyWords: params.seriesName,
              roleType: _this.searchModel.wordRole || '-1',
              star: params.name,
              end: params.name + ' ' + '23:59:59',
            }
            _this.showMoremodel(_this.exportData)
          })
        } else {
          console.log('没有数据')
        }
      })
    },
    getci(word) {
      let _this = this
      let ciparams = {}
      let wordData = []
      ciparams.word = word
      // 词相关数据画布渲染
      myChartCi = this.$echarts.init(document.getElementById('ciChart'))
      let categoriesList = [{ id: 0, name: '根' }]
      let linksList = [{ source: 0, target: 0 }]
      let nodesData = [
        {
          id: 0,
          category: 0,
          label: word,
          name: 0,
          symbolSize: 60,
          ignore: false,
          flag: true,
        },
      ]
      this.axios
        .post(currentBaseUrl + '/hotAnlys/getRelatedWords.do', qs.stringify(ciparams))
        .then((res) => {
          if (res.data.length > 0) {
            let dataLength
            if (res.data.length >= 15) {
              dataLength = 15
            } else {
              dataLength = res.data.length
            }
            for (let i = 0; i < dataLength; i++) {
              wordData[i] = {
                id: i + 1,
                category: 1,
                label: res.data[i].name,
                name: i + 1,
                symbolSize: res.data[i].score * 90,
                ignore: false,
                flag: true,
              }
            }
            let links = []
            for (let i = 0; i < dataLength; i++) {
              links[i] = {
                source: 0,
                target: i + 1,
              }
            }
            let categories = []
            for (let i = 0; i < dataLength; i++) {
              categories[i] = {
                id: i + 1,
                name: i + 1 + '层',
              }
            }
            _this.cioption.series[0].nodes = nodesData.concat(wordData)
            _this.cioption.series[0].categories = categories
            _this.cioption.series[0].links = links
            myChartCi.setOption(_this.cioption)
          } else {
            _this.cioption.series[0].nodes = nodesData
            _this.cioption.series[0].categories = categoriesList
            _this.cioption.series[0].links = linksList
            myChartCi.setOption(_this.cioption)
          }
        })
        .catch(function(error) {
          console.log(error)
        })
      myChartCi.on('click', function(params) {
        let paramsList = params
        _this.getClick(paramsList)
      })
    },
    getMap(keyword, times) {
      let params = {}
      let _this = this
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        _this.callSTime_Min = _this.Week
        _this.callSTime_Max = _this.Today
      } else {
        _this.callSTime_Min = this.gettimeform(this.formRight.times[0])
        _this.callSTime_Max = this.gettimeform(this.formRight.times[1])
      }
      params.beginDate = _this.callSTime_Min
      params.endDate = _this.callSTime_Max
      params.wordRole = this.searchModel.wordRole || '-1'
      params.buss_wordType = this.searchModel.buss_wordType
      params.keyWord = keyword
      params.subjectClassId = this.formRight.region // 分类id，多个时以逗号分隔
      params.subjectId = _this.getThenaticAnalysisId
      let url = currentBaseUrl + '/hotAnlys/getAreaData.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.area != null) {
            // let mdata = []
            let mmdata = response.data.area
            /* for (let i = 0; i < mmdata.length; i++) {
               mdata[i] = {
               name: mmdata[i].city,
               value: Object.values(mmdata[i].keywords)[0]
               }
               } */
            let legenddata = []
            for (let j = 0; j < mmdata.length; j++) {
              legenddata[j] = mmdata[j].city
            }
            let geoCoordMap = {
              海门: [121.15, 31.89],
              鄂尔多斯: [109.781327, 39.608266],
              招远: [120.38, 37.35],
              舟山: [122.207216, 29.985295],
              齐齐哈尔: [123.97, 47.33],
              盐城: [120.13, 33.38],
              赤峰: [118.87, 42.28],
              青岛: [120.33, 36.07],
              乳山: [121.52, 36.89],
              金昌: [102.188043, 38.520089],
              泉州: [118.58, 24.93],
              莱西: [120.53, 36.86],
              日照: [119.46, 35.42],
              胶南: [119.97, 35.88],
              南通: [121.05, 32.08],
              拉萨: [91.11, 29.97],
              云浮: [112.02, 22.93],
              梅州: [116.1, 24.55],
              文登: [122.05, 37.2],
              上海: [121.48, 31.22],
              攀枝花: [101.718637, 26.582347],
              威海: [122.1, 37.5],
              承德: [117.93, 40.97],
              厦门: [118.1, 24.46],
              汕尾: [115.375279, 22.786211],
              潮州: [116.63, 23.68],
              丹东: [124.37, 40.13],
              太仓: [121.1, 31.45],
              曲靖: [103.79, 25.51],
              烟台: [121.39, 37.52],
              福州: [119.3, 26.08],
              瓦房店: [121.979603, 39.627114],
              即墨: [120.45, 36.38],
              抚顺: [123.97, 41.97],
              玉溪: [102.52, 24.35],
              张家口: [114.87, 40.82],
              阳泉: [113.57, 37.85],
              莱州: [119.942327, 37.177017],
              湖州: [120.1, 30.86],
              汕头: [116.69, 23.39],
              昆山: [120.95, 31.39],
              宁波: [121.56, 29.86],
              湛江: [110.359377, 21.270708],
              揭阳: [116.35, 23.55],
              荣成: [122.41, 37.16],
              连云港: [119.16, 34.59],
              葫芦岛: [120.836932, 40.711052],
              常熟: [120.74, 31.64],
              东莞: [113.75, 23.04],
              河源: [114.68, 23.73],
              淮安: [119.15, 33.5],
              泰州: [119.9, 32.49],
              南宁: [108.33, 22.84],
              营口: [122.18, 40.65],
              惠州: [114.4, 23.09],
              江阴: [120.26, 31.91],
              蓬莱: [120.75, 37.8],
              韶关: [113.62, 24.84],
              嘉峪关: [98.289152, 39.77313],
              广州: [113.23, 23.16],
              延安: [109.47, 36.6],
              太原: [112.53, 37.87],
              清远: [113.01, 23.7],
              中山: [113.38, 22.52],
              昆明: [102.73, 25.04],
              寿光: [118.73, 36.86],
              盘锦: [122.070714, 41.119997],
              长治: [113.08, 36.18],
              深圳: [114.07, 22.62],
              珠海: [113.52, 22.3],
              宿迁: [118.3, 33.96],
              咸阳: [108.72, 34.36],
              铜川: [109.11, 35.09],
              平度: [119.97, 36.77],
              佛山: [113.11, 23.05],
              海口: [110.35, 20.02],
              江门: [113.06, 22.61],
              章丘: [117.53, 36.72],
              肇庆: [112.44, 23.05],
              大连: [121.62, 38.92],
              临汾: [111.5, 36.08],
              吴江: [120.63, 31.16],
              石嘴山: [106.39, 39.04],
              沈阳: [123.38, 41.8],
              苏州: [120.62, 31.32],
              茂名: [110.88, 21.68],
              嘉兴: [120.76, 30.77],
              长春: [125.35, 43.88],
              胶州: [120.03336, 36.264622],
              银川: [106.27, 38.47],
              张家港: [120.555821, 31.875428],
              三门峡: [111.19, 34.76],
              锦州: [121.15, 41.13],
              南昌: [115.89, 28.68],
              柳州: [109.4, 24.33],
              三亚: [109.511909, 18.252847],
              自贡: [104.778442, 29.33903],
              吉林: [126.57, 43.87],
              阳江: [111.95, 21.85],
              泸州: [105.39, 28.91],
              西宁: [101.74, 36.56],
              宜宾: [104.56, 29.77],
              呼和浩特: [111.65, 40.82],
              成都: [104.06, 30.67],
              大同: [113.3, 40.12],
              镇江: [119.44, 32.2],
              桂林: [110.28, 25.29],
              张家界: [110.479191, 29.117096],
              宜兴: [119.82, 31.36],
              北海: [109.12, 21.49],
              西安: [108.95, 34.27],
              金坛: [119.56, 31.74],
              东营: [118.49, 37.46],
              牡丹江: [129.58, 44.6],
              遵义: [106.9, 27.7],
              绍兴: [120.58, 30.01],
              扬州: [119.42, 32.39],
              常州: [119.95, 31.79],
              潍坊: [119.1, 36.62],
              重庆: [106.54, 29.59],
              台州: [121.420757, 28.656386],
              南京: [118.78, 32.04],
              滨州: [118.03, 37.36],
              贵阳: [106.71, 26.57],
              无锡: [120.29, 31.59],
              本溪: [123.73, 41.3],
              克拉玛依: [84.77, 45.59],
              渭南: [109.5, 34.52],
              马鞍山: [118.48, 31.56],
              宝鸡: [107.15, 34.38],
              焦作: [113.21, 35.24],
              句容: [119.16, 31.95],
              北京: [116.46, 39.92],
              徐州: [117.2, 34.26],
              衡水: [115.72, 37.72],
              包头: [110, 40.58],
              绵阳: [104.73, 31.48],
              乌鲁木齐: [87.68, 43.77],
              枣庄: [117.57, 34.86],
              杭州: [120.19, 30.26],
              淄博: [118.05, 36.78],
              鞍山: [122.85, 41.12],
              溧阳: [119.48, 31.43],
              库尔勒: [86.06, 41.68],
              安阳: [114.35, 36.1],
              开封: [114.35, 34.79],
              济南: [117, 36.65],
              德阳: [104.37, 31.13],
              温州: [120.65, 28.01],
              九江: [115.97, 29.71],
              邯郸: [114.47, 36.6],
              临安: [119.72, 30.23],
              兰州: [103.73, 36.03],
              沧州: [116.83, 38.33],
              临沂: [118.35, 35.05],
              南充: [106.110698, 30.837793],
              天津: [117.2, 39.13],
              富阳: [119.95, 30.07],
              泰安: [117.13, 36.18],
              诸暨: [120.23, 29.71],
              郑州: [113.65, 34.76],
              哈尔滨: [126.63, 45.75],
              聊城: [115.97, 36.45],
              芜湖: [118.38, 31.33],
              唐山: [118.02, 39.63],
              平顶山: [113.29, 33.75],
              邢台: [114.48, 37.05],
              德州: [116.29, 37.45],
              济宁: [116.59, 35.38],
              荆州: [112.239741, 30.335165],
              宜昌: [111.3, 30.7],
              义乌: [120.06, 29.32],
              丽水: [119.92, 28.45],
              洛阳: [112.44, 34.7],
              秦皇岛: [119.57, 39.95],
              株洲: [113.16, 27.83],
              石家庄: [114.48, 38.03],
              莱芜: [117.67, 36.19],
              常德: [111.69, 29.05],
              保定: [115.48, 38.85],
              湘潭: [112.91, 27.87],
              金华: [119.64, 29.12],
              岳阳: [113.09, 29.37],
              长沙: [113, 28.21],
              衢州: [118.88, 28.97],
              廊坊: [116.7, 39.53],
              菏泽: [115.480656, 35.23375],
              合肥: [117.27, 31.86],
              武汉: [114.31, 30.52],
              大庆: [125.03, 46.58],
            }
            let convertData = function(data) {
              let res = []
              for (let i = 0; i < data.length; i++) {
                let geoCoord = geoCoordMap[data[i].name]
                if (geoCoord) {
                  res.push({
                    name: data[i].name,
                    value: geoCoord.concat(data[i].value),
                  })
                }
              }
              return res
            }
            let seriesdata = []
            for (let m = 0; m < mmdata.length; m++) {
              seriesdata[m] = {
                name: mmdata[m].city,
                mapType: 'china',
                type: 'scatter',
                // symbolSize: 5,
                /* symbolSize: function (val) {
                   return val[2] * 10
                   }, */
                coordinateSystem: 'geo',
                label: {
                  normal: {
                    color: '#fff',
                    show: false,
                  },
                },
                itemStyle: {
                  normal: { label: { show: true } },
                  emphasis: { label: { show: true } },
                },
                data: convertData([
                  { name: mmdata[m].city, value: Object.values(mmdata[m].keywords)[0] },
                ]),
              }
            }
            let myPlaceChart = _this.$echarts.init(document.getElementById('placeChart'))
            myPlaceChart.setOption({
              tooltip: {
                formatter: function(params) {
                  return params.name + '(词频):' + params.value[2]
                },
                trigger: 'item',
              },
              legend: {
                left: 0,
                bottom: 20,
                top: 20,
                data: legenddata,
              },
              geo: [
                {
                  show: true,
                  map: 'china',
                  roam: true,
                },
              ],
              visualMap: {
                min: 0,
                max: 200,
                color: ['#d94e5d', '#eac736', '#50a3ba'],
                symbolSize: [10, 20],
                splitNumber: 5,
              },
              series: seriesdata,
            })
          }
        })
        .catch(function(error) {
          alert(error)
        })
    },
    // 词 点击事件
    getClick: function(paramsList) {
      let dataP = paramsList.data
      if (dataP != null && dataP != undefined) {
        let cid = dataP.category
        let pid = dataP.id
        let params = {}
        params.word = paramsList.data.label
        this.axios
          .post(currentBaseUrl + '/hotAnlys/getRelatedWords.do', qs.stringify(params))
          .then((res) => {
            if (res.data.length > 0) {
              if (dataP.ignore == true) {
                console.log('重复')
                return
              }
              // 得到links最后一个target
              let tcount = myChartCi.getOption().series[0].links.pop().target
              let ncount = myChartCi.getOption().series[0].nodes.pop().id
              // let ssize = paramsList.data.symbolSize
              let catCount = myChartCi.getOption().series[0].nodes.pop().id

              let nums
              if (res.data.length >= 15) {
                nums = 15
              } else {
                nums = res.data.length
              }
              // 重组数组
              let word = []
              if (cid === 0) {
                for (let i = 0; i < nums; i++) {
                  word[i] = {
                    id: i + 1,
                    category: cid + 1,
                    label: res.data[i].name,
                    name: i + 1,
                    symbolSize: res.data[i].score * 90,
                    ignore: false,
                    flag: true,
                  }
                }
              } else {
                let wAdd
                wAdd = ncount + 1
                for (let i = 0; i < nums; i++) {
                  word[i] = {
                    id: wAdd,
                    category: cid + 1,
                    label: res.data[i].name,
                    name: wAdd,
                    symbolSize: res.data[i].score * 90,
                    ignore: false,
                    flag: true,
                  }
                  wAdd = wAdd + 1
                }
              }
              // 设置点击过得词语不能再次查询
              let worddata = myChartCi.getOption().series[0].nodes.concat(word)
              worddata[pid].ignore = true
              // links
              let links = []
              // let sid = 0
              if (cid === 0) {
                // sid = 0
                for (let i = 0; i < nums; i++) {
                  links[i] = {
                    source: pid,
                    target: i + 1,
                  }
                }
              } else {
                // sid = sid + 1
                let lAdd
                lAdd = tcount + 1
                for (let i = 0; i < nums; i++) {
                  links[i] = {
                    source: pid,
                    target: lAdd,
                  }
                  lAdd = lAdd + 1
                }
              }
              let linksdata = myChartCi.getOption().series[0].links.concat(links)
              // categories
              let categories = []
              if (cid === 0) {
                for (let i = 0; i < nums; i++) {
                  categories[i] = {
                    id: i + 1,
                    name: i + 1 + '层',
                  }
                }
              } else {
                let cAdd
                cAdd = catCount + 1
                for (let i = 0; i < nums; i++) {
                  categories[i] = {
                    id: cAdd,
                    name: cAdd + '层',
                  }
                  cAdd = cAdd + 1
                }
              }
              let cdata = myChartCi.getOption().series[0].categories.concat(categories)
              myChartCi.setOption({
                series: [
                  {
                    links: linksdata,
                    nodes: worddata,
                    categories: cdata,
                  },
                ],
              })
            } else {
              console.log(null)
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    // 增加水词
    removeKeyWord() {
      let _this = this
      if (this.selectKeyWord == '') {
        this.$message({
          type: 'error',
          message: '请选择水词',
        })
      } else {
        _this.addWalterWordModalVisible = true
        _this.getWordClass(2)
        _this.addWalterTitle = '添加水词 [' + this.selectKeyWord + ']'
      }
      this.currentNode = ''
      this.wordDescribe = ''
      this.roleType = _this.roleType
    },
    handleWalterAddKeyWordThrottle() {
      this.lodashThrottle.throttle(this.handleWalterAddKeyWord, this)
    },
    radioChangeBussType(val) {
      this.getQuShiCharts()
    },
    radioChange(val) {
      this.roleType = val
      this.getQuShiCharts()
    },
    handleWalterAddKeyWord() {
      if (this.currentNode == '') {
        this.$message({
          type: 'error',
          message: '添加水词失败,分类不能为空',
        })
      } else {
        let _this = this
        let params = {
          wordlibType: 2,
          wordName: _this.selectKeyWord,
          keywordClass: 3,
          wordType: 1,
          wordDescribe: _this.wordDescribe,
          classId: _this.currentNode.classId,
          roleType: _this.roleType,
        }
        let url = currentBaseUrl + '/vocabulary/addManyKeyword.do?accessToken=' + CASTGC
        _this.axios.post(url, qs.stringify(params)).then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '添加水词成功',
            })
          } else {
            _this.$message({
              type: 'error',
              message: '水词已存在',
            })
          }
          _this.addWalterWordModalVisible = false
        })
      }
    },
    // 增加关键词
    addKeyWord() {
      if (this.selectKeyWord == '') {
        this.$message({
          type: 'error',
          message: '请选择关键词',
        })
      } else {
        let _this = this
        _this.addWordModalVisible = true
        _this.getWordClass(1)
        _this.addTitle = '添加关键词 [' + this.selectKeyWord + ']'
      }
      this.currentNode = ''
      this.wordDescribe = ''
      this.roleType = ''
    },
    // 添加关键词
    handleAddKeyWordThrottle() {
      this.lodashThrottle.throttle(this.handleAddKeyWord, this)
    },
    handleAddKeyWord() {
      if (this.currentNode == '') {
        this.$message({
          type: 'error',
          message: '添加关键词失败,分类不能为空',
        })
      } else {
        let _this = this
        let params = {
          wordlibType: 1,
          wordName: _this.selectKeyWord,
          keywordClass: 3,
          wordType: 1,
          wordDescribe: _this.wordDescribe,
          classId: _this.currentNode.classId,
        }
        let url = currentBaseUrl + '/vocabulary/addManyKeyword.do?accessToken=' + CASTGC
        _this.axios.post(url, qs.stringify(params)).then(function(response) {
          if (response.data) {
            _this.$message({
              type: 'success',
              message: '添加关键词成功',
            })
          } else {
            _this.$message({
              type: 'error',
              message: '关键词已存在',
            })
          }
          _this.addWordModalVisible = false
        })
      }
    },
    // 取消添加关键词
    cancelAdd() {
      this.addWordModalVisible = false
    },
    cancelWalterAdd() {
      this.addWalterWordModalVisible = false
    },
    // 获取关键词、水词分类
    getWordClass(val) {
      let _this = this
      let url = currentBaseUrl + '/vocabulary/getTrees.do?accessToken=' + CASTGC
      let params = {
        classId: 0,
        classType: val,
      }
      _this.axios.post(url, qs.stringify(params)).then(function(response) {
        _this.treeData = response['data']
      })
    },
    // 查询
    searchHot() {
      let _this = this
      let myChartCi = _this.$echarts.init(document.getElementById('ciChart'))
      myChartCi.dispose()
      let myPlaceChart = _this.$echarts.init(document.getElementById('placeChart'))
      myPlaceChart.dispose()
      _this.quShiTu(1)
      _this.keyword = ''
      let params = {}
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        _this.callSTime_Min = this.Week
        _this.callSTime_Max = this.Today
      } else {
        _this.callSTime_Min = this.gettimeform(this.formRight.times[0])
        _this.callSTime_Max = this.gettimeform(this.formRight.times[1])
      }
      params.beginDate = _this.callSTime_Min
      params.endDate = _this.callSTime_Max
      params.wordRole = this.searchModel.wordRole || '-1'
      params.buss_wordType = this.searchModel.buss_wordType
      params.keyWord = this.keyword
      params.subjectClassIds = this.formRight.region // 分类id，多个时以逗号分隔
      params.subjectId = _this.getThenaticAnalysisId
      let url = currentBaseUrl + '/hotAnlys/getAllkey.do?accessToken=' + CASTGC
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.loading = false
          }
          _this.tableCiData = response.data.keyword
          _this.keyword = ''
        })
        .catch(function(error) {
          alert(error)
          _this.tableCiData = []
          _this.$message({
            type: 'error',
            message: '获取热点数据值失败',
          })
        })
      let myQushiChart = _this.$echarts.init(document.getElementById('trendChart'))
      let urlQs = currentBaseUrl + '/hotAnlys/getTrendData.do'
      this.axios.post(urlQs, qs.stringify(params)).then(function(response) {
        if (response.data.dateList.length > 0 && response.data.trendData.length > 0) {
          $('#trendChart').show()
          myQushiChart.resize()
          let dateList = response.data.dateList
          let trendData = response.data.trendData
          let dateData = []
          let trend = []
          let nums
          if (trendData.length <= 5) {
            nums = trendData.length
          } else {
            nums = 5
          }
          for (let i = 0; i < dateList.length; i++) {
            dateData[i] = dateList[i][0]
          }
          // series
          for (let j = 0; j < nums; j++) {
            trend[j] = {
              name: trendData[j].keyword,
              type: 'line',
              data: trendData[j].timesList,
            }
          }
          // legend data
          let legendData = []
          for (let p = 0; p < nums; p++) {
            legendData[p] = trendData[p].keyword
          }
          // xAxis
          let xAxisData = []
          for (let a = 0; a < dateList.length; a++) {
            xAxisData[a] = dateList[a]
          }
          let option = {
            title: {
              text: '',
              textStyle: {
                color: '#5e6d82',
                fontSize: 14,
                fontWieght: 'normal',
              },
            },
            tooltip: {
              trigger: 'axis',
            },
            legend: {
              data: [],
            },

            grid: {
              left: '3%',
              right: '4%',
              bottom: '3%',
              containLabel: true,
            },
            xAxis: [
              {
                type: 'category',
                boundaryGap: false,
                data: [],
                splitLine: {
                  show: true,
                },
                axisLine: {
                  show: false,
                },
              },
            ],
            yAxis: [
              {
                type: 'value',
                splitLine: {
                  show: true,
                },
                axisLine: {
                  show: false,
                },
              },
            ],
            color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
            series: [],
          }
          option.legend.data = legendData
          option.xAxis[0].data = xAxisData
          option.series = trend
          myQushiChart.setOption(option, true)
          myQushiChart.on('contextmenu', function(params) {
            _this.timetype = '2'
            _this.exportData = {
              subjectId: _this.getThenaticAnalysisId,
              keyWords: params.seriesName,
              roleType: _this.searchModel.wordRole || '-1',
              star: params.name,
              end: params.name + ' ' + '23:59:59',
            }
            _this.showMoremodel(_this.exportData)
          })
        } else {
          myQushiChart && myQushiChart.dispose()
          $('#trendChart').hide()
        }
      })
    },
    drawPic(data) {
      // let qushi = JSON.parse(data.keyWord || '[]')
      let qushi = data
      let _this = this
      let map = {}
      for (let j = 0; j < 5; j++) {
        let keyWord = qushi[j].keyWord
        let date = qushi[j].date
        let times = qushi[j].times
        if (map.hasOwnProperty(keyWord)) {
          map[keyWord][0].push(date)
          map[keyWord][1].push(times)
        } else {
          map[keyWord] = []
          map[keyWord][0] = []
          map[keyWord][1] = []
          map[keyWord][0].push(date)
          map[keyWord][1].push(times)
        }
      }
      let arr = []
      // let qushiList = response.data.qushi
      for (let i = 0; i < 5; i++) {
        arr[i] = formatDate.formatDate(qushi[i].date).substring(0, 10)
      }
      let legend = []
      let series = []
      // let xaxis = ''
      for (let x in map) {
        let d = {}
        d['name'] = x
        d['type'] = 'line'
        // d['stack'] = '总量';
        d['data'] = map[x][1]
        legend.push(x)
        series.push(d)
        // xaxis = map[x][0]
      }
      _this.option1.series = series
      _this.option1.legend.data = legend
      _this.option1.xAxis[0].data = arr
      // _this.option1.xAxis[0].data = xaxis
      let myChart = _this.$echarts.init(document.getElementById('trendImage'))
      myChart.destroy()
      myChart.setOption(_this.option1)
      /* let keywordData = data.keyword || []
         let datas = []
         for (let i = 0; i < keywordData.length; i++) {
         datas.push({
         name: keywordData[i].keyWord,
         value: keywordData[i].times * 10,
         itemStyle: _this.createRandomItemStyle()
         // 变换风格
         })
         }
         _this.option2.series[0].data = datas */
      /* let myChart2 = this.$echarts.init(document.getElementById('wordImage'));
         myChart2.clear(); */
      // myChart2.setOption(_this.option2);
    },
    createRandomItemStyle() {
      return {
        normal: {
          textStyle: {
            fontSize: 12,
          },
        },
      }
    },
    handleAllClick(selection) {
      let keyWord = ''
      for (let val of selection) {
        if (val == selection[0]) {
          keyWord = val.keyWord
        } else {
          keyWord = keyWord + ',' + val.keyWord
        }
      }
      this.selectKeyWord = keyWord
      this.keyword = keyWord
      myChartCi && myChartCi.dispose()
      let _this = this
      // 趋势图
      _this.getQuShiTu()
      // 地图
      let times = ''
      _this.getMap(keyWord, times)
      // 词相关
      _this.getci(keyWord)
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let str = year + '-' + month + '-' + day
      return str
    },
    // 获取坐席组数据
    listSeat(dimention, subDimentionObj) {
      let _this = this
      let params = {
        dpcpId: '',
        showAccount: '0',
      }
      let url = currentBaseUrl + '/pageConstant/listSeat.do'
      _this.axios
        .get(url, { params })
        .then(function(response) {
          _this[dimention + 'Vals'] = response.data
          _this[subDimentionObj.label] = 'name'
          _this[subDimentionObj.value] = 'id'
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '坐席组数据获取失败',
          })
        })
    },
    // 获取区域数据
    listprovince(dimention, subDimentionObj) {
      let _this = this
      let url = currentBaseUrl + '/mobiletoarea/listprovince.do'
      _this.axios
        .get(url)
        .then(function(response) {
          _this[dimention + 'Vals'] = response.data
          _this[subDimentionObj.label] = 'province'
          _this[subDimentionObj.value] = 'province'
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '区域数据获取失败',
          })
        })
    },
    // 初始化时候的趋势图/词相关、区域图
    getQuShiCharts() {
      let _this = this
      if (
        this.formRight.times == undefined ||
        this.formRight.times == '' ||
        this.formRight.times.length <= 0
      ) {
        _this.callSTime_Min = _this.Week
        _this.callSTime_Max = _this.Today
      } else {
        _this.callSTime_Min = this.gettimeform(this.formRight.times[0])
        _this.callSTime_Max = this.gettimeform(this.formRight.times[1])
      }
      let params = {}
      params.beginDate = _this.callSTime_Min
      params.endDate = _this.callSTime_Max
      params.wordRole = _this.searchModel.wordRole || '-1'
      params.buss_wordType = _this.searchModel.buss_wordType
      params.keyWord = _this.keyword
      params.subjectClassIds = _this.formRight.region // 分类id，多个时以逗号分隔
      params.subjectId = _this.getThenaticAnalysisId
      let urlQs = currentBaseUrl + '/hotAnlys/getTrendData.do'
      _this.axios.post(urlQs, qs.stringify(params)).then(function(response) {
        if (response.data.dateList.length > 0 && response.data.trendData.length > 0) {
          let dateList = response.data.dateList
          let trendData = response.data.trendData
          let dateData = []
          let trend = []
          let nums
          if (trendData.length <= 5) {
            nums = trendData.length
          } else {
            nums = 5
          }
          for (let i = 0; i < dateList.length; i++) {
            dateData[i] = dateList[i][0]
          }
          // series
          for (let j = 0; j < nums; j++) {
            trend[j] = {
              name: trendData[j].keyword,
              type: 'line',
              data: trendData[j].timesList,
            }
          }
          // legend data
          let legendData = []
          for (let p = 0; p < nums; p++) {
            legendData[p] = trendData[p].keyword
          }
          // xAxis
          let xAxisData = []
          for (let a = 0; a < dateList.length; a++) {
            xAxisData[a] = dateList[a]
          }
          _this.qushiEchartsOption.legend.data = legendData
          _this.qushiEchartsOption.xAxis[0].data = xAxisData
          _this.qushiEchartsOption.series = trend
          let myQushiChart = _this.$echarts.init(document.getElementById('trendChart'))
          myQushiChart.setOption(_this.qushiEchartsOption, true)
          myQushiChart.on('contextmenu', function(params) {
            _this.timetype = '2'
            _this.exportData = {
              subjectId: _this.getThenaticAnalysisId,
              keyWords: params.seriesName,
              roleType: _this.searchModel.wordRole || '-1',
              star: params.name,
              end: params.name + ' ' + '23:59:59',
            }
            _this.showMoremodel(_this.exportData)
          })
          _this.getci(trendData[0].keyword)
          let times = dateList[0]
          _this.getMap(trendData[0].keyword, times)
          let paramsd = {}
          paramsd.beginDate = times
          paramsd.endDate = _this.callSTime_Max
          paramsd.wordRole = _this.searchModel.wordRole || '-1'
          paramsd.buss_wordType = _this.searchModel.buss_wordType
          paramsd.keyWord = _this.keyword
          paramsd.subjectId = _this.getThenaticAnalysisId
          paramsd.subjectClassIds = _this.formRight.region // 分类id，多个时以逗号分隔
          let urld = currentBaseUrl + '/hotAnlys/getAllkey.do?accessToken=' + CASTGC
          _this.axios
            .post(urld, qs.stringify(paramsd))
            .then(function(response) {
              if (response.data) {
                _this.loading = false
              }
              // _this.formRight.times = [times, _this.callSTime_Max]
              _this.tableCiData = response.data.keyword
              _this.keyword = ''
            })
            .catch(function(error) {
              alert(error)
              _this.tableCiData = []
              _this.$message({
                type: 'error',
                message: '获取热点数据值失败',
              })
            })
        } else {
          console.log('没有数据')
        }
      })
    },
    closeRecord() {
      this.limit = 10
      this.currentPagerecord = 1
      this.handleCurrentChange(1)
    },
  },
  directives: {
    'click-outside': {
      bind: function(el, binding, vNode) {
        // Provided expression must evaluate to a function.
        if (typeof binding.value !== 'function') {
          const compName = vNode.context.name
          let warn = `[Vue-click-outside:] provided expression '${
            binding.expression
          }' is not a function, but has to be`
          if (compName) {
            warn += `Found in component '${compName}'`
          }

          console.warn(warn)
        }
        // Define Handler and cache it on the element
        const bubble = binding.modifiers.bubble
        const handler = (e) => {
          if (bubble || (!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },
      unbind: function(el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      },
    },
  },
  mounted() {
    this.getAWeekTime()
    this.getQuShiCharts()
    this.getTreeMenu()
    this.getOverviewlist()
    this.getTrendOfAnalysisList()
    this.getTimeAnalusisList()
  },
}
</script>

<style lang="less" scoped="scoped">
.thematicAnalysisSub {
  width: 100%;
  height: 100%;
  position: relative;
  .fl {
    float: left;
  }
  .fr {
    float: right;
  }
  .m-tb-10 {
    margin: 10px 0;
  }
  .wraper {
    padding: 0 10px;
    .header {
      width: 100%;
      height: 50px;
      line-height: 50px;
      border-bottom: 1px dashed #ccc;
    }
    .content {
      margin-top: 10px;
      width: 100%;
      position: relative;
      .m-r-10 {
        margin-right: 10px;
      }
      .select-width {
        width: 200px;
        &.hide {
          display: none;
        }
      }
      .contentLeft {
        width: 200px;
        top: 38px;
        right: 0;
        position: absolute;
        z-index: 3000;
        .treeMenu {
          position: absolute;
          left: 0;
          right: 0;
          top: 0;
          bottom: 0;
          .el-tree {
            max-height: 200px;
            min-height: 80px;
            overflow-y: auto;
          }
          .btns {
            width: 99%;
            height: 36px;
            border: 1px solid #ccc;
            border-top: 0;
            background: #fff;
            .el-button {
              float: right;
              width: 52px;
              height: 30px;
              margin-top: 2px;
              font-size: 12px;
              margin-right: 10px;
            }
          }
        }
      }
      .commen {
        width: 100%;
        height: 150px;
        clear: both;
        .commen-block {
          display: inline-block;
          width: 32%;
          height: 100%;
          border: 1px solid #ccc;
          float: left;
          .aw-50 {
            width: 50%;
            height: 100%;
          }
          .aw-45 {
            width: 45%;
            height: 100%;
            padding-top: 45px;
            box-sizing: border-box;
            .p1 {
              margin-left: 25%;
              font-size: 14px;
              color: #000;
              font-weight: bold;
            }
            .p2 {
              margin-left: 25%;
              font-size: 28px;
              color: #50b4ff;
              font-weight: bold;
            }
          }
        }
      }
      .occupationRatio {
        width: 100%;
        height: 300px;
        margin-top: 10px;
        .block {
          height: 100%;
          border: 1px solid #ccc;
          font-size: 14px;
          .header {
            padding: 0 10px;
            box-sizing: border-box;
            width: 100%;
            height: 30px;
            line-height: 30px;
            border-bottom: 1px dashed #ccc;
          }
          .occupationRatio-block {
            box-sizing: border-box;
            width: 100%;
            height: 260px;
          }
          &.ratio-block {
            width: 32%;
            margin-right: 10px;
            .el-button.btn {
              width: 35px;
              height: 26px;
              padding: 0;
            }
          }
          &.trend-block {
            width: 65%;
            overflow: auto;
          }
        }
      }
    }
    // 时段分析
    .timeanalyse {
      width: 100%;
      height: 370px;
      border: 1px solid #ccc;
      margin: 10px 0;
      .title {
        width: 100%;
        height: 30px;
        line-height: 30px;
        border-bottom: 1px dashed #ccc;
      }
      .timeanalyse-content {
        width: 100%;
        height: 90%;
      }
    }
  }
  .el-button.out-btn {
    position: absolute;
    top: 10px;
    right: 60px;
  }
}
</style>
<style lang="less">
#hotanalyse .el-tabs__header {
  border-bottom: 1px solid #d1dbe5;
  padding: 0;
  position: inherit;
  margin: 0px;
}

#hotanalyse .el-tabs__content {
  box-sizing: border-box;
  position: relative;
  width: 100%;
  height: 100%;
}

#hotanalyse {
  div.el-radio-group {
    float: left;
    margin: 5px 0px;
    width: 100%;
  }
}

#hotanalyse {
  width: 100%;
  height: 500px;
  position: relative;
}

#hotanalyse .title {
  width: 100%;
  height: 30px;
  line-height: 30px;
  border-bottom: 1px dashed #ccc;
}

#hotanalyse .hotanalyse-header {
  position: absolute;
  width: 100%;
  height: 100px;
  padding: 0 10px;
  box-sizing: border-box;
  margin-bottom: 10px;
}

#hotanalyse .hotanalyse-content {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding-top: 60px;
  padding-bottom: 25px;
  border: 1px solid #ccc;
  margin-top: 10px;
}

#hotanalyse .hotanalyse-content .hotanalyse-content-pos {
  height: 100%;
  width: 100%;
  border: 1px solid #dfe6ec;
  border-radius: 8px;
}

#hotanalyse .hotanalyse-content-pos .hotanalyse-content-left {
  width: 30%;
  height: 100%;
  border-right: 1px solid #dfe6ec;
  padding: 0 10px;
  box-sizing: border-box;
}

#hotanalyse .hotanalyse-content-left .hotanalyseLeft-header {
  width: 100%;
}

#hotanalyse .hotanalyse-content-left .hotanalyseLeft-content {
  width: 100%;
  height: 100%;
  padding-top: 55px;
  padding-bottom: 5px;
  box-sizing: border-box;
}

#hotanalyse .hotanalyseLeft-content .hotanalyseLeft-content-pos {
  width: 100%;
  height: 100%;
}

#hotanalyse .hotanalyse-content-pos .hotanalyse-content-right {
  width: 69%;
  height: 100%;
}

#hotanalyse .hotanalyse-content-right .box {
  height: 100%;
  position: relative;
  box-sizing: border-box;
  width: 100%;
}

#hotanalyse .hotTop {
  border-radius: 4px;
  border: 1px solid #dfe6ec;
  line-height: 40px;
  float: left;
  box-sizing: border-box;
  top: 0px;
  width: 212px;
  margin: 10px 0px 0px 10px;
  height: 40px;
}

#hotanalyse .hotTop .activeQu {
  background: #409eff;
  border-radius: 4px;
  color: #fff;
}

#hotanalyse .hotTop ul li {
  cursor: pointer;
  text-align: center;
  width: 70px;
  float: left;
}

#hotanalyse .hotanalyse-content-right .box .hotanalyseRight {
  /*box-sizing: border-box;
    width: 100%;
    height: 100%;
    position: relative;*/
  padding-top: 50px;
  padding-bottom: 1px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}

#hotanalyse .hotBox {
  width: 100%;
  height: 100%;
  overflow: auto;
  cursor: pointer;
}

#hotanalyse
  .hotanalyse-content-pos
  .hotanalyse-content-right
  .hotanalyse-content-chart-head {
  /*margin-top: 10px;
    margin-left: 10px;*/
  position: absolute;
  top: 10px;
  left: 10px;
}

#hotanalyse
  .hotanalyse-content-pos
  .hotanalyse-content-right
  .hotanalyse-content-chart-head
  .active {
  background: #409eff;
  color: #fff;
  /*border-radius: 4px 0px 0px 4px;*/
}

#hotanalyse .hotanalyse-content-chart-head ul {
  border-radius: 4px;
  border: 1px solid #d8dce5;
  height: 36px;
  line-height: 36px;
  width: 240px;
  cursor: pointer;
}

#hotanalyse .hotanalyse-content-chart-head ul li {
  text-align: center;
  width: 80px;
  float: left;
  display: inline-block;
  font-size: 14px;
  color: #1f334f;
}

#hotanalyse .hotanalyse-content-chart-head ul li:hover {
  background: #409eff;
  color: #fff;
}

.is-current > .el-tree-node__content {
  background: #eef1f6;
}

#hotanalyse .hotanalyseRight span,
#hotanalyse .hotanalyseRightbottom span {
  display: inline-block;
  width: 100%;
  height: 55px;
  line-height: 55px;
  padding-left: 18px;
  box-sizing: border-box;
  font-size: 14px;
}
</style>
