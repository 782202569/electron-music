<template>
  <div class="intelligent" id="intelligentv">
    <div class="taskSetting">
      <div class="intelligent-header">
        <div class="operation">
          <div class="searchForm">
            <el-form :inline="true">
              <el-form-item>
                <el-input v-model="projectName" placeholder="请输入配置名称"></el-input>
              </el-form-item>
              <el-form-item>
                <el-select
                  v-model="taskType"
                  clearble
                  placeholder="请选择任务状态"
                  class="fr"
                >
                  <el-option
                    v-for="item in taskStatusS"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>

              <el-form-item>
                <el-date-picker
                  class="fr"
                  v-model="searchTime"
                  type="datetimerange"
                  placeholder="选择时间范围"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="taskInquery">查询</el-button>
              </el-form-item>
              <el-form-item>
                <el-button @click="newTask">新建</el-button>
              </el-form-item>
              <el-form-item>
                <el-button @click="batchDeleteConfirm">批量删除</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <div class="intelligent-content">
        <div class="intelligent-content-pos" style="overflow-y:auto;">
          <div style="width:100%;height:100%;">
            <el-table
              border
              ref="multipleTable"
              tootip-effect="dark"
              @selection-change="handleSelectionChange"
              :data="tableData"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column sortable prop="projectName" label="配置名称">
              </el-table-column>
              <el-table-column sortable prop="createUser" label="创建者">
              </el-table-column>
              <el-table-column
                prop="taskStartTime"
                sortable
                :formatter="exeTimeFilter"
                label="执行时间"
              >
              </el-table-column>
              <el-table-column sortable prop="taskStatus" label="任务状态">
                <template scope="scope">
                  <el-tag close-transition type="gray" v-if="scope.row.taskStatus == null"
                    >未开始</el-tag
                  >
                  <el-tag
                    close-transition
                    type="primary"
                    v-if="scope.row.taskStatus == 'running'"
                    >运行中</el-tag
                  >
                  <el-tag
                    close-transition
                    type="success"
                    v-if="scope.row.taskStatus == 'hanguping'"
                    >暂停</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column
                prop="operate"
                label="操作"
                width="380"
                show-overflow-tooltip
              >
                <template scope="scope">
                  <i
                    class="iconfont icon-222"
                    style="cursor:pointer;margin-right:8px;"
                    @click="diableLoopTask(scope.row.configId)"
                    v-if="scope.row.taskStatus == 'running'"
                    ><i style="font-family:'微软雅黑';margin-left:4px;">暂停</i></i
                  >
                  <i
                    class="el-icon-caret-right"
                    style="cursor:pointer;margin-right:20px"
                    @click="tapeStart(scope.row.configId)"
                    v-if="
                      scope.row.taskStatus == 'hanguping' || scope.row.taskStatus == null
                    "
                    ><i style="font-family:'微软雅黑';margin-left:4px;">开始</i></i
                  >

                  <i
                    class="el-icon-document"
                    style="cursor:pointer;margin-right:20px;"
                    @click="copyProjectDialog(scope.row.configId)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;">复制</i></i
                  >
                  <i
                    class="el-icon-close"
                    style="cursor:pointer;margin-right:20px;font-size:12px;"
                    @click="
                      deleteProjectConfirm(scope.row.projectName, scope.row.configId)
                    "
                    ><i style="font-family: '微软雅黑';margin-left:5px;font-size:14px;"
                      >删除</i
                    ></i
                  >
                  <i
                    class="iconfont icon-chakan"
                    style="cursor:pointer;margin-right:20px;"
                    @click="showDetail(scope.row.configId)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;">查看</i></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="intelligent-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
    </div>

    <el-dialog
      id="newTaskdialog"
      :close-on-click-modal="false"
      :title="dialogTitle"
      :visible.sync="dialogVisible"
    >
      <el-form ref="oneForm" label-width="100px" :model="taskModel" :rules="oneRules">
        <h3>任务属性</h3>
        <el-row>
          <el-col :span="6">
            <el-form-item label="配置名称" prop="projectNameCreate">
              <el-input v-model="taskModel.projectNameCreate"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="抽样类型" prop="sampleType">
              <el-select
                v-model="taskModel.sampleType"
                clearable
                @change="changeTemplate"
              >
                <el-option
                  v-for="item in sampleTypeS"
                  :value="item.type"
                  :label="item.name"
                  :key="item.id"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="完成天数" prop="day">
              <el-select v-model="taskModel.day" clearable>
                <el-option
                  v-for="item in days"
                  :value="item.id"
                  :label="item.name"
                  :key="item.id"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="7" v-show="isShow">
            <el-form-item label="模板选择" prop="selectModel">
              <el-select v-model="taskModel.selectModel" clearable>
                <el-option
                  :value="item.modleId"
                  :label="item.modleTitle"
                  v-for="item in modleS"
                  :key="item.modleId"
                ></el-option>
              </el-select>
              <i class="el-icon-setting setting" @click="gotoSetting"></i>
            </el-form-item>
          </el-col>
          <el-col :span="2" v-show="!isShow">
            <el-form-item label="初检成绩" prop="scoreMin">
              <el-input v-model="taskModel.scoreMin" style="width:80px"></el-input>
            </el-form-item>
          </el-col>
          <span v-show="!isShow">-</span>
          <el-col :span="1" v-show="!isShow">
            <el-form-item prop="scoreMax">
              <el-input v-model="taskModel.scoreMax" style="width:80px"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6" v-show="!isShow">
            <el-form-item label="致命项" prop="deadItem">
              <el-select v-model="taskModel.deadItem" clearable>
                <el-option
                  :value="item.id"
                  :label="item.name"
                  v-for="item in deadItemS"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <my-comp ref="myComp" :fromFModel="fromFModel"></my-comp>

      <el-form ref="threeForm" label-width="100px" :model="task2Form" :rules="threeRules">
        <h3>周期(天)</h3>
        <el-row>
          <el-col :span="6">
            <el-form-item label="运行周期" prop="cycType">
              <el-input v-model="task2Form.cycType"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="6">
            <el-form-item label="采集周期" prop="time">
              <el-input v-model="task2Form.time"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <h3>质检员</h3>
        <el-form-item label="质检员" prop="checkQaUserList">
          <el-checkbox-group v-model="task2Form.checkQaUserList">
            <el-checkbox
              v-for="qaUser in qaUsers"
              :label="qaUser.account"
              :value="qaUser.realName"
            ></el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-row>
          <el-col :span="6">
            <el-form-item label="抽样方式" prop="sampleMode">
              <el-select placeholder="随机抽样" clearable v-model="task2Form.sampleMode">
                <el-option label="随机抽样" value="1">随机抽样</el-option>
                <el-option label="平均抽样" value="0">平均抽样</el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="抽样数量" prop="techno">
              <el-input type="number" v-model="task2Form.techno"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="btns">
        <el-button type="primary" @click="taskCreateThrottle">{{
          dialogButtonText
        }}</el-button>
        <el-button @click="resetForm">清空</el-button>
        <el-button @click="taskGoback">返回</el-button>
      </div>
    </el-dialog>

    <el-dialog
      title="开始任务"
      :close-on-click-modal="false"
      :visible.sync="startDialogVisible"
      width="mini"
    >
      <div>
        <el-form>
          <el-form-item label="请设置任务执行时间">
            <el-date-picker
              v-model="taskStartTime"
              type="datetime"
              placeholder="选择日期时间"
              align="right"
            >
            </el-date-picker>
          </el-form-item>
        </el-form>
        <div class="btns">
          <el-button type="primary">确定</el-button>
          <el-button @click="">取消</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script type="text/ecmascript-6">
import $ from 'jquery'
import Qs from 'qs' // 导入qs
import moment from 'moment'
import global from '../../../global.js'
import nativeaxios from 'axios'
import cache from '../../../utils/cache.js'
import mycompVue from './formEngine/mycomp.vue'
let qualityUrl = global.qualityUrl
export default {
  components: {

    myComp: mycompVue
    // myComp: function(resolve, reject) {
    //   // 从表单引擎获取界面元素
    //   nativeaxios
    //     .post(
    //       global.formEngineUrl +
    //         '/creating.do?formIds=intellSampleOrder,intellSampleYGOrder&accessToken=' +
    //         cache.getItem('tgt_id')
    //     )
    //     .then(function(response) {
    //       $('body').append(response.data.Validate)
    //       let myHtml = response.data.Html
    //       resolve({
    //         template: myHtml,
    //         data() {
    //           return {
    //             /* eslint-disable */
    //             intellSampleOrder_intellSampleYGOrder_Model: intellSampleOrder_intellSampleYGOrder_,
    //             intellSampleOrder_intellSampleYGOrder_Rules: intellSampleOrder_intellSampleYGOrder_Rules,
    //             /* eslint-enable */
    //           }
    //         },
    //         props: ['fromFModel'], // 父组件的
    //         watch: {
    //           // 监控父亲数据的变化 如果有个变化则更新表单的内容
    //           fromFModel: function() {
    //             // alert(this.fromFModel)
    //             this.intellSampleOrder_intellSampleYGOrder_Model = this.fromFModel
    //             // 删除表单的验证
    //           },
    //         },
    //       })
    //     })
    // },
  },
  mounted: function() {
    let _this = this
    this.taskInquery() // 查询
    // 初始化模板和质检员
    this.axios
      .post(
        qualityUrl + '/manualOrderQualityAssurance/getModleInfoByCondition.do',
        Qs.stringify({
          modleType: 7,
          pageindex: 1,
          pagesize: 20,
        })
      )
      .then(function(response) {
        let models = response.data.Data
        _this.modleS = models
      })
    // 获取当前登录的主管下的质检员
    this.axios.post(qualityUrl + '/distributeTask.do').then(function(response) {
      _this.qaUsers = response.data.Data
    })
  },
  data: function() {
    return {
      task2Form: {
        cycType: '',
        time: '',
        techno: '', // 日均抽样量
        checkQaUserList: [],
        sampleMode: '1',
      },
      taskModel: {
        projectNameCreate: '',
        day: '',
        taskType: '',
        sampleType: '',
        isShow: '',
        selectModel: '',
        deadItem: '',
        scoreMin: '',
        scoreMax: '',
      },
      deadItemS: [{ id: '1', name: '是' }, { id: '2', name: '否' }],
      sampleTypeS: [
        { id: '1', name: '初检', type: '1' },
        { id: '2', name: '复检', type: '2' },
      ],
      isShow: '',
      thisConfigId: '',
      taskStartTime: '',
      days: [
        { id: '1', name: '一天' },
        { id: '2', name: '二天' },
        { id: '3', name: '三天' },
        { id: '4', name: '四天' },
        { id: '5', name: '五天' },
        { id: '6', name: '六天' },
        { id: '7', name: '七天' },
      ],
      qaUsers: [],
      modleS: [{ a: 1, b: 2 }],
      fromFModel: {},
      //  selectModel:'',
      dialogVisible: false, // 新建dialog
      startDialogVisible: false,
      configs: [],
      tableData: [],
      currentPage: 1,
      total: 0,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      projectName: '',
      taskType: '',
      searchTime: [],
      taskStatusS: [
        {
          label: '请选择',
          value: '',
        },
        {
          label: '运行中',
          value: 'running',
        },
        {
          label: '暂停',
          value: 'hunguping',
        },
      ],
      dialogTitle: '新建任务',
      dialogButtonText: '新建',
      oneRules: {
        projectNameCreate: [
          {
            required: true,
            message: '请输入配置名称',
            trigger: 'blur',
          },
        ],
        selectModel: [
          {
            required: true,
            message: '请选择模板 ',
            trigger: 'blur',
          },
        ],
        day: [
          {
            required: true,
            message: '请选择完成天数！',
            trigger: 'blur',
          },
        ],
        sampleType: [
          {
            required: true,
            message: '请选择抽样类型！',
            trigger: 'blur',
          },
        ],
        scoreMin: [{}],
        scoreMax: [{}],
      },
      threeRules: {
        techno: [{ required: true, message: '请输入日均抽样量', trigger: 'blur' }],
        cycType: [{ required: true, message: '请输入运行周期', trigger: 'blur' }],
        time: [{ required: true, message: '请输入采集周期', trigger: 'blur' }],
        checkQaUserList: [
          { type: 'array', required: true, message: '请选择质检员', trigger: 'change' },
        ],
      },
    }
  },
  methods: {
    changeTemplate(val) {
      if (val == '1') {
        this.isShow = true
        this.oneRules.selectModel = [
          {
            required: true,
            message: '请选择模板 ',
            trigger: 'blur',
          },
        ]
        this.oneRules.scoreMin = [{}]
        this.oneRules.scoreMax = [{}]
      } else {
        this.isShow = false
        this.oneRules.scoreMin = [{}]
        this.oneRules.scoreMax = [{}]
        this.oneRules.selectModel = [{}]
      }
    },
    gotoSetting() {
      this.$router.push('/manalScoreModel_new')
    },
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let hours = date.getHours()
      if (hours < 10) {
        hours = '0' + hours
      }
      let minute = date.getMinutes()
      if (minute < 10) {
        minute = '0' + minute
      }
      let second = date.getSeconds()
      if (second < 10) {
        second = '0' + second
      }
      let str = year + '-' + month + '-' + day + ' ' + hours + ':' + minute + ':' + second
      return str
    },
    batchDeleteConfirm() {
      // 批量删除
      //
      let _this = this

      if (_this.configs.length < 1) {
        _this.$message({
          type: 'warning',
          message: '请选择要删除的任务',
        })
        return false
      }
      let names = []
      let ids = []
      _this.configs.forEach(function(item) {
        names.push(item.projectName)
        ids.push(item.configId)
      })
      let message = ''
      if (names.length <= 3) {
        message = names.join(',')
      } else {
        message = names.splice(0, 3).join(',') + '等' + names.length + '个配置！！'
      }
      _this
        .$confirm('确定要删除[' + message + ']?', '提示', {
          cancelButtonText: '取消',
          confirmButtonText: '确定',
          type: 'warning',
        })
        .then(function() {
          _this.batchDelete(ids.join(','))
        })
        .catch(function() {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    batchDelete(ids) {
      let _this = this

      this.axios
        .post(qualityUrl + '/ascOrder/toDeal.do', Qs.stringify({ configId: ids }))
        .then(function(response) {
          if (response.data.Data) {
            _this.$message({
              type: 'info',
              message: '删除成功',
            })
            _this.taskInquery()
          }
        })
    },
    taskInquery() {
      // 查询智能抽样的项目
      let taskBeginTime = ''
      let taskEndTime = ''
      if (!this.searchTime || this.searchTime[0] == null) {
        // taskBeginTime = '';
        // taskEndTime = '';
      } else {
        taskBeginTime = this.gettimeform(this.searchTime[0])
        taskEndTime = this.gettimeform(this.searchTime[1])
      }
      let params = {
        taskBeginTime: taskBeginTime,
        taskEndTime: taskEndTime,
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        projectName: '%' + this.projectName + '%',
        taskStatus: this.taskType,
      }
      // 发送请求
      let self = this
      this.axios
        .post(qualityUrl + '/ascOrder/getAllSysSampleConfig.do', Qs.stringify(params))
        .then(function(response) {
          self.total = response.data.Count
          self.tableData = response.data.Data
        })
    },
    newTask() {
      // 新建任务弹出框
      let _this = this
      this.dialogTitle = '新建任务'
      this.dialogButtonText = '新建'
      this.dialogVisible = true
      this.$nextTick(() => {
        this.resetForm()
        // this.$refs.oneForm.resetFields()
        // this.$refs.threeForm.resetFields()
      })

      _this.isShow = true

    },
    copyProjectDialog(configId) {
      // 方案  异步组件引用父组件prop 子组件监视这个数据的变化

      let _this = this
      this.dialogTitle = '复制任务'
      this.dialogButtonText = '复制'
      this.dialogVisible = true

      // 异步组件  引用未能及时创建成功
      //  this.resetForm()
      this.axios
        .post(qualityUrl + '/ascOrder/getConfigStrate.do?configId=' + configId)
        .then((response) => {
          let strate = response.data.strt // 策略
          let config = response.data.config
          // 回显
          // 固定表单
          let task2Form = {}
          let users = config.teamId
          if (users) {
            task2Form.checkQaUserList = users.split(',')
          }
          // 质检人员数组 teamId
          task2Form.cycType = config.cycType + ''
          task2Form.time = config.time + ''
          task2Form.techno = config.techno + ''
          task2Form.sampleMode = config.sampleMode
          _this.task2Form = task2Form

          let taskModel = {}
          taskModel.day = config.afterwordsRes + ''
          taskModel.selectModel = config.qaModel + '' // 模板
          taskModel.projectNameCreate = config.projectName
          taskModel.scoreMin = config.scoreMin
          taskModel.scoreMax = config.scoreMax
          taskModel.sampleType = config.sampleType
          taskModel.deadItem = config.deadItem
          _this.taskModel = taskModel

          // 表单引擎的表单
          if (strate) {
            let stratObj = JSON.parse(strate.strategyObject)
            _this.fromFModel = stratObj
          }
        })
    },
    copyProject(configId) {
      let _this = this
      this.axios
        .post(qualityUrl + '/ascOrder/toCop.do?configId=' + configId)
        .then(function(response) {
          if (response.data.Data) {
            _this.taskInquery()
            _this.$message({
              type: 'info',
              message: '复制成功',
            })
          }
        })
    },
    /**
     * 暂停任务
     * @param configId
     */
    diableLoopTask(configId) {
      // alert(configId);
      let _this = this

      _this.updateStatus(configId, 'hanguping')
    },
    tapeStartDialog(configId) {
      this.startDialogVisible = true
      this.thisConfigId = configId
    },

    /**
     * 开始任务
     * @param configId
     */
    tapeStart(configId) {
      let _this = this
      _this.updateStatus(configId, 'running', null)
      // this.startDialogVisible = false;
    },
    updateStatus(configId, status, taskTime) {
      let _this = this
      this.axios
        .post(
          qualityUrl + '/ascOrder/updateStatus.do',
          Qs.stringify({
            configId: configId,
            status: status,
            taskTime: taskTime,
          })
        )
        .then(function(response) {
          if (response.data) {
            _this.taskInquery()
          }
        })
    },
    /**
     * 复制任务
     * @param row
     * @param type
     */
    editProject(row, type) {
      let _this = this
      this.axios
        .post(
          '',
          Qs.stringify({
            projectId: row.projectId,
          })
        )
        .then(function(response) {
          _this.projectModel = response.data
          _this.editeDialogVisible = true
          _this.projectModel.type = type
          if (type == 'edit') {
            _this.modalName = '编辑任务'
          } else if (type == 'copy') {
            _this.modalName = '复制任务'
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取任务详情失败',
          })
        })
    },
    /**
     * 删除任务确认框
     */
    deleteProjectConfirm(projectName, configId) {
      let _this = this
      _this
        .$confirm('确定要删除任务[' + projectName + ']', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
        })
        .then(() => {
          _this.deleteByConfigId(configId)
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 删除任务
    deleteByConfigId(configId) {
      let _this = this
      let param = {}
      param.configId = configId
      this.axios
        .post(qualityUrl + '/ascOrder/toDeal.do', Qs.stringify(param))
        .then(function(response) {
          if (response.data.Data) {
            _this.taskInquery()
            _this.$message({
              type: 'success',
              message: '任务删除成功',
            })
          }
        }) // 回调函数
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '任务删除失败',
          })
        })
    },
    showDetail(configId) {
      let obj = { configId: configId }
      console.log(this.$router)
      this.$store.commit('setAssignViewOrder', obj)
      this.$router.push({ path: '/assignViewOrder' }) // 获取路由并导到目标页面
    },
    /**
     * 每页条数改变的话
     */
    handleSizeChange(val) {
      this.pageSize = val
      this.taskInquery()
    },

    /**
     * 翻页
     */
    handleCurrentChange(val) {
      this.currentPage = val
      this.taskInquery()
    },

    /**
     * 选中的记录发生变化后
     * @param val
     */
    handleSelectionChange(val) {
      this.configs = val
    },
    taskCreateThrottle() {
      this.lodashThrottle.throttle(this.taskCreate, this)
    },
    taskCreate() {
      let _this = this
      let myEnForm = this.$refs.myComp // 获取表单引擎组件引用
      let clusterClient = myEnForm.intellSampleOrder_intellSampleYGOrder_Model
      let params = {
        templeateId: this.taskModel.selectModel, // 模板id
        people: this.task2Form.checkQaUserList.join(','),
        day: this.taskModel.day,
        cycType: this.task2Form.cycType,
        time: this.task2Form.time,
        techno: this.task2Form.techno,
        sampleMode: this.task2Form.sampleMode,
        projectName: this.taskModel.projectNameCreate,
        deadItem: this.taskModel.deadItem,
        scoreMin: this.taskModel.scoreMin,
        scoreMax: this.taskModel.scoreMax,
        sampleType: this.taskModel.sampleType,
      }
      this.getParams(params, clusterClient)
      if (clusterClient['callSTime'] && clusterClient['callSTime'].length > 0) {
        if (clusterClient['callSTime'][0]) {
          clusterClient['callSTime_Min'] = moment(clusterClient['callSTime'][0]).format(
            'YYYY-MM-DD HH:mm:ss'
          )
        }

        if (clusterClient['callSTime'][1]) {
          clusterClient['callSTime_Max'] = moment(clusterClient['callSTime'][1]).format(
            'YYYY-MM-DD HH:mm:ss'
          )
        }
      }
      clusterClient['callSTime'] = null
      params.strategyObject = JSON.stringify(clusterClient)
      this.$refs.oneForm.validate(function(validate) {
        if (!validate) {
          throw new Error('填写必填项')
        }
      })
      this.$refs.threeForm.validate(function(validate) {
        if (!validate) {
          throw new Error('填写必填项')
        }
      })

      this.axios
        .post(qualityUrl + '/ascOrder/addSysSampleConfig.do', Qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.taskInquery()
            _this.dialogVisible = false
            _this.$message({
              type: 'success',
              message: '任务新建成功',
            })
          } else {
            _this.$message({
              type: 'error',
              message: '已存在相同名称的任务，请重新输入',
            })
          }
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '任务新建失败',
          })
        })
    },
    searchAttr(formId) {
      for (let item in formId) {
        if (typeof formId[item] == 'string') {
          formId[item] = ''
        } else if (formId[item] instanceof Array) {
          formId[item] = []
        } else if (typeof formId[item] == 'object') {
          for (let jtm in formId[item]) {
            formId[item][jtm] = ''
          }
        }
      }
    },
    getParams(param, formId) {
      for (let item in formId) {
        if (item.indexOf('$CName') > -1) {
          continue
        }
        if (typeof formId[item] == 'string') {
          param[item] = formId[item]
        } else if (formId[item] instanceof Array) {
          if (formId[item].length == 2) {
            param[item + '_Min'] = formId[item][0]
            param[item + '_Max'] = formId[item][1]
          } else {
            param[item + '_Min'] = ''
            param[item + '_Max'] = ''
          }
        } else if (typeof formId[item] == 'object') {
          for (let jtm in formId[item]) {
            param[jtm] = formId[item][jtm]
          }
        }
      }
      return param
    },
    resetForm() {
      let _this = this
      let myEnForm = this.$refs.myComp // 获取表单引擎组件引用
      let clusterClient = myEnForm.intellSampleOrder_intellSampleYGOrder_Model
      _this.searchAttr(clusterClient) // 清空数据
      this.$refs.oneForm.resetFields()
      this.$refs.threeForm.resetFields()
    },
    taskGoback() {
      this.dialogVisible = false
    },
  },
}
</script>
<style lang="less">
.intelligent {
  .operation {
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
  .el-input {
    width: 180px;
  }
}
</style>
<style scoped="scoped" lang="less">
@boder-color: #d1dbe5;
.intelligent {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .operation {
    height: 55px;
    line-height: 55px;
    position: relative;
    border-bottom: 1px dashed @boder-color;
    padding-right: 10px;
    .el-form-item {
      margin-bottom: 0px;
      .el-form-item__content {
        line-height: 55px;
      }
    }
    & > div {
      display: inline-block;
      text-align: right;
      button {
        width: 90px;
      }
      &.searchForm {
        position: absolute;
        right: -10px;
        div.el-form-item__content {
          vertical-align: middle !important;
          border: 1px solid red;
        }
      }
    }
  }
  .taskResult {
    .operation {
      .tips {
        & > label {
          color: #9dadc2;
          font-size: 14px;
        }
        & > span {
          margin: 0px 10px 0px 5px;
        }
      }
      .btns {
        float: right;
        margin-right: -10px;
      }
    }
  }
  .intelligent-content {
    box-sizing: border-box;
    position: absolute;
    top: 65px;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 0px 10px;
    padding-bottom: 40px;
    overflow: hidden;
  }
  .intelligent-content .intelligent-content-pos {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .intelligent-content .intelligent-page {
    width: 100%;
    height: 35px;
    position: absolute;
    left: 0;
    right: 0px;
    bottom: 0;
    text-align: right;
  }
  .intelligent-page .el-pagination {
    display: inline-block;
    height: 28px;
    line-height: 28px;
    padding: 0px 10px;
  }
  #newTaskdialog .el-dialog__body {
  }
  #intelligent .intelligent-content-pos .el-table__body-wrapper {
    overflow-x: hidden;
  }
  .btns {
    text-align: right;
    margin-top: 10px;
  }
  table .cell > i {
    width: 35px;
    & > i {
      font-family: '微软雅黑';
      margin-left: 4px;
      font-size: 14px;
    }
  }
}

.setting {
  font-size: 16px;
  color: #8691a5;
  margin: 8px 0px 10px 10px;
  cursor: pointer;
}
</style>
