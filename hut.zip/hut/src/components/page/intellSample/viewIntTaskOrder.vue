<template>
  <div class="intelligent" id="">
    <div class="taskSetting">
      <div class="intelligent-header">
        <div class="operation">
          <div class="searchForm">
            <el-form :inline="true">
              <el-form-item>
                <el-button type="primary" @click="viewTaskChart">查看图表</el-button>
              </el-form-item>
              <el-form-item>
                <el-button @click="backToMain">返回</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <div class="intelligent-content">
        <div class="intelligent-content-pos" style="overflow-y:auto;">
          <div style="width:100%;height:100%;">
            <el-table border ref="resultTable" tootip-effect="dark" :data="tableData">
              <el-table-column type="index" width="55"> </el-table-column>
              <el-table-column prop="projectName" label="配置名称"> </el-table-column>
              <el-table-column
                prop="doneTime"
                label="完成时间"
                :formatter="exeTimeFilter"
              >
              </el-table-column>
              <el-table-column prop="extractCount" label="抽样数"> </el-table-column>
              <el-table-column prop="periodCount" label="周期录音总数"> </el-table-column>
              <el-table-column prop="extRate" :formatter="toFixed" label="抽出率">
              </el-table-column>
              <el-table-column
                prop="operate"
                label="操作"
                width="380"
                show-overflow-tooltip
              >
                <template scope="scope">
                  <i
                    class="iconfont icon-chakan"
                    style="cursor:pointer;margin-right:8px;"
                    @click="viewAssign(scope.row.logId)"
                    ><i style="font-family:'微软雅黑';margin-left:4px;">查看分配</i></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="intelligent-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog
      title="查看分配情况"
      :close-on-click-modal="false"
      :visible.sync="dialogVisible"
    >
      <div>
        <el-table border tootip-effect="dark" :data="assignTableData">
          <el-table-column prop="qaUser" label="质检员姓名"> </el-table-column>
          <el-table-column prop="qaMounthCount" label="当月分配"> </el-table-column>
          <el-table-column prop="qaCount" label="当前分配"> </el-table-column>
          <el-table-column prop="assignTime" :formatter="exeTimeFilter" label="分配时间">
          </el-table-column>
        </el-table>
        <div class="intelligent-page fr" style="margin-top: 20px;margin-bottom: 10px">
          <el-pagination
            @size-change="handleSizeChangeAssign"
            @current-change="handleCurrentChangeAssign"
            :current-page="currentPageAssign"
            :page-sizes="pageSizesAssign"
            :page-size="pageSizeAssign"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalAssign"
          >
          </el-pagination>
        </div>
      </div>
    </el-dialog>
    <!--表格弹出层 -->

    <el-dialog
      title="查看图表"
      :close-on-click-modal="false"
      :visible.sync="dialogChartVisible"
    >
      <div style="margin-bottom:20px">
        <el-form style="width: 100%; overflow: hidden" label-width="100px">
          <el-form-item label="时间" style="float: right" prop="value1">
            <el-date-picker
              @change="changeTime2"
              v-model="formChartDate"
              type="daterange"
              placeholder="选择日期范围"
            >
            </el-date-picker>
            <el-button @click="search">查询</el-button>
          </el-form-item>
        </el-form>
        <div id="echartImgBox" style="width: 100%; height:400px;">
          <div id="echartImg" style="width: 100%; height:400px;"></div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import Qs from 'qs' // 导入qs
import global from '../../../global.js'
let qualityUrl = global.qualityUrl

export default {
  data() {
    return {
      formChartDate: '',
      assignTableData: [],
      tableData: [],
      total: 1,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      currentPage: 1,
      currentPageAssign: 1,
      totalAssign: 1,
      pageSizesAssign: [10, 20, 30, 40],
      pageSizeAssign: 20,
      dialogVisible: false,
      dialogChartVisible: false,
      option2Rate: {
        title: {
          text: '总数统计',
        },
        tooltip: {},
        legend: {
          data: ['录音'],
        },
        xAxis: [
          {
            data: [],
          },
        ],
        yAxis: {},
        series: [
          {
            name: '录音',
            type: 'line',
            data: [],
            itemStyle: {
              normal: {
                color: '#50b4ff',
              },
            },
          },
        ],
      },
    }
  },
  methods: {
    canel() {},
    toFixed(x, y, cellVal) {
      let val = parseFloat(cellVal)
      return (val * 100).toFixed(2) + '%'
    },
    search: function() {
      $('#echartImg').show()
      const self = this
      let configId = this.$store.state.assigView.configId
      let params = {
        configId: configId,
        fromDate: this.fromDate,
        toDate: this.toDate,
      }
      if (!params['fromDate'] || !params['toDate']) {
        this.$message.error('请选择时间范围!')
        return
      }
      this.axios
        .post(qualityUrl + '/ascOrder/viewChart.do', Qs.stringify(params))
        .then((res) => {
          if (res.data) {
            console.log(res.data.stsMap)
            // 对象转换为数组
            let arr = []
            for (let i in res.data.stsMap) {
              let str = i + ':' + res.data.done
              arr.push(str.substring(8, 10))
            }

            let done = res.data.stsMap
            let testArr = JSON.stringify(done).split(',')
            let result = []
            for (let i = 0; i < testArr.length; i++) {
              result.push(testArr[i].replace('}', '').split(':')[1])
            }
            // console.log(testArr,result);
            this.option2Rate.series[0].data = result

            let options = null
            this.option2Rate.xAxis[0].data = arr
            options = self.option2Rate

            let myChart = self.$echarts.init(document.getElementById('echartImg'))
            myChart.setOption(options)
          } else {
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    statisticsSave: function() {
      this.dialogChartVisible = false
      $('#echartImg').hide()
    },
    changeTime2: function(val) {
      let fdata = val.substring(0, 10)
      let edata = val.substring(13, 23)
      // console.log(fdata2,edata2);
      /* if(edata2!=fdata2){
         this.$message({
         type: 'warning',
         message: '时间范围不可超过一个月'
         });
         } */
      this.fromDate = fdata
      this.toDate = edata
    },
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return this.gettimeform(cellValue)
      }
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let hours = date.getHours()
      if (hours < 10) {
        hours = '0' + hours
      }
      let minute = date.getMinutes()
      if (minute < 10) {
        minute = '0' + minute
      }
      let second = date.getSeconds()
      if (second < 10) {
        second = '0' + second
      }
      let str = year + '-' + month + '-' + day + ' ' + hours + ':' + minute + ':' + second
      return str
    },
    viewTaskChart(configId) {
      this.dialogChartVisible = true
    },
    viewAssign(logId) {
      let configId = this.$store.state.assigView.configId
      console.log(configId)
      let _this = this

      // 访问后台获取数据
      this.axios
        .post(
          qualityUrl +
            '/ascOrder/getAllTaskDeatil.do?configId=' +
            configId +
            '&logId=' +
            logId
        )
        .then(function(response) {
          _this.assignTableData = response.data.Data
        })
      this.dialogVisible = true
    },
    backToMain(configId) {
      this.$router.push({ path: '/zhinengchouyang_order' })
    },
    handleSizeChange() {},
    handleCurrentChange() {},
    handleSizeChangeAssign() {},
    handleCurrentChangeAssign() {},
  },
  mounted: function() {
    // 挂载后执行
    let _this = this
    let storage = window.localStorage // 解决网页刷新存储数据丢失
    let configId = this.$store.state.assigView.configId
    if (window.localStorage) {
      if (configId != '' && configId != null) {
        storage.setItem('configId', configId)
      }
    }
    if (configId == '' || configId == null) {
      configId = storage.getItem('configId')
    }
    let params = {
      configId: configId,
      currentPage: 1,
      pageSize: 10,
    }
    this.axios
      .post(qualityUrl + '/asc/getIvsSampleLogByVo.do', Qs.stringify(params))
      .then(function(response) {
        _this.tableData = response.data.Data
        _this.total = response.data.Count
      })
      .catch()
  },
}
</script>
<style lang="less">
.intelligent {
  .operation {
    .el-form-item {
      div.el-form-item__content {
        vertical-align: middle;
      }
    }
  }
}
</style>
<style scoped="scoped" lang="less">
@boder-color: #d1dbe5;
.intelligent {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .operation {
    height: 55px;
    line-height: 55px;
    position: relative;
    border-bottom: 1px dashed @boder-color;
    padding-right: 10px;
    .el-form-item {
      margin-bottom: 0px;
      .el-form-item__content {
        line-height: 55px;
      }
    }
    & > div {
      display: inline-block;
      text-align: right;
      button {
        width: 90px;
      }
      &.searchForm {
        position: absolute;
        right: -10px;
        div.el-form-item__content {
          vertical-align: middle !important;
          border: 1px solid red;
        }
      }
    }
  }
  .taskResult {
    .operation {
      .tips {
        & > label {
          color: #9dadc2;
          font-size: 14px;
        }
        & > span {
          margin: 0px 10px 0px 5px;
        }
      }
      .btns {
        float: right;
        margin-right: -10px;
      }
    }
  }
  .intelligent-content {
    box-sizing: border-box;
    position: absolute;
    top: 65px;
    left: 0;
    right: 0;
    bottom: 0;
    padding: 0px 10px;
    padding-bottom: 40px;
    overflow: hidden;
  }
  .intelligent-content .intelligent-content-pos {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .intelligent-content .intelligent-page {
    width: 100%;
    height: 35px;
    position: absolute;
    left: 0;
    right: 0px;
    bottom: 0;
    text-align: right;
  }
  .intelligent-page .el-pagination {
    display: inline-block;
    height: 28px;
    line-height: 28px;
    padding: 0px 10px;
  }
  #newTaskdialog .el-dialog__body {
  }
  #intelligent .intelligent-content-pos .el-table__body-wrapper {
    overflow-x: hidden;
  }
  .btns {
    text-align: right;
    margin-top: 10px;
  }
  table .cell > i {
    width: 35px;
    & > i {
      font-family: '微软雅黑';
      margin-left: 4px;
      font-size: 14px;
    }
  }
}
</style>
