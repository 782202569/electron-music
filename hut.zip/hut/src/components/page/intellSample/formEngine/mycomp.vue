<template>
  <el-form
    ref="intellSampleOrder_intellSampleYGOrder_Ref"
    :inline="true"
    :rules="intellSampleOrder_intellSampleYGOrder_Rules"
    :model="intellSampleOrder_intellSampleYGOrder_Model"
    label-width="84px"
  >
    <h3>订单属性</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item prop="orderNo" style="color:#8691a5" label="订单编号"
          ><el-input
            v-model="intellSampleOrder_intellSampleYGOrder_Model.orderNo"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="orderState" style="color:#8691a5" label="订单状态"
          ><el-select
            style="width:160px"
            v-model="intellSampleOrder_intellSampleYGOrder_Model.orderState"
            placeholder="请选择"
            id="orderState"
          ></el-select></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="orderTime" style="color:#8691a5" label="订单时间"
          ><el-date-picker
            style="width:160px"
            v-model="intellSampleOrder_intellSampleYGOrder_Model.orderTime"
            type="datetimerange"
            placeholder="选择时间范围"
            v-bind:default-time="['00:00:00', '23:59:59']"
          ></el-date-picker></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>坐席属性</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item prop="submiter" style="color:#8691a5" label="提交人"
          ><el-input
            v-model="intellSampleOrder_intellSampleYGOrder_Model.submiter"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="submiterName" style="color:#8691a5" label="提交人姓名"
          ><el-date-picker
            style="width:160px"
            v-model="intellSampleOrder_intellSampleYGOrder_Model.submiterName"
            type="datetimerange"
            placeholder="选择时间范围"
            v-bind:default-time="['00:00:00', '23:59:59']"
          ></el-date-picker></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item
          prop="deptId"
          style="color:#8691a5"
          label="坐席组"
        ></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row
  ></el-form>
</template>

<script>
var validateFunc = function() {}
export default {
  props: ['fromFModel'], // 父组件的
  data() {
    return {
      /* eslint-disable */
      intellSampleOrder_intellSampleYGOrder_Model: {
        orderNo: '',
        orderNo$CName: '订单编号',
        orderState: '',
        orderState$CName: '订单状态',
        orderTime: [],
        orderTime$CName: '订单时间',
        submiter: '',
        submiter$CName: '提交人',
        submiterName: [],
        submiterName$CName: '提交人姓名',
        deptId: '',
        deptId$CName: '坐席组',
      },
      intellSampleOrder_intellSampleYGOrder_Rules: {},
      /* eslint-enable */
    }
  },
  watch: {
    // 监控父亲数据的变化 如果有个变化则更新表单的内容
    fromFModel: function() {
      // alert(this.fromFModel)
      this.intellSampleOrder_intellSampleYGOrder_Model = this.fromFModel
      // 删除表单的验证
    },
  },
}
</script>

<style></style>
