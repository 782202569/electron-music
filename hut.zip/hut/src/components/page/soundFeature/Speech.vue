<template>
  <div id="speech">
    <div class="speech-header" style="position: absolute;">
      <el-form ref="form" :model="formSpeech" style="margin-top: 10px;">
        <el-form-item label="平均语速" class="fl" style="width:53%;">
          <el-input
            placeholder="最小值"
            style="width:80px;"
            v-model="formSpeech.avgSpeedMin"
          ></el-input>
          ---
          <el-input
            placeholder="最大值"
            style="width:80px;"
            v-model="formSpeech.avgSpeedMax"
          ></el-input>
          <el-radio-group
            @change="setSpeed"
            v-model="formSpeech.radio2"
            id="speedRadio"
            style="margin-left:20px;"
          >
            <el-radio :label="1"
              >速度过快(&gt;=<span>{{ maxSpeed }}</span
              >)</el-radio
            >
            <el-radio :label="2"
              >速度过慢(&lt;=<span>{{ minSpeed }}</span
              >)</el-radio
            >
          </el-radio-group>
        </el-form-item>
        <el-form-item label="开始时间" class="fl w23">
          <el-date-picker
            v-model="formSpeech.callSTimeMin"
            type="date"
            placeholder="选择日期"
            :picker-options="pickerOptions0"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item label="结束时间" class="fl w23">
          <el-date-picker
            v-model="formSpeech.callSTimeMax"
            type="date"
            placeholder="选择日期"
            :picker-options="pickerOptions0"
          >
          </el-date-picker>
        </el-form-item>
      </el-form>
    </div>
    <div
      class="speech-content-pos"
      style="padding-top:60px;box-sizing: border-box;height:100%;"
    >
      <div
        class="speech-content"
        style="width:100%;height:100%;position: relative;"
        v-show="isanalyticspeech"
      >
        <div class="speech-content-header" style="position: absolute;width:100%;">
          <el-button type="primary" class="fr" @click="showSpeechcanvas"
            >分析统计</el-button
          >
          <el-button class="fr" @click="speechExport">导出</el-button>
          <el-button class="fr" @click="clearSpeech">清空</el-button>
          <el-button type="primary" class="fr" @click="overlayInquirySpeech"
            >查询</el-button
          >
          <i
            class="el-icon-d-caret fr"
            @click="sortQuery"
            style="cursor:pointer;margin-top:25px"
            >按平均语速排序</i
          >
        </div>
        <div
          class="speech-content-con"
          style="width:100%;height:100%;padding-top:59px;padding-bottom:40px;box-sizing: border-box;"
        >
          <div
            class="speech-content-table"
            style="width:100%;height:100%;overflow-y:auto;"
          >
            <el-table
              id="tableSpeech"
              key="1"
              ref="singleTable"
              :data="tableDataspeech"
              highlight-current-row
              border
              style="width: 100%"
            >
              <el-table-column width="80" type="index" label="排名"></el-table-column>
              <el-table-column property="callId" label="录音编号">
                <template scope="scope">
                  <el-button type="text" @click="showDetail(scope.row.callId, scope.row.recordFileURL)">{{
                    scope.row.callId
                  }}</el-button>
                </template>
              </el-table-column>
              <el-table-column
                property="callSTime"
                :formatter="formatDate"
                label="录音时间"
                sortable
              ></el-table-column>
              <el-table-column property="seatName" label="坐席姓名"></el-table-column>
              <el-table-column property="avgSpeed" label="平均语速"></el-table-column>
              <el-table-column label="查看" width="120">
                <template scope="scope">
                  <i
                    @click="showDetail(scope.row.callId, scope.row.recordFileURL)"
                    class="iconfont icon-chakan"
                    style="cursor:pointer;margin-right:20px"
                    ><i style="font-size: 14px">查看</i></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="speech-content-footer">
            <el-pagination
              class="fr"
              @size-change="handleSizeChangespeech"
              @current-change="handleCurrentChangespeech"
              :current-page="currentPage1speech"
              :page-size="pageSizespeech"
              :page-sizes="[10, 15, 20, 25, 30]"
              layout="total, sizes, prev, pager, next, jumper"
              :total="speachTotal"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <div
        class="speech-content-work"
        style="width:100%;height:100%;position: relative;"
        v-show="!isanalyticspeech"
      >
        <div class="speech-content-header" style="position: absolute;width:100%;">
          <span class="speechSpan speechSpanActive" :data-id="1" @click="toggleSpeech"
            >按部门</span
          >
          <span class="speechSpan" :data-id="2" @click="toggleSpeech">按班组</span>
          <el-button class="fr" @click="goBackList">返回清单</el-button>
          <el-button class="fr" type="primary" @click="speechExport2">导出</el-button>
          <el-button class="fr" @click="showSpeechcanvas">查询</el-button>
          <el-select
            v-model="value4speech"
            clearable
            placeholder="请选择班组"
            class="fr"
            style="margin-top:10px;"
            v-show="currentIndex == '2'"
            @change="speechChange"
          >
            <el-option
              v-for="item in optionspeech"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
          <span
            class="fr"
            style="margin-top:18px;margin-right:10px;"
            v-show="currentIndex == '2'"
            >班组</span
          >
        </div>
        <div
          class="speech-content-con"
          style="width:100%;height:100%;padding-top:59px;padding-bottom:40px;box-sizing: border-box;"
        >
          <div style="width:100%;height:100%;">
            <div id="byDeptspeech"></div>
          </div>
          <el-dialog :title="dialogTitle" :visible.sync="dialogTableVisibleself">
            <el-table
              :data="tableData3speech"
              border
              height="400"
              v-if="dialogTableVisibleself"
            >
              <el-table-column property="callId" label="录音编号"></el-table-column>
              <el-table-column property="avgSpeed" label="平均语速"></el-table-column>
            </el-table>
            <el-pagination
              class="fl"
              style="margin:20px 0;"
              @current-change="handleCurrentChange3speech"
              @size-change="handleDetailSizeChange"
              :current-page="currentPage3speech"
              :page-size="detailPageSize"
              :page-sizes="[10, 20, 30, 40]"
              layout="total, sizes, prev, pager, next, jumper"
              :total="speachTotal3"
            >
            </el-pagination>
            <el-button
              type="primary"
              class="fr"
              style="margin-top:20px;margin-left:10px;"
              @click="deparmentSure"
              >确定
            </el-button>
            <el-button
              class="fr"
              style="margin-top:20px;margin-left:10px;"
              @click="deparmentInquiry"
              >取消</el-button
            >
          </el-dialog>
        </div>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<style lang="less">
#speech {
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
  #speedRadio .el-radio__input {
    width: 16px !important;
    padding: 0px !important;
  }

  .speech-header {
    width: 100%;
    height: 58px;
    line-height: 58px;
    border-bottom: 1px dashed #cfdbe7;
  }

  .speech-header span {
    padding: 0 10px;
  }

  .speech-header .el-input {
    width: 180px;
  }

  .speech-content .speech-content-header {
    height: 59px;
    line-height: 59px;
  }

  .speech-content .speech-content-header .el-button,
  .speech-content-work .speech-content-header .el-button {
    margin-top: 10px;
    margin-left: 20px;
    width: 86px;
  }

  .speech-content-work .speech-content-header span {
    box-sizing: border-box;
    display: inline-block;
  }

  .speechSpan {
    padding: 0 20px;
    height: 46px;
    line-height: 46px;
    font-size: 14px;
    border-bottom: 3px solid #d1dbe4;
    color: #d1dbe4;
  }

  .speechSpanActive {
    border-bottom: 3px solid #202d3d;
    color: #202d3d;
  }

  .speakSpeech-content {
    position: absolute;
    width: 260px;
    height: 150px;
    margin-top: 6px;
    z-index: 999;
    border: 1px solid #cdcdcd;
    background: #fff;
  }

  .speakSpeech-content .speakSpeech-content-body {
    padding-top: 10px;
    box-sizing: border-box;
    height: 120px;
  }

  .speakSpeechInput {
    padding-left: 4px;
    box-sizing: border-box;
    height: 26px;
  }

  .speakSpeech-content .speakSpeech-content-footer {
    border-top: 1px solid #ebebeb;
    padding: 0 10px;
    box-sizing: border-box;
  }

  #tableSpeech .el-table__body-wrapper {
    overflow-x: hidden;
  }

  #speedRadio span.el-radio__inner {
    padding: 0px !important;
  }
}
</style>
<script>
import $ from 'jquery'
import global from '../../../global.js'

// import vEchart from './EchartImg.vue'
import Qs from 'qs'
import dateUtil from '../../../utils/dateUtil.js'
import commonUtil from '../../../utils/commonUtil.js'
import recordingplay from '../recordingPlay/recordingPlayNew.vue'
// import vPlayer from '../../common/player.vue'
import bus from '../../common/bus.js'
let currentBaseUrl = global.currentBaseUrl

export default {
  beforeMount: function() {
    this.recordPlayCloseHandler()
    let self = this
    this.axios
      .post(currentBaseUrl + '/pageConstant/getConfig.do')
      .then(function(response) {
        self.minSpeed = response.data['minSpeed']
        self.maxSpeed = response.data['maxSpeed']
      })
  },
  mounted: function() {
    this.$nextTick(() => {
      this.overlayInquirySpeech()
      this.loadSeatGroup()
    })
  },
  components: {
    // vEchart,
    // Vspeakspeech,
    recordingplay,
    // vPlayer,
  },
  data() {
    return {
      recordDialogVisible: false,
      formSpeech: {
        avgSpeedMin: '',
        avgSpeedMax: '',
        radio2: null,
        callSTimeMax: dateUtil.timeToString(new Date()),
        callSTimeMin: dateUtil.timeToString(dateUtil.getPreDay(new Date(), -7)),
        sortField: 'avgSpeed',
        sortType: false,
      },
      minSpeed: -1,
      maxSpeed: 7,
      dialogTitle: '部门结果',
      pageSizespeech: 20, //
      currentPage1speech: 1,
      detailPageSize: 10,
      input: '', // 语速
      isanalyticspeech: true, //
      tableDataspeech: [], // 录音列表的数据
      tableData1Speech: [], // 按部门
      tableData2Speech: [], // 按班组
      tableData3speech: [], // 弹出框
      option2Speech: {
        tooltip: {},
        legend: {
          data: ['录音数'],
          textStyle: {
            color: '#737f8d',
          },
          x: 'center',
          y: 'bottom',
        },
        xAxis: [
          {
            data: [],
            axisLine: {
              lineStyle: {
                color: '#737f8d',
              },
            },
            name: '班组',
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '时间',
          },
        ],
        dataZoom: {
          start: 80,
          end: 100,
          show: true,
          realtime: false,
          y: 360,
          height: 20,
          filterMode: 'empty',
          handleSize: 20,
        },
        series: [
          {
            name: '录音数',
            type: 'bar',
            data: [],
            barWidth: 10,
            itemStyle: {
              normal: {
                color: '#50b4ff',
                label: {
                  show: true,
                  position: 'top',
                },
              },
            },
          },
        ],
      },
      currentIndex: '1', // 当前页面的是按部门
      dialogTableVisibleself: false,
      currentPage3speech: 1, // 弹出框
      speachTotal3: 0,
      deptyIdcurrent: '', // 当前的
      value4speech: '',
      optionspeech: [],
      speachTotal: 0, // 分页1的总数
      option: {
        calculable: true,
        tooltip: {},
        legend: {
          data: ['录音数'],
          textStyle: {
            color: '#737f8d',
          },
          x: 'center',
          y: 'bottom',
        },
        xAxis: [
          {
            data: [],
            splitLine: {
              show: true,
              //  改变轴线颜色
              lineStyle: {
                // 使用深浅的间隔色
                color: ['#ddd'],
              },
            },
            axisLine: {
              lineStyle: {
                color: '#737f8d',
              },
            },
            name: '坐席',
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '总量',
          },
        ],
        dataZoom: {
          start: 80,
          end: 100,
          show: true,
          realtime: false,
          y: 360,
          height: 20,
          filterMode: 'empty',
          handleSize: 20,
        },
        series: [
          {
            name: '录音数',
            type: 'bar',
            data: [],
            barWidth: 10,
            itemStyle: {
              normal: {
                color: '#50b4ff',
                label: {
                  show: true,
                  position: 'top',
                },
              },
            },
          },
        ],
      },
    }
  },
  methods: {
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'integratedSearchHr'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    speechChange(val) {
      this.value4speech = val
    },
    speechExport() {
      let params = {
        callSTimeMin: this.gettimeform(this.formSpeech.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSpeech.callSTimeMax),
        avgSpeedMin: this.formSpeech.avgSpeedMin,
        avgSpeedMax: this.formSpeech.avgSpeedMax,
        sortField: this.formSpeech.sortField,
        sortType: this.formSpeech.sortType,
      }
      commonUtil.doExport(currentBaseUrl + '/speechFeature/export.do', params)
    },
    speechExport2() {
      let baseUrl = currentBaseUrl
      if (this.currentIndex == '1') {
        baseUrl += '/speechFeature/exporDeptStatsByCode.do'
      } else {
        baseUrl += '/speechFeature/exportSeatStatsByCode.do'
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formSpeech.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSpeech.callSTimeMax),
        avgSpeedMin: this.formSpeech.avgSpeedMin,
        avgSpeedMax: this.formSpeech.avgSpeedMax,
        sortField: this.formSpeech.sortField,
        sortType: this.formSpeech.sortType,
      }
      commonUtil.doExport(baseUrl, params)
    },
    overlayInquirySpeech() {
      // 查询
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      const self = this
      let params = {
        callSTimeMin: this.gettimeform(this.formSpeech.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSpeech.callSTimeMax),
        avgSpeedMin: this.formSpeech.avgSpeedMin,
        avgSpeedMax: this.formSpeech.avgSpeedMax,
        sortField: this.formSpeech.sortField,
        pageNumber: this.currentPage1speech,
        pageSize: this.pageSizespeech,
        sortType: this.formSpeech.sortType,
      }
      this.axios
        .post(
          currentBaseUrl + '/speechFeature/queryRecords.do',
          Qs.stringify(params),
          configss
        )
        .then(function(response) {
          if (response.status == 200 && response.data.state == '1') {
            self.tableDataspeech = response.data.results
            self.speachTotal = response.data.count
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    sortQuery() {
      this.formSpeech.sortType = !this.formSpeech.sortType
      this.overlayInquirySpeech()
    },
    handleSizeChangespeech(val) {
      this.pageSizespeech = val
      this.overlayInquirySpeech()
    },
    handleCurrentChangespeech(val) {
      this.currentPage1speech = val
      this.overlayInquirySpeech()
    },
    clearSpeech() {
      // 清空
      this.formSpeech.radio2 = null
      this.formSpeech.avgSpeedMin = ''
      this.formSpeech.avgSpeedMax = ''
      this.formSpeech.callSTimeMax = ''
      this.formSpeech.callSTimeMin = ''
      this.formSpeech['sortType'] = 'false'
      this.formSpeech['sortField'] = 'avgSpeed'
      this.formSpeech.avgSpeedMin = ''
      this.formSpeech.avgSpeedMax = ''
    },
    handleCurrentChange3speech(val) {
      this.currentPage3speech = val
      this.quirySpeechlist()
    },
    handleDetailSizeChange(val) {
      this.currentPage3speech = 1
      this.detailPageSize = val
      this.quirySpeechlist()
    },
    quirySpeechlist(deptId) {
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let paramss = {
        callSTimeMin: this.gettimeform(this.formSpeech.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSpeech.callSTimeMax),
        avgSpeedMin: this.formSpeech.avgSpeedMin,
        avgSpeedMax: this.formSpeech.avgSpeedMax,
        sortField: 'avgSpeed',
        pageNumber: this.currentPage3speech,
        pageSize: this.detailPageSize,
      }
      if (this.currentIndex == '1') {
        if (deptId) {
          paramss.deptId = deptId
        } else {
          paramss.deptId = this.deptyIdcurrent
        }
      } else if (this.currentIndex == '2') {
        if (deptId) {
          paramss.seatNo = deptId
        } else {
          paramss.seatNo = this.deptyIdcurrent
        }
      }
      const self = this
      this.axios
        .post(
          currentBaseUrl + '/speechFeature/queryRecords.do',
          Qs.stringify(paramss),
          configss
        )
        .then(function(res) {
          if (res.status == 200 && res.data.state == '1') {
            self.tableData3speech = res.data.results
            self.speachTotal3 = res.data.count
            self.dialogTableVisibleself = true
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    showSpeechcanvas() {
      this.isanalyticspeech = false // 这儿是默认按照按部门分析的
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formSpeech.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSpeech.callSTimeMax),
        avgSpeedMin: this.formSpeech.avgSpeedMin,
        avgSpeedMax: this.formSpeech.avgSpeedMax,
      }
      const self = this
      if (self.currentIndex == '2') {
        params.groupId = self.value4speech
      }
      this.axios
        .post(currentBaseUrl + '/speechFeature/statis.do', Qs.stringify(params), configss)
        .then(function(response) {
          if (response.status == 200 && response.data.state == 1) {
            self.tableData1Speech = response.data.other.dept
            self.tableData2Speech = response.data.other.seat
            let options = null
            if (self.currentIndex == '1') {
              // 按部门
              self.option2Speech.series[0].data = []
              self.option2Speech.xAxis[0].data = []
              for (let key in self.tableData1Speech) {
                let str = ''
                str = key.replace('[', '').replace(']', '')
                self.option2Speech.xAxis[0].data.push(str.split(',')[1])
                self.option2Speech.series[0].data.push(self.tableData1Speech[key])
              }
              options = self.option2Speech
            } else if (self.currentIndex == '2') {
              // 按组织option
              self.option.series[0].data = []
              self.option.xAxis[0].data = []
              // 由于这个数据从接口那儿返回过来就是个空对象，所以，我这儿采用假数据
              for (let key in self.tableData2Speech) {
                let str = ''
                str = key.replace('[', '').replace(']', '')
                self.option.xAxis[0].data.push(str.split(',')[1])
                self.option.series[0].data.push(self.tableData2Speech[key])
              }
              options = self.option
            }
            if (window.innerHeight > 900) {
              document.getElementById('byDeptspeech').style.width = 1420 + 'px'
              document.getElementById('byDeptspeech').style.height = 400 + 'px'
            } else if (window.innerHeight > 768) {
              document.getElementById('byDeptspeech').style.width = 1220 + 'px'
              document.getElementById('byDeptspeech').style.height = 400 + 'px'
            } else {
              document.getElementById('byDeptspeech').style.width = 1100 + 'px'
              document.getElementById('byDeptspeech').style.height = 400 + 'px'
            }
            let mychart = self.$echarts.init(document.getElementById('byDeptspeech'))
            mychart.clear()
            mychart.setOption(options)
            window.onresize = function() {
              if (window.innerHeight > 900) {
                document.getElementById('byDeptspeech').style.width = 1600 + 'px'
                document.getElementById('byDeptspeech').style.height = 400 + 'px'
              } else if (window.innerHeight > 768) {
                document.getElementById('byDeptspeech').style.width = 1300 + 'px'
                document.getElementById('byDeptspeech').style.height = 450 + 'px'
              } else {
                document.getElementById('byDeptspeech').style.width = 1100 + 'px'
                document.getElementById('byDeptspeech').style.height = 400 + 'px'
              }
              mychart.resize()
            }
            mychart.on('click', function(params) {
              let deptId
              if (self.currentIndex == '1') {
                for (let key in self.tableData1Speech) {
                  let str = []
                  str = key
                    .replace('[', '')
                    .replace(']', '')
                    .split(',')
                  if (params.name == str[1]) {
                    deptId = str[0]
                    break
                  }
                }
              } else if (self.currentIndex == '2') {
                for (let key in self.tableData2Speech) {
                  let str = []
                  str = key
                    .replace('[', '')
                    .replace(']', '')
                    .split(',')
                  if (params.name == str[1]) {
                    deptId = str[0]
                    break
                  }
                }
              }
              self.deptyIdcurrent = deptId
              self.currentPage3speech = 1
              self.quirySpeechlist(deptId)
            })
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    toggleSpeech() {
      let currentIndex = $(event.target).attr('data-id')
      this.currentIndex = currentIndex
      $('.speechSpan').removeClass('speechSpanActive')
      $(event.target).addClass('speechSpanActive')
      this.showSpeechcanvas()
    },
    goBackList() {
      this.isanalyticspeech = true
    },
    deparmentSure() {
      this.dialogTableVisibleself = true
    },
    deparmentInquiry() {
      this.dialogTableVisibleself = false
    },
    pickerOptions0() {},
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let str = year + '-' + month + '-' + day
      return str
    },
    formatDate(row, column, cellValue) {
      return dateUtil.timeToString(cellValue)
    },
    setSpeed(speed) {
      if (speed == 1) {
        this.formSpeech['avgSpeedMin'] = this.maxSpeed
        this.formSpeech['avgSpeedMax'] = ''
      } else if (speed == 2) {
        this.formSpeech['avgSpeedMin'] = ''
        this.formSpeech['avgSpeedMax'] = this.minSpeed
      } else {
        this.formSpeech['avgSpeedMin'] = ''
        this.formSpeech['avgSpeedMax'] = ''
      }
    },
    loadSeatGroup() {
      let self = this
      this.axios
        .post(currentBaseUrl + '/pageConstant/getValue.do?keys=seatGroup')
        .then(function(response) {
          self.optionspeech = response['data']['seatGroup']
        })
    },
  },
}
</script>
