<template>
  <div id="overlay" style="width:100%;height: 100%;position: relative">
    <div class="overlay-header" style="position: absolute;">
      <el-form ref="form" :model="formOverlay" style="margin-top: 10px;">
        <el-form-item label="重叠次数" class="fl w23">
          <el-input
            placeholder="最小值"
            style="width:80px;"
            v-model="formOverlay.overlapMin"
          ></el-input>
          ---
          <el-input
            placeholder="最大值"
            style="width:80px;"
            v-model="formOverlay.overlapMax"
          ></el-input>
        </el-form-item>
        <el-form-item label="开始时间" class="fl w23">
          <el-date-picker
            v-model="formOverlay.callSTimeMin"
            type="date"
            placeholder="选择日期"
            :picker-options="pickerOptions0"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item label="结束时间" class="fl w23">
          <el-date-picker
            v-model="formOverlay.callSTimeMax"
            type="date"
            placeholder="选择日期"
            :picker-options="pickerOptions0"
          >
          </el-date-picker>
        </el-form-item>
      </el-form>
    </div>
    <div
      class="overlay-content-pos"
      style="padding-top:60px;box-sizing: border-box;height:100%;"
    >
      <div
        class="overlay-content"
        style="width:100%;height:100%;position: relative;"
        v-if="isanalytic"
      >
        <div class="overlay-content-header" style="position: absolute;width:100%;">
          <el-button type="primary" class="fr" @click="showCanvasOverlay"
            >分析统计</el-button
          >
          <el-button class="fr" @click="overlayExport">导出</el-button>
          <el-button class="fr" @click="clearOverlay">清空</el-button>
          <el-button type="primary" class="fr" @click="inquiryOverlay">查询</el-button>
          <i
            class="el-icon-d-caret fr"
            @click="sortQuery"
            style="cursor:pointer;margin-top:25px"
            >按重叠次数排序</i
          >
        </div>
        <div
          class="overlay-content-con"
          style="width:100%;height:100%;padding-top:59px;padding-bottom:40px;box-sizing: border-box;"
        >
          <div
            class="overlay-content-table"
            style="width:100%;height:100%;overflow-y:auto;"
          >
            <el-table
              id="tableOverlay"
              key="1"
              ref="singleTable"
              :data="tableDataOverlay"
              highlight-current-row
              border
              style="width: 100%"
            >
              <el-table-column width="80" type="index" label="排名"></el-table-column>
              <el-table-column property="callId" label="录音编号">
                <template scope="scope">
                  <el-button type="text" @click="showDetail(scope.row.callId, scope.row.recordFileURL)">{{
                    scope.row.callId
                  }}</el-button>
                </template>
              </el-table-column>
              <el-table-column
                property="callSTime"
                :formatter="formatDate"
                label="录音时间"
                sortable
              ></el-table-column>
              <el-table-column property="callTime" label="通话时长"></el-table-column>
              <el-table-column property="callType" label="通话类型"></el-table-column>
              <el-table-column property="seatName" label="坐席姓名"></el-table-column>
              <el-table-column property="overLap" label="重叠次数"></el-table-column>
              <el-table-column label="查看" width="120">
                <template scope="scope">
                  <i
                    @click="showDetail(scope.row.callId)"
                    class="iconfont icon-chakan"
                    style="cursor:pointer;margin-right:20px"
                    ><i style="font-size: 14px">查看</i></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="overlay-content-footer">
            <el-pagination
              class="fr"
              @size-change="handleSizeChangeOverlay"
              @current-change="handleCurrentChangeOverlay"
              :current-page="currentPageOverlay"
              :page-size="pageSizeOverlay"
              layout="total, sizes, prev, pager, next, jumper"
              :page-sizes="[10, 20, 30, 40]"
              :total="overlayTotal"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <div
        class="overlay-content-work"
        style="width:100%;height:100%;position: relative;"
        v-show="!isanalytic"
      >
        <div class="overlay-content-header" style="position: absolute;width:100%;">
          <span class="overlaySpan overlaySpanActive" :data-id="1" @click="toggleOvlay"
            >按部门</span
          >
          <span class="overlaySpan" :data-id="2" @click="toggleOvlay">按班组</span>
          <el-button class="fr" @click="goBackList">返回清单</el-button>
          <el-button type="primary" class="fr" @click="overlayExport2">导出</el-button>
          <el-button class="fr" @click="showCanvasOverlay">查询</el-button>
          <el-select
            v-model="value4Overlay"
            clearable
            placeholder="请选择班组"
            class="fr"
            style="margin-top:10px;"
            v-if="overLayByt == '2'"
            @change="overlayChange"
          >
            <el-option
              v-for="item in optionoverLayList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
          <span
            class="fr"
            style="margin-top:18px;margin-right:10px;"
            v-if="overLayByt == '2'"
            >班组</span
          >
        </div>
        <div
          class="overlay-content-con"
          style="width:100%;height:100%;padding-top:59px;padding-bottom:40px;box-sizing: border-box;"
        >
          <div
            class="overlay-content-table"
            style="width:100%;height:100%;overflow-y:auto;"
          >
            <div id="overlayDept"></div>
          </div>
          <el-dialog :title="dialogTitle" :visible.sync="dialogTableVisible">
            <el-table :data="tableData2Overlay" border height="400">
              <el-table-column property="callId" label="录音编号"></el-table-column>
              <el-table-column property="overLap" label="重叠次数"></el-table-column>
            </el-table>
            <el-pagination
              class="fl"
              style="margin:20px 0;"
              @current-change="handleCurrentChange1Overlay"
              :current-page="currentPage1overlay"
              :page-size="detailPageSize"
              :total="diagTotal"
              layout="total, sizes, prev, pager, next, jumper"
              :page-sizes="[10, 20, 30, 40]"
              @size-change="handleDetailSizeChange"
            >
            </el-pagination>
            <el-button
              type="primary"
              class="fr"
              style="margin-top:20px;margin-left:10px;"
              @click="deparmentSure"
              >确定
            </el-button>
            <el-button
              class="fr"
              style="margin-top:20px;margin-left:10px;"
              @click="deparmentInquiry"
              >取消</el-button
            >
          </el-dialog>
        </div>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<style lang="less">
#overlay {
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }

  .overlay-header {
    width: 100%;
    height: 58px;
    line-height: 58px;
    border-bottom: 1px dashed #cfdbe7;
  }

  .overlay-header span {
    padding: 0 10px;
  }

  .overlay-header .el-input {
    width: 180px;
  }

  .overlay-content .overlay-content-header {
    height: 59px;
    line-height: 59px;
  }

  .overlay-content .overlay-content-header .el-button,
  .overlay-content-work .overlay-content-header .el-button {
    margin-top: 10px;
    margin-left: 20px;
    width: 86px;
  }

  .overlay-content-work .overlay-content-header span {
    box-sizing: border-box;
    display: inline-block;
  }

  .overlaySpan {
    padding: 0 20px;
    height: 46px;
    line-height: 46px;
    font-size: 14px;
    border-bottom: 3px solid #d1dbe4;
    color: #d1dbe4;
  }

  .overlaySpanActive {
    border-bottom: 3px solid #202d3d;
    color: #202d3d;
  }

  #tableOverlay .el-table__body-wrapper {
    overflow-x: hidden;
  }
}
</style>
<script>
import $ from 'jquery'
import vechart from './EchartImg.vue'
import global from '../../../global.js'
import Qs from 'qs'
import dateUtil from '../../../utils/dateUtil.js'
import commonUtil from '../../../utils/commonUtil.js'
import recordingplay from '../recordingPlay/recordingPlayNew.vue'
import vPlayer from '../../common/player.vue'
import bus from '../../common/bus.js'

let currentBaseUrl = global.currentBaseUrl

export default {
  components: {
    vechart,
    recordingplay,
    vPlayer,
  },
  data() {
    return {
      recordDialogVisible: false,
      formOverlay: {
        overlapMin: '',
        overlapMax: '',
        callSTimeMin: dateUtil.timeToString(dateUtil.getPreDay(new Date(), -7)),
        callSTimeMax: dateUtil.timeToString(new Date()),
        sortField: 'overLap',
        sortType: false,
      },
      dialogTitle: '部门结果',
      tableDataOverlay: [], // 表格数据
      tableDataOverlayDept: [], // 按部门的数组
      tableDataOverlayZuzhi: [],
      dialogTableVisible: false, // 按部门的数据
      isanalytic: true, // 分析统计按钮
      // imgshow:false,//
      pageSizeOverlay: 20,
      currentPageOverlay: 1,
      overlayTotal: 0,
      currentPage1overlay: 1, // 弹框
      detailPageSize: 10,
      tableData2Overlay: [], // 弹框
      diagTotal: 0,
      option2overlay: {
        tooltip: {},
        legend: {
          data: ['录音数'],
          textStyle: {
            color: '#737f8d',
          },
          x: 'center',
          y: 'bottom',
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        xAxis: [
          {
            data: [],
            axisLine: {
              lineStyle: {
                color: '#737f8d',
              },
            },
            name: '班组',
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '时间',
          },
        ],
        dataZoom: {
          start: 80,
          end: 100,
          show: true,
          realtime: false,
          y: 360,
          height: 20,
          filterMode: 'empty',
          handleSize: 20,
        },
        series: [
          {
            name: '录音数',
            type: 'bar',
            data: [],
            barWidth: 10,
            itemStyle: {
              normal: {
                color: '#50b4ff',
                label: {
                  show: true,
                  position: 'top',
                },
              },
            },
          },
        ],
      },
      overLayByt: '1', // 按部门
      overbydptId: '', //
      optionOverlay: {
        calculable: true,
        tooltip: {},
        legend: {
          data: ['录音数'],
          textStyle: {
            color: '#737f8d',
          },
          x: 'center',
          y: 'bottom',
        },
        xAxis: [
          {
            data: [],
            splitLine: {
              show: true,
              //  改变轴线颜色
              lineStyle: {
                // 使用深浅的间隔色
                color: ['#ddd'],
              },
            },
            axisLine: {
              lineStyle: {
                color: '#737f8d',
              },
            },
            name: '坐席',
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '总量',
          },
        ],
        dataZoom: {
          start: 80,
          end: 100,
          show: true,
          realtime: false,
          y: 360,
          height: 20,
          filterMode: 'empty',
          handleSize: 20,
        },
        series: [
          {
            name: '录音数',
            type: 'bar',
            data: [12, 45, 30, 33, 12, 14, 29, 46],
            barWidth: 10,
            itemStyle: {
              normal: {
                color: '#50b4ff',
                label: {
                  show: true,
                  position: 'top',
                },
              },
            },
          },
        ],
      },
      value4Overlay: '',
      optionoverLayList: [],
    }
  },
  mounted() {
    this.recordPlayCloseHandler()
    this.inquiryOverlay()
    this.loadSeatGroup()
  },
  methods: {
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'integratedSearchHr'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    overlayChange(val) {
      this.value4Overlay = val
    },
    overlayExport() {
      let params = {
        overlapMin: this.formOverlay.overlapMin,
        overlapMax: this.formOverlay.overlapMax,
        callSTimeMin: this.gettimeform(this.formOverlay.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formOverlay.callSTimeMax),
        sortField: this.formOverlay.sortField,
        sortType: this.formOverlay.sortType,
      }
      commonUtil.doExport(currentBaseUrl + '/speechFeature/export.do', params)
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    overlayExport2() {
      let baseUrl = currentBaseUrl
      if (this.currentIndex == '1') {
        baseUrl += '/speechFeature/exporDeptStatsByCode.do'
      } else {
        baseUrl += '/speechFeature/exportSeatStatsByCode.do'
      }
      let params = {
        overlapMin: this.formOverlay.overlapMin,
        overlapMax: this.formOverlay.overlapMax,
        callSTimeMin: this.gettimeform(this.formOverlay.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formOverlay.callSTimeMax),
        sortField: this.formOverlay.sortField,
        sortType: this.formOverlay.sortType,
      }
      commonUtil.doExport(baseUrl, params)
    },
    handleSizeChangeOverlay(val) {
      // 页改变
      this.pageSizeOverlay = val
      this.inquiryOverlay()
    },
    handleCurrentChangeOverlay(val) {
      // 页码改变
      this.currentPageOverlay = val
      this.inquiryOverlay()
    },
    handleCurrentChange1Overlay(val) {
      this.currentPage1overlay = val
      this.getdetialList()
    },
    handleDetailSizeChange: function(val) {
      this.detailPageSize = val
      this.currentPage1overlay = 1
      this.getdetialList()
    },
    toggleOvlay(event) {
      let currentIndex = $(event.target).attr('data-id')
      this.overLayByt = currentIndex
      $('.overlaySpan').removeClass('overlaySpanActive')
      $(event.target).addClass('overlaySpanActive')
      this.showCanvasOverlay()
    },
    getdetialList(deptId) {
      const self = this
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formOverlay.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formOverlay.callSTimeMax),
        overlapMin: this.formOverlay.overlapMin,
        overlapMax: this.formOverlay.overlapMax,
        sortField: this.formOverlay.sortField,
        pageNumber: this.currentPage1overlay,
        pageSize: this.detailPageSize,
      }
      if (self.overLayByt == '1') {
        if (deptId) {
          params.deptId = deptId
        } else {
          params.deptId = self.overbydptId
        }
      } else if (self.overLayByt == '2') {
        if (deptId) {
          params.seatNo = deptId
        } else {
          params.seatNo = self.overbydptId
        }
      }

      this.axios
        .post(
          currentBaseUrl + '/speechFeature/queryRecords.do',
          Qs.stringify(params),
          configss
        )
        .then(function(res) {
          if (res.status == 200 && res.data.state == '1') {
            self.tableData2Overlay = res.data.results
            self.diagTotal = res.data.count
            self.dialogTableVisible = true
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    goBackList() {
      // 返回清单
      this.isanalytic = true
    },
    showCanvasOverlay() {
      this.isanalytic = false
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      const self = this
      let params = {
        callSTimeMin: this.gettimeform(this.formOverlay.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formOverlay.callSTimeMax),
        overlapMin: this.formOverlay.overlapMin,
        overlapMax: this.formOverlay.overlapMax,
      }
      if (self.overLayByt == '2') {
        params.groupId = self.value4Overlay
      }
      this.axios
        .post(currentBaseUrl + '/speechFeature/statis.do', Qs.stringify(params), configss)
        .then(function(response) {
          if (response.status == 200 && response.data.state == 1) {
            self.tableDataOverlayDept = response.data.other.dept
            self.tableDataOverlayZuzhi = response.data.other.seat
            let options = null
            if (self.overLayByt == '1') {
              // 按部门
              self.option2overlay.series[0].data = []
              self.option2overlay.xAxis[0].data = []
              for (let key in self.tableDataOverlayDept) {
                let str = ''
                str = key.replace('[', '').replace(']', '')
                self.option2overlay.xAxis[0].data.push(str.split(',')[1])
                self.option2overlay.series[0].data.push(self.tableDataOverlayDept[key])
              }
              options = self.option2overlay
            } else if (self.overLayByt == '2') {
              self.optionOverlay.series[0].data = []
              self.optionOverlay.xAxis[0].data = []
              for (let key in self.tableDataOverlayZuzhi) {
                let str = ''
                str = key.replace('[', '').replace(']', '')
                self.optionOverlay.xAxis[0].data.push(str.split(',')[1])
                self.optionOverlay.series[0].data.push(self.tableDataOverlayZuzhi[key])
              }
              options = self.optionOverlay
            }
            if (window.innerHeight > 900) {
              document.getElementById('overlayDept').style.width = 1420 + 'px'
              document.getElementById('overlayDept').style.height = 400 + 'px'
            } else if (window.innerHeight > 768) {
              document.getElementById('overlayDept').style.width = 1220 + 'px'
              document.getElementById('overlayDept').style.height = 400 + 'px'
            } else {
              document.getElementById('overlayDept').style.width = 1100 + 'px'
              document.getElementById('overlayDept').style.height = 400 + 'px'
            }
            let mychart = self.$echarts.init(document.getElementById('overlayDept'))
            mychart.clear()
            mychart.setOption(options)
            window.onresize = function() {
              if (window.innerHeight > 900) {
                document.getElementById('overlayDept').style.width = 1600 + 'px'
                document.getElementById('overlayDept').style.height = 400 + 'px'
              } else if (window.innerHeight > 768) {
                document.getElementById('overlayDept').style.width = 1300 + 'px'
                document.getElementById('overlayDept').style.height = 450 + 'px'
              } else {
                document.getElementById('overlayDept').style.width = 1100 + 'px'
                document.getElementById('overlayDept').style.height = 400 + 'px'
              }
              mychart.resize()
            }
            mychart.on('click', function(params) {
              let deptId
              if (self.overLayByt == '1') {
                for (let key in self.tableDataOverlayDept) {
                  let str = []
                  str = key
                    .replace('[', '')
                    .replace(']', '')
                    .split(',')
                  if (params.name == str[1]) {
                    deptId = str[0]
                    break
                  }
                }
              } else if (self.overLayByt == '2') {
                for (let key in self.tableDataOverlayZuzhi) {
                  let str = []
                  str = key
                    .replace('[', '')
                    .replace(']', '')
                    .split(',')
                  if (params.name == str[1]) {
                    deptId = str[0]
                    break
                  }
                }
              }
              self.overbydptId = deptId
              self.currentPage1overlay = 1
              self.getdetialList(deptId)
            })
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let str = year + '-' + month + '-' + day
      return str
    },
    deparmentSure() {
      // 部门结果确定
      this.dialogTableVisible = false
    },
    deparmentInquiry() {
      // 部门结果取消
      this.dialogTableVisible = false
    },
    inquiryOverlay() {
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formOverlay.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formOverlay.callSTimeMax),
        overlapMin: this.formOverlay.overlapMin,
        overlapMax: this.formOverlay.overlapMax,
        sortField: this.formOverlay.sortField,
        pageNumber: this.currentPageOverlay,
        pageSize: this.pageSizeOverlay,
        sortType: this.formOverlay.sortType,
      }
      const self = this
      this.axios
        .post(
          currentBaseUrl + '/speechFeature/queryRecords.do',
          Qs.stringify(params),
          configss
        )
        .then(function(response) {
          self.tableDataOverlay = response.data.results
          self.overlayTotal = response.data.count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    sortQuery() {
      this.formOverlay.sortType = !this.formOverlay.sortType
      this.inquiryOverlay()
    },
    pickerOptions0() {},
    clearOverlay() {
      for (let key in this.formOverlay) {
        this.formOverlay[key] = ''
      }
      this.formOverlay.sortField = 'overLap'
      this.formOverlay.sortType = false
    },
    formatDate(row, column, cellValue) {
      return dateUtil.timeToString(cellValue)
    },
    loadSeatGroup() {
      let self = this
      this.axios
        .post(currentBaseUrl + '/pageConstant/getValue.do?keys=seatGroup')
        .then(function(response) {
          self.optionoverLayList = response['data']['seatGroup']
        })
    },
  },
}
</script>
