<template>
  <div id="slicent">
    <div class="slicent-header" style="position: absolute;height:56px;line-height: 56px;">
      <el-form ref="form" :model="formSlicent" style="margin-top: 10px;">
        <el-form-item label="静默特征" class="fl w23">
          <el-select
            placeholder="请选择"
            @change="sliceChange"
            v-model="formSlicent.sortField"
          >
            <el-option label="时长" value="silenceLong"></el-option>
            <el-option label="占比" value="silencePer"></el-option>
            <el-option label="次数" value="silenceCount"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          label="时长"
          v-if="formSlicent.sortField == 'silenceLong'"
          class="fl w23"
        >
          <el-input
            placeholder="最小值"
            style="width:80px;"
            v-model="formSlicent.silenceLongMin"
          ></el-input>
          ---
          <el-input
            placeholder="最大值"
            style="width:80px;"
            v-model="formSlicent.silenceLongMax"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="占比"
          v-if="formSlicent.sortField == 'silencePer'"
          class="fl w23"
        >
          <el-input
            placeholder="最小值"
            style="width:80px;"
            v-model="formSlicent.silencePerMin"
          ></el-input>
          ---
          <el-input
            placeholder="最大值"
            style="width:80px;"
            v-model="formSlicent.silencePerMax"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="次数"
          v-if="formSlicent.sortField == 'silenceCount'"
          class="fl w23"
        >
          <el-input
            placeholder="最小值"
            style="width:80px;"
            v-model="formSlicent.silenceCountMin"
          ></el-input>
          ---
          <el-input
            placeholder="最大值"
            style="width:80px;"
            v-model="formSlicent.silenceCountMax"
          ></el-input>
        </el-form-item>
        <el-form-item label="开始时间" class="fl w23">
          <el-date-picker
            v-model="formSlicent.callSTimeMin"
            type="date"
            placeholder="选择日期"
            :picker-options="pickerOptions0"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item label="结束时间" class="fl w23">
          <el-date-picker
            v-model="formSlicent.callSTimeMax"
            type="date"
            placeholder="选择日期"
            :picker-options="pickerOptions0"
          >
          </el-date-picker>
        </el-form-item>
      </el-form>
    </div>
    <div
      class="slicent-content-pos"
      style="padding-top:60px;box-sizing: border-box;height:100%;top:80px;"
    >
      <div
        class="slicent-content"
        style="width:100%;height:100%;position: relative;"
        v-if="isanalytic"
      >
        <div class="slicent-content-header" style="position: absolute;width:100%;">
          <el-button type="primary" class="fr" @click="showCanvas">分析统计</el-button>
          <el-button class="fr" @click="sliceExport">导出</el-button>
          <el-button class="fr" @click="emptySound">清空</el-button>
          <el-button type="primary" class="fr" @click="overlayInquiry">查询</el-button>
          <i
            class="el-icon-d-caret fr"
            @click="sortQuery"
            style="cursor:pointer;margin-top:25px"
            >{{ sortFieldName }}</i
          >
        </div>
        <div
          class="slicent-content-con"
          style="width:100%;height:100%;padding-top:59px;padding-bottom:40px;box-sizing: border-box;"
        >
          <div
            class="slicent-content-table"
            style="width:100%;height:100%;overflow-y:auto;"
          >
            <el-table
              id="tableSlice"
              ref="singleTable"
              :data="tableData"
              border
              highlight-current-row
            >
              <el-table-column width="80" type="index" label="排名"></el-table-column>
              <el-table-column property="callId" label="录音编号">
                <template scope="scope">
                  <el-button type="text" @click="showDetail(scope.row.callId, scope.row.recordFileURL)">{{
                    scope.row.callId
                  }}</el-button>
                </template>
              </el-table-column>
              <el-table-column
                property="callSTime"
                :formatter="formatDate"
                label="录音时间"
                sortable
              ></el-table-column>
              <el-table-column property="seatName" label="坐席姓名"></el-table-column>
              <el-table-column property="silenceCount" label="静默次数"></el-table-column>
              <el-table-column
                property="silenceLong"
                label="静默总时长"
              ></el-table-column>
              <el-table-column property="silencePer" label="静默占比"></el-table-column>
              <el-table-column label="查看" width="120">
                <template scope="scope">
                  <i
                    @click="showDetail(scope.row.callId, scope.row.recordFileURL)"
                    class="iconfont icon-chakan"
                    style="cursor:pointer;margin-right:20px"
                    ><i style="font-size: 14px">查看</i></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="slicent-content-footer">
            <el-pagination
              class="fr"
              @size-change="handleSizeChangeSlice"
              @current-change="handleCurrentChangeSlice"
              :current-page="currentPage1"
              :page-sizes="[10, 20, 30, 40]"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="tapeCount"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <div
        class="slicent-content-work"
        style="width:100%;height:100%;position: relative;"
        v-show="!isanalytic"
      >
        <div class="slicent-content-header" style="position: absolute;width:100%;">
          <span class="slicentSpan slicentSpanActive" :data-id="1" @click="toggleSlice"
            >按部门</span
          >
          <span class="slicentSpan" :data-id="2" @click="toggleSlice">按班组</span>
          <el-button class="fr" @click="goBackList">返回清单</el-button>
          <el-button type="primary" class="fr" @click="sliceExport2">导出</el-button>
          <el-button class="fr" @click="showCanvas">查询</el-button>
          <el-select
            v-model="value4slice"
            clearable
            placeholder="请选择班组"
            class="fr"
            style="margin-top:10px;"
            v-if="currentBydept == '2'"
            @change="groupChange"
          >
            <el-option
              v-for="item in optionslice"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
          <span
            class="fr"
            style="margin-top:18px;margin-right:10px;"
            v-if="currentBydept == '2'"
            >班组</span
          >
        </div>
        <div
          class="slicent-content-con"
          style="width:100%;height:100%;padding-top:59px;padding-bottom:70px;box-sizing: border-box;"
        >
          <div
            class="slicent-content-table"
            style="width:100%;height:100%;overflow-y:auto;"
          >
            <div id="byDept"></div>
          </div>
          <el-dialog :title="dialogTitle" :visible.sync="dialogTableVisible">
            <el-table :data="tableData2" border height="400" v-if="dialogTableVisible">
              <el-table-column property="callId" label="录音编号"></el-table-column>
              <el-table-column
                property="silenceLong"
                label="静默总时长"
              ></el-table-column>
              <el-table-column property="silenceCount" label="静默次数"></el-table-column>
              <el-table-column property="silencePer" label="静默占比"></el-table-column>
            </el-table>
            <el-pagination
              class="fl"
              style="margin:20px 0;"
              v-if="dialogTableVisible"
              @current-change="handleCurrentChange1"
              @size-change="handleDetailSizeChange"
              :current-page="currentPage2"
              :page-size="detailPageSize"
              :total="byDeptTotal"
              :page-sizes="[10, 20, 30, 40]"
              layout="total, sizes, prev, pager, next, jumper"
            >
            </el-pagination>
            <el-button
              class="fr"
              style="margin-top:20px;margin-left:10px;"
              @click="deparmentInquiry"
              >取消
            </el-button>
            <el-button
              type="primary"
              class="fr"
              style="margin-top:20px;margin-left:10px;"
              @click="deparmentSure"
              >确定
            </el-button>
          </el-dialog>
        </div>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>

<style lang="less">
#slicent {
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
  .slicent-header {
    width: 100%;
    height: 58px;
    border-bottom: 1px dashed #cfdbe7;
  }

  .slicent-header span {
    padding: 0 10px;
  }

  .slicent-header .el-input {
    width: 180px;
  }

  .slicent-content .slicent-content-header {
    height: 59px;
    line-height: 59px;
  }

  .slicent-content .slicent-content-header .el-button,
  .slicent-content-work .slicent-content-header .el-button {
    margin-top: 10px;
    margin-left: 20px;
    width: 86px;
  }

  .slicent-content-work .slicent-content-header span {
    box-sizing: border-box;
    display: inline-block;
  }

  .slicentSpan {
    padding: 0 20px;
    height: 46px;
    line-height: 46px;
    font-size: 14px;
    border-bottom: 3px solid #d1dbe4;
    color: #d1dbe4;
  }

  .slicentSpanActive {
    border-bottom: 3px solid #202d3d;
    color: #202d3d;
  }

  /*静默特征分析的span选中的按钮*/
  .spanActive {
    background: #f3f4f3;
  }

  #tableSlice .el-table__body-wrapper {
    overflow-x: hidden;
  }
  /*button*/
  .el-button + .el-button {
    margin-left: 0;
  }
}
</style>
<script>
import $ from 'jquery'
import global from '../../../global.js'
import Qs from 'qs'
import dateUtil from '../../../utils/dateUtil.js'
import commonUtil from '../../../utils/commonUtil.js'
import recordingplay from '../recordingPlay/recordingPlayNew.vue'
import vPlayer from '../../common/player.vue'
import bus from '../../common/bus.js'
let currentBaseUrl = global.currentBaseUrl
import vechartimg from './EchartImg.vue'

export default {
  created: function() {
    this.recordPlayCloseHandler()
    this.$nextTick(() => {
      // 这儿是默认查询
      this.overlayInquiry()
      this.loadSeatGroup()
    })
  },
  components: {
    vechartimg,
    recordingplay,
    vPlayer,
  },
  data() {
    return {
      recordDialogVisible: false,
      sortFieldName: '按静默时长排序',
      dialogTitle: '部门结果',
      isanalytic: true, // 统计分析
      dialogTableVisible: false, // 弹出窗
      tapeCount: 0, // 录音列表==》总数
      currentPage1: 1, // 录音列表
      tableData: [],
      pageSize: 20,
      tableData1: [], // 按部门拿到的数据
      tableData3: [], // 按班组拿到数据==》现在暂时没有
      tableData2: [], // ==》部门结果的具体展示（弹出框）
      option2: {
        tooltip: {},
        legend: {
          data: ['静默总时长'],
          textStyle: {
            color: '#737f8d',
          },
          x: 'center',
          y: 'bottom',
        },
        xAxis: [
          {
            data: [],
            axisLine: {
              lineStyle: {
                color: '#737f8d',
              },
            },
            name: '班组',
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '总数',
          },
        ],
        dataZoom: {
          start: 80,
          end: 100,
          show: true,
          realtime: false,
          y: 360,
          height: 20,
          filterMode: 'empty',
          handleSize: 20,
        },
        series: [
          {
            name: '静默总时长',
            type: 'bar',
            data: [],
            barWidth: 10,
            barGap: 5,
            itemStyle: {
              normal: {
                color: '#50b4ff',
                label: {
                  show: true,
                  position: 'top',
                },
              },
            },
          },
        ],
      },
      byDeptTotal: 0, // 按部门查询拿到的数据
      currentPage2: 1, // 按部门查询的当前页
      detailPageSize: 10,
      currentRow: '', // 当前行
      formSlicent: {
        // 静默的表单
        sortField: 'silenceLong',
        sortType: false,
        silenceLongMin: '', // 静默时长
        silenceLongMax: '',
        silenceCountMin: '', // 静默次数
        silenceCountMax: '',
        silencePerMin: '', // 静默占比
        silencePerMax: '',
        callSTimeMin: dateUtil.timeToString(dateUtil.getPreDay(new Date(), -7)), // 录音开始时间
        callSTimeMax: dateUtil.timeToString(new Date()), // 录音结束时间
      },
      currentBydept: '1', // 当前按部门
      value4slice: '', // 按班组
      optionslice: [],
      optionSlice: {
        calculable: true,
        tooltip: {},
        legend: {
          data: ['录音数'],
          textStyle: {
            color: '#737f8d',
          },
          x: 'center',
          y: 'bottom',
        },
        xAxis: [
          {
            data: ['小毛', '李四', '张三', '123', 'qwe', 'asd', 'qwe', 'qwe'],
            splitLine: {
              show: true,
              //  改变轴线颜色
              lineStyle: {
                // 使用深浅的间隔色
                color: ['#ddd'],
              },
            },
            axisLine: {
              lineStyle: {
                color: '#737f8d',
              },
            },
            name: '坐席',
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '总量',
          },
        ],
        dataZoom: {
          start: 80,
          end: 100,
          show: true,
          realtime: false,
          y: 360,
          height: 20,
          filterMode: 'empty',
          handleSize: 20,
        },
        series: [
          {
            name: '录音数',
            type: 'bar',
            data: [],
            barWidth: 10,
            barGap: 5,
            itemStyle: {
              normal: {
                color: ['#50b4ff'],
                label: {
                  show: true,
                  position: 'top',
                },
              },
            },
          },
        ],
      },
      currentdeptId: '',
    }
  },
  methods: {
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'integratedSearchHr'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    groupChange(val) {
      this.value4slice = val
    },
    sliceExport() {
      // 录音清单导出
      let params = {
        callSTimeMin: this.gettimeform(this.formSlicent.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSlicent.callSTimeMax),
        silenceCountMin: this.formSlicent.silenceCountMin,
        silenceCountMax: this.formSlicent.silenceCountMax,
        silenceLongMin: this.formSlicent.silenceLongMin,
        silenceLongMax: this.formSlicent.silenceLongMax,
        silencePerMin: this.formSlicent.silencePerMin,
        silencePerMax: this.formSlicent.silencePerMax,
        sortField: this.formSlicent.sortField,
        sortType: this.formSlicent.sortType,
      }
      commonUtil.doExport(currentBaseUrl + '/speechFeature/export.do', params)
    },
    sliceExport2() {
      // 统计信息导出
      let baseUrl = currentBaseUrl
      if (this.currentBydept == '1') {
        // 按部门导出
        baseUrl += '/speechFeature/exporDeptStatsByCode.do'
      } else {
        // 按组织导出
        baseUrl += '/speechFeature/exportSeatStatsByCode.do'
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formSlicent.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSlicent.callSTimeMax),
        silenceCountMin: this.formSlicent.silenceCountMin,
        silenceCountMax: this.formSlicent.silenceCountMax,
        silenceLongMin: this.formSlicent.silenceLongMin,
        silenceLongMax: this.formSlicent.silenceLongMax,
        silencePerMin: this.formSlicent.silencePerMin,
        silencePerMax: this.formSlicent.silencePerMax,
        sortField: this.formSlicent.sortField,
        sortType: this.formSlicent.sortType,
      }
      commonUtil.doExport(baseUrl, params)
    },
    emptySound() {
      // 清空查询参数
      for (let key in this.formSlicent) {
        this.formSlicent[key] = ''
      }
      this.formSlicent.sortField = 'silenceLong'
      this.formSlicent.sortType = false
    },
    overlayInquiry() {
      // 查询参数
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formSlicent.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSlicent.callSTimeMax),
        silenceCountMin: this.formSlicent.silenceCountMin,
        silenceCountMax: this.formSlicent.silenceCountMax,
        silenceLongMin: this.formSlicent.silenceLongMin,
        silenceLongMax: this.formSlicent.silenceLongMax,
        silencePerMin: this.formSlicent.silencePerMin,
        silencePerMax: this.formSlicent.silencePerMax,
        pageNumber: this.currentPage1,
        pageSize: this.pageSize,
        sortField: this.formSlicent.sortField,
        sortType: this.formSlicent.sortType,
      }
      const self = this
      this.axios
        .post(
          currentBaseUrl + '/speechFeature/queryRecords.do',
          Qs.stringify(params),
          configss
        )
        .then(function(response) {
          if (response.status == 200 && response.data.state == 1) {
            response.data.results.forEach(function(val, index) {
              val.silenceLong = (val.silenceLong / 1000).toFixed(2) + '秒'
              val.silencePer = (val.silencePer * 100).toFixed(2) + '%'
            })
            self.tableData = response.data.results
            self.tapeCount = response.data.count
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    sortQuery() {
      this.formSlicent.sortType = !this.formSlicent.sortType
      this.overlayInquiry()
    },
    handleCurrentChangeSlice(val) {
      // 分页的查询
      this.currentPage1 = val
      this.overlayInquiry()
    },
    handleSizeChangeSlice(val) {
      // 分页的
      this.pageSize = val
      this.overlayInquiry()
    },
    handleCurrentChange1(val) {
      // 按部门查询的==>弹框里的
      this.currentPage2 = val
      this.deptQuiry()
    },
    handleDetailSizeChange(val) {
      this.detailPageSize = val
      this.currentPage2 = 1
      this.deptQuiry()
    },
    deptQuiry(deptId) {
      // 按部门查询
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      const self = this
      let params = {
        callSTimeMin: this.gettimeform(this.formSlicent.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSlicent.callSTimeMax),
        silenceCountMin: this.formSlicent.silenceCountMin,
        silenceCountMax: this.formSlicent.silenceCountMax,
        silenceLongMin: this.formSlicent.silenceLongMin,
        silenceLongMax: this.formSlicent.silenceLongMax,
        silencePerMin: this.formSlicent.silencePerMin,
        silencePerMax: this.formSlicent.silencePerMax,
        pageNumber: this.currentPage2,
        pageSize: this.detailPageSize,
        sortField: this.formSlicent.sortField,
      }
      if (this.currentBydept == '1') {
        if (deptId) {
          params.deptId = deptId
        } else {
          params.deptId = this.currentdeptId
        }
      } else if (this.currentBydept == '2') {
        if (deptId) {
          params.seatNo = deptId
        } else {
          params.seatNo = this.currentdeptId
        }
      }

      this.axios
        .post(
          currentBaseUrl + '/speechFeature/queryRecords.do',
          Qs.stringify(params),
          configss
        )
        .then(function(res) {
          if (res.status == 200 && res.data.state == '1') {
            res.data.results.forEach(function(val, index) {
              val.silenceLong = (val.silenceLong / 1000).toFixed(2) + '秒'
              val.silencePer = (val.silencePer * 100).toFixed(2) + '%'
            })
            self.tableData2 = res.data.results
            self.byDeptTotal = res.data.count
            self.dialogTableVisible = true
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    pickerOptions0() {},
    showCanvas() {
      this.isanalytic = false
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formSlicent.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formSlicent.callSTimeMax),
        silenceCountMin: this.formSlicent.silenceCountMin,
        silenceCountMax: this.formSlicent.silenceCountMax,
        silenceLongMin: this.formSlicent.silenceLongMin,
        silenceLongMax: this.formSlicent.silenceLongMax,
        silencePerMin: this.formSlicent.silencePerMin,
        silencePerMax: this.formSlicent.silencePerMax,
      }
      const self = this
      if (self.currentBydept == '2') {
        params.groupId = self.value4slice
      }
      this.axios
        .post(currentBaseUrl + '/speechFeature/statis.do', Qs.stringify(params), configss)
        .then(function(response) {
          if (response.status == 200 && response.data.state == 1) {
            self.tableData1 = response.data.other.dept
            self.tableData3 = response.data.other.seat
            let options = null
            if (self.currentBydept == '1') {
              // 按部门
              self.option2.legend.data = ['录音数']
              self.option2.series[0].name = '录音数'
              self.option2.series[0].data = []
              self.option2.xAxis[0].data = []
              for (let key in self.tableData1) {
                let str = ''
                str = key.replace('[', '').replace(']', '')
                self.option2.xAxis[0].data.push(str.split(',')[1])
                self.option2.series[0].data.push(self.tableData1[key])
              }
              options = self.option2
            } else if (self.currentBydept == '2') {
              // 按组织optionSlice
              self.option2.legend.data = ['录音数']
              self.option2.series[0].name = '录音数'
              self.optionSlice.series[0].data = []
              self.optionSlice.xAxis[0].data = []
              // 注意这儿从后边拿到的self.tableData3是一个空对象，后面是没有数据的==》这儿用的就是假数据
              for (let key in self.tableData3) {
                let arr = key
                  .replace('[', '')
                  .replace(']', '')
                  .split(',')
                self.optionSlice.xAxis[0].data.push(arr[1])
                self.optionSlice.series[0].data.push(self.tableData3[key])
              }
              options = self.optionSlice
            }
            if (window.innerHeight > 900) {
              document.getElementById('byDept').style.width = 1420 + 'px'
              document.getElementById('byDept').style.height = 400 + 'px'
            } else if (window.innerHeight > 768) {
              document.getElementById('byDept').style.width = 1220 + 'px'
              // document.getElementById('byDept').style.height = 350 + 'px'
              document.getElementById('byDept').style.height = 400 + 'px'
            } else {
              document.getElementById('byDept').style.width = 1100 + 'px'
              // document.getElementById('byDept').style.height = 280 + '%'
              document.getElementById('byDept').style.height = 400 + 'px'
            }
            let mychart = self.$echarts.init(document.getElementById('byDept'))
            mychart.clear()
            mychart.setOption(options)
            window.onresize = function() {
              if (document.getElementById('byDept')) {
                if (window.innerHeight > 900) {
                  document.getElementById('byDept').style.width = 1600 + 'px'
                  document.getElementById('byDept').style.height = 400 + 'px'
                } else if (window.innerHeight > 768) {
                  document.getElementById('byDept').style.width = 1300 + 'px'
                  document.getElementById('byDept').style.height = 450 + 'px'
                } else {
                  document.getElementById('byDept').style.width = 1100 + 'px'
                  document.getElementById('byDept').style.height = 400 + 'px'
                }
                mychart.resize()
              }
            }
            mychart.on('click', function(params) {
              console.log('点击了图表!')
              let deptId
              if (self.currentBydept == '1') {
                self.dialogTitle = '部门结果'
                for (let key in self.tableData1) {
                  let str = []
                  str = key
                    .replace('[', '')
                    .replace(']', '')
                    .split(',')
                  if (params.name == str[1]) {
                    deptId = str[0]
                    break
                  }
                }
              } else if (self.currentBydept == '2') {
                self.dialogTitle = '班组结果'
                for (let key in self.tableData3) {
                  console.log(key)
                  let str = []
                  str = key
                    .replace('[', '')
                    .replace(']', '')
                    .split(',')
                  if (params.name == str[1]) {
                    deptId = str[0]
                    break
                  }
                }
              }
              self.currentdeptId = deptId
              self.currentPage2 = 1
              console.log(self.currentdeptId)
              self.deptQuiry(deptId)
            })
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    goBackList() {
      this.isanalytic = true
    },
    toggleSlice() {
      // 部门与组织之间的查询
      let currentIndex = $(event.target).attr('data-id')
      this.currentBydept = currentIndex
      $('.slicentSpan').removeClass('slicentSpanActive')
      $(event.target).addClass('slicentSpanActive')
      this.showCanvas()
    },
    deparmentSure() {
      this.dialogTableVisible = false
    },
    deparmentInquiry() {
      this.dialogTableVisible = false
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let str = year + '-' + month + '-' + day
      return str
    },
    sliceChange(val) {
      // 静默特征切换
      this.formSlicent.sortField = val
      if (val == 'silenceLong') {
        this.sortFieldName = '按静默时长排序'
        this.formSlicent.silenceCountMin = ''
        this.formSlicent.silenceCountMax = ''
        this.formSlicent.silencePerMin = ''
        this.formSlicent.silencePerMax = ''
      }
      if (val == 'silenceCount') {
        this.sortFieldName = '按静默次数排序'
        this.formSlicent.silenceLongMin = ''
        this.formSlicent.silenceLongMax = ''
        this.formSlicent.silencePerMin = ''
        this.formSlicent.silencePerMax = ''
      }
      if (val == 'silencePer') {
        this.sortFieldName = '按静默占比排序'
        this.formSlicent.silenceLongMin = ''
        this.formSlicent.silenceLongMax = ''
        this.formSlicent.silenceCountMin = ''
        this.formSlicent.silenceCountMax = ''
      }
    },
    formatDate(row, column, cellValue) {
      return dateUtil.timeToString(cellValue)
    },
    loadSeatGroup() {
      let self = this
      this.axios
        .post(currentBaseUrl + '/pageConstant/getValue.do?keys=seatGroup')
        .then(function(response) {
          self.optionslice = response['data']['seatGroup']
        })
    },
  },
}
</script>
