<template>
  <div id="callingRate">
    <div class="callingRate-header" style="position: absolute;">
      <el-form ref="form" :model="formRate" style="margin-top: 10px;">
        <el-form-item label="占比" class="fl w22">
          <el-select
            placeholder="请选择"
            @change="callRateChange"
            v-model="formRate.sortField"
          >
            <el-option label="通话回合数占比" value="seatCallRoundPer"></el-option>
            <el-option label="通话时长占比" value="seatCallTimePer"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          label="通话回合数占比"
          v-if="formRate.sortField == 'seatCallRoundPer'"
          class="fl w28"
        >
          <el-input
            placeholder="最小值"
            style="width:80px;"
            v-model="formRate.seatCallRoundPerMin"
          ></el-input>
          ---
          <el-input
            placeholder="最大值"
            style="width:80px;"
            v-model="formRate.seatCallRoundPerMax"
          ></el-input>
        </el-form-item>
        <el-form-item
          label="通话时长占比"
          v-if="formRate.sortField == 'seatCallTimePer'"
          class="fl w28"
        >
          <el-input
            placeholder="最小值"
            style="width:80px;"
            v-model="formRate.seatCallTimePerMin"
          ></el-input>
          ---
          <el-input
            placeholder="最大值"
            style="width:80px;"
            v-model="formRate.seatCallTimePerMax"
          ></el-input>
        </el-form-item>
        <el-form-item label="开始时间" class="fl w23">
          <el-date-picker
            v-model="formRate.callSTimeMin"
            type="date"
            placeholder="选择日期"
            :picker-options="pickerOptions0"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item label="结束时间" class="fl w23">
          <el-date-picker
            v-model="formRate.callSTimeMax"
            type="date"
            placeholder="选择日期"
            :picker-options="pickerOptions0"
          >
          </el-date-picker>
        </el-form-item>
      </el-form>
    </div>
    <div
      class="callingRate-content-pos"
      style="padding-top:60px;box-sizing: border-box;height:100%;"
    >
      <div
        class="callingRate-content"
        style="width:100%;height:100%;position: relative;"
        v-if="isanalytic"
      >
        <div class="callingRate-content-header" style="position: absolute;width:100%;">
          <el-button type="primary" class="fr" @click="showRateCanas">分析统计</el-button>
          <el-button class="fr" @click="rateExport">导出</el-button>
          <el-button class="fr" @click="clearCallRate">清空</el-button>
          <el-button type="primary" class="fr" @click="inquiryOverlay">查询</el-button>
          <i
            class="el-icon-d-caret fr"
            @click="sortQuery"
            style="cursor:pointer;margin-top:25px"
            >{{ sortFieldName }}</i
          >
        </div>
        <div
          class="callingRate-content-con"
          style="width:100%;height:100%;padding-top:59px;padding-bottom:40px;box-sizing: border-box;"
        >
          <div
            class="callingRate-content-table"
            style="width:100%;height:100%;overflow-y:auto;"
          >
            <el-table
              id="tableDataRate"
              key="1"
              ref="singleTable"
              :data="tableDataRate"
              highlight-current-row
              border
              style="width: 100%"
            >
              <el-table-column
                property="ranging"
                type="index"
                label="排名"
                width="80"
              ></el-table-column>
              <el-table-column property="callId" label="录音编号">
                <template scope="scope">
                  <el-button type="text" @click="showDetail(scope.row.callId, scope.row.recordFileURL)">{{
                    scope.row.callId
                  }}</el-button>
                </template>
              </el-table-column>
              <el-table-column
                property="callSTime"
                :formatter="formatDate"
                label="录音时间"
                sortable
              ></el-table-column>
              <el-table-column property="callTime" label="通话时长"></el-table-column>
              <el-table-column property="callType" label="通话类型"></el-table-column>
              <el-table-column property="seatName" label="坐席姓名"></el-table-column>
              <el-table-column
                property="seatCallRoundPer"
                :formatter="toFixed"
                label="通话回合数占比"
              ></el-table-column>
              <el-table-column
                property="seatCallTimePer"
                :formatter="toFixed"
                label="通话时长占比"
              ></el-table-column>
              <el-table-column label="查看" width="120">
                <template scope="scope">
                  <i
                    @click="showDetail(scope.row.callId, scope.row.recordFileURL)"
                    class="iconfont icon-chakan"
                    style="cursor:pointer;margin-right:20px"
                    ><i style="font-size: 14px">查看</i></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="callingRate-content-footer">
            <el-pagination
              class="fr"
              @size-change="handleSizeChangeRate"
              @current-change="handleCurrentChangeRate"
              :current-page="currentPageRate"
              :page-sizes="[10, 20, 30, 40]"
              :page-size="pageSizeRate"
              layout="total, sizes, prev, pager, next, jumper"
              :total="tapeRateTotal"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <div
        class="callingRate-content-work"
        style="width:100%;height:100%;position: relative;"
        v-show="!isanalytic"
      >
        <div class="callingRate-content-header" style="position: absolute;width:100%;">
          <span class="callingSpan callingSpanActive" :data-id="1" @click="toggleCalling"
            >按部门</span
          >
          <span class="callingSpan" :data-id="2" @click="toggleCalling">按班组</span>
          <el-button class="fr" @click="goBackList">返回清单</el-button>
          <el-button class="fr" type="primary" @click="rateExport2">导出</el-button>
          <el-button class="fr" @click="showRateCanas">查询</el-button>
          <el-select
            v-model="valueRate4"
            clearable
            placeholder="请选择班组"
            class="fr"
            style="margin-top:10px;"
            v-if="currentIndexRate == '2'"
            @change="rateChange"
          >
            <el-option
              v-for="item in optionRate4"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
          <span
            class="fr"
            style="margin-top:18px;margin-right:10px;"
            v-if="currentIndexRate == '2'"
            >班组</span
          >
        </div>
        <div
          class="callingRate-content-con"
          style="width:100%;height:100%;padding-top:59px;padding-bottom:40px;box-sizing: border-box;"
        >
          <div style="width:100%;height:100%;">
            <div id="byDeptRate"></div>
          </div>
          <el-dialog :title="dialogTitle" :visible.sync="dialogTableVisible">
            <el-table :data="tableData3Rate" border height="400">
              <el-table-column property="callId" label="录音编号"></el-table-column>
              <el-table-column
                property="seatCallRoundPer"
                :formatter="toFixed"
                label="通话回合数占比"
              ></el-table-column>
              <el-table-column
                property="seatCallTimePer"
                :formatter="toFixed"
                label="通话时间占比"
              ></el-table-column>
            </el-table>
            <el-pagination
              class="fl"
              style="margin:20px 0;"
              @current-change="handleCurrentChangeRate2"
              :current-page="currentPageRate2"
              :page-size="detailPageSize"
              :total="TotalRate1"
              :page-sizes="[10, 20, 30, 40]"
              layout="total, sizes, prev, pager, next, jumper"
              @size-change="handleDetailSizeChange"
            >
            </el-pagination>
            <el-button
              type="primary"
              class="fr"
              style="margin-top:20px;margin-left:10px;"
              @click="deparmentSure"
              >确定
            </el-button>
            <el-button
              class="fr"
              style="margin-top:20px;margin-left:10px;"
              @click="deparmentInquiry"
              >取消</el-button
            >
          </el-dialog>
        </div>
      </div>
    </div>
    <el-dialog
      title="录音播放页面"
      class="single"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import vechartimg from './EchartImg.vue'
import global from '../../../global.js'
import Qs from 'qs'
import dateUtil from '../../../utils/dateUtil.js'
import commonUtil from '../../../utils/commonUtil.js'
import recordingplay from '../recordingPlay/recordingPlayNew.vue'
import vPlayer from '../../common/player.vue'
import bus from '../../common/bus.js'
let currentBaseUrl = global.currentBaseUrl

export default {
  components: {
    vechartimg,
    recordingplay,
    vPlayer,
  },
  mounted() {
    this.recordPlayCloseHandler()
    this.inquiryOverlay()
    this.loadSeatGroup()
  },
  data() {
    return {
      recordDialogVisible: false,
      formRate: {
        callSTimeMin: dateUtil.timeToString(dateUtil.getPreDay(new Date(), -7)),
        callSTimeMax: dateUtil.timeToString(new Date()),
        seatCallRoundPerMin: '',
        seatCallRoundPerMax: '',
        seatCallTimePerMin: '',
        seatCallTimePerMax: '',
        sortField: 'seatCallRoundPer',
        sortType: false,
      },
      sortFieldName: '按通话回合数占比排序',
      dialogTitle: '部门结果',
      currentPageRate: 1,
      pageSizeRate: 20,
      tapeRateTotal: 0,
      currentPageRate2: 1, // 弹框里的
      detailPageSize: 10,
      tableData3Rate: [], // 弹框里的
      TotalRate1: 0, // 弹框里的
      valueRate4: '',
      optionRate4: [],
      deRateIdcurrent: '',
      isanalytic: true,
      tableDataRate: [], // 录音列表
      dialogTableVisible: false, //
      tableData1Rate: [], // 按部门
      tableData2Rate: [], // 按班组
      currentIndexRate: '1',
      optionRate: {
        calculable: true,
        tooltip: {},
        legend: {
          data: ['录音数'],
          textStyle: {
            color: '#737f8d',
          },
          x: 'center',
          y: 'bottom',
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        xAxis: [
          {
            data: [],
            splitLine: {
              show: true,
              //  改变轴线颜色
              lineStyle: {
                // 使用深浅的间隔色
                color: ['#ddd'],
              },
            },
            axisLine: {
              lineStyle: {
                color: '#737f8d',
              },
            },
            name: '坐席',
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '总量',
          },
        ],
        dataZoom: {
          start: 80,
          end: 100,
          show: true,
          realtime: false,
          y: 360,
          height: 20,
          filterMode: 'empty',
          handleSize: 20,
        },
        series: [
          {
            name: '录音数',
            type: 'bar',
            data: [],
            barWidth: 10,
            itemStyle: {
              normal: {
                color: '#50b4ff',
                label: {
                  show: true,
                  position: 'top',
                },
              },
            },
          },
        ],
      },
      option2Rate: {
        tooltip: {},
        legend: {
          data: ['录音数'],
          textStyle: {
            color: '#737f8d',
          },
          x: 'center',
          y: 'bottom',
        },
        xAxis: [
          {
            data: [],
            axisLine: {
              lineStyle: {
                color: '#737f8d',
              },
            },
            name: '班组',
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '时间',
          },
        ],
        dataZoom: {
          start: 80,
          end: 100,
          show: true,
          realtime: false,
          y: 360,
          height: 20,
          filterMode: 'empty',
          handleSize: 20,
        },
        series: [
          {
            name: '录音数',
            type: 'bar',
            data: [],
            barWidth: 10,
            itemStyle: {
              normal: {
                color: '#50b4ff',
                label: {
                  show: true,
                  position: 'top',
                },
              },
            },
          },
        ],
      },
    }
  },
  methods: {
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'integratedSearchHr'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    rateChange(val) {
      this.valueRate4 = val
    },
    rateExport() {
      let baseUrl = currentBaseUrl + '/speechFeature/export.do'
      let params = {
        callSTimeMin: this.gettimeform(this.formRate.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formRate.callSTimeMax),
        seatCallRoundPerMin: this.formRate.seatCallRoundPerMin,
        seatCallRoundPerMax: this.formRate.seatCallRoundPerMax,
        seatCallTimePerMin: this.formRate.seatCallTimePerMin,
        seatCallTimePerMax: this.formRate.seatCallTimePerMax,
        sortField: this.formRate.sortField,
        sortType: this.formRate.sortType,
      }
      commonUtil.doExport(baseUrl, params)
    },
    rateExport2() {
      let baseUrl = currentBaseUrl
      if (this.currentIndex == '1') {
        baseUrl += '/speechFeature/exporDeptStatsByCode.do'
      } else {
        baseUrl += '/speechFeature/exportSeatStatsByCode.do'
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formRate.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formRate.callSTimeMax),
        seatCallRoundPerMin: this.formRate.seatCallRoundPerMin,
        seatCallRoundPerMax: this.formRate.seatCallRoundPerMax,
        seatCallTimePerMin: this.formRate.seatCallTimePerMin,
        seatCallTimePerMax: this.formRate.seatCallTimePerMax,
        sortField: this.formRate.sortField,
        sortType: this.formRate.sortType,
      }
      commonUtil.doExport(baseUrl, params)
    },
    inquiryOverlay() {
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formRate.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formRate.callSTimeMax),
        seatCallRoundPerMin: this.formRate.seatCallRoundPerMin,
        seatCallRoundPerMax: this.formRate.seatCallRoundPerMax,
        seatCallTimePerMin: this.formRate.seatCallTimePerMin,
        seatCallTimePerMax: this.formRate.seatCallTimePerMax,
        sortField: this.formRate.sortField,
        pageNumber: this.currentPageRate,
        pageSize: this.pageSizeRate,
        sortType: this.formRate.sortType,
      }
      const self = this
      this.axios
        .post(
          currentBaseUrl + '/speechFeature/queryRecords.do',
          Qs.stringify(params),
          configss
        )
        .then(function(response) {
          if (response.status == 200 && response.data.state == 1) {
            self.tableDataRate = response.data.results
            self.tapeRateTotal = response.data.count
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    sortQuery() {
      this.formRate.sortType = !this.formRate.sortType
      this.inquiryOverlay()
    },
    toFixed(r, x, cellVal) {
      return (cellVal * 100).toFixed(2) + '%'
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let str = year + '-' + month + '-' + day
      return str
    },
    handleCurrentChangeRate(val) {
      this.currentPageRate = val
      this.inquiryOverlay()
    },
    handleSizeChangeRate(val) {
      this.pageSizeRate = val
      this.inquiryOverlay()
    },
    handleCurrentChangeRate2(val) {
      this.currentPageRate2 = val
      this.quiryOverlaylist()
    },

    handleDetailSizeChange: function(val) {
      this.detailPageSize = val
      this.currentPageRate2 = 1
      this.quiryOverlaylist()
    },
    showRateCanas() {
      this.isanalytic = false
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let params = {
        callSTimeMin: this.gettimeform(this.formRate.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formRate.callSTimeMax),
        seatCallRoundPerMin: this.formRate.seatCallRoundPerMin,
        seatCallRoundPerMax: this.formRate.seatCallRoundPerMax,
        seatCallTimePerMin: this.formRate.seatCallTimePerMin,
        seatCallTimePerMax: this.formRate.seatCallTimePerMax,
      }
      const self = this
      if (self.currentIndexRate == '2') {
        params.groupId = self.valueRate4
      }
      this.axios
        .post(currentBaseUrl + '/speechFeature/statis.do', Qs.stringify(params), configss)
        .then(function(response) {
          if (response.status == 200 && response.data.state == 1) {
            self.tableData1Rate = response.data.other.dept
            self.tableData2Rate = response.data.other.seat

            let options = null
            if (self.currentIndexRate == '1') {
              // 按部门
              self.option2Rate.series[0].data = []
              self.option2Rate.xAxis[0].data = []
              for (let key in self.tableData1Rate) {
                let str = ''
                str = key.replace('[', '').replace(']', '')
                self.option2Rate.xAxis[0].data.push(str.split(',')[1])
                self.option2Rate.series[0].data.push(self.tableData1Rate[key])
              }
              options = self.option2Rate
            } else if (self.currentIndexRate == '2') {
              // 按组织
              self.optionRate.series[0].data = []
              self.optionRate.xAxis[0].data = []
              for (let key in self.tableData2Rate) {
                // self.optionRate.xAxis[0].data.push(key)
                let arr = key
                  .replace('[', '')
                  .replace(']', '')
                  .split(',')
                self.optionRate.xAxis[0].data.push(arr[1])
                self.optionRate.series[0].data.push(self.tableData2Rate[key])
              }
              options = self.optionRate
            }
            if (window.innerHeight > 900) {
              document.getElementById('byDeptRate').style.width = 1420 + 'px'
              document.getElementById('byDeptRate').style.height = 400 + 'px'
            } else if (window.innerHeight > 768) {
              document.getElementById('byDeptRate').style.width = 1220 + 'px'
              document.getElementById('byDeptRate').style.height = 400 + 'px'
            } else {
              document.getElementById('byDeptRate').style.width = 1100 + 'px'
              document.getElementById('byDeptRate').style.height = 400 + 'px'
            }
            let mychart = self.$echarts.init(document.getElementById('byDeptRate'))
            mychart.clear()
            mychart.setOption(options)
            window.onresize = function() {
              if (window.innerHeight > 900) {
                document.getElementById('byDeptRate').style.width = 1600 + 'px'
                document.getElementById('byDeptRate').style.height = 400 + 'px'
              } else if (window.innerHeight > 768) {
                document.getElementById('byDeptRate').style.width = 1300 + 'px'
                document.getElementById('byDeptRate').style.height = 450 + 'px'
              } else {
                document.getElementById('byDeptRate').style.width = 1100 + 'px'
                document.getElementById('byDeptRate').style.height = 400 + 'px'
              }
              mychart.resize()
            }
            mychart.on('click', function(params) {
              let deptId
              if (self.currentIndexRate == '1') {
                for (let key in self.tableData1Rate) {
                  let str = []
                  str = key
                    .replace('[', '')
                    .replace(']', '')
                    .split(',')
                  if (params.name == str[1]) {
                    deptId = str[0]
                    break
                  }
                }
              } else if (self.currentIndexRate == '2') {
                for (let key in self.tableData2Rate) {
                  let str = []
                  str = key
                    .replace('[', '')
                    .replace(']', '')
                    .split(',')
                  if (params.name == str[1]) {
                    deptId = str[0]
                    break
                  }
                }
              }
              self.deRateIdcurrent = deptId
              self.currentPageRate2 = 1
              self.quiryOverlaylist(deptId)
            })
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    goBackList() {
      this.isanalytic = true
    },
    toggleCalling() {
      let currentIndex = $(event.target).attr('data-id')
      this.currentIndexRate = currentIndex
      $('.callingSpan').removeClass('callingSpanActive')
      $(event.target).addClass('callingSpanActive')
      this.showRateCanas()
    },
    quiryOverlaylist(deptId) {
      // 查询详细信息
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      const self = this
      let params = {
        callSTimeMin: this.gettimeform(this.formRate.callSTimeMin),
        callSTimeMax: this.gettimeform(this.formRate.callSTimeMax),
        seatCallRoundPerMin: this.formRate.seatCallRoundPerMin,
        seatCallRoundPerMax: this.formRate.seatCallRoundPerMax,
        seatCallTimePerMin: this.formRate.seatCallTimePerMin,
        seatCallTimePerMax: this.formRate.seatCallTimePerMax,
        sortField: this.formRate.sortField,
        pageNumber: this.currentPageRate2,
        pageSize: this.detailPageSize,
      }
      if (this.currentIndexRate == '1') {
        // deRateIdcurrent
        if (deptId) {
          params.deptId = deptId
        } else {
          params.deptId = this.deRateIdcurrent
        }
      } else if (this.currentIndexRate == '2') {
        if (deptId) {
          params.seatNo = deptId
        } else {
          params.seatNo = this.deRateIdcurrent
        }
      }

      this.axios
        .post(
          currentBaseUrl + '/speechFeature/queryRecords.do',
          Qs.stringify(params),
          configss
        )
        .then(function(res) {
          if (res.status == 200 && res.data.state == '1') {
            self.tableData3Rate = res.data.results
            self.TotalRate1 = res.data.count
            self.dialogTableVisible = true
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    check() {
      // 查看
      this.dialogTableVisible = true
    },
    deparmentSure() {
      this.dialogTableVisible = false
    },
    deparmentInquiry() {
      this.dialogTableVisible = false
    },
    callRateChange(val) {
      // 通话占比切换
      this.formRate.sortField = val
      if (val == 'seatCallRoundPer') {
        this.sortFieldName = '按通话回合数占比排序'
        this.formRate.seatCallTimePerMin = ''
        this.formRate.seatCallTimePerMax = ''
      }

      if (val == 'seatCallTimePer') {
        this.sortFieldName = '按通话时长占比排序'
        this.formRate.seatCallRoundPerMin = ''
        this.formRate.seatCallRoundPerMax = ''
      }
    },
    clearCallRate() {
      for (let key in this.formRate) {
        this.formRate[key] = ''
      }
      this.formRate['sortField'] = 'seatCallRoundPer'
      this.formRate['sortType'] = false
    },
    pickerOptions0() {},
    formatDate(row, column, cellValue) {
      return dateUtil.timeToString(cellValue)
    },
    loadSeatGroup() {
      let self = this
      this.axios
        .post(currentBaseUrl + '/pageConstant/getValue.do?keys=seatGroup')
        .then(function(response) {
          self.optionRate4 = response['data']['seatGroup']
        })
    },
  },
}
</script>
<style lang="less">
#callingRate {
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }

  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }

  .callingRate-header {
    width: 100%;
    height: 58px;
    line-height: 58px;
    border-bottom: 1px dashed #cfdbe7;
  }

  .callingRate-header span {
    padding: 0 10px;
  }

  .callingRate-header .el-input {
    width: 180px;
  }

  .callingRate-header .callingRate-content-header {
    height: 59px;
    line-height: 59px;
  }

  .callingRate-content .callingRate-content-header .el-button,
  .callingRate-content-work .callingRate-content-header .el-button {
    margin-top: 10px;
    margin-left: 20px;
    width: 86px;
  }

  .callingRate-content-work .callingRate-content-header span {
    box-sizing: border-box;
    display: inline-block;
  }

  .callingSpan {
    padding: 0 20px;
    height: 46px;
    line-height: 46px;
    font-size: 14px;
    border-bottom: 3px solid #d1dbe4;
    color: #d1dbe4;
  }

  .callingSpanActive {
    border-bottom: 3px solid #202d3d;
    color: #202d3d;
  }

  #tableDataRate .el-table__body-wrapper {
    overflow-x: hidden;
  }
}
</style>
