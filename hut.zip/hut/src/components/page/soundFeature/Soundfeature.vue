<template>
  <div id="soundfeature">
    <div class="soundfeature-pos">
      <div class="soundfeature-pos-nav">
        <ul>
          <li data-id="1" @click="toggleSound" class="soundfeatureActive">静默分析</li>
          <li data-id="2" @click="toggleSound">语速分析</li>
          <li data-id="3" @click="toggleSound">重叠分析</li>
          <li data-id="4" @click="toggleSound">通话占比</li>
        </ul>
      </div>
      <div class="soundfeature-pos-content">
        <vSlicent
          style="width:100%;height:100%; position: relative;"
          v-show="index == 1"
        ></vSlicent>
        <vSpeech style="width:100%;height:100%; position: relative;" v-show="index == 2">
        </vSpeech>
        <vOverlay
          style="width:100%;height:100%; position: relative;"
          v-show="index == 3"
        ></vOverlay>
        <vCallrate
          style="width:100%;height:100%; position: relative;"
          v-show="index == 4"
        ></vCallrate>
      </div>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import vOverlay from './Overlay.vue' // 重叠分析
import vSlicent from './Slicent.vue' // 静默分析
import vCallrate from './CallingRate.vue' // 通话占比
import vSpeech from './Speech.vue' // 语速分析
export default {
  components: {
    vOverlay,
    vSlicent,
    vCallrate,
    vSpeech,
  },
  data() {
    return {
      index: '1', // 默认显示页签
    }
  },
  methods: {
    toggleSound(event) {
      // 首页头部切换
      let currentIndex = $(event.target).attr('data-id')
      this.index = currentIndex
      $('.soundfeature-pos-nav ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
    },
  },
}
</script>
<style lang="less">
#soundfeature {
  box-sizing: border-box;
  height: 100%;
  width: 100%;
  .soundfeature-pos {
    width: 100%;
    height: 100%;
    position: relative;
  }
  .soundfeature-pos .soundfeature-pos-nav {
    width: 100%;
    height: 40px;
    line-height: 40px;
    background: #eef1f6;
    border-bottom: 1px solid #d1dbe4;
    position: absolute;
  }
  .soundfeature-pos-nav ul {
    width: 100%;
    box-sizing: border-box;
  }
  .soundfeature-pos-nav ul li {
    float: left;
    padding: 0 12.5px;
    box-sizing: border-box;
    font-size: 14px;
    color: #96a2b2;
    cursor: pointer;
  }
  .soundfeatureActive {
    color: #21a2ff !important;
  }
  .soundfeature-pos .soundfeature-pos-content {
    padding: 42px 10px 0;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}
</style>
