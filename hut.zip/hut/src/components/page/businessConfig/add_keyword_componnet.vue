<template>
  <el-dialog
    :title="title"
    :visible.sync="visible"
    :before-close="beforeClose"
  >
    <div style="padding: 30px 20px;overflow: hidden;">
      <div style="float: left;width: 30%; height:320px;border: 1px solid #d1dbe5">
        <el-tree
          :data="smallTreeData"
          :props="wordDefaultProps"
          ref="keyWordMenu"
          node-key="classId"
          @node-click="handleNodeClick"
          check-strictly
        >
        </el-tree>
      </div>
      <div style="float: right;width: 68%;height:320px;border: 1px solid #d1dbe5">
        <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">关键词描述</div>
        <el-input
          type="textarea"
          v-model="wordDescribe"
          :rows="10"
          style="width: 90%; margin: 10px 0px 0px 10px;"
        ></el-input>
      </div>
      <div slot="footer" style="float: right; margin-top: 10px">
        <el-button @click="cancelAdd">取 消</el-button>
        <el-button type="primary" @click="submit" :loading="loading">确 定</el-button>
      </div>
    </div>
  </el-dialog>
</template>
<script>
import global from '@/global.js'
import Qs from 'qs'
import throttle from 'lodash/throttle'
export default {
  methods: {
    getWordClass: throttle(
      function() {
        this.doGetWordClass()
      },
      1000,
      { trailing: false }
    ),
    // 获取关键词、水词分类
    doGetWordClass() {
      let _this = this
      let url = global.currentBaseUrl + '/vocabulary/getTrees.do'
      let params = {
        classId: 0,
        classType: 1,
      }
      _this.axios.post(url, Qs.stringify(params)).then(function(response) {
        console.log(response)
        _this.smallTreeData = response['data']
      })
    },
    beforeClose() {
      this.cancelAdd()
    },
    handleNodeClick(data) {
      this.currentNode = data
      this.classId = data.classId
    },
    cancelAdd() {
      this.$emit('cancel')
    },
    submit: throttle(
      function() {
        this.doSubmit()
      },
      1000,
      { trailing: false }
    ),
    doSubmit() {
      this.loading = true
      if (!this.currentNode) {
        this.$message({
          type: 'error',
          message: '添加关键词失败,分类不能为空',
        })
        this.loading = false
      } else {
        let params = {
          wordlibType: 1,
          wordName: this.words,
          keywordClass: 3,
          wordType: 1,
          wordDescribe: this.wordDescribe,
          classId: this.currentNode.classId,
        }
        let url = global.currentBaseUrl + '/vocabulary/addManyKeyword.do'
        this.axios
          .post(url, Qs.stringify(params))
          .then((response) => {
            if (response.data) {
              this.$message({
                type: 'success',
                message: '添加关键词成功',
              })
              this.$emit('success')
            } else {
              this.$message({
                type: 'error',
                message: '关键词已存在',
              })
            }
          })
          .catch((err) => {
            console.error(err)
          })
          .then(() => {
            this.loading = false
          })
      }
    },
  },
  watch: {
    visible(val) {
      if (val) {
        this.getWordClass()
      }
      if (this.cleanForm) {
        this.classId = ''
        this.wordDescribe = ''
      }
    },
  },
  data() {
    return {
      loading: false,
      currentNode: null,
      classId: '',
      wordDescribe: '',
      wordDefaultProps: {
        children: 'children',
        label: 'classTitle',
      },
      smallTreeData: [],
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: false,
    },
    title: {
      type: String,
      default: '添加关键词',
    },
    words: {
      type: String,
      required: true,
    },
    cleanForm: {
      type: Boolean,
      default: true,
    },
  },
}
</script>
<style lang="less" scoped></style>
