<template>
  <el-dialog
    :title="title"
    :visible.sync="visible"
    size="small"
    :before-close="beforeClose"
  >
    <div style="padding:20px 30px; overflow: hidden;">
      <div style="float: left;width: 30%; height:320px;border: 1px solid #d1dbe5">
        <el-tree
          :data="smallTreeData"
          :props="wordDefaultProps"
          ref="keyWordMenu"
          node-key="classId"
          @node-click="handleNodeClick"
          check-strictly
        >
        </el-tree>
      </div>
      <div style="float: right;width: 68%;height:320px;border: 1px solid #d1dbe5">
        <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">
          角色类型
          <el-select v-model="roleType" style="margin-left: 5px;margin-top: 1px;">
            <el-option label="全部" value="0"></el-option>
            <el-option label="客户" value="1"></el-option>
            <el-option label="客服" value="2"></el-option>
          </el-select>
        </div>
        <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">水词描述</div>
        <el-input
          type="textarea"
          v-model="wordDescribe"
          :rows="9"
          style="width: 90%; margin: 10px 0px 0px 10px;"
        ></el-input>
      </div>
      <div slot="footer" style="float: right; margin-top: 10px">
        <el-button @click="cancelAdd">取 消</el-button>
        <el-button type="primary" @click="submit">确 定</el-button>
      </div>
    </div>
  </el-dialog>
</template>
<script>
import global from '@/global.js'
import Qs from 'qs'
import throttle from 'lodash/throttle'
export default {
  methods: {
    getWordClass: throttle(
      function() {
        this.doGetWordClass()
      },
      1000,
      { trailing: false }
    ),
    // 获取关键词、水词分类
    doGetWordClass() {
      let _this = this
      let url = global.currentBaseUrl + '/vocabulary/getTrees.do'
      let params = {
        classId: 0,
        classType: 2,
      }
      _this.axios.post(url, Qs.stringify(params)).then(function(response) {
        console.log(response)
        _this.smallTreeData = response['data']
      })
    },
    beforeClose() {
      this.cancelAdd()
    },
    handleNodeClick(data) {
      this.currentNode = data
      this.classId = data.classId
    },
    cancelAdd() {
      this.$emit('cancel')
    },
    submit: throttle(
      function() {
        this.doSubmit()
      },
      1000,
      { trailing: false }
    ),
    doSubmit() {
      this.loading = true
      if (!this.currentNode) {
        this.$message({
          type: 'error',
          message: '添加水词失败,分类不能为空',
        })
        this.loading = false
      } else {
        let _this = this
        let params = {
          wordlibType: 2,
          wordName: this.words,
          keywordClass: 3,
          wordType: 1,
          wordDescribe: _this.wordDescribe,
          classId: _this.currentNode.classId,
          roleType: _this.roleType,
        }
        let url =
          global.currentBaseUrl +
          '/vocabulary/addManyKeyword.do?accessToken=' +
          this.$store.state.token
        _this.axios
          .post(url, Qs.stringify(params))
          .then(function(response) {
            if (response.data) {
              _this.$message({
                type: 'success',
                message: '添加水词成功',
              })
              _this.$emit('success')
            } else {
              _this.$message({
                type: 'error',
                message: '水词已存在',
              })
            }
          })
          .catch((err) => {
            console.error(err)
          })
          .then(() => {
            this.loading = false
          })
      }
    },
  },
  watch: {
    visible(val) {
      if (val) {
        this.getWordClass()
      }
      if (this.cleanForm) {
        this.classId = ''
        this.wordDescribe = ''
        if (this.defaultRoleType) {
          this.roleType = this.defaultRoleType
        }
      }
    },
  },
  data() {
    return {
      roleType: '',
      loading: false,
      currentNode: null,
      classId: '',
      wordDescribe: '',
      wordDefaultProps: {
        children: 'children',
        label: 'classTitle',
      },
      smallTreeData: [],
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: false,
    },
    title: {
      type: String,
      default: '添加水词',
    },
    words: {
      type: String,
      required: true,
    },
    cleanForm: {
      type: Boolean,
      default: true,
    },
    defaultRoleType: {
      type: String,
      required: false,
    },
  },
}
</script>
<style lang="less" scoped></style>
