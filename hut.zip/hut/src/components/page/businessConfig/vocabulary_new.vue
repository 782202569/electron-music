<template>
  <div class="vocabularyContainer" id="vocabulary_new">
    <el-tabs v-model="activeName" tab-position="left" @tab-click="changeTab">
      <el-tab-pane label="通用关键词词库" name="1" v-if="showWordlibType(1)">
        <div class="contentLeft">
          <div class="operation">
            <el-button
              icon="el-icon-plus"
              @click="addClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-edit"
              @click="editClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-close"
              @click="removeClassbtn"
            ></el-button>
          </div>
          <div class="treeMenu">
            <el-tree
              :data="treeMenu"
              :props="defaultProps"
              @node-click="handleNodeClick"
              ref="keyWordMenu"
              node-key="classId"
              check-strictly
            >
            </el-tree>
          </div>
        </div>
        <div class="contentRight contents">
          <div class="operation">
            <div class="buttons">
              <el-button
                @click="showAddWordDialog(0)"
                v-if="classId !== '0'"
                >添加</el-button
              >
              <el-button @click="batchDelete">批量删除</el-button>
              <el-button @click="copyDialogVisible = true"
                >复制到</el-button
              >
              <el-button @click="exportWord" v-if="classId !== '0'">导出</el-button>
            </div>
            <div class="searchForm" id="waterWordSearch">
              <el-form :inline="true">
                <el-form-item>
                  <el-input v-model="wordName" placeholder="请输入内容"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="searchKeyWords">查询</el-button>
                </el-form-item>
              </el-form>
            </div>
          </div>
          <div class="tableContent">
            <el-table
              ref="multipleTable"
              :data="keyWords"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="45"> </el-table-column>
              <el-table-column prop="wordName" label="名称" sortable width="200">
              </el-table-column>
              <el-table-column
                prop="updateTime"
                width="175"
                :formatter="createTimeFilter"
                sortable
                label="维护时间"
              >
              </el-table-column>
              <el-table-column prop="updateUserName" label="维护人" sortable width="150">
              </el-table-column>
              <el-table-column label="操作">
                <template scope="scope">
                  <el-button
                    @click="editWord(scope.row)"
                    type="text"
                    size="small"
                    icon="edit"
                    >编辑</el-button
                  >
                  <el-button
                    @click="deleteWord(scope.row)"
                    type="text"
                    size="small"
                    icon="close"
                    >删除</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="文本纠错关键词词库" name="7" v-if="showWordlibType(7)">
        <div class="contentLeft">
          <div class="operation">
<!--            <el-button-->
<!--              funcId="000367"-->
<!--              icon="el-icon-setting"-->
<!--              @click="editDistancebtn"-->
<!--            ></el-button>-->
            <el-button
              icon="el-icon-plus"
              @click="addClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-edit"
              @click="editClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-close"
              @click="removeClassbtn"
            ></el-button>
          </div>
          <div class="treeMenu">
            <el-tree
              :data="treeMenu"
              :props="defaultProps"
              @node-click="handleNodeClick"
              ref="keyWordMenu"
              node-key="classId"
              check-strictly
            >
            </el-tree>
          </div>
        </div>
        <div class="contentRight contents">
          <div class="operation">
            <div class="searchForm" id="waterWordSearch">
              <el-form :inline="true">
                <el-form-item>
                  <el-input v-model="wordName" placeholder="请输入内容"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="searchKeyWords">查询</el-button>
                </el-form-item>
              </el-form>
            </div>
            <div class="buttons">
              <el-button
                @click="showAddWordDialog(0)"
                v-if="classId !== '0'"
                >添加</el-button
              >
              <el-button @click="exportWord" v-if="classId !== '0'">导出</el-button>
              <el-button @click="batchDelete">批量删除</el-button>
              <el-button @click="copyDialogVisible = true"
                >复制到</el-button>
              <el-button @click="synchVocabulary" class="long-btn" :disabled="!keyWords.length">同步纠错算法词库</el-button>
            </div>
          </div>
          <div class="tableContent">
            <el-table
              ref="multipleTable"
              :data="keyWords"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="45"> </el-table-column>
              <el-table-column prop="wordName" label="名称" sortable width="200">
              </el-table-column>
              <el-table-column
                prop="updateTime"
                width="175"
                :formatter="createTimeFilter"
                sortable
                label="维护时间"
              >
              </el-table-column>
              <el-table-column prop="updateUserName" label="维护人" sortable width="150">
              </el-table-column>
              <el-table-column label="操作">
                <template scope="scope">
                  <el-button
                    @click="editWord(scope.row)"
                    type="text"
                    size="small"
                    icon="edit"
                    >编辑</el-button
                  >
                  <el-button
                    @click="deleteWord(scope.row)"
                    type="text"
                    size="small"
                    icon="close"
                    >删除</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="通用水词库" name="2" v-if="showWordlibType(2)">
        <div class="contentLeft">
          <div class="operation">
            <el-button
              icon="el-icon-plus"
              @click="addClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-edit"
              @click="editClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-close"
              @click="removeClassbtn"
            ></el-button>
          </div>
          <div class="treeMenu">
            <el-tree
              :data="treeMenu"
              :props="defaultProps"
              @node-click="handleNodeClick"
              ref="WaterWordMenu"
              node-key="classId"
              check-strictly
            >
            </el-tree>
          </div>
        </div>
        <div class="contentRight contents">
          <div class="operation">
            <div class="searchForm" id="waterWordSearch">
              <el-form :inline="true">
                <el-form-item>
                  <el-input v-model="wordName" placeholder="请输入内容"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="searchKeyWords">查询</el-button>
                </el-form-item>
              </el-form>
            </div>
            <div class="buttons">
              <el-button
                @click="showAddWordDialog(0)"
                v-if="classId !== '0'"
                >添加</el-button
              >
              <el-button @click="exportWord" v-if="classId !== '0'">导出</el-button>
              <el-button @click="batchDelete">批量删除</el-button>
              <el-button @click="copyDialogVisible = true"
                >复制到</el-button
              >
            </div>
          </div>
          <div class="tableContent">
            <el-table
              ref="multipleTable"
              :data="keyWords"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="45"> </el-table-column>
              <el-table-column prop="wordName" label="名称" sortable width="200">
              </el-table-column>
              <el-table-column
                prop="updateTime"
                width="175"
                sortable
                :formatter="createTimeFilter"
                label="维护时间"
              >
              </el-table-column>
              <el-table-column prop="updateUserName" sortable label="维护人" width="150">
              </el-table-column>
              <el-table-column label="操作">
                <template scope="scope">
                  <el-button
                    @click="editWaterWord(scope.row)"
                    type="text"
                    size="small"
                    icon="edit"
                    >编辑</el-button
                  >
                  <el-button
                    @click="deleteWord(scope.row)"
                    type="text"
                    size="small"
                    icon="close"
                    >删除</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="聚类水词库" name="5" v-if="showWordlibType(5)">
        <div class="contentLeft">
          <div class="operation">
            <el-button

              icon="el-icon-plus"
              @click="addClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-edit"
              @click="editClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-close"
              @click="removeClassbtn"
            ></el-button>
          </div>
          <div class="treeMenu">
            <el-tree
              :data="treeMenu"
              :props="defaultProps"
              @node-click="handleNodeClick"
              ref="WaterWordMenu"
              node-key="classId"
              check-strictly
            >
            </el-tree>
          </div>
        </div>
        <div class="contentRight contents">
          <div class="operation">
            <div class="searchForm" id="waterWordSearch">
              <el-form :inline="true">
                <el-form-item>
                  <el-input v-model="wordName" placeholder="请输入内容"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="searchKeyWords">查询</el-button>
                </el-form-item>
              </el-form>
            </div>
            <div class="buttons">
              <el-button
                @click="showAddWordDialog(0)"
                v-if="classId !== '0'"
                >添加</el-button
              >
              <el-button @click="exportWord" v-if="classId !== '0'">导出</el-button>
              <el-button @click="batchDelete">批量删除</el-button>
              <el-button @click="copyDialogVisible = true"
                >复制到</el-button
              >
            </div>
          </div>
          <div class="tableContent">
            <el-table
              ref="multipleTable"
              :data="keyWords"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="45"> </el-table-column>
              <el-table-column prop="wordName" label="名称" sortable width="200">
              </el-table-column>
              <el-table-column
                prop="updateTime"
                width="175"
                sortable
                :formatter="createTimeFilter"
                label="维护时间"
              >
              </el-table-column>
              <el-table-column prop="updateUserName" sortable label="维护人" width="150">
              </el-table-column>
              <el-table-column label="操作">
                <template scope="scope">
                  <el-button
                    @click="editWaterWord(scope.row)"
                    type="text"
                    size="small"
                    icon="edit"
                    >编辑</el-button
                  >
                  <el-button
                    @click="deleteWord(scope.row)"
                    type="text"
                    size="small"
                    icon="close"
                    >删除</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="相似词词库" name="4" v-if="showWordlibType(4)">
        <div class="contentLeft">
          <div class="operation">
            <el-button

              icon="el-icon-plus"
              @click="addClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-edit"
              @click="editClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-close"
              @click="removeClassbtn"
            ></el-button>
          </div>
          <div class="treeMenu">
            <el-tree
              :data="treeMenu"
              :props="defaultProps"
              @node-click="handleNodeClick"
              ref="SynonymMenu"
              node-key="classId"
              check-strictly
            >
            </el-tree>
          </div>
        </div>
        <div class="contentRight contents">
          <div class="operation">
            <div class="searchForm">
              <el-form :inline="true">
                <el-form-item>
                  <el-input v-model="wordName" placeholder="请输入内容"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="searchKeyWords">查询</el-button>
                </el-form-item>
              </el-form>
            </div>
            <div class="buttons">
              <el-button
                @click="showAddWordDialog(1)"
                v-if="classId !== '0'"
                >添加</el-button
              >
              <el-button @click="batchDelete">批量删除</el-button>
              <el-button @click="exportWord" v-if="classId !== '0'">导出</el-button>
            </div>
          </div>
          <div class="tableContent">
            <el-table
              ref="multipleTable"
              :data="keyWords"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="45"> </el-table-column>
              <el-table-column
                prop="wordName"
                label="名称"
                sortable
                show-overflow-tooltip
                width="140"
              >
              </el-table-column>
              <el-table-column
                prop="wordNames"
                label="相似词"
                sortable
                width="200"
                show-overflow-tooltip
              >
              </el-table-column>
              <el-table-column
                prop="updateTime"
                width="160"
                :formatter="createTimeFilter"
                sortable
                label="维护时间"
              >
              </el-table-column>
              <el-table-column prop="updateUserName" label="维护人" sortable>
              </el-table-column>
              <el-table-column label="操作">
                <template scope="scope">
                  <el-button
                    @click="editSynonym(scope.row)"
                    type="text"
                    size="small"
                    icon="edit"
                    >编辑</el-button
                  >
                  <el-button
                    @click="deleteWord(scope.row)"
                    type="text"
                    size="small"
                    icon="close"
                    >删除</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="敏感词词库" name="8" v-if="showWordlibType(8)">
        <div class="contentLeft">
          <div class="operation">
            <el-button
              icon="el-icon-plus"
              @click="addClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-edit"
              @click="editClassbtn"
            ></el-button>
            <el-button
              icon="el-icon-close"
              @click="removeClassbtn"
            ></el-button>
          </div>
          <div class="treeMenu">
            <el-tree
              :data="treeMenu"
              :props="defaultProps"
              @node-click="handleNodeClick"
              ref="WaterWordMenu"
              node-key="classId"
              check-strictly
            >
            </el-tree>
          </div>
        </div>
        <div class="contentRight contents">
          <div class="operation">
            <div class="searchForm" id="waterWordSearch">
              <el-form :inline="true">
                <el-form-item>
                  <el-input v-model="wordName" placeholder="请输入内容"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="searchKeyWords">查询</el-button>
                </el-form-item>
              </el-form>
            </div>
            <div class="buttons">
              <el-button
                @click="showAddWordDialog(0)"
                v-if="classId !== '0'"
                >添加</el-button
              >
              <el-button @click="exportWord" v-if="classId !== '0'">导出</el-button>
              <el-button @click="batchDelete">批量删除</el-button>
            </div>
          </div>
          <div class="tableContent">
            <el-table
              ref="multipleTable"
              :data="keyWords"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="45"> </el-table-column>
              <el-table-column prop="wordName" label="名称" sortable width="200">
              </el-table-column>
              <el-table-column
                prop="updateTime"
                width="175"
                sortable
                :formatter="createTimeFilter"
                label="维护时间"
              >
              </el-table-column>
              <el-table-column prop="updateUserName" sortable label="维护人" width="150">
              </el-table-column>
              <el-table-column label="操作">
                <template scope="scope">
                  <el-button
                    @click="editWord(scope.row)"
                    type="text"
                    size="small"
                    icon="edit"
                    >编辑</el-button
                  >
                  <el-button
                    @click="deleteWord(scope.row)"
                    type="text"
                    size="small"
                    icon="close"
                    >删除</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </el-tab-pane>
    </el-tabs>
    <!-- 编辑关键词弹出框 -->
    <el-dialog
      title="编辑关键词"
      :visible.sync="modifyDialogVisible"
      :close-on-click-modal="false"
      @closed="handleCloseKeyWordModify"
    >
      <el-form
        label-width="100px"
        :model="modifyKeyWordModel"
        ref="modifyKeyWordModel"
        :rules="addKeyWordRules"
      >
        <el-form-item label="关键词名称" prop="wordName">
          <el-input v-model="modifyKeyWordModel.wordName"></el-input>
        </el-form-item>
        <el-form-item class="btn">
          <el-button type="primary" @click="modifyKeyword">确定</el-button>
          <el-button @click="modifyDialogVisible = false">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <!-- 编辑水词弹出框 -->
    <el-dialog
      title="编辑水词"
      :close-on-click-modal="false"
      :visible.sync="modifyWaterWordDialogVisible"
      @close="handleCloseWordModify"
    >
      <el-form
        label-width="100px"
        :model="modifyWordModel"
        ref="modifyWordModel"
        :rules="addWordRules"
      >
        <el-form-item label="水词名称" prop="wordName">
          <el-input v-model="modifyWordModel.wordName"></el-input>
        </el-form-item>
        <el-form-item class="btn">
          <el-button type="primary" @click="modifyWord">确定</el-button>
          <el-button @click="modifyWaterWordDialogVisible = false">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 编辑相似词弹出框 -->
    <el-dialog
      title="编辑相似词"
      :close-on-click-modal="false"
      :visible.sync="modifySynonymDialogVisible"
      @close="handleCloseSynonymModify"
    >
      <el-form
        label-width="100px"
        :model="modifySynonymModel"
        ref="modifySynonymModel"
        :rules="addSynonymRules"
      >
        <el-form-item label="名称" prop="wordName">
          <el-input v-model="modifySynonymModel.wordName"></el-input>
        </el-form-item>
        <el-form-item label="相似词" prop="formWordDescribe">
          <el-row type="flex" justify="start" :gutter="10" style="margin-bottom: 20px;">
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[0]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[0]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[1]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[1]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row type="flex" justify="start" :gutter="10" style="margin-bottom: 20px;">
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[2]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[2]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[3]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[3]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row type="flex" justify="start" :gutter="10" style="margin-bottom: 20px;">
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[4]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[4]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[5]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[5]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row type="flex" justify="start" :gutter="10" style="margin-bottom: 20px;">
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[6]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[6]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[7]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[7]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row type="flex" justify="start" :gutter="10">
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[8]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[8]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item
                prop="wordDescribes[9]"
                :rules="[{ validator: synonymValidator, trigger: 'blur' }]"
              >
                <el-input
                  v-model="modifySynonymModel.wordDescribes[9]"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item class="btn">
          <el-button type="primary" @click="modifySynonym">确定</el-button>
          <el-button @click="handleCloseSynonymModify">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <!-- 添加分类弹出框 -->
    <el-dialog
      title="添加分类"
      @close="handleCloseAddClass"
      :close-on-click-modal="false"
      :visible.sync="addClassDialog"
    >
      <el-form
        label-width="100px"
        :model="AddClassModel"
        ref="AddClassModel"
        :rules="addClassRules"
      >
        <el-form-item label="上级分类标题" prop="parentclassTitle">
          <el-input v-model="AddClassModel.parentclassTitle" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="分类标题" prop="classTitle">
          <el-input
            v-model.trim="AddClassModel.classTitle"
            placeholder="请输入"
          ></el-input>
        </el-form-item>
        <!--<el-form-item label="备注" prop="remark">
          <el-input type="textarea" v-model="AddClassModel.remark"></el-input>
        </el-form-item>-->
        <el-form-item class="btn">
          <el-button type="primary" @click="addClass">确定</el-button>
          <el-button @click="handleCloseAddClass">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 编辑分类弹出框 -->
    <el-dialog
      title="编辑分类"
      @close="handleCloseModifyClass"
      :visible.sync="ModifyClassDialog"
      :close-on-click-modal="false"
    >
      <el-form
        label-width="100px"
        :model="ModifyClassModel"
        ref="ModifyClassModel"
        :rules="modifyClassRules"
      >
        <el-form-item label="原分类标题" prop="oldclassTitle">
          <el-input v-model="ModifyClassModel.oldclassTitle" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="新分类标题" prop="newclassTitle">
          <el-input
            v-model.trim="ModifyClassModel.newclassTitle"
            placeholder="请输入"
          ></el-input>
        </el-form-item>
        <el-form-item class="btn">
          <el-button type="primary" @click="modifyClass">确定</el-button>
          <el-button @click="handleCloseModifyClass">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>

    <!-- "复制到"弹框 -->
    <vocabulary-dialog-copy
      :visible.sync="copyDialogVisible"
      :tree-props="defaultProps"
      :items="checkedItems"
      :currentClassId="classId"
      :currentTabName="activeName"
      :wordArr="wordArr"
    />

    <!-- 添加关键词弹出框 -->
    <vocabulary-dialog-add
      :visible.sync="addWordDialogVisible"
      :mode="addKeyWordMode"
      :templateFileURL="templateFileURL"
      :importActionUrl="importActionUrl"
      :versionId="versionId"
      :industryId="industryId"
      :wordlibType="wordlibType"
      :currentClassId="classId"
    />

<!--    <vocabulary-dialog-setting :visible.sync="editDistanceVisible" />-->
  </div>
</template>
<script>
import qs from 'qs'
import moment from 'moment'
import global from '../../../global.js'
import cache from '../../../utils/cache.js'
import VocabularyDialogCopy from './vocabulary-dialog-copy'
import VocabularyDialogAdd from './vocabulary-dialog-add'
// import VocabularyDialogSetting from './vocabulary-dialog-setting'
import { constants } from 'fs';
import funcFilter from '@/utils/funcFilter.js'

let currentBaseUrl = global.qualityUrl // global.currentBaseUrl
let aiUrl = global.aiUrl
export default {
  components: { VocabularyDialogAdd, VocabularyDialogCopy },
  data() {
    let validatorNull = (rule, value, callback) => {
      if (this.$data.AddClassModel.classTitle != '') {
        let reg = /^\s*$/
        let result = reg.test(this.$data.AddClassModel.classTitle)
        if (result == true) {
          callback('请输入非空字符')
        } else {
          callback()
        }
      }
      callback()
    }
    let validatorModifyNull = (rule, value, callback) => {
      if (this.$data.ModifyClassModel.newclassTitle != '') {
        let reg = /^\s*$/
        let result = reg.test(this.$data.ModifyClassModel.newclassTitle)
        if (result == true) {
          callback('请输入非空字符')
        } else {
          callback()
        }
      }
      callback()
    }
    // 关键词校验器（可以用逗号分隔多个词）
    let keywordValidator = (rule, value, callback) => {
      const errors = []
      let word = typeof value === 'string' ? value.trim() : ''
      if (word) {
        if (/[^\s]+\s+[^\s]/g.test(word)) {
          errors.push('关键词名称中不能包含空格')
        } else if (word.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '_').length > 10) {
          errors.push('关键词名称不能超过10个字')
        }
        if (errors.length) {
          callback(errors)
        } else {
          this.modifyKeyWordModel.industryId = this.industryId
          this.modifyKeyWordModel.versionId = this.versionId
          this.axios
            .post(
              aiUrl + '/vocabulary/editKeyword.do',
              qs.stringify(this.modifyKeyWordModel),
              global.formHeader
            )
            .then((res) => {
              if (!res.data) {
                errors.push('该词已存在')
              }
              callback(errors)
            })
            .catch((err) => {
              console.log(err)
              callback(errors)
            })
        }
      } else {
        callback(errors)
      }
    }
    // 水词校验器（可以用逗号分隔多个词）
    let wordValidator = (rule, value, callback) => {
      const errors = []
      let word = typeof value === 'string' ? value.trim() : ''
      if (word) {
        if (/[^\s]+\s+[^\s]/g.test(word)) {
          errors.push('关键词名称中不能包含空格')
        } else if (word.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '_').length > 10) {
          errors.push('关键词名称不能超过10个字')
        }
        if (errors.length) {
          callback(errors)
        } else {
          this.modifyWordModel.industryId = this.industryId
          this.modifyWordModel.versionId = this.versionId
          this.modifyWordModel.wordlibType = '1'
          this.modifyWordModel.oldWordName = ''
          this.modifyWordModel.wordNames = this.modifyWordModel.wordName
          this.axios
            .post(
              aiUrl + '/vocabulary/checkMoreWords.do',
              qs.stringify(this.modifyWordModel),
              global.formHeader
            )
            .then((res) => {
              if (!res.data.flag) {
                errors.push('该词已存在')
              }
              callback(errors)
            })
            .catch((err) => {
              console.log(err)
              callback(errors)
            })
        }
      } else {
        callback(errors)
      }
    }
    // 相似词校验器（可以用逗号分隔多个词）
    let synonymwordValidator = (rule, value, callback) => {
      const errors = []
      if (value) {
        // 可以使用逗号分隔多个相似词
        let word = value.trim()
        if (/[^\s]+\s+[^\s]/g.test(word)) {
          errors.push('词名称中不能包含空格')
        } else if (word.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '_').length > 10) {
          errors.push('词名称不能超过10个字')
        }
        if (errors.length) {
          callback(errors)
        } else {
          this.checkAlike()
            .then((res) => {
              let { data } = res
              let fail = data.fail
              if (!data.flag && fail.some((item) => item == word)) {
                errors.push('该词已存在')
              }
              callback(errors)
            })
            .catch((err) => {
              console.log(err)
              callback(errors)
            })
        }
      } else {
        callback()
      }
    }
    return {
      // "复制到"弹框到可见状态
      copyDialogVisible: false,
      // 距离设置弹框可见状态
      settingsDialogVisible: false,
      activeName: '1', // 当前所在的tab页
      wordName: '',
      wordlibType: '1',
      versionId: '',
      companyId: '',
      industryId: '',
      keyWords: [],
      treeMenu: [],
      classId: '0',
      labelName: '通用关键词词库',
      addKeyWordMode: 'keyword',
      rootclassId: '0',
      classType: '1',
      defaultProps: {
        children: 'childIqc',
        label: 'classTitle',
      },
      currentPage: 1,
      total: 200,
      pageSize: 20,
      pageSizes: [10, 20, 30, 40],
      addDialogVisible: false,
      wordDescribe: '',
      checkedItems: [],
      KeyWordModel: {
        wordName: '',
        wordDescribe: '',
      },
      modifyDialogVisible: false,
      modifyKeyWordModel: {
        wordName: '',
      },
      addKeyWordRules: {
        wordName: [
          { required: true, message: '请输入关键词名称', trigger: 'blur' },
          { validator: keywordValidator, trigger: 'blur' },
        ],
      },
      addWordRules: {
        wordName: [
          { required: true, message: '请输入水词名称', trigger: 'blur' },
          { validator: wordValidator, trigger: 'blur' },
        ],
      },
      addSynonymRules: {
        wordName: [
          { required: true, message: '请输入词名称', trigger: 'blur' },
          { validator: synonymwordValidator, trigger: 'blur' },
        ],
        formWordDescribe: [{ validator: keywordValidator, trigger: 'blur' }],
      },
      addWordDialogVisible: false,
      modifyWaterWordDialogVisible: false,
      modifyWordModel: {
        wordName: '',
      },
      modifySynonymDialogVisible: false,
      modifySynonymModel: {
        wordName: '',
        wordDescribes: [],
        formWordDescribe: '',
      },
      addClassDialog: false,
      AddClassModel: {
        classTitle: '',
        //remark: '',
        parentclassTitle: '',
        parentClassId: '',
        classType: '',
      },
      ModifyClassModel: {
        oldclassTitle: '',
        newclassTitle: '',
      },
      ModifyClassDialog: false,
      templateFileURL: '',
      importActionUrl: '',
      // importKeywordExcelUrl: baseUrl + '/zuul/analyticSystem/vocabulary/importKeywordExcel.do?accessToken=' + cache.getItem('tgt_id') + '&prefer-service-zone=locallyq',
      // importWaterWordExcelUrl: baseUrl + '/zuul/analyticSystem/vocabulary/importWaterWordExcel.do?accessToken=' + cache.getItem('tgt_id') + '&prefer-service-zone=locallyq',
      editDistanceVisible: false,
      currentNode: '',
      addClassRules: {
        classTitle: [
          { required: true, message: '请输入分类标题', trigger: 'blur' },
          { max: 10, message: '分类标题不能超过10个汉字', trigger: 'blur' },
          { validator: validatorNull, trigger: 'blur' },
        ],
      },
      modifyClassRules: {
        newclassTitle: [
          { required: true, message: '请输入分类标题', trigger: 'blur' },
          { max: 10, message: '分类标题不能超过10个汉字', trigger: 'blur' },
          { validator: validatorModifyNull, trigger: 'blur' },
        ],
      },
      roleTypes: [
        {
          label: '全部',
          value: '0',
        },
        {
          label: '客户',
          value: '1',
        },
        {
          label: '坐席',
          value: '2',
        },
      ],
      wordArr: [],
    }
  },
  beforeCreate() {
    this.axios
      .get(currentBaseUrl + '/vocabulary/getWordLibTypes')
      .then((res) => {
        if (res.data) {
          this.wordArr = res.data
          this.activeName = '' + this.wordArr[0]
        }
      })
      .catch((err) => {
        console.log(err)
      })
  },
  created() {
    this.getKeyWords()
    this.getTreeMenu()
  },
  watch: {
    wordlibType() {
      this.getKeyWords()
      this.currentNode = ''
    },
    pageSize() {
      this.getKeyWords()
    },
    currentPage() {
      this.getKeyWords()
    },
    addWordDialogVisible() {
      this.getKeyWords()
    },
  },
  methods: {
    showWordlibType(id) {
      return this.wordArr.indexOf(id) != -1
    },
    // 编辑相似词校验器（可以用逗号分隔多个词）
    synonymValidator(rule, value, callback) {
      const errors = []
      let word = typeof value === 'string' ? value.trim() : ''
      const sameArr = this.hasSameWord(this.modifySynonymModel.wordDescribes)
      if (word) {
        if (/[^\s]+\s+[^\s]/g.test(word)) {
          errors.push('相似词中不能包含空格')
        } else if (word.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '_').length > 10) {
          errors.push('单个相似词不能超过10个字')
        } else if (sameArr && sameArr.some((item) => item == word)) {
          errors.push('该词已经存在')
        }
        if (errors.length) {
          callback(errors)
        } else {
          this.checkAlike()
            .then((res) => {
              let { data } = res
              let fail = data.fail
              if (!data.flag && fail.some((item) => item == word)) {
                errors.push('该词已存在')
              }
              callback(errors)
            })
            .catch((err) => {
              console.log(err)
              callback(errors)
            })
        }
      } else {
        callback(errors)
      }
    },
    checkAlike() {
      this.modifySynonymModel.wordDescribe = ''
      this.modifySynonymModel.wordNames = ''
      this.modifySynonymModel.wordDescribes.forEach((item) => {
        if (item !== '') {
          this.modifySynonymModel.wordNames += item + ','
        }
      })
      this.modifySynonymModel.wordNames = this.modifySynonymModel.wordNames.substring(
        0,
        this.modifySynonymModel.wordNames.length - 1
      )
      let params = {}
      let { wordId, wordNames, classId, wordlibType, wordName } = this.modifySynonymModel
      wordlibType === '4' ? (wordlibType = '5') : '1'
      params.wordId = wordId
      params.wordNames = wordNames
      params.classId = classId
      params.wordlibType = wordlibType
      params.wordName = wordName
      params.industryId = this.industryId
      params.versionId = this.versionId
      params.companyId = this.companyId
      return this.axios.post(
        aiUrl + '/vocabulary/checkEditAlikeWords',
        qs.stringify(params),
        global.formHeader
      )
    },
    changeTab(tab, event) {
      this.wordlibType = tab.name
      this.activeName = tab.name
      this.classId = '0'
      this.currentPage = 1
      this.classType = tab.name
      this.getTreeMenu()
      this.wordName = ''
      this.checkedItems = []
      this.currentNode = null
      this.labelName = tab.label
    },
    searchKeyWords() {
      this.getKeyWords()
    },
    handleSelectionChange(val) {
      this.checkedItems = val
    },
    handleNodeClick(data) {
      this.currentNode = data
      this.classId = data.classId
      this.getKeyWords()
    },
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    editWord(row) {
      this.modifyDialogVisible = true
      this.modifyKeyWordModel.wordName = row.wordName
      this.modifyKeyWordModel.oldWordName = row.wordName
      this.modifyKeyWordModel.wordId = row.wordId
      this.modifyKeyWordModel.classId = row.classId
    },
    handleCloseKeyWordModify() {
      this.modifyDialogVisible = false
      this.$refs.modifyKeyWordModel.resetFields()
    },
    createTimeFilter(row, column, cellValue) {
      return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
    },
    deleteWord(word) {
      let id = word.wordId
      let name = word.wordName
      let names
      if (word.wordNames) {
        names = word.wordName + word.wordNames
      }
      let type = ''
      if (this.wordlibType == '1') {
        type = '关键词'
      } else if (this.wordlibType == '2') {
        type = '停词水词'
      } else {
        type = '同义词'
      }
      this.$confirm('确定要删除' + type + '[' + name + ']吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          if (word.wordNames) {
            this.deleteWordsByIds(id, names, this.wordlibType)
          } else {
            this.deleteWordsByIds(id, name, this.wordlibType)
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 批量删除提示
    batchDelete() {
      if (this.checkedItems.length < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择要删除的记录',
        })
        return false
      }
      let words = []
      let ids = []
      let wordNames = []
      for (let i = 0; i < this.checkedItems.length; i++) {
        words.push(this.checkedItems[i].wordName)
        if (this.checkedItems[i].wordNames) {
          wordNames.push(this.checkedItems[i].wordName, this.checkedItems[i].wordNames)
        }
      }
      for (let i = 0; i < this.checkedItems.length; i++) {
        ids.push(this.checkedItems[i].wordId)
      }
      let type = ''
      if (this.wordlibType == '1') {
        type = '关键词'
      } else if (this.wordlibType == '2') {
        type = '停词水词'
      } else {
        type = '同义词'
      }
      this.$confirm(
        '确定要删除' +
          type +
          '[' +
          words.join(',') +
          ']等' +
          this.checkedItems.length +
          '个词语?',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      )
        .then(() => {
          if (this.checkedItems[0].wordNames) {
            this.deleteWordsByIds(ids.join(','), wordNames.join(','), this.wordlibType)
          } else {
            this.deleteWordsByIds(ids.join(','), words.join(','), this.wordlibType)
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 批量删除方法
    deleteWordsByIds(ids, names, wordlibType) {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/vocabulary/removeManyKeywords.do',
          qs.stringify({
            ids: ids,
            names: names,
            wordlibType: wordlibType,
          })
        )
        .then(function(response) {
          _this.$message({
            type: 'success',
            message: '删除成功!',
          })
          _this.currentPage = 1
          _this.getKeyWords()
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '删除出现问题',
          })
        })
    },
    handleClose() {
      this.addDialogVisible = false
      this.$refs.KeyWordModel.resetFields()
    },
    // 得到分类
    getTreeMenu() {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/vocabulary/getTrees.do',
          qs.stringify({
            classId: this.rootclassId,
            classType: this.classType,
          })
        )
        .then(function(response) {
          let data = response.data
          if (data) {
            _this.treeMenu = data
            _this.versionId = data[0].versionId
            _this.industryId = data[0].industryId
          }
          _this.filterButton() // 过滤权限按钮
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 得到关键词表格
    getKeyWords() {
      let _this = this
      let params = {}
      params.wordlibType = this.wordlibType
      params.pageSize = this.pageSize
      params.currentPage = this.currentPage
      params.wordName = this.wordName
      params.classId = this.classId
      params.begin = 1
      params.end = 1
      this.axios
        .post(currentBaseUrl + '/vocabulary/queryPage.do', qs.stringify(params))
        .then(function(res) {
          if (res.data.Data.length) {
            _this.companyId = res.data.companyId
          }
          _this.total = res.data.Count
          _this.keyWords = res.data.Data
          _this.filterButton() // 过滤权限按钮
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    // 显示添加关键词对话框
    showAddDialog() {
      this.addDialogVisible = true
      // this.$nextTick(function () {
      //   this.$refs.KeyWordModel.resetFields()
      // })
    },
    /*addKeyWordThrottle() {
      this.lodashThrottle.throttle(this.addKeyword, this)
    },*/
    // 添加关键词方法
    addKeyword() {
      this.$refs.KeyWordModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let _this = this
          this.KeyWordModel.wordId = ''
          this.KeyWordModel.wordlibType = this.wordlibType
          this.KeyWordModel.wordType = ''
          this.KeyWordModel.classId = this.classId
          // 检查是否已存在
          this.axios
            .post(
              currentBaseUrl + '/vocabulary/checkKeyWordisExist.do',
              qs.stringify(this.KeyWordModel)
            )
            .then(function(response) {
              if (response.data == true) {
                return Promise.reject(response)
              } else {
                return Promise.resolve(response)
              }
            })
            .then(function(response) {
              _this.axios
                .post(
                  currentBaseUrl + '/vocabulary/addNewKeyword.do',
                  qs.stringify(_this.KeyWordModel)
                )
                .then(function(response) {
                  _this.$message({
                    type: 'success',
                    message: '新增关键词成功!',
                  })
                  _this.addDialogVisible = false
                  _this.currentPage = 1
                  _this.getKeyWords()
                  this.$refs.KeyWordModel.resetFields()
                })
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '关键词已存在',
              })
            })
        }
      })
    },
   /* modifyKeyWordThrottle() {
      this.lodashThrottle.throttle(this.modifyKeyword, this)
    },*/
    // 修改关键词
    modifyKeyword() {
      this.$refs.modifyKeyWordModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let _this = this
          this.modifyKeyWordModel.wordlibType = this.wordlibType
          this.axios
            .post(
              currentBaseUrl + '/vocabulary/editKeyword.do',
              qs.stringify(this.modifyKeyWordModel)
            )
            .then(function(response) {
              if (response.data.flag) {
                _this.$message({
                  type: 'success',
                  message: '编辑关键词成功!',
                })
                _this.modifyDialogVisible = false
                _this.getKeyWords()
              } else {
                _this.$message({
                  type: 'warning',
                  message: '编辑关键词失败!',
                })
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '编辑关键词异常！',
              })
              _this.modifyDialogVisible = false
              _this.getKeyWords()
            })
        }
      })
    },
    // 显示添加对话框
    showAddWordDialog(mode) {
      if (mode === 1) {
        this.addKeyWordMode = 'similar'
        this.importActionUrl =
          currentBaseUrl +
          '/vocabulary/importSynonymWordsExcel.do?accessToken=' +
          cache.getItem('tgt_id')
          // + '&prefer-service-zone=localjc'
      } else {
        this.addKeyWordMode = 'keyword'
        this.importActionUrl =
          currentBaseUrl +
          '/vocabulary/excelImportWords.do?accessToken=' +
          cache.getItem('tgt_id')
          // + '&prefer-service-zone=localjc'
      }
      if (this.wordlibType === '4') {
        // 相似词
        this.templateFileURL =
          currentBaseUrl + '/excel/alikeWord.xlsx?accessToken=' + cache.getItem('tgt_id')
      } else if (this.wordlibType === '1' || this.wordlibType === '8') {
        // 普通词下载模版
        this.templateFileURL =
          currentBaseUrl + '/excel/importModel.xlsx?accessToken=' + cache.getItem('tgt_id')
      } else if (this.wordlibType === '7') {
        // 普通词下载模版
        this.templateFileURL =
          currentBaseUrl + '/excel/importCorrection.xlsx?accessToken=' + cache.getItem('tgt_id')
      } else {
        this.templateFileURL =
          currentBaseUrl + '/excel/importWaterword.xlsx?accessToken=' + cache.getItem('tgt_id')
      }
      this.addWordDialogVisible = true
    },
    // 导出关键词、停词水词、同义词
    exportWord() {
      if (this.checkedItems.length < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择要导出的记录',
        })
        return false
      }
      let ids = []
      this.checkedItems.forEach(function(item) {
        ids.push(item.wordId)
      })
      let params = {}
      // if (this.wordlibType == 4) {
      //   this.wordlibType = '5'
      // }
      params.classId = this.classId
      params.wordIds = ids.join(',')
      params.wordlibType = this.wordlibType
      params.industryId = this.industryId || ''
      params.companyId = this.companyId
      params.versionId = this.versionId
      params.CASTGC = localStorage.getItem('tgt_id')
      let form = document.createElement('form')
      form.method = 'post'
      form.target = '_blank'
      for (let key in params) {
        let input = document.createElement('input')
        input.name = key
        input.value = params[key]
        form.appendChild(input)
      }
      console.log(form)
      // if (this.wordlibType === '5') {
      //   form.action =
      //     aiUrl + '/vocabulary/exportAlikeWords.do?accessToken=' + cache.getItem('tgt_id') +
      //     '&prefer-service-zone=localjc'
      // } else {
      //   form.action =
      //     aiUrl + '/vocabulary/exportKeywords.do?accessToken=' + cache.getItem('tgt_id') +
      //     '&prefer-service-zone=localjc'
      // }
      if (this.wordlibType == '1' || this.wordlibType == '7' || this.wordlibType == '8') {
        form.action =
          currentBaseUrl +
          '/vocabulary/exportKeywords.do?accessToken=' +
          cache.getItem('tgt_id')
      } else if (this.wordlibType == '2' || this.wordlibType == '5') {
        form.action =
          currentBaseUrl +
          '/vocabulary/exportWaterwords.do?accessToken=' +
          cache.getItem('tgt_id')
      } else if (this.wordlibType == '4') {
        form.action =
          currentBaseUrl +
          '/vocabulary/exportAlikeWords.do?accessToken=' +
          cache.getItem('tgt_id')
      }
      document.querySelector('body').appendChild(form)
      form.submit()
      document.querySelector('body').removeChild(form)
    },
    editWaterWord(row) {
      this.modifyWaterWordDialogVisible = true
      this.modifyWordModel.wordName = row.wordName
      this.modifyWordModel.oldWordName = row.wordName
      this.modifyWordModel.wordId = row.wordId
      this.modifyWordModel.classId = row.classId
    },
    handleCloseWordModify() {
      this.modifyWaterWordDialogVisible = false
      this.$refs.modifyWordModel.resetFields()
    },
    /*modifyWordThrottle() {
      this.lodashThrottle.throttle(this.modifyWord, this)
    },*/
    // 编辑水词方法
    modifyWord() {
      this.$refs.modifyWordModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let _this = this
          this.modifyWordModel.wordlibType = this.wordlibType
          this.axios
            .post(
              currentBaseUrl + '/vocabulary/editKeyword.do',
              qs.stringify(this.modifyWordModel)
            )
            .then(function(response) {
              if (response.data.flag) {
                _this.$message({
                  type: 'success',
                  message: '编辑水词成功!',
                })
                _this.modifyWaterWordDialogVisible = false
                _this.getKeyWords()
              } else {
                _this.$message({
                  type: 'warning',
                  message: '编辑水词失败!',
                })
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '编辑水词异常！',
              })
              _this.modifyWaterWordDialogVisible = false
              _this.getKeyWords()
            })
        }
      })
    },
    // 点击编辑同义词按钮
    editSynonym(row) {
      this.modifySynonymDialogVisible = true
      this.modifySynonymModel.wordName = row.wordName
      this.modifySynonymModel.oldWordName = row.wordName
      this.modifySynonymModel.wordDescribes = row.wordNames
        .replace(/\，/g, ',')
        .split(',')
      this.modifySynonymModel.oldWordDescribes = row.wordNames
        .replace(/\，/g, ',')
        .split(',')
      this.modifySynonymModel.wordId = row.wordId
      this.modifySynonymModel.classId = row.classId
    },
    handleCloseSynonymModify() {
      this.$nextTick(() => {
        this.$refs['modifySynonymModel'].clearValidate()
      })
      this.modifySynonymDialogVisible = false
    },
    modifySynonym() {
      this.$refs.modifySynonymModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          let _this = this
          this.modifySynonymModel.wordlibType = this.wordlibType
          _this.modifySynonymModel.wordNames = ''
          _this.modifySynonymModel.oldWordNames = ''
          this.modifySynonymModel.wordDescribes.forEach(function(item, index) {
            if (item != '') {
              _this.modifySynonymModel.wordNames += item + ','
            }
          })
          this.modifySynonymModel.wordNames = this.modifySynonymModel.wordNames.substring(
            0,
            this.modifySynonymModel.wordNames.length - 1
          )
          this.modifySynonymModel.oldWordNames = this.modifySynonymModel.oldWordDescribes.join(
            ','
          )
          let params = {}
          params.wordId = this.modifySynonymModel.wordId
          params.wordName = this.modifySynonymModel.wordName
          params.oldWordName = this.modifySynonymModel.oldWordName
          params.wordNames = this.modifySynonymModel.wordNames
          params.oldWordNames = this.modifySynonymModel.oldWordNames
          params.classId = this.modifySynonymModel.classId
          params.wordlibType = this.modifySynonymModel.wordlibType
          params.wordId = this.modifySynonymModel.wordId
          this.axios
            .post(currentBaseUrl + '/vocabulary/editAlikeWord.do', qs.stringify(params))
            .then(function(response) {
              if (response.data) {
                _this.$message({
                  type: 'success',
                  message: '编辑相似词成功!',
                })
                _this.modifySynonymDialogVisible = false
                _this.getKeyWords()
              } else {
                _this.$message({
                  type: 'warning',
                  message: '编辑相似词失败，相似词重复!',
                })
              }
            })
            .catch(function() {
              _this.$message({
                type: 'error',
                message: '编辑相似词出现问题',
              })
            })
        }
      })
    },
    addClassbtn() {
      // let _this = this
      this.addClassDialog = true
      let current = this.currentNode
      this.AddClassModel.classTitle = ''
      //this.AddClassModel.remark = ''
      this.AddClassModel.parentclassTitle = current != null ? current.classTitle : ''
      this.AddClassModel.parentClassId = current ? current.classId : '0'
      this.AddClassModel.classId = ''
      this.AddClassModel.classType = this.classType
    },
    addClass() {
      let _this = this
      _this.$refs.AddClassModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          _this.axios
            .post(
              currentBaseUrl + '/vocabulary/saveClass.do',
              qs.stringify(this.AddClassModel)
            )
            .then(function(response) {
              if (response.data.flag) {
                _this.$message({
                  type: 'success',
                  message: '新类添加成功!',
                })
                _this.addClassDialog = false
                _this.getTreeMenu()
                _this.$refs.AddClassModel.resetFields()
              } else {
                _this.$message({
                  type: 'error',
                  message: '该分类已存在',
                })
              }
            })
            .catch(function() {
              _this.$message({
                type: 'error',
                message: '新类添加失败！',
              })
              _this.$refs.AddClassModel.resetFields()
            })
        }
      })
    },
    // 关闭分类
    handleCloseAddClass() {
      this.addClassDialog = false
      this.$refs.AddClassModel.resetFields()
    },
    // 删除分类按钮
    removeClassbtn() {
      let current = this.currentNode
      let msg = ''
      if (this.wordlibType == 1) {
        msg = '关键词'
      } else if (this.wordlibType == 2) {
        msg = '停词水词'
      } else {
        msg = '同义词'
      }
      if (!current) {
        this.$message({
          message: '请先选择一个分类',
          type: 'warning',
        })
        return false
      }
      this.$confirm(
        '删除分类会将分类下的' + msg + '同时删除，确定要删除选中的分类吗?',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      )
        .then(() => {
          this.removeClass(current.classId)
          this.currentNode = ''
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 删除分类
    removeClass(id) {
      let _this = this
      this.axios
        .post(
          currentBaseUrl + '/vocabulary/deleteClass.do',
          qs.stringify({
            classId: id,
          })
        )
        .then(function(response) {
          _this.$message({
            type: 'success',
            message: '删除成功!',
          })
          _this.classId = null
          _this.getKeyWords()
          _this.classId = '0'
          _this.getTreeMenu()
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '删除出现问题',
          })
        })
    },
    // 编辑分类按钮
    editClassbtn() {
      let current = this.currentNode
      if (!current) {
        this.$message({
          message: '请先选择一个分类',
          type: 'warning',
        })
        return false
      }
      this.ModifyClassDialog = true
      this.$nextTick(function() {
        this.$refs.ModifyClassModel.resetFields()
        this.ModifyClassModel.oldclassTitle = current.classTitle
        this.ModifyClassModel.classId = current.classId
        this.ModifyClassModel.classType = this.classType
        this.ModifyClassModel.parentClassId = current.parentClassId
          ? current.parentClassId
          : '0'
      })
    },
    // 关闭修改分类
    handleCloseModifyClass() {
      this.ModifyClassDialog = false
      this.$refs.ModifyClassModel.resetFields()
    },
    modifyClass() {
      let _this = this
      this.$refs.ModifyClassModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          _this.ModifyClassModel.classTitle = _this.ModifyClassModel.newclassTitle
          this.axios
            .post(
              currentBaseUrl + '/vocabulary/saveClass.do',
              qs.stringify(_this.ModifyClassModel)
            )
            .then(function(response) {
              if (response.data.flag) {
                _this.$message({
                  type: 'success',
                  message: '类别编辑成功!',
                })
                _this.$refs.ModifyClassModel.resetFields()
                _this.currentNode = null
                _this.ModifyClassDialog = false
                _this.getTreeMenu()
              } else {
                _this.$message({
                  type: 'error',
                  message: '类别编辑名称已存在,请重新输入！',
                })
              }
            })
            .catch(function() {
              _this.$message({
                type: 'error',
                message: '类别编辑异常！',
              })
              _this.ModifyClassDialog = false
              _this.$refs.ModifyClassModel.resetFields()
            })
        }
      })
    },
    editDistancebtn() {
      let _this = this
      _this.editDistanceVisible = true
    },
    // 过滤重复相似词
    hasSameWord(words) {
      let pass = false
      let sameArr = []
      let keyword = words.filter((d) => d)
      let len = keyword.length
      if (len < 2) {
        return pass
      }
      let set = new Set(keyword)
      if (len !== set.size) {
        for (var i = 0; i < words.length; i++) {
          for (var j = 0; j < words.length; j++) {
            if (words[i] === words[j] && i !== j) {
              sameArr.push(words[i])
            }
          }
        }
      }
      sameArr = [...new Set(sameArr)]
      return sameArr
    },
    //同步纠错算法的词库数据
    synchVocabulary() {
      let _this = this
      this.axios
          .post(
            currentBaseUrl + '/vocabulary/syncKeyWord.do'
          )
          .then(function(response) {
            if (response.data.code == 0){
              _this.$message({
                type: 'success',
                message: '同步算法纠错词成功!',
              })
            } else {
              _this.$message({
                type: 'error',
                message: response.data.msg,
              })
            }
          })
          .catch(function() {
          })
    },

      /*
    * 过滤权限按钮
    * */
    filterButton() {
        /*
       获取数据后dom节点更改了，
        需要再获取一遍dom节点对[funcID]按钮进行过滤
       * */
        let menuId = localStorage.getItem('menuId')
        let path = this.$route.path.replace('/', '')
        funcFilter(menuId, path)
    }
  },
}
</script>
<style lang="less">
@border-color: #d1dbe5;
// 修改组件样式
.vocabularyContainer {
  height: 100%;
  position: relative;
  box-sizing: border-box;
  div {
    box-sizing: border-box;
  }
  .el-tabs {
    height: 100%;
    .el-tabs__header {
      margin: 0px;
      .el-tabs__item.is-top:nth-child(2) {
        padding-left: 20px;
      }
    }
    .el-tabs__content {
      height: 100%;
      .el-tab-pane {
        height: 100%;
      }
    }
  }
  .operation .el-form-item {
    margin-bottom: 0px;
    .el-form-item__content {
      line-height: 55px;
    }
  }
  .el-tabs__header {
    background-color: #eef1f6;
  }
  .el-tabs__active-bar {
    display: none;
  }
  .el-tree {
    border: none;
  }
  .el-pagination {
    text-align: right;
  }
  .el-select {
    width: 100%;
  }
}

// 页面样式
.vocabularyContainer {
  .operation {
    height: 55px;
    line-height: 55px;
    border-bottom: 1px dashed @border-color;
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
  }
  .contentLeft {
    width: 230px;
    height: 100%;
    float: left;
    position: relative;
    .operation {
      text-align: right;
      padding-right: 10px;
      button {
        opacity: 0.7;
        width: 25px;
        height: 25px;
        padding: 0px;
      }
    }
    .treeMenu {
      position: absolute;
      left: 0;
      right: 0;
      top: 60px;
      bottom: 0;
      overflow-y: auto;
      z-index: 0;
    }
  }
  .contentRight {
    position: relative;
    height: 100%;
    margin-left: 230px;
    border-left: 1px solid @border-color;
    .operation > div {
      display: inline-block;
      text-align: right;
      button {
        width: 90px;
        &.long-btn{
          width: 150px;
        }
      }
      &.searchForm {
        position: absolute;
        right: 10px;
      }
      &.buttons {
        position: absolute;
        left: 10px;
      }
    }
    .tableContent {
      padding: 10px;
      overflow-y: auto;
      position: absolute;
      top: 60px;
      left: 0;
      right: 0;
      bottom: 35px;
    }
    .el-pagination {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
    }
  }
  .import_btn {
    text-align: right;
    margin-top: 10px;
  }
  .is-current > .el-tree-node__content {
    background: #eef1f6;
  }
  .btn {
    text-align: right;
  }
}
</style>
