<template>
  <el-dialog
    title="添加"
    :visible.sync="dialogVisible"
    :close-on-click-modal="false"
    @closed="reset"
    width="600px"
  >
    <el-form label-position="right" label-width="120px" :model="keywordData" ref="$form">
      <el-form-item label="添加形式">
        <el-radio-group v-model="type">
          <el-radio label="input">输入添加</el-radio>
          <el-radio label="import">批量导入</el-radio>
        </el-radio-group>
      </el-form-item>

      <template v-if="mode == 'keyword'">
        <el-form-item
          v-if="type === 'input'"
          label="关键词名称"
          prop="wordName"
          :rules="[
            { required: true, message: '请输入关键词名称' },
            { validator: keywordValidator, model: keywordData, prop: 'wordName' },
          ]"
        >
          <el-input
            type="textarea"
            rows="4"
            autocomplete="off"
            width="400px"
            placeholder="可添加多个关键词，请用逗号分隔"
            v-model.trim="keywordData.wordName"
          ></el-input>
        </el-form-item>
      </template>
    </el-form>

    <template v-if="mode != 'keyword'">
      <div v-if="type === 'input'">
        <div class="field-row field-label">
          <div class="field-col field-first">词名称</div>
          <div class="field-col field-last">相似词名称</div>
        </div>

        <div
          class="field-row"
          v-for="(word, index) in similarWordsData.wordList"
          :key="index"
        >
          <el-form :key="word" ref="$similarForms" :model="word" :inline="true">
            <el-form-item
              prop="wordName"
              :rules="[
                { required: true, message: '请输入词名称' },
                { validator: singleWordValidator, index: index },
              ]"
            >
              <el-input
                class="field-col field-first"
                v-model.trim="similarWordsData.wordList[index].wordName"
                autocomplete="off"
              />
            </el-form-item>
            <el-form-item
              prop="similarWordName"
              :rules="[
                { required: true, message: '请输入相似词名称' },
                {
                  validator: similarValidator,
                  model: similarWordsData.wordList[index],
                  prop: 'similarWordName',
                },
              ]"
            >
              <el-input
                class="field-col"
                v-model.trim="similarWordsData.wordList[index].similarWordName"
                placeholder="可添加多个相似词，请用逗号分隔"
                autocomplete="off"
              />
            </el-form-item>
            <span class="icon-wrap">
              <i
                v-if="index !== 0"
                class="el-icon-remove"
                @click="onRemoveSimilarWord(index)"
              ></i>
              <i
                v-if="index === similarWordsData.wordList.length - 1"
                class="el-icon-circle-plus"
                @click="onAddSimilarWord"
              ></i>
            </span>
          </el-form>
        </div>
      </div>
    </template>

    <el-form label-position="right" label-width="120px">
      <el-form-item v-if="type === 'import'" label="导入文件">
        <el-upload
          ref="$uploader"
          :action="importActionUrl"
          :file-list="importData.fileList"
          :on-change="onUploadFileListChange"
          :multiple="false"
          :on-success="onImportSuccess"
          :on-error="onImportError"
          name="ut_fileUpload"
          :data="importData"
          accept="xlsx,xls"
          :auto-upload="false"
        >
          <el-button size="small" type="primary">上传文件</el-button>
          <div slot="tip" class="upload-tips">注：请先下载模板，按模板填写后再上传</div>
        </el-upload>
        <div class="anchor-wrap">
          <a class="anchor" :href="templateFileURL" target="_blank">下载模板</a>
        </div>
      </el-form-item>
    </el-form>

    <span slot="footer" class="dialog-footer">
      <el-button @click="dialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="submit">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import global from '../../../global.js'
import cache from '../../../utils/cache.js'
import qs from 'qs'
/**
 * 新增关键词对话框
 */
export default {
  name: 'VocabularyDialogAdd',

  props: {
    /**
     * 模式
     * 值为 keyword，输入关键词
     * 值为 similar ，为相似词
     * 默认为 keyword
     */
    mode: {
      type: String,
      default: 'keyword',
    },

    /**
     * 当前弹框是否可见
     */
    visible: {
      type: Boolean,
      default: false,
    },

    /**
     * 模板文件下载地址
     */
    templateFileURL: {
      type: String,
      default: '',
    },

    /**
     * 保存词的地址
     */
    submitURL: {
      type: String,
      default: global.qualityUrl,
    },

    checkURL: {
      type: String,
      default: global.aiUrl,
    },

    /**
     * 导入处理程序地址
     */
    importActionUrl: {
      type: String,
      default: () =>
        `${global.qualityUrl}/vocabulary/excelImportWords?accessToken=${cache.getItem(
          'tgt_id'
        )}`,
    },

    /**
     * 当前关键词所在分类的ID
     */
    currentClassId: {
      type: String,
      default: '',
    },

    /**
     * 词库类型
     */
    wordlibType: {
      type: String,
      default: '1',
    },

    /*行业id*/
    industryId: {
      type: String,
      default: '1',
    },
    /*
     * 词库版本
     * */
    versionId: {
      type: String,
      default: '',
    },
    /**
     * 导入模式参数数据
     */
    importParams: {
      type: Object,
      default: () => ({}),
    },

    /**
     * 输入模式参数数据
     */
    keywordParams: {
      type: Object,
      default: () => ({}),
    },

    /**
     * 相似词参数数据
     */
    similarParams: {
      type: Object,
      default: () => ({}),
    },
  },

  data() {
    const { visible } = this.$props
    return {
      // 模式(input、import)
      type: 'input',
      // 弹框是否可见
      dialogVisible: !!visible,
      // 导入上传参数数据
      importData: {
        // 上传的文件列表
        fileList: [],
      },
      // 关键词参数数据
      keywordData: {
        wordName: '',
      },
      // 相似词参数数据
      similarWordsData: {
        wordList: [
          {
            wordName: '',
            similarWordName: '',
          },
        ],
      },
    }
  },

  watch: {
    visible(visible) {
      this.dialogVisible = !!visible
      this.reset()
    },

    dialogVisible(visible) {
      this.$emit('update:visible', !!visible)
    },

    type(val) {
      if (val === 'input') {
        this.importData.fileList = []
      } else {
        this.keywordData.wordName = ''
        this.similarWordsData.wordList = [
          {
            wordName: '',
            similarWordName: '',
          },
        ]
      }
    },
  },

  methods: {
    onUploadFileListChange(file, fileList) {
      if (file.response) {
        if (file.response.flag) {
          this.$message({
            type: 'success',
            message: `文件 ${file.name} 上传成功！`,
          })
        } else {
          this.$message({
            type: 'error',
            message: `${file.response.Data}`,
          })
        }
      }
      this.importData.fileList = Array.isArray(fileList) ? [...fileList] : []
    },
    // 提交
    submit() {
      const type = this.type
      const mode = this.mode
      if (type == 'input') {
        if (mode == 'keyword') {
          // 普通关键字模式
          this.beforeKeywordSubmit()
        } else {
          // 相似词关键字模式
          this.beforeSimilarWordSubmit()
        }
      } else {
        // 导入模式
        const { fileList } = this.importData
        if (fileList.length) {
          const { $uploader } = this.$refs
          this.importData = {
            classId: this.currentClassId,
            wordlibType: this.wordlibType,
            fileList: this.importData,
            versionId: this.versionId,
          }
          console.log(this.importData)
          this.$nextTick(() => {
            $uploader.submit()
          })
        } else {
          this.$message({
            type: 'error',
            message: '请先上传要导入的文件',
          })
        }
      }
    },

    // 普通关键字模式提交
    beforeKeywordSubmit() {
      let _this = this
      const { $form } = this.$refs
      return $form.validate().then(() => {
        let params = {}
        params.wordNames = this.keywordData.wordName.replace(/,,/g, ',')
        params.classId = this.currentClassId
        params.wordlibType = this.wordlibType
        params.industryId = this.industryId
        params.versionId = this.versionId
        this.axios
          .post(this.submitURL + '/vocabulary/addMoreWords.do', qs.stringify(params))
          .then((res) => {
            if (!res.data || res.data == null) {
              _this.$message({
                type: 'error',
                message: '添加失败！',
              })
            } else if (res.data.length == 0) {
              _this.$message({
                type: 'success',
                message: '添加成功！',
              })
            } else {
              _this.$message({
                  type: 'warning',
                  message: '[' + res.data + ']' + '已添加过！'
              })
            }

            _this.visible = false
            _this.reset()
          })
      })
    },

    // 相似词模式关键词提交
    beforeSimilarWordSubmit() {
      let _this = this
      const { $similarForms } = this.$refs
      // 校验表单字段
      return Promise.all(
        (Array.isArray($similarForms) ? $similarForms : [$similarForms]).map(($form) =>
          $form.validate()
        )
      ).then(() => {
        console.log(_this.similarWordsData)
        let params = new Array(_this.similarWordsData.wordList.length)
        for (let i = 0; i < _this.similarWordsData.wordList.length; i++) {
          let param = {}
          param.wordName = _this.similarWordsData.wordList[i].wordName
          param.classId = _this.currentClassId
          param.wordNames = _this.similarWordsData.wordList[i].similarWordName.replace(/,,/g, ',')
          params[i] = param
        }
        // 验证是否重复（是否需要校验重复？）
        let similarParams = {}
        similarParams.params = JSON.stringify(params)
        _this.axios
          .post(
            _this.submitURL + '/vocabulary/addAlikeWords.do',
            qs.stringify(similarParams)
          )
          .then((res) => {
            if (!res.data || res.data == null) {
              _this.$message({
                type: 'error',
                message: '添加失败！',
              })
            } else if (res.data.length == 0) {
              _this.$message({
                type: 'success',
                message: '添加成功！',
              })
              _this.visible = false
              _this.reset()
            } else if (res.data.length > 0) {
              _this.$message({
                type: 'warning',
                message: '重复词：' + res.data,
              })
              _this.visible = false
              _this.reset()
            }
          })
          .catch(() => {
            _this.$message({
              type: 'error',
              message: '添加失败！',
            })
            _this.visible = false
            _this.reset()
          })
          .catch((err) => {
            console.log(err)
            this.visible = false
            this.reset()
          })
      })
    },

    // 单个词校验
    singleWordValidator(rule, value, callback) {
      const errors = []
      if (value) {
        if (/[^\s]+\s[^\s]/.test(value)) {
          errors.push('关键词中不能包含空格')
        } else if (value.indexOf('，') !== -1) {
          errors.push('只能填入单个词')
        } else if (
          this.similarWordsData.wordList.some(
            (word, index) => index !== rule.index && word.wordName === value
          )
        ) {
          errors.push('词名称重复')
        } else if (value.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '_').length > 10) {
          errors.push('单个关键词不能超过10个字')
        }
      }
      if (errors.length) {
        callback(errors)
      } else {
        // 验证是否有重复
        let params = new Array(this.similarWordsData.wordList.length)
        for (let i = 0; i < this.similarWordsData.wordList.length; i++) {
          let param = {}
          let { wordList } = this.similarWordsData
          param.wordName = wordList[i].wordName
          param.wordNames = wordList[i].similarWordName
          param.classId = this.currentClassId
          param.industryId = this.industryId
          param.versionId = this.versionId
          params[i] = param
        }
        let similarParams = {}
        similarParams.params = JSON.stringify(params)
        this.axios
          .post(
            this.checkURL + '/vocabulary/checkAlikeWords',
            qs.stringify(similarParams),
            global.formHeader
          )
          .then((res) => {
            let { data } = res
            let fail = data.fail.join()
            if (!data.flag && fail !== '') {
              errors.push(`[${fail}] 已存在`)
            }
            callback(errors)
          })
          .catch((err) => {
            console.log(err)
            callback(errors)
          })
      }
    },

    // 关键词校验器（可以用逗号分隔多个词）
    keywordValidator(rule, value, callback) {
      let word = typeof value === 'string' ? value.trim() : ''
      const errors = []
      if (word) {
        const { model, prop } = rule
        // 可以使用逗号分隔多个关键词
        const keywords = value
          .replace(/，/g, ',')
          .split(',')
          .map((word) => word.trim())
        if (keywords.length > 10) {
          errors.push('关键词不能超过10个')
        } else {
          for (let i = 0; i < keywords.length; i++) {
            let word = keywords[i]
            if (/[^\s]+\s[^\s]/.test(value)) {
              errors.push('关键词中不能包含空格')
            } else if (keywords.some((item, index) => index !== i && word === item)) {
              errors.push('词名称重复')
            } else if (word.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '_').length > 10) {
              errors.push('单个关键词不能超过10个字')
            } else if (this.wordlibType == 7) {
              // ^[\u4e00-\u9fa5]{0,}$  /^(?![^a-zA-Z]+$)/.test(value) || /(?!\D+$)/.test(value)  ^[A-Za-z0-9]+$
              if (/^(?![^a-zA-Z0-9]+$)/.test(value)) {
                errors.push('关键词中不能包含数字或字母')
              } else if (/[`~!@#$%^&*()（）_=+<>?:"{}.\/;'[\]]/.test(value)) {
                errors.push('关键词中不能包含特殊符号')
              }
            }
          }
        }
        if (errors.length) {
          callback(errors)
        } else {
          // 去掉多余的空格，并回设值
          model[prop] = keywords.join(',')
          let params = {}
          this.wordlibType == 4 ? (params.wordlibType = '5') : (params.wordlibType = '1')
          params.wordNames = this.keywordData.wordName
          params.classId = this.currentClassId
          params.industryId = this.industryId
          params.versionId = this.versionId
          this.axios
            .post(
              this.checkURL + '/vocabulary/checkMoreWords',
              qs.stringify(params),
              global.formHeader
            )
            .then((res) => {
              let { data } = res
              let fail = data.fail.join()
              let success = data.success.join()
              if (!data.flag && !success) {
                errors.push(`[${fail}] 已存在`)
              }
              callback(errors)
            })
            .catch((err) => {
              console.log(err)
              callback(errors)
            })
        }
      }
    },

    // 相似词校验器
    similarValidator(rule, value, callback) {
      const errors = []
      if (value) {
        const { model, prop } = rule
        // 可以使用逗号分隔多个关键词
        const keywords = value
          .replace(/，/g, ',')
          .split(',')
          .map((word) => word.trim())
        if (keywords.length > 10) {
          errors.push('关键词不能超过10个')
        } else {
          for (let i = 0; i < keywords.length; i++) {
            let word = keywords[i]
            if (/[^\s]+\s[^\s]/.test(value)) {
              errors.push('关键词中不能包含空格')
            } else if (keywords.some((item, index) => index !== i && word === item)) {
              errors.push('词名称重复')
            } else if (word.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '_').length > 10) {
              errors.push('单个关键词不能超过10个字')
            }
          }
        }
        if (errors.length) {
          callback(errors)
        } else {
          // 去掉多余的空格，并回设值
          model[prop] = keywords.join(',')
          // 验证是否有重复
          let params = new Array(this.similarWordsData.wordList.length)
          for (let i = 0; i < this.similarWordsData.wordList.length; i++) {
            let param = {}
            this.wordlibType === '4'
              ? (params.wordlibType = '5')
              : (params.wordlibType = '1')
            param.wordName = this.similarWordsData.wordList[i].wordName
            param.classId = this.currentClassId
            param.wordNames = this.similarWordsData.wordList[i].similarWordName
            param.industryId = this.industryId
            param.versionId = this.versionId
            params[i] = param
          }
          let similarParams = {}
          similarParams.params = JSON.stringify(params)
          this.axios
            .post(
              this.checkURL + '/vocabulary/checkAlikeWords',
              qs.stringify(similarParams),
              global.formHeader
            )
            .then((res) => {
              let { data } = res
              let fail = data.fail.join()
              if (!data.flag && fail !== '') {
                errors.push(`[${fail}] 已存在`)
              }
              callback(errors)
            })
            .catch((err) => {
              console.log(err)
              callback(errors)
            })
        }
      }
    },

    // 重置
    reset() {
      this.$refs.$form.resetFields()
      this.type = 'input'
      this.keywordData.wordName = ''
      this.similarWordsData.wordList = [
        {
          wordName: '',
          similarWordName: '',
        },
      ]
      this.importData.fileList = []
    },

    // 导入成功
    onImportSuccess() {
      this.visible = false
      this.reset()
    },

    // 导入失败
    onImportError() {
      this.visible = false
      this.reset()
    },

    // 移除相似词
    onRemoveSimilarWord(index) {
      this.similarWordsData.wordList.splice(index, 1)
    },

    // 添加相似词
    onAddSimilarWord() {
      this.similarWordsData.wordList.push({
        wordName: '',
        similarWordName: '',
      })
    },
  },
}
</script>

<style scoped lang="less">
.anchor-wrap {
  line-height: 1.2em;
  .anchor {
    color: #409eff;
    &:hover {
      text-decoration: underline;
    }
  }
}

.upload-tips {
  font-size: 12px;
  color: #8f8f8f;
}

.field-row {
  .field-col {
    display: inline-block;
    width: 260px;
    &.field-first {
      width: 180px;
    }
  }

  &.field-label {
    .field-col {
      margin-bottom: 8px;
      &.field-last {
        padding-left: 10px;
      }
    }
  }
  .icon-wrap {
    font-size: 25px;
    color: #409eff;
    i {
      cursor: pointer;
    }
  }
}
</style>
