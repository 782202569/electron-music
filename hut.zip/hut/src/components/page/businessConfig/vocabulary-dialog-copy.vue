<template>
  <!--"复制"弹出框-->
  <el-dialog
    title="复制到"
    top="20px"
    :close-on-click-modal="false"
    :before-close="close"
    :visible="dialogVisible"
  >
    <div class="tree-box">
      <div
        :class="['item-wrap', { 'check-disabled': !normal.tree.length }]"
        v-if="currentTabName != '1' && wordArr.some(word => word == '1')"
      >
        <span>添加到通用关键词库</span>
        <div class="tree-wrap" v-loading="normal.loading">
          <el-tree
            show-checkbox
            empty-text=" "
            check-strictly
            default-expand-all
            :data="normal.tree"
            :props="treeProps"
            :node-key="nodeKey"
            @check="normal.onCheck"
          ></el-tree>
          <div v-show="!normal.loading" class="disable-mask">
            {{ normal.tree.length ? '' : '暂无数据' }}
          </div>
        </div>
      </div>
      <div
        :class="['item-wrap', { 'check-disabled': !correction.tree.length }]"
        v-if="currentTabName != '7' && wordArr.some(word => word == '7')"
      >
        <span>添加到文本纠错关键词库</span>
        <div class="tree-wrap" v-loading="correction.loading">
          <el-tree
            show-checkbox
            empty-text=" "
            check-strictly
            default-expand-all
            :data="correction.tree"
            :props="treeProps"
            :node-key="nodeKey"
            @check="correction.onCheck"
          ></el-tree>
          <div v-show="!correction.loading" class="disable-mask">
            {{ correction.tree.length ? '' : '暂无数据' }}
          </div>
        </div>
      </div>
      <div
        :class="['item-wrap', { 'check-disabled': !water.tree.length }]"
        v-if="currentTabName != '2' && wordArr.some(word => word == '2')"
      >
        <span>添加到通用水词库</span>
        <div class="tree-wrap" v-loading="water.loading">
          <el-tree
            show-checkbox
            empty-text=" "
            check-strictly
            default-expand-all
            :data="water.tree"
            :props="treeProps"
            :node-key="nodeKey"
            @check="water.onCheck"
          ></el-tree>
          <div v-show="!water.loading" class="disable-mask">
            {{ water.tree.length ? '' : '暂无数据' }}
          </div>
        </div>
      </div>
      <div
        :class="['item-wrap', { 'check-disabled': !cluster.tree.length }]"
        v-if="currentTabName != '5' && wordArr.some(word => word == '5')"
      >
        <span>添加到聚类水词库</span>
        <div class="tree-wrap" v-loading="cluster.loading">
          <el-tree
            show-checkbox
            empty-text=" "
            check-strictly
            default-expand-all
            :data="cluster.tree"
            :props="treeProps"
            :node-key="nodeKey"
            @check="cluster.onCheck"
          ></el-tree>
          <div v-show="!cluster.loading" class="disable-mask">
            {{ cluster.tree.length ? '' : '暂无数据' }}
          </div>
        </div>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="submit" :disabled="submittable">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import global from '@/global'
import qs from 'qs'
import axios from 'axios'
const baseURL = global.qualityUrl
/**
 * 复制词到选定到分类中
 */
export default {
  name: 'VocabularyDialogCopy',

  props: {
    /**
     *  弹框是否可见
     */
    visible: {
      type: Boolean,
      default: false,
    },
    /**
     * 树节点字段映射配置
     */
    treeProps: {
      type: Object,
      default: () => ({
        children: 'children',
        label: 'label',
        disabled: 'disabled',
      }),
    },
    /**
     * 需要进行复制的项
     */
    items: {
      type: Array,
      default: () => [],
    },
    /**
     * 主键字段名
     */
    nodeKey: {
      type: String,
      default: 'classId',
    },
    /**
     * 当前关键词所在分类的ID
     */
    currentClassId: {
      type: String,
      default: '',
    },
    currentTabName: {
      type: String,
      default: '1',
    },
    wordArr: {
      type: Array,
      default: () => [],
    },
  },

  data() {
    const { items, visible } = this.$props
    return {
      // 弹框是否可见
      dialogVisible: !!(Array.isArray(items) && items.length && visible),
      // 词库类型映射
      types: [
        { type: 'normal', id: '1' },
        { type: 'water', id: '2' },
        { type: 'correction', id: '7' },
        { type: 'cluster', id: '5' },
      ],
      // 通用词库
      normal: {
        tree: [],
        nodes: [],
        loading: false,
        cancelSource: '',
        onCheck: (node, state) => {
          const checked = state.checkedNodes
          this.normal.nodes = Array.isArray(checked) ? checked : []
        },
      },
      // 纠错词库
      correction: {
        tree: [],
        nodes: [],
        loading: false,
        cancelSource: '',
        onCheck: (node, state) => {
          const checked = state.checkedNodes
          this.correction.nodes = Array.isArray(checked) ? checked : []
        },
      },
      // 水词词库
      water: {
        tree: [],
        nodes: [],
        loading: false,
        cancelSource: '',
        onCheck: (node, state) => {
          const checked = state.checkedNodes
          this.water.nodes = Array.isArray(checked) ? checked : []
        },
      },
      // 聚类词库
      cluster: {
        tree: [],
        nodes: [],
        loading: false,
        cancelSource: '',
        onCheck: (node, state) => {
          const checked = state.checkedNodes
          this.cluster.nodes = Array.isArray(checked) ? checked : []
        },
      },
    }
  },

  watch: {
    // 外部更新弹框可见状态
    visible(visible) {
      const { items } = this
      const hasItems = !!(Array.isArray(items) && items.length)
      if (visible && !hasItems) {
        this.$message({
          type: 'warning',
          message: '请先选择要复制的关键词',
        })
      }
      visible = !!(hasItems && visible)
      this.dialogVisible = visible
      this.$emit('update:visible', visible)
    },

    // 内部弹框可见状态
    dialogVisible(visible) {
      if (!visible) {
        this.reset()
      } else {
        this.fetch()
      }
    },
  },

  computed: {
    // 是否可提交
    submittable() {
      const { normal, water, cluster, correction } = this
      return !(
        normal.nodes.length ||
        water.nodes.length ||
        cluster.nodes.length ||
        correction.nodes.length
      )
    },
  },

  mounted() {
    if (this.dialogVisible) {
      this.fetch()
    }
  },

  methods: {
    // 加载树数据
    fetch() {
      let types = []
      this.types.forEach((item) => {
        if (this.wordArr.some(word => word == item.id)){
          types.push(item)
        }
      })
      this.types = types
      console.log(types)
      const { disabled } = this.treeProps || {}
      types.forEach((item) => {
        const { type, id } = item
        const state = this[type]
        const key = this.nodeKey
        const currentClassId = this.currentClassId
        const CancelToken = axios.CancelToken
        state.loading = true
        state.cancelSource = CancelToken.source()
        // 加载数据
        this.axios
          .request({
            method: 'post',
            url: `${baseURL}/vocabulary/getTrees.do`,
            data: qs.stringify({
              classId: '0',
              classType: id,
            }),
            cancelToken: state.cancelSource.token,
          })
          .then((res) => {
            const tree = res ? res.data : null
            if (Array.isArray(tree)) {
              // 禁用掉当前关键词列表所在分类
              this.treeWalker(tree, (node) => {
                node[disabled || 'disabled'] = node[key] === currentClassId
              })
              state.tree = tree
            }
            state.loading = false
          })
          .catch(() => {
            state.loading = false
          })
      })
    },

    // 重置状态
    reset() {
      let types = []
      this.types.forEach((item) => {
        if (this.wordArr.some(word => word == item.id)){
          types.push(item)
        }
      })
      this.types = types
      const { normal, water, cluster, correction } = this
      normal.nodes = []
      normal.tree = []
      water.nodes = []
      water.tree = []
      cluster.nodes = []
      cluster.tree = []
      correction.nodes = []
      correction.tree = []
      types.forEach((item) => {
        const state = this[item.type]
        const { loading, cancelSource } = state
        if (loading) {
          // 取消掉进行中的请求
          state.loading = false
          cancelSource.cancel('abort！')
        }
      })
    },

    // 提交更新
    submit() {
      const nodes = this.getCheckedNodes()
      let classId = ''
      let classTypes = ''
      for (let i = 0; i < nodes.length; i++) {
        if (i === 0) {
          classId = nodes[i].classId
          classTypes = nodes[i].classType
        } else {
          classId += ',' + nodes[i].classId
          classTypes += ',' + nodes[i].classType
        }
      }
      const nodeKeys = this.getCheckedNodeKeys()
      const items = this.items
      console.log('分类：', nodes)
      console.log('分类ID：', nodeKeys)
      console.log('词：', items)
      let wordNames = ''
      for (let i = 0; i < items.length; i++) {
        if (i === 0) {
          wordNames = items[i].wordName
        } else {
          wordNames += ',' + items[i].wordName
        }
      }
      console.log('词字符串：', wordNames)
      let params = {}
      params.wordNames = wordNames
      params.classTypes = classTypes
      params.classId = classId
      this.axios
        .request({
          method: 'post',
          url: `${baseURL}/vocabulary/copyWords.do`,
          data: qs.stringify(params),
        })
        .then((res) => {
          console.log(res.data.code)
          if (res.data.code == 0) {
            this.$message({
              type: 'success',
              message: '复制成功！',
            })
          } else {
            this.$message({
              type: 'warning',
              message: '该词库已存在！',
            })
          }
          this.close()
          this.reset()
        })
        .catch(() => {
          this.$message({
            type: 'error',
            message: '复制失败！',
          })
          this.close()
          this.reset()
        })
    },

    // 关闭弹框
    close() {
      this.dialogVisible = false
      this.$emit('update:visible', false)
    },

    // 获取选中的节点对象列表
    getCheckedNodes() {
      return this.types.reduce((nodes, item) => {
        const state = this[item.type]
        return nodes.concat(state.nodes)
      }, [])
    },

    // 获取选中的节点ID列表
    getCheckedNodeKeys() {
      const key = this.nodeKey
      return this.getCheckedNodes().map((node) => node[key])
    },

    // 迭代树节点
    treeWalker(tree, iterator) {
      const { children } = this.treeProps || {}
      if (Array.isArray(tree)) {
        tree.forEach((node) => {
          iterator(node)
          this.treeWalker(node[children || 'children'], iterator)
        })
      } else if (tree) {
        iterator(tree)
        this.treeWalker(tree[children || 'children'], iterator)
      }
    },
  },
}
</script>

<style scoped lang="less">
.tree-box {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  flex: 1;
  .item-wrap {
    width: 50%;
    height: 50%;
    padding: 10px;
    box-sizing: border-box;
    &:nth-child(1),
    &:nth-child(2) {
      padding-top: 0;
    }
    &:nth-child(3),
    &:nth-child(4) {
      padding-bottom: 0;
    }
  }
  .tree-wrap {
    width: 100%;
    height: 100%;
    margin-top: 8px;
    min-height: 200px;
    max-height: 200px;
    box-sizing: border-box;
    border: 1px solid #eee;
    position: relative;
    overflow: auto;
  }
  .disable-mask {
    position: absolute;
    z-index: -1;
    transition: background-color 0.5s;
    background-color: transparent;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #c0c4cc;
  }
  .check-disabled {
    .disable-mask {
      z-index: 100;
      background-color: rgba(255, 255, 255, 0.8);
    }
  }
}
</style>
