<template>
  <el-dialog
    title="编辑距离设置"
    :visible.sync="dialogVisible"
    :close-on-click-modal="false"
    @closed="reset"
    width="600px"
  >
    <el-form label-position="left" label-width="120px">
      <el-form-item label="编辑距离类型">
        <el-radio-group @change="changeType" v-model="type">
          <el-radio label="word">每个字</el-radio>
          <el-radio label="bizWord">每个业务词</el-radio>
          <el-radio label="bizWordCount">业务词字数</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>

    <div :key="index" class="field-row" v-for="(item, index) in items">
      <el-form :key="item" ref="$forms" :inline="true" :model="item">
        <el-form-item
          v-if="type === 'bizWordCount'"
          prop="count"
          label="字数"
          :rules="[
            { required: true, message: '请输入字数' },
            { type: 'integer', message: '请输入数值' },
            { validator: wordCountValidator, index: index },
          ]"
        >
          <el-input
            class="field-col field-first"
            v-model.trim.number="items[index].count"
            autocomplete="off"
          />
        </el-form-item>

        <el-form-item
          prop="spacing"
          label="编辑距离"
          :rules="[
            { required: true, message: '请输入编辑距离' },
            { type: 'integer', message: '请输入数值' },
            { validator: valueValidator, index: index },
          ]"
        >
          <el-input
            class="field-col"
            v-model.trim.number="items[index].spacing"
            autocomplete="off"
          />
        </el-form-item>

        <span v-if="type === 'bizWordCount'" class="icon-wrap">
          <i v-if="index !== 0" class="el-icon-remove" @click="onRemoveItem(index)"></i>
          <i
            v-if="index === items.length - 1"
            class="el-icon-circle-plus"
            @click="onAddItem"
          ></i>
        </span>
      </el-form>
    </div>
    <div>
      <el-form :inline="true" :model="bizWordCount">
        <el-form-item
          v-if="type === 'bizWordCount'"
          prop="value"
          label="默认编辑距离"
          :rules="[
            { required: true, message: '请输入编辑距离' },
            { type: 'integer', message: '请输入数值' },
            { validator: valueValidator1 },
          ]"
        >
          <el-input
            class="field-col field-first"
            v-model.trim.number="bizWordCount.value"
            autocomplete="off"
          />
        </el-form-item>
      </el-form>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="dialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="submit">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import global from '../../../global.js'
// import cache from '../../../utils/cache.js'
import qs from 'qs'
/**
 * 菜单上的词距离设置弹框
 */
export default {
  name: 'vocabulary-dialog-setting',

  props: {
    /**
     * 当前弹框是否可见
     */
    visible: {
      type: Boolean,
      default: false,
    },
  },

  data() {
    const { visible } = this.$props
    return {
      // 内部弹框可见性
      dialogVisible: !!visible,

      // 距离类型(word、bizWord、bizWordCount)
      type: 'word',

      bizWordCount: {
        value: '',
      },
      // 项列表
      items: [
        {
          // 字数
          count: '',
          // 间隔距离
          spacing: '',
        },
      ],
    }
  },

  watch: {
    visible(visible) {
      this.dialogVisible = !!visible
      this.getEditDistance(false)
    },

    dialogVisible(visible) {
      this.$emit('update:visible', !!visible)
    },
  },

  methods: {
    // 重置
    reset(noType) {
      if (!noType) {
        this.type = 'word'
      }
      this.items = [
        {
          count: '',
          spacing: '',
        },
      ]
      this.bizWordCount.value = ''
    },

    // 提交
    submit() {
      let _this = this
      const { $forms } = _this.$refs
      Promise.all(
        (Array.isArray($forms) ? $forms : [$forms]).map(($form) => $form.validate())
      ).then(() => {
        const { type, items } = _this
        console.log('编辑类型：', type)
        console.log('设置项：', items)
        // alert('TODO: 提交请求')
        let params = {}
        if (_this.type == 'word') {
          params.type = 1
          params.value = _this.items[0].spacing
        } else if (_this.type == 'bizWord') {
          params.type = 2
          params.value = _this.items[0].spacing
        } else if (_this.type == 'bizWordCount') {
          params.type = 3
          params.value = _this.bizWordCount.value
          params.values = JSON.stringify(_this.items)
        }
        _this.axios
          .post(
            global.qualityUrl + '/vocabulary/editDistanceUpdate.do',
            qs.stringify(params)
          )
          .then((res) => {
            if (res.data) {
              _this.$message({
                type: 'success',
                message: '配置修改成功！',
              })
            } else {
              _this.$message({
                type: 'error',
                message: '配置修改失败！',
              })
            }
            _this.visible = false
            _this.reset()
          })
          .catch(() => {
            _this.$message({
              type: 'error',
              message: '配置修改失败！',
            })
            _this.visible = false
            _this.reset()
          })
      })
    },

    // 字数校验器
    wordCountValidator(rule, value, callback) {
      const errors = []
      if (
        this.items.some((item, index) => index !== rule.index && item.count === +value)
      ) {
        errors.push('字数重复')
      }
      callback(errors)
    },

    //编辑距离校验
    valueValidator(rule, value, callback) {
      const errors = []
      if (this.items.some((item, index) => value < 1 || value > 5)) {
        errors.push('编辑距离在1到5之间')
      }
      callback(errors)
    },

    //编辑距离校验
    valueValidator1(rule, value, callback) {
      const errors = []
      if (value < 1 || value > 5) {
        errors.push('编辑距离在1到5之间')
      }
      callback(errors)
    },

    // 移除项
    onRemoveItem(index) {
      this.items.splice(index, 1)
    },

    // 添加项
    onAddItem() {
      this.items.push({
        count: '',
        spacing: '',
      })
    },
    // 获取编辑距离配置
    getEditDistance(byTypeFlag) {
      let _this = this
      let typeValue = null
      let url = '/vocabulary/getEditDistance.do'
      if (byTypeFlag) {
        if (_this.type == 'word') {
          typeValue = 1
        } else if (_this.type == 'bizWord') {
          typeValue = 2
        } else if (_this.type == 'bizWordCount') {
          typeValue = 3
        }
        url = '/vocabulary/getEditDistance.do?type=' + typeValue
      }
      this.axios
        .get(global.qualityUrl + url, {})
        .then((res) => {
          console.log(res.data)
          if (res.data) {
            if (res.data.type === 1) {
              _this.type = 'word'
              _this.items[0].spacing = res.data.value
            } else if (res.data.type === 2) {
              _this.type = 'bizWord'
              _this.items[0].spacing = res.data.value
            } else if (res.data.type === 3) {
              _this.type = 'bizWordCount'
              _this.items = res.data.items
              _this.bizWordCount.value = res.data.value
            } else {
              _this.reset(true)
            }
          } else {
            _this.$message({
              type: 'warning',
              message: '未获取到编辑距离配置！',
            })
          }
        })
        .catch(() => {
          _this.$message({
            type: 'error',
            message: '获取编辑距离配置失败！',
          })
        })
    },

    changeType(typeItem) {
      this.getEditDistance(true)
    },
  },
}
</script>

<style scoped lang="less">
.field-row {
  .field-col {
    width: 200px;
    &.field-first {
      width: 100px;
    }
  }

  .icon-wrap {
    font-size: 25px;
    color: #409eff;
    i {
      cursor: pointer;
    }
  }
}
</style>
