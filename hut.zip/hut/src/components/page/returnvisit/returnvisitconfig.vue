<template>
  <div style="width:100%;height:100%;">
    <div v-if="!showTaskResult">
      <div class="ietemplate-header">
        <el-button
          funcId="000259"
          style="float: right;margin-right: 5px;margin-top: 5px"
          @click="batchDelete"
          >批量删除</el-button
        >
        <el-button
          funcId="000258"
          style="float: right;margin-right: 10px;margin-top: 5px"
          @click="showEditConfigDialog(null, 'add')"
        >
          新建
        </el-button>
        <el-button
          style="float: right;margin-right: 10px;margin-top: 5px"
          type="primary"
          @click="queryProjects"
        >
          查询
        </el-button>
        <el-date-picker
          v-model="queryDateRange"
          type="datetimerange"
          placeholder="执行时间"
          align="right"
          style="float: right;margin-right: 5px;margin-top: 5px"
        ></el-date-picker>
        <el-input
          v-model="queryProjectName"
          placeholder="配置名称"
          style="float: right;margin-right: 5px;margin-top: 5px;width: 120px"
        ></el-input>
      </div>
      <div>
        <div style="overflow: auto;width: 100%;height: 650px">
          <el-table
            :data="returnVisitProjects"
            border
            @selection-change="handleSelectionChange"
            ref="templateTable"
          >
            <el-table-column type="selection" width="55px"></el-table-column>
            <el-table-column prop="projectName" label="配置名称"></el-table-column>
            <el-table-column prop="createUserName" label="创建人"></el-table-column>
            <el-table-column
              prop="executeTime"
              :formatter="formatDate"
              label="执行时间"
            ></el-table-column>
            <el-table-column
              prop="taskExecuteState"
              label="任务状态"
              show-overflow-tooltip
            >
              <template scope="scope">
                <el-tag
                  close-transition
                  v-if="scope.row.executeTime == null && scope.row.enable == 0"
                  >未开始</el-tag
                >
                <el-tag close-transition type="primary" v-if="scope.row.enable == 1"
                  >运行中</el-tag
                >
                <el-tag
                  close-transition
                  v-if="scope.row.executeTime != null && scope.row.enable == 0"
                  >暂停中</el-tag
                >
              </template>
            </el-table-column>
            <el-table-column label="操作" show-overflow-tooltip>
              <template scope="scope">
                <i
                  funcId="000374"
                  class="el-icon-caret-right"
                  style="cursor:pointer;margin-right:4px;"
                  v-if="scope.row.enable == '0'"
                  @click="showTaskStartPage(scope.row)"
                >
                  <i
                    style="font-family:'微软雅黑';font-size:12px;"
                    @click="showTaskStartPage(scope.row)"
                    >开始</i
                  >
                </i>
                <i
                  funcId="000400"
                  class="iconfont icon-222"
                  style="cursor:pointer;float:left;margin-right:4px;"
                  v-if="scope.row.enable == '1'"
                  @click="disableProject(scope.row)"
                >
                  <i
                    style="font-family: '微软雅黑';font-size:12px;"
                    @click="disableProject(scope.row)"
                    >暂停</i
                  >
                </i>
                <i
                  funcId="000375"
                  class="el-icon-document"
                  style="cursor:pointer;margin-right:4px;"
                  @click="showEditConfigDialog(scope.row, 'copy')"
                >
                  <i
                    style="font-family: '微软雅黑';font-size:12px;"
                    @click="showEditConfigDialog(scope.row, 'copy')"
                    >复制</i
                  >
                </i>
                <i
                  funcId="000376"
                  class="el-icon-close"
                  style="cursor:pointer;margin-right:4px;"
                  @click="deleteOneProject(scope.row)"
                >
                  <i
                    style="font-family: '微软雅黑';font-size:12px;margin-left:2px;"
                    @click="deleteOneProject(scope.row)"
                    >删除</i
                  >
                </i>
                <i
                  funcId="000377"
                  class="el-icon-search"
                  style="cursor:pointer;margin-right:0px;"
                  @click="showTaskResultPage(scope.row)"
                >
                  <i
                    style="font-family: '微软雅黑';font-size:12px;"
                    @click="showTaskResultPage(scope.row)"
                    >查看</i
                  >
                </i>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div>
          <div
            style="float: right;margin-top: 10px;position: absolute;bottom: 0px;right: 0px"
          >
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page.sync="pageNumber"
              :page-size="pageSize"
              :page-sizes="[10, 20, 30, 40]"
              layout="total, sizes, prev, pager, next, jumper"
              :total="totalProjectCount"
            >
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
    <v-task-result
      v-if="showTaskResult"
      v-on:send="showProjectPage"
      :projectModel="queryProjectModel"
    ></v-task-result>
    <el-dialog
      id="editConfigDialog"
      :title="modalName"
      :visible.sync="editConfigShow"
      :close-on-click-modal="false"
    >
      <v-task
        v-on:send="closeEditConfigDialog"
        v-if="editConfigShow"
        :projectModel="projectModel"
        :editType="editType"
      ></v-task>
    </el-dialog>
    <el-dialog
      id="newTaskStarttime"
      title="开始任务"
      :close-on-click-modal="false"
      :visible.sync="startTaskDialog"
    >
      <el-form ref="saveStrategyModel" label-width="100px" label-position="top">
        <el-form-item label="任务执行时间">
          <el-date-picker
            v-model="taskStartTime"
            type="datetime"
            placeholder="选择日期时间"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item>
          <div class="btns">
            <el-button type="primary" @click="enableProject">确定</el-button>
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<style scoped lang="less">
.ietemplate-header {
  box-sizing: border-box;
  top: 5px;
  width: 100%;
  height: 50px;
  border-bottom: 1px dashed #d1dbe7;
}
</style>

<script type="text/ecmascript-6">
import vTask from '../returnvisit/rvconfig.vue'
import vTaskResult from '../returnvisit/rvtaskresult'
import global from '../../../global.js'
import formatdate from '../../../utils/formatdate.js'
import Qs from 'qs'
let currentBaseUrl = global.currentBaseUrl
let baseUrl = currentBaseUrl + '/rvp/'
let requestUrls = {
  getProjectsUrl: baseUrl + 'queryProjects.do',
  batchDeleteProjectsUrl: baseUrl + 'batchDeleteProjects.do',
  saveProjectUrl: baseUrl + 'saveProject.do',
  updateProjectUrl: baseUrl + 'updateProject.do',
  enableProjectUrl: currentBaseUrl + '/rvt/enableProject.do',
  disableProjectUrl: currentBaseUrl + '/rvt/disableProject.do',
}
import bus from '../../common/bus.js'
export default {
  components: {
    vTask,
    vTaskResult,
  },
  mounted() {
    this.$store.commit('setPlayerInfo', {
      exist: false,
      extendClassName: '',
      maxCallback: null,
    })
    bus.$emit('closeToplayer')
    this.getProjects()
    if (
      this.$route.query.isRootMenu != undefined &&
      !this.$route.query.isRootMenu &&
      this.$store.state.returnVisitConfig.taskId !== '' &&
      this.$store.state.returnVisitConfig.projectId != ''
    ) {
      this.showTaskResult = true
      this.queryProjectModel = {
        projectId: this.$store.state.returnVisitConfig.projectId,
      }
    }
  },
  data() {
    return {
      queryProjectName: '',
      queryDateRange: [],
      returnVisitProjects: [],
      pageNumber: 1,
      pageSize: 10,
      totalProjectCount: 0,
      selectedProjects: [],
      editConfigShow: false,
      modalName: '保存任务',
      projectModel: null,
      editType: 'add',
      showTaskResult: false,
      queryProjectModel: null,
      taskStartTime: null,
      startTaskDialog: false,
      selectStartProject: null,
    }
  },
  methods: {
    formatDate(val) {
      if (val['executeTime']) {
        return formatdate.formatDate(val['executeTime'])
      } else {
        return '\\'
      }
    },
    handleSelectionChange(val) {
      this.selectedProjects = val
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.pageNumber = 1
      this.getProjects()
    },
    handleCurrentChange(val) {
      this.pageNumber = val
      this.getProjects()
    },
    getProjects() {
      let params = {
        projectName: this.queryProjectName,
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
      }
      if (this.queryDateRange[0]) {
        params['startTime'] = formatdate.formatDate(this.queryDateRange[0])
      }
      if (this.queryDateRange[1]) {
        params['endTime'] = formatdate.formatDate(this.queryDateRange[1])
      }
      this.axios
        .post(requestUrls['getProjectsUrl'], Qs.stringify(params))
        .then((response) => {
          this.returnVisitProjects = response['data']['results']
          this.totalProjectCount = response['data']['count']
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('查询回访参数配置列表发生异常!')
        })
    },
    queryProjects() {
      this.pageNumber = 1
      this.getProjects()
    },
    closeEditConfigDialog() {
      this.editConfigShow = false
      this.projectModel = null
      this.getProjects()
    },
    showEditConfigDialog(project, editType) {
      this.projectModel = project
      this.editType = editType
      this.editConfigShow = true
    },
    batchDeleteProjects(projectIds, removeMessage) {
      if (!projectIds || projectIds.length === 0) {
        this.$message.error('请至少选择一个配置进行删除')
        return
      }
      let params = {
        projectIdStr: projectIds.join(','),
      }
      this.$confirm(removeMessage, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        this.axios
          .post(requestUrls['batchDeleteProjectsUrl'], Qs.stringify(params))
          .then((response) => {
            if (response.data) {
              this.$message.info('删除成功!')
              this.getProjects()
            } else {
              this.$message.error('删除失败!')
            }
          })
          .catch((e) => {
            console.log(e)
            this.$message.error('删除回访话术配置发生异常!')
          })
      })
    },
    batchDelete() {
      let projectIds = []
      this.selectedProjects.forEach(function(e) {
        projectIds.push(e['projectId'])
      })
      this.batchDeleteProjects(projectIds, this.getRemoveMessage(this.selectedProjects))
    },
    deleteOneProject(row) {
      this.batchDeleteProjects(
        [row['projectId']],
        '你确定要删除【' + row['projectName'] + '】这1条数据吗?'
      )
    },
    getRemoveMessage(_dataList) {
      let message = '你真的要删除【'
      let dataList = _dataList
      if (dataList.length > 3) {
        dataList = dataList.slice(0, 3)
      }
      let projectNameArr = []
      dataList.forEach(function(e) {
        projectNameArr.push(e['projectName'])
      })
      message += projectNameArr.join(',') + '】'
      if (_dataList.length > 3) {
        message += '等'
      } else {
        message += '这'
      }
      message += _dataList.length + '条数据吗?'
      return message
    },
    showTaskResultPage(row) {
      this.queryProjectModel = row
      this.showTaskResult = true
      localStorage.setItem('fromFirst', 'yes')
    },
    showProjectPage() {
      this.showTaskResult = false
    },
    showTaskStartPage(row) {
      this.startTaskDialog = true
      this.selectStartProject = row
    },
    enableProject() {
      let params = {
        projectId: this.selectStartProject['projectId'],
      }
      if (!this['taskStartTime']) {
        this.$message.error('请选择任务开始时间')
        return
      }
      params['taskStartTime'] = formatdate.formatDate(this.taskStartTime)
      this.axios
        .post(requestUrls['enableProjectUrl'], Qs.stringify(params))
        .then((response) => {
          let data = response['data']
          if (data) {
            this.$message.info('任务已经开始运行!')
            this.getProjects()
            this.startTaskDialog = false
            this.taskStartTime = null
          } else {
            this.$message.error('任务开始失败!')
          }
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('开始回访话术任务出现异常!')
        })
    },
    disableProject(row) {
      let params = {
        projectId: row['projectId'],
      }
      this.axios
        .post(requestUrls['disableProjectUrl'], Qs.stringify(params))
        .then((response) => {
          if (response.data) {
            this.$message.info('任务暂停成功!')
            this.getProjects()
          } else {
            this.$message.error('任务暂停失败!')
          }
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('任务禁用出现异常!')
        })
    },
  },
}
</script>
