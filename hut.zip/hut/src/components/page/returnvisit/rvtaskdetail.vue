<template>
  <div style="width: 100%;height: 100%" id="rv_task_detail">
    <div style="width: 100%;height:50px;border-bottom:1px dashed #d1dbe7;">
      <div class="tips">
        <label>匹配数量</label>
        <el-tag type="success">{{ taskModel.matchRecordCount }}</el-tag>
        <label>周期录音数量</label>
        <el-tag type="warning">{{ taskModel.allRecordCount }}</el-tag>
        <label>合规率</label>
        <el-tag type="danger">{{ getMatchRatio }}</el-tag>
        <el-button style="float: right;margin-right: 5px;margin-top: 5px" @click="goBack"
          >返回</el-button
        >
        <el-button
          style="float: right;margin-right: 10px;margin-top: 5px"
          type="primary"
          @click="exportTaskDetails"
          >导出</el-button
        >
      </div>
    </div>
    <div style="overflow: auto;width: 100%;height: 650px">
      <el-table :data="taskDetails" border>
        <el-table-column type="index" label="序号"></el-table-column>
        <el-table-column prop="objectId" label="录音编号">
          <template scope="scope">
            <el-button type="text" @click="showDetail(scope.row)">{{
              scope.row.objectId
            }}</el-button>
          </template>
        </el-table-column>
        <el-table-column
          prop="recordTime"
          :formatter="formatDate"
          label="录音时间"
        ></el-table-column>
        <el-table-column prop="callTime" label="录音时长"></el-table-column>
        <el-table-column prop="seatName" label="坐席姓名"></el-table-column>
        <el-table-column prop="seatGroup" label="坐席组"></el-table-column>
        <el-table-column prop="isValidStr" label="是否合规"></el-table-column>
        <el-table-column label="操作" show-overflow-tooltip>
          <template scope="scope">
            <i class="el-icon-search" style="cursor:pointer;margin-right:20px;">
              <i
                style="font-family: '微软雅黑';margin-left:4px;"
                @click="showDetail(scope.row)"
                >查看</i
              >
            </i>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div>
      <div
        style="float: right;margin-top: 10px;position: absolute;bottom: 0px;right: 0px"
      >
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageNumber"
          :page-size="pageSize"
          :page-sizes="[10, 20, 30, 40]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="totalTaskDetailCount"
        >
        </el-pagination>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>

<style scoped lang="less">
.tips {
  & > label {
    color: #9dadc2;
    font-size: 14px;
    margin-left: 5px;
  }
  & > span {
    margin: 10px 10px 10px 10px;
  }
}

#rv_task_detail {
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
}
</style>
<style lang="less">
#rv_task_detail {
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
}
</style>

<script type="text/ecmascript-6">
import formatdate from '../../../utils/formatdate.js'
import Qs from 'qs'
import global from '../../../global.js'
import commonUtil from '../../../utils/commonUtil'
import recordingplay from '../recordingPlay/recordingPlayNew.vue'
import vPlayer from '../../common/player.vue'
import bus from '../../common/bus.js'
let currentBaseUrl = global.currentBaseUrl

export default {
  props: ['taskModel'],
  components: {
    recordingplay,
    vPlayer,
  },
  data() {
    return {
      pageSize: 10,
      pageNumber: 1,
      taskDetails: [],
      totalTaskDetailCount: 0,
      recordDialogVisible: false,
    }
  },
  methods: {
    goBack() {
      this.$emit('send')
    },
    showDetail(row) {
      let obj = {
        detailId: row['detailId'],
        objectId: row['objectId'],
        isReturnVisit: true,
        callId: row['objectId'],
        recordFileURL: row['recordFileURL'],
        from: 'returnVisitConfig',
      }
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    formatDate(val) {
      if (val['recordTime']) {
        return formatdate.formatDate(val['recordTime'])
      } else {
        return '\\'
      }
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.pageNumber = 1
      this.getTaskDetails()
    },
    handleCurrentChange(val) {
      this.pageNumber = val
      this.getTaskDetails()
    },
    getTaskDetails() {
      let params = {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        taskId: this.taskModel['taskId'],
      }
      this.axios
        .post(currentBaseUrl + '/rvt/queryTaskDetails.do', Qs.stringify(params))
        .then((response) => {
          this.taskDetails = response['data']['results']
          this.totalTaskDetailCount = response['data']['count']
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('查询任务详细情况发生异常')
        })
    },
    exportTaskDetails() {
      let params = {
        taskId: this.taskModel['taskId'],
      }
      commonUtil.doExport(currentBaseUrl + '/rvt/exportTaskDetails.do', params)
    },
  },
  mounted() {
    this.recordPlayCloseHandler()
    this.getTaskDetails()
  },
  computed: {
    getMatchRatio() {
      if (this.taskModel && this.taskModel.matchRatio) {
        return (this.taskModel.matchRatio * 100).toFixed(2) + '%'
      }
      return '0%'
    },
  },
}
</script>
