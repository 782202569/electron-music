<template>
  <div style="width: 100%;height: 100%">
    <div style="width: 100%;height:50px;border-bottom:1px dashed #d1dbe7;">
      <el-button style="float: right;margin-right: 5px;margin-top: 5px" @click="goBack"
        >返回</el-button
      >
    </div>
    <div
      style="width: 100%;height:50px;border-bottom:1px dashed #d1dbe7;"
      v-if="editType == 'edit'"
    >
      <el-button
        funcId="000411"
        style="float: right;margin-right: 5px;margin-top: 5px"
        @click="batchDeleteQuestions"
        >批量删除</el-button
      >
      <el-button
        funcId="000412"
        style="float: right;margin-right: 10px;margin-top: 5px"
        type="primary"
        @click="showEditQuestion(null, 'save')"
      >
        新建问题
      </el-button>
    </div>
    <div>
      <div style="overflow: auto;width: 100%;height: 650px;">
        <el-table
          :data="questions"
          border
          style="width: 100%;"
          @selection-change="handleSelectionChange"
          ref="questionTable"
        >
          <el-table-column type="selection" width="55px"></el-table-column>
          <el-table-column type="index" label="序号"></el-table-column>
          <el-table-column prop="questionName" label="回访问题"></el-table-column>
          <el-table-column prop="answerOutputs" label="答案"></el-table-column>
          <el-table-column
            prop="createTime"
            :formatter="formatDate"
            label="创建时间"
          ></el-table-column>
          <el-table-column label="操作" show-overflow-tooltip>
            <template scope="scope">
              <i
                funcId="000413"
                class="el-icon-edit"
                style="cursor:pointer;margin-right:10px;"
                v-if="editType == 'edit'"
                @click="showEditQuestion(scope.row, 'edit')"
              >
                <i
                  style="font-family: '微软雅黑';margin-left:4px;"
                  @click="showEditQuestion(scope.row, 'edit')"
                  >编辑</i
                >
              </i>
              <i
                funcId="000414"
                class="el-icon-close"
                style="cursor:pointer;margin-right:10px;font-size:12px;"
                v-if="editType == 'edit'"
                @click="deleteOneQuestion(scope.row)"
              >
                <i
                  style="font-family: '微软雅黑';margin-left:5px;font-size:14px;"
                  @click="deleteOneQuestion(scope.row)"
                  >删除</i
                >
              </i>
              <i
                funcId="000415"
                class="el-icon-search"
                style="cursor:pointer;margin-right:10px;"
                @click="showEditQuestion(scope.row, 'watch')"
              >
                <i
                  style="font-family: '微软雅黑';margin-left:4px;"
                  @click="showEditQuestion(scope.row, 'watch')"
                  >查看</i
                >
              </i>
              <i
                funcId="000416"
                class="el-icon-arrow-up"
                style="cursor:pointer;margin-right:10px;"
                v-if="editType == 'edit'"
                @click="upgradeQuestionOrder(scope.row)"
              >
                <i
                  style="font-family: '微软雅黑';margin-left:4px;"
                  @click="upgradeQuestionOrder(scope.row)"
                  >上移</i
                >
              </i>
              <i
                funcId="000417"
                class="el-icon-arrow-down"
                style="cursor:pointer;margin-right:10px;"
                v-if="editType == 'edit'"
                @click="reduceQuestionOrder(scope.row)"
              >
                <i
                  style="font-family: '微软雅黑';margin-left:4px;"
                  @click="reduceQuestionOrder(scope.row)"
                  >下移</i
                >
              </i>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div>
        <div
          style="float: right;margin-top: 10px;margin-right: 10px;position: absolute;right: 0px;bottom: 0px"
        >
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page.sync="pageNumber"
            :page-size="pageSize"
            :page-sizes="[10, 20, 30, 40]"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalQuestionsCount"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog
      :title="editQuestionTitle"
      :visible.sync="editQuestionShow"
      @close="closeDialog"
    >
      <div>
        <el-form
          :model="editQuestionModel"
          :rules="formRules"
          ref="editQuestionForm"
          labelPosition="left"
          @close="closeDialog"
        >
          <el-form-item label="问题名称" prop="questionName">
            <el-input
              style="width: 80%"
              v-model="editQuestionModel.questionName"
            ></el-input>
          </el-form-item>
          <el-form-item label="问题关键词" prop="questionKeyword">
            <textarea
              class="keywordtextarea"
              v-model="editQuestionModel.questionKeyword"
            ></textarea>
          </el-form-item>
          <div v-if="editQuestionType !== 'watch'">
            <span class="spanStyle" @click="insertQuestion('OR')">OR</span>
            <span class="spanStyle" @click="insertQuestion('AND')">AND</span>
            <span class="spanStyle" @click="insertQuestion('()')">()</span>
          </div>
        </el-form>
        <i
          funcId="000418"
          class="el-icon-plus"
          style="cursor: pointer;margin-left: 20px"
          @click="addAnswer(-1)"
          v-if="editAnswers.length === 0"
          >添加答案</i
        >
        <el-table :data="editAnswers" style="width: 100%" :show-header="false">
          <el-table-column style="display: inline">
            <template scope="scope">
              <div>
                <span>
                  {{ '答案' + (scope.$index + 1) + '输出' }}
                </span>
                <el-input
                  style="width: 60%;margin-left: 15px"
                  v-model="scope.row.answerOutPut"
                ></el-input>
                <i
                  class="el-icon-plus"
                  style="cursor: pointer;margin-left: 20px"
                  @click="addAnswer(scope.$index)"
                  v-if="editQuestionType !== 'watch'"
                ></i>
                <i
                  class="el-icon-minus"
                  style="cursor: pointer;margin-left: 20px"
                  @click="removeAnswer(scope.$index)"
                  v-if="editQuestionType !== 'watch'"
                ></i>
              </div>
              <div>
                <span style="line-height: 56px">
                  {{ '答案' + (scope.$index + 1) + '关键词' }}
                </span>
                <textarea
                  class="keywordtextarea"
                  v-model="scope.row.answerKeyword"
                ></textarea>
              </div>
              <div v-if="editQuestionType !== 'watch'">
                <span class="spanStyle" @click="insertAnswer(scope.$index, 'OR')"
                  >OR</span
                >
                <span class="spanStyle" @click="insertAnswer(scope.$index, 'AND')"
                  >AND</span
                >
                <span class="spanStyle" @click="insertAnswer(scope.$index, '()')"
                  >()</span
                >
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div slot="footer">
        <el-button @click="closeDialog">取 消</el-button>
        <el-button
          type="primary"
          v-if="editQuestionType !== 'watch'"
          @click="modifyQuestion"
          >确 定</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>

<style scoped lang="less">
.keywordtextarea {
  width: 80%;
  height: 80px;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-sizing: border-box;
  padding-left: 10px;
  padding-top: 10px;
  margin-top: 10px;
}

.spanStyle {
  display: inline-block;
  border: 1px solid #ddd;
  text-align: center !important;
  width: 55px !important;
  margin-left: 3px;
  border-radius: 4px;
  cursor: pointer;
}
</style>

<script type="text/ecmascript-6">
import global from '../../../global.js'
import Qs from 'qs'
import formatdate from '../../../utils/formatdate.js'
let currentBaseUrl = global.currentBaseUrl
let baseUrl = currentBaseUrl + '/rvQuestion/'
let requestUrls = {
  getQuestionsUrl: baseUrl + 'getQuestions.do',
  batchDeleteQuestionsUrl: baseUrl + 'batchDeleteQuestions.do',
  upgradeQuestionUrl: baseUrl + 'upgradeQuestionOrder.do',
  reduceQuestionOrderUrl: baseUrl + 'reduceQuestionOrder.do',
  saveQuestionUrl: baseUrl + 'saveQuestion.do',
  updateQuestionUrl: baseUrl + 'updateQuestion.do',
}

export default {
  props: ['templateData', 'editType'],
  data() {
    return {
      questions: [],
      pageSize: 10,
      pageNumber: 1,
      totalQuestionsCount: 0,
      selectedQuestions: [],
      editQuestion: null,
      editQuestionType: 'edit',
      editQuestionShow: false,
      formRules: {
        questionName: [
          { required: true, message: '问题名称不能为空!', trigger: 'blur,change' },
        ],
        questionKeyword: [
          { required: true, message: '问题关键词不能为空!', trigger: 'blur,change' },
        ],
      },
      editQuestionModel: {
        questionName: '',
        questionKeyword: '',
      },
      editAnswers: [],
      editQuestionTitle: '编辑问题',
    }
  },
  mounted() {
    this.getQuestions()
  },
  methods: {
    formatDate(val) {
      return formatdate.formatDate(val['createTime'])
    },
    goBack() {
      this.$emit('send')
    },
    getQuestions() {
      let params = {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        templateId: this.templateData['templateId'],
      }
      let self = this
      this.axios
        .post(requestUrls['getQuestionsUrl'], Qs.stringify(params))
        .then(function(response) {
          let data = response.data
          self.questions = data['results']
          self.totalQuestionsCount = data['Count']
        })
        .catch(function(e) {
          self.$message.error('获取回访话术问题发生异常')
        })
    },
    handleSelectionChange(val) {
      this.selectedQuestions = val
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.pageNumber = 1
      this.getQuestions()
    },
    handleCurrentChange(val) {
      this.pageNumber = val
      this.getQuestions()
    },
    deleteQuestions(questionIds) {
      if (questionIds.length === 0) {
        this.$message.error('至少选择一个回访话术问题进行删除!')
        return
      }
      this.$confirm('确定要删除这' + questionIds.length + '个回访话术问题吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        let params = {
          questionIdStr: questionIds.join(','),
        }
        let self = this
        this.axios
          .post(requestUrls['batchDeleteQuestionsUrl'], Qs.stringify(params))
          .then(function(response) {
            if (response.data) {
              self.$message.info('删除成功')
              self.getQuestions()
            }
          })
      })
    },
    batchDeleteQuestions() {
      let questionIds = []
      this.selectedQuestions.forEach(function(e) {
        questionIds.push(e['questionId'])
      })
      this.deleteQuestions(questionIds)
    },
    deleteOneQuestion(row) {
      this.deleteQuestions([row['questionId']])
    },
    upgradeQuestionOrder(row) {
      let params = {
        questionId: row['questionId'],
      }
      this.axios
        .post(requestUrls['upgradeQuestionUrl'], Qs.stringify(params))
        .then((response) => {
          if (response.data.state === '1') {
            this.$message.info('上移成功!')
            this.getQuestions()
          } else {
            this.$message.error(response.data['message'])
          }
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('上移回访话术问题发生异常!')
        })
    },
    reduceQuestionOrder(row) {
      let params = {
        questionId: row['questionId'],
      }
      this.axios
        .post(requestUrls['reduceQuestionOrderUrl'], Qs.stringify(params))
        .then((response) => {
          if (response.data.state === '1') {
            this.$message.info('下移成功!')
            this.getQuestions()
          } else {
            this.$message.error(response.data['message'])
          }
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('下移回访话术问题发生异常!')
        })
    },
    closeDialog() {
      this.editQuestionShow = false
      this.editQuestion = null
      this.editAnswers = []
      this.editQuestionModel.questionName = ''
      this.editQuestionModel.questionKeyword = ''
    },
    getEditQuestionParams() {
      let params = {
        templateId: this.templateData['templateId'],
        questionName: this.editQuestionModel.questionName,
        questionKeyword: this.editQuestionModel.questionKeyword,
        answersStr: JSON.stringify(this.editAnswers),
      }
      if (this.editQuestion) {
        params['questionId'] = this.editQuestion['questionId']
      }
      return params
    },
    modifyQuestion() {
      let msg = this.checkEditParams()
      if (msg) {
        this.$message.error(msg)
        return
      }
      if (this.editQuestionType === 'edit') {
        this.updateQuestion()
      }
      if (this.editQuestionType === 'save') {
        this.saveQuestion()
      }
    },
    isBlank(str) {
      return str === null || str === undefined || str.toString().trim() === ''
    },
    checkEditParams() {
      if (this.isBlank(this.editQuestionModel.questionName)) {
        return '问题不能为空!'
      }
      if (this.editQuestionModel.questionName.length > 30) {
        return '问题长度不能超过30'
      }
      if (this.isBlank(this.editQuestionModel.questionKeyword)) {
        return '问题关键词不能为空!'
      }
      if (this.editQuestionModel.questionKeyword.length > 200) {
        return '问题关键词长度不能超过200!'
      }
      if (this.editAnswers.length === 0) {
        return '请至少保存一个答案!'
      }
      let msg = null
      for (let i = 0; i < this.editAnswers.length; i++) {
        let e = this.editAnswers[i]
        if (this.isBlank(e['answerOutPut'])) {
          msg = '答案' + (i + 1) + '输出为空!'
          break
        }
        if (this.isBlank(e['answerKeyword'])) {
          msg = '答案' + (i + 1) + '关键词为空!'
          break
        }
        if (e['answerOutPut'].length > 30) {
          msg = '答案' + (i + 1) + '输出长度不能大于30!'
          break
        }
        if (e['answerKeyword'].length > 200) {
          msg = '答案' + (i + 1) + '关键词长度不能大于200!'
          break
        }
      }
      return msg
    },
    saveQuestion() {
      this.$refs['editQuestionForm'].validate((valid) => {
        if (valid) {
          this.axios
            .post(
              requestUrls['saveQuestionUrl'],
              Qs.stringify(this.getEditQuestionParams())
            )
            .then((response) => {
              if (response['data']) {
                this.$message.info('保存回访话术问题成功!')
                this.closeDialog()
                this.getQuestions()
              } else {
                this.$message.error('保存回访话术问题失败!')
              }
            })
            .catch((e) => {
              console.log(e)
              this.$message.error('保存回访话术问题发生异常!')
            })
        }
      })
    },
    updateQuestion() {
      this.$refs['editQuestionForm'].validate((valid) => {
        if (valid) {
          this.axios
            .post(
              requestUrls['updateQuestionUrl'],
              Qs.stringify(this.getEditQuestionParams())
            )
            .then((response) => {
              if (response['data']) {
                this.$message.info('更新回访话术问题成功!')
                this.closeDialog()
                this.getQuestions()
              } else {
                this.$message.error('更新回访话术问题失败!')
              }
            })
            .catch((e) => {
              console.log(e)
              this.$message.error('更新回访话术问题发生异常!')
            })
        }
      })
    },
    fillQuestionModel(question) {
      if (question) {
        this.editQuestionModel.questionName = question['questionName']
        this.editQuestionModel.questionKeyword = question['questionKeyword']
        this.editAnswers = []
        for (let i = 0; i < question['answers'].length; i++) {
          let ele = {
            answerOutPut: question['answers'][i]['answerOutPut'],
            answerKeyword: question['answers'][i]['answerKeyword'],
          }
          this.editAnswers.push(ele)
        }
      } else {
        this.editAnswers = []
      }
    },
    showEditQuestion(row, editType) {
      this.editQuestion = row
      this.editQuestionType = editType
      if (editType === 'edit') {
        this.editQuestionTitle = '编辑问题'
      } else if (editType == 'watch') {
        this.editQuestionTitle = '查看问题'
      } else {
        this.editQuestionTitle = '保存问题'
        if (this.$refs['editQuestionForm']) {
          this.$refs['editQuestionForm'].resetFields()
        }
        this.editQuestionModel.questionName = ''
        this.editQuestionModel.questionKeyword = ''
      }
      this.fillQuestionModel(row)
      this.editQuestionShow = true
    },
    addAnswer(index) {
      let answers = this.editAnswers
      answers.splice(index + 1, 0, { answerOutPut: '', answerKeyword: '' })
    },
    removeAnswer(index) {
      let answers = this.editAnswers
      answers.splice(index, 1)
    },
    insertQuestion(token) {
      if (token === '()') {
        this.editQuestionModel.questionKeyword =
          '(' + this.editQuestionModel.questionKeyword + ')'
      } else {
        this.editQuestionModel.questionKeyword += ' ' + token + ' '
      }
    },
    insertAnswer(index, token) {
      let keyword = this.editAnswers[index]['answerKeyword']
      if (token === '()') {
        this.editAnswers[index]['answerKeyword'] = '(' + keyword + ')'
      } else {
        this.editAnswers[index]['answerKeyword'] = keyword + ' ' + token + ' '
      }
    },
  },
}
</script>
