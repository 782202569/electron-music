<template>
  <el-form
    ref="returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Ref"
    :inline="true"
    :rules="returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Rules"
    :model="returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model"
    label-width="84px"
  >
    <h3>录音属性</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item
          prop="sysAutoScore_Min"
          style="color:#8691a5"
          label="系统自动评分值"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.sysAutoScore_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="sysAutoScore_Max"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.sysAutoScore_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="callId" style="color:#8691a5" label="录音编号"
          ><el-input
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.callId
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="callNo" style="color:#8691a5" label="主叫号码"
          ><el-input
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.callNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="calledNo" style="color:#8691a5" label="被叫号码"
          ><el-input
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.calledNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="6"
        ><el-form-item prop="extenNo" style="color:#8691a5" label="分机号码"
          ><el-input
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.extenNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="24"
        ><el-form-item prop="callTime_Min" style="color:#8691a5" label="通话时长"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.callTime_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="callTime_Max"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.callTime_Max
            "
            placeholder=""
          ></el-input></el-form-item
        ><el-form-item prop="callId"
          ><el-select
            style="width:120px;margin-left:10px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.timeType
            "
            placeholder="请选择"
          >
            <el-option label="秒" value="2"></el-option
            ><el-option label="分" value="1"></el-option
            ><el-option label="时" value="0"></el-option></el-select
        ></el-form-item> </el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>员工属性</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item prop="seatNo" style="color:#8691a5" label="坐席工号"
          ><el-input
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.seatNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="seatName" style="color:#8691a5" label="坐席姓名"
          ><el-input
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.seatName
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="seatStar" style="color:#8691a5" label="坐席星级"
          ><el-select
            style="width:160px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.seatStar
            "
            placeholder="请选择"
            id="seatStar"
          ></el-select></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="deptId" style="color:#8691a5" label="坐席组"
          ><el-select
            style="width:160px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.deptId
            "
            placeholder="请选择"
            id="seatGroup"
            ><el-option
              label=""
              v-for="item in seatGroupOptions"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option></el-select></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>客户属性</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item prop="customerNo" style="color:#8691a5" label="客户帐号"
          ><el-input
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.customerNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="customerName" style="color:#8691a5" label="客户姓名"
          ><el-input
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.customerName
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="certNo" style="color:#8691a5" label="证件号码"
          ><el-input
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.certNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>语音特征</h3>
    <el-row
      ><el-col :span="6"
        ><el-form-item prop="moodScore_Min" style="color:#8691a5" label="情绪分值"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.moodScore_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="moodScore_Max"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.moodScore_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="silenceLong_Min" style="color:#8691a5" label="静默时长"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.silenceLong_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="silenceLong_Max"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.silenceLong_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="avgSpeed_Min" style="color:#8691a5" label="平均语速"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.avgSpeed_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="avgSpeed_Max"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.avgSpeed_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="silencePer_Min" style="color:#8691a5" label="静默占比"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.silencePer_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="silencePer_Max"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.silencePer_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="6"
        ><el-form-item prop="overLap_Min" style="color:#8691a5" label="重叠次数"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.overLap_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="overLap_Max"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.overLap_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col
      ><el-col :span="6"
        ><el-form-item prop="silenceCount_Min" style="color:#8691a5" label="静默次数"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.silenceCount_Min
            "
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="silenceCount_Max"
          ><el-input
            style="width:55px"
            v-model="
              returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model.silenceCount_Max
            "
            placeholder=""
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row
  ></el-form>
</template>

<script>
import Qs from 'qs'
import global from '@/global.js'

const currentBaseUrl = global.currentBaseUrl

var validateFunc = function() {}
export default {
  data() {
    return {
      seatGroupOptions: [], // 坐席组

      returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model: {
        sysAutoScore_Min: '',
        sysAutoScore_Min$CName: '系统自动评分值(最小值)',
        sysAutoScore_Max: '',
        sysAutoScore_Max$CName: '系统自动评分值(最大值)',
        callId: '',
        callId$CName: '录音编号',
        callNo: '',
        callNo$CName: '主叫号码',
        calledNo: '',
        calledNo$CName: '被叫号码',
        extenNo: '',
        extenNo$CName: '分机号码',
        callTime_Min: '',
        callTime_Min$CName: '通话时长(最小值)',
        callTime_Max: '',
        callTime_Max$CName: '通话时长(最大值)',
        seatNo: '',
        seatNo$CName: '坐席工号',
        seatName: '',
        seatName$CName: '坐席姓名',
        seatStar: '',
        seatStar$CName: '坐席星级',
        deptId: '',
        deptId$CName: '坐席组',
        customerNo: '',
        customerNo$CName: '客户帐号',
        customerName: '',
        customerName$CName: '客户姓名',
        certNo: '',
        certNo$CName: '证件号码',
        moodScore_Min: '',
        moodScore_Min$CName: '情绪分值(最小值)',
        moodScore_Max: '',
        moodScore_Max$CName: '情绪分值(最大值)',
        silenceLong_Min: '',
        silenceLong_Min$CName: '静默时长(最小值)',
        silenceLong_Max: '',
        silenceLong_Max$CName: '静默时长(最大值)',
        avgSpeed_Min: '',
        avgSpeed_Min$CName: '平均语速(最小值)',
        avgSpeed_Max: '',
        avgSpeed_Max$CName: '平均语速(最大值)',
        silencePer_Min: '',
        silencePer_Min$CName: '静默占比(最小值)',
        silencePer_Max: '',
        silencePer_Max$CName: '静默占比(最大值)',
        overLap_Min: '',
        overLap_Min$CName: '重叠次数(最小值)',
        overLap_Max: '',
        overLap_Max$CName: '重叠次数(最大值)',
        silenceCount_Min: '',
        silenceCount_Min$CName: '静默次数(最小值)',
        silenceCount_Max: '',
        silenceCount_Max$CName: '静默次数(最大值)',
      },
      returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Rules: {},
    }
  },
  mounted() {
    this.getSeatGroupValue()
  },
  methods: {
    getSeatGroupValue() {
      let _this = this
      let url = currentBaseUrl + '/pageConstant/getValue.do'
      let searchParam = {}
      searchParam.keys = 'seatGroup'
      this.axios
        .post(url, Qs.stringify(searchParam))
        .then(function(response) {
          _this.seatGroupOptions = response.data.seatGroup
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取常量值出现问题',
          })
        })
    },
  },
}
</script>

<style></style>
