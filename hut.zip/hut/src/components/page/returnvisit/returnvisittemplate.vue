<template>
  <div style="width:100%;height:100%;">
    <div v-show="!questionPageShow">
      <div class="ietemplate-header">
        <el-button
          funcId="000252"
          style="float: right;margin-right: 5px;margin-top: 5px"
          @click="batchRemove"
          >批量删除</el-button
        >
        <el-button
          funcId="000253"
          style="float: right;margin-right: 10px;margin-top: 5px"
          type="primary"
          @click="showSaveTemplateModal"
        >
          新建
        </el-button>
      </div>
      <div>
        <div style="overflow: auto;width: 100%;height: 650px">
          <el-table
            :data="returnVisitTemplates"
            border
            style="width: 100%;"
            id="modelId"
            @selection-change="handleSelectionChange"
            ref="templateTable"
          >
            <el-table-column type="selection" width="55px"></el-table-column>
            <el-table-column prop="templateName" label="模板名称"></el-table-column>
            <el-table-column prop="createUserName" label="创建人"></el-table-column>
            <el-table-column
              prop="createTime"
              :formatter="formatDate"
              label="创建时间"
            ></el-table-column>
            <el-table-column label="操作" show-overflow-tooltip>
              <template scope="scope">
                <i
                  funcId="000401"
                  class="el-icon-edit"
                  style="cursor:pointer;margin-right:10px;"
                  @click="showQuestionPage(scope.row, 'edit')"
                >
                  <i
                    style="font-family: '微软雅黑';margin-left:4px;"
                    @click="showQuestionPage(scope.row, 'edit')"
                    >编辑</i
                  >
                </i>
                <i
                  funcId="000403"
                  class="el-icon-edit"
                  style="cursor:pointer;margin-right:10px;"
                  @click="showUpdateTemplateNameModal(scope.row)"
                >
                  <i
                    style="font-family: '微软雅黑';margin-left:4px;"
                    @click="showUpdateTemplateNameModal(scope.row)"
                    >修改模板名称</i
                  >
                </i>
                <i
                  funcId="000402"
                  class="el-icon-close"
                  style="cursor:pointer;margin-right:10px;font-size:12px;"
                  @click="removeOneTemplate(scope.row)"
                >
                  <i
                    style="font-family: '微软雅黑';margin-left:5px;font-size:14px;"
                    @click="removeOneTemplate(scope.row)"
                    >删除</i
                  >
                </i>
                <i
                  class="el-icon-search"
                  style="cursor:pointer;margin-right:10px;"
                  @click="showQuestionPage(scope.row, 'watch')"
                >
                  <i
                    style="font-family: '微软雅黑';margin-left:4px;"
                    @click="showQuestionPage(scope.row, 'watch')"
                    >查看</i
                  >
                </i>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div>
          <div style="float: right;margin-top: 10px;margin-right: 10px" class="page">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page.sync="pageNumber"
              :page-size="pageSize"
              :page-sizes="[10, 20, 30, 40]"
              layout="total, sizes, prev, pager, next, jumper"
              :total="totalTemplatesCount"
            >
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
    <vTemplate
      v-if="questionPageShow"
      v-on:send="showTemplatePage"
      :templateData="editTemplate"
      :editType="editType"
    ></vTemplate>
    <el-dialog
      title="新建回访话术模板"
      :visible.sync="addTemplateShow"
      @close="closeDialog"
    >
      <el-form
        :model="form"
        :rules="formRules"
        ref="saveTemplateForm"
        labelPosition="left"
      >
        <el-form-item label="模板名称" prop="templateName" class="demo-ruleForm">
          <el-input v-model="form.templateName"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeDialog">取 消</el-button>
        <el-button type="primary" @click="saveTemplate">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="更新回访话术模板名称"
      :visible.sync="updateTemplateNameShow"
      @close="closeDialog"
    >
      <el-form
        :model="updateNameForm"
        :rules="formRules"
        ref="updateTemplateNameForm"
        labelPosition="left"
      >
        <el-form-item label="模板名称" prop="oldTemplateName" class="demo-ruleForm">
          <el-input disabled v-model="updateNameForm.oldTemplateName"></el-input>
        </el-form-item>
        <el-form-item label="新模板名称" prop="newTemplateName" class="demo-ruleForm">
          <el-input v-model="updateNameForm.newTemplateName"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="closeDialog">取 消</el-button>
        <el-button type="primary" @click="updateTemplateName">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<style scoped lang="less">
.ietemplate-header {
  box-sizing: border-box;
  top: 5px;
  width: 100%;
  height: 50px;
  border-bottom: 1px dashed #d1dbe7;
}

.page {
  position: absolute;
  left: 0;
  right: 5px;
  bottom: 0;
  text-align: right;
}
</style>

<script type="text/ecmascript-6">
import vTemplate from './rvtquestion.vue'
import global from '../../../global.js'
import formatdate from '../../../utils/formatdate.js'
import commonUtil from '../../../utils/commonUtil.js'
import Qs from 'qs'
let currentBaseUrl = global.currentBaseUrl
let baseUrl = currentBaseUrl + '/rvtemplate/'
let requestUrls = {
  getTemplatesUrl: baseUrl + 'getTemplates.do',
  deleteTemplateUrl: baseUrl + 'batchRemoveTemplates.do',
  saveTemplateUrl: baseUrl + 'saveTemplate.do',
  updateTemplateNameUrl: baseUrl + 'updateTemplateName.do',
}

export default {
  components: {
    vTemplate,
  },
  mounted() {
    this.getTemplates()
  },
  data() {
    return {
      returnVisitTemplates: [],
      pageNumber: 1,
      pageSize: 10,
      totalTemplatesCount: 0,
      selectedTemplates: [],
      addTemplateShow: false,
      updateTemplateNameShow: false,
      templateName: '',
      formRules: {
        templateName: [
          { required: true, message: '模板名称不能为空!', trigger: 'blur,change' },
        ],
        newTemplateName: [
          { required: true, message: '新模板名称不能为空!', trigger: 'blur,change' },
        ],
      },
      form: {
        templateName: '',
      },
      updateNameForm: {
        newTemplateName: '',
        oldTemplateName: '',
        templateId: '',
      },
      questionPageShow: false,
      editTemplate: null,
      editType: 'edit',
    }
  },
  methods: {
    formatDate(val) {
      return formatdate.formatDate(val['createTime'])
    },
    getTemplates() {
      let params = {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
      }
      let self = this
      this.axios
        .post(requestUrls['getTemplatesUrl'], Qs.stringify(params))
        .then(function(response) {
          let data = response.data
          self.returnVisitTemplates = data['results']
          self.totalTemplatesCount = data['count']
        })
        .catch(function(e) {
          console.log(e)
          self.$message.error('获取回访话术模板发生异常!')
        })
    },
    batchRemoveTemplates(templateIds, removeMessage) {
      if (templateIds.length === 0) {
        this.$message.error('至少选择一个模板进行删除')
        return
      }
      this.$confirm(removeMessage, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        let params = {
          templateStr: templateIds.join(','),
        }
        let self = this
        this.axios
          .post(requestUrls['deleteTemplateUrl'], Qs.stringify(params))
          .then(function(response) {
            if (response.data) {
              self.$message.info('删除成功!')
              self.getTemplates()
            } else {
              self.$message.error('删除失败!')
            }
          })
          .catch(function(e) {
            console.log(e)
            self.$message.error('删除回访话术模板发生异常')
          })
      })
    },
    handleSelectionChange(val) {
      this.selectedTemplates = val
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.pageNumber = 1
      this.getTemplates()
    },
    handleCurrentChange(val) {
      this.pageNumber = val
      this.getTemplates()
    },
    saveTemplate() {
      this.$refs.saveTemplateForm.validate((valid) => {
        if (!valid) {
          return false
        }
        let params = {
          templateName: this.form.templateName,
        }
        if (commonUtil.isBlank(params['templateName'])) {
          this.$message.error('模板名称不能为空')
          return
        }
        this.axios
          .post(requestUrls['saveTemplateUrl'], Qs.stringify(params))
          .then((response) => {
            let data = response.data
            if (data['state'] === '1') {
              this.$message.info('保存成功!')
              this.getTemplates()
              this.addTemplateShow = false
              this.showQuestionPage(data['results'][0], 'edit')
            } else {
              this.$message.error(data['message'])
            }
          })
          .catch((e) => {
            console.log(e)
            this.$message.error('保存回访话术模板发生异常')
          })
      })
    },
    updateTemplateName() {
      this.$refs.updateTemplateNameForm.validate((valid) => {
        if (!valid) {
          return false
        }
        let params = {
          newTemplateName: this.updateNameForm.newTemplateName,
          templateId: this.updateNameForm.templateId,
        }
        this.axios
          .post(requestUrls['updateTemplateNameUrl'], Qs.stringify(params))
          .then((response) => {
            let data = response['data']
            if (data['state'] === '1') {
              this.$message.info('更新成功!')
              this.getTemplates()
              this.updateTemplateNameShow = false
            } else {
              this.$message.error(data['message'])
            }
          })
          .catch((e) => {
            this.$message.error('更新回访话术模板名称发生异常')
          })
      })
    },
    removeOneTemplate(row) {
      this.batchRemoveTemplates(
        [row['templateId']],
        '你真的要删除【' + row['templateName'] + '】这1个模板吗?'
      )
    },
    batchRemove() {
      let templateIds = []
      this.selectedTemplates.forEach(function(item) {
        templateIds.push(item['templateId'])
      })
      this.batchRemoveTemplates(
        templateIds,
        this.getRemoveMessage(this.selectedTemplates)
      )
    },
    getRemoveMessage(_dataList) {
      let message = '你确定要删除【'
      let dataList = _dataList
      if (dataList.length > 3) {
        dataList = dataList.slice(0, 3)
      }
      let templateNameArr = []
      dataList.forEach(function(e) {
        templateNameArr.push(e['templateName'])
      })
      message += templateNameArr.join(',') + '】'
      if (_dataList.length > 3) {
        message += '等'
      } else {
        message += '这'
      }
      message += _dataList.length + '个模板吗?'
      return message
    },
    showSaveTemplateModal() {
      this.addTemplateShow = true
      if (this.$refs.saveTemplateForm) {
        this.$refs.saveTemplateForm.resetFields()
      }
    },
    showUpdateTemplateNameModal(row) {
      if (this.$refs.updateTemplateNameForm) {
        this.$refs.updateTemplateNameForm.resetFields()
      }
      this.updateNameForm.oldTemplateName = row['templateName']
      this.updateNameForm.templateId = row['templateId']
      this.updateTemplateNameShow = true
    },
    closeDialog() {
      this.updateNameForm.oldTemplateName = ''
      this.updateNameForm.newTemplateName = ''
      this.form.templateName = ''
      this.addTemplateShow = false
      this.updateTemplateNameShow = false
    },
    showQuestionPage(row, editType) {
      this.editTemplate = row
      this.editType = editType
      this.questionPageShow = true
    },
    showTemplatePage() {
      this.questionPageShow = false
    },
  },
}
</script>
