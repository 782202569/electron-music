<template>
  <div>
    <div style="width: 100%;height: 100%" v-if="!showDetailPage">
      <div style="width: 100%;height:50px;border-bottom:1px dashed #d1dbe7;">
        <el-button style="float: right;margin-right: 5px;margin-top: 5px" @click="goBack"
          >返回</el-button
        >
        <el-button
          style="float: right;margin-right: 10px;margin-top: 5px"
          type="primary"
          @click="exportTaskInfo"
          >导出</el-button
        >
        <el-button
          style="float: right;margin-right: 10px;margin-top: 5px"
          @click="showTaskStatsChart"
          >查看图表</el-button
        >
        <el-button
          style="float: right;margin-right: 5px;margin-top: 5px"
          type="primary"
          @click="queryTasks"
          >查询</el-button
        >
        <el-date-picker
          v-model="queryDateRange"
          type="datetimerange"
          placeholder="执行时间"
          align="right"
          style="float: right;margin-right: 5px;margin-top: 5px"
        ></el-date-picker>
      </div>
      <div style="overflow: auto;width: 100%;height: 650px">
        <el-table :data="taskList" border>
          <el-table-column type="index" label="序号"></el-table-column>
          <el-table-column
            prop="taskFinishTime"
            :formatter="formatDate"
            label="完成时间"
          ></el-table-column>
          <el-table-column prop="allRecordCount" label="周期录音数"></el-table-column>
          <el-table-column prop="matchRecordCount" label="合规数"></el-table-column>
          <el-table-column
            prop="matchRatio"
            label="合规率"
            :formatter="getPercentStr"
          ></el-table-column>
          <el-table-column label="操作" show-overflow-tooltip>
            <template scope="scope">
              <i class="el-icon-search" style="cursor:pointer;margin-right:20px;">
                <i
                  style="font-family: '微软雅黑';margin-left:4px;"
                  @click="showTaskDetailPage(scope.row)"
                  >查看</i
                >
              </i>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div>
        <div
          style="float: right;margin-top: 10px;position: absolute;bottom: 0px;right: 0px"
        >
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page.sync="pageNumber"
            :page-size="pageSize"
            :page-sizes="[10, 20, 30, 40]"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalTaskCount"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <rv-task-detail
      :taskModel="queryTaskModel"
      v-on:send="showTaskPage"
      v-if="showDetailPage"
    ></rv-task-detail>
    <el-dialog
      id="taskStatsDialog"
      title="任务执行情况"
      :visible.sync="taskStatsDialogShow"
      :close-on-click-modal="false"
    >
      <div class="chartCondition">
        <el-form :inline="true">
          <el-form-item>
            <el-col :span="11">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                v-model="queryTaskStatStartTime"
                style="width: 100%;"
              ></el-date-picker>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-date-picker
                type="date"
                placeholder="选择日期"
                v-model="queryTaskStatEndTime"
                style="width: 100%;"
              ></el-date-picker>
            </el-col>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="getTaskStatsInfo">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
      <div id="chart_container" style="width: 100%; height: 600px;">
        <p>
          暂无数据
        </p>
      </div>
    </el-dialog>
  </div>
</template>

<script type="text/ecmascript-6">
import rvTaskDetail from '../returnvisit/rvtaskdetail'
import global from '../../../global.js'
import Qs from 'qs'
import formatdate from '../../../utils/formatdate.js'
import commonUtil from '../../../utils/commonUtil'

let currentBaseUrl = global.currentBaseUrl
let baseUrl = currentBaseUrl + '/rvt/'
let requestUrls = {
  queryTasksUrl: baseUrl + 'queryTasks.do',
  exportTaskInfoUrl: baseUrl + 'exportTaskInfo.do',
  getTaskStatsUrl: baseUrl + 'getTaskStatsPerDay.do',
}

export default {
  props: ['projectModel'],
  components: {
    rvTaskDetail,
  },
  data() {
    return {
      queryDateRange: [],
      queryTaskStatStartTime: null,
      queryTaskStatEndTime: null,
      taskList: [],
      pageNumber: 1,
      pageSize: 10,
      totalTaskCount: 0,
      showDetailPage: false,
      queryTaskModel: null,
      taskStatsDialogShow: false,
      chart: null,
    }
  },
  methods: {
    formatDate(val) {
      if (val['taskFinishTime']) {
        return formatdate.formatDate(val['taskFinishTime'])
      } else {
        return '\\'
      }
    },
    getTasks() {
      let params = {
        projectId: this.projectModel['projectId'],
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
      }
      if (this.queryDateRange) {
        if (this.queryDateRange[0]) {
          params['startTime'] = formatdate.formatDate(this.queryDateRange[0])
        }
        if (this.queryDateRange[1]) {
          params['endTime'] = formatdate.formatDate(this.queryDateRange[1])
        }
      }
      this.axios
        .post(requestUrls['queryTasksUrl'], Qs.stringify(params))
        .then((response) => {
          this.taskList = response['data']['results']
          this.totalTaskCount = response['data']['count']
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('查询任务列表发生异常!')
        })
    },
    queryTasks() {
      this.pageNumber = 1
      this.getTasks()
    },
    goBack() {
      this.$emit('send')
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.pageNumber = 1
      this.getTasks()
    },
    handleCurrentChange(val) {
      this.pageNumber = val
      this.getTasks()
    },
    getPercentStr(val) {
      if (commonUtil.isNotBlank(val['matchRatio'])) {
        return (parseFloat(val['matchRatio']) * 100).toFixed(2) + '%'
      }
      return ''
    },
    showTaskPage() {
      this.showDetailPage = false
    },
    showTaskDetailPage(row) {
      this.queryTaskModel = row
      this.showDetailPage = true
    },
    exportTaskInfo() {
      let params = {
        projectId: this.projectModel['projectId'],
      }
      commonUtil.doExport(requestUrls['exportTaskInfoUrl'], params)
    },
    getTaskStatsInfo() {
      let params = {
        projectId: this.projectModel['projectId'],
      }
      if (this.queryTaskStatStartTime) {
        params['startTime'] = formatdate.formatDate(this.queryTaskStatStartTime)
      }
      if (this.queryTaskStatEndTime) {
        params['endTime'] = formatdate.formatDate(this.queryTaskStatEndTime)
      }
      this.axios
        .post(requestUrls['getTaskStatsUrl'], Qs.stringify(params))
        .then((response) => {
          let data = response['data']
          this.createChart(data)
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('查询任务信息发生异常')
        })
    },
    showTaskStatsChart() {
      this.taskStatsDialogShow = true
      this.queryTaskStatStartTime = null
      this.queryTaskStatEndTime = null
      this.getTaskStatsInfo()
    },
    createChart(data) {
      let option = {
        tooltip: {
          trigger: 'axis',
        },
        grid: {
          top: '3%',
          left: '3%',
          right: '50',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: [],
          splitLine: {
            show: true,
          },
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
          },
        },
        series: [
          {
            name: '匹配录音数量',
            type: 'line',
            stack: '总量',
            data: [],
            itemStyle: {
              normal: {
                color: '#50b4ff',
              },
            },
          },
        ],
      }
      let xAxis = []
      let yAxis = []
      if (data && data.length > 0) {
        data.forEach(function(item) {
          xAxis.push(item['day'])
          yAxis.push(item['total_record_count'])
        })
      }
      option.xAxis.data = xAxis
      option.series[0].data = yAxis
      this.$nextTick(() => {
        this.chart = this.$echarts.init(document.getElementById('chart_container'))
        this.chart.setOption(option)
      })
    },
  },
  mounted() {
    this.getTasks()
    if (localStorage.getItem('fromFirst')) {
      localStorage.removeItem('fromFirst')
    } else if (
      this.$route.query.isRootMenu != undefined &&
      !this.$route.query.isRootMenu &&
      this.$store.state.returnVisitConfig.taskId !== '' &&
      this.$store.state.returnVisitConfig.projectId != ''
    ) {
      this.showDetailPage = true
      this.queryTaskModel = {
        taskId: this.$store.state.returnVisitConfig.taskId,
        matchRecordCount: this.$store.state.returnVisitConfig.matchRecordCount,
        allRecordCount: this.$store.state.returnVisitConfig.allRecordCount,
        matchRatio: this.$store.state.returnVisitConfig.matchRatio,
      }
      this.queryProjectModel = {
        projectId: this.$store.state.returnVisitConfig.projectId,
      }
    }
  },
}
</script>
