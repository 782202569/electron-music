<template>
  <div id="newtask">
    <div class="attrs">
      <el-form
        label-width="100px"
        :model="editProjectForm"
        ref="editProjectForm"
        :rules="editProjectRules"
      >
        <div class="audioAttrs_part taskAttrs">
          <h3>
            任务属性
          </h3>
          <div class="audioAttrsInputs">
            <el-col :span="6">
              <el-form-item label="任务名称" prop="projectName">
                <el-input
                  v-model="editProjectForm.projectName"
                  :disabled="dialogType == 'edit'"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="匹配模板" prop="templateId">
                <el-select
                  v-model="editProjectForm.templateId"
                  clearable
                  placeholder="请选择"
                >
                  <el-option
                    v-for="item in templates"
                    :key="item.templateId"
                    :label="item.templateName"
                    :value="item.templateId"
                  >
                  </el-option>
                </el-select>
                <i class="el-icon-setting setting" @click="gotoSetting"></i>
              </el-form-item>
            </el-col>
            <el-col :span="4">
              <el-form-item label="运行周期" prop="runCycle">
                <el-input
                  v-model="editProjectForm.runCycle"
                  size="tiny"
                  type="number"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="4">
              <el-form-item label="采集周期" prop="gatherCycle">
                <el-input v-model="editProjectForm.gatherCycle" type="number"></el-input>
              </el-form-item>
            </el-col>
          </div>
        </div>
        <div>
          <my-comp ref="myComp"></my-comp>
        </div>
      </el-form>
      <div class="btns">
        <el-button type="primary" @click="saveProject">保存</el-button>
        <el-button @click="goBack">返回</el-button>
      </div>
    </div>
  </div>
</template>
<style lang="less" scoped>
#newtask {
  .attrs .audioAttrs_part .audioAttrsInputs .el-form-item label {
    color: #8691a5;
  }
  .attrs {
    .form {
      h3 {
        padding-left: 10px;
        line-height: 30px;
        color: #9dadc2;
        font-weight: normal;
      }
      label {
        color: #8691a5;
      }
      .el-row {
        padding: 0px 10px;
      }
    }
  }
}
</style>
<style scoped="scoped" lang="less">
@border-color: #d1dbe5;
.attrs {
  .audioAttrs_part {
    border-bottom: 1px dashed @border-color;
    overflow: hidden;
    .audioAttrsInputs {
      padding: 10px;
    }
  }
  h3 {
    padding-left: 10px;
    line-height: 30px;
    color: #9dadc2;
    font-weight: normal;
  }
  .btns {
    text-align: right;
    margin-top: 10px;
  }
}

.line {
  text-align: center;
}

.timeline {
  text-align: center;
  margin-top: 5px;
  margin-right: -5px;
}

.unit {
  margin: 0 5px;
}

.setting {
  font-size: 16px;
  color: #8691a5;
  margin: 8px 0px 10px 10px;
  cursor: pointer;
}
</style>
<script type="text/ecmascript-6">
import nativeaxios from 'axios'
import global from '../../../global.js'
import Qs from 'qs'
import $ from 'jquery'
import cache from '@/utils/cache'
import myCompVue from './myComp.vue'
let currentBaseUrl = global.currentBaseUrl
let baseUrl = currentBaseUrl + '/rvp/'
let requestUrls = {
  saveProjectUrl: baseUrl + 'saveProject.do',
  getAllTemplatesUrl: currentBaseUrl + '/rvtemplate/getAllTemplates.do',
}


export default {
  components: {
    'my-comp': myCompVue
    // 'my-comp': (resolve, reject) => {
    //   nativeaxios
    //     .post(
    //       global.formEngineUrl +
    //         '/creating.do?formIds=returnVisitBase,returnVisitSeat,returnVisitCust,returnVisitSF&accessToken=' +
    //         cache.getItem('tgt_id')
    //     )
    //     .then((response) => {
    //       $('body').append(response.data.Validate)
    //       let myHtml = response.data.Html
    //       resolve({
    //         template: myHtml,
    //         data() {
    //           return {
    //             seatGroupOptions: [], // 坐席组
    //             /* eslint-disable */
    //             returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model: JSON.parse(
    //               JSON.stringify(
    //                 returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_
    //               )
    //             ),
    //             returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Rules: returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Rules,
    //             /* eslint-enable */
    //           }
    //         },
    //         mounted() {
    //           this.getSeatGroupValue()
    //         },
    //         methods: {
    //           getSeatGroupValue() {
    //             let _this = this
    //             let url = currentBaseUrl + '/pageConstant/getValue.do'
    //             let searchParam = {}
    //             searchParam.keys = 'seatGroup'
    //             this.axios
    //               .post(url, Qs.stringify(searchParam))
    //               .then(function(response) {
    //                 _this.seatGroupOptions = response.data.seatGroup
    //               })
    //               .catch(function() {
    //                 _this.$message({
    //                   type: 'error',
    //                   message: '获取常量值出现问题',
    //                 })
    //               })
    //           },
    //         },
    //       })
    //     })
    // },
  },
  props: ['projectModel'],
  data() {
    return {
      dialogType: 'add',
      editProjectId: null,
      editProjectForm: {
        projectName: '',
        templateId: '',
        runCycle: '',
        gatherCycle: '',
      }, // 任务属性
      editProjectRules: {
        // 任务属性验证
        projectName: [{ required: true, message: '任务名称不能为空', trigger: 'blur' }],
        templateId: [{ required: true, message: '请选择模板', trigger: 'blur' }],
        runCycle: [{ required: true, message: '请设置运行周期', trigger: 'blur' }],
        gatherCycle: [{ required: true, message: '请设置采集周期', trigger: 'blur' }],
      },
      templates: [],
    }
  },
  methods: {
    getSeatGroupValue() {
      let _this = this
      let url = currentBaseUrl + '/pageConstant/getValue.do'
      let searchParam = {}
      searchParam.keys = 'seatGroup'
      this.axios
        .post(url, Qs.stringify(searchParam))
        .then(function(response) {
          _this.seatGroupOptions = response.data.seatGroup
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取常量值出现问题',
          })
        })
    },
    getModifyParams() {
      let params = {
        strategyJsonStr: '{}',
        projectName: this.editProjectForm.projectName,
        templateId: this.editProjectForm.templateId,
        runCycle: this.editProjectForm.runCycle,
        gatherCycle: this.editProjectForm.gatherCycle,
      }
      let myCompModel = this.$refs['myComp'][
        'returnVisitBase_returnVisitSeat_returnVisitCust_returnVisitSF_Model'
      ]
      params['strategyJsonStr'] = JSON.stringify(myCompModel)
      return params
    },
    saveProject() {
      this.$refs['editProjectForm'].validate((valid) => {
        if (valid) {
          this.axios
            .post(requestUrls['saveProjectUrl'], Qs.stringify(this.getModifyParams()))
            .then((response) => {
              if (response.data['state'] === '1') {
                this.$message.info('保存成功!')
                this.$emit('send')
              } else {
                this.$message.error(response.data['message'])
              }
            })
            .catch((e) => {
              console.log(e)
              this.$message.error('保存配置失败!')
            })
        }
      })
    },
    getTemplates() {
      this.axios
        .post(requestUrls['getAllTemplatesUrl'])
        .then((response) => {
          this.templates = response.data
        })
        .catch((e) => {
          console.log(e)
          this.$message.error('获取回访话术模板出现异常')
        })
    },
    gotoSetting() {
      this.$router.push('/returnVisitTemplate')
    },
    goBack() {
      this.$emit('send')
    },
  },
  mounted() {
    this.getTemplates()
    this.getSeatGroupValue()
    if (this.projectModel) {
      console.log(this.projectModel)
      this.editProjectId = this.projectModel.projectId
      this.editProjectForm.projectName = this.projectModel.projectName
      this.editProjectForm.templateId = this.projectModel.templateId
      this.editProjectForm.runCycle = this.projectModel.runCycle + ''
      this.editProjectForm.gatherCycle = this.projectModel.gatherCycle + ''
    }
  },
}
</script>
