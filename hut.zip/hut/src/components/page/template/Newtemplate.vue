<template>
  <div class="newTemplate">
    <div class="newTemplate-header clearfix fl">
      <el-button class="fr" @click="goBacktem">返回</el-button>
      <el-button
        class="fr"
        type="primary"
        @click="modelSaveThrottle"
        v-show="type != 'checked'"
        >保存</el-button
      >
      <span>新建智能筛选模板</span>
      <span v-show="false"> {{ initValue }} </span>
    </div>
    <div class="newTemplate-name fl clearfix">
      <span class="fl">模板名称</span>
      <el-input
        v-model="input"
        :disabled="true"
        style="width:280px;margin-top:20px;"
        class="fl"
      ></el-input>
      <el-button
        v-show="type != 'checked'"
        icon="el-icon-edit"
        class="el-icon-edit"
        style="margin-top: 20px;margin-left: 10px"
        @click="handleIconClick"
      ></el-button>
    </div>
    <!--编模版辑名称-->
    <el-dialog title="修改模板" :visible.sync="dialogFormVisibleEdit">
      <el-form
        :model="formName"
        :rules="formNameRules"
        ref="formName"
        labelPosition="left"
      >
        <el-form-item
          label="模板名称"
          prop="scriptName"
          class="demo-ruleForm"
          :label-width="formLabelWidth"
        >
          <el-input v-model="formName.scriptName"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisibleEdit = false">取 消</el-button>
        <el-button type="primary" @click="submitFormThrottle">确 定</el-button>
      </div>
    </el-dialog>
    <div class="newTemplate-special fl clearfix" style="width:100%;">
      <span>特征</span>
      <div
        style="padding-left:15px;box-sizing: border-box;border-bottom:1px dashed #d1dae9;width:100%;"
      >
        <el-form
          :inline="true"
          ref="formSpecial"
          :model="formSpecial"
          :rules="formSpecialRules"
          class="demo-form-inline clearfix"
        >
          <el-form-item label="重叠次数" class="w23 fl" prop="overlapMin">
            <el-input
              type="number"
              placeholder="最小次数"
              v-model="formSpecial.overlapMin"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
            --
            <el-input
              type="number"
              placeholder="最大次数"
              v-model="formSpecial.overlapMax"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
          </el-form-item>
          <el-form-item> </el-form-item>
          <el-form-item label="坐席平均语速" class="w26 fl">
            <el-input
              type="number"
              placeholder="最小速度"
              v-model="formSpecial.speedMin"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
            --
            <el-input
              placeholder="最大速度"
              type="number"
              v-model="formSpecial.speedMax"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
          </el-form-item>
          <el-form-item label="静默特征" class="w26 fl">
            <el-select
              v-model="formSpecial.selienceType"
              placeholder="请选择"
              clearable
              :disabled="type == 'checked'"
            >
              <el-option
                v-for="item in silenceTypeData"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item
            label="时长"
            class="w20 fl"
            v-show="this.formSpecial.selienceType == 1"
          >
            <el-input
              type="number"
              placeholder="最小值"
              v-model="formSpecial.selienceLengthMin"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
            --
            <el-input
              type="number"
              placeholder="最大值"
              v-model="formSpecial.selienceLengthMax"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="占比"
            class="w20 fl"
            v-show="this.formSpecial.selienceType == 3"
          >
            <el-input
              type="number"
              placeholder="最小值"
              v-model="formSpecial.silenceRatioMin"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
            --
            <el-input
              placeholder="最大值"
              type="number"
              v-model="formSpecial.silenceRatioMax"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="次数"
            class="w20 fl"
            v-show="this.formSpecial.selienceType == 2"
          >
            <el-input
              type="number"
              placeholder="最小值"
              v-model="formSpecial.silenceTimeMin"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
            --
            <el-input
              type="number"
              placeholder="最大值"
              v-model="formSpecial.silenceTimeMax"
              style="width:80px;"
              :disabled="this.type == 'checked'"
            ></el-input>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div
      class="newTemplate-keyWord-pos"
      style="width:100%;height: 100%;padding-top:240px;box-sizing:border-box;"
    >
      <div class="newTemplate-keyWord" style="width:100%;height:100%;position: relative;">
        <div class="newTemplate-keyWord-header fl">
          <span>关键字</span>
          <el-button
            funcId="000395"
            class="fr"
            @click="numQuiry"
            v-show="type != 'checked'"
            >批量删除</el-button
          >
          <el-button
            funcId="000396"
            class="fr"
            @click="addKeyworld"
            v-show="type != 'checked'"
            >添加关键词</el-button
          >
        </div>
        <div
          class="newTemplate-keyWord-content-pos"
          style="width:100%;height:100%;padding-bottom:80px;padding-top:54px;box-sizing:border-box;"
        >
          <div
            style="width:100%;height:100%;overflow: auto;"
            v-if="this.type == 'edit' || this.type == 'newFile'"
          >
            <el-table
              id="newTemmodel"
              @selection-change="handleSelectionChange"
              ref="multipleTable"
              :data="tableData"
              border
              style="width: 100%"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column prop="keywordContext" label="关键词"> </el-table-column>
              <el-table-column prop="fullScriptRole" label="角色">
                <template scope="scope">
                  <i v-if="scope.row.fullScriptRole == 2">客服</i>
                  <i v-else-if="scope.row.fullScriptRole == 1">客户</i>
                  <i v-else>全部</i>
                </template>
              </el-table-column>
              <el-table-column prop="note" label="备注"> </el-table-column>
              <el-table-column prop="teloperate" label="操作" show-overflow-tooltip>
                <template scope="scope">
                  <i
                    funcId="000397"
                    class="el-icon-edit"
                    style="cursor:pointer;margin-right:20px;"
                    @click="tapeEdit(scope.$index, scope.row)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;">编辑</i></i
                  >
                  <i
                    funcId="000398"
                    class="el-icon-close"
                    style="cursor:pointer;margin-right:20px;font-size:12px;"
                    @click="tapeClose(scope.$index, scope.row)"
                    ><i style="font-family: '微软雅黑';margin-left:5px;font-size:14px;"
                      >删除</i
                    ></i
                  >
                  <i
                    class="el-icon-search"
                    style="cursor:pointer;margin-right:20px;"
                    @click="tapeSearch(scope.$index, scope.row)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;">查看</i></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div style="width:100%;height:100%;overflow: auto;" v-else>
            <el-table
              id="newTemmodelself"
              @selection-change="handleSelectionChange"
              ref="multipleTable"
              :data="tableData"
              border
              style="width: 100%"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column prop="keywordContext" label="关键词"> </el-table-column>
              <el-table-column prop="note" label="备注"> </el-table-column>
              <el-table-column prop="fullScriptRole" label="角色">
                <template scope="scope">
                  <i v-if="scope.row.fullScriptRole == 2">客服</i>
                  <i v-else-if="scope.row.fullScriptRole == 1">客户</i>
                  <i v-else>全部</i>
                </template>
              </el-table-column>
              <el-table-column prop="teloperate" label="操作" show-overflow-tooltip>
                <template scope="scope">
                  <i
                    class="el-icon-search"
                    style="cursor:pointer;margin-right:20px;"
                    @click="tapeSearch(scope.$index, scope.row)"
                    ><i style="font-family: '微软雅黑';margin-left:4px;">查看</i></i
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div
          class="newTemplate-keyWord-page"
          style="position: absolute;bottom:0px;width:100%;height:60px;"
        >
          <div class="block fr" style="margin-top: 15px;" v-if="newTeltotal != 0">
            <el-pagination
              class="fr"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page.sync="currentPage1"
              :page-sizes="[10, 20, 30, 40]"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="newTeltotal"
            >
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
    <el-dialog
      title="添加关键词"
      :close-on-click-modal="false"
      :visible.sync="dialogVisible"
      @close="keyWorldQuit"
    >
      <!--form 筛选条件-->
      <el-form
        :model="screeningConditionsForm"
        :rules="screeningConditionsRules"
        ref="screeningConditionsForm"
        class="demo-ruleForm"
      >
        <div>
          <el-form-item class="w-240" label="筛选类型" prop="type">
            <el-select
              class="w-160"
              :disabled="this.keyWorldEdit == 'checked'"
              v-model="screeningConditionsForm.type"
              @change="changeScreeningType"
            >
              <el-option
                v-for="item in screeningConditionsForm.types"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item
            v-if="this.onlyKeyword == true"
            class="w-240"
            label="静默类型"
            prop="silenceType"
          >
            <el-select
              class="w-160"
              :disabled="this.keyWorldEdit == 'checked'"
              v-model="screeningConditionsForm.silenceType"
              placeholder="请选择"
            >
              <el-option
                v-for="item in screeningConditionsForm.silenceTypes"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item
            v-if="this.onlyKeyword == true && screeningConditionsForm.silenceType == '1'"
            class="w-218"
            label="数量"
            prop="silenceTimeMin"
          >
            <el-input
              type="number"
              class="w-78"
              :disabled="this.keyWorldEdit == 'checked'"
              v-model="screeningConditionsForm.silenceTimeMin"
            ></el-input>
            --
            <el-input
              type="number"
              class="w-78"
              :disabled="this.keyWorldEdit == 'checked'"
              v-model="screeningConditionsForm.silenceTimeMax"
            ></el-input>
          </el-form-item>
        </div>
        <div>
          <el-form-item
            v-if="this.onlyKeyword == true"
            class="w-138"
            label="场景"
            prop="sceneTime"
          >
            <el-input
              type="number"
              class="w-67"
              :disabled="this.keyWorldEdit == 'checked'"
              v-model="screeningConditionsForm.sceneTime"
            ></el-input>
            次
          </el-form-item>
          <el-form-item v-if="this.onlyKeyword == true" prop="sceneType">
            <el-select
              :disabled="this.keyWorldEdit == 'checked'"
              class="w-97"
              v-model="screeningConditionsForm.sceneType"
            >
              <el-option
                v-for="(item, index) in screeningConditionsForm.sceneTypes"
                :key="index"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item
            v-if="this.onlyKeyword == true"
            class="w-240"
            label="场景数值"
            prop="sceneValue"
          >
            <el-input
              class="w-160"
              type="number"
              :disabled="this.keyWorldEdit == 'checked'"
              v-model="screeningConditionsForm.sceneValue"
              placeholder="请输入数值"
            ></el-input>
          </el-form-item>
          <el-form-item
            v-if="this.onlyKeyword == true"
            class="w-138"
            prop="sceneValueType"
          >
            <el-select
              :disabled="this.keyWorldEdit == 'checked'"
              class="w-65"
              v-model="screeningConditionsForm.sceneValueType"
            >
              <el-option
                v-for="item in screeningConditionsForm.sceneNumTimes"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </div>
      </el-form>
      <div id="addKey" style="position:relative">
        <div class="keyWorld">
          <span class="xingDot">*</span>
          <span style="height:260px;" class="keyzuhe">关键词组合</span>
          <div style="margin-left:95px;height:260px;">
            <textarea
              id="keywordZuhe"
              style="width:100%;height:260px;border:1px solid #ddd;border-radius:4px;padding-left:10px;padding-top:10px;box-sizing:border-box;padding-bottom:50px"
              :disabled="this.keyWorldEdit == 'checked'"
              v-model="keywordContext"
            ></textarea>
            <div
              style="height:25px;position:absolute;bottom:1px;left:96px;right:6px;padding-top:3px;background:#fff;border-radio:3px"
              id="keyWorldpos"
            >
              <span class="spanStyle" @click="insertAtCursor('OR')">OR</span>
              <span class="spanStyle" @click="insertAtCursor('AND')">AND</span>
              <span class="spanStyle" @click="insertAtCursor('NOT')">NOT</span>
              <span class="spanStyle" @click="insertAtCursor('NEAR')">NEAR</span>
              <span class="spanStyle" @click="insertAtCursor('BEFORE')">BEFORE</span>
              <span class="spanStyle" @click="insertAtCursor('AFTER')">AFTER</span>
              <span class="spanStyle" @click="insertAtCursor('()')">()</span>
              <el-radio-group
                :disabled="this.keyWorldEdit == 'checked'"
                v-model="fullScriptRole"
                style="display:inline-block;margin-left:5px;"
              >
                <el-radio :label="0">全部</el-radio>
                <el-radio :label="2">客服</el-radio>
                <el-radio :label="1">客户</el-radio>
              </el-radio-group>
            </div>
          </div>
        </div>
        <span
          style="display: block;height: 50px;width:100%;text-align: right;line-height: 50px;"
          ><span
            style="color:#505962;border-bottom: 1px solid #505962;font-size:14px;cursor: pointer;"
            @click="showkeyRules"
            >术语规则</span
          ></span
        >
        <div class="keyBeizhu">
          <span style="height:174px;" class="keyzuhe">备注</span>
          <div style="margin-left:85px;height:174px;">
            <!-- <el-input type="textarea" :rows="7" :disabled="this.keyWorldEdit=='checked'" :value="note"></el-input> -->
            <textarea
              style="width:100%;height:174px; border:1px solid #ddd;border-radius:4px;box-sizing:border-box;padding-left:10px;padding-top:10px;"
              id="getNote"
              :disabled="this.keyWorldEdit == 'checked'"
              v-model="note"
            ></textarea>
          </div>
        </div>
        <div
          id="keyRules"
          style="position: absolute;background: #fff"
          v-show="showKeyRules"
        >
          1."AND"关键字表示"与"的关系，可以匹配到同时存在关键字左右两个关键词<br />
          2."OR"关键字表示"或"的关系，可以匹配到存在关键字左右其中至少一个关键词<br />
          3."NOT"关键字表示"非"的关系，可以匹配到存在不存在关键字右侧的关键词<br />
          4."BEFORE"关键字表示有先后顺序"临近"的关系，可以匹配到存在关键字右侧的关键词且之前的n个词内会存在关键字左侧的关键词<br />
          5."AFTER"关键字表示有先后顺序"临近"的关系，可以匹配到存在关键字右侧的关键词且之前的n个词内会存在关键字左侧的关键词<br />
          6."NEAR"关键词表示有临近关系<br />
          7."()"可以在括号中使用以上关键字并提高关键字的匹配优先级<br />
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="keyWorldQuit">取 消</el-button>
        <el-button type="primary" @click="keyWorldSave" v-show="showSure"
          >确 定</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>
<style scoped lang="less">
.newTemplate {
  width: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .newTemplate-header {
    box-sizing: border-box;
    top: 0px;
    width: 100%;
    height: 58px;
    border-bottom: 1px dashed #d1dbe7;
  }
  .newTemplate-header .el-button,
  .newTemplate-keyWord .newTemplate-keyWord-header .el-button {
    margin-top: 10px;
    width: 100px;
    margin-left: 10px;
    font-family: '微软雅黑';
  }
  .newTemplate-header span {
    display: inline-block;
    height: 58px;
    line-height: 58px;
    font-size: 14px;
    color: #6e798b;
  }
  .newTemplate-name {
    width: 100%;
    height: 72px;
    border-bottom: 1px dashed #d1dbe7;
  }
  .newTemplate-name span {
    display: inline-block;
    height: 72px;
    line-height: 72px;
    font-size: 14px;
    padding: 0 13px;
    box-sizing: border-box;
  }
  .newTemplate-special span {
    display: block;
    padding: 18px 0px;
    box-sizing: border-box;
    font-size: 14px;
  }
  .newTemplate-keyWord .newTemplate-keyWord-header {
    width: 100%;
    height: 54px;
  }
  .newTemplate-keyWord .newTemplate-keyWord-header span {
    display: inline-block;
    height: 54px;
    line-height: 54px;
    font-size: 14px;
  }
  #addKey .keyBeizhu span,
  #addKey .keyWorld span.xingDot {
    width: 8px;
    text-align: right;
    float: left;
    font-size: 14px;
    color: #ff4949;
  }
  #addKey .keyBeizhu span,
  #addKey .keyWorld span.keyzuhe {
    width: 80px;
    text-align: right;
    float: left;
    font-size: 14px;
    color: #8691a3;
  }
  .keyWorld {
    position: relative;
  }
  .addkeyFooter .el-button {
    margin-top: 10px;
    width: 100px;
    margin-left: 10px;
    font-family: '微软雅黑';
  }
  #addKey #keyRules {
    padding: 20px 25px 30px 18px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 1500px) {
    #addKey #keyRules {
      width: 400px;
      height: 380px;
      border: 1px solid #bfcbd9;
      box-shadow: 2px 2px 2px 2px #f4f4f4;
      top: 48%;
      right: 70px;
      transform: translateY(-50%);
    }

    #addKey #keyRules::before {
      content: '';
      height: 15px;
      position: absolute;
      width: 15px;
      background: #fff;
      top: 62%;
      right: -7px;
      transform: rotate(45deg);
      border-top: 1px solid #bfcbd9;
      border-right: 1px solid #bfcbd9;
    }
  }
  @media screen and (max-width: 2000px) and (min-width: 1500px) {
    #addKey #keyRules {
      width: 466px;
      height: 400px;
      border: 1px solid #bfcbd9;
      box-shadow: 2px 2px 2px 2px #f4f4f4;
      top: 43%;
      left: 39%;
      transform: translateY(-50%);
    }

    #addKey #keyRules::before {
      content: '';
      height: 15px;
      position: absolute;
      width: 15px;
      background: #fff;
      top: 43%;
      right: -7px;
      transform: rotate(45deg);
      border-top: 1px solid #bfcbd9;
      border-right: 1px solid #bfcbd9;
    }
  }
  .spanStyle {
    display: inline-block;
    border: 1px solid #ddd;
    text-align: center !important;
    width: 55px !important;
    margin-left: 3px;
    border-radius: 4px;
    cursor: pointer;
  }
  .el-input.w-65 {
    width: 65px;
  }
  .el-input.w-67 {
    width: 67px;
  }
  .el-input.w-78 {
    width: 78px;
  }
  .el-input.w-160 {
    width: 160px;
  }
  .el-select.w-65 {
    width: 65px;
  }
  .el-select.w-97 {
    width: 97px;
  }
  .el-select.w-160 {
    width: 160px;
  }
  .el-form-item {
    display: inline-block;
  }
  .el-form-item.w-240 {
    width: 240px;
  }
  .el-form-item.w-218 {
    width: 218px;
  }
  .el-form-item.w-138 {
    width: 138px;
  }
}
</style>
<style>
.newTemplate {
  #newTemmodelself,
  #newTemmodel {
    background: #fff;
    border: none;
  }

  #newTemmodelself table,
  #newTemmodel table {
    border-left: 1px solid #dfe6ec;
  }

  #newTemmodelself .el-table__body-wrapper,
  #newTemmodel .el-table__body-wrapper {
    overflow-x: hidden;
  }

  @media screen and (min-height: 769px) {
    #newTemmodelself .el-table__body-wrapper,
    #newTemmodel .el-table__body-wrapper {
      height: 400px;
    }
  }

  @media screen and (max-height: 768px) and (min-height: 650px) {
    #newTemmodelself .el-table__body-wrapper,
    #newTemmodel .el-table__body-wrapper {
      height: 200px;
    }
  }

  @media screen and (max-height: 649px) {
    #newTemmodelself .el-table__body-wrapper,
    #newTemmodel .el-table__body-wrapper {
      height: 90px;
    }
  }
}
</style>
<script>
import $ from 'jquery'
import Qs from 'qs'
import bus from './bus.js'
import commonUtil from '../../../utils/commonUtil'
// import lodashThrottle from '../../../utils/lodashThrottle.js'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
export default {
  props: ['keywordData', 'doseScriptData', 'type', 'scriptId'],
  data() {
    let validateSilenceTimeMin = (rule, value, callback) => {
      let self = this
      if (
        commonUtil.isBlank(value) &&
        commonUtil.isBlank(self.screeningConditionsForm.silenceTimeMax)
      ) {
        callback(new Error('请至少填写一项'))
      } else if (value > 0 && self.screeningConditionsForm.silenceTimeMax > 0) {
        if (parseInt(value) >= parseInt(self.screeningConditionsForm.silenceTimeMax)) {
          callback(new Error('请输入大于第一项的数值'))
        }
        callback()
      } else if (value < 0 || self.screeningConditionsForm.silenceTimeMax < 0) {
        callback(new Error('请输入大于0的数值'))
      } else if (value == 0 && self.screeningConditionsForm.silenceTimeMax == 0) {
        callback(new Error('请输入大于0的数值'))
      } else {
        callback()
      }
    }
    let validateScene = (rule, value, callback) => {
      if (value <= 0) {
        callback(new Error('请填写正整数'))
      } else {
        callback()
      }
    }
    let validataSceneNum = (rule, value, callback) => {
      if (value <= 0) {
        callback(new Error('请填写正整数'))
      } else {
        callback()
      }
    }
    return {
      onlyKeyword: '',
      onlyDuration: '',
      screeningConditionsForm: {
        types: [{ value: '1', label: '关键词' }, { value: '2', label: '静默关键词' }],
        type: '1',
        silenceTypes: [{ value: '1', label: '时长' }, { value: '2', label: '次数' }],
        silenceType: '1',
        silenceTimeMin: '',
        silenceTimeMax: '',
        sceneTime: '',
        sceneTypes: [{ value: '1', label: '之前' }, { value: '2', label: '之后' }],
        sceneType: '1',
        sceneNumTimes: [{ value: '1', label: '秒' }, { value: '2', label: '句' }],
        sceneValueType: '1',
        sceneValue: '',
      },
      screeningConditionsRules: {
        type: [{ required: true, message: '筛选类型不得为空', trigger: 'blur,change' }],
        silenceType: [
          { required: true, message: '静默类型不得为空', trigger: 'blur,change' },
        ],
        silenceTimeMin: [{ validator: validateSilenceTimeMin, trigger: 'blur,change' }],
        sceneTime: [
          { required: true, message: '请填写', trigger: 'blur,change' },
          { validator: validateScene, trigger: 'blur,change' },
        ],
        sceneType: [{ required: true, message: '请选择', trigger: 'blur,change' }],
        sceneValue: [
          { required: true, message: '场景数值不得为空', trigger: 'blur,change' },
          { validator: validataSceneNum, trigger: 'blur,change' },
        ],
        sceneValueType: [
          { required: true, message: '场景数值时间不得为空', trigger: 'blur,change' },
        ],
      },
      formSpecial: {
        // 特征值；
        overlapMin: '',
        overlapMax: '',
        speedMin: '',
        speedMax: '',
        speecheMoMax: '',
        speecheMoMin: '',
        speechSlient: 'time',
        selienceLengthMin: '', // 静默时长
        selienceLengthMax: '',
        silenceTimeMin: '', // 静默次数
        silenceTimeMax: '',
        silenceRatioMin: '', // 静默占比
        silenceRatioMax: '',
        selienceType: 0,
      },
      formSpecialRules: {
        overlapMin: [],
        overlapMax: [],
        speedMin: [],
        speedMax: [],
        speecheMoMax: [],
        speecheMoMin: [],
        speechSlient: [],
        selienceLengthMin: [], // 静默时长
        selienceLengthMax: [],
        silenceTimeMin: [], // 静默次数
        silenceTimeMax: [],
        silenceRatioMin: [], // 静默占比
        silenceRatioMax: [],
        selienceType: 1,
      },
      silenceTypeData: [
        { id: 0, name: '请选择' },
        { id: 1, name: '时长' },
        { id: 2, name: '次数' },
        {
          id: 3,
          name: '占比',
        },
      ],
      tableData: [],
      currentPage1: 1,
      dialogVisible: false,
      dialogFormVisibleEdit: false,
      input: '', // 模板名称
      newTeltotal: 0,
      pageSize: 10,
      typeParent: '',
      scriptidParent: '',
      showKeyRules: false,
      textarea: '',
      fullScriptRole: 0,
      keyWorldEdit: 'newFile',
      multipleSelection: [],
      keyWorldScriptid: '', // 关键词id
      newFileScriptId: '', // 新建情况下，生成的模板ID
      sliceType: 'time', // 静默类型
      keywordContext: '',
      note: '',
      errorTrue: false,
      inputCopy: '',
      showSure: true, // 确定按钮显示隐藏
      formName: {
        scriptName: '',
      },
      formNameRules: {
        scriptName: [{ required: true, message: '名称不能为空', trigger: 'change,blur' }],
      },
      formLabelWidth: '80px',
      flag: false,
    }
  },
  computed: {
    initValue: function() {
      localStorage.setItem(
        'telplateComputed',
        localStorage.getItem('telplateComputed') + 1
      )
      if (
        localStorage.getItem('telplateComputed') == '11' ||
        localStorage.getItem('telplateComputed') == '1'
      ) {
        localStorage.setItem('telplateInitValue', JSON.stringify(this.formSpecial))
      }
      return JSON.stringify(this.formSpecial)
    },
  },
  mounted: function() {
    this.typeParent = this.type
    if (this.type != 'newFile') {
      // this.keywordData.Data.forEach(function (val, index) {
      //   if (val.fullScriptRole == '0') {
      //     val.fullScriptRole = '全部'
      //   } else if (val.fullScriptRole == '2') {
      //     val.fullScriptRole = '客服'
      //   } else if (val.fullScriptRole == '1') {
      //     val.fullScriptRole = '客户'
      //   }
      // })
      this.tableData = this.keywordData.Data
      this.newTeltotal = this.keywordData.Count
      for (let key in this.doseScriptData) {
        if (this.formSpecial.hasOwnProperty(key)) {
          this.formSpecial[key] = this.doseScriptData[key]
        }
      }
      this.input = this.doseScriptData.scriptName
      this.inputCopy = this.doseScriptData.scriptName
    } else {
      this.input = localStorage.getItem('scriptname')
      this.inputCopy = localStorage.getItem('scriptname')
    }
  },
  methods: {
    isObjectValueEqual: function(obja, objb) {
      let jsonObja = $.parseJSON(obja)
      let jsonObjb = $.parseJSON(objb)

      for (let i = 0; i < Object.keys(jsonObja).length; i++) {
        if (!(jsonObja.overlapMin == jsonObjb.overlapMin)) {
          return false
        }
        if (!(jsonObja.overlapMax == jsonObjb.overlapMax)) {
          return false
        }
        if (!(jsonObja.speedMin == jsonObjb.speedMin)) {
          return false
        }
        if (!(jsonObja.speedMax == jsonObjb.speedMax)) {
          return false
        }
        if (!(jsonObja.speecheMoMax == jsonObjb.speecheMoMax)) {
          return false
        }
        if (!(jsonObja.speecheMoMin == jsonObjb.speecheMoMin)) {
          return false
        }
        if (!(jsonObja.speechSlient == jsonObjb.speechSlient)) {
          return false
        }
        if (!(jsonObja.selienceLengthMin == jsonObjb.selienceLengthMin)) {
          return false
        }
        if (!(jsonObja.selienceLengthMax == jsonObjb.selienceLengthMax)) {
          return false
        }
        if (!(jsonObja.silenceTimeMin == jsonObjb.silenceTimeMin)) {
          return false
        }
        if (!(jsonObja.silenceTimeMax == jsonObjb.silenceTimeMax)) {
          return false
        }
        if (!(jsonObja.silenceRatioMin == jsonObjb.silenceRatioMin)) {
          return false
        }
        if (!(jsonObja.silenceRatioMax == jsonObjb.silenceRatioMax)) {
          return false
        }
        if (!(jsonObja.selienceType == jsonObjb.selienceType)) {
          return false
        }
      }

      return true
    },
    handleSelectionChange: function(val) {
      this.multipleSelection = val
    },
    handleSizeChange: function(val) {
      this.pageSize = val
      this.getKeywordlist()
    },
    handleCurrentChange: function(val) {
      this.currentPage1 = val
      this.getKeywordlist()
    },
    /*
     *添加关键词 选择筛选类型改变处理
     * */
    changeScreeningType: function(value) {
      if (value == '2') {
        this.onlyKeyword = true
        this.keywordContext = ''
        this.note = ''
      }
      if (value == '1') {
        this.onlyKeyword = false
        this.screeningConditionsForm.silenceType = '1'
        this.screeningConditionsForm.silenceTimeMin = ''
        this.screeningConditionsForm.silenceTimeMax = ''
        this.screeningConditionsForm.sceneTime = ''
        this.screeningConditionsForm.sceneType = '1'
        this.screeningConditionsForm.sceneValue = ''
        this.screeningConditionsForm.sceneValueType = '1'
        this.keywordContext = ''
        this.fullScriptRole = 0
        this.note = ''
      }
    },
    /*
     *修改名称
     * */
    handleIconClick: function() {
      this.dialogFormVisibleEdit = true
      this.formName.scriptName = this.input
    },
    submitFormThrottle() {
      this.lodashThrottle.throttle(this.submitForm, this)
    },
    /*
     * 修改名称保存
     * */
    submitForm: function() {
      this.$refs.formName.validate((valid) => {
        if (valid) {
          let prames = {
            fullScriptId: localStorage.getItem('scriptNameId'),
            newScriptName: this.formName.scriptName,
          }
          if (commonUtil.isBlank(prames.newScriptName)) {
            this.$message.error('模板名称不能为空!')
            return
          }
          if (prames.newScriptName == this.input) {
            this.dialogFormVisibleEdit = false
            this.$message({
              type: 'success',
              message: '保存成功!',
            })
            return false
          }
          this.axios
            .post(
              currentBaseUrl + '/filterTemplate/updateDoseScriptName.do',
              Qs.stringify(prames)
            )
            .then((res) => {
              if (res.data.state == '1') {
                this.input = this.formName.scriptName
                this.dialogFormVisibleEdit = false
                this.$message({
                  type: 'success',
                  message: '保存成功!',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: res.data.message,
                })
              }
            })
            .catch(function() {})
        }
      })
    },
    goBacktem() {
      const self = this
      if (
        !this.isObjectValueEqual(
          this.initValue,
          localStorage.getItem('telplateInitValue')
        )
      ) {
        this.$confirm('模板内容有修改，确定退出吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
          .then(() => {
            localStorage.removeItem('telplateComputed')
            localStorage.removeItem('telplateInitValue')
            self.$emit('send', true)
            bus.$emit('emitgetmodels')
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消返回',
            })
          })
      } else {
        self.$emit('send', true)
        bus.$emit('emitgetmodels')
        localStorage.removeItem('telplateComputed')
        localStorage.removeItem('telplateInitValue')
      }
    },
    addKeyworld() {
      // 添加关键词
      this.keyWorldEdit = 'newFile'
      if (this.type == 'newFile') {
        this.newFileScriptId = localStorage.getItem('scriptid')
        let scriptid = localStorage.getItem('scriptid')
        if (!scriptid) {
          this.$message({
            type: 'info',
            message: '当前模板为新创建的模板，请先保存',
          })
          return false
        }
      }
      this.fullScriptRole = 0
      this.keywordContext = ''
      this.note = ''
      this.dialogVisible = true
      this.$nextTick(function() {
        this.$refs.screeningConditionsForm.resetFields()
        this.screeningConditionsForm.type = '1'
        this.screeningConditionsForm.silenceType = '1'
        this.screeningConditionsForm.silenceTimeMin = ''
        this.screeningConditionsForm.silenceTimeMax = ''
        this.screeningConditionsForm.sceneTime = ''
        this.screeningConditionsForm.sceneType = '1'
        this.screeningConditionsForm.sceneValue = ''
        this.screeningConditionsForm.sceneValueType = '1'
      })
      this.showSure = true
      this.onlyKeyword = false
    },

    modelSaveThrottle() {
      this.lodashThrottle.throttle(this.modelSave, this)
    },
    isNotBlank(val) {
      return !this.isBlank(val)
    },
    isBlank(val) {
      return val === null || val === undefined || val.toString().trim() === ''
    },
    isNumber(val) {
      if (this.isBlank(val)) {
        return true
      }
      return !isNaN(val)
    },
    isMinus(val) {
      return this.isNotBlank(val) && parseFloat(val) < 0
    },
    validateSaveParams(params) {
      if (
        this.isNotBlank(params['overlapMin']) &&
        this.isNotBlank(params['overlapMax'])
      ) {
        if (parseFloat(params['overlapMin']) > parseFloat(params['overlapMax'])) {
          return { pass: false, message: '重叠次数低值不能大于重叠次数高值!' }
        }
      }
      if (this.isMinus(params['overlapMin']) || this.isMinus(params['overlapMax'])) {
        return { pass: false, message: '重叠次数不能为负数!' }
      }

      if (this.isNotBlank(params['speedMin']) && this.isNotBlank(params['speedMax'])) {
        if (parseFloat(params['speedMin']) > parseFloat(params['speedMax'])) {
          return { pass: false, message: '平均语速低值不能大于平均语速高值!' }
        }
      }

      if (this.isMinus(params['speedMin']) || this.isMinus(params['speedMax'])) {
        return { pass: false, message: '平均语速不能为负数!' }
      }

      if (this.isNotBlank(params['selienceType'])) {
        let silenceType = params['selienceType']
        if (silenceType == '1') {
          if (
            this.isBlank(params['selienceLengthMin']) &&
            this.isBlank(params['selienceLengthMax'])
          ) {
            return { pass: false, message: '请填写静默时长!' }
          }

          if (
            this.isMinus(params['selienceLengthMin']) ||
            this.isMinus(params['selienceLengthMax'])
          ) {
            return { pass: false, message: '静默时长不能为负数!' }
          }
        } else if (silenceType == '2') {
          if (
            this.isBlank(params['silenceTimeMin']) &&
            this.isBlank(params['silenceTimeMax'])
          ) {
            return { pass: false, message: '请填写静默次数!' }
          }

          if (
            this.isMinus(params['silenceTimeMin']) ||
            this.isMinus(params['silenceTimeMax'])
          ) {
            return { pass: false, message: '静默次数不能为负数!' }
          }
        } else if (silenceType == '3') {
          if (
            this.isBlank(params['silenceRatioMin']) &&
            this.isBlank(params['silenceRatioMax'])
          ) {
            return { pass: false, message: '请填写静默占比!' }
          }

          if (
            this.isMinus(params['silenceRatioMin']) ||
            this.isMinus(params['silenceRatioMax'])
          ) {
            return { pass: false, message: '静默占比不能为负数!' }
          }
        }

        if (
          this.isNotBlank(params['selienceLengthMin']) &&
          this.isNotBlank(params['selienceLengthMax'])
        ) {
          if (
            parseFloat(params['selienceLengthMin']) >
            parseFloat(params['selienceLengthMax'])
          ) {
            return { pass: false, message: '静默时长低值不能大于静默时长高值!' }
          }
        }

        if (
          this.isNotBlank(params['silenceTimeMin']) &&
          this.isNotBlank(params['silenceTimeMax'])
        ) {
          if (
            parseFloat(params['silenceTimeMin']) > parseFloat(params['silenceTimeMax'])
          ) {
            return { pass: false, message: '静默次数低值不能大于静默次数高值!' }
          }
        }

        if (
          this.isNotBlank(params['silenceRatioMin']) &&
          this.isNotBlank(params['silenceRatioMax'])
        ) {
          if (
            parseFloat(params['silenceRatioMin']) > parseFloat(params['silenceRatioMax'])
          ) {
            return { pass: false, message: '静默占比低值不能大于静默占比高值!' }
          }
        }
      }

      let result = {
        pass: true,
        message: '',
      }
      return result
    },
    modelSave() {
      // 新建智能模板保存==>这儿得分两种：直接新建/通过编辑过来
      this.errorTrue = false
      if (!this.input) {
        this.errorTrue = true
        return false
      }
      let fullScriptId = localStorage.getItem('scriptid')
      if (this.type == 'edit') {
        fullScriptId = localStorage.getItem('scriptNameId')
      }
      let selienceLengthMin,
        selienceLengthMax,
        silenceRatioMin,
        silenceRatioMax,
        silenceTimeMin,
        silenceTimeMax
      if (this.formSpecial.selienceType == 1) {
        selienceLengthMin = this.formSpecial.selienceLengthMin
        selienceLengthMax = this.formSpecial.selienceLengthMax
        silenceRatioMin = ''
        silenceRatioMax = ''
        silenceTimeMin = ''
        silenceTimeMax = ''
      } else if (this.formSpecial.selienceType == 2) {
        silenceRatioMin = ''
        silenceRatioMax = ''
        selienceLengthMin = ''
        selienceLengthMax = ''
        silenceTimeMin = this.formSpecial.silenceTimeMin
        silenceTimeMax = this.formSpecial.silenceTimeMax
      } else if (this.formSpecial.selienceType == 3) {
        silenceRatioMin = this.formSpecial.silenceRatioMin
        silenceRatioMax = this.formSpecial.silenceRatioMax
        selienceLengthMin = ''
        selienceLengthMax = ''
        silenceTimeMin = ''
        silenceTimeMax = ''
      }
      let params = {
        fullScriptId: fullScriptId,
        selienceType: this.formSpecial.selienceType,
        selienceLengthMin: selienceLengthMin,
        selienceLengthMax: selienceLengthMax,
        speedMin: this.formSpecial.speedMin,
        speedMax: this.formSpecial.speedMax,
        silenceTimeMin: silenceTimeMin,
        silenceTimeMax: silenceTimeMax,
        silenceRatioMin: silenceRatioMin,
        silenceRatioMax: silenceRatioMax,
        overlapMin: this.formSpecial.overlapMin,
        overlapMax: this.formSpecial.overlapMax,
      }
      let validateRasult = this.validateSaveParams(params)
      if (!validateRasult['pass']) {
        this.$message.warning(validateRasult['message'])
        return
      }
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let self = this
      this.axios
        .post(
          currentBaseUrl + '/filterTemplate/saveScript.do',
          Qs.stringify(params),
          configss
        )
        .then(function(response) {
          if (response.status == 200 && response.data.state == '1') {
            localStorage.setItem('telplateInitValue', JSON.stringify(self.formSpecial))
            if (self.type == 'newFile') {
              self.$message({
                type: 'success',
                message: '模板新建成功',
              })
              self.newFileScriptId = response.data.other.newScript.fullScriptId
            } else {
              self.$message({
                type: 'success',
                message: '模板修改成功',
              })
              let params = {
                scriptId: self.scriptId,
                pageNumber: '1',
                pageSize: '10',
              }

              this.axios
                .post(
                  currentBaseUrl + '/filterTemplate/getAllDoseScriptData.do',
                  Qs.stringify(params),
                  configss
                )
                .then(function(response) {
                  if (response.status == 200) {
                    self.parentKeywordData = response.data.keywordData
                    self.parentDoseScriptData = response.data.doseScriptData
                    self.templateShow = false
                    self.formSpecial.selienceType =
                      response.data.doseScriptData['selienceType']
                  }
                })
                .catch(function() {})
              self.newFileScriptId = ''
            }
            // self.modelSave = false;
          } else if (response.status == 200 && response.data.state == '0') {
            self.$message({
              type: 'error',
              message: response.data.message,
            })
          }
        })
        .catch(function() {})
    },
    getKeywordlist() {
      const self = this
      let configss = {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        },
      }
      let scriptId = this.scriptId
      if (this.type == 'newFile') {
        scriptId = this.newFileScriptId
      }
      let params = {
        scriptId: scriptId,
        pageNumber: this.currentPage1,
        pageSize: this.pageSize,
      }
      self.tableData = []
      this.axios
        .post(
          currentBaseUrl + '/filterTemplate/getAllDoseScriptData.do',
          Qs.stringify(params),
          configss
        )
        .then(function(response) {
          // response.data.keywordData.Data.forEach(function (val, index) {
          //   if (val.fullScriptRole == 0) {
          //     val.fullScriptRole = '全部'
          //   } else if (val.fullScriptRole == 2) {
          //     val.fullScriptRole = '客服'
          //   } else if (val.fullScriptRole == 1) {
          //     val.fullScriptRole = '客户'
          //   }
          // })

          self.tableData = response.data.keywordData.Data
          self.newTeltotal = response.data.keywordData.Count
        })
        .catch(function() {})
    },
    showkeyRules() {
      // 显示术语规则
      this.showKeyRules = !this.showKeyRules
    },
    keyWorldSave() {
      this.$refs.screeningConditionsForm.validate((valid) => {
        if (valid) {
          const self = this
          let configss = {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            },
          }
          if (!this.keywordContext) {
            this.$message({
              type: 'error',
              message: '请填写相关关键词',
            })
            return false
          }
          if (this.keyWorldEdit == 'newFile') {
            let fullScriptId = localStorage.getItem('scriptid')
            if (this.type == 'edit') {
              fullScriptId = localStorage.getItem('scriptNameId')
            }
            let params = {
              fullScriptId: fullScriptId,
              keywordContext: document.getElementById('keywordZuhe').value,
              fullScriptRole: this.fullScriptRole,
              note: this.note,
              type: this.screeningConditionsForm.type,
              silenceType: this.screeningConditionsForm.silenceType,
              silenceTimeMin: this.screeningConditionsForm.silenceTimeMin,
              silenceTimeMax: this.screeningConditionsForm.silenceTimeMax,
              sceneTime: this.screeningConditionsForm.sceneTime,
              sceneType: this.screeningConditionsForm.sceneType,
              sceneValue: this.screeningConditionsForm.sceneValue,
              sceneValueType: this.screeningConditionsForm.sceneValueType,
            }
            if (params['note'] && params['note'].length > 100) {
              this.$message.error('备注长度不能大于100')
              return
            }
            this.axios
              .post(
                currentBaseUrl + '/filterTemplate/saveScriptKeyword.do',
                Qs.stringify(params),
                configss
              )
              .then(function(response) {
                if (response.status == 200) {
                  self.dialogVisible = false
                  self.getKeywordlist()
                }
              })
              .catch(function() {})
            return false
          }
          if (this.keyWorldEdit == 'edit') {
            let params = {
              scriptKeywordId: this.keyWorldScriptid,
              keywordContext: document.getElementById('keywordZuhe').value,
              fullScriptRole: this.fullScriptRole,
              note: this.note,
              type: this.screeningConditionsForm.type,
              silenceType: this.screeningConditionsForm.silenceType,
              silenceTimeMin: this.screeningConditionsForm.silenceTimeMin,
              silenceTimeMax: this.screeningConditionsForm.silenceTimeMax,
              sceneTime: this.screeningConditionsForm.sceneTime,
              sceneType: this.screeningConditionsForm.sceneType,
              sceneValue: this.screeningConditionsForm.sceneValue,
              sceneValueType: this.screeningConditionsForm.sceneValueType,
            }
            if (params['note'] && params['note'].length > 100) {
              this.$message.error('备注长度不能大于100')
              return
            }
            this.axios
              .post(
                currentBaseUrl + '/filterTemplate/updateScriptKeyword.do',
                Qs.stringify(params),
                configss
              )
              .then(function(response) {
                if (response.status == 200) {
                  self.dialogVisible = false
                  self.getKeywordlist()
                }
              })
              .catch(function() {})
            return false
          }
          let fullScriptId = ''
          if (this.type == 'edit') {
            fullScriptId = this.scriptId
          } else if (this.type == 'newFile') {
            fullScriptId = localStorage.getItem('scriptNameId')
          }
          let params = {
            fullScriptId: fullScriptId,
            keywordContext: document.getElementById('keywordZuhe').value,
            fullScriptRole: this.fullScriptRole,
            note: this.note,
          }
          if (params['note'] && params['note'].length > 100) {
            this.$message.error('备注长度不能大于100')
            return
          }
          this.axios
            .post(
              currentBaseUrl + '/filterTemplate/saveScriptKeyword.do',
              Qs.stringify(params),
              configss
            )
            .then(function(response) {
              if (response.status == 200) {
                self.dialogVisible = false
                self.getKeywordlist()
              }
            })
            .catch(function() {})
        }
      })
    },
    insertAtCursor(myValue) {
      let myField = document.getElementById('keywordZuhe')
      // IE 浏览器
      if (document.selection) {
        myField.focus()
        let sel = document.selection.createRange()
        sel.text = myValue
        sel.select()
        // FireFox、Chrome等
      } else if (myField.selectionStart || myField.selectionStart == '0') {
        let startPos = myField.selectionStart
        let endPos = myField.selectionEnd
        // 保存滚动条
        let restoreTop = myField.scrollTop
        myField.value =
          myField.value.substring(0, startPos) +
          ' ' +
          myValue +
          ' ' +
          myField.value.substring(endPos, myField.value.length)
        if (restoreTop > 0) {
          myField.scrollTop = restoreTop
        }
        myField.focus()
        myField.selectionStart = startPos + myValue.length + 2
        myField.selectionEnd = startPos + myValue.length + 2
      } else {
        myField.value += myValue
        myField.focus()
      }
    },
    spanclick(event) {
      let str
      if ($(event.target).html() == '()') {
        str = ' ' + '(' + ' ' + ' ' + ')' + ' '
      } else {
        str = ' ' + $(event.target).html() + ' '
      }
      let valstr = this.keywordContext + str
      this.keywordContext = valstr
      $('#keywordZuhe').focus()
    },
    keyWorldQuit() {
      this.dialogVisible = false
      this.$refs.screeningConditionsForm.resetFields()
      this.keywordContext = ''
      this.note = ''
      this.fullScriptRole = 0
    },
    tapeEdit(index, row) {
      //
      // TODO
      // 此处row要有相应数据
      this.keyWorldEdit = 'edit'
      this.showSure = true
      this.dialogVisible = true
      this.keyWorldScriptid = row.scriptKeywordId
      if (row.type == '1') {
        this.onlyKeyword = false
        this.screeningConditionsForm.type = '1'
        this.screeningConditionsForm.silenceType = '1'
        this.screeningConditionsForm.silenceTimeMin = ''
        this.screeningConditionsForm.silenceTimeMax = ''
        this.screeningConditionsForm.sceneTime = ''
        this.screeningConditionsForm.sceneType = '1'
        this.screeningConditionsForm.sceneValue = ''
        this.screeningConditionsForm.sceneValueType = '1'
      }
      if (row.type == '2') {
        this.onlyKeyword = true
        this.screeningConditionsForm.type = '2'
        this.screeningConditionsForm.silenceType = row.silenceType + ''
        this.screeningConditionsForm.silenceTimeMin = row.silenceTimeMin
        this.screeningConditionsForm.silenceTimeMax = row.silenceTimeMax
        this.screeningConditionsForm.sceneTime = row.sceneTime + ''
        this.screeningConditionsForm.sceneType = row.sceneType + ''
        this.screeningConditionsForm.sceneValue = row.sceneValue + ''
        this.screeningConditionsForm.sceneValueType = row.sceneValueType + ''
      }
      this.keywordContext = row.keywordContext
      this.note = row.note
      this.$nextTick(function() {
        document.getElementById('keywordZuhe').value = row.keywordContext
        document.getElementById('getNote').value = row.note
      })
      this.fullScriptRole = row.fullScriptRole * 1
    },
    tapeClose(index, row) {
      // 关键词删除
      this.$confirm('是否删除选中的关键词【' + row['keywordContext'] + '】？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          const self = this
          let params = {
            keywordIds: row.scriptKeywordId,
          }
          let configss = {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            },
          }
          this.axios
            .post(
              currentBaseUrl + '/filterTemplate/removeKeywords.do',
              Qs.stringify(params),
              configss
            )
            .then(function(response) {
              if (response.status == 200) {
                self.$message({
                  type: 'success',
                  message: '删除成功!',
                })
                self.getKeywordlist()
              }
            })
            .catch(function() {})
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    tapeSearch(index, row) {
      // 关键词查看
      this.screeningConditionsForm.type = ''
      this.showSure = false
      this.dialogVisible = true
      if (this.$refs['screeningConditionsForm']) {
        this.$refs['screeningConditionsForm'].resetFields()
      }
      this.keyWorldScriptid = row.scriptKeywordId
      this.screeningConditionsForm.type = row.type + ''
      if (row.type == 1) {
        this.onlyKeyword = false
      } else {
        this.onlyKeyword = true
        this.screeningConditionsForm.silenceType = row.silenceType + ''
        this.screeningConditionsForm.silenceTimeMin = row.silenceTimeMin
        this.screeningConditionsForm.silenceTimeMax = row.silenceTimeMax
        this.screeningConditionsForm.sceneTime = row.sceneTime
        this.screeningConditionsForm.sceneType = row.sceneType + ''
        this.screeningConditionsForm.sceneValue = row.sceneValue
        this.screeningConditionsForm.sceneValueType = row.sceneValueType + ''
      }
      this.keywordContext = row.keywordContext
      this.note = row.note
      this.$nextTick(function() {
        document.getElementById('keywordZuhe').value = row.keywordContext
        document.getElementById('getNote').value = row.note
      })
      this.fullScriptRole = row.fullScriptRole * 1
      this.keyWorldEdit = 'checked'
    },
    numQuiry() {
      // 批量删除
      if (this.multipleSelection.length == 0) {
        this.$message({
          type: 'info',
          message: '请先选择相关的录音',
        })
        return false
      }
      const self = this
      let messageArr = []
      this.multipleSelection.forEach(function(val) {
        messageArr.push(val['keywordContext'])
      })
      let message = '确定删除【'
      if (messageArr.length <= 3) {
        message += messageArr.join(',')
        message += '】这' + messageArr.length + '个关键词吗?'
      } else {
        let array = messageArr.slice(0, 3)
        message += array.join(',')
        message += '】等' + messageArr.length + '个关键词吗?'
      }

      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let arr = []
          self.multipleSelection.forEach(function(val, index) {
            arr.push(val.scriptKeywordId)
          })
          let params = {
            keywordIds: arr.join(),
          }
          let configss = {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            },
          }

          this.axios
            .post(
              currentBaseUrl + '/filterTemplate/removeKeywords.do',
              Qs.stringify(params),
              configss
            )
            .then(function(response) {
              if (response.status == 200) {
                self.$message({
                  type: 'success',
                  message: '删除成功!',
                })
                self.getKeywordlist()
              }
            })
            .catch(function(error) {
              console.log(error)
            })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
  },
}
</script>
