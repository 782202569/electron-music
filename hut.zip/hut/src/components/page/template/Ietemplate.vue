<template>
  <div style="width:100%;height:100%;" class="letemplateContainer">
    <div class="ietemplate" v-show="templateShow">
      <div class="ietemplate-header">
        <el-button funcId="000248" class="fr" @click="taskResback">批量删除</el-button>
        <el-button funcId="000249" type="primary" class="fr" @click="newtemplate"
          >新建</el-button
        >
        <i
          class="el-icon-d-caret fr"
          @click="sortQuery"
          style="cursor:pointer;margin-top:25px"
          >按时间排序</i
        >
      </div>
      <div class="ietemplate-content">
        <div class="ietemplate-content-pos" style="overflow: auto;">
          <el-table
            id="modelId"
            @selection-change="handleSelectionChange"
            ref="multipleTable"
            :data="tableData"
            border
            style="width: 100%;"
          >
            <el-table-column type="selection" width="55"> </el-table-column>
            <el-table-column prop="modelName" label="模板名称" width="150">
            </el-table-column>
            <el-table-column prop="createUserName" label="创建人" width="150">
            </el-table-column>
            <el-table-column prop="createTime" label="创建时间"> </el-table-column>
            <el-table-column prop="lastUsetime" label="最后使用时间"> </el-table-column>
            <el-table-column
              prop="teloperate"
              label="操作"
              width="400"
              show-overflow-tooltip
            >
              <template scope="scope">
                <i
                  funcId="000371"
                  class="el-icon-edit"
                  style="cursor:pointer;margin-right:20px;"
                  @click="tapeEdit(scope.$index, scope.row)"
                  ><i style="font-family: '微软雅黑';margin-left:4px;">编辑</i></i
                >
                <i
                  funcId="000372"
                  class="el-icon-close"
                  style="cursor:pointer;margin-right:20px;font-size:12px;"
                  @click="tapeClose(scope.$index, scope.row)"
                  ><i style="font-family: '微软雅黑';margin-left:5px;font-size:14px;"
                    >删除</i
                  ></i
                >
                <i
                  funcId="000373"
                  class="el-icon-search"
                  style="cursor:pointer;margin-right:20px;"
                  @click="tapeSearch(scope.$index, scope.row)"
                  ><i style="font-family: '微软雅黑';margin-left:4px;">查看</i></i
                >
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="ietemplate-page">
          <div class="block fr clearfix" v-show="modelTotal != 0">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page.sync="currentPage1"
              :page-sizes="[10, 20, 30, 40]"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="modelTotal"
            >
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
    <vTemplate
      v-if="!templateShow"
      v-on:send="changeshow"
      :keywordData="parentKeywordData"
      :doseScriptData="parentDoseScriptData"
      :type="editType"
      :scriptId="scriptIdself"
    ></vTemplate>
    <!--新建按钮弹窗-->
    <el-dialog title="新建模板" :visible.sync="dialogFormVisibleAdd">
      <el-form :model="form" :rules="formRules" ref="form" labelPosition="left">
        <el-form-item
          label="模板名称"
          prop="scriptName"
          class="demo-ruleForm"
          :label-width="formLabelWidth"
        >
          <el-input v-model="form.scriptName"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisibleAdd = false">取 消</el-button>
        <el-button type="primary" @click="submitFormThrottle">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<style scoped="scoped" lang="less">
.letemplateContainer {
  .ietemplate {
    width: 100%;
    padding: 0 10px;
    box-sizing: border-box;
    height: 100%;
    position: relative;
  }
  .ietemplate-header {
    float: left;
    box-sizing: border-box;
    top: 0px;
    width: 100%;
    height: 58px;
    border-bottom: 1px dashed #d1dbe7;
  }
  .ietemplate-header .el-button {
    margin-top: 10px;
    width: 90px;
    margin-left: 10px;
    font-family: '微软雅黑';
  }
  .ietemplate-content {
    padding-top: 68px;
    padding-bottom: 80px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .ietemplate-content .ietemplate-content-pos {
    width: 100%;
    height: 100%;
  }
  .ietemplate-content .ietemplate-page {
    width: 100%;
    height: 80px;
  }
  .ietemplate-page .el-pagination {
    display: inline-block;
    height: 28px;
    line-height: 28px;
  }
}
</style>
<style lang="less">
.letemplateContainer {
  #modelId {
    background: #fff;
    border: none;
  }
  #modelId table {
    border-left: 1px solid #dfe6ec;
    border-top: 1px solid #dfe6ec;
  }
  .el-table::after,
  .el-table::before {
    background: #fff;
  }
  #modelId .el-table__body-wrapper {
    overflow-x: hidden;
  }
  @media screen and (min-height: 767px) {
    #modelId .el-table__body-wrapper {
      height: 600px;
    }
  }
  @media screen and (max-height: 766px) and (min-height: 650px) {
    #modelId .el-table__body-wrapper {
      height: 410px;
    }
  }
  @media screen and (max-height: 649px) {
    #modelId .el-table__body-wrapper {
      height: 300px;
    }
  }
}
</style>
<script>
import vTemplate from './Newtemplate.vue'
import Qs from 'qs'
import bus from './bus.js'
import commonUtil from '../../../utils/commonUtil'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl

export default {
  components: {
    vTemplate,
  },
  created() {
    this.getModels()
  },
  mounted() {
    const self = this
    bus.$on('emitgetmodels', function() {
      self.getModels()
    })
    bus.$on('getScriptId', function() {
      return self.scriptIdself
    })
  },
  data() {
    return {
      tableData: [],
      currentPage1: 1,
      templateShow: true, // 是否新建
      modelTotal: 0, // 分页的总数
      pageSize: 20, // 每页的数量
      parentKeywordData: null,
      parentDoseScriptData: null,
      editType: '',
      multipleSelection: [],
      scriptIdself: '', // 模板脚本id(编辑),
      sortType: false,
      dialogFormVisibleAdd: false,
      formLabelWidth: '80px',
      form: {
        scriptName: '',
      },
      formRules: {
        scriptName: [{ required: true, message: '名称不能为空', trigger: 'change,blur' }],
      },
    }
  },
  methods: {
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    getModels() {
      const self = this
      let configss = {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      }
      let params = {
        pageNumber: this.currentPage1,
        pageSize: this.pageSize,
        sortType: this.sortType,
      }
      this.axios
        .post(
          currentBaseUrl + '/filterTemplate/getFilterModels.do',
          Qs.stringify(params),
          configss
        )
        .then(function(response) {
          if (response.status == 200) {
            self.tableData = response.data.Data
            self.modelTotal = response.data.Count
          }
        })
        .catch(function() {})
    },
    sortQuery() {
      this.sortType = !this.sortType
      this.getModels()
    },
    handleSizeChange: function(val) {
      this.pageSize = val
      this.getModels()
    },
    handleCurrentChange: function(val) {
      this.currentPage1 = val
      this.getModels()
    },
    taskResback() {
      if (this.multipleSelection.length == 0) {
        this.$message({
          type: 'info',
          message: '请先选择相关的录音',
        })
        return false
      }
      const self = this
      let messageArr = []
      this.multipleSelection.forEach(function(val) {
        messageArr.push(val['modelName'])
      })
      let message = '确定要删除【'
      if (messageArr.length <= 3) {
        message += messageArr.join(',')
        message += '】这' + messageArr.length + '个筛选项目吗?'
      } else {
        let arr = messageArr.slice(0, 3)
        message += arr.join(',')
        message += '】等' + messageArr.length + '个筛选项目吗?'
      }
      this.$confirm(message, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let arr = []
          self.multipleSelection.forEach(function(val, index) {
            arr.push(val.modelId)
          })
          let params = {
            scriptIdStr: arr.join(),
          }
          let configss = {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            },
          }
          this.axios
            .post(
              currentBaseUrl + '/filterTemplate/batchRemoveScript.do',
              Qs.stringify(params),
              configss
            )
            .then(function(response) {
              if (response.status == 200) {
                self.$message({
                  type: 'success',
                  message: '删除成功!',
                })
                self.getModels()
              }
            })
            .catch(function() {})
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    submitFormThrottle() {
      this.lodashThrottle.throttle(this.submitForm, this)
    },
    /*
     * 新建模版保存
     * */
    submitForm: function() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          if (commonUtil.isBlank(this.form.scriptName)) {
            this.$message.error('模板名称不能为空!')
            return
          }
          this.axios
            .post(
              currentBaseUrl + '/filterTemplate/saveScript.do',
              Qs.stringify(this.form)
            )
            .then((res) => {
              if (res.data.state == '1') {
                localStorage.setItem('scriptname', this.$data.form.scriptName)
                localStorage.setItem('scriptid', res.data.other.newScript.fullScriptId)
                this.dialogFormVisibleAdd = false
                this.templateShow = false
                this.$message({
                  type: 'success',
                  message: '保存成功!',
                })
              } else {
                this.$message({
                  type: 'error',
                  message: res.data.message,
                })
              }
            })
            .catch(function() {})
        }
      })
    },
    newtemplate() {
      this.dialogFormVisibleAdd = true
      let self = this
      this.$nextTick(function() {
        self.$refs['form'].resetFields()
      })
      this.editType = 'newFile'
      this.$data.form.scriptName = ''
    },
    changeshow(input) {
      // 改变当前页面的显示情况（templateShow改变这个值）
      this.templateShow = input
    },
    tapeEdit(index, row) {
      // 录音编辑
      this.scriptIdself = row.modelId
      this.editType = 'edit'
      const self = this
      let configss = {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        },
      }
      localStorage.setItem('scriptNameId', row.modelId)
      let params = {
        scriptId: row.modelId,
        pageNumber: '1',
        pageSize: '10',
      }
      this.axios
        .post(
          currentBaseUrl + '/filterTemplate/getAllDoseScriptData.do',
          Qs.stringify(params),
          configss
        )
        .then(function(response) {
          if (response.status == 200) {
            self.parentKeywordData = response.data.keywordData
            self.parentDoseScriptData = response.data.doseScriptData
            self.templateShow = false
          }
        })
        .catch(function() {})
    },
    tapeSearch(index, row) {
      // 录音查看
      this.editType = 'checked'
      let configss = {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        },
      }
      let params = {
        scriptId: row.modelId,
        pageNumber: '1',
        pageSize: '10',
      }
      const self = this
      this.axios
        .post(
          currentBaseUrl + '/filterTemplate/getAllDoseScriptData.do',
          Qs.stringify(params),
          configss
        )
        .then(function(response) {
          if (response.status == 200) {
            self.parentKeywordData = response.data.keywordData
            self.parentDoseScriptData = response.data.doseScriptData
            self.templateShow = false
          }
        })
        .catch(function() {})
    },
    tapeClose(index, row) {
      // 录音删除
      const self = this
      this.$confirm('是否删除【' + row['modelName'] + '】模板？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          let params = {
            scriptId: row.modelId,
          }
          let configss = {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            },
          }
          this.axios
            .post(
              currentBaseUrl + '/filterTemplate/removeScript.do',
              Qs.stringify(params),
              configss
            )
            .then(function(response) {
              if (response.status == 200) {
                self.$message({
                  type: 'success',
                  message: '删除成功!',
                })
                self.getModels()
              }
            })
            .catch(function() {})
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
  },
}
</script>
