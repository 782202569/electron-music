import Vue from 'vue'
let bus = new Vue({})
export default bus
