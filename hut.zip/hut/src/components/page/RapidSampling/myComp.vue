<template>
  <el-form
    ref="orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Ref"
    :inline="true"
    :rules="orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Rules"
    :model="orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model"
    label-width="84px"
  >
    <h3>订单属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="orderTime" style="color:#8691a5" label="下单时间"
          ><el-date-picker
            style="width:160px"
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.orderTime
            "
            type="datetimerange"
            placeholder="选择时间范围"
            v-bind:default-time="['00:00:00', '23:59:59']"
          ></el-date-picker></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="wholeContent" style="color:#8691a5" label="订单内容"
          ><el-input
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.wholeContent
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12"
        ><el-form-item prop="orderNo" style="color:#8691a5" label="订单编号"
          ><el-input
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.orderNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>员工属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="submiter" style="color:#8691a5" label="提交人工号"
          ><el-input
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.submiter
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="submiterName" style="color:#8691a5" label="提交人姓名"
          ><el-input
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.submiterName
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12"
        ><el-form-item prop="groupId" style="color:#8691a5" label="坐席组ID"
          ><el-input
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.groupId
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="seatStar" style="color:#8691a5" label="坐席星级"
          ><el-input
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.seatStar
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>客户属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="customerName" style="color:#8691a5" label="客户姓名"
          ><el-input
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.customerName
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="certNo" style="color:#8691a5" label="证件号码"
          ><el-input
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.certNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12"
        ><el-form-item prop="customerNo" style="color:#8691a5" label="客户帐号"
          ><el-input
            v-model="
              orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model.customerNo
            "
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row
  ></el-form>
</template>

<script>
var validateFunc = function() {}
export default {
  data() {
    return {
      orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model: {
        orderTime: [],
        orderTime$CName: '下单时间',
        wholeContent: '',
        wholeContent$CName: '订单内容',
        orderNo: '',
        orderNo$CName: '订单编号',
        submiter: '',
        submiter$CName: '提交人工号',
        submiterName: '',
        submiterName$CName: '提交人姓名',
        groupId: '',
        groupId$CName: '坐席组ID',
        seatStar: '',
        seatStar$CName: '坐席星级',
        customerName: '',
        customerName$CName: '客户姓名',
        certNo: '',
        certNo$CName: '证件号码',
        customerNo: '',
        customerNo$CName: '客户帐号',
      },
      orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Rules: {},
    }
  },
}
</script>

<style></style>
