<template>
  <div class="rapidSampleContainer">
    <el-row>
      <el-col :span="12" :class="hidden ? 'hidden' : ''">
        <div class="contentLeft">
          <div class="operation">
            <h3>
              筛选条件
            </h3>
            <div class="btns" v-if="sampleType == 'custom'">
              <el-button type="primary" @click="searchSample">查询</el-button>
              <el-button @click="createStrategybtn">生成策略</el-button>
              <el-button @click="resetSearchForm">清空</el-button>
            </div>
          </div>
          <div class="attrs customSample" v-if="sampleType == 'custom'">
            <my-comp ref="myComp"></my-comp>
          </div>
          <div class="attrs strategySample" v-if="sampleType == 'strategy'">
            <div class="settingStrategy">
              <ut-dtail
                :strategy="strategy"
                :currentStrategy="currentStrategy"
                v-for="strategy in strategyList"
                @deleteStrategy="deleteStrategy"
                @editStrategy="editStrategy"
                @click="searchSampleByStrategy"
              >
              </ut-dtail>
              <div class="detailContainer" @click="changeSampleType('custom')">+</div>
              <div
                class="detailContainer noborder"
                v-if="strategyList.length % 3 != 2"
              ></div>
              <div
                class="detailContainer noborder"
                v-if="strategyList.length % 3 == 0"
              ></div>
            </div>
          </div>
          <div class="sampleType">
            <div
              class="custom"
              @click="changeSampleType('custom')"
              :class="sampleType == 'custom' ? 'currentType' : ''"
            >
              自定义抽样
            </div>
            <div
              class="strategy"
              @click="changeSampleType('strategy')"
              :class="sampleType == 'strategy' ? 'currentType' : ''"
            >
              策略抽样
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="rightSpan">
        <div class="contentRight records" v-show="rightContent == 'records'">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="operation">
            <div class="btns">
              <el-button @click="exportOut">导出</el-button>
              <el-button @click="distribution">分配</el-button>
              <el-button @click="addToSamplePool">加入样本池</el-button>
            </div>
          </div>
          <div class="attrs recordsList recordsList_table">
            <el-table
              ref="recordsListTable"
              :data="recordsList"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" fixed width="55"></el-table-column>
              <el-table-column label="订单编号" fixed prop="orderNo" width="120">
                <template scope="scope">
                  <el-button
                    type="text"
                    class="callId"
                    @click="showDetail(scope.row.orderNo, scope.row.recordFileURL)"
                    >{{ scope.row.orderNo }}
                  </el-button>
                </template>
              </el-table-column>
              <el-table-column
                label="下单时间"
                prop="orderTime"
                :formatter="createTimeFilter"
                width="120"
              ></el-table-column>
              <el-table-column prop="orderState" label="订单状态">
                <template scope="scope">
                  <el-tag
                    close-transition
                    type="primary"
                    v-if="scope.row.orderState == '0'"
                    >取消单</el-tag
                  >
                  <el-tag
                    close-transition
                    type="success"
                    v-if="scope.row.orderState == '1'"
                    >成功单</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column
                prop="submiterName"
                label="提交人"
                show-overflow-tooltip
              ></el-table-column>
            </el-table>
          </div>
          <div class="page">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="pageNumber"
              :page-sizes="pageSizes"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
        <div class="contentRight editStrategy" v-show="rightContent == 'editStrategy'">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="operation">
            <h3>
              修改策略
            </h3>
            <div class="btns">
              <el-button type="primary" @click="saveEditStrategy">保存</el-button>
              <el-button @click="cancleEditStrategy">取消</el-button>
            </div>
          </div>
          <div class="attrs customSample">
            <my-comp ref="updateMyComp"></my-comp>
          </div>
        </div>
      </el-col>
    </el-row>
    <!-- 分配质检员 -->
    <el-dialog
      title="分配质检员"
      :visible.sync="distributeInspectorVisible"
      :close-on-click-modal="false"
      :before-close="handleCloseDistributeInspector"
    >
      <div class="distributeInspectorFiled">
        <div class="part_1">
          <el-form
            :model="distributeInspectorModel"
            ref="distributeInspectorModel"
            label-width="100px"
          >
            <el-form-item label="质检模板" prop="templeateId">
              <el-select
                v-model="distributeInspectorModel.templeateId"
                placeholder="请选择"
                clearable
              >
                <el-option
                  v-for="item in templeateIds"
                  :label="item.modleTitle"
                  :value="item.modleId"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="完成时间" prop="day">
              <el-select
                v-model="distributeInspectorModel.day"
                placeholder="请选择"
                clearable
              >
                <el-option label="一天" value="1"></el-option>
                <el-option label="二天" value="2"></el-option>
                <el-option label="三天" value="3"></el-option>
                <el-option label="四天" value="4"></el-option>
                <el-option label="五天" value="5"></el-option>
                <el-option label="六天" value="6"></el-option>
                <el-option label="七天" value="7"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="选择质检员" prop="people">
              <el-checkbox-group
                :min="0"
                :max="checkedRecordList.length"
                v-model="distributeInspectorModel.people"
              >
                <el-checkbox :label="item.account" v-for="item in people">{{
                  item.realName
                }}</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
            <el-form-item>
              <div class="btns">
                <el-button @click="resetForm('distributeInspectorModel')">清空</el-button>
                <el-button type="primary" @click="confirmAdd">确定</el-button>
              </div>
            </el-form-item>
          </el-form>
        </div>
        <div class="part_2">
          <div>剩余未分配：{{ rest }}</div>
          <div>
            <el-table :data="tableData" style="width: 100%">
              <el-table-column
                prop="qaUserName"
                label="质检员姓名"
                width="180"
              ></el-table-column>
              <el-table-column
                prop="count"
                label="当月分配"
                width="180"
              ></el-table-column>
              <el-table-column label="当前分配">
                <template scope="scope">
                  <span
                    v-if="checkShow(scope.$index, 'edit')"
                    class="currentDistributeCount"
                  >
                    {{ currentDistribute[scope.$index] }}
                  </span>
                  <el-button
                    v-if="checkShow(scope.$index, 'edit')"
                    @click="editTableCell(scope.$index, 'edit')"
                    type="text"
                    size="small"
                    icon="edit"
                  ></el-button>
                  <el-input
                    v-if="checkShow(scope.$index, 'save')"
                    class="currentDistributeCount"
                    v-model="currentDistribute[scope.$index]"
                    placeholder="请输入内容"
                    @blur="checkNumber(scope.$index)"
                  ></el-input>
                  <el-button
                    v-if="checkShow(scope.$index, 'save')"
                    @click="editTableCell(scope.$index, 'save')"
                    type="text"
                    size="small"
                    icon="check"
                  ></el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="btns distributeInspectorbtn">
          <el-button @click="handleCloseDistributeInspector">取消</el-button>
          <el-button type="primary" @click="distributeInspector">分配</el-button>
        </div>
      </div>
    </el-dialog>
    <el-dialog
      title="保存策略"
      :visible.sync="saveStrategyVisible"
      :close-on-click-modal="false"
      :before-close="handleCloseSaveStrategy"
    >
      <div class="distributeInspectorFiled">
        <el-form
          :model="saveStrategyModel"
          ref="saveStrategyModel"
          label-width="100px"
          :rules="saveStrategyRules"
        >
          <el-form-item label="策略名称" prop="strategyName">
            <el-input
              v-model="saveStrategyModel.strategyName"
              placeholder="请输入策略名称"
            ></el-input>
          </el-form-item>
          <el-form-item>
            <div class="btns">
              <el-button @click="handleCloseSaveStrategy">取消</el-button>
              <el-button type="primary" @click="createStrategyThrottle">保存</el-button>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </el-dialog>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import utDtail from './detailOrder.vue'
import qs from 'qs'
import moment from 'moment'
import commonUtil from '../../../utils/commonUtil.js'
import global from '../../../global.js'
let formEngineUrl = global.formEngineUrl
let qualityUrl = global.qualityUrl
import recordingplay from '../recordingPlayOrder/recordingPlayOrder.vue'
import bus from '../../common/bus.js'
import nativeaxios from 'axios'
import cache from '../../../utils/cache.js'
import myCompVue from './myComp.vue'
let requestUrls = {
  getFormUrl:
    formEngineUrl +
    '/creating.do?formIds=orderRapidSampleOrder,orderRapidSampleSeat,orderRapidSampleCust&accessToken=' +
    cache.getItem('tgt_id'),
  queryByConditionUrl: qualityUrl + '/orderManualSample/queryByCondition.do',
  queryByStrategyUrl: qualityUrl + '/orderManualSample/queryByStrategy.do',
  addToSamplePoolUrl: qualityUrl + '/orderManualSample/addToOrderSamplePool.do',
  distributeQaUsersUrl: qualityUrl + '/orderManualSample/distributeOrderNosToQaUsers.do',
  getStrategiesUrl: qualityUrl + '/orderManualSample/getStrategies.do',
  getQaUsersUrl: qualityUrl + '/orderManualSample/getQaUsers.do',
  getQaUserDistributeInfoUrl:
    qualityUrl + '/orderManualSample/getQaUserDistributeInfo.do',
  saveStrategyUrl: qualityUrl + '/orderManualSample/saveStrategy.do',
  updateStrategyUrl: qualityUrl + '/orderManualSample/updateStrategy.do',
  removeStrategyUrl: qualityUrl + '/orderManualSample/removeStrategy.do',
  exportUrl: qualityUrl + '/orderManualSample/exportOrders.do',
  getOrderModelUrl: qualityUrl + '/orderManualSample/getOrderModels.do',
}

const objectType = 1

export default {
  components: {
    // 局部注册
    recordingplay,
    utDtail,
    'my-comp': myCompVue,
    // 'my-comp': (resolve) => {
    //   nativeaxios.post(requestUrls.getFormUrl).then(function(response) {
    //     $('body').append(response.data.Validate)
    //     let myHtml = response.data.Html
    //     resolve({
    //       template: myHtml,
    //       data() {
    //         return {
    //           /* eslint-disable */
    //           orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model: JSON.parse(
    //             JSON.stringify(
    //               orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_
    //             )
    //           ),
    //           orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Rules: orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Rules,
    //           /* eslint-enable */
    //         }
    //       },
    //     })
    //   })
    // },
  },
  data() {
    return {
      recordDialogVisible: false,
      sampleType: 'custom', // 自定义抽样（'custom'）或策略抽样（'strategy'）
      showvCusterinfo: false, // 是否显示策略详情
      status: '1', // 获取策略列表时传的参数，据说每个页面一个，不知道是什么
      strategyList: [], // 策略列表
      currentStrategy: {}, // 当前选择策略
      currentStrategyObj: {},
      rightContent: 'records', // 右侧显示内容（''=>暂无数据，'records'=>录音记录，'editStrategy'=>编辑策略）
      displayType: 1, // 筛选结果展现形式 ('1'=>按详情展示，‘2’=>按数据展示)
      screeningConditionsModel: {}, // 筛选条件表单
      modifyConditionsModel: {
        silenceCount: '',
        firmAdd: '',
        callNo: '',
        certNo: '',
      }, // 修改策略formmodel
      recordsList: [], // 录音列表
      checkedRecordList: [], // 选中的录音列表
      pageNumber: 1, // 当前页码
      total: 0, // 记录总条数
      pageSize: 20, // 每页显示的记录条数
      pageSizes: [10, 15, 20, 25],
      showSelectAllbtn: true, // 是否显示全选按钮
      distributeInspectorVisible: false,
      distributeInspectorModel: {
        templeateId: '',
        day: '',
        people: [],
      }, // 分配质检员表单
      tableData: [],
      templeateIds: [], // 质检模板列表
      people: [],
      modleType: '7',
      callId: '', // 录音编号
      saveStrategyVisible: false, // 输入策略名称弹出层
      saveStrategyModel: {
        // 策略名称
        strategyName: '',
      },
      saveStrategyRules: {
        strategyName: [
          {
            required: true,
            message: '请输入策略名称',
            trigger: 'blur',
          },
        ],
      },
      currentClickedStrategy: {}, // 当前点击的策略
      strategyId: '', // 当前正在编辑的策略id
      currentDistribute: [], // 当前分配列表
      editCountIndex: '', // 当前编辑的单元格所在的行index
      countHasError: false, // 质检员分配的任务数量是否存在问题
      position: 'top',
      tempNum: '', // 临时变量
      hidden: false, // 左侧部分是否隐藏,
      queryMode: 'byCondition',
      selectedQueryStrategyId: '',
    }
  },
  methods: {
    handleSizeChange(val) {
      this.pageSize = val
      this.pageNumber = 1
      this.queryOrders()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    exportOut() {
      if (this.checkedRecordList.length == 0) {
        this.$message.warning('请至少选择一条记录进行导出!')
      } else {
        let params = {
          orderNos: this.checkedRecordList.join(','),
        }
        commonUtil.doExport(requestUrls.exportUrl, params)
      }
    },
    getKeyword(params) {
      let str = ''
      if (params['wholeContent_firstKey']) {
        str += params['wholeContent_firstKey'] + ' '
        if (params['wholeContent_firstLogic'] && params['wholeContent_secondKey']) {
          str +=
            params['wholeContent_firstLogic'] + ' ' + params['wholeContent_secondKey']
          if (params['wholeContent_MidLogic']) {
            if (params['wholeContent_thirdKey']) {
              str += ' ' + params['wholeContent_MidLogic'] + ' '
              str += params['wholeContent_thirdKey'] + ' '
              if (params['wholeContent_LastLogic'] && params['wholeContent_LastKey']) {
                str +=
                  params['wholeContent_LastLogic'] + ' ' + params['wholeContent_LastKey']
              }
            }
          }
        }
      }
      return str
    },
    getStrategyList() {
      let _this = this
      this.axios
        .post(
          requestUrls.getStrategiesUrl,
          qs.stringify({
            status: this.status,
          })
        )
        .then(function(response) {
          _this.strategyList = []
          _this.strategyList = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取策略列表出现问题',
          })
        })
    },
    changeSampleType(type) {
      if (type == 'custom' && this.rightContent == 'editStrategy') {
        this.$message({
          type: 'warning',
          message: '请先保存策略',
        })
        return false
      }
      this.sampleType = type
      this.currentStrategy = {}
    },
    editStrategy(strategy) {
      this.rightContent = 'editStrategy'
      this.strategyId = strategy.strategyId
      let upComp = this.$refs.updateMyComp
      let stratObj = JSON.parse(strategy.strategyObject)
      if (stratObj['orderTime_Min'] && stratObj['orderTime_Max']) {
        stratObj['orderTime'] = []
        stratObj['orderTime'][0] = new Date(stratObj['orderTime_Min'])
        stratObj['orderTime'][1] = new Date(stratObj['orderTime_Max'])
      }
      upComp.orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model = stratObj
      this.modifyConditionsModel =
        upComp.orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model
    },
    saveEditStrategy() {
      let _this = this
      let params = {}
      params.strategyId = this.strategyId
      params.strategyObject = JSON.stringify(this.modifyConditionsModel)
      this.axios
        .post(requestUrls.updateStrategyUrl, qs.stringify(params))
        .then(function(response) {
          _this.getStrategyList()
          _this.$message.success('策略编辑成功')
          _this.cancleEditStrategy()
        })
        .catch(function() {
          _this.$message.error('策略保存出现问题')
        })
    },
    deleteStrategy(strategy) {
      let _this = this
      let id = strategy.strategyId
      let name = strategy.strategyName
      this.$confirm('确定要删除策略[' + name + ']么?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          _this.removeStrategy(id, name)
        })
        .catch(() => {
          _this.$message.error('已取消删除')
        })
    },
    removeStrategy(id, name) {
      let params = { strategyId: id }
      this.axios
        .post(requestUrls.removeStrategyUrl, qs.stringify(params))
        .then((response) => {
          let data = response.data
          if (data) {
            this.$message('删除策略[' + name + ']已成功删除')
            this.getStrategyList()
          } else {
            this.$message.error('删除策略[' + name + ']失败!')
          }
        })
        .catch(() => {
          this.$message.error('删除策略出现问题')
        })
    },
    showPlay() {
      event.target.querySelector('.play').style.display = 'block'
    },
    hidePlay() {
      event.target.querySelector('.play').style.display = 'none'
    },
    selectAllRecords() {
      this.checkedRecordList = []
      this.showSelectAllbtn = false
      this.recordsList.forEach((item, index) => {
        this.checkedRecordList.push(item.orderNo)
      })
    },
    tapePlay() {
      console.log('tapePlay')
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.pageNumber = val
      this.queryOrders()
    },
    createTimeFilter(row, column, cellValue) {
      return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
    },
    convertOrderState(x, y, orderState) {
      if (orderState === '1') {
        return '成功'
      }
      return '失败'
    },
    handleSelectionChange(val) {
      this.checkedRecordList = []
      let _this = this
      val.forEach(function(item) {
        _this.checkedRecordList.push(item.orderNo)
      })
    },
    distribution() {
      if (this.checkedRecordList.length < 1) {
        this.$message.warning('请先选择样本')
        return false
      }
      this.distributeInspectorVisible = true
      this.resetForm('distributeInspectorModel')
      this.getModleInfoByCondition()
      this.getQaUsers()
      this.tableData = []
    },
    resetSearchForm() {
      this.$nextTick(() => {
        this.$refs['myComp']['$refs'][
          'orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Ref'
        ].resetFields()
      })
    },
    resetForm(formName) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[formName].resetFields()
      })
      if (formName == 'distributeInspectorModel') {
        this.tableData = []
        this.currentDistribute = []
        this.tempNum = 0
      }
    },
    handleCloseDistributeInspector() {
      this.distributeInspectorVisible = false
    },
    getModleInfoByCondition() {
      let _this = this
      let params = {}
      params.modleType = this.modleType
      params.pageindex = this.currentPage
      params.pagesize = this.pageSize
      this.axios
        .post(requestUrls.getOrderModelUrl, qs.stringify(params))
        .then(function(response) {
          _this.templeateIds = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检模板出现问题',
          })
        })
    },
    getQaUsers() {
      this.axios
        .post(requestUrls.getQaUsersUrl)
        .then((response) => {
          this.people = response.data
        })
        .catch(() => {
          this.$message('获取质检员列表出现问题')
        })
    },
    confirmAdd() {
      this.tableData = []
      this.getDistributes()
    },
    setCurrentDistribute() {
      let qaUserCount = this.tableData.length
      this.currentDistribute = []
      let orderNos = this.checkedRecordList
      for (let i = 0; i < orderNos.length; i++) {
        let index = i % qaUserCount
        if (!this.currentDistribute[index]) {
          this['currentDistribute'][index] = '1'
        } else {
          this['currentDistribute'][index] =
            parseInt(this['currentDistribute'][index]) + 1 + ''
        }
      }
    },
    getDistributes() {
      if (this.distributeInspectorModel.people.length < 1) {
        this.$message.warning('请先选择质检员')
        return false
      }
      let params = {}
      params.qaUsers = this.distributeInspectorModel.people.join(',')
      params.objectType = objectType
      this.axios
        .post(requestUrls.getQaUserDistributeInfoUrl, qs.stringify(params))
        .then((response) => {
          this.tableData = response.data
          this.setCurrentDistribute()
        })
        .catch(() => {
          this.$message.error('获取质检员任务分配情况失败')
        })
    },
    getDistributeParams() {
      let params = {}
      params['objectType'] = objectType
      params.modelId = this.distributeInspectorModel.templeateId
      params.duration = this.distributeInspectorModel.day
      let qaUserCount = this.tableData.length
      let qaUserNumberMap = {}
      for (let i = 0; i < qaUserCount; i++) {
        let qaUser = this.tableData[i].qaUser
        let count = parseInt(this.currentDistribute[i])
        qaUserNumberMap[qaUser] = count
      }
      params['qaUserNumberMap'] = JSON.stringify(qaUserNumberMap)
      params['orderNos'] = this.checkedRecordList.join(',')
      return params
    },
    distributeInspector() {
      if (this.tempNum < 0 || this.tempNum > 0) {
        this.$message.error('任务分配总数量和录音总数量不匹配，请重新分配')
        return false
      }
      if (this.countHasError) {
        return false
      } else if (this.editCountIndex != '') {
        this.$message.error('请确认质检员当前分配任务数量')
        return false
      }
      let params = this.getDistributeParams()

      if (commonUtil.isBlank(params['modelId'])) {
        this.$message.warning('请选择质检模板!')
        return
      }

      if (commonUtil.isBlank(params['duration'])) {
        this.$message.warning('请选择天数')
        return
      }

      this.axios
        .post(requestUrls.distributeQaUsersUrl, qs.stringify(params))
        .then((response) => {
          let data = response.data
          if (data) {
            this.$message.success('任务已成功分配')
            this.distributeInspectorVisible = false
            this.searchSample()
          } else {
            this.$message.error('任务分配失败!')
          }
        })
        .catch(() => {
          this.$message.error('任务分配失败!')
        })
    },
    addToSamplePool() {
      if (this.checkedRecordList.length < 1) {
        this.$message.warning('请先选择样本')
        return false
      }
      let params = {}
      params.orderNos = this.checkedRecordList.join(',')
      params['objectType'] = objectType
      this.axios
        .post(requestUrls.addToSamplePoolUrl, qs.stringify(params))
        .then((response) => {
          let successCount = response.data
          if (successCount > 0) {
            this.$message.success('成功加入样板池' + response.data + '个样本')
          }
          this.pageNumber = 1
          this.queryOrders()
        })
        .catch(() => {
          this.$message.error('获取质检模板出现问题')
        })
    },
    onDisplayTypeChange() {
      this.checkedRecordList.length = 0
      this.currentPage = 1
    },
    searchAttr(formId) {
      for (let item in formId) {
        if (typeof formId[item] == 'string') {
          formId[item] = ''
        } else if (formId[item] instanceof Array) {
          formId[item] = []
        } else if (typeof formId[item] == 'object') {
          for (let jtm in formId[item]) {
            formId[item][jtm] = ''
          }
        }
      }
    },
    getParams(param, formId) {
      for (let item in formId) {
        if (typeof formId[item] == 'string') {
          param[item] = formId[item]
        } else if (formId[item] instanceof Array) {
          if (formId[item].length == 2) {
            param[item + '_Min'] = formId[item][0]
            param[item + '_Max'] = formId[item][1]
          } else {
            param[item + '_Min'] = ''
            param[item + '_Max'] = ''
          }
        } else if (typeof formId[item] == 'object') {
          for (let jtm in formId[item]) {
            param[jtm] = formId[item][jtm]
          }
        }
      }
      return param
    },
    queryOrders() {
      let params = {}
      let url = ''
      if (this.queryMode === 'byCondition') {
        url = requestUrls.queryByConditionUrl
        params = this.getStrategyObject()
      } else {
        url = requestUrls.queryByStrategyUrl
        params['strategyId'] = this.selectedQueryStrategyId
      }
      params['pageNumber'] = this.pageNumber
      params['pageSize'] = this.pageSize
      params['sortField'] = 'orderTime'
      params['sortType'] = 'DESC'
      this.axios
        .post(url, qs.stringify(params))
        .then((response) => {
          let data = response['data']
          if (data['state'] === '1') {
            this.recordsList = data['results']
            this.rightContent = 'records'
            this.total = data['count']
          } else {
            this.$message.error(data['message'])
          }
        })
        .catch(function() {
          this.$message.error('查询样本出现问题')
        })
    },
    searchSample() {
      this.pageNumber = 1
      this.queryMode = 'byCondition'
      this.queryOrders()
    },
    createStrategybtn() {
      this.saveStrategyVisible = true
      this.resetForm('saveStrategyModel') //
    },
    handleCloseSaveStrategy() {
      this.saveStrategyVisible = false
    },
    createStrategyThrottle() {
      this.lodashThrottle.throttle(this.createStrategy, this)
    },
    createStrategy() {
      let params = {}
      params.strategyObject = JSON.stringify(this.getStrategyObject())
      params.strategyName = this.saveStrategyModel.strategyName

      this.$refs.saveStrategyModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          this.axios
            .post(requestUrls.saveStrategyUrl, qs.stringify(params))
            .then((response) => {
              let data = response.data
              if (data['state'] === '1') {
                this.$message.success('策略保存成功')
                this.rightContent = 'records'
                this.saveStrategyVisible = false
                this.resetSearchForm()
              } else {
                this.$message.error(data['message'])
              }
            })
        }
      })
    },
    getStrategyObject() {
      let obj = {}
      let model = this.$refs.myComp
        .orderRapidSampleOrder_orderRapidSampleSeat_orderRapidSampleCust_Model
      for (let prop in model) {
        if (model.hasOwnProperty(prop)) {
          obj[prop] = model[prop]
        }
      }
      if (model['orderTime'] && model['orderTime'].length === 2) {
        obj['orderTime_Min'] = model['orderTime'][0].getTime()
        obj['orderTime_Max'] = model['orderTime'][1].getTime()
      }
      delete obj['orderTime']
      return obj
    },
    searchSampleByStrategy(strategy) {
      this.queryMode = 'byStrategy'
      this.pageNumber = 1
      this.selectedQueryStrategyId = strategy['strategyId']
      this.queryOrders()
    },
    cancleEditStrategy() {
      this.rightContent = 'records'
    },
    editTableCell(index, flag) {
      if (this.countHasError) {
        return false
      }
      if (flag == 'edit') {
        this.editCountIndex = index
      } else {
        if (isNaN(this.currentDistribute[index])) {
          this.countHasError = true
          return false
        }
        this.editCountIndex = ''
      }
    },
    checkNumber(index) {
      this.countHasError = false
      if (isNaN(this.currentDistribute[index])) {
        this.$message.error('请输入数字')
        event.target.focus()
        this.countHasError = true
        return false
      } else {
        if (parseInt(this.currentDistribute[index]) == 0) {
          this.distributeInspectorModel.people.forEach((i, n) => {
            if (n.account == this.tableData[index].account) {
              this.distributeInspectorModel.people.splice(i, 1)
            }
          })
          this.tableData.splice(index, 1)
          this.currentDistribute.splice(index, 1)
        }
      }
    },
    checkShow(index, flag) {
      if (flag == 'edit' && this.editCountIndex !== index) {
        return true
      } else if (flag == 'save' && this.editCountIndex !== index) {
        return false
      } else if (flag == 'save' && this.editCountIndex === index) {
        return true
      } else {
        return false
      }
    },
    toggleContainer() {
      this.hidden = !this.hidden
    },
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'artificialSampleOrder'
      obj.pageId = 'artificialSampleOrder'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      obj.queryMode = this.queryMode
      obj.selectedQueryStrategyId = this.selectedQueryStrategyId
      obj.orderNo = id
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push({path: '/recordingPlayOrder', query: obj})
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
  },
  created() {
    this.recordPlayCloseHandler()
    if (
      this.recordingPlayPage.fromPage === 'artificialSampleOrder' &&
      this.recordingPlayPage.searchModel.pageNumber
    ) {
      this.pageNumber = this.recordingPlayPage.searchModel.pageNumber
      this.pageSize = this.recordingPlayPage.searchModel.pageSize
    }
  },
  mounted() {
    if (this.recordingPlayPage.fromPage === 'artificialSampleOrder') {
      this.queryOrders()
    }
    this.resetSearchForm()
  },
  filters: {
    timeTransform(val) {
      return val / 1000
    },
  },
  watch: {
    sampleType(val) {
      if (val == 'custom') {
        console.log('custom')
      } else if (val == 'strategy') {
        this.getStrategyList()
      }
    },
  },
  computed: {
    rest() {
      let sum = 0
      this.currentDistribute.forEach(function(item) {
        if (!isNaN(parseInt(item))) {
          sum += parseInt(item)
        }
      })
      this.tempNum = this.checkedRecordList.length - sum
      return this.checkedRecordList.length - sum > 0
        ? this.checkedRecordList.length - sum
        : 0
    },
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less">
@border-color: #d1dbe5;
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
.rapidSampleContainer {
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
  div {
    box-sizing: border-box;
  }
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
  .operation {
    box-sizing: border-box;
    height: 60px;
    line-height: 60px;
    padding: 0px 10px 0px 0px;
    border-bottom: 1px dashed @border-color;
    position: absolute;
    top: 0px;
    left: 10px;
    right: 10px;
    h3 {
      width: 65px;
      float: left;
      font-size: 14px;
      color: #5e6d82;
      font-weight: normal;
    }
  }
  .btns {
    float: right;
    button {
      width: 90px;
    }
  }
  .el-row {
    height: 100%;
    .el-col {
      height: 100%;
    }
  }
  .contentLeft,
  .contentRight {
    border-right: 1px solid @border-color;
    height: 100%;
    width: 100%;
    position: relative;
    .attrs {
      position: absolute;
      top: 60px;
      right: 0px;
      left: 0px;
      bottom: 50px;
      overflow-y: auto;
      .audioAttrs_part {
        border-bottom: 1px dashed @border-color;
        .audioAttrsInputs {
          padding: 10px;
          .el-form-item > label {
            font-size: 14px;
            color: #8691a5;
          }
        }
      }
      .audioAttrs_part:last-child {
        border-bottom: none;
      }
      h3 {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        color: #9dadc2;
        font-weight: normal;
      }
    }
    .sampleType {
      position: absolute;
      bottom: 0px;
      left: 0;
      right: 0;
      display: flex;
      height: 50px;
      line-height: 50px;
      overflow: hidden;
      div {
        cursor: pointer;
        flex-grow: 1;
        text-align: center;
        background: #eef1f6;
        border-top: 1px solid @border-color;
        position: relative;
        color: #8391a5;
        font-size: 14px;
      }
      div.currentType {
        background: #fff;
        color: #20a0ff;
      }
    }

    .currentType::before {
      content: '';
      display: block;
      width: 15px;
      height: 15px;
      margin: 0 auto;
      position: absolute;
      transform: rotate(45deg);
      border-right: 1px solid #d5dce6;
      border-bottom: 1px solid #d5dce6;
      top: -8px;
      left: 48%;
      background: #fff;
    }
  }
  .editStrategy .attrs {
    bottom: 0px;
  }
  .attrs.customSample {
    padding: 10px;
  }
  .strategySample {
    .settingStrategy {
      width: 100%;
      box-sizing: border-box;
      padding-bottom: 10px;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      .detailContainer {
        cursor: pointer;
      }
      .noborder {
        visibility: hidden;
      }
    }
  }
  .records {
    .operation .btns {
      .el-button:last-child {
        padding-left: 10px;
      }
      .el-radio-group:first-child {
        margin-right: 10px;
      }
    }
    .recordsList {
      position: absolute;
      top: 60px;
      left: 0;
      right: 0;
      bottom: 50px;
      overflow-y: auto;
      p {
        text-align: center;
        font-size: 14px;
        color: #9dadc2;
        padding-top: 30px;
      }
    }
    .recordsList_table {
      padding: 10px;
    }
    .page {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0px;
      border-top: 1px solid @border-color;
      text-align: right;
      height: 50px;
      box-sizing: border-box;
      padding-top: 10px;
      .el-pagination {
        display: inline-block;
        height: 30px;
      }
    }
  }
  .el-checkbox-group {
    display: flex;
    flex-wrap: wrap;
    padding-top: 10px;
  }
  .recordDisplayBoxContainer {
    box-sizing: border-box;
    width: 100%;
    padding: 0px 10px;
  }
  .recordDisplayBox {
    position: relative;
    border: 1px solid @border-color;
    width: 100%;
    margin-bottom: 10px;
    height: 185px;
    box-sizing: border-box;
    & > div {
      padding: 0px 10px;
    }
    .recordDisplay_header {
      height: 45px;
      line-height: 45px;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      font-weight: bold;
      background: #eff2f7;
      & > span {
        margin-left: 10px;
        vertical-align: middle;
      }
      & > label {
        vertical-align: middle;
        span.el-checkbox__label {
          display: none;
        }
      }
    }
    .recordDisplay_content {
      position: absolute;
      top: 45px;
      left: 0;
      right: 0;
      bottom: 35px;
      overflow: hidden;
      &:hover {
        cursor: pointer;
      }
      .play {
        display: none;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 10;
        background: rgba(00, 00, 00, 0.4);
        text-align: center;
        line-height: 145px;
        img {
          display: inline;
          width: 51px;
          height: 51px;
        }
      }
    }
    .recordDisplay_footer {
      height: 35px;
      line-height: 35px;
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      background: #fbfdff;
      border-top: 1px solid @border-color;
      span:nth-child(2) {
        margin-right: 10px;
      }
    }
  }
  .recordDisplayBoxContainer_hidden {
    width: 50%;
    margin: 0px;
    box-sizing: border-box;
    padding-bottom: 10px;
    &:nth-child(2n + 1) {
      padding-left: 10px;
      padding-right: 5px;
    }
    &:nth-child(2n) {
      padding-right: 10px;
      padding-left: 5px;
    }
    .recordDisplayBox {
      margin: 0px;
    }
  }
  .distributeInspectorbtn {
    margin: 10px 0px 10px;
  }
  .distributeInspectorFiled .part_1 {
    border-bottom: 1px dashed @border-color;
    margin-bottom: 10px;
    .el-checkbox + .el-checkbox {
      margin-left: 0px;
    }
    .el-checkbox__label {
      display: inline-block;
      min-width: 100px;
    }
  }
  .distributeInspectorFiled .part_2 {
    div:first-child {
      margin: 10px 0px;
    }
  }
  .currentDistributeCount {
    display: inline-block;
    width: 80px;
  }
  .hidden {
    display: none;
  }
  .toggleBtn {
    cursor: pointer;
    width: 20px;
    height: 30px;
    background-image: url('../../../assets/img/close.png');
    position: absolute;
    left: -20px;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggle-hidden {
    left: 0px;
    transform: rotate(180deg);
  }
  .callId {
    &:hover {
      color: #20a0ff;
      cursor: pointer;
    }
  }
}
</style>
