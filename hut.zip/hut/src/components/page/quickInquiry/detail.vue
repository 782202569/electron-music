<template>
  <div
    class="detailContainer"
    :class="[
      currentStrategy.strategyId === strategy.strategyId ? 'active' : '',
      hoverflag ? 'hovered' : '',
    ]"
  >
    <el-popover placement="right" width="350" height="350" trigger="hover">
      <div
        class="strategybtn"
        @mouseenter="hoverflag = true"
        @mouseleave="hoverflag = false"
        @click.self="searchSampleByStrategy(strategy)"
        slot="reference"
      >
        <span
          class="settingStrategyName"
          @click.self="searchSampleByStrategy(strategy)"
          >{{ strategy.strategyName }}</span
        >
        <span class="settingStrategybtns" v-if="hoverflag">
          <i class="el-icon-edit" @click.prevent="editStrategy(strategy)"></i>
          <i class="el-icon-close" @click.prevent="deleteStrategy(strategy)"></i>
        </span>
      </div>
      <div class="details">
        <div v-for="(value, key) in strategyObject" :key="key">
          <div
            class="content"
            v-if="key.indexOf('$CName') < 0 && key.indexOf('wholeContent') < 0"
          >
            <span
              >{{ strategyObject[key + '$CName'] || '' }}：<i>{{
                value | formatFilter
              }}</i></span
            >
          </div>
        </div>
        <div class="content">
          <span
            >关键词：<i>
              {{
                '( ' +
                  (strategyObject.wholeContent_firstKey || '') +
                  ' ' +
                  (strategyObject.wholeContent_firstLogic || '') +
                  ' ' +
                  (strategyObject.wholeContent_secondKey || '') +
                  ' ) ' +
                  (strategyObject.wholeContent_MidLogic || '') +
                  ' (' +
                  (strategyObject.wholeContent_thirdKey || '') +
                  ' ' +
                  (strategyObject.wholeContent_LastLogic || '') +
                  ' ' +
                  (strategyObject.wholeContent_LastKey || '') +
                  ' )'
              }}
            </i></span
          >
        </div>
      </div>
    </el-popover>
  </div>
</template>
<script>
export default {
  name: 'Datail',
  props: ['strategy', 'currentStrategy'],
  data() {
    return {
      hoverflag: false,
    }
  },
  methods: {
    editStrategy(strategy) {
      this.$emit('editStrategy', strategy)
    },
    deleteStrategy(strategy) {
      this.$emit('deleteStrategy', strategy)
    },
    searchSampleByStrategy(strategy) {
      this.$emit('click', strategy)
    },
  },
  computed: {
    strategyObject() {
      return JSON.parse(this.strategy.strategyObject)
    },
  },
  filters: {
    formatFilter(val) {
      if (Object.prototype.toString.call(val) === '[object Array]') {
        return val.join('~')
      } else {
        return val
      }
    },
  },
}
</script>
<style lang="less">
.detailContainer {
  width: 30%;
  display: inline-block;
  height: 36px;
  margin: 15px 6px 0px;
  overflow: hidden;
  line-height: 36px;
  white-space: nowrap;
  text-align: center;
  padding: 0;
  position: relative;
  border: 1px solid #c4c4c4;
  color: #1f2d3d;
  border-radius: 4px;
  text-align: center;
  vertical-align: middle;
  & > span {
    .strategybtn {
      cursor: pointer;
      overflow: hidden;
      padding-left: 10px;
      padding-right: 10px;
      .settingStrategyName {
        width: 100%;
        overflow: hidden;
        display: inline-block;
        text-overflow: ellipsis;
        float: left;
      }
    }
    .settingStrategybtns {
      float: right;
      width: 50px;
      i {
        margin-right: 5px;
        width: 18px;
        height: 18px;
        line-height: 18px;
        font-size: 10px;
        color: #20a0ff;
        &:hover {
          background: #20a0ff;
          color: #fff;
          border-radius: 50%;
        }
      }
    }
  }
  &.hovered {
    border-color: #20a0ff;
    span .strategybtn {
      padding-right: 0px;
      .settingStrategyName {
        width: 100px;
        color: #20a0ff;
      }
    }
    &.active span .strategybtn {
      .settingStrategyName {
        color: #fff;
      }
      .settingStrategybtns {
        i {
          color: #fff;
          &:hover {
            background: #fff;
            color: #20a0ff;
          }
        }
      }
    }
  }
  &.active {
    background: #20a0ff;
    color: #fff;
    border-color: #20a0ff;
    .settingStrategybtns {
      i {
        &:hover {
          background: #fff;
          color: #20a0ff;
        }
      }
    }
  }
  .details {
    display: flex;
    flex-wrap: wrap;
  }
  .content {
    line-height: 24px;
    width: 50%;
    span {
      color: #9ca2b2;
      i {
        color: #1f2d3d;
      }
    }
  }
}
</style>
