<template>
  <div class="rapidScreenContainer">
    <el-row>
      <el-col :span="12" :class="hidden ? 'hidden' : ''">
        <div class="contentLeft">
          <div class="operation">
            <h3>
              筛选条件
            </h3>
            <div class="btns" v-if="sampleType == 'custom'">
              <el-button type="primary" @click="searchSample">查询</el-button>
              <el-button funcId="000211" @click="createStrategybtn">生成策略</el-button>
              <el-button funcId="000212" @click="resetSearchForm">清空</el-button>
            </div>
          </div>
          <div class="attrs customSample" v-if="sampleType == 'custom'">
            <my-comp ref="myComp"></my-comp>
          </div>
          <div class="attrs strategySample" v-if="sampleType == 'strategy'">
            <div class="settingStrategy">
              <ut-dtail
                :strategy="strategy"
                :currentStrategy="currentStrategy"
                v-for="(strategy, index) in strategyList"
                :key="index"
                @deleteStrategy="deleteStrategy"
                @editStrategy="editStrategy"
                @click="searchSampleByStrategy"
              >
              </ut-dtail>
              <div class="detailContainer" @click="changeSampleType('custom')">+</div>
              <div
                class="detailContainer noborder"
                v-if="strategyList.length % 3 != 2"
              ></div>
              <div
                class="detailContainer noborder"
                v-if="strategyList.length % 3 == 0"
              ></div>
            </div>
          </div>
          <div class="sampleType">
            <div
              class="custom"
              @click="changeSampleType('custom')"
              :class="sampleType == 'custom' ? 'currentType' : ''"
            >
              自定义筛选
            </div>
            <div
              class="strategy"
              @click="changeSampleType('strategy')"
              :class="sampleType == 'strategy' ? 'currentType' : ''"
            >
              策略筛选
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="rightSpan">
        <div class="contentRight records" v-show="rightContent == 'records'">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="operation">
            <div class="btns">
              <el-radio-group v-model="displayType" @change="onDisplayTypeChange">
                <el-radio class="radio" :label="2">按数据展示</el-radio>
                <el-radio class="radio" :label="1">按详情展示</el-radio>
              </el-radio-group>
              <el-button
                @click="disSelectAllRecords"
                v-if="displayType == 1 && !showSelectAllbtn"
                >全不选</el-button
              >
              <el-button @click="exportOut">导出</el-button>
            </div>
          </div>
          <div class="attrs recordsList" v-if="displayType == 1">
            <el-checkbox-group v-model="checkedRecordList" v-if="recordsList.length > 0">
              <div
                :class="
                  hidden
                    ? 'recordDisplayBoxContainer_hidden'
                    : 'recordDisplayBoxContainer'
                "
                :key="index"
                v-for="(item, index) in recordsList"
              >
                <div class="recordDisplayBox">
                  <div class="recordDisplay_header">
                    <el-checkbox size="small" :label="item.callId"></el-checkbox>
                    <span
                      >录音编号<span
                        @click="showDetail(item.callId, item.recordFileURL)"
                        class="callId"
                        >{{ item.callId }}</span
                      ></span
                    >
                  </div>
                  <div
                    class="recordDisplay_content"
                    @mouseenter="showPlay"
                    @mouseleave="hidePlay"
                  >
                    {{ item.wholeContent }}
                    <div
                      class="play"
                      @click="showDetail(item.callId, item.recordFileURL)"
                    >
                      <img src="../../../assets/img/u493.png" />
                    </div>
                  </div>
                  <div class="recordDisplay_footer">
                    <label>坐席姓名：</label>
                    <span>{{ item.seatName }}</span>
                    <label>录音时间：</label>
                    <span>{{ item.callTime | timeTransform }}</span>
                  </div>
                </div>
              </div>
            </el-checkbox-group>
            <p v-else>
              暂无符合要求样本
            </p>
          </div>
          <div class="attrs recordsList recordsList_table" v-if="displayType == 2">
            <el-table
              ref="recordsListTable"
              :data="recordsList"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" fixed width="55"> </el-table-column>
              <el-table-column label="录音编号" fixed prop="callId" sortable width="120">
                <template scope="scope">
                  <el-button
                    type="text"
                    class="callId"
                    @click="showDetail(scope.row.callId, scope.row.recordFileURL)"
                    >{{ scope.row.callId }}</el-button
                  >
                </template>
              </el-table-column>
              <el-table-column
                label="录音时间"
                prop="callSTime"
                sortable
                :formatter="createTimeFilter"
                width="120"
              >
              </el-table-column>
              <el-table-column
                prop="callTime"
                label="通话时长"
                sortable
                :formatter="convertCallTime"
                width="120"
              >
              </el-table-column>
              <el-table-column
                prop="mblNo"
                label="客户号码"
                sortable
                show-overflow-tooltip
              >
              </el-table-column>
              <el-table-column
                prop="deptName"
                sortable
                label="坐席组"
                show-overflow-tooltip
              >
              </el-table-column>
              <el-table-column
                prop="seatName"
                sortable
                label="坐席姓名"
                show-overflow-tooltip
              >
              </el-table-column>
            </el-table>
          </div>
          <div class="page">
            <el-pagination
              :small="true"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="pageSizes"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
        <div class="contentRight editStrategy" v-show="rightContent == 'editStrategy'">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="operation">
            <h3>
              修改策略
            </h3>
            <div class="btns">
              <el-button funcId="000213" type="primary" @click="saveEditStrategy"
                >保存</el-button
              >
              <el-button funcId="000214" @click="cancleEditStrategy">取消</el-button>
            </div>
          </div>
          <div class="attrs customSample">
            <!-- 修改的地方 -->
            <my-comp ref="updateMyComp"></my-comp>
          </div>
        </div>
      </el-col>
    </el-row>
    <!-- 输入策略名称 -->
    <el-dialog
      title="保存策略"
      :visible.sync="saveStrategyVisible"
      :close-on-click-modal="false"
      :before-close="handleCloseSaveStrategy"
    >
      <div class="distributeInspectorFiled">
        <el-form
          :model="saveStrategyModel"
          ref="saveStrategyModel"
          label-width="100px"
          :rules="saveStrategyRules"
        >
          <el-form-item label="策略名称" prop="strategyName">
            <el-input
              v-model="saveStrategyModel.strategyName"
              placeholder="请输入策略名称"
            ></el-input>
          </el-form-item>
          <el-form-item>
            <div class="btns">
              <el-button funcId="000215" @click="handleCloseSaveStrategy">取消</el-button>
              <el-button funcId="000216" type="primary" @click="createStrategyThrottle"
                >保存</el-button
              >
            </div>
          </el-form-item>
        </el-form>
      </div>
    </el-dialog>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import nativeaxios from 'axios'
import cache from '../../../utils/cache.js'
import utDtail from './detail.vue'
import qs from 'qs'
import moment from 'moment'
import formatdate from '../../../utils/formatdate.js'
import recordingplay from '../recordingPlay/recordingPlayNew.vue'

import bus from '../../common/bus.js'
import global from '../../../global.js'
import myCompVue from './myComp.vue'
let currentBaseUrl = global.currentBaseUrl
export default {
  components: {
    // 局部注册
    utDtail,
    'my-comp': myCompVue,
    // 'my-comp': (resolve, reject) => {
    //   nativeaxios
    //     .post(
    //       global.formEngineUrl +
    //         '/creating.do?formIds=fastFilterLuyin,fastFilterYuangong,fastFilterKehu,fastFilterYuyin,recordingContent&accessToken=' +
    //         cache.getItem('tgt_id')
    //     )
    //     .then(function(response) {
    //       $('body').append(response.data.Validate)
    //       let myHtml = response.data.Html
    //       resolve({
    //         template: myHtml,
    //         watch: {
    //           // 监听
    //         },
    //         data() {
    //           return {
    //             /* eslint-disable */
    //             fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model: JSON.parse(
    //               JSON.stringify(
    //                 fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_
    //               )
    //             ),
    //             fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Rules: fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Rules,
    //             /* eslint-enable */
    //           }
    //         },
    //       })
    //     })
    // },
    recordingplay,
  },
  data() {
    return {
      sampleType: 'custom', // 自定义抽样（'custom'）或策略抽样（'strategy'）
      showvCusterinfo: false, // 是否显示策略详情
      status: '2', // 获取策略列表时传的参数，据说每个页面一个，不知道是什么
      strategyList: [], // 策略列表
      currentStrategy: {}, // 当前选择策略
      currentStrategyObj: {},
      rightContent: 'records', // 右侧显示内容（''=>暂无数据，'records'=>录音记录，'editStrategy'=>编辑策略）
      displayType: 1, // 筛选结果展现形式 ('1'=>按详情展示，‘2’=>按数据展示)
      screeningConditionsModel: {}, // 筛选条件表单
      modifyConditionsModel: {}, // 修改策略formmodel
      recordsList: [], // 录音列表
      checkedRecordList: [], // 选中的录音列表
      currentPage: 1, // 当前页码
      total: 0, // 记录总条数
      pageSize: 20, // 每页显示的记录条数
      pageSizes: [10, 15, 20, 25],
      showSelectAllbtn: true, // 是否显示全选按钮
      distributeInspectorModel: {
        templeateId: '',
        day: '1',
        people: [],
      }, // 分配质检员表单
      tableData: [],
      templeateIds: [], // 质检模板列表
      people: [],
      modleType: '7',
      callId: '', // 录音编号
      saveStrategyVisible: false, // 输入策略名称弹出层
      saveStrategyModel: {
        // 策略名称
        strategyName: '',
      },
      saveStrategyRules: {
        strategyName: [
          {
            required: true,
            message: '请输入策略名称',
            trigger: 'blur',
          },
        ],
      },
      currentClickedStrategy: {}, // 当前点击的策略
      strategyId: '', // 当前正在编辑的策略id
      currentDistribute: [], // 当前分配列表
      editCountIndex: '', // 当前编辑的单元格所在的行index
      countHasError: false, // 质检员分配的任务数量是否存在问题
      position: 'top',
      recordDialogVisible: false,
      tempNum: '', // 临时变量
      hidden: false, // 左侧部分是否隐藏
    }
  },
  methods: {
    handleSizeChange(val) {
      this.pageSize = val
    },
    // 获取表单引擎中的表单方法
    getForm(formId, position) {
      let _this = this
      let url = global.formEngineUrl + '/creating.do?formIds=' + formId
      this.axios
        .post(url)
        .then(function(response) {
          document.querySelector(position).innerHTML = response.data.Html
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取表单内容出现问题',
          })
        })
    },
    // 获取策略列表
    getStrategyList() {
      let _this = this
      let url = currentBaseUrl + '/ivsStrategy/getStrategyList.do'
      this.axios
        .post(
          url,
          qs.stringify({
            status: '2',
          })
        )
        .then(function(response) {
          _this.strategyList = []
          _this.strategyList = response.data
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取策略列表出现问题',
          })
        })
    },
    // 展示自定义抽样页面还是策略抽样页面
    changeSampleType(type) {
      if (type == 'custom' && this.rightContent == 'editStrategy') {
        this.$message({
          type: 'warning',
          message: '请先保存策略',
        })
        return false
      }
      this.sampleType = type
      this.currentStrategy = {}
    },
    // 编辑策略按钮
    editStrategy(strategy) {
      this.rightContent = 'editStrategy'
      this.strategyId = strategy.strategyId
      // 获取引用
      let upComp = this.$refs.updateMyComp
      let stratObj = JSON.parse(strategy.strategyObject)
      upComp.fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model = stratObj
      this.modifyConditionsModel =
        upComp.fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model
    },
    // 保存编辑好的策略
    saveEditStrategy() {
      let _this = this
      let url = currentBaseUrl + '/ivsStrategy/updateStrategyObject.do'
      let params = {}
      params.strategyId = this.strategyId
      this.modifyConditionsModel.callSTime = this.modifyConditionsModel.callSTime.map(
        function(item) {
          return formatdate.formatDate(item)
        }
      )
      params.strategyObject = JSON.stringify(this.modifyConditionsModel)
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.getStrategyList()
          _this.$message({
            type: 'success',
            message: '策略编辑成功',
          })
          _this.cancleEditStrategy()
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '策略保存出现问题',
          })
        })
    },
    // 删除策略确认
    deleteStrategy(strategy) {
      let _this = this
      let id = strategy.strategyId
      let name = strategy.strategyName
      this.$confirm('确定要删除策略[' + name + ']么?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          _this.removeStrategy(id, name)
        })
        .catch(() => {
          _this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
    // 删除策略方法
    removeStrategy(id, name) {
      let _this = this
      let url = currentBaseUrl + '/ivsStrategy/removeStrategy.do'
      this.axios
        .post(
          url,
          qs.stringify({
            strategyId: id,
          })
        )
        .then(function(response) {
          _this.getStrategyList()
          _this.$message({
            type: 'success',
            message: '删除策略[' + name + ']已成功删除',
          })
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '删除策略出现问题',
          })
        })
    },
    // 鼠标放到录音内容上时展示播放按钮
    showPlay() {
      event.target.querySelector('.play').style.display = 'block'
    },
    // 鼠标移出录音内容上时展示播放按钮
    hidePlay() {
      event.target.querySelector('.play').style.display = 'none'
    },
    // 全选录音
    selectAllRecords() {
      let _this = this
      this.checkedRecordList = []
      this.showSelectAllbtn = false
      this.recordsList.forEach(function(item, index) {
        _this.checkedRecordList.push(item.callId)
      })
    },
    // 全选录音
    disSelectAllRecords() {
      this.checkedRecordList = []
      this.showSelectAllbtn = true
    },
    tapePlay() {
      // 跳转到录音播放界面
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    // 转换表格中的时间
    createTimeFilter(row, column, cellValue) {
      return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
    },
    // 转换录音时长格式
    convertCallTime(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    // 录音table中行的选中状态变化时触发(val为选中的object)
    handleSelectionChange(val) {
      this.checkedRecordList.length = 0
      let _this = this
      val.forEach(function(item) {
        _this.checkedRecordList.push(item.callId)
      })
    },
    resetSearchForm() {
      let _this = this
      this.$nextTick(function() {
        _this.$refs['myComp']['$refs'][
          'fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Ref'
        ].resetFields()
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model.wholeContent_firstKey =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model.wholeContent_firstLogic =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model.wholeContent_secondKey =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model.wholeContent_MidLogic =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model.wholeContent_thirdKey =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model.wholeContent_LastLogic =
          ''
        _this.$refs[
          'myComp'
        ].fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model.wholeContent_LastKey =
          ''
      })
    },
    // 重置表单
    resetForm(formName) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[formName].resetFields()
      })
    },
    // 抽样结果展示形式变化时清空已选中的列表,页码重置为1
    onDisplayTypeChange() {
      this.checkedRecordList.length = 0
      this.currentPage = 1
    },
    getParams(param, formId) {
      for (let item in formId) {
        if (typeof formId[item] === 'string') {
          param[item] = formId[item]
        } else if (formId[item] instanceof Array) {
          if (formId[item].length === 2) {
            param[item + '_Min'] = formatdate.formatDate(formId[item][0])
            param[item + '_Max'] = formatdate.formatDate(formId[item][1])
          } else {
            param[item + '_Min'] = ''
            param[item + '_Max'] = ''
          }
        } else if (typeof formId[item] === 'object') {
          for (let jtm in formId[item]) {
            param[jtm] = formId[item][jtm]
          }
        }
      }
      return param
    },
    getKeyword(params) {
      let str = ''
      if (params['wholeContent_firstKey']) {
        str += params['wholeContent_firstKey'] + ' '
        if (params['wholeContent_firstLogic'] && params['wholeContent_secondKey']) {
          str +=
            params['wholeContent_firstLogic'] + ' ' + params['wholeContent_secondKey']
          if (params['wholeContent_MidLogic']) {
            if (params['wholeContent_thirdKey']) {
              str += ' ' + params['wholeContent_MidLogic'] + ' '
              str += params['wholeContent_thirdKey'] + ' '
              if (params['wholeContent_LastLogic'] && params['wholeContent_LastKey']) {
                str +=
                  params['wholeContent_LastLogic'] + ' ' + params['wholeContent_LastKey']
              }
            }
          }
        }
      }
      if (str != '') {
        let Str = {}
        Str.keywords = str
        this.$store.commit('setKeywordsHigh', Str)
      } else {
        this.$store.commit('setKeywordsHigh', null)
      }
      return str
    },
    // 获取抽样结果（录音列表）
    getRecordsList(strateObject) {
      let _this = this
      let myComp = this.$refs.myComp
      let searchModel = {}
      searchModel.pageNumber = this.currentPage
      searchModel.pageSize = this.pageSize
      searchModel.sortType = 'callSTime'
      let obj = {}
      obj.searchModel = searchModel
      obj.searchModel.strateObject = myComp
        ? myComp.fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model
        : ''
      obj.searchModel.sampleType = this.sampleType
      obj.searchModel.displayType = this.displayType
      obj.searchModel.currentStrategy = this.currentStrategy
      this.$store.commit('setRecordingPlayPage', obj)
      if (strateObject) {
        _this.getParams(searchModel, strateObject)
      } else {
        _this.getParams(
          searchModel,
          myComp.fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model
        )
      }
      let keyword = ''
      if (strateObject) {
        keyword = _this.getKeyword(strateObject)
      } else {
        keyword = _this.getKeyword(
          myComp.fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model
        )
      }
      searchModel['wholeContent'] = keyword
      if (searchModel['callSTime_Min']) {
        searchModel['callSTime_Min'] = moment(searchModel['callSTime_Min']).format(
          'YYYY-MM-DD HH:mm:ss'
        )
      }
      if (searchModel['callSTime_Max']) {
        searchModel['callSTime_Max'] = moment(searchModel['callSTime_Max']).format(
          'YYYY-MM-DD HH:mm:ss'
        )
      }
      let url = currentBaseUrl + '/iqc/integratedQueryRecords.do'
      this.axios
        .post(url, qs.stringify(searchModel))
        .then(function(response) {
          _this.recordsList = response.data.Data
          _this.rightContent = 'records'
          _this.total = response.data.Count
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '抽取样本出现问题',
          })
        })
    },
    // 查询样本
    searchSample() {
      this.getRecordsList()
    },
    // 点击生成策略按钮，弹出弹出层,输入策略名称
    createStrategybtn() {
      this.saveStrategyVisible = true
      this.resetForm('saveStrategyModel') //
    },
    handleCloseSaveStrategy() {
      this.saveStrategyVisible = false
    },
    createStrategyThrottle() {
      this.lodashThrottle.throttle(this.createStrategy, this)
    },
    // 生成策略
    createStrategy() {
      let _this = this
      let params = {}
      this.$refs.myComp.fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model.callSTime = this.$refs.myComp.fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model.callSTime.map(
        function(item) {
          return formatdate.formatDate(item)
        }
      )
      params.strategyObject = JSON.stringify(
        this.$refs.myComp
          .fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model
      )
      params.strategyName = this.saveStrategyModel.strategyName
      params.strategyBelong = '快速筛选'
      params.status = '2'
      let url = currentBaseUrl + '/ivsStrategy/saveStrategy.do'
      this.$refs.saveStrategyModel.validate((valid) => {
        if (!valid) {
          return false
        } else {
          _this.axios
            .post(url, qs.stringify(params))
            .then(function(response) {
              if (response.data && response.data.flag == 1) {
                _this.$message({
                  type: 'success',
                  message: '策略保存成功',
                })
                _this.rightContent = 'records'
                _this.saveStrategyVisible = false
                _this.resetSearchForm()
              } else if (response.data && response.data.flag == 2) {
                _this.$message({
                  type: 'error',
                  message: response.data.message,
                })
              } else {
                return Promise.reject()
              }
            })
            .catch(function(error) {
              console.log(error)
              _this.$message({
                type: 'error',
                message: '策略保存失败',
              })
            })
        }
      })
    },
    // 通过策略抽样
    searchSampleByStrategy(strategy) {
      let stratObject = JSON.parse(strategy.strategyObject)
      this.currentStrategy = strategy
      this.getRecordsList(stratObject)
    },
    // 取消保存策略
    cancleEditStrategy() {
      this.rightContent = 'records'
    },
    toggleContainer() {
      this.hidden = !this.hidden
    },
    // 调到录音播放页
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.from = 'integratedSearchHr'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 导出录音
    exportOut() {
      if (this.checkedRecordList.length < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择要导出样本',
        })
        return false
      } else {
        let params = {}
        params.callIdStr = this.checkedRecordList.join(',')
        params.accessToken = cache.getItem('tgt_id')
        let form = document.createElement('form')
        form.method = 'post'
        form.target = '_blank'
        for (let key in params) {
          let input = document.createElement('input')
          input.name = key
          input.value = params[key]
          form.appendChild(input)
        }
        form.action = currentBaseUrl + '/iqc/excelExportByCallIds.do'
        document.querySelector('body').appendChild(form)
        form.submit()
        document.querySelector('body').removeChild(form)
      }
    },
  },
  created() {
    this.recordPlayCloseHandler()
    if (
      this.recordingPlayPage.fromPage === 'integratedSearchHr' &&
      this.recordingPlayPage.searchModel.pageNumber
    ) {
      this.currentPage = this.recordingPlayPage.searchModel.pageNumber
      this.pageSize = this.recordingPlayPage.searchModel.pageSize
    }
  },
  mounted() {
    if (
      this.recordingPlayPage.fromPage === 'integratedSearchHr' &&
      this.recordingPlayPage.searchModel.pageNumber
    ) {
      this.sampleType = this.recordingPlayPage.searchModel.sampleType
      this.displayType = this.recordingPlayPage.searchModel.displayType
      if (this.recordingPlayPage.searchModel.sampleType === 'strategy') {
        this.currentStrategy = this.recordingPlayPage.searchModel.currentStrategy
        this.getRecordsList(JSON.parse(this.currentStrategy.strategyObject))
      } else {
        this.$refs.myComp.fastFilterLuyin_fastFilterYuangong_fastFilterKehu_fastFilterYuyin_recordingContent_Model = this.recordingPlayPage.searchModel.strateObject
        this.getRecordsList()
      }
      // this.getRecordsList(this.recordingPlayPage.searchModel.strateObject)
    }
    this.resetSearchForm()
  },
  filters: {
    timeTransform(val) {
      return val / 1000
    },
  },
  watch: {
    sampleType(val) {
      this.recordsList = []
      this.total = 0
      if (val === 'custom' && this.rightContent === 'editStrategy') {
        // this.$message({
        //   type: 'warning',
        //   message: '请先保存策略'
        // });
        // return false;
      } else if (val === 'strategy') {
        this.getStrategyList()
      }
    },
    pageSize() {
      if (this.sampleType === 'custom') {
        this.getRecordsList()
      } else {
        this.getRecordsList(JSON.parse(this.currentStrategy.strategyObject))
      }
    },
    currentPage() {
      if (this.sampleType === 'custom') {
        this.getRecordsList()
      } else {
        this.getRecordsList(JSON.parse(this.currentStrategy.strategyObject))
      }
    },
  },
  computed: {
    rest() {
      let sum = 0
      this.currentDistribute.forEach(function(item) {
        if (!isNaN(parseInt(item))) {
          sum += parseInt(item)
        }
      })
      this.tempNum = this.checkedRecordList.length - sum
      return this.checkedRecordList.length - sum > 0
        ? this.checkedRecordList.length - sum
        : 0
    },
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less">
@border-color: #d1dbe5;
.rapidScreenContainer {
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .el-dialog__wrapper.single {
    position: fixed;
    top: 10px;
    left: 20px;
    right: 20px;
    bottom: 12px;
    .el-dialog {
      width: 100%;
      height: 100%;
      margin-top: 0 !important;
      margin-bottom: 0 !important;
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
  }
  div {
    box-sizing: border-box;
  }
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
  .operation {
    box-sizing: border-box;
    height: 60px;
    line-height: 60px;
    padding: 0px 10px 0px 0px;
    border-bottom: 1px dashed @border-color;
    position: absolute;
    top: 0px;
    left: 10px;
    right: 10px;
    h3 {
      width: 65px;
      float: left;
      font-size: 14px;
      color: #5e6d82;
      font-weight: normal;
    }
  }
  .btns {
    float: right;
    button {
      width: 90px;
    }
  }
  .el-row {
    height: 100%;
    .el-col {
      height: 100%;
    }
  }
  .contentLeft,
  .contentRight {
    border-right: 1px solid @border-color;
    height: 100%;
    width: 100%;
    position: relative;
    .attrs {
      position: absolute;
      top: 60px;
      right: 0px;
      left: 0px;
      bottom: 50px;
      overflow-y: auto;
      .audioAttrs_part {
        border-bottom: 1px dashed @border-color;
        .audioAttrsInputs {
          padding: 10px;
          .el-form-item > label {
            font-size: 14px;
            color: #8691a5;
          }
        }
      }
      .audioAttrs_part:last-child {
        border-bottom: none;
      }
      h3 {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        color: #9dadc2;
        font-weight: normal;
      }
    }
    .sampleType {
      position: absolute;
      bottom: 0px;
      left: 0;
      right: 0;
      display: flex;
      height: 50px;
      line-height: 50px;
      overflow: hidden;
      div {
        cursor: pointer;
        flex-grow: 1;
        text-align: center;
        background: #eef1f6;
        border-top: 1px solid @border-color;
        position: relative;
        color: #8391a5;
        font-size: 14px;
      }
      div.currentType {
        background: #fff;
        color: #20a0ff;
      }
    }

    .currentType::before {
      content: '';
      display: block;
      width: 15px;
      height: 15px;
      margin: 0 auto;
      position: absolute;
      transform: rotate(45deg);
      border-right: 1px solid #d5dce6;
      border-bottom: 1px solid #d5dce6;
      top: -8px;
      left: 48%;
      background: #fff;
    }
  }
  .editStrategy .attrs {
    bottom: 0px;
  }
  .attrs.customSample {
    padding: 10px;
  }
  .strategySample {
    .settingStrategy {
      width: 100%;
      box-sizing: border-box;
      padding-bottom: 10px;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      .detailContainer {
        cursor: pointer;
      }
      .noborder {
        visibility: hidden;
      }
    }
  }
  .records {
    .operation .btns {
      .el-button:last-child {
        padding-left: 10px;
      }
      .el-radio-group:first-child {
        margin-right: 10px;
      }
    }
    .recordsList {
      position: absolute;
      top: 60px;
      left: 0;
      right: 0;
      bottom: 50px;
      overflow-y: auto;
      p {
        text-align: center;
        font-size: 14px;
        color: #9dadc2;
        padding-top: 30px;
      }
    }
    .recordsList_table {
      padding: 10px;
    }
    .page {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0px;
      border-top: 1px solid @border-color;
      text-align: right;
      height: 50px;
      box-sizing: border-box;
      padding-top: 10px;
      .el-pagination {
        display: inline-block;
        height: 30px;
      }
    }
  }
  .el-checkbox-group {
    display: flex;
    flex-wrap: wrap;
    padding-top: 10px;
    font-size: 12px;
  }
  .recordDisplayBoxContainer {
    box-sizing: border-box;
    width: 100%;
    padding: 0px 10px;
  }
  .recordDisplayBox {
    position: relative;
    border: 1px solid @border-color;
    width: 100%;
    margin-bottom: 10px;
    height: 185px;
    box-sizing: border-box;
    & > div {
      padding: 0px 10px;
    }
    .recordDisplay_header {
      height: 45px;
      line-height: 45px;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      font-weight: bold;
      background: #eff2f7;
      & > span {
        margin-left: 10px;
        vertical-align: middle;
      }
      & > label {
        vertical-align: middle;
        span.el-checkbox__label {
          display: none;
        }
      }
    }
    .recordDisplay_content {
      position: absolute;
      top: 45px;
      left: 0;
      right: 0;
      bottom: 35px;
      overflow: hidden;
      &:hover {
        cursor: pointer;
      }
      .play {
        display: none;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 10;
        background: rgba(00, 00, 00, 0.4);
        text-align: center;
        line-height: 145px;
        img {
          display: inline;
          width: 51px;
          height: 51px;
        }
      }
    }
    .recordDisplay_footer {
      height: 35px;
      line-height: 35px;
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      background: #fbfdff;
      border-top: 1px solid @border-color;
      span:nth-child(2) {
        margin-right: 10px;
      }
    }
  }
  .recordDisplayBoxContainer_hidden {
    width: 50%;
    margin: 0px;
    box-sizing: border-box;
    padding-bottom: 10px;
    &:nth-child(2n + 1) {
      padding-left: 10px;
      padding-right: 5px;
    }
    &:nth-child(2n) {
      padding-right: 10px;
      padding-left: 5px;
    }
    .recordDisplayBox {
      margin: 0px;
    }
  }
  .distributeInspectorbtn {
    margin: 10px 0px 10px;
  }
  .distributeInspectorFiled .part_1 {
    border-bottom: 1px dashed @border-color;
    margin-bottom: 10px;
    .el-checkbox + .el-checkbox {
      margin-left: 0px;
    }
    .el-checkbox__label {
      display: inline-block;
      min-width: 100px;
    }
  }
  .distributeInspectorFiled .part_2 {
    div:first-child {
      margin: 10px 0px;
    }
  }
  .currentDistributeCount {
    display: inline-block;
    width: 80px;
  }
  .hidden {
    display: none;
  }
  .toggleBtn {
    cursor: pointer;
    width: 20px;
    height: 30px;
    background-image: url('../../../assets/img/close.png');
    position: absolute;
    left: -20px;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggle-hidden {
    left: 0px;
    transform: rotate(180deg);
  }
  .callId {
    &:hover {
      color: #20a0ff;
      cursor: pointer;
    }
  }
}
</style>
