<template>
  <div id="leaderOrderAppeal" class="leaderOrderAppeal">
    <el-row>
      <el-col :span="12" :class="hidden ? 'hidden' : ''">
        <div class="leftContent">
          <div class="searchHeader">
            <div style="float: right; margin-right: 10px">
              <el-select v-model="orderType" class="w-200" placeholder="请选择">
                <el-option
                  v-for="item in orderTypeOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
              <el-button type="primary" @click="searchTask" style="width: 90px;"
                >查询组长</el-button
              >
            </div>
          </div>
          <div class="searchForm">
            <el-form
              :label-position="labelPosition"
              :inline="true"
              :model="formInline"
              ref="formInline"
              label-width="80px"
            >
              <div style="padding: 10px;">
                <el-form-item label="订单编号" prop="objectId_Like">
                  <el-input
                    v-model="formInline.objectId"
                    placeholder="请输入内容"
                  ></el-input>
                </el-form-item>
                <el-form-item label="分发时间" prop="fenfaTime">
                  <el-date-picker
                    @change="fenfaChange"
                    v-model="formInline.objectTime"
                    type="datetimerange"
                    :picker-options="fenfaOptions"
                    placeholder="选择时间范围"
                    align="right"
                  >
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="质检结果" prop="calledNo">
                  <el-input
                    v-model="formInline.score_Max"
                    style="width: 100px"
                    placeholder="请输入内容"
                  ></el-input>
                  --
                  <el-input
                    v-model="formInline.score_Min"
                    style="width: 100px"
                    placeholder="请输入内容"
                  ></el-input>
                </el-form-item>
                <div>
                  <el-form-item label="任务状态" prop="taskType_list">
                    <el-select
                      clearable
                      @change="changeType"
                      v-model="formInline.state"
                      placeholder="请选择"
                      style="width: 175px;"
                    >
                      <el-option
                        v-for="item in orderAppealState"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </el-form-item>
                </div>
                <div>
                  <el-form-item label="申诉状态" prop="taskType_list">
                    <el-select
                      clearable
                      @change="changeType"
                      v-model="formInline.appealState"
                      placeholder="请选择"
                      style="width: 175px;"
                    >
                      <el-option
                        v-for="item in pageConstantValue.appealState"
                        :key="item.id"
                        :label="item.name"
                        :value="item.id"
                      >
                      </el-option>
                    </el-select>
                  </el-form-item>
                </div>
              </div>
            </el-form>
          </div>
        </div>
      </el-col>

      <el-col :span="rightSpan">
        <div class="rightContent">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="tableBox">
            <div class="table" style="overflow: auto;padding:0px 10px;">
              <el-table
                :data="tableData"
                border
                highlight-current-row
                style="width: 100%"
              >
                <el-table-column fixed="left" prop="objectId" label="订单编号">
                  <template scope="scope">
                    <el-button type="text" @click="showDetail(scope.row.objectId, scope.row.recordFileURL)">{{
                      scope.row.objectId
                    }}</el-button>
                  </template>
                </el-table-column>
                <el-table-column
                  prop="objectTime"
                  :formatter="dateFormat"
                  label="下单时间"
                >
                </el-table-column>
                <el-table-column prop="state" :formatter="stateFormat" label="任务状态">
                </el-table-column>
                <el-table-column
                  prop="appealState"
                  :formatter="appealStateFormat"
                  label="申诉状态"
                >
                </el-table-column>
                <el-table-column prop="score" label="质检结果"> </el-table-column>
                <el-table-column label="操作">
                  <template scope="scope">
                    <div style="cursor: pointer">
                      <i
                        @click="getAppealDetails(scope.row)"
                        class="iconfont icon-jiancha"
                        style="font-size:14px"
                        ><i style="padding-left: 3px;">查看</i></i
                      >
                      <i
                        v-if="scope.row.state == '0'"
                        @click="leaderHandleOpen(scope.row, 3)"
                        class="el-icon-circle-check"
                        style="font-size:14px"
                        ><i style="padding-left: 3px;">通过</i></i
                      >
                      <i
                        v-if="scope.row.state == '0'"
                        @click="leaderHandleOpen(scope.row, 2)"
                        class="el-icon-circle-close"
                        style="font-size:14px"
                        ><i style="padding-left: 3px;">拒绝</i></i
                      >
                    </div>
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="page">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageindex"
                :page-sizes="[20, 30, 40]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>

    <el-dialog
      title="组长审批"
      :visible.sync="leaderHandleVisible"
      :close-on-click-modal="false"
      :before-close="leaderHandleClose"
    >
      <div>
        <el-form :model="leaderHandle" ref="leaderHandle" label-width="100px">
          <el-form-item :label="leaderHandle.label">
            <el-input
              type="textarea"
              autosize
              v-model="leaderHandle.appealReason"
              placeholder="请输入审批理由"
            ></el-input>
          </el-form-item>
          <el-form-item>
            <div class="btns">
              <el-button @click="leaderHandleClose">取消</el-button>
              <el-button type="primary" @click="leaderAppealProcess">保存</el-button>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </el-dialog>

    <el-dialog title="坐席申诉流程详情" :visible.sync="lookSeatAppealModel">
      <div class="flowContent">
        <div class="flowContentBox">
          <div style="height: 300px;">
            <el-steps direction="vertical" :active="1">
              <div v-for="item in appealDetailData">
                <el-step :title="item.role">
                  <div slot="description">
                    <div style="padding-bottom: 10px;">
                      审批理由：{{ item.appealReason }}
                    </div>
                    <div style="padding-bottom: 10px;">
                      审批人：{{ item.appealUserId }}
                    </div>
                    <div style="padding-bottom: 10px;">
                      审批结果：{{ item.appealState }}
                    </div>
                    <div style="padding-bottom: 10px;">
                      审批时间：{{ item.appealTime }}
                    </div>
                  </div>
                </el-step>
              </div>
            </el-steps>
          </div>
        </div>
      </div>
    </el-dialog>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import axios from 'axios'
import Qs from 'qs'
import global from '../../../global.js'
import recordingplay from '../recordingPlayOrder/recordingPlayOrder.vue'
import bus from '../../common/bus.js'
let qualityUrl = global.qualityUrl
axios.defaults.withCredentials = true
axios.defaults.headers = {
  'Content-Type': 'application/x-www-form-urlencoded ;charset=UTF-8',
}
let orderAppealUrl = qualityUrl + '/orderAppeal'
import formatdate from '../../../utils/formatdate.js'
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      recordDialogVisible: false,
      labelPosition: 'right',
      hidden: false, // 左侧部分是否隐藏
      leaderHandle: {
        appealReason: '',
        label: '',
        appealData: '',
        appealState: '',
      },
      pageConstantValue: {},
      appealTaskState: [
        {
          value: 1,
          label: '坐席发起申诉',
        },
      ],
      orderType: '',
      orderTypeOptions: [
        {
          value: 1,
          label: '录音',
        },
        {
          value: 2,
          label: '订单',
        },
      ],
      orderAppealState: [
        {
          value: 0,
          label: '未处理',
        },
        {
          value: 1,
          label: '已处理',
        },
      ],
      appealDetailData: [
        {
          appealReason: '',
          appealUserId: '',
          appealState: '',
          appealTime: '',
        },
      ],
      leaderHandleVisible: false,
      lookSeatAppealModel: false,
      callOptions: {
        disabledDate(time) {},
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      planOptions: {
        disabledDate(time) {},
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      fenfaOptions: {
        disabledDate(time) {},
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      pickerOptions2: {
        disabledDate(time) {
          // return time.getTime() < Date.now() - 8.64e7;
        },
        /* shortcuts: [ {
            onClick(picker) {
             // const end = new Date();
              //const start = new Date();
              //start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
             // picker.$emit('pick', [start, end]);
            }
          }] */
      },
      tableData: [],
      formInline: {
        objectId: '', // 订单编号
        objectTime: '', // 下单时间
        state: '', // 任务状态
        appealState: '', // 申诉状态
        score_Max: '', // 质检成绩
        score_Min: '',
        appealTaskId: '', // 申诉任务Id
        appealId: '', // 待办任务Id
      },
      pageConstant: 'appealState',
      pageindex: 1,
      pagesize: 20,
      totalCount: 0,
      selection: '',
      statisticsModel: false,
      formItem: {
        value1: '',
      },
      qaUser: '',
      fromDate: '',
      toDate: '',
      fFSDate: '',
      fFEndDate: '',
      pStartDate: '',
      pEndDate: '',
      cStartDate: '',
      cEndDate: '',
    }
  },
  computed: {
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
  methods: {
    showDetail(id, recordFileURL) {
      let obj = {}
      obj.pageId = 'appealOrderInfo'
      obj.callId = id
      obj.recordFileURL = recordFileURL
      obj.orderNo = id
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push({path: '/recordingPlayOrder', query: obj})
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    toggleContainer() {
      this.hidden = !this.hidden
    },
    appealStepsDetails() {
      this.lookSeatAppealModel = true
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.searchTapTask()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.searchTapTask()
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    stateFormat: function(row, column) {
      let state = row[column.property]
      if (state == 0) {
        return '待处理'
      } else {
        return '已处理'
      }
    },
    appealStateFormat: function(row, column) {
      let state = row[column.property]
      let appealTaskState = this.pageConstantValue.appealState
      for (let i = 0; i < appealTaskState.length; i++) {
        if (state == appealTaskState[i].id) {
          return appealTaskState[i].name
        }
      }
    },
    // 将数字转换为时分秒

    // 将录音时长转换为秒
    dateFormatTwo(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    searchTask: function() {
      this.searchTapTask()
    },
    change: function(val) {
      this.formInline.taskStatus_list = val
    },
    changeType: function(val) {
      this.formInline.taskType_list = val
    },
    changeData: function(val) {
      this.formInline.callSDate = val
    },
    // 截取分发时间
    fenfaChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.fFSDate = fdata
      this.fFEndDate = edata
    },
    // 截取计划时间
    planChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.pStartDate = fdata
      this.pEndDate = edata
    },
    callChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.cStartDate = fdata
      this.cEndDate = edata
    },
    changeTime2: function(val) {
      let fdata = val.substring(0, 10)
      let edata = val.substring(13, 23)
      /* if(fdata==edata){
           fdata=fdata+" 00:00:00"
           edata=edata+" 23:59:59"
         } */
      this.fromDate = fdata
      this.toDate = edata
    },
    changeTime: function(val) {
      this.formInline.callETime = val
      if (this.formInline.callETime < this.formInline.callSDate) {
        this.$message({
          type: 'warning',
          message: '结束时间要大于开始时间',
        })
      }
    },
    leaderHandleClose() {
      this.leaderHandleVisible = false
      this.appealProcessTemp = ''
    },
    leaderHandleOpen(val, appealState) {
      this.leaderHandleVisible = true
      this.leaderHandle.appealData = val
      this.leaderHandle.appealState = appealState
      if (appealState == 3) {
        this.leaderHandle.label = '审批通过原因'
      } else {
        this.leaderHandle.label = '审批拒绝原因'
      }
    },
    leaderAppealProcess() {
      let appealDate = this.leaderHandle.appealData
      let params = {
        appealId: appealDate.appealId,
        appealTaskId: appealDate.appealTaskId,
        appealReason: this.leaderHandle.appealReason,
        appealState: this.leaderHandle.appealState,
      }
      this.appealProcess(params)
    },
    getAppealDetails(val) {
      this.appealStepsDetails()
      let params = {
        taskId: val.appealTaskId,
      }
      this.axios
        .post(orderAppealUrl + '/getAppealSteps.do', Qs.stringify(params))
        .then((res) => {
          this.appealDetailData = res.data.results
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    appealProcess: function(val) {
      let params = val
      this.axios
        .post(qualityUrl + '/orderAppeal/appealProcess.do', Qs.stringify(params))
        .then((res) => {})
        .catch(function(error) {
          console.log(error)
        })
    },
    getValue() {
      let parmas = {
        keys: this.pageConstant,
      }
      this.axios
        .post(qualityUrl + '/pageConstant/getValue.do', Qs.stringify(parmas))
        .then((res) => {
          this.pageConstantValue = res.data
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    searchTapTask: function() {
      let params = {
        objectId: this.formInline.objectId,
        objectTime_Min: this.fFSDate,
        objectTime_Max: this.fFEndDate,
        score_Min: this.formInline.score_Min,
        score_Max: this.formInline.score_Max,
        state: this.formInline.state,
        appealState: this.formInline.appealState,
        role: 'headman',
      }

      let obj = {}
      obj.searchModel = {}
      obj.searchModel.queryString = this.formInline
      this.$store.commit('setRecordingPlayPage', obj)

      this.axios
        .post(
          qualityUrl +
            '/orderAppeal/getAppealList.do?pageSize=' +
            this.pagesize +
            '&pageNumber=' +
            this.pageindex,
          Qs.stringify(params)
        )
        .then((res) => {
          let data = res.data
          this.tableData = data.results
          this.totalCount = res.data.count
        })
        .catch(function(error) {
          console.log(error)
        })
    },
  },
  created() {
    this.recordPlayCloseHandler()
    this.getValue()
  },
}
</script>
<style lang="less">
.el-select.w-200 {
  width: 200px;
}
</style>
<style scoped="scoped" lang="less">
.leaderOrderAppeal {
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
  .rightContent {
    height: 100%;
    width: 100%;
    box-sizing: border-box;
    position: relative;
    .tableBox {
      padding-top: 8px;
      padding-bottom: 80px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      .table {
        width: 100%;
        height: 100%;
      }
      .page {
        right: 10px;
        position: absolute;
        bottom: 10px;
      }
    }
  }
  .toggle-show {
    position: absolute;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggleBtn {
    cursor: pointer;
    width: 20px;
    height: 30px;
    background-image: url('../../../assets/img/close.png');
    position: absolute;
    left: -20px;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggle-hidden {
    left: 0px;
    transform: rotate(180deg);
  }
  .leftContent {
    height: 100%;
    overflow: auto;
    left: 0px;
    top: 0px;
    position: relative;
    border-right: 1px solid #d1dbe5;
    .searchHeader {
      border-bottom: 1px dashed #d1dbe5;
      position: absolute;
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      position: absolute;
      top: 0px;
      left: 0px;
      width: 100%;
    }
    .searchForm {
      position: absolute;
      top: 65px;
      left: 0px;
      bottom: 0px;
      overflow: auto;
      width: 100%;
      cursor: pointer;
      p {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        font-weight: bold;
        color: #9dadc2;
      }
    }
  }
  .el-row {
    height: 100%;
    .el-col {
      height: 100%;
    }
  }
}
#leaderOrderAppeal div {
  box-sizing: border-box;
}
#leaderOrderAppeal {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
}
</style>
