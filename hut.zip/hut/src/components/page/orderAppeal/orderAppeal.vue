<template>
  <div class="myQCTask" id="myQCTask">
    <div class="myQCTask-box">
      <div class="myQCTask-box-nav">
        <ul>
          <li data-id="1" @click="taskActive" class="active">坐席申诉</li>
          <li data-id="2" @click="taskActive">组长申诉</li>
          <li data-id="3" @click="taskActive">主管申诉</li>
        </ul>
      </div>
      <div class="myQCTask-box-content">
        <vSeatOrderAppeal style="width:100%;height:100%;" v-show="index == 1">
        </vSeatOrderAppeal>
        <vLeaderAppeal
          style="width:100%;height:100%;"
          v-show="index == 2"
        ></vLeaderAppeal>
        <vSuperVisorAppeal style="width:100%;height:100%;" v-show="index == 3">
        </vSuperVisorAppeal>
      </div>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import vLeaderAppeal from './leaderOrderAppeal.vue' // 组长申诉
import vSuperVisorAppeal from './superVisorOrderAppeal.vue' // 主管申诉
import vSeatOrderAppeal from './seatOrderAppeal.vue' // 坐席申诉
export default {
  components: {
    vLeaderAppeal,
    vSuperVisorAppeal,
    vSeatOrderAppeal,
  },
  data() {
    return {
      index: '1',
    }
  },
  methods: {
    taskActive: function() {
      let currentIndex = $(event.target).attr('data-id')
      this.index = currentIndex
      $('.myQCTask-box-nav ul li').removeClass('active')
      $(event.target).addClass('active')
    },
  },
  mounted() {
    if (
      this.recordingPlayPage.fromPage == 'myQaTasks' &&
      this.recordingPlayPage.qaScoreType
    ) {
      let index = this.recordingPlayPage.qaScoreType - 1
      // 控制三个tab页的展示1=》初检任务，2=》复检任务，3=》复议任务
      $('.myQCTask-box-nav > ul> li')[index].click()
    }
  },
  computed: {
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less" scoped="scoped">
.myQCTask {
  width: 100%;
  box-sizing: border-box;
  height: 100%;
  position: relative;
  .myQCTask-box {
    width: 100%;
    height: 100%;
    position: relative;
    ul {
      width: 100%;
      padding: 0 12.5px;
      box-sizing: border-box;
      .active {
        color: #21a2ff !important;
      }
      li {
        float: left;
        padding: 0 12.5px;
        box-sizing: border-box;
        font-size: 14px;
        color: #96a2b2;
        cursor: pointer;
      }
    }
    .myQCTask-box-content {
      padding-top: 42px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .myQCTask-box-nav {
      width: 100%;
      height: 40px;
      line-height: 40px;
      background: #eef1f6;
      border-bottom: 1px solid #d1dbe4;
      position: absolute;
    }
  }
}
</style>
<style>
#myQCTask .el-tabs__active-bar {
  background: none;
}
</style>
