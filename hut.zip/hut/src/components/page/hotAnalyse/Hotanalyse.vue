<template>
  <div id="hotanalyse">
    <div class="hotanalyse-header">
      <div style="width:100%;height:100%;" class="hotanalyse-header-pos">
        <el-form :model="searchModel" ref="searchModel" :inline="true">
          <div style="width:100%;height:36px;margin-top:10px;margin-bottom: 10px;">
            <el-form-item label="时间：" prop="timeAreaType">
              <el-date-picker
                v-model="searchModel.times"
                type="daterange"
                align="right"
                placeholder="选择日期范围"
                :picker-options="pickerOptions2"
              >
              </el-date-picker>
              <!--<el-radio-group v-model="searchModel.timeAreaType"
                              @change="resetTime"
                              style="margin-top: 9px;">
                <el-radio label="1">近一天</el-radio>
                <el-radio label="2">近一周</el-radio>
                <el-radio label="3">近一月</el-radio>
                <el-radio label="4">其他</el-radio>
              </el-radio-group>-->
            </el-form-item>
            <!--<el-form-item prop="callSTime_Min">
              <el-date-picker type="date" placeholder="开始日期" v-model="searchModel.callSTime_Min" @change="setMinTime"></el-date-picker>
            </el-form-item>
            <el-form-item prop="callSTime_Max">
              <el-date-picker type="date" placeholder="结束日期" v-model="searchModel.callSTime_Max" @change="setMaxTime"></el-date-picker>
            </el-form-item>-->
            <el-form-item label="词汇类型：" style="margin-left: 20px"></el-form-item>
            <el-form-item prop="buss_wordType">
              <el-radio-group
                v-model="searchModel.buss_wordType"
                style="margin-top: 9px;"
              >
                <el-radio label="0">全部</el-radio>
                <el-radio label="1">热词</el-radio>
                <el-radio label="2">新词</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="角色：" style="margin-left: 20px"></el-form-item>
            <el-form-item prop="wordRole">
              <el-radio-group
                v-model="searchModel.wordRole"
                @change="radioChange"
                style="margin-top: 9px;"
              >
                <el-radio label="0">全部</el-radio>
                <el-radio label="1">客户</el-radio>
                <el-radio label="2">客服</el-radio>
              </el-radio-group>
            </el-form-item>
          </div>
          <el-form-item label="主维度" prop="mainMd">
            <el-select
              v-model="searchModel.mainMd"
              placeholder="请选择"
              clearable
              @change="changeDimention('mainMd')"
            >
              <el-option
                :label="item.value"
                :value="item.key"
                v-for="item in dimentions"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="mainMdVal">
            <el-select v-model="searchModel.mainMdVal" placeholder="请选择" clearable>
              <el-option
                :label="item[mainSubDimentionLabel]"
                :value="item[mainSubDimentionValue]"
                v-for="item in mainMdVals"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="副维度" prop="viceMd">
            <el-select
              v-model="searchModel.viceMd"
              placeholder="请选择"
              clearable
              @change="changeDimention('viceMd')"
            >
              <el-option
                :label="item.value"
                :value="item.key"
                v-for="item in dimentions"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="viceMdVal">
            <el-select v-model="searchModel.viceMdVal" placeholder="请选择" clearable>
              <el-option
                :label="item[viceSubDimentionLabel]"
                :value="item[viceSubDimentionValue]"
                v-for="item in viceMdVals"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item style="float: right">
            <el-button size="medium" @click="resetForm('searchModel')"
              >清空</el-button
            >
          </el-form-item>
          <el-form-item style="float: right">
            <el-button type="primary" size="medium" @click="search">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <el-dialog :title="addTitle" :visible.sync="addWordModalVisible">
      <div style="width:100%;overflow: hidden;">
        <div style="float: left;width: 30%; height:320px;border: 1px solid #d1dbe5">
          <!-- <el-tree check-strictly :data="treeData"  node-key="classId"
                    highlight-current :expand-on-click-node="false"  default-expand-all ref="editTree"
                    show-checkbox>
           </el-tree>-->
          <el-tree
            :data="treeData"
            :props="defaultProps"
            ref="keyWordMenu"
            node-key="classId"
            @node-click="handleNodeClick"
            check-strictly
          >
          </el-tree>
        </div>
        <div style="float: right;width: 68%;height:320px;border: 1px solid #d1dbe5">
          <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">关键词描述</div>
          <el-input
            type="textarea"
            v-model="wordDescribe"
            :rows="10"
            style="width: 90%; margin: 10px 0px 0px 10px;"
          ></el-input>
        </div>
        <div slot="footer" style="float: right; margin-top: 10px">
          <el-button funcId="000234" @click="cancelAdd">取 消</el-button>
          <el-button funcId="000235" type="primary" @click="handleAddKeyWordThrottle"
            >确 定</el-button
          >
        </div>
      </div>
    </el-dialog>
    <el-dialog
      :title="addWalterTitle"
      :visible.sync="addWalterWordModalVisible"
    >
      <div style="width:100%;overflow: hidden;">
        <div style="float: left;width: 30%; height:320px;border: 1px solid #d1dbe5">
          <!-- <el-tree check-strictly :data="treeData"  node-key="classId"
                    highlight-current :expand-on-click-node="false"  default-expand-all ref="editTree"
                    show-checkbox>
           </el-tree>-->
          <el-tree
            :data="treeData"
            :props="defaultProps"
            ref="keyWordMenu"
            node-key="classId"
            @node-click="handleNodeClick"
            check-strictly
          >
          </el-tree>
        </div>
        <div style="float: right;width: 68%;height:320px;border: 1px solid #d1dbe5">
          <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">
            角色类型
            <el-select v-model="roleType" style="margin-left: 5px;margin-top: 1px;">
              <el-option label="客户" value="1"></el-option>
              <el-option label="客服" value="2"></el-option>
              <el-option label="全部" value="0"></el-option>
            </el-select>
          </div>

          <div style="padding: 10px;border-bottom: 1px dashed #d1dbe5">水词描述</div>
          <el-input
            type="textarea"
            v-model="wordDescribe"
            :rows="9"
            style="width: 90%; margin: 10px 0px 0px 10px;"
          ></el-input>
        </div>
        <div slot="footer" style="float: right; margin-top: 10px">
          <el-button funcId="000236" @click="cancelWalterAdd">取 消</el-button>
          <el-button
            funcId="000237"
            type="primary"
            @click="handleWalterAddKeyWordThrottle"
            >确 定</el-button
          >
        </div>
      </div>
    </el-dialog>

    <div class="hotanalyse-content">
      <div class="hotanalyse-content-pos clearfix">
        <div class="hotanalyse-content-left fl" style="position: relative;">
          <div class="hotanalyseLeft-header clearfix" style="position: absolute;">
            <span
              style="font-size:14px;display: inline-block;height:46px;line-height: 46px;"
              >热词统计</span
            >
            <el-button
              funcId="000238"
              class="fr"
              style="margin-top:10px;margin-right: 20px;"
              @click="removeKeyWord"
              >移入水词</el-button
            >
            <el-button
              funcId="000239"
              class="fr"
              style="margin-top:10px;margin-right: 20px;"
              @click="addKeyWord"
              >添加关键词</el-button
            >
          </div>
          <div class="hotanalyseLeft-content">
            <div class="hotanalyseLeft-content-pos" style="overflow-y: auto;">
              <el-table
                ref="multipleTable"
                highlight-current-row
                :data="tableCiData"
                border
                @selection-change="handleAllClick"
                @row-click="rowClick"
                style="width: 100%"
              >
                <el-table-column type="selection" width="55"> </el-table-column>
                <el-table-column type="index" label="序号" width="70"> </el-table-column>
                <el-table-column prop="keyword" label="词语"> </el-table-column>
                <el-table-column prop="times" label="热度" show-overflow-tooltip>
                </el-table-column>
                <!-- <el-table-column
                prop="ratio"
                label="环比">

                </el-table-column> -->
              </el-table>
            </div>
          </div>
        </div>
        <div class="hotanalyse-content-right fl">
          <div class="box">
            <div class="hotTop">
              <ul>
                <li @click="quShiTu(1)" class="activeQu" id="qushi">趋势图</li>
                <li @click="quShiTu(2)" id="ci">词相关</li>
                <li @click="quShiTu(3)" id="place">区域图</li>
              </ul>
            </div>
            <div class="hotanalyseRight">
              <div class="hotBox">
                <div id="trendChart" style="width: 100%; height: 100%"></div>
                <div id="ciChart" style="width: 100%; height: 100%; display: none"></div>
                <div
                  id="placeChart"
                  style="width: 100%; height: 100%;display: none"
                ></div>
              </div>
            </div>
          </div>
          <!--<div class="hotanalyseRight">
            <span>趋势图</span>
            <div id="trendImage" style="height:90%; overflow: scroll;">

            </div>
          </div>-->
          <!--<div class="hotanalyseRightbottom">
            <span>词表图</span>
            <div id="wordImage"  style="height:200px;">

            </div>
          </div>-->
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import $ from 'jquery'
import cache from '../../../utils/cache.js'
import formatDate from '../../../utils/formatdate.js'
import qs from 'qs'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
let CASTGC = cache.getItem('tgt_id')
let myChartCi
export default {
  data() {
    return {
      qushiEchartsOption: {
        title: {
          text: '',
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: [],
        },

        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            boundaryGap: false,
            data: [],
            splitLine: {
              show: true,
            },
            axisLine: {
              show: false,
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
            splitLine: {
              show: true,
            },
            axisLine: {
              show: false,
            },
          },
        ],
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        series: [],
      },
      pickerOptions2: {
        shortcuts: [
          {
            text: '近一天',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 1)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      loading: false,
      activeName2: 'first',
      checkboxGroup1: ['上海'],
      checkboxGroup2: ['北京'],
      checkboxGroup3: ['广州'],
      cities: ['上海', '北京', '广州', '深圳'],
      mapOption: {
        series: [
          {
            type: 'map',
            data: [
              { name: '北京', value: Math.round(Math.random() * 1000) },
              { name: '天津', value: Math.round(Math.random() * 1000) },
              { name: '上海', value: Math.round(Math.random() * 1000) },
              { name: '重庆', value: Math.round(Math.random() * 1000) },
              { name: '河北', value: Math.round(Math.random() * 1000) },
              { name: '河南', value: Math.round(Math.random() * 1000) },
              { name: '云南', value: Math.round(Math.random() * 1000) },
              { name: '辽宁', value: Math.round(Math.random() * 1000) },
              { name: '黑龙江', value: Math.round(Math.random() * 1000) },
              { name: '湖南', value: Math.round(Math.random() * 1000) },
              { name: '安徽', value: Math.round(Math.random() * 1000) },
              { name: '山东', value: Math.round(Math.random() * 1000) },
              { name: '新疆', value: Math.round(Math.random() * 1000) },
              { name: '江苏', value: Math.round(Math.random() * 1000) },
              { name: '浙江', value: Math.round(Math.random() * 1000) },
              { name: '江西', value: Math.round(Math.random() * 1000) },
              { name: '湖北', value: Math.round(Math.random() * 1000) },
              { name: '广西', value: Math.round(Math.random() * 1000) },
              { name: '甘肃', value: Math.round(Math.random() * 1000) },
              { name: '山西', value: Math.round(Math.random() * 1000) },
              { name: '内蒙古', value: Math.round(Math.random() * 1000) },
              { name: '陕西', value: Math.round(Math.random() * 1000) },
              { name: '吉林', value: Math.round(Math.random() * 1000) },
              { name: '福建', value: Math.round(Math.random() * 1000) },
              { name: '贵州', value: Math.round(Math.random() * 1000) },
              { name: '广东', value: Math.round(Math.random() * 1000) },
              { name: '青海', value: Math.round(Math.random() * 1000) },
              { name: '西藏', value: Math.round(Math.random() * 1000) },
              { name: '四川', value: Math.round(Math.random() * 1000) },
              { name: '宁夏', value: Math.round(Math.random() * 1000) },
              { name: '海南', value: Math.round(Math.random() * 1000) },
              { name: '台湾', value: Math.round(Math.random() * 1000) },
              { name: '香港', value: Math.round(Math.random() * 1000) },
              { name: '澳门', value: Math.round(Math.random() * 1000) },
            ],
          },
        ],
      },
      optionRate: {
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          show: true,
          data: [],
          // right: 10,
          // top: '45%',
          // orient: 'vertical'
        },
        xAxis: [
          {
            data: [],
          },
        ],
        yAxis: {},
        series: [
          {
            name: '',
            type: 'line',
            stack: '广告',
            data: [],
            itemStyle: {
              normal: {
                color: '#50b4ff',
              },
            },
          },
        ],
      },
      roleType: '0',
      addTitle: '添加关键词',
      addWalterTitle: '添加水词',
      currentNode: '',
      addWordModalVisible: false,
      addWalterWordModalVisible: false,
      wordDescribe: '',
      classId: 0,
      treeData: [],
      treeWalterData: [],
      selectKeyWord: '',
      callSTime_Min: '',
      callSTime_Max: '',
      searchModel: {
        buss_wordType: '1', // 词汇类型
        times: '', // 时间
        function: '1', // 统计的单位，1为录音量，2为平均时长，3为总通话时长
        mainMd: '', // 主维度下拉框
        viceMd: '', // 副维度下拉框
        mainMdVal: '', // 主维度的第二个下拉框值
        viceMdVal: '', // 副维度的第二个下拉框值
        timeAreaType: '4',
        wordRole: '0', // 角色 0为全部 1为客户 2为客服
      },
      dimentions: [], // 主维度和副维度下拉框的值
      mainMdVals: [], // 主维度的第二个下拉框
      viceMdVals: [], // 副维度的第二个下拉框
      yType: '1', // 纵坐标
      xAx: '2', // 横坐标
      groupBy: '', // groupBy字段，统计主副维度数据时使用
      mainSubDimentionValue: '', // 主维度的二级维度下拉框Value
      mainSubDimentionLabel: '', // 主维度的二级维度下拉框Label
      viceSubDimentionValue: '', // 副维度的二级维度下拉框Value
      viceSubDimentionLabel: '', // 副维度的二级维度下拉框Label
      value1: '', //
      value4: '',
      currentPage3: 1,
      tableCiData: [],
      option1: {
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: '',
        },
        toolbox: {
          show: true,
          feature: {
            saveAsImage: {
              show: false,
            },
          },
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        calculable: true,
        grid: {
          top: 80,
          bottom: 50,
        },
        xAxis: [
          {
            type: 'category',
            boundaryGap: false,
            data: [],
          },
        ],
        yAxis: [
          {
            type: 'value',
          },
        ],
        series: [],
      },
      option2: {
        title: {
          text: ' ',
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        tooltip: {
          show: true,
          formatter: function(params) {
            return '词语信息：' + params.name + '<br>词频：' + params.value / 10
          },
        },
        series: [
          {
            name: '词语',
            type: 'wordCloud',
            size: ['80%', '80%'],
            textRotation: [0, 0],
            textPadding: 10,
            autoSize: {
              enable: true,
              minSize: 14,
            },
            data: [],
          },
        ],
      },
      defaultProps: {
        children: 'childIqc',
        label: 'classTitle',
      },
      fullscreenLoading: false,
      keyword: '',
      mapData: [],
      cioption: {
        title: {
          text: '', // 标题
        },
        label: {
          normal: {
            show: true,
            textStyle: {
              fontSize: 12,
            },
          },
        },
        // 全局颜色，图例、节点、边的颜色都是从这里取，按照之前划分的种类依序选取
        // color: ['rgb(194,53,49)', 'rgb(178,144,137)', 'rgb(97,160,168)'],
        // sereis的数据: 用于设置图表数据之用
        series: [
          {
            name: '', // 系列名称
            type: 'graph', // 图表类型
            layout: 'force', // echarts3的变化，force是力向图，circular是和弦图
            symbolSize: 45,
            // focusNodeAdjacency: true,  // 突出相关
            force: {
              // gravity: 0.1,
              // symbol: 'pin',
              edgeLength: [100, 10], // 线的长度，这个距离也会受 repulsion，支持设置成数组表达边长的范围
              repulsion: 200, // 节点之间的斥力因子。值越大则斥力越大
            },
            // draggable: true, // 指示节点是否可以拖动
            roam: true, // 是否开启鼠标缩放和平移漫游。默认不开启。如果只想要开启缩放或者平移，可以设置成 'scale' 或者 'move'。设置成 true 为都开启
            label: {
              // 图形上的文本标签，可用于说明图形的一些数据信息
              normal: {
                show: true, // 显示
                color: '#fff',
                position: 'inside', // 相对于节点标签的位置
                // 回调函数，你期望节点标签上显示什么
                formatter: function(params) {
                  return params.data.label
                },
              },
            },
            // 节点的style
            itemStyle: {
              normal: {
                label: { show: true },
                nodeStyle: {
                  brushType: 'both',
                  borderColor: 'rgba(255,215,0,0.4)',
                  borderWidth: 1,
                },
              },
            },
            // 关系边的公用线条样式
            lineStyle: {
              normal: {
                width: 3,
                type: 'solid',
                show: true,
                color: 'target', // 决定边的颜色是与起点相同还是与终点相同
                curveness: 0.3, // 边的曲度，支持从 0 到 1 的值，值越大曲度越大。
              },
            },
            categories: [],
            nodes: [],
            links: [],
          },
        ],
      },
    }
  },
  methods: {
    quShiTu: function(val) {
      if (val === 1) {
        $('#trendChart').show()
        $('#ciChart').hide()
        $('#placeChart').hide()
        $('#qushi').addClass('activeQu')
        $('#ci').removeClass('activeQu')
        $('#place').removeClass('activeQu')
      } else if (val === 2) {
        $('#trendChart').hide()
        $('#ciChart').show()
        $('#placeChart').hide()
        $('#qushi').removeClass('activeQu')
        $('#ci').addClass('activeQu')
        $('#place').removeClass('activeQu')
        myChartCi = this.$echarts.init(document.getElementById('ciChart'))
        myChartCi.resize()
      } else {
        $('#trendChart').hide()
        $('#ciChart').hide()
        $('#placeChart').show()
        $('#qushi').removeClass('activeQu')
        $('#ci').removeClass('activeQu')
        $('#place').addClass('activeQu')
        let myChartPlace = this.$echarts.init(document.getElementById('placeChart'))
        myChartPlace.resize()
      }
    },
    getQuShiTu() {
      let _this = this
      _this.callSTime_Min = this.gettimeform(this.searchModel.times[0])
      _this.callSTime_Max = this.gettimeform(this.searchModel.times[1])
      let params = {}
      if (_this.callSTime_Min == '' || _this.callSTime_Max == '') {
        return
      }
      params.beginDate = _this.callSTime_Min
      params.endDate = _this.callSTime_Max
      params.majorDim = this.searchModel.mainMd || '-1'
      params.viceDim = this.searchModel.viceMd || '-1'
      params.wordRole = this.searchModel.wordRole || '-1'
      params.buss_wordType = this.searchModel.buss_wordType
      params.keyWord = this.keyword
      let urlQs = currentBaseUrl + '/hotAnlys/getTrendData.do'
      this.axios
        .post(urlQs, qs.stringify(params))
        .then(function(response) {
          if (response.data.dateList.length > 0 && response.data.trendData.length > 0) {
            let dateList = response.data.dateList
            let trendData = response.data.trendData
            let dateData = []
            let trend = []
            let nums
            if (trendData.length <= 5) {
              nums = trendData.length
            } else {
              nums = 5
            }
            for (let i = 0; i < dateList.length; i++) {
              dateData[i] = dateList[i][0]
            }
            // series
            for (let j = 0; j < nums; j++) {
              trend[j] = {
                name: trendData[j].keyword,
                type: 'line',
                // stack: '总量',
                // areaStyle: {normal: {}},
                data: trendData[j].timesList,
              }
            }
            // legend data
            let legendData = []
            for (let p = 0; p < nums; p++) {
              legendData[p] = trendData[p].keyword
            }
            // xAxis
            let xAxisData = []
            for (let a = 0; a < dateList.length; a++) {
              xAxisData[a] = dateList[a]
            }
            let option = {
              title: {
                text: '',
                textStyle: {
                  color: '#5e6d82',
                  fontSize: 14,
                  fontWieght: 'normal',
                },
              },
              tooltip: {
                trigger: 'axis',
              },
              legend: {
                data: [],
              },

              grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true,
              },
              xAxis: [
                {
                  type: 'category',
                  boundaryGap: false,
                  data: [],
                  splitLine: {
                    show: true,
                  },
                  axisLine: {
                    show: false,
                  },
                },
              ],
              yAxis: [
                {
                  type: 'value',
                  splitLine: {
                    show: true,
                  },
                  axisLine: {
                    show: false,
                  },
                },
              ],
              color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
              series: [],
            }
            option.legend.data = legendData
            option.xAxis[0].data = xAxisData
            option.series = trend
            let myQushiChart = _this.$echarts.init(document.getElementById('trendChart'))
            myQushiChart.setOption(option, true)
          } else {
            console.log('没有数据')
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    rowClick: function(row, event, column) {
      this.keyword = row.keyWord
      myChartCi && myChartCi.dispose()
      let _this = this
      // 趋势图
      _this.getQuShiTu()
      // 地图
      let times = ''
      _this.getMap(row.keyWord, times)
      // 词相关
      _this.getci(row.keyWord)
    },
    getci(word) {
      let _this = this
      let ciparams = {}
      let wordData = []
      ciparams.word = word
      // 词相关数据画布渲染
      myChartCi = this.$echarts.init(document.getElementById('ciChart'))
      let categoriesList = [{ id: 0, name: '根' }]
      let linksList = [{ source: 0, target: 0 }]
      let nodesData = [
        {
          id: 0,
          category: 0,
          label: word,
          name: 0,
          symbolSize: 60,
          ignore: false,
          flag: true,
        },
      ]
      this.axios
        .post(currentBaseUrl + '/hotAnlys/getRelatedWords.do', qs.stringify(ciparams))
        .then((res) => {
          if (res.data.length > 0) {
            let dataLength
            if (res.data.length >= 15) {
              dataLength = 15
            } else {
              dataLength = res.data.length
            }
            for (let i = 0; i < dataLength; i++) {
              wordData[i] = {
                id: i + 1,
                category: 1,
                label: res.data[i].name,
                name: i + 1,
                symbolSize: res.data[i].score * 90,
                ignore: false,
                flag: true,
              }
            }
            let links = []
            for (let i = 0; i < dataLength; i++) {
              links[i] = {
                source: 0,
                target: i + 1,
              }
            }
            let categories = []
            for (let i = 0; i < dataLength; i++) {
              categories[i] = {
                id: i + 1,
                name: i + 1 + '层',
              }
            }
            _this.cioption.series[0].nodes = nodesData.concat(wordData)
            _this.cioption.series[0].categories = categories
            _this.cioption.series[0].links = links
            myChartCi.setOption(_this.cioption)
          } else {
            _this.cioption.series[0].nodes = nodesData
            _this.cioption.series[0].categories = categoriesList
            _this.cioption.series[0].links = linksList
            myChartCi.setOption(_this.cioption)
          }
        })
        .catch(function(error) {
          console.log(error)
        })
      myChartCi.on('click', function(params) {
        let paramsList = params
        _this.getClick(paramsList)
      })
    },
    getMap(keyword, times) {
      let params = {}
      let _this = this
      if (times == '') {
        _this.callSTime_Min = this.gettimeform(this.searchModel.times[0])
        _this.callSTime_Max = this.gettimeform(this.searchModel.times[1])
        if (_this.callSTime_Min == '' || _this.callSTime_Max == '') {
          return
        }
      } else {
        _this.callSTime_Min = times
        _this.callSTime_Max = times
      }

      params.beginDate = _this.callSTime_Min
      params.endDate = _this.callSTime_Max
      params.majorDim = this.searchModel.mainMd || '-1'
      params.viceDim = this.searchModel.viceMd || '-1'
      params.wordRole = this.searchModel.wordRole || '-1'
      params.buss_wordType = this.searchModel.buss_wordType
      params.keyWord = keyword
      let url = currentBaseUrl + '/hotAnlys/getAreaData.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data.area != null) {
            // let mdata = []
            let mmdata = response.data.area
            /* for (let i = 0; i < mmdata.length; i++) {
               mdata[i] = {
               name: mmdata[i].city,
               value: Object.values(mmdata[i].keywords)[0]
               }
               } */
            let legenddata = []
            for (let j = 0; j < mmdata.length; j++) {
              legenddata[j] = mmdata[j].city
            }
            let geoCoordMap = {
              海门: [121.15, 31.89],
              鄂尔多斯: [109.781327, 39.608266],
              招远: [120.38, 37.35],
              舟山: [122.207216, 29.985295],
              齐齐哈尔: [123.97, 47.33],
              盐城: [120.13, 33.38],
              赤峰: [118.87, 42.28],
              青岛: [120.33, 36.07],
              乳山: [121.52, 36.89],
              金昌: [102.188043, 38.520089],
              泉州: [118.58, 24.93],
              莱西: [120.53, 36.86],
              日照: [119.46, 35.42],
              胶南: [119.97, 35.88],
              南通: [121.05, 32.08],
              拉萨: [91.11, 29.97],
              云浮: [112.02, 22.93],
              梅州: [116.1, 24.55],
              文登: [122.05, 37.2],
              上海: [121.48, 31.22],
              攀枝花: [101.718637, 26.582347],
              威海: [122.1, 37.5],
              承德: [117.93, 40.97],
              厦门: [118.1, 24.46],
              汕尾: [115.375279, 22.786211],
              潮州: [116.63, 23.68],
              丹东: [124.37, 40.13],
              太仓: [121.1, 31.45],
              曲靖: [103.79, 25.51],
              烟台: [121.39, 37.52],
              福州: [119.3, 26.08],
              瓦房店: [121.979603, 39.627114],
              即墨: [120.45, 36.38],
              抚顺: [123.97, 41.97],
              玉溪: [102.52, 24.35],
              张家口: [114.87, 40.82],
              阳泉: [113.57, 37.85],
              莱州: [119.942327, 37.177017],
              湖州: [120.1, 30.86],
              汕头: [116.69, 23.39],
              昆山: [120.95, 31.39],
              宁波: [121.56, 29.86],
              湛江: [110.359377, 21.270708],
              揭阳: [116.35, 23.55],
              荣成: [122.41, 37.16],
              连云港: [119.16, 34.59],
              葫芦岛: [120.836932, 40.711052],
              常熟: [120.74, 31.64],
              东莞: [113.75, 23.04],
              河源: [114.68, 23.73],
              淮安: [119.15, 33.5],
              泰州: [119.9, 32.49],
              南宁: [108.33, 22.84],
              营口: [122.18, 40.65],
              惠州: [114.4, 23.09],
              江阴: [120.26, 31.91],
              蓬莱: [120.75, 37.8],
              韶关: [113.62, 24.84],
              嘉峪关: [98.289152, 39.77313],
              广州: [113.23, 23.16],
              延安: [109.47, 36.6],
              太原: [112.53, 37.87],
              清远: [113.01, 23.7],
              中山: [113.38, 22.52],
              昆明: [102.73, 25.04],
              寿光: [118.73, 36.86],
              盘锦: [122.070714, 41.119997],
              长治: [113.08, 36.18],
              深圳: [114.07, 22.62],
              珠海: [113.52, 22.3],
              宿迁: [118.3, 33.96],
              咸阳: [108.72, 34.36],
              铜川: [109.11, 35.09],
              平度: [119.97, 36.77],
              佛山: [113.11, 23.05],
              海口: [110.35, 20.02],
              江门: [113.06, 22.61],
              章丘: [117.53, 36.72],
              肇庆: [112.44, 23.05],
              大连: [121.62, 38.92],
              临汾: [111.5, 36.08],
              吴江: [120.63, 31.16],
              石嘴山: [106.39, 39.04],
              沈阳: [123.38, 41.8],
              苏州: [120.62, 31.32],
              茂名: [110.88, 21.68],
              嘉兴: [120.76, 30.77],
              长春: [125.35, 43.88],
              胶州: [120.03336, 36.264622],
              银川: [106.27, 38.47],
              张家港: [120.555821, 31.875428],
              三门峡: [111.19, 34.76],
              锦州: [121.15, 41.13],
              南昌: [115.89, 28.68],
              柳州: [109.4, 24.33],
              三亚: [109.511909, 18.252847],
              自贡: [104.778442, 29.33903],
              吉林: [126.57, 43.87],
              阳江: [111.95, 21.85],
              泸州: [105.39, 28.91],
              西宁: [101.74, 36.56],
              宜宾: [104.56, 29.77],
              呼和浩特: [111.65, 40.82],
              成都: [104.06, 30.67],
              大同: [113.3, 40.12],
              镇江: [119.44, 32.2],
              桂林: [110.28, 25.29],
              张家界: [110.479191, 29.117096],
              宜兴: [119.82, 31.36],
              北海: [109.12, 21.49],
              西安: [108.95, 34.27],
              金坛: [119.56, 31.74],
              东营: [118.49, 37.46],
              牡丹江: [129.58, 44.6],
              遵义: [106.9, 27.7],
              绍兴: [120.58, 30.01],
              扬州: [119.42, 32.39],
              常州: [119.95, 31.79],
              潍坊: [119.1, 36.62],
              重庆: [106.54, 29.59],
              台州: [121.420757, 28.656386],
              南京: [118.78, 32.04],
              滨州: [118.03, 37.36],
              贵阳: [106.71, 26.57],
              无锡: [120.29, 31.59],
              本溪: [123.73, 41.3],
              克拉玛依: [84.77, 45.59],
              渭南: [109.5, 34.52],
              马鞍山: [118.48, 31.56],
              宝鸡: [107.15, 34.38],
              焦作: [113.21, 35.24],
              句容: [119.16, 31.95],
              北京: [116.46, 39.92],
              徐州: [117.2, 34.26],
              衡水: [115.72, 37.72],
              包头: [110, 40.58],
              绵阳: [104.73, 31.48],
              乌鲁木齐: [87.68, 43.77],
              枣庄: [117.57, 34.86],
              杭州: [120.19, 30.26],
              淄博: [118.05, 36.78],
              鞍山: [122.85, 41.12],
              溧阳: [119.48, 31.43],
              库尔勒: [86.06, 41.68],
              安阳: [114.35, 36.1],
              开封: [114.35, 34.79],
              济南: [117, 36.65],
              德阳: [104.37, 31.13],
              温州: [120.65, 28.01],
              九江: [115.97, 29.71],
              邯郸: [114.47, 36.6],
              临安: [119.72, 30.23],
              兰州: [103.73, 36.03],
              沧州: [116.83, 38.33],
              临沂: [118.35, 35.05],
              南充: [106.110698, 30.837793],
              天津: [117.2, 39.13],
              富阳: [119.95, 30.07],
              泰安: [117.13, 36.18],
              诸暨: [120.23, 29.71],
              郑州: [113.65, 34.76],
              哈尔滨: [126.63, 45.75],
              聊城: [115.97, 36.45],
              芜湖: [118.38, 31.33],
              唐山: [118.02, 39.63],
              平顶山: [113.29, 33.75],
              邢台: [114.48, 37.05],
              德州: [116.29, 37.45],
              济宁: [116.59, 35.38],
              荆州: [112.239741, 30.335165],
              宜昌: [111.3, 30.7],
              义乌: [120.06, 29.32],
              丽水: [119.92, 28.45],
              洛阳: [112.44, 34.7],
              秦皇岛: [119.57, 39.95],
              株洲: [113.16, 27.83],
              石家庄: [114.48, 38.03],
              莱芜: [117.67, 36.19],
              常德: [111.69, 29.05],
              保定: [115.48, 38.85],
              湘潭: [112.91, 27.87],
              金华: [119.64, 29.12],
              岳阳: [113.09, 29.37],
              长沙: [113, 28.21],
              衢州: [118.88, 28.97],
              廊坊: [116.7, 39.53],
              菏泽: [115.480656, 35.23375],
              合肥: [117.27, 31.86],
              武汉: [114.31, 30.52],
              大庆: [125.03, 46.58],
            }
            let convertData = function(data) {
              let res = []
              for (let i = 0; i < data.length; i++) {
                let geoCoord = geoCoordMap[data[i].name]
                if (geoCoord) {
                  res.push({
                    name: data[i].name,
                    value: geoCoord.concat(data[i].value),
                  })
                }
              }
              return res
            }
            let seriesdata = []
            for (let m = 0; m < mmdata.length; m++) {
              seriesdata[m] = {
                name: mmdata[m].city,
                mapType: 'china',
                type: 'scatter',
                symbolSize: function(val) {
                  return val[2] * 2
                },
                coordinateSystem: 'geo',
                label: {
                  normal: {
                    color: '#fff',
                    show: false,
                  },
                },
                itemStyle: {
                  normal: { label: { show: true } },
                  emphasis: { label: { show: true } },
                },
                data: convertData([
                  { name: mmdata[m].city, value: Object.values(mmdata[m].keywords)[0] },
                ]),
              }
            }
            let myPlaceChart = _this.$echarts.init(document.getElementById('placeChart'))
            myPlaceChart.setOption({
              tooltip: {
                formatter: function(params) {
                  return params.name + '(词频):' + params.value[2]
                },
                trigger: 'item',
              },
              legend: {
                left: 0,
                bottom: 20,
                top: 20,
                data: legenddata,
              },
              geo: [
                {
                  show: true,
                  map: 'china',
                  roam: true,
                },
              ],
              visualMap: {
                min: 0,
                max: 200,
                color: ['#d94e5d', '#eac736', '#50a3ba'],
                splitNumber: 5,
              },
              series: seriesdata,
            })
          }
        })
        .catch(function(error) {
          alert(error)
        })
    },
    // 词 点击事件
    getClick: function(paramsList) {
      let dataP = paramsList.data
      if (dataP != null && dataP != undefined) {
        let cid = dataP.category
        let pid = dataP.id
        let params = {}
        params.word = paramsList.data.label
        this.axios
          .post(currentBaseUrl + '/hotAnlys/getRelatedWords.do', qs.stringify(params))
          .then((res) => {
            if (res.data.length > 0) {
              if (dataP.ignore == true) {
                console.log('重复')
                return
              }
              // 得到links最后一个target
              let tcount = myChartCi.getOption().series[0].links.pop().target
              let ncount = myChartCi.getOption().series[0].nodes.pop().id
              // let ssize = paramsList.data.symbolSize
              let catCount = myChartCi.getOption().series[0].nodes.pop().id

              let nums
              if (res.data.length >= 15) {
                nums = 15
              } else {
                nums = res.data.length
              }
              // 重组数组
              let word = []
              if (cid === 0) {
                for (let i = 0; i < nums; i++) {
                  word[i] = {
                    id: i + 1,
                    category: cid + 1,
                    label: res.data[i].name,
                    name: i + 1,
                    symbolSize: res.data[i].score * 90,
                    ignore: false,
                    flag: true,
                  }
                }
              } else {
                let wAdd
                wAdd = ncount + 1
                for (let i = 0; i < nums; i++) {
                  word[i] = {
                    id: wAdd,
                    category: cid + 1,
                    label: res.data[i].name,
                    name: wAdd,
                    symbolSize: res.data[i].score * 90,
                    ignore: false,
                    flag: true,
                  }
                  wAdd = wAdd + 1
                }
              }
              // 设置点击过得词语不能再次查询
              let worddata = myChartCi.getOption().series[0].nodes.concat(word)
              worddata[pid].ignore = true
              // links
              let links = []
              // let sid = 0
              if (cid === 0) {
                // sid = 0
                for (let i = 0; i < nums; i++) {
                  links[i] = {
                    source: pid,
                    target: i + 1,
                  }
                }
              } else {
                // sid = sid + 1
                let lAdd
                lAdd = tcount + 1
                for (let i = 0; i < nums; i++) {
                  links[i] = {
                    source: pid,
                    target: lAdd,
                  }
                  lAdd = lAdd + 1
                }
              }
              let linksdata = myChartCi.getOption().series[0].links.concat(links)
              // categories
              let categories = []
              if (cid === 0) {
                for (let i = 0; i < nums; i++) {
                  categories[i] = {
                    id: i + 1,
                    name: i + 1 + '层',
                  }
                }
              } else {
                let cAdd
                cAdd = catCount + 1
                for (let i = 0; i < nums; i++) {
                  categories[i] = {
                    id: cAdd,
                    name: cAdd + '层',
                  }
                  cAdd = cAdd + 1
                }
              }
              let cdata = myChartCi.getOption().series[0].categories.concat(categories)
              myChartCi.setOption({
                series: [
                  {
                    links: linksdata,
                    nodes: worddata,
                    categories: cdata,
                  },
                ],
              })
            } else {
              console.log(null)
            }
          })
          .catch(function(error) {
            console.log(error)
          })
      }
    },
    // 处理节点点击
    handleNodeClick(data) {
      this.currentNode = data
    },
    // 增加水词
    removeKeyWord() {
      let _this = this
      if (this.selectKeyWord == '') {
        this.$message({
          type: 'error',
          message: '请选择水词',
        })
      } else {
        _this.addWalterWordModalVisible = true
        _this.getWordClass(2)
        _this.addWalterTitle = '添加水词 [' + this.selectKeyWord + ']'
      }
      this.currentNode = ''
      this.wordDescribe = ''
      this.roleType = _this.roleType
    },
    handleWalterAddKeyWordThrottle() {
      this.lodashThrottle.throttle(this.handleWalterAddKeyWord, this)
    },
    radioChange(val) {
      this.roleType = val
    },
    handleWalterAddKeyWord() {
      if (this.currentNode == '') {
        this.$message({
          type: 'error',
          message: '添加水词失败,分类不能为空',
        })
      } else {
        let _this = this
        let params = {
          wordlibType: 2,
          wordName: _this.selectKeyWord,
          keywordClass: 3,
          wordType: 1,
          wordDescribe: _this.wordDescribe,
          classId: _this.currentNode.classId,
          roleType: _this.roleType,
        }
        let url = currentBaseUrl + '/vocabulary/addManyKeyword.do?CASTGC=' + CASTGC
        _this.axios
          .post(url, qs.stringify(params))
          .then(function(response) {
            _this.$message({
              type: 'success',
              message: '添加水词成功',
            })
            _this.addWalterWordModalVisible = false
          })
          .catch(function() {
            _this.$message({
              type: 'error',
              message: '添加水词失败',
            })
          })
      }
    },
    // 增加关键词
    addKeyWord() {
      if (this.selectKeyWord == '') {
        this.$message({
          type: 'error',
          message: '请选择关键词',
        })
      } else {
        let _this = this
        _this.addWordModalVisible = true
        _this.getWordClass(1)
        _this.addTitle = '添加关键词 [' + this.selectKeyWord + ']'
      }
      this.currentNode = ''
      this.wordDescribe = ''
      this.roleType = ''
    },
    // 添加关键词
    handleAddKeyWordThrottle() {
      this.lodashThrottle.throttle(this.handleAddKeyWord, this)
    },
    handleAddKeyWord() {
      if (this.currentNode == '') {
        this.$message({
          type: 'error',
          message: '添加关键词失败,分类不能为空',
        })
      } else {
        let _this = this
        let params = {
          wordlibType: 1,
          wordName: _this.selectKeyWord,
          keywordClass: 3,
          wordType: 1,
          wordDescribe: _this.wordDescribe,
          classId: _this.currentNode.classId,
        }
        let url = currentBaseUrl + '/vocabulary/addManyKeyword.do?CASTGC=' + CASTGC
        _this.axios
          .post(url, qs.stringify(params))
          .then(function(response) {
            _this.$message({
              type: 'success',
              message: '添加关键词成功',
            })
            _this.addWordModalVisible = false
          })
          .catch(function() {
            _this.$message({
              type: 'error',
              message: '添加关键词失败',
            })
          })
      }
    },
    // 取消添加关键词
    cancelAdd() {
      this.addWordModalVisible = false
    },
    cancelWalterAdd() {
      this.addWalterWordModalVisible = false
    },
    // 获取关键词、水词分类
    getWordClass(val) {
      let _this = this
      let url = currentBaseUrl + '/vocabulary/getTrees.do?CASTGC=' + CASTGC
      let params = {
        classId: 0,
        classType: val,
      }
      _this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.treeData = response['data']
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取分类树失败',
          })
        })
    },
    // 查询
    search() {
      let _this = this
      let myChartCi = _this.$echarts.init(document.getElementById('ciChart'))
      myChartCi.dispose()
      let myPlaceChart = _this.$echarts.init(document.getElementById('placeChart'))
      myPlaceChart.dispose()
      _this.quShiTu(1)
      _this.keyword = ''
      // this.loading = true
      let params = {}
      if (_this.searchModel.times == undefined) {
        this.$message({
          message: '请选择日期范围',
          type: 'warning',
        })
        return
      } else {
        _this.callSTime_Min = this.gettimeform(this.searchModel.times[0])
        _this.callSTime_Max = this.gettimeform(this.searchModel.times[1])
      }
      this.dealDimentionData(params)
      params.beginDate = _this.callSTime_Min
      params.endDate = _this.callSTime_Max
      params.majorDim = this.searchModel.mainMd || '-1'
      params.viceDim = this.searchModel.viceMd || '-1'
      params.wordRole = this.searchModel.wordRole || '-1'
      params.buss_wordType = this.searchModel.buss_wordType
      params.keyWord = this.keyword

      let url = currentBaseUrl + '/hotAnlys/getAllkey.do?CASTGC=' + CASTGC
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (response.data) {
            _this.loading = false
          }
          _this.tableCiData = response.data.keyword
          _this.keyword = ''
        })
        .catch(function(error) {
          alert(error)
          _this.tableCiData = []
          _this.$message({
            type: 'error',
            message: '获取热点数据值失败',
          })
        })
      let myQushiChart = _this.$echarts.init(document.getElementById('trendChart'))
      let urlQs = currentBaseUrl + '/hotAnlys/getTrendData.do'
      this.axios
        .post(urlQs, qs.stringify(params))
        .then(function(response) {
          if (response.data.dateList.length > 0 && response.data.trendData.length > 0) {
            $('#trendChart').show()
            myQushiChart.resize()
            let dateList = response.data.dateList
            let trendData = response.data.trendData
            let dateData = []
            let trend = []
            let nums
            if (trendData.length <= 5) {
              nums = trendData.length
            } else {
              nums = 5
            }
            for (let i = 0; i < dateList.length; i++) {
              dateData[i] = dateList[i][0]
            }
            // series
            for (let j = 0; j < nums; j++) {
              trend[j] = {
                name: trendData[j].keyword,
                type: 'line',
                data: trendData[j].timesList,
              }
            }
            // legend data
            let legendData = []
            for (let p = 0; p < nums; p++) {
              legendData[p] = trendData[p].keyword
            }
            // xAxis
            let xAxisData = []
            for (let a = 0; a < dateList.length; a++) {
              xAxisData[a] = dateList[a]
            }
            let option = {
              title: {
                text: '',
                textStyle: {
                  color: '#5e6d82',
                  fontSize: 14,
                  fontWieght: 'normal',
                },
              },
              tooltip: {
                trigger: 'axis',
              },
              legend: {
                data: [],
              },

              grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true,
              },
              xAxis: [
                {
                  type: 'category',
                  boundaryGap: false,
                  data: [],
                  splitLine: {
                    show: true,
                  },
                  axisLine: {
                    show: false,
                  },
                },
              ],
              yAxis: [
                {
                  type: 'value',
                  splitLine: {
                    show: true,
                  },
                  axisLine: {
                    show: false,
                  },
                },
              ],
              color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
              series: [],
            }
            option.legend.data = legendData
            option.xAxis[0].data = xAxisData
            option.series = trend
            myQushiChart.setOption(option, true)
          } else {
            myQushiChart && myQushiChart.dispose()
            $('#trendChart').hide()
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    drawPic(data) {
      // let qushi = JSON.parse(data.keyWord || '[]')
      let qushi = data
      let _this = this
      let map = {}
      for (let j = 0; j < 5; j++) {
        let keyWord = qushi[j].keyWord
        let date = qushi[j].date
        let times = qushi[j].times
        if (map.hasOwnProperty(keyWord)) {
          map[keyWord][0].push(date)
          map[keyWord][1].push(times)
        } else {
          map[keyWord] = []
          map[keyWord][0] = []
          map[keyWord][1] = []
          map[keyWord][0].push(date)
          map[keyWord][1].push(times)
        }
      }
      let arr = []
      // let qushiList = response.data.qushi
      for (let i = 0; i < 5; i++) {
        arr[i] = formatDate.formatDate(qushi[i].date).substring(0, 10)
      }
      let legend = []
      let series = []
      // let xaxis = ''
      for (let x in map) {
        let d = {}
        d['name'] = x
        d['type'] = 'line'
        // d['stack'] = '总量';
        d['data'] = map[x][1]
        legend.push(x)
        series.push(d)
        // xaxis = map[x][0]
      }
      _this.option1.series = series
      _this.option1.legend.data = legend
      _this.option1.xAxis[0].data = arr
      // _this.option1.xAxis[0].data = xaxis
      let myChart = _this.$echarts.init(document.getElementById('trendImage'))
      myChart.destroy()
      myChart.setOption(_this.option1)
      /* let keywordData = data.keyword || []
         let datas = []
         for (let i = 0; i < keywordData.length; i++) {
         datas.push({
         name: keywordData[i].keyWord,
         value: keywordData[i].times * 10,
         itemStyle: _this.createRandomItemStyle()
         // 变换风格
         })
         }
         _this.option2.series[0].data = datas */
      /* let myChart2 = this.$echarts.init(document.getElementById('wordImage'));
         myChart2.clear(); */
      // myChart2.setOption(_this.option2);
    },
    createRandomItemStyle() {
      return {
        normal: {
          textStyle: {
            fontSize: 12,
          },
        },
      }
    },
    handleAllClick(selection) {
      let keyWord = ''
      for (let val of selection) {
        if (val == selection[0]) {
          keyWord = val.keyWord
        } else {
          keyWord = keyWord + ',' + val.keyWord
        }
      }
      this.selectKeyWord = keyWord
    },
    // 主维度、副维度、主维度的二级维度和副维度的二级维度数据需要特殊处理，该方法将处理结果加到params上
    dealDimentionData(params) {
      let _this = this
      if (!this.searchModel.mainMdVal && params.mainMd != '-1') {
        let mainMdVal = []
        let mainMdText = []
        this.mainMdVals.forEach(function(item) {
          mainMdVal.push(item[_this.mainSubDimentionValue])
          mainMdText.push(item[_this.mainSubDimentionLabel])
        })
        params.majorDim_value = mainMdVal.join(',')
        params.mainMdText = mainMdText.join(',')
      } else if (params.mainMd == '-1') {
        params.majorDim_value = ''
        params.mainMdText = ''
      } else {
        params.majorDim_value = _this.searchModel.mainMdVal
        let text = _this.mainMdVals.filter(function(item) {
          return item[_this.mainSubDimentionValue] == _this.searchModel.mainMdVal
        })
        params.majorDim_value = _this.searchModel.mainMdVal
        params.mainMdText = text[0][_this.mainSubDimentionLabel]
      }
      if (!_this.searchModel.viceMdVal && params.viceMd != '-1') {
        let viceMdVal = []
        let viceMdText = []
        _this.viceMdVals.forEach(function(item) {
          viceMdVal.push(item[_this.viceSubDimentionValue])
          viceMdText.push(item[_this.viceSubDimentionLabel])
        })
        params.viceMdVal = viceMdVal.join(',')
        params.viceMdText = viceMdText.join(',')
      } else if (params.viceMd == '-1') {
        params.viceMdVal = ''
        params.viceMdText = ''
      } else {
        params.viceMdVal = _this.searchModel.viceMdVal.key
        let text = _this.viceMdVals.filter(function(item) {
          return item[_this.viceSubDimentionValue] == _this.searchModel.viceMdVal
        })
        params.viceMdVal = _this.searchModel.viceMdVal
        params.viceMdText = text[0][_this.viceSubDimentionLabel]
      }
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let str = year + '-' + month + '-' + day
      return str
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
      this.searchModel.times = ''
    },
    // 获取主维度和副维度下拉框的值
    getDimentions() {
      let _this = this
      let params = {
        dataCode: 'hotAnalyse',
      }
      let url = currentBaseUrl + '/pageConstant/getStandByCode.do'
      _this.axios
        .get(url, { params })
        .then(function(response) {
          _this.dimentions = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '下拉列表获取失败',
          })
        })
    },
    // 监测一级维度变化，获取二级维度
    changeDimention(dimention) {
      let subDimentionObj = {}
      if (dimention === 'mainMd') {
        this.searchModel.mainMdVal = ''
        this.getStandByCode(dimention)
        subDimentionObj.value = 'mainSubDimentionValue'
        subDimentionObj.label = 'mainSubDimentionLabel'
      } else {
        this.searchModel.viceMdVal = ''
        subDimentionObj.value = 'viceSubDimentionValue'
        subDimentionObj.label = 'viceSubDimentionLabel'
      }
      console.log(this.searchModel[dimention])
      if (this.searchModel[dimention] == 'seatGroup') {
        this.listSeat(dimention, subDimentionObj)
      } else if (this.searchModel[dimention] == 'province') {
        this.listprovince(dimention, subDimentionObj)
      }
    },
    // 获取查询过程中所需要的groupBy字段,查询主维度副维度数据时需要
    getStandByCode(dimention) {
      let _this = this
      let params = {
        dataCode: 'cross_' + this.searchModel[dimention],
      }
      let url = currentBaseUrl + '/pageConstant/getStandByCode.do'
      _this.axios
        .get(url, { params })
        .then(function(response) {
          response.data.forEach(function(item) {
            if (item.key == 'groupBy') {
              _this.groupBy = item.value
            }
          })
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: 'groupBy字段获取失败',
          })
        })
    },
    // 获取坐席组数据
    listSeat(dimention, subDimentionObj) {
      let _this = this
      let params = {
        dpcpId: '',
        showAccount: '0',
      }
      let url = currentBaseUrl + '/pageConstant/listSeat.do'
      _this.axios
        .get(url, { params })
        .then(function(response) {
          _this[dimention + 'Vals'] = response.data
          _this[subDimentionObj.label] = 'name'
          _this[subDimentionObj.value] = 'id'
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '坐席组数据获取失败',
          })
        })
    },
    // 获取区域数据
    listprovince(dimention, subDimentionObj) {
      let _this = this
      let url = currentBaseUrl + '/mobiletoarea/listprovince.do'
      _this.axios
        .get(url)
        .then(function(response) {
          _this[dimention + 'Vals'] = response.data
          _this[subDimentionObj.label] = 'province'
          _this[subDimentionObj.value] = 'province'
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '区域数据获取失败',
          })
        })
    },
    // 初始化时候的趋势图/词相关、区域图
    getQuShiCharts() {
      let myDate = new Date()
      console.log(this.gettimeform(myDate.getTime()))
      let mm = this.gettimeform(myDate.getTime())
      let _this = this
      let params = {}
      params.beginDate = mm
      params.endDate = mm
      params.majorDim = _this.searchModel.mainMd || '-1'
      params.viceDim = _this.searchModel.viceMd || '-1'
      params.wordRole = _this.searchModel.wordRole || '-1'
      params.buss_wordType = _this.searchModel.buss_wordType
      params.keyWord = _this.keyword
      let urlQs = currentBaseUrl + '/hotAnlys/getTrendData.do'
      _this.axios
        .post(urlQs, qs.stringify(params))
        .then(function(response) {
          if (response.data.dateList.length > 0 && response.data.trendData.length > 0) {
            let dateList = response.data.dateList
            let trendData = response.data.trendData
            let dateData = []
            let trend = []
            let nums
            if (trendData.length <= 5) {
              nums = trendData.length
            } else {
              nums = 5
            }
            for (let i = 0; i < dateList.length; i++) {
              dateData[i] = dateList[i][0]
            }
            // series
            for (let j = 0; j < nums; j++) {
              trend[j] = {
                name: trendData[j].keyword,
                type: 'line',
                data: trendData[j].timesList,
              }
            }
            // legend data
            let legendData = []
            for (let p = 0; p < nums; p++) {
              legendData[p] = trendData[p].keyword
            }
            // xAxis
            let xAxisData = []
            for (let a = 0; a < dateList.length; a++) {
              xAxisData[a] = dateList[a]
            }
            _this.qushiEchartsOption.legend.data = legendData
            _this.qushiEchartsOption.xAxis[0].data = xAxisData
            _this.qushiEchartsOption.series = trend
            let myQushiChart = _this.$echarts.init(document.getElementById('trendChart'))
            myQushiChart.setOption(_this.qushiEchartsOption, true)
            _this.getci(trendData[0].keyword)
            let times = dateList[0]
            _this.getMap(trendData[0].keyword, times)
            let paramsd = {}
            _this.dealDimentionData(paramsd)
            paramsd.beginDate = times
            paramsd.endDate = times
            paramsd.majorDim = _this.searchModel.mainMd || '-1'
            paramsd.viceDim = _this.searchModel.viceMd || '-1'
            paramsd.wordRole = _this.searchModel.wordRole || '-1'
            paramsd.buss_wordType = _this.searchModel.buss_wordType
            paramsd.keyWord = _this.keyword

            let urld = currentBaseUrl + '/hotAnlys/getAllkey.do?CASTGC=' + CASTGC
            _this.axios
              .post(urld, qs.stringify(paramsd))
              .then(function(response) {
                if (response.data) {
                  _this.loading = false
                }
                _this.searchModel.times = [times, times]
                _this.tableCiData = response.data.keyword
                _this.keyword = ''
              })
              .catch(function(error) {
                alert(error)
                _this.tableCiData = []
                _this.$message({
                  type: 'error',
                  message: '获取热点数据值失败',
                })
              })
          } else {
            console.log('没有数据')
          }
        })
        .catch(function(error) {
          console.log(error)
        })
    },
  },
  created() {
    this.getQuShiCharts()
    this.getDimentions()
  },
}
</script>
<style lang="less">
#hotanalyse .el-tabs__header {
  border-bottom: 1px solid #d1dbe5;
  padding: 0;
  position: inherit;
  margin: 0px;
}

#hotanalyse .el-tabs__content {
  box-sizing: border-box;
  position: relative;
  width: 100%;
  height: 100%;
}

#hotanalyse {
  div.el-radio-group {
    float: left;
    margin: 5px 0px;
    width: 100%;
  }
}

#hotanalyse {
  width: 100%;
  height: 100%;
  position: relative;
}

#hotanalyse .hotanalyse-header {
  position: absolute;
  width: 100%;
  height: 100px;
  padding: 0 10px;
  box-sizing: border-box;
  margin-bottom: 10px;
}

#hotanalyse .hotanalyse-header .hotanalyse-header-pos {
  border-bottom: 1px dashed #d4dde6;
}

#hotanalyse .hotanalyse-content {
  width: 100%;
  height: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  padding-top: 120px;
  padding-bottom: 25px;
}

#hotanalyse .hotanalyse-content .hotanalyse-content-pos {
  height: 100%;
  width: 100%;
  border: 1px solid #dfe6ec;
  border-radius: 8px;
}

#hotanalyse .hotanalyse-content-pos .hotanalyse-content-left {
  width: 30%;
  height: 100%;
  border-right: 1px solid #dfe6ec;
  padding: 0 10px;
  box-sizing: border-box;
}

#hotanalyse .hotanalyse-content-left .hotanalyseLeft-header {
  width: 100%;
}

#hotanalyse .hotanalyse-content-left .hotanalyseLeft-content {
  width: 100%;
  height: 100%;
  padding-top: 55px;
  padding-bottom: 5px;
  box-sizing: border-box;
}

#hotanalyse .hotanalyseLeft-content .hotanalyseLeft-content-pos {
  width: 100%;
  height: 100%;
}

#hotanalyse .hotanalyse-content-pos .hotanalyse-content-right {
  width: 69%;
  height: 100%;
}

#hotanalyse .hotanalyse-content-right .box {
  height: 100%;
  position: relative;
  box-sizing: border-box;
  width: 100%;
}

#hotanalyse .hotTop {
  border-radius: 4px;
  border: 1px solid #dfe6ec;
  line-height: 40px;
  float: left;
  box-sizing: border-box;
  top: 0px;
  width: 212px;
  margin: 10px 0px 0px 10px;
  height: 40px;
}

#hotanalyse .hotTop .activeQu {
  background: #409eff;
  border-radius: 4px;
  color: #fff;
}

#hotanalyse .hotTop ul li {
  cursor: pointer;
  text-align: center;
  width: 70px;
  float: left;
}

#hotanalyse .hotanalyse-content-right .box .hotanalyseRight {
  /*box-sizing: border-box;
    width: 100%;
    height: 100%;
    position: relative;*/
  padding-top: 50px;
  padding-bottom: 1px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}

#hotanalyse .hotBox {
  width: 100%;
  height: 100%;
  overflow: auto;
  cursor: pointer;
}

#hotanalyse
  .hotanalyse-content-pos
  .hotanalyse-content-right
  .hotanalyse-content-chart-head {
  /*margin-top: 10px;
    margin-left: 10px;*/
  position: absolute;
  top: 10px;
  left: 10px;
}

#hotanalyse
  .hotanalyse-content-pos
  .hotanalyse-content-right
  .hotanalyse-content-chart-head
  .active {
  background: #409eff;
  color: #fff;
  /*border-radius: 4px 0px 0px 4px;*/
}

#hotanalyse .hotanalyse-content-chart-head ul {
  border-radius: 4px;
  border: 1px solid #d8dce5;
  height: 36px;
  line-height: 36px;
  width: 240px;
  cursor: pointer;
}

#hotanalyse .hotanalyse-content-chart-head ul li {
  text-align: center;
  width: 80px;
  float: left;
  display: inline-block;
  font-size: 14px;
  color: #1f334f;
}

#hotanalyse .hotanalyse-content-chart-head ul li:hover {
  background: #409eff;
  color: #fff;
}

.is-current > .el-tree-node__content {
  background: #eef1f6;
}

#hotanalyse .hotanalyseRight span,
#hotanalyse .hotanalyseRightbottom span {
  display: inline-block;
  width: 100%;
  height: 55px;
  line-height: 55px;
  padding-left: 18px;
  box-sizing: border-box;
  font-size: 14px;
}
</style>
