<template>
  <div id="soundfeature">
    <div class="conpalinDiv edealFind">
      <div class="caseHeader">
        申诉管理
      </div>
      <div class="complianContent">
        <ul>
          <li
            data-id="1"
            @click="toggleSound"
            class="soundfeatureActive"
            style="margin-left:5px;"
          >
            未处理
          </li>
          <li data-id="2" @click="toggleSoundtwo">已处理</li>
        </ul>
      </div>
      <div class="changeCondtion">
        <el-form :inline="true">
          <el-form-item style="float: right;margin-right: 0px;">
            <el-date-picker
              v-model="searchForm.callSTime"
              type="datetimerange"
              :clearable="false"
              :editable="false"
              align="right"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :default-time="['00:00:00', '23:59:59']"
              style="width: 375px;padding: 1px 10px;"
            >
            </el-date-picker>
            <el-button
              @click="scoreInquery"
              v-show="untrendSize"
              type="primary"
              style="margin-left: 7px;margin-right: 20px;"
              >查询</el-button
            >
            <el-button
              @click="secherInquery"
              v-show="!untrendSize"
              type="primary"
              style="margin-left: 7px;margin-right: 20px;"
              >查询</el-button
            >
          </el-form-item>
        </el-form>
      </div>
      <div class="content" v-show="untrendSize">
        <div class="table">
          <div style="padding: 0 16px 80px 19px;">
            <el-table
              :data="tableData"
              border
              ref="multipleTable"
              tootip-effect="dark"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="callId" label="录音编号">
                <template scope="scope">
                  <el-button
                    type="text"
                    @click="
                      jumpToSound(
                        1,
                        scope.row.callId,
                        scope.row.apStatus,
                        scope.row.appealId,
                        scope.row.qaScoreType,
                        scope.row.recordFileURL
                      )
                    "
                    >{{ scope.row.callId }}</el-button
                  >
                </template>
              </el-table-column>
              <el-table-column prop="seatName" label="申诉坐席" width="150">
              </el-table-column>
              <el-table-column prop="seatGroup" label="坐席组"> </el-table-column>
              <el-table-column
                prop="apTime"
                sortable
                :formatter="exeTimeFilter"
                label="提交时间"
              >
              </el-table-column>
              <el-table-column prop="score" sortable label="质检成绩"> </el-table-column>
              <el-table-column prop="comments" label="申诉原因"> </el-table-column>
              <el-table-column prop="state" label="申诉状态" width="180">
                <template scope="scope">
                  <div v-if="scope.row.state === 1">
                    坐席发起一次申诉
                  </div>
                  <div v-else-if="scope.row.state === 2">
                    组长审批通过
                  </div>
                  <div v-else-if="scope.row.state === 3">
                    主管第一次审批通过
                  </div>
                  <div v-else-if="scope.row.state === 4">
                    主管第二次审批通过
                  </div>
                  <div v-else-if="scope.row.state === 5">
                    组长审批驳回
                  </div>
                  <div v-else-if="scope.row.state === 6">
                    坐席发起二次申诉
                  </div>
                  <div v-else-if="scope.row.state === 7">
                    主管一次审批驳回
                  </div>
                  <div v-else-if="scope.row.state === 8">
                    主管二次审批驳回
                  </div>
                  <div v-else-if="scope.row.state === 10">
                    坐席终止申诉
                  </div>
                  <div v-else-if="scope.row.state === 11">
                    坐席终止申诉
                  </div>
                  <div v-else-if="scope.row.state === 13">
                    本人已确认
                  </div>
                  <div v-else-if="scope.row.state === 14">
                    系统自动确认
                  </div>
                  <div v-else-if="scope.row.state == null">
                    未确认
                  </div>
                  <div v-else>坐席终止申诉</div>
                </template>
              </el-table-column>
              <el-table-column label="操作">
                <template scope="scope">
                  <div class="operation">
                    <i class="opeatLeft"
                      ><i
                        funcId="000350"
                        style="color: #20A0FF;cursor: pointer;"
                        @click="approveClik(scope.row.appealId, scope.row.procTaskId)"
                        >审批</i
                      ></i
                    >
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="autoGrading-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
      <el-dialog
        class="giveManger"
        :visible.sync="setInput"
        width="420px"
        title="审批"
        :close-on-click-modal="false"
      >
        <div class="dealCenter">
          <el-form label-width="84px" ref="fourForm">
            <el-form-item label="" style="margin-top: 20px;">
              <template>
                <el-radio-group v-model="radioValue">
                  <el-radio :label="1">通过</el-radio>
                  <el-radio :label="2">驳回</el-radio>
                </el-radio-group>
              </template>
            </el-form-item>
            <el-form-item label="审批理由" style="margin-top: 20px;">
              <el-input
                v-model="searchForm.byReson"
                type="textarea"
                placeholder="请输入内容"
                maxlength="200"
              ></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div
          class="footerAll"
          style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
        >
          <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
            <el-button @click="notChange">取 消</el-button>
            <el-button :disabled="submitDisable" @click="complainNext" type="primary" style="margin-right: 18px;"
              >提 交</el-button
            >
          </div>
        </div>
      </el-dialog>
      <div class="content" v-show="!untrendSize">
        <div class="table">
          <div style="padding: 0 16px 80px 19px;">
            <el-table
              :data="tableSearch"
              border
              ref="multipleTable"
              tootip-effect="dark"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="callId" label="录音编号">
                <template scope="scope">
                  <el-button
                    type="text"
                    @click="
                      jumpToSound(
                        1,
                        scope.row.callId,
                        scope.row.apStatus,
                        scope.row.appealId,
                        scope.row.qaScoreType,
                        scope.row.recordFileURL
                      )
                    "
                    >{{ scope.row.callId }}</el-button
                  >
                </template>
              </el-table-column>
              <el-table-column prop="seatName" label="申诉坐席" width="150">
              </el-table-column>
              <el-table-column
                prop="apTime"
                sortable
                :formatter="exeTimeFilter"
                label="提交时间"
              >
              </el-table-column>
              <el-table-column prop="secondQaScore" sortable label="质检成绩">
              </el-table-column>
              <el-table-column prop="comments" label="申诉原因"> </el-table-column>
              <el-table-column prop="passFlag" label="审批结果">
                <template scope="scope">
                  <i v-if="scope.row.passFlag == 1">通过</i>
                  <i v-if="scope.row.passFlag == 0">驳回</i>
                </template>
              </el-table-column>
              <el-table-column prop="apNote" label="审批理由"> </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="autoGrading-page">
          <el-pagination
            @size-change="handleSizeChangeone"
            @current-change="handleCurrentChangeone"
            :current-page="currentPageone"
            :page-sizes="pageSizesone"
            :page-size="pageSizeone"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalone"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import global from '@/global'
import $ from 'jquery'
import formatdate from '../../../utils/formatdate.js'
import Qs from 'qs'
import moment from 'moment'
import recordingplay from '../recordingPlay/recordingPlayShenSu.vue'
import bus from '../../common/bus.js'
import funcFilter from '@/utils/funcFilter.js'

let qualityUrl = global.qualityUrl
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      submitDisable: false,
      searchForm: {
        callSTime: [],
        byReson: '',
      },
      tableData: [],
      tableSearch: [],
      setInput: false,
      untrendSize: true,
      setIds: '',
      notIds: '',
      currentPage: 1,
      currentPageone: 1,
      radioValue: 1,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
      pageSizesone: [10, 20, 30, 40],
      pageSizeone: 20,
      totalone: 0,
      recordDialogVisible: false,
      tabIndex: 0,
    }
  },
  methods: {
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    toggleSound(event) {
      // 首页头部切换
      $('.complianContent ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
      this.untrendSize = true
      this.scoreInquery()
      let obj = {}
      obj.shensuTabIndex = 2
      this.$store.commit('setRecordingPlayPage', obj)
    },
    toggleSoundtwo(event) {
      // 首页头部切换
      this.untrendSize = false
      $('.complianContent ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
      this.secherInquery()
      let obj = {}
      obj.shensuTabIndex = 1
      this.$store.commit('setRecordingPlayPage', obj)
    },
    notChange: function() {
      this.setInput = false
    },
    complainNext: function() {
      this.submitDisable = true
      let params = {
        wfTaskUserOpt: this.radioValue,
        comments: this.searchForm.byReson,
        procTaskId: this.notIds,
        appealId: this.setIds,
      }
      this.axios
        .post(qualityUrl + '/appealsProcess/groupApprove.do', Qs.stringify(params))
        .then((resp) => {
          console.log(resp.data)
          if (resp.data) {
            this.scoreInquery()
            this.setInput = false
            this.$message({
              type: 'success',
              message: '审批成功',
            })
          } else {
            this.$message({
              type: 'error',
              message: '审批失败',
            })
            this.submitDisable = false
          }
        })
        .catch(() => {
          this.$message({
            type: 'error',
            message: '审批失败',
          })
          this.submitDisable = false
        })
    },
    scoreInquery() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        apTime_Min: fromTime,
        apTime_Max: toTime,
      }
      this.axios
        .post(qualityUrl + '/appealsProcess/zzGetUnApproveList.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            this.tableData = resp.data.Data.map((item) => {
              item.score = parseInt(Number(item.score))
              return item
            })
            this.filterButton() // 过滤权限按钮
          } else {
            this.tableData = []
          }
          this.total = resp.data.Count
        })
    },
    secherInquery() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        apTime_Min: fromTime,
        apTime_Max: toTime,
      }
      this.axios
        .post(qualityUrl + '/appealsProcess/zzGetApprovedList.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            this.tableSearch = resp.data.Data.map((item) => {
              item.score = parseInt(Number(item.score))
              return item
            })
          } else {
            this.tableSearch = []
          }
          this.totalone = resp.data.Count
        })
    },
    handleSelectionChange(val) {
      console.log(val)
      this.selectedArr = val
    },
    // 跳转到录音播放页面
    jumpToSound: function(type, callId, apStatus, appealId, qaScoreType, recordFileURL) {
      let obj = {}
      obj.from = 'scoreResultInfo'
      obj.scoreResultRole = 'scoreResultZuZhang'
      obj.appealStatus = apStatus
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.appealId = appealId
      obj.qaScoreType = qaScoreType
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlay')
      // 初始化play
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay', // 扩展样式
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 将录音时长转换为秒
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    approveClik: function(index, flag) {
      this.setIds = index
      this.notIds = flag
      this.setInput = true
      this.submitDisable = false
      this.searchForm.byReson = ''
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.scoreInquery()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.scoreInquery()
    },
    handleSizeChangeone(val) {
      this.pageSize = val
      this.secherInquery()
    },
    handleCurrentChangeone(val) {
      this.currentPage = val
      this.secherInquery()
    },
   /*
    * 过滤权限按钮
    * */
    filterButton() {
        /*
       获取数据后dom节点更改了，
        需要再获取一遍dom节点对[funcID]按钮进行过滤
       * */
        let menuId = localStorage.getItem('menuId')
        let path = this.$route.path.replace('/', '')
        funcFilter(menuId, path)
    }
  },
  mounted: function() {
    let obj = {}
    obj.shensuTabIndex = 2
    this.$store.commit('setRecordingPlayPage', obj)
  },
  computed: {},
  created() {
    this.scoreInquery()
  },
}
</script>
<style lang="less" scoped="scoped">
#soundfeature {
  box-sizing: border-box;
  height: 95%;
  width: 100%;
  overflow: hidden;
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .conpalinDiv {
    width: 100%;
    height: 100%;
    .caseHeader {
      padding: 18px 16px;
      font-size: 14px;
    }
    .complianContent {
      width: 100%;
      height: 48px;
      line-height: 48px;
      background: #eef1f6;
      border-bottom: 1px solid #d1dbe4;
      border-top: 1px solid #d1dbe4;
      background: #ffffff;
      ul {
        width: 100%;
        li {
          float: left;
          padding: 0 16px;
          box-sizing: border-box;
          font-size: 14px;
          color: #96a2b2;
          cursor: pointer;
        }
      }
    }
    .soundfeatureActive {
      color: #21a2ff !important;
      border-bottom: 2px solid #21a2ff;
    }
    .changeCondtion {
      width: 100%;
      height: 44px;
      margin-top: 10px;
    }
    .content {
      padding-bottom: 140px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .table {
      width: 100%;
      height: 100%;
      overflow: auto;
    }
    .autoGrading-page {
      height: 35px;
      position: absolute;
      background: white;
      right: 0px;
      bottom: 0px;
      text-align: right;
      .el-pagination {
        display: inline-block;
        height: 28px;
        line-height: 28px;
        padding: 0px 10px;
      }
    }
  }
}
</style>
<style lang="less">
.content .table th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}
.giveManger {
  .el-textarea__inner {
    width: 80%;
    height: 200px;
  }
}
.edealFind {
  .el-dialog__body {
    padding: 0;
  }
  .el-dialog__header {
    padding: 25px 0px 10px 0px;
    border-bottom: 1px solid #e0e6ed;
    .el-dialog__title {
      padding-left: 20px;
    }
  }
}
.single {
  &.el-dialog__wrapper {
    position: fixed;
    top: 106px;
    left: 20px;
    right: 20px;
    bottom: 12px;
    .el-dialog {
      width: 100%;
      height: 100%;
      margin: 0 !important;
    }
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .el-dialog--large {
    width: 90%;
    height: 84%;
    top: 5% !important;
  }
}
</style>
