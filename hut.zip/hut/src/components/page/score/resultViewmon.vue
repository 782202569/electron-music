<template>
  <div id="soundfeature">
    <div class="soundfeature-pos edealFind">
      <!-- 头部导航 -->
      <div class="soundfeature-pos-nav">
        <ul>
          <li
            data-id="1"
            @click="toggleSound"
            class="soundfeatureActive"
            style="margin-left:34px;"
          >
            未确认
          </li>
          <li data-id="2" @click="toggleSoundtwo">申诉中</li>
          <li data-id="3" @click="toggleSoundthree">已确认</li>
          <li class="all-search">
            <el-form :inline="true">
              <el-form-item style="float: right;margin-right: 0px;">
                <el-date-picker
                  v-model="searchForm.callSTime"
                  type="datetimerange"
                  :clearable="false"
                  align="right"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  :default-time="['00:00:00', '23:59:59']"
                  style="width: 375px;padding: 1px 10px;"
                >
                </el-date-picker>
              </el-form-item>
            </el-form>
          </li>
        </ul>
      </div>
      <!-- 未确认页面 -->
      <div class="soundfeature-pos-content" v-show="index == 1">
        <div class="soundfeature-search">
          <el-form :inline="true" ref="searchForms1" :model="searchForms1">
            <el-form-item label="质检结果" prop="score">
              <el-col :span="10">
                <el-input
                  placeholder="请输入最小值"
                  style="width:120px"
                  v-model.number="searchForms1.score_Min"
                  oninput="value=value.replace(/[^-\d]/g,'')"
                  maxLength="3"
                ></el-input>
              </el-col>
              <el-col class="line" :span="4">~</el-col>
              <el-col :span="10">
                <el-input
                  placeholder="请输入最大值"
                  style="width:120px;margin-right:25px"
                  v-model.number="searchForms1.score_Max"
                  oninput="value=value.replace(/[^-\d]/g,'')"
                  maxLength="3"
                ></el-input>
              </el-col>
            </el-form-item>
            <el-form-item label="是否致命" prop="deadItem">
              <el-select
                v-model="searchForms1.deadItem"
                placeholder="请选择"
                style="width:100px"
              >
                <el-option label="是" value="1"></el-option>
                <el-option label="否" value="2"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="searchFormNoconfirm">查询</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="content contentButt">
          <div class="table">
            <div>
              <el-table
                :data="tableData"
                border
                ref="multipleTable"
                tootip-effect="dark"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"></el-table-column>
                <el-table-column prop="callId" label="录音编号">
                  <template scope="scope">
                    <el-button
                      type="text"
                      @click="
                        jumpToSound(
                          1,
                          scope.row.callId,
                          scope.row.status,
                          scope.row.appealId,
                          null,
                          scope.row.taskStatus,
                          scope.row.secAppFlag,
                          scope.row.qaScoreType,
                          scope.row.recordFileURL
                        )
                      "
                      >{{ scope.row.callId }}</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="callSTime"
                  sortable
                  :formatter="dateFormat"
                  label="录音时间"
                  width="180px"
                >
                </el-table-column>
                <el-table-column
                  prop="callTime"
                  :formatter="dateFormatTwo"
                  label="录音时长"
                >
                </el-table-column>
                <el-table-column prop="score" sortable label="质检结果">
                  <template scope="scope">
                    <span>{{ scope.row.score }}&nbsp;&nbsp;</span>
                    <el-popover
                      trigger="hover"
                      placement="right"
                      v-if="scope.row.isOverDue == '1'"
                    >
                      <template slot="reference">
                        <i class="el-icon-question"></i>
                      </template>
                      <p>{{ scope.row.disableMsg }}</p>
                    </el-popover>
                  </template>
                </el-table-column>
                <el-table-column prop="deadItem" sortable label="是否致命">
                  <template scope="scope">
                    <i v-if="scope.row.deadItem == 1">是</i>
                    <i v-else="">否</i>
                  </template>
                </el-table-column>
                <el-table-column prop="state" label="成绩状态" width="200px">
                  <template scope="scope">
                    <div v-if="scope.row.state === 1">
                      申诉进行中
                    </div>
                    <div v-else-if="scope.row.state === 2">
                      已确认
                    </div>
                    <div v-else-if="scope.row.state === 3">
                      待确认
                    </div>
                  </template>
                </el-table-column>
                <el-table-column label="操作" prop="isOverDue">
                  <template scope="scope">
                    <div class="operation" v-if="scope.row.isOverDue == '0'">
                      <i class="opeatLeft"
                        ><i
                          funcId="000388"
                          @click="sumitBet(scope.row.callId)"
                          style="color: #20A0FF;cursor: pointer;"
                          >申诉</i
                        ></i
                      >
                    </div>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="autoGrading-page">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="pageSizes"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <!-- 申诉中页面 -->
      <div class="soundfeature-pos-content" v-show="index == 2">
        <div class="soundfeature-search">
          <el-form :inline="true" ref="searchForms2" :model="searchForms2">
            <el-form-item label="质检结果" prop="score">
              <el-col :span="10">
                <el-input
                  placeholder="请输入最小值"
                  style="width:120px"
                  v-model.number="searchForms2.score_Min"
                  oninput="value=value.replace(/[^-\d]/g,'')"
                  maxLength="3"
                >
                </el-input>
              </el-col>
              <el-col class="line" :span="4">~</el-col>
              <el-col :span="10">
                <el-input
                  placeholder="请输入最大值"
                  style="width:120px;margin-right:25px"
                  v-model.number="searchForms2.score_Max"
                  oninput="value=value.replace(/[^-\d]/g,'')"
                  maxLength="3"
                ></el-input>
              </el-col>
            </el-form-item>
            <el-form-item label="是否致命" prop="deadItem">
              <el-select
                v-model="searchForms2.deadItem"
                placeholder="请选择"
                style="width:100px"
              >
                <el-option label="是" value="1"></el-option>
                <el-option label="否" value="2"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="成绩状态" prop="scorestatus">
              <el-select v-model="searchForms2.scoreStatus" placeholder="请选择">
                <el-option label="一次申诉中" value="1"></el-option>
                <el-option label="一次申诉成绩已发布" value="3"></el-option>
                <el-option label="一次申诉成绩已驳回" value="5"></el-option>
                <el-option label="二次申诉中" value="6"></el-option>
                <el-option label="二次申诉成绩已发布" value="4"></el-option>
                <el-option label="二次申诉成绩已驳回" value="8"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="searchFormAppeal">查询</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="content contentButt">
          <div class="table">
            <div>
              <el-table
                :data="twoData"
                border
                ref="multipleTable"
                tootip-effect="dark"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"></el-table-column>
                <el-table-column prop="callId" label="录音编号">
                  <template scope="scope">
                    <el-button
                      type="text"
                      @click="
                        jumpToSound(
                          1,
                          scope.row.callId,
                          scope.row.status,
                          scope.row.appealId,
                          scope.row.scoreId,
                          scope.row.taskStatus,
                          scope.row.secAppFlag,
                          scope.row.qaScoreType,
                          scope.row.recordFileURL
                        )
                      "
                      >{{ scope.row.callId }}</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="callSTime"
                  sortable
                  :formatter="dateFormat"
                  label="录音时间"
                  width="180px"
                >
                </el-table-column>
                <el-table-column
                  prop="callTime"
                  :formatter="dateFormatTwo"
                  label="录音时长"
                >
                </el-table-column>
                <el-table-column prop="score" sortable label="质检结果">
                </el-table-column>
                <el-table-column prop="deadItem" sortable label="是否致命">
                  <template scope="scope">
                    <i v-if="scope.row.deadItem == 1">是</i>
                    <i v-else="">否</i>
                  </template>
                </el-table-column>
                <el-table-column prop="status" label="成绩状态" width="200">
                  <template scope="scope">
                    <span v-if="scope.row.status === 1 || scope.row.status === 2">
                      一次申诉中
                    </span>
                    <span v-else-if="scope.row.status === 3">
                      一次申诉成绩已公布
                    </span>
                    <span v-else-if="scope.row.status === 4">
                      二次申诉成绩已公布
                    </span>
                    <span v-else-if="scope.row.status === 5 || scope.row.status === 7">
                      一次申诉成绩已驳回
                    </span>
                    <span v-else-if="scope.row.status === 6">
                      二次申诉中
                    </span>
                    <span v-else-if="scope.row.status === 8">
                      二次申诉成绩已驳回
                    </span>
                    <span v-else>未确认</span>
                    <el-popover placement="left" trigger="hover">
                      <slot name="reference">
                        <div class="showMcen" id="notTable">
                          <div class="detailsNew">
                            <div
                              v-for="(item, index) in scope.row.AppDetail"
                              :key="index"
                              style="width: 100%;"
                              v-if="index < scope.row.AppDetail.length - 1"
                            >
                              <div>
                                <div
                                  style="height:10px;width:10px;float:left;background: #BFCBD9;display: inline-block;border-radius: 50%"
                                ></div>
                                <div
                                  style="padding-left: 30px;margin-left: 5px;border-left: 1px solid #BFCBD9;"
                                >
                                  {{ item.actDesc }}
                                </div>
                              </div>
                              <div
                                style="margin-left: 5px;border-left: 1px solid #BFCBD9;"
                              >
                                <div style="padding-left: 30px;">
                                  理由：{{ item.actReson }}
                                </div>
                              </div>
                              <div
                                class=""
                                style="margin-left: 5px;border-left: 1px solid #BFCBD9;"
                              >
                                <div style="padding-left: 30px;padding-bottom: 30px;">
                                  {{ formatDate(item.actTime) }}
                                </div>
                              </div>
                            </div>
                            <div
                              v-for="(item, index) in scope.row.AppDetail"
                              :key="index"
                              style="width: 100%;"
                              v-if="index == scope.row.AppDetail.length - 1"
                            >
                              <div>
                                <div
                                  style="height:10px;width:10px;float:left;background: #20A0FF;display: inline-block;border-radius: 50%"
                                ></div>
                                <div style="padding-left: 30px;margin-left: 5px;">
                                  {{ item.actDesc }}
                                </div>
                              </div>
                              <div style="margin-left: 5px;">
                                <div style="padding-left: 30px;">
                                  理由：{{ item.actReson }}
                                </div>
                              </div>
                              <div class="" style="margin-left: 5px;">
                                <div style="padding-left: 30px;padding-bottom: 30px;">
                                  {{ formatDate(item.actTime) }}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </slot>
                      <span slot="reference" class="yuan">i</span>
                    </el-popover>
                  </template>
                </el-table-column>
                <el-table-column label="操作">
                  <template scope="scope">
                    <div class="operation">
                      <i
                        class="opeatLeft"
                        v-if="
                          scope.row.taskStatus != 1 &&
                            (scope.row.status == 3 ||
                              scope.row.status == 5 ||
                              scope.row.status == 7) &&
                            scope.row.secAppFlag === 1
                        "
                      >
                        <i
                          funcId="000068"
                          @click="
                            jumpToSound(
                              1,
                              scope.row.callId,
                              scope.row.status,
                              scope.row.appealId,
                              scope.row.scoreId,
                              scope.row.taskStatus,
                              scope.row.secAppFlag,
                              scope.row.qaScoreType,
                              scope.row.recordFileURL
                            )
                          "
                          style="color: #20A0FF;cursor: pointer;"
                          >成绩确认</i
                        ></i
                      >
                    </div>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="autoGrading-page">
            <el-pagination
              @size-change="complinChange"
              @current-change="complinCurrent"
              :current-page="currentPage"
              :page-sizes="pageSizes"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <!-- 已确认页面 -->
      <div class="soundfeature-pos-content" v-show="index == 3">
        <div class="soundfeature-search">
          <el-form :inline="true" ref="searchForms3" :model="searchForms3">
            <el-form-item label="质检结果" prop="score">
              <el-col :span="10">
                <el-input
                  placeholder="请输入最小值"
                  style="width:120px"
                  v-model.number="searchForms3.score_Min"
                  oninput="value=value.replace(/[^-\d]/g,'')"
                  maxLength="3"
                ></el-input>
              </el-col>
              <el-col class="line" :span="4">~</el-col>
              <el-col :span="10">
                <el-input
                  placeholder="请输入最大值"
                  style="width:120px;margin-right:25px"
                  v-model.number="searchForms3.score_Max"
                  oninput="value=value.replace(/[^-\d]/g,'')"
                  maxLength="3"
                ></el-input>
              </el-col>
            </el-form-item>
            <el-form-item label="是否致命" prop="deadItem">
              <el-select
                v-model="searchForms3.deadItem"
                placeholder="请选择"
                style="width:100px"
              >
                <el-option label="是" value="1"></el-option>
                <el-option label="否" value="2"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="searchFormConfirm">查询</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="content contentButt">
          <div class="table">
            <div>
              <el-table
                :data="fillData"
                border
                ref="multipleTable"
                tootip-effect="dark"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"></el-table-column>
                <el-table-column prop="callId" label="录音编号">
                  <template scope="scope">
                    <el-button
                      type="text"
                      @click="
                        jumpToSound(
                          1,
                          scope.row.callId,
                          scope.row.status,
                          scope.row.appealId,
                          null,
                          scope.row.taskStatus,
                          scope.row.secAppFlag,
                          scope.row.qaScoreType,
                          scope.row.recordFileURL
                        )
                      "
                      >{{ scope.row.callId }}</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="callSTime"
                  sortable="true"
                  label="录音时间"
                  :formatter="dateFormat"
                  width="180px"
                >
                </el-table-column>
                <el-table-column
                  prop="callTime"
                  :formatter="dateFormatTwo"
                  label="录音时长"
                >
                </el-table-column>
                <el-table-column prop="score" sortable label="质检结果">
                </el-table-column>
                <el-table-column prop="deadItem" sortable label="是否致命">
                  <template scope="scope">
                    <i v-if="scope.row.deadItem == 1">是</i>
                    <i v-else="">否</i>
                  </template>
                </el-table-column>
                <el-table-column prop="state" label="成绩状态">
                  <template scope="scope">
                    <i v-if="scope.row.state == 2">已确认</i>
                    <el-popover
                      placement="left"
                      trigger="hover"
                      v-if="scope.row.AppDetail.length > 0"
                    >
                      <slot name="reference">
                        <div class="showMcen" id="notTable">
                          <div class="detailsNew">
                            <div
                              v-for="(item, index) in scope.row.AppDetail"
                              :key="index"
                              style="width: 100%;"
                              v-if="index < scope.row.AppDetail.length - 1"
                            >
                              <div>
                                <div
                                  style="height:10px;width:10px;float:left;background: #BFCBD9;display: inline-block;border-radius: 50%"
                                ></div>
                                <div
                                  style="padding-left: 30px;margin-left: 5px;border-left: 1px solid #BFCBD9;"
                                >
                                  {{ item.actDesc }}
                                </div>
                              </div>
                              <div
                                style="margin-left: 5px;border-left: 1px solid #BFCBD9;"
                              >
                                <div style="padding-left: 30px;">
                                  理由：{{ item.actReson }}
                                </div>
                              </div>
                              <div
                                class=""
                                style="margin-left: 5px;border-left: 1px solid #BFCBD9;"
                              >
                                <div style="padding-left: 30px;padding-bottom: 30px;">
                                  {{ formatDate(item.actTime) }}
                                </div>
                              </div>
                            </div>
                            <div
                              v-for="(item, index) in scope.row.AppDetail"
                              :key="index"
                              style="width: 100%;"
                              v-if="index == scope.row.AppDetail.length - 1"
                            >
                              <div>
                                <div
                                  style="height:10px;width:10px;float:left;background: #20A0FF;display: inline-block;border-radius: 50%"
                                ></div>
                                <div style="padding-left: 30px;margin-left: 5px;">
                                  {{ item.actDesc }}
                                </div>
                              </div>
                              <div style="margin-left: 5px;">
                                <div style="padding-left: 30px;">
                                  理由：{{ item.actReson }}
                                </div>
                              </div>
                              <div class="" style="margin-left: 5px;">
                                <div style="padding-left: 30px;padding-bottom: 30px;">
                                  {{ formatDate(item.actTime) }}
                                </div>
                              </div>
                            </div>
                            <!-- <el-table :data="scope.row.AppDetail">
                                  <el-table-column>
                                    <template scope="scopes">
                                      @{{formatDate(scopes.row.actTime)}}<br/>
                                      !{{scopes.row.actReson}}<br/>
                                      #{{scopes.row.actDesc}}
                                    </template>
                                  </el-table-column>
                                </el-table> -->
                          </div>
                        </div>
                      </slot>
                      <span
                        slot="reference"
                        class="yuan"
                        v-if="scope.row.AppDetail != undefined"
                        >i</span
                      >
                    </el-popover>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="autoGrading-page">
            <el-pagination
              @size-change="comfirmSize"
              @current-change="comfirmBiger"
              :current-page="currentPage"
              :page-sizes="pageSizes"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <!-- 申诉弹窗 -->
      <el-dialog
        class="giveResult"
        :visible.sync="setInput"
        width="420px"
        title="申诉"
        :close-on-click-modal="false"
      >
        <div class="dealCenter">
          <el-form
            :model="searchForm"
            label-width="84px"
            ref="fourForm"
            :rules="searchFormRules"
          >
            <el-form-item label="申诉理由" prop="byReson" style="margin-top: 20px;">
              <el-input
                v-model="searchForm.byReson"
                type="textarea"
                placeholder="请输入内容"
              ></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div
          class="footerAll"
          style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
        >
          <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
            <el-button @click="notChange">取 消</el-button>
            <el-button
              @click="complainNextThrottle"
              type="primary"
              style="margin-right: 18px;"
              >提 交</el-button
            >
          </div>
        </div>
      </el-dialog>
    </div>
    <!-- 录音播放页面弹窗 -->
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="single"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @shenSuScored="onShenSuScored"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        >
        </recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import global from '@/global'
import $ from 'jquery'
import formatdate from '../../../utils/formatdate.js'
import Qs from 'qs'
import bus from '../../common/bus.js'
import recordingplay from '../recordingPlay/recordingPlayResultScore.vue'
import funcFilter from '@/utils/funcFilter.js'
let qualityUrl = global.qualityUrl
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      index: '1', // 默认显示页签
      // 查询参数
      //未确认
      searchForms1: {
        score_Max: '',
        score_Min: '',
        deadItem: '',
      },
      //申诉中
      searchForms2: {
        score_Max: '',
        score_Min: '',
        deadItem: '',
        scoreStatus: '',
      },
      //已确认
      searchForms3: {
        score_Max: '',
        score_Min: '',
        deadItem: '',
      },
      searchForm: {
        callSTime: [], //录音时间
        byReson: '',
      },
      searchFormRules: {
        byReson: [{ max: 250, message: '申诉理由不能超过250个字符', trigger: 'change' }],
      },
      cunCallid: '',
      selectedArr: [],
      tableData: [], //未确认表格数据
      twoData: [], //申诉中表格数据
      fillData: [], //已确认表格数据
      currentPage: 1,
      resultScoreIndex: '3', // 1申诉中 2已确认 3未确认
      setInput: false,
      recordDialogVisible: false,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
    }
  },
  methods: {
    toggleSound(event) {
      // 未确认头部切换
      let currentIndex = $(event.target).attr('data-id')
      this.index = currentIndex
      $('.soundfeature-pos-nav ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
      let obj = {}
      obj.resultScoreIndex = '3'
      this.resultScoreIndex = '3'
      this.currentPage = 1
      this.searchFormNoconfirm()
      this.$store.commit('setRecordingPlayPage', obj)
    },
    toggleSoundtwo(event) {
      // 申诉中头部切换
      let currentIndex = $(event.target).attr('data-id')
      this.index = currentIndex
      $('.soundfeature-pos-nav ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
      let obj = {}
      obj.resultScoreIndex = '1'
      this.resultScoreIndex = '1'
      this.currentPage = 1
      this.searchFormAppeal()
      this.$store.commit('setRecordingPlayPage', obj)
    },
    toggleSoundthree(event) {
      // 已确认头部切换
      let currentIndex = $(event.target).attr('data-id')
      this.index = currentIndex
      $('.soundfeature-pos-nav ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
      let obj = {}
      obj.resultScoreIndex = '2'
      this.resultScoreIndex = '2'
      this.currentPage = 1
      this.searchFormConfirm()
      this.$store.commit('setRecordingPlayPage', obj)
    },
    sumitBet(index) {
      this.setInput = true
      this.cunCallid = index
      this.searchForm.byReson = ''
    },
    //申诉弹窗提交操作
    complainNextThrottle() {
      this.$refs.fourForm.validate((valid) => {
        if (valid) {
          this.lodashThrottle.throttle(this.complainNext, this)
        }
      })
    },
    complainNext() {
      let params = {
        callId: this.cunCallid,
        comments: this.searchForm.byReson,
      }
      this.axios
        .post(qualityUrl + '/appealsProcess/seatAppeal.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.flag) {
            this.setInput = false
            this.$message({
              type: 'success',
              message: resp.data.msg,
            })
            // 服务端返回的数据没那么及时
            setTimeout(() => {
              this.searchFormNoconfirm()
            }, 800)
          } else {
            this.$message({
              type: 'error',
              message: resp.data.msg,
            })
          }
        })
        .catch(function() {
          this.$message({
            type: 'error',
            message: '申诉失败',
          })
        })
    },
    // 申诉确认分数
    onShenSuScored() {
      setTimeout(() => {
        this.searchFormAppeal()
      }, 800)
    },
    // 取消申诉
    notChange() {
      this.setInput = false
    },
    // 手动关闭录音播放页面
    recordPlayCloseHandler() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    //录音播放页面最小化
    recordPlayMinimizeHandler() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 跳转到录音播放页面
    jumpToSound(
      type,
      callId,
      status,
      appealId,
      scoreId,
      taskStatus,
      secAppFlag,
      qaScoreType,
      recordFileURL
    ) {
      let obj = {}
      obj.from = 'scoreResultInfo'
      obj.scoreResultRole = 'scoreResultZuoXi'
      obj.appealStatus = status
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.appealId = appealId
      obj.qaScoreType = qaScoreType
      obj.resultScoreIndex = this.resultScoreIndex
      obj.scoreId = scoreId
      obj.taskStatus = taskStatus
      obj.secAppFlag = secAppFlag
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlay')
      // 初始化play
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay', // 扩展样式
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    dateFormat(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // 将录音时长转换为秒
    dateFormatTwo(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.searchFormNoconfirm()
    },
    formatDate(obj) {
      let date = new Date(obj)
      let y = 1900 + date.getYear()
      let m = '0' + (date.getMonth() + 1)
      let d = '0' + date.getDate()
      let h = '0' + date.getHours()
      let f = '0' + date.getMinutes()
      let s = '0' + date.getSeconds()
      return (
        y +
        '-' +
        m.substring(m.length - 2, m.length) +
        '-' +
        d.substring(d.length - 2, d.length) +
        ' ' +
        h.substring(h.length - 2, h.length) +
        ':' +
        f.substring(f.length - 2, f.length) +
        ':' +
        s.substring(s.length - 2, s.length)
      )
    },
    // scoreInquery() {
    //   let fromTime = ''
    //   let toTime = ''
    //   if (this.searchForm.callSTime == null) {
    //     this.fromTime = ''
    //     this.toTime = ''
    //   } else {
    //     if (
    //       this.searchForm.callSTime[0] != undefined &&
    //       this.searchForm.callSTime[0] != ''
    //     ) {
    //       fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
    //     } else {
    //       // 默认获取当前月的第一天
    //       let now = new Date()
    //       now.setDate(1)
    //       now.setHours(0)
    //       now.setMinutes(0)
    //       now.setSeconds(0)
    //       fromTime = formatdate.formatDate(now)
    //     }
    //     if (
    //       this.searchForm.callSTime[1] != undefined &&
    //       this.searchForm.callSTime[1] != ''
    //     ) {
    //       toTime = formatdate.formatDate(this.searchForm.callSTime[1])
    //     } else {
    //       // 默认获取当前月的最后一天
    //       let now = new Date()
    //       let currentMonth = now.getMonth()
    //       let nextMonth = ++currentMonth
    //       let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
    //       let oneDay = 1000
    //       toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
    //     }
    //   }
    //   this.searchForm.callSTime = [fromTime, toTime]
    //   let params = {
    //     pageindex: this.currentPage,
    //     pagesize: this.pageSize,
    //     callSTime_DLMin: fromTime,
    //     callSTime_DLMax: toTime,
    //     state: 3,
    //   }
    //   this.axios
    //     .post(qualityUrl + '/scoreResult/queryScoreList.do', Qs.stringify(params))
    //     .then((resp) => {
    //       if (resp.data.Count) {
    //         this.tableData = resp.data.Data
    //       } else {
    //         this.tableData = []
    //       }
    //       this.total = resp.data.Count
    //     })
    // },
    // complint() {
    //   let fromTime = ''
    //   let toTime = ''
    //   if (this.searchForm.callSTime == null) {
    //     this.fromTime = ''
    //     this.toTime = ''
    //   } else {
    //     if (
    //       this.searchForm.callSTime[0] != undefined &&
    //       this.searchForm.callSTime[0] != ''
    //     ) {
    //       fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
    //     } else {
    //       // 默认获取当前月的第一天
    //       let now = new Date()
    //       now.setDate(1)
    //       now.setHours(0)
    //       now.setMinutes(0)
    //       now.setSeconds(0)
    //       fromTime = formatdate.formatDate(now)
    //     }
    //     if (
    //       this.searchForm.callSTime[1] != undefined &&
    //       this.searchForm.callSTime[1] != ''
    //     ) {
    //       toTime = formatdate.formatDate(this.searchForm.callSTime[1])
    //     } else {
    //       // 默认获取当前月的最后一天
    //       let now = new Date()
    //       let currentMonth = now.getMonth()
    //       let nextMonth = ++currentMonth
    //       let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
    //       let oneDay = 1
    //       toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
    //     }
    //   }
    //   this.searchForm.callSTime = [fromTime, toTime]
    //   let params = {
    //     pageindex: this.currentPage,
    //     pagesize: this.pageSize,
    //     callSTime_DLMin: fromTime,
    //     callSTime_DLMax: toTime,
    //     state: 1,
    //   }
    //   this.axios
    //     .post(qualityUrl + '/scoreResult/queryScoreList.do', Qs.stringify(params))
    //     .then((resp) => {
    //       let c1 = [1, 2, 3]
    //       let d1 = [4, 5, 6]
    //       let a1 = []
    //       a1.push(c1)
    //       a1.push(d1)
    //       if (resp.data.Count) {
    //         this.twoData = resp.data.Data
    //       } else {
    //         this.twoData = []
    //       }
    //       this.total = resp.data.Count
    //     })
    //   this.$refs.searchForms2.resetFields()
    // },
    // comfirmSide() {
    //   let fromTime = ''
    //   let toTime = ''
    //   if (this.searchForm.callSTime == null) {
    //     this.fromTime = ''
    //     this.toTime = ''
    //   } else {
    //     if (
    //       this.searchForm.callSTime[0] != undefined &&
    //       this.searchForm.callSTime[0] != ''
    //     ) {
    //       fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
    //     } else {
    //       // 默认获取当前月的第一天
    //       let now = new Date()
    //       now.setDate(1)
    //       now.setHours(0)
    //       now.setMinutes(0)
    //       now.setSeconds(0)
    //       fromTime = formatdate.formatDate(now)
    //     }
    //     if (
    //       this.searchForm.callSTime[1] != undefined &&
    //       this.searchForm.callSTime[1] != ''
    //     ) {
    //       toTime = formatdate.formatDate(this.searchForm.callSTime[1])
    //     } else {
    //       // 默认获取当前月的最后一天
    //       let now = new Date()
    //       let currentMonth = now.getMonth()
    //       let nextMonth = ++currentMonth
    //       let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
    //       let oneDay = 1000
    //       toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
    //     }
    //   }
    //   this.searchForm.callSTime = [fromTime, toTime]
    //   let params = {
    //     pageindex: this.currentPage,
    //     pagesize: this.pageSize,
    //     callSTime_DLMin: fromTime,
    //     callSTime_DLMax: toTime,
    //     state: 2,
    //   }
    //   this.axios
    //     .post(qualityUrl + '/scoreResult/queryScoreList.do', Qs.stringify(params))
    //     .then((resp) => {
    //       if (resp.data.Count) {
    //         this.fillData = resp.data.Data
    //       } else {
    //         this.fillData = []
    //       }
    //       this.total = resp.data.Count
    //     })
    // },
    //未确认内容查询
    searchFormNoconfirm() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      if (this.searchForms1.score_Min && this.searchForms1.score_Max) {
        if (this.searchForms1.score_Min > this.searchForms1.score_Max) {
          this.$message({
            type: 'error',
            message: '请输入正确的质检结果范围',
          })
          return
        }
      }
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        callSTime_DLMin: fromTime,
        callSTime_DLMax: toTime,
        score_Min: this.searchForms1.score_Min,
        score_Max: this.searchForms1.score_Max,
        deadItem: this.searchForms1.deadItem,
        state: 3,
      }
      this.axios
        .post(qualityUrl + '/scoreResult/queryScoreList.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            this.tableData = resp.data.Data.map((item) => {
              item.score = parseInt(Number(item.score))
              return item
            })
            this.filterButton() // 过滤权限控制
          } else {
            this.tableData = []
          }
          this.total = resp.data.Count
        })
    },
    //申诉中内容查询
    searchFormAppeal() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      if (this.searchForms2.score_Min && this.searchForms2.score_Max) {
        if (this.searchForms2.score_Min > this.searchForms2.score_Max) {
          this.$message({
            type: 'error',
            message: '请输入正确的质检结果范围',
          })
          return
        }
      }
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        callSTime_DLMin: fromTime,
        callSTime_DLMax: toTime,
        score_Min: this.searchForms2.score_Min,
        score_Max: this.searchForms2.score_Max,
        deadItem: this.searchForms2.deadItem,
        status: this.searchForms2.scoreStatus,
        state: 1,
      }
      this.axios
        .post(qualityUrl + '/scoreResult/queryScoreList.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            this.twoData = resp.data.Data.map((item) => {
              item.score = parseInt(Number(item.score))
              return item
            })
            this.filterButton() // 过滤控制权限
          } else {
            this.twoData = []
          }
          this.total = resp.data.Count
        })
    },
    //已确认内容查询
    searchFormConfirm() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      if (this.searchForms3.score_Min && this.searchForms3.score_Max) {
        if (this.searchForms3.score_Min > this.searchForms3.score_Max) {
          this.$message({
            type: 'error',
            message: '请输入正确的质检结果范围',
          })
          return
        }
      }
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        callSTime_DLMin: fromTime,
        callSTime_DLMax: toTime,
        score_Min: this.searchForms3.score_Min,
        score_Max: this.searchForms3.score_Max,
        deadItem: this.searchForms3.deadItem,
        state: 2,
      }
      this.axios
        .post(qualityUrl + '/scoreResult/queryScoreList.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            this.fillData = resp.data.Data.map((item) => {
              item.score = parseInt(Number(item.score))
              return item
            })
          } else {
            this.fillData = []
          }
          this.total = resp.data.Count
        })
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.searchFormNoconfirm()
    },
    // 申诉中的分页
    complinChange(val) {
      this.pageSize = val
      this.searchFormAppeal()
    },
    complinCurrent(val) {
      this.currentPage = val
      this.searchFormAppeal()
    },
    // 已确认的分页
    comfirmSize(val) {
      this.pageSize = val
      this.searchFormConfirm()
    },
    comfirmBiger(val) {
      this.currentPage = val
      this.searchFormConfirm()
    },
    handleSelectionChange(val) {
      this.selectedArr = val
    },
    /*
     * 过滤权限按钮
     * */
    filterButton() {
      /*
       获取数据后dom节点更改了，
        需要再获取一遍dom节点对[funcID]按钮进行过滤
       * */
      let menuId = localStorage.getItem('menuId')
      let path = this.$route.path.replace('/', '')
      funcFilter(menuId, path)
    },
  },
  mounted() {
    this.currentPage = 1
    this.pagesize = 20
    this.searchFormNoconfirm()
  },
  computed: {},
  created() {
    this.recordPlayCloseHandler()
  },
}
</script>
<style lang="less" scoped="scoped">
.table {
  width: 100%;
  height: 100%;
  overflow: auto;
}
.content {
  padding-bottom: 120px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}
.yuan {
  display: inline-block;
  cursor: pointer;
  height: 18px;
  width: 18px;
  border-radius: 50%;
  background: #99a8bd;
  text-align: center;
  line-height: 18px;
  float: right;
  color: #fff;
  margin-top: 3px;
}
#soundfeature {
  box-sizing: border-box;
  height: 100%;
  width: 100%;
  .soundfeature-pos {
    width: 100%;
    height: 100%;
    position: relative;
  }
  .soundfeature-pos .soundfeature-pos-nav {
    width: 100%;
    height: 60px;
    line-height: 60px;
    background: #eef1f6;
    border-bottom: 1px solid #d1dbe4;
    border-top: 1px solid #d1dbe4;
    background: #ffffff;
    position: absolute;
  }
  .soundfeature-pos-nav ul {
    width: 100%;
    box-sizing: border-box;
  }
  .soundfeature-pos-nav ul li {
    float: left;
    padding: 0 16px;
    box-sizing: border-box;
    font-size: 14px;
    color: #96a2b2;
    cursor: pointer;
  }
  .soundfeature-pos-nav ul li.all-search {
    padding-top: 10px;
    padding-right: 20px;
    float: right;
  }
  .soundfeatureActive {
    color: #21a2ff !important;
    border-bottom: 2px solid #21a2ff;
  }
  .soundfeature-pos .soundfeature-pos-content {
    padding: 70px 20px 0;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    overflow: hidden;
    .soundfeature-search {
      width: 100%;
      height: 60px;
      margin-top: 10px;
      .line {
        text-align: center;
      }
    }
  }
  .moreChoice {
    line-height: 36px;
    text-decoration: underline;
    color: #20a0ff;
    cursor: pointer;
    font-size: 13px;
    margin-left: 4px;
  }
  .scoreinfo-page {
    width: 100%;
    height: 35px;
    position: absolute;
    background: white;
    left: 0;
    right: 0px;
    bottom: 0px;
    text-align: right;
    .el-pagination {
      display: inline-block;
      height: 28px;
      line-height: 28px;
      padding: 0px 10px;
    }
  }
}
.autoGrading-page {
  right: 10px;
  position: absolute;
  bottom: 10px;
}
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
</style>
<style lang="less">
#soundfeature {
  .soundfeature-pos-nav .el-form-item {
    margin-bottom: 0;
  }
  .contentButt .el-button {
    padding: 10px 0px;
  }
  .el-table--border th {
    background: #e5e9f2;
    padding: 10px 0;
  }
  .el-table thead {
    color: #475669;
  }
  .giveResult {
    .el-textarea__inner {
      width: 80%;
      height: 200px;
    }
  }
  .edealFind {
    .el-dialog__body {
      padding: 0;
    }
    .el-dialog__header {
      padding: 25px 0px 10px 0px;
      border-bottom: 1px solid #e0e6ed;
      .el-dialog__title {
        padding-left: 20px;
      }
    }
    .giveResult .dealCenter .el-input__inner {
      width: 240px;
    }
  }
}
.el-dialog__wrapper.single {
  position: fixed;
  top: 106px;
  left: 20px;
  right: 20px;
  bottom: 12px;
  .el-dialog {
    width: 100%;
    height: 100%;
    margin: 0 !important;
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}

.el-button.goback-btn {
  padding: 0;
  margin: 0;
  border: none;
  font-size: 14px;
  color: #20a0ff;
}

.showMcen {
  width: 100%;
  display: inline-block;
  overflow: hidden;
  text-align: left;
  padding: 15px;
  position: relative;
  color: #1f2d3d;
  border-radius: 4px;
  vertical-align: middle;
  & > span {
    .strategybtn {
      cursor: pointer;
      overflow: hidden;
      padding-left: 10px;
      padding-right: 10px;
      .settingStrategyName {
        width: 100%;
        overflow: hidden;
        display: inline-block;
        text-overflow: ellipsis;
        float: left;
      }
    }
    .settingStrategybtns {
      float: right;
      width: 50px;
      i {
        margin-right: 5px;
        width: 18px;
        height: 18px;
        line-height: 18px;
        font-size: 10px;
        color: #20a0ff;
        &:hover {
          background: #20a0ff;
          color: #fff;
          border-radius: 50%;
        }
      }
    }
  }
  &.hovered {
    border-color: #20a0ff;
    span .strategybtn {
      padding-right: 0px;
      .settingStrategyName {
        width: 100px;
        color: #20a0ff;
      }
    }
    &.active span .strategybtn {
      .settingStrategyName {
        color: #fff;
      }
      .settingStrategybtns {
        i {
          color: #fff;
          &:hover {
            background: #fff;
            color: #20a0ff;
          }
        }
      }
    }
  }
  &.active {
    background: #20a0ff;
    color: #fff;
    border-color: #20a0ff;
    .settingStrategybtns {
      i {
        &:hover {
          background: #fff;
          color: #20a0ff;
        }
      }
    }
  }
  .detailsNew {
    display: flex;
    flex-wrap: wrap;
  }
  .contentNew {
    line-height: 30px;
    width: 100%;
    span {
      color: #9ca2b2;
      i {
        color: #1f2d3d;
      }
    }
  }
}
.el-popover {
  width: 25%;
}
#notTable .el-table__header-wrapper {
  display: none;
}
#notTable .el-table td {
  border-bottom: 0px solid #ebeef5;
}
</style>
