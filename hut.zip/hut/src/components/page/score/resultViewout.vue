<template>
  <div id="soundfeature">
    <div class="soundfeature-pos edealcell">
      <div class="soundfeature-pos-nav">
        <ul>
          <li
            data-id="1"
            @click="toggleSound"
            class="soundfeatureActive"
            style="margin-left:34px;"
          >
            成绩统计
          </li>
          <li data-id="2" @click="toggleSound">成绩查看</li>
        </ul>
      </div>
      <div class="soundfeature-pos-content" v-show="index == 2">
        <div style="display: flex;display: -webkit-flex;">
          <div style="flex-direction: row;width: 100%;">
            <el-form :inline="true">
              <el-date-picker
                v-model="searchForm.callSTime"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                align="right"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 375px;"
              >
              </el-date-picker>
              <el-form-item label="质检结果" style="margin-left: 14px;">
                <el-input
                  v-model="searchForm.score_Min"
                  placeholder=""
                  style="width:70px"
                ></el-input>
                <span>-</span>
                <el-input
                  v-model="searchForm.score_Max"
                  placeholder=""
                  style="width:70px"
                ></el-input>
              </el-form-item>
              <el-form-item label="是否致命">
                <el-select
                  v-model="searchForm.deadItem"
                  placeholder="请输入内容"
                  style="width: 135px;"
                >
                  <el-option value="1" label="是"></el-option>
                  <el-option value="2" label="否"></el-option>
                </el-select>
              </el-form-item>
              <el-button @click="scoreInquery" type="primary" style="margin-left: 7px;"
                >查询</el-button
              >
              <a class="moreChoice" @click="moreCondition">更多条件搜索</a>
              <el-form-item style="float: right;margin-right: 0px;">
                <el-button @click="exportExl">导出</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
        <div class="content contentButt">
          <div class="table">
            <div style="padding-bottom: 70px;">
              <el-table
                :data="tableData"
                border
                ref="multipleTable"
                tootip-effect="dark"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"></el-table-column>
                <el-table-column prop="callId" label="录音编号">
                  <template scope="scope">
                    <el-button type="text" @click="jumpToSound(1, scope.row.callId,scope.row.recordFileURL)">{{
                      scope.row.callId
                    }}</el-button>
                  </template>
                </el-table-column>
                <el-table-column prop="seatName" label="坐席姓名"> </el-table-column>
                <el-table-column
                  prop="callSTime"
                  sortable
                  :formatter="dateFormat"
                  label="录音时间"
                  width="180"
                >
                </el-table-column>
                <el-table-column
                  prop="callTime"
                  :formatter="dateFormatTwo"
                  label="录音时长"
                >
                </el-table-column>
                <el-table-column prop="score" sortable label="质检成绩">
                </el-table-column>
                <el-table-column prop="deadItem" sortable label="是否致命">
                  <template scope="scope">
                    <i v-if="scope.row.deadItem == 1">是</i>
                    <i v-else="">否</i>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
          <div class="autoGrading-page">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="pageSizes"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
      </div>
      <div v-show="index == 1" style="height: 100%;width: 100%;overflow-y: scroll;">
        <div style="padding: 10px 20px 0 50px;height: 50px;line-height: 50px;">
          <div style="font-size: 14px;font-weight: bold;display: inline-block;">
            查看成绩分布
          </div>
          <div style="display: inline-block;float: right;">
            <el-form :inline="true" class="fr">
              <el-form-item>
                <template>
                  <el-input
                    class="select-width hide"
                    v-model="formRight.region"
                  ></el-input>
                  <el-input
                    class="select-width"
                    v-click-outside="outside"
                    @focus="inside"
                    ref="regionInput"
                    placeholder="请选择范围"
                    clearable
                    v-model="formRight.name"
                  >
                  </el-input>
                  <div class="contentLeft" v-show="this.showTree == true">
                    <div class="treeMenu">
                      <el-tree
                        :data="treeMenu"
                        :props="defaultProps"
                        :render-after-expand="false"
                        @node-click="handleNodeClick"
                        @check="clickDin"
                        ref="keyWordsMenu"
                        show-checkbox
                        node-key="id"
                        :check-strictly="true"
                      >
                      </el-tree>
                    </div>
                  </div>
                </template>
              </el-form-item>
              <el-date-picker
                v-model="searchForm.findTimer"
                type="datetimerange"
                :editable="false"
                :clearable="false"
                align="right"
                @change="clickDin"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :default-time="['00:00:00', '23:59:59']"
                style="width: 375px;"
              >
              </el-date-picker>
            </el-form>
          </div>
        </div>
        <div
          id="mainAminte"
          class="soundfeature-pos-content"
          style="width: 100%;height:320px;padding: 0 20px;"
        ></div>
        <div style="padding: 10px 20px 0 50px;height: 50px;line-height: 50px;">
          <div style="font-size: 14px;font-weight: bold;display: inline-block;width: 40%">
            致命项统计
          </div>
          <div style="font-size: 14px;font-weight: bold;display: inline-block;width: 58%">
            致命项原因排名
          </div>
        </div>
        <div
          id="mainpie"
          class="soundfeature-pos-content"
          style="width: 40%;height:320px;display: inline-block;padding: 0 20px;"
        ></div>
        <div
          id="lineDraw"
          class="soundfeature-pos-content"
          style="width: 59%;height:320px;display: inline-block;padding: 20px;"
        ></div>
        <div
          v-show="mateLate"
          class="soundfeature-pos-content"
          style="width: 59%;height:320px;display: inline-block;padding: 20px;"
        >
          <div
            style="width: 100%;height: 100%;border: 1px solid #E0E6ED;display:flex;justify-content:center;align-items:center;"
          >
            暂无数据
          </div>
        </div>
        <div style="width:100%;border-top: 1px solid #E4E4E4"></div>
        <div style="padding: 10px 20px 0 50px;height: 50px;line-height: 50px;">
          <div style="font-size: 14px;font-weight: bold;display: inline-block;">
            得分趋势图
          </div>
        </div>
        <div
          id="diagram"
          class="soundfeature-pos-content"
          style="width: 100%;height:320px;padding: 0 20px;margin-bottom: 60px;"
        ></div>
      </div>
      <el-dialog
        class="speGivere"
        :visible.sync="moreChance"
        width="420px"
        :before-close="closeAll"
        :close-on-click-modal="false"
      >
        <div class="dealCenter" style="border-top: 1px solid #E0E6ED;padding: 10px 0;">
          <el-form label-width="84px" ref="fourForm">
            <el-form-item label="录音编号">
              <el-input v-model="searchForm.objectId" placeholder="请输入内容"></el-input>
            </el-form-item>
            <el-form-item label="坐席姓名">
              <el-input v-model="searchForm.seatName" placeholder="请输入内容"></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div
          class="footerAll"
          style="width: 100%;border-top: 1px solid #E0E6ED;height: 68px;"
        >
          <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
            <el-button @click="cancelNot">取 消</el-button>
            <el-button @click="findSomething" type="primary" style="margin-right: 18px;"
              >查 询</el-button
            >
          </div>
        </div>
      </el-dialog>
    </div>
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="single"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        >
        </recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import global from '@/global'
import $ from 'jquery'
import formatdate from '../../../utils/formatdate.js'
import Qs from 'qs'
import cache from '../../../utils/cache.js'
import bus from '../../common/bus.js'
import recordingplay from '../recordingPlay/recordingPlayResultScore.vue'
let qualityUrl = global.qualityUrl
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      nav: { value: 'id', label: 'name', children: 'child' },
      index: '1', // 默认显示页签
      showTree: false, // 树的显示隐藏
      mateLate: false,
      treeMenu: [], // 树菜单
      defaultProps: {
        value: 'id',
        children: 'child',
        label: 'name',
      },
      formRight: {
        region: '',
        name: '',
        times: [],
      },
      searchForm: {
        callSTime: [],
        findTimer: [],
        lastTimer: [],
        score_Min: '',
        score_Max: '',
        deadItem: '2',
        objectId: '',
        seatName: '',
        drapingRow: [],
      },
      option: {
        color: ['#3398DB','#40E0B0'],
        grid: {
          show: true,
          left: '5%',
          top: '15%',
          containLabel: true,
          borderWidth: 0,
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
        },
        legend: {},
        xAxis: {
          splitLine: {
            show: false,
            lineStyle: '#3398DB',
          },
          boundaryGap:true,
          type: 'category',
          data: [],
          axisTick: {
            alignWithLabel: true,
          },
          name: '成绩区间',
          nameTextStyle: {
            color: '#1F2D3D',
            fontSize: 14,
            borderColor: '#3398DB',
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#C0CCDA',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#1F2D3D',
            },
          },
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: false,
          },
          name: '录音数',
          nameTextStyle: {
            color: '#1F2D3D',
            fontSize: 14,
          },
          axisLine: {
            show: true,
            lineStyle: {
              color: '#C0CCDA',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#1F2D3D',
            },
          },
        },
        series: [],
      },
      prtion: {
        color: ['#C0CCDA', '#40E0B0'],
        series: [
          {
            type: 'pie',
            radius: ['60%', '75%'],
            center: ['45%', '45%'],
            label: {
              normal: {
                show: false,
                position: 'center',
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: '18',
                  fontWeight: 'bold',
                },
              },
            },
            startAngle: 300,
            data: [],
          },
        ],
      },
      custom: {
        grid: {
          left: '15%',
          top: '5%',
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
          formatter: function(params) {
            let res = ''
            res += '<strong>' + params[0].name + '</strong>'
            for (let i = 0; i < params.length; i++) {
              if (i == params.length - 1) {
                res +=
                  '<br/>' + params[i].seriesName + ':&nbsp;' + params[i].value + '(%)'
              } else {
                res +=
                  '<br/><div style="display:inline-block;margin-right:5px;height: 10px;width:10px;border-radius:50%;background:' +
                  params[i].color +
                  '"></div>' +
                  params[i].seriesName +
                  ':&nbsp;' +
                  params[i].value +
                  '(项)'
              }
            }
            return res
          },
        },
        calculable: true,
        xAxis: {
          type: 'value',
          show: false,
        },
        yAxis: {
          type: 'category',
          data: [],
          axisLine: {
            show: true,
            lineStyle: {
              color: '#C0CCDA',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#1F2D3D',
            },
          },
        },
        series: [],
      },
      diaouyt: {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
          },
        },
        legend: {
          data: [],
        },
        grid: {
          left: 30,
          top: 70,
          bottom: 50,
        },
        xAxis: [
          {
            type: 'category',
            name: '日期',
            data: [],
          },
          {
            type: 'category',
            axisTick: {
              alignWithLabel: true,
            },
            axisLine: {
              onZero: false,
              lineStyle: {
                color: '#C0CCDA',
              },
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
            name: '得分',
            axisLine: {
              lineStyle: {
                color: '#1F2D3D',
              },
            },
            axisLabel: {
              textStyle: {
                color: '#1F2D3D',
              },
            },
          },
        ],
        series: [],
      },
      selectedArr: [],
      tableData: [],
      currentPage: 1,
      moreChance: false,
      recordDialogVisible: false,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
    }
  },
  computed: {
    /* 专题ID */
    getThenaticAnalysisId() {
      return this.$store.state.thenaticAnalysisId.subjectId
    },
  },
  methods: {
    toggleSound(event) {
      // 首页头部切换
      let currentIndex = $(event.target).attr('data-id')
      this.index = currentIndex
      $('.soundfeature-pos-nav ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
    },
    // openCell: function () {
    // $('.is-focusable .el-checkbox__input span').removeClass('el-checkbox__inner')
    // $('.is-focusable .el-checkbox__input span').addClass('el-radio__inner')
    // },
    moreCondition: function() {
      this.searchForm.objectId = ''
      this.searchForm.seatName = ''
      this.moreChance = true
    },
    cancelNot: function() {
      this.moreChance = false
      this.searchForm.objectId = ''
      this.searchForm.seatName = ''
    },
    findSomething: function() {
      this.scoreInquery()
      this.moreChance = false
    },
    closeAll: function(done) {
      done()
      this.searchForm.objectId = ''
      this.searchForm.seatName = ''
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 点击自己 还是除了自己以外的元素
    outside: function(e) {
      this.showTree = false
    },
    inside: function(e) {
      this.showTree = true
      $('.is-focusable .el-checkbox__input span').removeClass('el-checkbox__inner')
      $('.is-focusable .el-checkbox__input span').addClass('el-radio__inner')
      this.resetChecked()
    },
    // 树节点点击
    handleNodeClick(data) {
      // this.currentNode = data
      // this.classId = data.classId
      // this.getKeyWords()
    },
    clickDin: function() {
      // console.log(this.$refs.keyWordsMenu.setCheckedKeys())
      let fouyt = this.$refs.keyWordsMenu.getCheckedNodes()
      console.log(fouyt.length)
      if (fouyt.length != 0) {
        this.formRight.name = fouyt[0].name
        console.log(fouyt[0].name)
      } else {
        this.formRight.name = ''
      }
      this.handleChange()
      this.showTree = false
    },
    // 清空树
    resetChecked() {
      this.$refs.keyWordsMenu.setCheckedKeys([])
      this.formRight.regionName = ''
      this.formRight.region = ''
    },
    // 获取得到分类树
    getTreeMenu() {
      let _this = this
      this.axios
        .post(qualityUrl + '/scoreResult/seatGroups.do')
        .then(function(response) {
          _this.treeMenu = response.data
        })
        .catch(function(error) {
          console.log(error)
          _this.$message({
            type: 'error',
            message: '获取菜单出现问题',
          })
        })
    },
    handleChange: function() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.findTimer == null) {
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      } else {
        if (
          this.searchForm.findTimer[0] != undefined &&
          this.searchForm.findTimer[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.findTimer[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.findTimer[1] != undefined &&
          this.searchForm.findTimer[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.findTimer[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
        this.searchForm.findTimer = [fromTime, toTime]
      }
      let fouyt = this.$refs.keyWordsMenu.getCheckedKeys()
      let rwty = fouyt.toString()
      let params = {
        param: rwty,
        from: fromTime,
        to: toTime,
      }
      this.axios
        .post(qualityUrl + '/scoreResult/deadItem.do', Qs.stringify(params))
        .then((resp) => {
          let serieses = []
          let seriset = []
          serieses.push({
            type: 'pie',
            radius: ['60%', '75%'],
            center: ['45%', '45%'],
            hoverAnimation: false,
            legendHoverLink: false,
            label: {
              normal: {
                show: true,
                position: 'center',
                textStyle: {
                  fontSize: '18',
                  fontWeight: 'bold',
                },
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: '20',
                  fontWeight: 'bold',
                },
              },
            },
            startAngle: 300,
            data: [
              {
                name: '',
                value: resp.data.percent1,
              },
              {
                name:
                  resp.data.percent +
                  '%\n(' +
                  resp.data.deadItem +
                  ',' +
                  resp.data.count +
                  ')',
                value: resp.data.percent,
              },
            ],
          })
          this.prtion.series = serieses
          document.getElementById('mainpie').setAttribute('_echarts_instance_', '')
          let myChartset = this.$echarts.init(document.getElementById('mainpie'))
          myChartset.setOption(this.prtion)
          if (resp.data.keywords.length != 0) {
            this.mateLate = false
            $('#lineDraw').show()
            for (let i = 0; i < resp.data.data.length; i++) {
              seriset.push({
                name: resp.data.data[i].seats,
                type: 'bar',
                stack: 'sum',
                barCategoryGap: '50%',
                itemStyle: {
                  normal: {
                    color: '#A0A7E6',
                    barBorderColor: '#A0A7E6',
                    label: {
                      show: false,
                      position: 'right',
                      formatter: '',
                    },
                  },
                },
                data: resp.data.data[i].data,
              })
            }
            this.custom.yAxis.data = resp.data.keywords
            seriset.push({
              name: '总占比',
              type: 'bar',
              stack: 'sum',
              barCategoryGap: '50%',
              label: {
                normal: {
                  color: '#A0A7E6',
                  show: true,
                  barBorderColor: '#A0A7E6',
                  position: 'insideLeft',
                  formatter: '{c}%',
                  textStyle: {
                    color: '#000',
                  },
                },
              },
              itemStyle: {
                normal: {
                  color: 'rgba(128, 128, 128, 0)',
                },
              },
              data: resp.data.key,
            })
            this.custom.series = seriset
            document.getElementById('lineDraw').setAttribute('_echarts_instance_', '')
            let myChartout = this.$echarts.init(document.getElementById('lineDraw'))
            myChartout.setOption(this.custom)
          } else {
            this.mateLate = true
            $('#lineDraw').hide()
          }
        })
      this.axios
        .post(qualityUrl + '/scoreResult/distribution.do', Qs.stringify(params))
        .then((resp) => {
          console.log(resp)
          let series = []
          if (resp.data.length == 0) {
            series = []
          } else {
            for (let i = 0; i < resp.data.data.length; i++) {
              series.push({
                name: resp.data.data[i].seatName,
                type: 'bar',
                barWidth: 10,
                stack: '成绩',
                // itemStyle: {
                //   normal: {
                //     color: '#3398DB',
                //   },
                // },
                data: resp.data.data[i].data,
              })
            }
          }
          this.option.series = series
          this.option.xAxis.data = resp.data.xAxis
          document.getElementById('mainAminte').setAttribute('_echarts_instance_', '')
          let myChart = this.$echarts.init(document.getElementById('mainAminte'))
          // console.log(JSON.stringify(this.option))
          myChart.setOption(this.option)
          window.onresize = function(){
              myChart.resize();
          }
        })
      this.axios
        .post(qualityUrl + '/scoreResult/trend.do', Qs.stringify(params))
        .then((resp) => {
          let diaouop = []
          let legended = []
          if (resp.data.data.length == 0) {
            diaouop = []
          } else {
            for (let j = 0; j < resp.data.data.length; j++) {
              legended.push(resp.data.data[j].seatName)
            }
            for (let i = 0; i < resp.data.data.length; i++) {
              diaouop.push({
                name: resp.data.data[i].seatName,
                type: 'line',
                barWidth: 100,
                smooth: true,
                data: resp.data.data[i].score,
              })
            }
          }
          this.diaouyt.xAxis[0].data = resp.data.xAxis
          this.diaouyt.series = diaouop
          this.diaouyt.legend.data = legended
          document.getElementById('diagram').setAttribute('_echarts_instance_', '')
          let myChartAll = this.$echarts.init(document.getElementById('diagram'))
          myChartAll.setOption(this.diaouyt)
        })
    },
    // 跳转到录音播放页面
    jumpToSound: function(type, callId, recordFileURL) {
      let obj = {}
      obj.from = 'scoreResultInfo'
      obj.scoreResultRole = 'scoreResultZuZhang'
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlay')
      // 初始化play
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay', // 扩展样式
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // 将录音时长转换为秒
    dateFormatTwo(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.scoreInquery()
    },
    scoreInquery() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        score_Min: this.searchForm.score_Min,
        score_Max: this.searchForm.score_Max,
        objectId: this.searchForm.objectId,
        deadItem: this.searchForm.deadItem,
        callSTime_DLMin: fromTime,
        callSTime_DLMax: toTime,
        seatName: this.searchForm.seatName,
        state: 2,
      }
      this.axios
        .post(qualityUrl + '/scoreResult/queryScoreList.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            this.tableData = resp.data.Data.map((item) => {
              item.score = parseInt(Number(item.score))
              return item
            })
          } else {
            this.tableData = []
          }
          this.total = resp.data.Count
          this.searchForm.objectId = ''
          this.searchForm.seatName = ''
        })
    },
    exportExl() {
      let fromTime = ''
      let toTime = ''
      if (
        this.searchForm.callSTime[0] != undefined &&
        this.searchForm.callSTime[0] != ''
      ) {
        fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
      } else {
        // 默认获取当前月的第一天
        let now = new Date()
        now.setDate(1)
        now.setHours(0)
        now.setMinutes(0)
        now.setSeconds(0)
        fromTime = formatdate.formatDate(now)
      }
      if (
        this.searchForm.callSTime[1] != undefined &&
        this.searchForm.callSTime[1] != ''
      ) {
        toTime = formatdate.formatDate(this.searchForm.callSTime[1])
      } else {
        // 默认获取当前月的最后一天
        let now = new Date()
        let currentMonth = now.getMonth()
        let nextMonth = ++currentMonth
        let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
        let oneDay = 1000
        toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
      }
      this.searchForm.callSTime = [fromTime, toTime]
      if (this.selectedArr.length == 0) {
        this.$message({
          type: 'error',
          message: '请选中导出',
        })
        return
      }
      let objArrs = []
      for (let i = 0; i < this.selectedArr.length; i++) {
        objArrs.push(this.selectedArr[i].callId)
      }
      let objects = objArrs.join(',')
      window.location.href =
        qualityUrl +
        '/scoreResult/exportEx.do?objectIds=' +
        objects +
        '&accessToken=' +
        cache.getItem('tgt_id') +
        '&pageindex=' +
        this.currentPage +
        '&pagesize=' +
        this.pageSize +
        '&score_Min=' +
        this.searchForm.score_Min +
        '&score_Max=' +
        this.searchForm.score_Max +
        '&objectId=' +
        this.searchForm.objectId +
        '&deadItem=' +
        this.searchForm.deadItem +
        '&callSTime_DLMin=' +
        fromTime +
        '&callSTime_DLMax=' +
        toTime +
        '&seatName=' +
        this.searchForm.seatName
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.scoreInquery()
    },
    handleSelectionChange(val) {
      this.selectedArr = val
    },
  },
  directives: {
    'click-outside': {
      bind: function(el, binding, vNode) {
        // Provided expression must evaluate to a function.
        if (typeof binding.value !== 'function') {
          const compName = vNode.context.name
          let warn = `[Vue-click-outside:] provided expression '${
            binding.expression
          }' is not a function, but has to be`
          if (compName) {
            warn += `Found in component '${compName}'`
          }

          console.warn(warn)
        }
        // Define Handler and cache it on the element
        const bubble = binding.modifiers.bubble
        const handler = (e) => {
          if (bubble || (!el.contains(e.target) && el !== e.target)) {
            binding.value(e)
          }
        }
        el.__vueClickOutside__ = handler

        // add Event Listeners
        document.addEventListener('click', handler)
      },
      unbind: function(el, binding) {
        // Remove Event Listeners
        document.removeEventListener('click', el.__vueClickOutside__)
        el.__vueClickOutside__ = null
      },
    },
  },
  mounted: function() {
    this.scoreInquery()
    this.handleChange()
    this.getTreeMenu()
  },
  created() {
    this.recordPlayCloseHandler()
  },
}
</script>
<style lang="less" scoped="scoped">
.table {
  width: 100%;
  height: 100%;
  overflow: auto;
}
.content {
  padding-top: 12px;
  padding-bottom: 150px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
}
#soundfeature {
  box-sizing: border-box;
  height: 100%;
  width: 100%;
  .soundfeature-pos {
    width: 100%;
    height: 100%;
    position: relative;
  }
  .soundfeature-pos .soundfeature-pos-nav {
    width: 100%;
    height: 48px;
    line-height: 48px;
    background: #eef1f6;
    border-bottom: 1px solid #d1dbe4;
    border-top: 1px solid #d1dbe4;
    background: #ffffff;
  }
  .soundfeature-pos-nav ul {
    width: 100%;
    box-sizing: border-box;
  }
  .soundfeature-pos-nav ul li {
    float: left;
    padding: 0 16px;
    box-sizing: border-box;
    font-size: 14px;
    color: #96a2b2;
    cursor: pointer;
  }
  .soundfeatureActive {
    color: #21a2ff !important;
    border-bottom: 2px solid #21a2ff;
  }
  .soundfeature-pos .soundfeature-pos-content {
    padding: 20px 20px 0;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    overflow: hidden;
  }
  .moreChoice {
    line-height: 36px;
    text-decoration: underline;
    color: #20a0ff;
    cursor: pointer;
    font-size: 13px;
    margin-left: 4px;
  }
  .scoreinfo-page {
    width: 100%;
    height: 35px;
    position: absolute;
    background: white;
    left: 0;
    right: 0px;
    bottom: 0px;
    text-align: right;
    .el-pagination {
      display: inline-block;
      height: 28px;
      line-height: 28px;
      padding: 0px 10px;
    }
  }
}
.autoGrading-page {
  right: 10px;
  position: absolute;
  bottom: 10px;
}
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
.select-width {
  width: 200px;
  margin-top: 5px;
  &.hide {
    display: none;
  }
}
.contentLeft {
  width: 200px;
  top: 38px;
  right: 0;
  position: absolute;
  z-index: 3000;
  .treeMenu {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    .el-tree {
      max-height: 200px;
      min-height: 80px;
      overflow-y: auto;
      border: 1px solid #ccc;
    }
    .btns {
      width: 99%;
      height: 36px;
      border: 1px solid #ccc;
      border-top: 0;
      background: #fff;
      .el-button {
        float: right;
        width: 52px;
        height: 30px;
        margin-top: 2px;
        font-size: 12px;
        margin-right: 10px;
      }
    }
  }
}
</style>
<style lang="less">
#soundfeature {
  .contentButt .el-button {
    padding: 10px 0px;
  }
  .el-table--border th {
    background: #e5e9f2;
    padding: 10px 0;
  }
  .el-table thead {
    color: #475669;
  }
  .edealcell {
    .el-dialog__body {
      padding: 0;
    }
    .el-dialog__header {
      padding: 25px;
    }
    .speGivere .dealCenter .el-input__inner {
      width: 240px;
    }
  }
}
.el-dialog__wrapper.single {
  position: fixed;
  top: 106px;
  left: 20px;
  right: 20px;
  bottom: 12px;
  .el-dialog {
    width: 100%;
    height: 100%;
    margin: 0 !important;
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
}

.el-button.goback-btn {
  padding: 0;
  margin: 0;
  border: none;
  font-size: 14px;
  color: #20a0ff;
}
.cerall .el-form-item__content {
  margin-top: 3px;
}
</style>
