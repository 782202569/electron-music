<template>
  <div id="initialITask" class="initialITask">
    <el-row>
      <el-col :span="12" :class="hidden ? 'hidden' : ''">
        <div class="leftContent">
          <div class="searchHeader">
            <div style="float: right; margin-right: 10px">
              <el-button @click="resetForm('formInline')" style="width: 90px;"
                >清空</el-button
              >
              <el-button type="primary" @click="scoreInquery" style="width: 90px;"
                >查询</el-button
              >
            </div>
          </div>
          <div class="searchForm">
            <el-form
              :label-position="labelPosition"
              :inline="true"
              :model="formInline"
              ref="formInline"
              label-width="80px"
            >
              <p>订单属性</p>
              <div style="padding: 10px;">
                <el-form-item label="订单编号" prop="orderNo_Like">
                  <el-input
                    v-model="formInline.orderNo_Like"
                    placeholder="请输入内容"
                  ></el-input>
                </el-form-item>
                <el-form-item label="订单状态" prop="orderState">
                  <el-select
                    clearable
                    @change="changeStatus"
                    v-model="formInline.orderState"
                    placeholder="请选择"
                    style="width: 175px;"
                  >
                    <el-option
                      v-for="item in options5"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="下单时间" prop="orderTime">
                  <el-date-picker
                    @change="orderChange"
                    v-model="formInline.orderTime"
                    type="datetimerange"
                    placeholder="选择时间范围"
                    align="right"
                  >
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="质检结果" prop="score">
                  <el-input
                    v-model="formInline.score_Min"
                    placeholder="请输入内容"
                    style="width:100px"
                  ></el-input>
                  <el-input
                    v-model="formInline.score_Max"
                    placeholder="请输入内容"
                    style="width:100px"
                  ></el-input>
                </el-form-item>
                <el-form-item label="是否致命" prop="deadItem">
                  <el-select v-model="formInline.deadItem" placeholder="请输入内容">
                    <el-option value="1" label="是"></el-option>
                    <el-option value="2" label="否"></el-option>
                  </el-select>
                </el-form-item>
              </div>
            </el-form>
          </div>
        </div>
      </el-col>
      <el-col :span="rightSpan">
        <div class="rightContent">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="operation">
            <div class="btns" style="float: right; margin-right: 10px">
              <el-button @click="exportExl">导出</el-button>
              <el-button @click="queryTendChart" type="primary">查询趋势</el-button>
            </div>
          </div>
          <div class="tableBox">
            <div class="table" style="overflow: auto;padding:0px 10px;">
              <el-table
                :data="tableData"
                border
                highlight-current-row
                style="width: 100%"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"></el-table-column>
                <el-table-column fixed="left" prop="objectId" label="订单编号">
                  <template scope="scope">
                    <el-button
                      type="text"
                      @click="
                        showDetail(
                          scope.row.objectId,
                          scope.row.submiterName,
                          scope.row.submiter
                        )
                      "
                      >{{ scope.row.objectId }}</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="orderTime"
                  :formatter="dateFormat"
                  label="下单时间"
                >
                </el-table-column>
                <el-table-column prop="orderState" label="订单状态">
                  <template scope="scope">
                    <div v-if="scope.row.orderState === '1'">
                      <el-tag type="success">成功单</el-tag>
                    </div>
                    <div v-else="">
                      <el-tag type="primary">取消单</el-tag>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column prop="submiterName" label="提交人姓名">
                </el-table-column>
                <el-table-column prop="seatGroup" label="提交人坐席组"> </el-table-column>
                <el-table-column prop="score" label="质检分数"> </el-table-column>
                <el-table-column sortable prop="deadItem" label="是否致命">
                  <template scope="scope">
                    <el-tag close-transition v-if="scope.row.orderState == '2'"
                      >非致命</el-tag
                    >
                    <el-tag close-transition v-if="scope.row.orderState == '1'"
                      >致命</el-tag
                    >
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="page">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="pageindex"
                :page-sizes="[20, 30, 40]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
    <el-dialog
      id="lookAreaDialog"
      title="得分趋势图"
      :close-on-click-modal="false"
      :visible.sync="lookAreaDialogVisible"
      @close="destoryValue()"
    >
      <div style="display: flex;flex-direction: column;">
        <div class="chartCondition">
          <el-form :inline="true" style="float: right">
            <el-form-item>
              <el-col :span="11">
                <el-date-picker
                  type="date"
                  format="yyyy-MM-dd"
                  :value-format="'yyyy-MM-dd'"
                  placeholder="选择日期"
                  v-model="stsSearchForm.startTime"
                  style="width: 100%;"
                ></el-date-picker>
              </el-col>
              <el-col class="line" :span="2">-</el-col>
              <el-col :span="11">
                <el-date-picker
                  value-format="yyyy-MM-dd"
                  type="date"
                  placeholder="选择日期"
                  v-model="stsSearchForm.endTime"
                  style="width: 100%;"
                ></el-date-picker>
              </el-col>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="search">查询</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div id="area_container" style="width: 100%; height: 600px;">
          <p>
            暂无数据
          </p>
        </div>
      </div>
    </el-dialog>
    <el-dialog
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      class="recordingplay"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import axios from 'axios'
import Qs from 'qs'
import global from '../../../global.js'
import vPlayer from '../../common/player.vue'
import recordingplay from '../recordingPlayOrder/recordingPlayOrder.vue'
import bus from '../../common/bus.js'
axios.defaults.withCredentials = true
axios.defaults.headers = {
  'Content-Type': 'application/x-www-form-urlencoded ;charset=UTF-8',
}
let qualityUrl = global.qualityUrl
import formatdate from '../../../utils/formatdate.js'
let pageConstantUrl = qualityUrl + '/pageConstant/getValue.do?keys=seatGroup'
let myChart
export default {
  components: {
    vPlayer,
    recordingplay,
  },
  data() {
    return {
      lookAreaDialogVisible: false,
      selectedArr: [],
      labelPosition: 'right',
      recordDialogVisible: false,
      hidden: false, // 左侧部分是否隐藏
      stsSearchForm: {
        startTime: '',
        endTime: '',
      },
      options5: [
        {
          value: 1,
          label: '成功单',
        },
        {
          value: 2,
          label: '取消单',
        },
      ],
      tableData: [],
      seatGroupList: [], // 坐席组
      formInline: {
        submiter: '', // 坐席编号
        orderTime: '', // 下单时间
        deadItem: '2',
        endTime_Min: '',
        orderNo_Like: '',
        orderState: '',
        submiterName: '',
        taskType: '',
        score_Min: '',
        score_Max: '',
      },
      pageindex: 1,
      pagesize: 20,
      totalCount: 0,
      selection: '',
      qaUser: '',
      fromDate: '',
      toDate: '',
      chartOption: {
        title: {
          text: '',
        },
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: [],
        },
        grid: {
          left: '3%',
          right: '8%',
          bottom: '3%',
          containLabel: true,
        },
        toolbox: {
          feature: {
            saveAsImage: {},
          },
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: [],
          axisLabel: {
            interval: 0,
          },
        },
        yAxis: {
          type: 'value',
        },
        series: [
          {
            name: '',
            type: 'line',
            stack: '总量',
            data: [],
          },
        ],
      },
    }
  },
  computed: {
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
    recordingPlayPage() {
      return this.$store.state.recordingPlayPage
    },
  },
  methods: {
    scoreInquery() {
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        score_Min: this.formInline.score_Min,
        score_Max: this.formInline.score_Max,
        objectId: this.formInline.orderNo_Like,
        deadItem: this.formInline.deadItem,
        orderTime_Min: this.oStartDate,
        orderTime_Max: this.oEndDate,
      }
      this.axios
        .post(qualityUrl + '/OrderScoreResult/getList.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            this.tableData = resp.data.Data
          } else {
            this.tableData = []
          }
          this.total = resp.data.Count
        })
    },
    search() {
      if (this.stsSearchForm.startTime == '') {
        return
      }
      const self = this
      let start = formatdate.formatDate(this.stsSearchForm.startTime)
      let end = formatdate.formatDate(this.stsSearchForm.endTime)
      let params = {
        fromDate: start,
        toDate: end,
      }
      this.axios
        .post(qualityUrl + '/OrderScoreResult/stsQaedScore.do', Qs.stringify(params))
        .then(function(resp) {
          if (resp.data.flag) {
            self.chartOption.legend.data = resp.data.lines
            self.chartOption.xAxis.data = resp.data.xzh
            let seriResult = resp.data.yzh
            let series = []
            for (let i = 0; i < seriResult.length; i++) {
              series.push({
                name: seriResult[i].line,
                type: 'line',
                smooth: seriResult[i].smooth,
                itemStyle: {
                  normal: {
                    lineStyle: {
                      type:
                        seriResult[i].smooth != null && seriResult[i].smooth == false
                          ? 'dotted'
                          : 'solid',
                    },
                  },
                }, // stack: '总量',
                data: seriResult[i].data,
              })
            }
            self.chartOption.series = series
            myChart = self.$echarts.init(document.getElementById('area_container'))
            myChart.setOption(self.chartOption)
          }
        })
    },
    destoryValue() {
      myChart.dispose()
    },
    queryTendChart() {
      this.lookAreaDialogVisible = true
      this.stsSearchForm.startTime = ''
      this.stsSearchForm.endTime = ''
    },
    exportExl() {
      if (this.selectedArr.length == 0) {
        this.$message({
          type: 'error',
          message: '请选中导出',
        })
        return
      }
      let objArrs = []
      for (let i = 0; i < this.selectedArr.length; i++) {
        objArrs.push(this.selectedArr[i].objectId)
      }
      let objects = objArrs.join(',')
      window.location.href =
        qualityUrl +
        'qualityInspectionSystem/OrderScoreResult/exportEx.do?objectIds=' +
        objects
    },
    toggleContainer() {
      this.hidden = !this.hidden
    },
    showDetail(id, submiterName, submiter) {
      let obj = {}
      // obj.from = 'scoreResultInfoOrder'  // 从我的质检任务的第一个tab页来
      obj.pageId = 'scoreResultInfoOrder'
      obj.orderNo = id
      obj.submiterName = submiterName
      obj.submiter = submiter
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlayOrder')
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay',
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 关闭录音弹窗
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    // 录音播放页面 点击最小化触发
    toMinDialog: function(playInfo) {
      if (playInfo.isMaximization === false) {
        this.showVplayer = false
        let play = {}
        play.isMaximization = false
        play.exist = true
        this.$store.commit('setPlayerInfo', play)
      }
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    resetForm() {
      this.$refs.formInline.resetFields()
      this.formInline.score_Max = ''
      this.formInline.score_Min = ''
    },
    /**
     * 每页条数
     * **/
    handleSizeChange(val) {
      this.pagesize = val
      this.pageindex = 1
      this.scoreInquery()
    },
    /**
     *当前页数
     * */
    handleCurrentChange(val) {
      this.pageindex = val
      this.scoreInquery()
    },
    handleSelectionChange(val) {
      console.log(val)
      this.selectedArr = val
    },
    /**
     *时间戳
     * **/
    dateFormat: function(row, column) {
      let date = row[column.property]
      let fdate = formatdate.formatDate(date)
      if (date == undefined) {
        return ''
      }
      return fdate
    },
    // 将录音时长转换为秒
    dateFormatTwo(x, y, callTime) {
      let needConvert = callTime && callTime != 'null'
      return (needConvert ? (parseFloat(callTime) / 1000).toFixed(2) : '') + '秒'
    },
    change: function(val) {
      this.formInline.taskStatus = val
    },
    changeType: function(val) {
      this.formInline.taskType = val
    },
    changeData: function(val) {
      this.formInline.callSDate = val
    },
    changeStatus: function(val) {
      this.formInline.orderState = val
    },
    getSeatGroupList: function() {
      let self = this
      this.axios.post(pageConstantUrl).then(function(response) {
        self['seatGroupList'] = response.data.seatGroup
      })
    },
    // 下单时间
    orderChange: function(val) {
      let fdata = val.substring(0, 19)
      let edata = val.substring(22, 41)
      this.oStartDate = fdata
      this.oEndDate = edata
    },
    changeTime: function(val) {
      this.formInline.callETime = val
      if (this.formInline.callETime < this.formInline.callSDate) {
        this.$message({
          type: 'warning',
          message: '结束时间要大于开始时间',
        })
      }
    },
  },
  mounted: function() {
    this.scoreInquery()
    // this.getSeatGroup()
  },
  created() {
    this.recordPlayCloseHandler()
  },
}
</script>
<style scoped="scoped" lang="less">
@border-color: #d1dbe5;
.recordingplayWrap {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  position: relative;
}
.initialITask {
  .rightContent {
    height: 100%;
    width: 100%;
    box-sizing: border-box;
    position: relative;
    .operation .btns {
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      padding: 0px 10px 0px 0px;
      border-bottom: 1px dashed @border-color;
      // position:absolute;
      // top:0px;
      // left:10px;
      // right: 10px;
      // .el-button:last-child {
      //   padding-left: 10px;
      // }
      // .el-radio-group:first-child {
      //   margin-right: 10px;
      // }
    }
    .tableBox {
      padding-top: 8px;
      padding-bottom: 80px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      .table {
        width: 100%;
        height: 100%;
      }
      .page {
        right: 10px;
        position: absolute;
        bottom: 10px;
      }
    }
  }
  .toggle-show {
    position: absolute;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggleBtn {
    cursor: pointer;
    width: 20px;
    height: 30px;
    background-image: url('../../../assets/img/close.png');
    position: absolute;
    left: -20px;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggle-hidden {
    left: 0px;
    transform: rotate(180deg);
  }
  .leftContent {
    height: 100%;
    overflow: auto;
    left: 0px;
    top: 0px;
    position: relative;
    border-right: 1px solid #d1dbe5;
    .searchHeader {
      border-bottom: 1px dashed #d1dbe5;
      position: absolute;
      box-sizing: border-box;
      height: 60px;
      line-height: 60px;
      position: absolute;
      top: 0px;
      left: 0px;
      width: 100%;
    }
    .searchForm {
      position: absolute;
      top: 65px;
      left: 0px;
      bottom: 0px;
      overflow: auto;
      width: 100%;
      cursor: pointer;
      p {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        font-weight: bold;
        color: #9dadc2;
      }
    }
  }
  .el-row {
    height: 100%;
    .el-col {
      height: 100%;
    }
  }
}
#initialITask div {
  box-sizing: border-box;
}
#initialITask {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
}
</style>
<style>
#initialITask .el-dialog--small {
  width: 65% !important;
}
#initialITask .hidden {
  display: none;
}
</style>
