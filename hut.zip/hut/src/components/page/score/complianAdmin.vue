<template>
  <div id="soundfeature">
    <div class="conpalinDiv edealFind">
      <div class="caseHeader">
        申诉管理
      </div>
      <div class="complianContent">
        <ul>
          <li
            data-id="1"
            @click="toggleSound"
            class="soundfeatureActive"
            style="margin-left:5px;"
          >
            未处理
          </li>
          <li data-id="2" @click="toggleSoundtwo">已处理</li>
        </ul>
      </div>
      <div class="changeCondtion">
        <el-form :inline="true">
          <el-form-item style="float: right;margin-right: 0px;">
            <el-date-picker
              v-model="searchForm.callSTime"
              type="datetimerange"
              :clearable="false"
              :editable="false"
              align="right"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :default-time="['00:00:00', '23:59:59']"
              style="width: 375px;padding: 1px 10px;"
            >
            </el-date-picker>
            <el-button
              @click="scoreInquery"
              v-show="untrendSize"
              type="primary"
              style="margin-left: 7px;margin-right: 20px;"
              >查询
            </el-button>
            <el-button
              @click="secherInquery"
              v-show="!untrendSize"
              type="primary"
              style="margin-left: 7px;margin-right: 20px;"
              >查询
            </el-button>
          </el-form-item>
        </el-form>
      </div>
      <div class="content" v-show="untrendSize">
        <div class="table">
          <div style="padding: 0 16px 80px 19px;">
            <el-table
              :data="tableData"
              border
              ref="multipleTable"
              tootip-effect="dark"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="callId" label="录音编号">
                <template scope="scope">
                  <el-button
                    type="text"
                    @click="
                      jumpToSound(
                        1,
                        scope.row.callId,
                        scope.row.apStatus,
                        scope.row.appealId,
                        scope.row.procTaskId,
                        scope.row.qaScoreType,
                        scope.row.recordFileURL
                      )
                    "
                  >
                    {{ scope.row.callId }}
                  </el-button>
                </template>
              </el-table-column>
              <el-table-column prop="seatName" label="申诉坐席" width="100">
              </el-table-column>
              <el-table-column prop="seatGroup" label="坐席组"> </el-table-column>
              <el-table-column
                prop="apTime"
                sortable
                :formatter="exeTimeFilter"
                label="提交时间"
                width="170"
              >
              </el-table-column>
              <el-table-column prop="score" sortable label="质检成绩" width="130">
              </el-table-column>
              <el-table-column prop="comments" label="申诉原因"> </el-table-column>
              <el-table-column prop="apStatus" label="申诉状态" width="180">
                <template scope="scope">
                  <span v-if="scope.row.apStatus === 1 || scope.row.apStatus === 2">
                    一次申诉待审批
                  </span>
                  <span v-else-if="scope.row.apStatus === 6">
                    二次申诉待审批
                  </span>
                  <el-popover placement="left" trigger="hover">
                    <slot name="reference">
                      <div class="detailnewMcen" id="notTable">
                        <div class="detailsNew">
                          <div
                            v-for="(item, index) in scope.row.AppDetail"
                            :key="index"
                            style="width: 100%;"
                            v-if="index < scope.row.AppDetail.length - 1"
                          >
                            <div>
                              <div
                                style="height:10px;width:10px;float:left;background: #BFCBD9;display: inline-block;border-radius: 50%"
                              ></div>
                              <div
                                style="padding-left: 30px;margin-left: 5px;border-left: 1px solid #BFCBD9;"
                              >
                                {{ item.actDesc }}
                              </div>
                            </div>
                            <div style="margin-left: 5px;border-left: 1px solid #BFCBD9;">
                              <div style="padding-left: 30px;">
                                理由：{{ item.actReson }}
                              </div>
                            </div>
                            <div
                              class=""
                              style="margin-left: 5px;border-left: 1px solid #BFCBD9;"
                            >
                              <div style="padding-left: 30px;padding-bottom: 30px;">
                                {{ formatDate(item.actTime) }}
                              </div>
                            </div>
                          </div>
                          <div
                            v-for="(item, index) in scope.row.AppDetail"
                            :key="index"
                            style="width: 100%;"
                            v-if="index == scope.row.AppDetail.length - 1"
                          >
                            <div>
                              <div
                                style="height:10px;width:10px;float:left;background: #20A0FF;display: inline-block;border-radius: 50%"
                              ></div>
                              <div style="padding-left: 30px;margin-left: 5px;">
                                {{ item.actDesc }}
                              </div>
                            </div>
                            <div style="margin-left: 5px;">
                              <div style="padding-left: 30px;">
                                理由：{{ item.actReson }}
                              </div>
                            </div>
                            <div class="" style="margin-left: 5px;">
                              <div style="padding-left: 30px;padding-bottom: 30px;">
                                {{ formatDate(item.actTime) }}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </slot>
                    <span slot="reference" class="yuan">i</span>
                  </el-popover>
                </template>
              </el-table-column>
              <el-table-column label="操作" width="180">
                <template scope="scope">
                  <div class="operation">
                    <i class="opeatLeft"
                      ><i
                        funcId="000350"
                        style="color: #20A0FF;cursor: pointer;margin-right: 5px"
                        @click="
                          jumpToSound(
                            1,
                            scope.row.callId,
                            scope.row.apStatus,
                            scope.row.appealId,
                            scope.row.procTaskId,
                            scope.row.qaScoreType,
                            scope.row.recordFileURL
                          )
                        "
                        >审批</i
                      ></i
                    >
                    <i class="opeatLeft" v-if="scope.row.isFuyi == 1"
                      ><i
                        funcId="000351"
                        style="color: #20A0FF;cursor: pointer;margin-right: 5px"
                        @click="checkClik(scope.row.appealId, scope.row.assignType)"
                        >查看分发({{ scope.row.RNum }}/{{ scope.row.DNum }})</i
                      ></i
                    >
                    <i class="opeatLeft" v-if="scope.row.isFuyi == 0"
                      ><i
                        funcId="000352"
                        style="color: #20A0FF;cursor: pointer;"
                        @click="
                          approveClik(
                            scope.row.appealId,
                            scope.row.procTaskId,
                            scope.row.assignType
                          )
                        "
                        >分发任务</i
                      ></i
                    >
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="autoGrading-page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
      <el-dialog
        class="giveRecive firstPeople"
        :visible.sync="setInput"
        width="520px"
        title="分发任务"
        :close-on-click-modal="false"
      >
        <div class="dealCenter">
          <el-form label-width="100px" ref="fourForm">
            <el-form-item label="选择质检员" prop="people">
              <el-select
                @change="confirmAdd"
                v-model="distributeInspectorModel.people"
                multiple
                placeholder="请选择质检员"
                style="margin-bottom: 44px;"
              >
                <el-option
                  v-for="item in people"
                  :value="item.account"
                  :label="item.realName"
                  :key="item.account"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
        </div>
        <div
          class="footerAll"
          style="width: 100%;border-top: 1px solid #E0E6ED;margin-top: 30px;height: 68px;"
        >
          <div class="footInside" style="float: right;height: 53px;padding-top: 15px">
            <el-button @click="notChange">取 消</el-button>
            <el-button @click="complainNext" :disabled="submitDisable" type="primary" style="margin-right: 18px;"
              >提 交</el-button
            >
          </div>
        </div>
      </el-dialog>
      <el-dialog
        class="giveRecive secondPeople"
        :visible.sync="checkContent"
        width="620px"
        title="查看分发"
        :close-on-click-modal="false"
      >
        <div style="margin: 10px 20px;">
          <div style="display: inline-block;">
            目前共{{ listLength }}个质检员参与, 合计: 评分无误/评分有误 ({{
              numberFirst
            }}/{{ numberSecond }})
          </div>
          <div
            class="finalyNext"
            style="display: inline-block;width: 200px;margin-left: 30px;"
            v-show="untrendSize"
          >
            <el-select
              ref="mySelect"
              @change="copyPeople"
              v-model="distributeInspectorModel.peopleOne"
              multiple
              placeholder="分发更多质检员"
            >
              <el-option
                v-for="item in peopleOne"
                :value="item.account"
                :label="item.realName"
                :key="item.account"
                :disabled="item.disabled"
              >
              </el-option>
              <div
                style="text-align: right;padding-right: 10px;border-top: 1px solid #D3DCE6;"
              >
                <el-button @click="cahngList" style="padding: 8px;margin-top: 10px;"
                  >确定分发</el-button
                >
              </div>
            </el-select>
          </div>
        </div>
        <div id="tableFindset" style="margin: 0 15px;">
          <el-table :data="tableDataswer" style="width: 100%">
            <el-table-column prop="responseQauser" label="复议人"> </el-table-column>
            <el-table-column prop="responseResult" label="复议结果">
              <template scope="scope">
                <i v-if="scope.row.responseResult == 1">评分有误</i>
                <i v-if="scope.row.responseResult == 2">评分无误</i>
              </template>
            </el-table-column>
            <el-table-column prop="responseContent" label="评分说明"> </el-table-column>
            <el-table-column prop="responseScore" label="评定成绩"> </el-table-column>
          </el-table>
        </div>
        <div
          class="footerAll"
          style="width: 100%;height: 68px;border-top: 1px solid #E0E6ED;margin-top: 10px;"
        >
          <div class="footInside" style="float: right; height: 53px;padding-top: 15px">
            <el-button @click="notChange">取 消</el-button>
            <el-button @click="yesChange" type="primary" style="margin-right: 18px;"
              >确 定</el-button
            >
          </div>
        </div>
      </el-dialog>
      <div class="content" v-show="!untrendSize">
        <div class="table">
          <div style="padding: 0 16px 80px 19px;">
            <el-table
              :data="tableSearch"
              border
              ref="multipleTable"
              tootip-effect="dark"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="callId" label="录音编号">
                <template scope="scope">
                  <el-button
                    type="text"
                    @click="
                      jumpToSound(
                        1,
                        scope.row.callId,
                        scope.row.apStatus,
                        scope.row.appealId,
                        scope.row.procTaskId,
                        scope.row.qaScoreType,
                        scope.row.qaScoreType,
                        scope.row.recordFileURL
                      )
                    "
                  >
                    {{ scope.row.callId }}
                  </el-button>
                </template>
              </el-table-column>
              <el-table-column prop="seatName" label="申诉坐席" width="150">
              </el-table-column>
              <el-table-column prop="seatGroup" label="坐席组"> </el-table-column>
              <el-table-column
                prop="apTime"
                sortable
                :formatter="exeTimeFilter"
                label="提交时间"
              >
              </el-table-column>
              <el-table-column prop="score" sortable label="质检结果"> </el-table-column>
              <el-table-column prop="comments" label="申诉原因"> </el-table-column>
              <el-table-column prop="passState" label="申诉状态" width="180">
                <template scope="scope">
                  <span v-if="scope.row.passState === 2">
                    一次申诉已通过
                  </span>
                  <span v-else-if="scope.row.passState === 1">
                    一次申诉已驳回
                  </span>
                  <span v-else-if="scope.row.passState === 4">
                    二次申诉已通过
                  </span>
                  <span v-else-if="scope.row.passState === 3">
                    二次申诉已驳回
                  </span>
                  <!-- <span v-else-if="scope.row.passState === 13">
                    本人已确认
                  </span>
                  <span v-else-if="scope.row.passState === 14">
                    系统自动确认
                  </span> -->
                  <el-popover placement="left" trigger="hover">
                    <slot name="reference">
                      <div class="detailnewMcen" id="notTable">
                        <div class="detailsNew">
                          <div
                            v-for="(item, index) in scope.row.AppDetail"
                            :key="index"
                            style="width: 100%;"
                            v-if="index < scope.row.AppDetail.length - 1"
                          >
                            <div>
                              <div
                                style="height:10px;width:10px;float:left;background: #BFCBD9;display: inline-block;border-radius: 50%"
                              ></div>
                              <div
                                style="padding-left: 30px;margin-left: 5px;border-left: 1px solid #BFCBD9;"
                              >
                                {{ item.actDesc }}
                              </div>
                            </div>
                            <div style="margin-left: 5px;border-left: 1px solid #BFCBD9;">
                              <div style="padding-left: 30px;">
                                理由：{{ item.actReson }}
                              </div>
                            </div>
                            <div
                              class=""
                              style="margin-left: 5px;border-left: 1px solid #BFCBD9;"
                            >
                              <div style="padding-left: 30px;padding-bottom: 30px;">
                                {{ formatDate(item.actTime) }}
                              </div>
                            </div>
                          </div>
                          <div
                            v-for="(item, index) in scope.row.AppDetail"
                            :key="index"
                            style="width: 100%;"
                            v-if="index == scope.row.AppDetail.length - 1"
                          >
                            <div>
                              <div
                                style="height:10px;width:10px;float:left;background: #20A0FF;display: inline-block;border-radius: 50%"
                              ></div>
                              <div style="padding-left: 30px;margin-left: 5px;">
                                {{ item.actDesc }}
                              </div>
                            </div>
                            <div style="margin-left: 5px;">
                              <div style="padding-left: 30px;">
                                理由：{{ item.actReson }}
                              </div>
                            </div>
                            <div class="" style="margin-left: 5px;">
                              <div style="padding-left: 30px;padding-bottom: 30px;">
                                {{ formatDate(item.actTime) }}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </slot>
                    <span slot="reference" class="yuan">i</span>
                  </el-popover>
                </template>
              </el-table-column>
              <el-table-column label="操作" width="180">
                <template scope="scope">
                  <div class="operation">
                    <i class="opeatLeft"
                      ><i
                        funcId="000066"
                        style="color: #20A0FF;cursor: pointer;"
                        @click="checkClik(scope.row.appealId, scope.row.assignType)"
                        >查看分发({{ scope.row.RNum }}/{{ scope.row.DNum }})</i
                      ></i
                    >
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="autoGrading-page">
          <el-pagination
            @size-change="handleSizeChangeone"
            @current-change="handleCurrentChangeone"
            :current-page="currentPageone"
            :page-sizes="pageSizesone"
            :page-size="pageSizeone"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalone"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import global from '@/global'
import $ from 'jquery'
import formatdate from '../../../utils/formatdate.js'
import funcFilter from '@/utils/funcFilter.js'
import Qs from 'qs'
import recordingplay from '../recordingPlay/recordingPlayShenSu.vue'
import bus from '../../common/bus.js'
import moment from 'moment'
let qualityUrl = global.qualityUrl
export default {
  components: {
    recordingplay,
  },
  data() {
    return {
      submitDisable: false,
      searchForm: {
        callSTime: [],
        byReson: '',
      },
      distributeInspectorModel: {
        people: [],
        peopleOne: [],
      },
      people: [],
      peopleOne: [],
      tableData: [],
      tableSearch: [],
      tableDataswer: [],
      setInput: false,
      checkContent: false,
      untrendSize: true,
      numberSecond: '',
      numberFirst: '',
      listLength: '0',
      setIds: '',
      notIds: '',
      checkLook: '',
      cellLook: '',
      appealcel: '',
      currentPage: 1,
      currentPageone: 1,
      pageSizes: [10, 20, 30, 40],
      pageSize: 20,
      total: 0,
      pageSizesone: [10, 20, 30, 40],
      pageSizeone: 20,
      totalone: 0,
      recordDialogVisible: false,
      tabIndex: 2,
    }
  },
  methods: {
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      let obj = {}
      obj.shensuTabIndex = this.tabIndex
      this.$store.commit('setRecordingPlayPage', obj)
      this.scoreInquery()
      this.secherInquery()
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    toggleSound(event) {
      // 首页头部切换
      $('.complianContent ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
      this.untrendSize = true
      let obj = {}
      obj.shensuTabIndex = 2
      this.tabIndex = 2
      this.$store.commit('setRecordingPlayPage', obj)
    },
    toggleSoundtwo(event) {
      // 首页头部切换
      this.untrendSize = false
      $('.complianContent ul li').removeClass('soundfeatureActive')
      $(event.target).addClass('soundfeatureActive')
      let obj = {}
      obj.shensuTabIndex = 1
      this.tabIndex = 1
      this.$store.commit('setRecordingPlayPage', obj)
      // 没有数据就请求
      if (!this.tableSearch.length) {
        this.secherInquery()
      }
    },
    notChange: function() {
      this.setInput = false
      this.checkContent = false
    },
    yesChange: function() {
      this.checkContent = false
      this.scoreInquery()
    },
    formatDate(obj) {
      let date = new Date(obj)
      let y = 1900 + date.getYear()
      let m = '0' + (date.getMonth() + 1)
      let d = '0' + date.getDate()
      let h = '0' + date.getHours()
      let f = '0' + date.getMinutes()
      let s = '0' + date.getSeconds()
      return (
        y +
        '-' +
        m.substring(m.length - 2, m.length) +
        '-' +
        d.substring(d.length - 2, d.length) +
        ' ' +
        h.substring(h.length - 2, h.length) +
        ':' +
        f.substring(f.length - 2, f.length) +
        ':' +
        s.substring(s.length - 2, s.length)
      )
    },
    checkClik: function(index, flag) {
      this.checkContent = true
      this.checkLook = index
      this.cellLook = flag
      this.distributeInspectorModel.peopleOne = []
      $('.el-select__tags')
        .children('span')
        .remove()
      let params = {
        assignType: flag,
        appealId: index,
      }
      this.axios
        .post(qualityUrl + '/appealsProcess/toFuYiResultView.do', Qs.stringify(params))
        .then((resp) => {
          console.log(resp.data)
          this.tableDataswer = resp.data.listResults
          this.listLength = resp.data.listResults.length
          this.numberFirst = resp.data.gradeDuiSum
          this.numberSecond = resp.data.gradeCuoSum
        })
      let paramsValue = {
        assignType: flag,
        appealId: index,
      }
      this.axios
        .post(
          qualityUrl + '/appealsProcess/getFuYiTaskQaUser.do',
          Qs.stringify(paramsValue)
        )
        .then((resp) => {
          this.peopleOne = resp.data.listivdOper
        })
        .catch(function() {
          this.$message({
            type: 'error',
            message: '请求失败',
          })
        })
    },
    complainNext: function() {
      this.submitDisable = true
      let valueSuzu = this.distributeInspectorModel.people
      let rwty = valueSuzu.toString()
      if (rwty == '') {
        this.$message({
          type: 'error',
          message: '请选择质检员',
        })
      } else {
        let params = {
          assignType: this.appealcel,
          appealId: this.setIds,
          qaUserArray: rwty,
        }
        this.axios
          .post(qualityUrl + '/appealsProcess/fuyiTaskToQaUser.do', Qs.stringify(params))
          .then((resp) => {
            console.log(resp.data)
            if (resp.data) {
              this.scoreInquery()
              this.setInput = false
              this.$message({
                type: 'success',
                message: '分发成功',
              })
            } else {
              this.$message({
                type: 'error',
                message: '分发失败',
              })
                this.submitDisable = false
            }
          })
          .catch(() => {
            this.$message({
              type: 'error',
              message: '分发失败',
            })
            this.submitDisable = false
          })
      }
    },
    confirmAdd() {
      $('.firstPeople .el-select__tags')
        .children('span')
        .remove()
      if (this.distributeInspectorModel.people.length >= 1) {
        $('.el-select__tags').append(
          '<span class="playuer">已选择' +
            this.distributeInspectorModel.people.length +
            '人</span>'
        )
      }
    },
    copyPeople: function() {
      $('.secondPeople .el-select__tags')
        .children('span')
        .remove()
      if (this.distributeInspectorModel.peopleOne.length >= 1) {
        $('.el-select__tags').append(
          '<span class="playuer">已选择' +
            this.distributeInspectorModel.peopleOne.length +
            '人</span>'
        )
      }
    },
    cahngList: function() {
      let valueSuzu = this.distributeInspectorModel.peopleOne
      let rwty = valueSuzu.toString()
      if (rwty == '') {
        this.$message({
          type: 'error',
          message: '请选择质检员',
        })
        this.$refs.mySelect.handleClose()
      } else {
        let params = {
          assignType: this.cellLook,
          appealId: this.checkLook,
          qaUserArray: rwty,
        }
        this.axios
          .post(qualityUrl + '/appealsProcess/fuyiTaskToQaUser.do', Qs.stringify(params))
          .then((resp) => {
            console.log(resp.data)
            if (resp.data) {
              this.checkClik(this.checkLook, this.cellLook)
              this.$refs.mySelect.handleClose()
            } else {
              this.$message({
                type: 'error',
                message: '分发失败',
              })
            }
          })
          .catch(function() {
            this.$message({
              type: 'error',
              message: '分发失败',
            })
          })
      }
    },
    scoreInquery() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        apTime_Min: fromTime,
        apTime_Max: toTime,
      }
      this.axios
        .post(qualityUrl + '/appealsProcess/zgGetUnApproveList.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            let result = resp.data.Data
            this.tableData = result.map((item) => {
              item.score = parseInt(Number(item.score))
              return item
            })
            this.filterButton() // 过滤权限按钮
          } else {
            this.tableData = []
          }
          this.total = resp.data.Count
        })
    },
    secherInquery() {
      let fromTime = ''
      let toTime = ''
      if (this.searchForm.callSTime == null) {
        this.fromTime = ''
        this.toTime = ''
      } else {
        if (
          this.searchForm.callSTime[0] != undefined &&
          this.searchForm.callSTime[0] != ''
        ) {
          fromTime = formatdate.formatDate(this.searchForm.callSTime[0])
        } else {
          // 默认获取当前月的第一天
          let now = new Date()
          now.setDate(1)
          now.setHours(0)
          now.setMinutes(0)
          now.setSeconds(0)
          fromTime = formatdate.formatDate(now)
        }
        if (
          this.searchForm.callSTime[1] != undefined &&
          this.searchForm.callSTime[1] != ''
        ) {
          toTime = formatdate.formatDate(this.searchForm.callSTime[1])
        } else {
          // 默认获取当前月的最后一天
          let now = new Date()
          let currentMonth = now.getMonth()
          let nextMonth = ++currentMonth
          let nextMonthFirstDay = new Date(now.getFullYear(), nextMonth, 1)
          let oneDay = 1000
          toTime = formatdate.formatDate(new Date(nextMonthFirstDay - oneDay))
        }
      }
      this.searchForm.callSTime = [fromTime, toTime]
      let params = {
        pageindex: this.currentPage,
        pagesize: this.pageSize,
        apTime_Min: fromTime,
        apTime_Max: toTime,
      }
      this.axios
        .post(qualityUrl + '/appealsProcess/zgGetApprovedList.do', Qs.stringify(params))
        .then((resp) => {
          if (resp.data.Count) {
            let result = resp.data.Data
            this.tableSearch = result.map((item) => {
              item.score = parseInt(Number(item.score))
              return item
            })
            this.filterButton() // 权限按钮过滤
          } else {
            this.tableSearch = []
          }
          this.totalone = resp.data.Count
        })
    },
    handleSelectionChange(val) {
      console.log(val)
      this.selectedArr = val
    },
    // 跳转到录音播放页面
    jumpToSound: function(type, callId, apStatus, appealId, procTaskId, qaScoreType,recordFileURL) {
      let obj = {}
      obj.from = 'scoreResultInfo'
      obj.scoreResultRole = 'scoreResultZhuGuan'
      obj.appealStatus = apStatus
      obj.callId = callId
      obj.recordFileURL = recordFileURL
      obj.qaScoreType = qaScoreType
      obj.appealId = appealId
      obj.procTaskId = procTaskId // 申诉打分所需
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push('/recordingPlay')
      // 初始化play
      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay', // 扩展样式
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
    // 将录音时长转换为秒
    exeTimeFilter(row, column, cellValue) {
      if (cellValue) {
        return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
      }
    },
    approveClik: function(index, flag, finaly) {
      this.setIds = index
      this.notIds = flag
      this.appealcel = finaly
      this.setInput = true
      this.submitDisable = false
      this.searchForm.byReson = ''
      this.distributeInspectorModel.people = []
      $('.el-select__tags')
        .children('span')
        .remove()
      let params = {
        assignType: finaly,
        appealId: index,
      }
      this.axios
        .post(qualityUrl + '/appealsProcess/getFuYiTaskQaUser.do', Qs.stringify(params))
        .then((resp) => {
          this.people = resp.data.listivdOper
        })
        .catch(function() {
          this.$message({
            type: 'error',
            message: '请求失败',
          })
        })
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.scoreInquery()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.scoreInquery()
    },
    handleSizeChangeone(val) {
      this.pageSize = val
      this.secherInquery()
    },
    handleCurrentChangeone(val) {
      this.currentPage = val
      this.secherInquery()
    },
    /*
     * 过滤权限按钮
     * */
    filterButton() {
      /*
       获取数据后dom节点更改了，
        需要再获取一遍dom节点对[funcID]按钮进行过滤
       * */
      let menuId = localStorage.getItem('menuId')
      let path = this.$route.path.replace('/', '')
      funcFilter(menuId, path)
    },
  },
  mounted: function() {
    let obj = {}
    obj.shensuTabIndex = 2
    this.tabIndex = 2
    this.$store.commit('setRecordingPlayPage', obj)
  },
  computed: {},
  created() {
    this.scoreInquery()
  },
}
</script>
<style lang="less" scoped="scoped">
.dealCenter {
  padding-top: 20px;
}

#soundfeature {
  box-sizing: border-box;
  height: 95%;
  width: 100%;
  overflow: hidden;
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .conpalinDiv {
    width: 100%;
    height: 100%;
    .caseHeader {
      padding: 18px 16px;
      font-size: 14px;
    }
    .complianContent {
      width: 100%;
      height: 48px;
      line-height: 48px;
      background: #eef1f6;
      border-bottom: 1px solid #d1dbe4;
      border-top: 1px solid #d1dbe4;
      background: #ffffff;
      ul {
        width: 100%;
        li {
          float: left;
          padding: 0 16px;
          box-sizing: border-box;
          font-size: 14px;
          color: #96a2b2;
          cursor: pointer;
        }
      }
    }
    .soundfeatureActive {
      color: #21a2ff !important;
      border-bottom: 2px solid #21a2ff;
    }
    .changeCondtion {
      width: 100%;
      height: 44px;
      margin-top: 10px;
    }
    .content {
      padding-bottom: 140px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .table {
      width: 100%;
      height: 100%;
      overflow: auto;
    }
    .autoGrading-page {
      height: 35px;
      position: absolute;
      background: white;
      right: 0px;
      bottom: 0px;
      text-align: right;
      .el-pagination {
        display: inline-block;
        height: 28px;
        line-height: 28px;
        padding: 0px 10px;
      }
    }
  }
}

.yuan {
  display: inline-block;
  cursor: pointer;
  height: 18px;
  width: 18px;
  border-radius: 50%;
  background: #99a8bd;
  text-align: center;
  line-height: 18px;
  float: right;
  color: #fff;
  margin-top: 3px;
}
</style>
<style lang="less">
#tableFindset th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}

.content .table th {
  background-color: #e0e6ed;
  color: #475669;
  padding: 10px 0;
}

.giveRecive {
  .el-textarea__inner {
    width: 80%;
    height: 200px;
  }
}

#soundfeature .edealFind {
  .el-dialog__body {
    padding: 0;
  }
  .el-dialog__header {
    padding: 25px 0px 10px 0px;
    border-bottom: 1px solid #e0e6ed;
    .el-dialog__title {
      padding-left: 20px;
    }
  }
}

.el-popover {
  width: 25%;
}

.detailnewMcen {
  width: 100%;
  display: inline-block;
  overflow: hidden;
  text-align: left;
  padding: 15px;
  position: relative;
  color: #1f2d3d;
  border-radius: 4px;
  vertical-align: middle;
  & > span {
    .strategybtn {
      cursor: pointer;
      overflow: hidden;
      padding-left: 10px;
      padding-right: 10px;
      .settingStrategyName {
        width: 100%;
        overflow: hidden;
        display: inline-block;
        text-overflow: ellipsis;
        float: left;
      }
    }
    .settingStrategybtns {
      float: right;
      width: 50px;
      i {
        margin-right: 5px;
        width: 18px;
        height: 18px;
        line-height: 18px;
        font-size: 10px;
        color: #20a0ff;
        &:hover {
          background: #20a0ff;
          color: #fff;
          border-radius: 50%;
        }
      }
    }
  }
  &.hovered {
    border-color: #20a0ff;
    span .strategybtn {
      padding-right: 0px;
      .settingStrategyName {
        width: 100px;
        color: #20a0ff;
      }
    }
    &.active span .strategybtn {
      .settingStrategyName {
        color: #fff;
      }
      .settingStrategybtns {
        i {
          color: #fff;
          &:hover {
            background: #fff;
            color: #20a0ff;
          }
        }
      }
    }
  }
  &.active {
    background: #20a0ff;
    color: #fff;
    border-color: #20a0ff;
    .settingStrategybtns {
      i {
        &:hover {
          background: #fff;
          color: #20a0ff;
        }
      }
    }
  }
  .detailsNew {
    display: flex;
    flex-wrap: wrap;
  }
  .contentNew {
    line-height: 30px;
    width: 100%;
    span {
      color: #9ca2b2;
      i {
        color: #1f2d3d;
      }
    }
  }
}

.playuer {
  padding-left: 20px;
}

.single {
  &.el-dialog__wrapper {
    position: fixed;
    top: 106px;
    left: 20px;
    right: 20px;
    bottom: 12px;
    .el-dialog {
      width: 100%;
      height: 100%;
      margin: 0 !important;
    }
  }
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 10px 20px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
  }
  .el-dialog--large {
    width: 90%;
    height: 84%;
    top: 5% !important;
  }
}
</style>
