<template>
  <div style="height: 100%">
    <vSlicent v-if="index == 1"></vSlicent>
    <vSpeech v-if="index == 2"> </vSpeech>
  </div>
</template>
<script>
import global from '@/global'
import vSlicent from './complianAdmin.vue' // 质检主管
import vSpeech from './complianMange.vue' // 坐席组长
import matchRoleId from '../../../utils/matchRoleId'
import cache from '../../../utils/cache'
import qs from 'qs'
export default {
  components: {
    vSlicent,
    vSpeech,
  },
  data() {
    return {
      index: '1', // 默认显示页签
      role:'', // 角色名称
      roleId:'', // 角色id
      rolename:[], // 角色编码
    }
  },
  methods: {
    // 获取权限按钮
    getFuncId: function() {
      // let codes = cache.getItem('roleInfo')
      // this.roleCodeId = codes.split(',')
      // console.log(this.roleCodeId)
      if (this.rolename.includes('qa_suvs')) {
        this.index = '1'
      } else if (this.rolename.includes('headman')) {
        this.index = '2'
      } else {
        this.index = '3'
      }
    },
    // 获取角色与角色ID
    initActRole() {
      let that = this
      this.axios
        .get(global.hrmApi + '/role/rolesForAccount.do?accountID=' + this.accountId, {})
        .then((res) => {
          that.role = res.data.Data
          that.roleId = res.data.IDS
          if (that.role == null || that.role == '') {
            that.role = '超级管理员'
            that.roleId = '超级管理员'
          }
          that.matchActRoleId(res.data.IDS)
        })
        .catch((err) => {
          console.log(err)
        })
    },
    // 匹配角色ID
    matchActRoleId(id) {
      let ids = id.split(',')
      let _this = this
      let parames = {
        code: global.roleCode.toString(),
      }
      this.axios
        .post(
          global.qualityUrl + '/pageConstant/getRoleIdByCode.do',
          qs.stringify(parames)
        )
        .then((res) => {
          if (_this.role == '超级管理员') {
            _this.rolename.push('超级管理员')
          } else {
            let resdata = res.data
            _this.rolename = matchRoleId.match(ids, resdata)
          }
          _this.getFuncId()
        })
        .catch((err) => {
          console.log(err)
        })
    },
  },
  computed: {
    accountId() {
      return this.$store.state.loginUserinfo.accountId
    },
  },
  created() {
    // this.getFuncId()
    this.initActRole()
  },
}
</script>
<style lang="less"></style>
