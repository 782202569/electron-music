<template>
  <div style="height: 100%">
    <!--<vOverlay style="overflow:hidden;height: 100%;" v-if="index == 3"></vOverlay>-->
    <vSlicent v-if="index == 1" style="overflow:hidden;height: 100%;"></vSlicent>
    <vSpeech style="overflow:hidden;height: 100%;" v-if="index == 2"> </vSpeech>
  </div>
</template>
<script>
import global from '@/global'
// import vOverlay from './resultViewmon.vue'// 普通坐席
import vSlicent from './resultViewset.vue' // 质检主管
import vSpeech from './resultViewout.vue' // 坐席组长
import cache from '../../../utils/cache'
import qs from 'qs'
export default {
  components: {
    vSlicent,
    vSpeech, // vOverlay,
  },
  data() {
    return {
      index: '', // 默认显示页签
      role:'', // 角色名称
      roleId:'', // 角色id
      roleCodeId:[], // 角色编码
    }
  },
  methods: {
    // 获取权限按钮
    getFuncId: function() {
      let codes = cache.getItem('roleInfo')
      this.roleCodeId = codes.split(',')
      console.log(this.roleCodeId)
      if (this.roleCodeId.includes('qa_suvs')) {
        this.index = '1'
      } else if (this.roleCodeId.includes('headman')) {
        this.index = '2'
      } else {
        this.index = '3'
      }
    },
  },
  computed: {
    accountId() {
      return this.$store.state.loginUserinfo.accountId
    },
  },
  created() {
    this.getFuncId()
  },
}
</script>
<style lang="less"></style>
