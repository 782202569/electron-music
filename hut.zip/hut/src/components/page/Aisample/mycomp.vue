<template>
  <el-form
    ref="orderRecheckSampleOrder_orderRecheckSampleTask_orderRecheckSampleSeat_orderRecheckSampleRecord_Ref"
    :inline="true"
    :rules="rules"
    :model="model"
    label-width="84px"
  >
    <h3>订单属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="orderNo" style="color:#8691a5" label="订单编号"
          ><el-input
            v-model="model.orderNo"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="orderTime" style="color:#8691a5" label="订单时间"
          ><el-date-picker
            style="width:160px"
            v-model="model.orderTime"
            type="datetimerange"
            placeholder="选择时间范围"
            v-bind:default-time="['00:00:00', '23:59:59']"
          ></el-date-picker></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>任务属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="assignTime" style="color:#8691a5" label="任务分发时间"
          ><el-date-picker
            style="width:160px"
            v-model="model.assignTime"
            type="datetimerange"
            placeholder="选择时间范围"
            v-bind:default-time="['00:00:00', '23:59:59']"
          ></el-date-picker></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="qaUser" style="color:#8691a5" label="质检员工号"
          ><el-input
            v-model="model.qaUser"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12"
        ><el-form-item prop="qaUserName" style="color:#8691a5" label="质检员姓名"
          ><el-input
            v-model="model.qaUserName"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="score_Min" style="color:#8691a5" label="质检分数"
          ><el-input
            style="width:55px"
            v-model="model.score_Min"
            placeholder=""
          ></el-input
        ></el-form-item>
        <span style="line-height:30px;margin-right:4px">--</span>
        <el-form-item prop="score_Max"
          ><el-input
            style="width:55px"
            v-model="model.score_Max"
            placeholder=""
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>坐席属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="submiter" style="color:#8691a5" label="提交人工号"
          ><el-input
            v-model="model.submiter"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="submiterName" style="color:#8691a5" label="提交人姓名"
          ><el-input
            v-model="model.submiterName"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row
      ><el-col :span="12"
        ><el-form-item prop="groupId" style="color:#8691a5" label="提交人坐席组"
          ><el-input
            v-model="model.groupId"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row>
    <h3>录音属性</h3>
    <el-row
      ><el-col :span="12"
        ><el-form-item prop="callId" style="color:#8691a5" label="录音编号"
          ><el-input
            v-model="model.callId"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col
      ><el-col :span="12"
        ><el-form-item prop="callNo" style="color:#8691a5" label="拨打电话"
          ><el-input
            v-model="model.callNo"
            placeholder="请输入内容"
            style="width:160px"
          ></el-input></el-form-item></el-col></el-row
    ><el-row style="border-top:1px solid #d1dbe5;"><el-col :span="24"></el-col></el-row
  ></el-form>
</template>

<script>
export default {
  data() {
    return {
      model: {
        orderNo: '',
        orderNo$CName: '订单编号',
        orderTime: [],
        orderTime$CName: '订单时间',
        assignTime: [],
        assignTime$CName: '任务分发时间',
        qaUser: '',
        qaUser$CName: '质检员工号',
        qaUserName: '',
        qaUserName$CName: '质检员姓名',
        score_Min: '',
        score_Min$CName: '质检分数(最小值)',
        score_Max: '',
        score_Max$CName: '质检分数(最大值)',
        submiter: '',
        submiter$CName: '提交人工号',
        submiterName: '',
        submiterName$CName: '提交人姓名',
        groupId: '',
        groupId$CName: '提交人坐席组',
        callId: '',
        callId$CName: '录音编号',
        callNo: '',
        callNo$CName: '拨打电话',
      },
      rules: {},
      validateFunc: function() {},
    }
  },
}
</script>

<style></style>
