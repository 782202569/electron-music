<template>
  <div class="rapidSampleContainer">
    <el-row>
      <el-col :span="12" :class="hidden ? 'hidden' : ''">
        <div class="contentLeft">
          <div class="operation">
            <h3>
              筛选条件
            </h3>
            <div class="btns">
              <el-button type="primary" @click="searchSample">查询</el-button>
              <el-button @click="resetFormEngine">清空</el-button>
            </div>
          </div>
          <div class="attrs customSample">
            <!--查询条件-->
            <my-comp ref="myComp"></my-comp>
            <!--查询条件-->
          </div>
        </div>
      </el-col>
      <el-col :span="rightSpan">
        <div class="contentRight records">
          <div
            class="toggleBtn"
            @click="toggleContainer"
            :class="hidden ? 'toggle-hidden' : 'toggle-show'"
          ></div>
          <div class="operation">
            <div class="btns">
              <el-button @click="distribution">分配</el-button>
            </div>
          </div>
          <div class="attrs recordsList recordsList_table">
            <el-table
              ref="recordsListTable"
              :data="recordsList"
              border
              tooltip-effect="dark"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" fixed width="55"></el-table-column>
              <el-table-column label="订单编号" fixed prop="orderNo">
                <template scope="scope">
                  <el-button
                    type="text"
                    class="orderNo"
                    @click="
                      showDetail(
                        scope.row.orderNo,
                        scope.row.submiterName,
                        scope.row.submiter,
                        scope.row.recordFileURL
                      )
                    "
                    >{{ scope.row.orderNo }}</el-button
                  >
                </template>
              </el-table-column>
              <el-table-column
                label="下单时间"
                prop="orderTime"
                :formatter="createTimeFilter"
              ></el-table-column>
              <el-table-column
                prop="orderState"
                label="订单状态"
                :formatter="convertOrderState"
              >
                <template scope="scope">
                  <el-tag
                    close-transition
                    type="primary"
                    v-if="scope.row.orderState == '0'"
                    >取消单</el-tag
                  >
                  <el-tag
                    close-transition
                    type="success"
                    v-if="scope.row.orderState == '1'"
                    >成功单</el-tag
                  >
                </template>
              </el-table-column>
              <el-table-column
                prop="submiter"
                label="提交人"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="seatGroup"
                label="提交人坐席组"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="score"
                label="质检得分"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="qaUser"
                label="质检员"
                show-overflow-tooltip
              ></el-table-column>
              <el-table-column
                prop="comments"
                label="质检结果"
                show-overflow-tooltip
              ></el-table-column>
            </el-table>
          </div>
          <div class="page">
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="pageSizes"
              :page-size="pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </div>
      </el-col>
    </el-row>
    <!-- 分配质检员 -->
    <el-dialog
      title="分配质检员"
      :visible.sync="distributeInspectorVisible"
      :close-on-click-modal="false"
      :before-close="handleCloseDistributeInspector"
    >
      <div class="distributeInspectorFiled">
        <div class="part_1">
          <el-form
            :model="distributeInspectorModel"
            ref="distributeInspectorModel"
            label-width="100px"
          >
            <el-form-item label="完成时间" prop="day">
              <el-select
                v-model="distributeInspectorModel.day"
                placeholder="请选择"
                clearable
              >
                <el-option label="一天" value="1"></el-option>
                <el-option label="二天" value="2"></el-option>
                <el-option label="三天" value="3"></el-option>
                <el-option label="四天" value="4"></el-option>
                <el-option label="五天" value="5"></el-option>
                <el-option label="六天" value="6"></el-option>
                <el-option label="七天" value="7"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="选择质检员" prop="people">
              <el-checkbox-group
                :min="0"
                :max="checkedRecordList.length"
                v-model="distributeInspectorModel.people"
              >
                <el-checkbox :label="item.account" v-for="item in people">{{
                  item.realName
                }}</el-checkbox>
              </el-checkbox-group>
            </el-form-item>
            <el-form-item>
              <div class="btns">
                <el-button @click="resetForm('distributeInspectorModel')">清空</el-button>
                <el-button type="primary" @click="confirmAdd">确定</el-button>
              </div>
            </el-form-item>
          </el-form>
        </div>
        <div class="part_2">
          <div>剩余未分配：{{ rest }}</div>
          <div>
            <el-table :data="tableData" style="width: 100%">
              <el-table-column
                prop="qaUserName"
                label="质检员姓名"
                width="180"
              ></el-table-column>
              <el-table-column
                prop="count"
                label="当月分配"
                width="180"
              ></el-table-column>
              <el-table-column label="当前分配">
                <template scope="scope">
                  <span
                    v-if="checkShow(scope.$index, 'edit')"
                    class="currentDistributeCount"
                  >
                    {{ currentDistribute[scope.$index] }}
                  </span>
                  <el-button
                    v-if="checkShow(scope.$index, 'edit')"
                    @click="editTableCell(scope.$index, 'edit')"
                    type="text"
                    size="small"
                    icon="edit"
                  ></el-button>
                  <el-input
                    v-if="checkShow(scope.$index, 'save')"
                    class="currentDistributeCount"
                    v-model="currentDistribute[scope.$index]"
                    placeholder="请输入内容"
                    @blur="checkNumber(scope.$index)"
                  ></el-input>
                  <el-button
                    v-if="checkShow(scope.$index, 'save')"
                    @click="editTableCell(scope.$index, 'save')"
                    type="text"
                    size="small"
                    icon="check"
                  ></el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="btns distributeInspectorbtn">
          <el-button @click="handleCloseDistributeInspector">取消</el-button>
          <el-button type="primary" @click="distributeInspector">分配</el-button>
        </div>
      </div>
    </el-dialog>
    <el-dialog
      class="single"
      title="录音播放页面"
      :visible.sync="recordDialogVisible"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
    >
      <div class="recordingplayWrap">
        <recordingplay
          ref="recordPlay"
          @onclose="recordPlayCloseHandler"
          @onminimize="recordPlayMinimizeHandler"
        ></recordingplay>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery'
import nativeaxios from 'axios'
import cache from '../../../utils/cache.js'
import qs from 'qs'
import moment from 'moment'
import formatDate from '../../../utils/formatdate.js'
import commonUtil from '../../../utils/commonUtil.js'
import dateUtil from '../../../utils/dateUtil.js'
import recordingplay from '../recordingPlayOrder/recordingPlayOrder.vue'
import bus from '../../common/bus.js'
import global from '../../../global.js'
import mycompVue from './mycomp.vue'

let qualityUrl = global.qualityUrl
export default {
  components: {
    // 局部注册
    recordingplay,
    'my-comp': mycompVue,
    // 'my-comp': (resolve) => {
    //   nativeaxios
    //     .post(
    //       global.formEngineUrl +
    //         '/creating.do?formIds=orderRecheckSampleOrder,orderRecheckSampleTask,orderRecheckSampleSeat,orderRecheckSampleRecord&accessToken=' +
    //         cache.getItem('tgt_id')
    //     )
    //     .then(function(response) {
    //       $('body').append(response.data.Validate)
    //       let myHtml = response.data.Html
    //       resolve({
    //         template: myHtml,
    //         watch: {
    //           // 监听
    //         },
    //         data() {
    //           return {
    //             /* eslint-disable */
    //             orderRecheckSampleOrder_orderRecheckSampleTask_orderRecheckSampleSeat_orderRecheckSampleRecord_Model: JSON.parse(
    //               JSON.stringify(
    //                 orderRecheckSampleOrder_orderRecheckSampleTask_orderRecheckSampleSeat_orderRecheckSampleRecord_
    //               )
    //             ),
    //             orderRecheckSampleOrder_orderRecheckSampleTask_orderRecheckSampleSeat_orderRecheckSampleRecord_Rules: orderRecheckSampleOrder_orderRecheckSampleTask_orderRecheckSampleSeat_orderRecheckSampleRecord_Rules,
    //             /* eslint-enable */
    //           }
    //         },
    //       })
    //     })
    // },
  },
  data() {
    return {
      recordDialogVisible: false,
      recordsList: [], // 录音列表
      checkedRecordList: [], // 选中的录音列表
      currentPage: 1, // 当前页码
      total: 0, // 记录总条数
      pageSize: 20, // 每页显示的记录条数
      pageSizes: [10, 15, 20, 25],
      showSelectAllbtn: true, // 是否显示全选按钮
      distributeInspectorVisible: false,
      distributeInspectorModel: {
        day: '',
        people: [],
      }, // 分配质检员表单
      tableData: [],
      templeateIds: [], // 质检模板列表
      people: [],
      modleType: '7',
      callId: '', // 录音编号
      currentDistribute: [], // 当前分配列表
      editCountIndex: '', // 当前编辑的单元格所在的行index
      countHasError: false, // 质检员分配的任务数量是否存在问题
      position: 'top',
      objectType: '1', // 1代表录音，2代表文本
      tempNum: '', // 计算过后的临时的分配总数
      hidden: false, // 左侧部分是否隐藏
    }
  },
  filters: {
    formatDate(time) {
      return formatDate.formatDate(time)
    },
  },
  methods: {
    // 获取元素的纵坐标（相对于窗口）
    getTop(e) {
      let offset = e.offsetTop
      if (e.offsetParent != null) offset += this.getTop(e.offsetParent)
      return offset
    },
    // 鼠标放到录音内容上时展示播放按钮
    showPlay() {
      event.target.querySelector('.play').style.display = 'block'
    },
    // 鼠标移出录音内容上时展示播放按钮
    hidePlay() {
      event.target.querySelector('.play').style.display = 'none'
    },
    getRangeData: function(dateArr) {
      let arr = ['', '']
      if (dateArr && dateArr.length > 0) {
        arr[0] = dateUtil.timeToString(dateArr[0])
        arr[1] = dateUtil.timeToString(dateArr[1])
      }
      return arr
    },
    // 全选录音
    selectAllRecords() {
      let _this = this
      this.checkedRecordList = []
      this.showSelectAllbtn = false
      this.recordsList.forEach(function(item, index) {
        _this.checkedRecordList.push(item.orderNo)
      })
    },
    // 全选录音
    disSelectAllRecords() {
      this.checkedRecordList = []
      this.showSelectAllbtn = true
    },
    tapePlay() {
      // 跳转到录音播放界面
    },
    handleCurrentChange(val) {
      this.currentPage = val
    },
    // 转换表格中的时间
    createTimeFilter(row, column, cellValue) {
      return moment(cellValue).format('YYYY-MM-DD HH:mm:ss')
    },
    convertOrderState(x, y, orderState) {
      return orderState
    },
    // 录音table中行的选中状态变化时触发(val为选中的object)
    handleSelectionChange(val) {
      this.checkedRecordList.length = 0
      let _this = this
      val.forEach(function(item) {
        _this.checkedRecordList.push(item.orderNo)
      })
    },
    // 分配质检员
    distribution() {
      if (this.checkedRecordList.length < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择一条数据',
        })
        return false
      }
      this.distributeInspectorVisible = true
      this.resetForm('distributeInspectorModel')
      this.distributeTask()
      this.tableData = []
    },
    handleSizeChange(val) {
      this.pageSize = val
    },
    resetFormEngine() {
      this.$nextTick(() => {
        this.$refs['myComp']['$refs'][
          'orderRecheckSampleOrder_orderRecheckSampleTask_orderRecheckSampleSeat_orderRecheckSampleRecord_Ref'
        ].resetFields()
      })
    },
    // 重置表单
    resetForm(formName) {
      let _this = this
      this.$nextTick(function() {
        _this.$refs[formName].resetFields()
      })
      if (formName == 'distributeInspectorModel') {
        this.tableData = []
        this.currentDistribute = []
        this.tempNum = 0
      }
    },
    // 关闭分配弹窗
    handleCloseDistributeInspector() {
      this.distributeInspectorVisible = false
    },
    // 获取质检员方法
    distributeTask() {
      let _this = this
      let url = qualityUrl + '/orderSamplePool/getQaUsers.do'
      this.axios
        .post(url)
        .then(function(response) {
          _this.people = response.data
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检员列表出现问题',
          })
        })
    },
    // 确认添加（质检员）
    confirmAdd() {
      this.tableData = []
      this.getDistributes()
    },
    setCurrentDistribute() {
      let qaUserCount = this.tableData.length
      this.currentDistribute = []
      let orderNos = this.checkedRecordList
      for (let i = 0; i < orderNos.length; i++) {
        let index = i % qaUserCount
        if (!this.currentDistribute[index]) {
          this['currentDistribute'][index] = '1'
        } else {
          this['currentDistribute'][index] =
            parseInt(this['currentDistribute'][index]) + 1 + ''
        }
      }
    },
    // 获取质检员任务分配情况
    getDistributes() {
      let _this = this
      if (this.distributeInspectorModel.people.length < 1) {
        this.$message({
          type: 'warning',
          message: '请先选择质检员',
        })
        return false
      }
      let url = qualityUrl + '/orderSamplePool/getQaUserDistributeInfo.do'
      let params = {}
      params.objectType = this.objectType
      params.qaUsers = this.distributeInspectorModel.people.join(',')
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.tableData = response.data
          _this.setCurrentDistribute()
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '获取质检员任务分配情况失败',
          })
        })
    },
    getDistributeParams() {
      let params = {}
      params['objectType'] = this.objectType
      params.duration = this.distributeInspectorModel.day
      let qaUserCount = this.tableData.length
      let qaUserNumberMap = {}
      for (let i = 0; i < qaUserCount; i++) {
        let qaUser = this.tableData[i].qaUser
        let count = parseInt(this.currentDistribute[i])
        qaUserNumberMap[qaUser] = count
      }
      params['qaUserNumberMap'] = JSON.stringify(qaUserNumberMap)
      params['orderNos'] = this.checkedRecordList.join(',')
      return params
    },
    updateIsSamoed: function(orderNos) {
      let params = {
        orderNos: orderNos,
      }
      this.axios.post(
        qualityUrl + '/orderReInspectionSampling/updateIsCheckedSamoed.do',
        qs.stringify(params)
      )
    },
    // 给质检员分配任务
    distributeInspector() {
      if (this.tempNum < 0 || this.tempNum > 0) {
        this.$message({
          type: 'error',
          message: '任务分配总数量和录音总数量不匹配，请重新分配',
        })
        return false
      }
      if (this.countHasError) {
        return false
      } else if (this.editCountIndex != '') {
        this.$message({
          type: 'error',
          message: '请确认质检员当前分配任务数量',
        })
        return false
      }
      let _this = this
      let params = this.getDistributeParams()

      if (commonUtil.isBlank(params['duration'])) {
        this.$message.warning('请选择完成天数!')
        return
      }

      let url =
        qualityUrl + '/orderReInspectionSampling/distributeOrderReInspectionTask.do'
      this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          _this.$message({
            type: 'success',
            message: '任务已成功分配',
          })
          _this.distributeInspectorVisible = false
          _this.searchSample()
          _this.updateIsSamoed(params['orderNos'])
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '任务分配失败',
          })
        })
    },
    getParams(param, formId) {
      for (let item in formId) {
        if (typeof formId[item] == 'string') {
          param[item] = formId[item]
        } else if (formId[item] instanceof Array) {
          if (formId[item].length == 2) {
            param[item + '_Min'] = formId[item][0]
            param[item + '_Max'] = formId[item][1]
          } else {
            param[item + '_Min'] = ''
            param[item + '_Max'] = ''
          }
        } else if (typeof formId[item] == 'object') {
          for (let jtm in formId[item]) {
            param[jtm] = formId[item][jtm]
          }
        }
      }
      return param
    },
    // 获取复检抽样（订单列表）
    getRecordsList() {
      let _this = this
      let myComp = this.$refs.myComp
      let searchParam = {}
      let obj = {}
      let model = myComp.model
      for (let prop in model) {
        if (model.hasOwnProperty(prop)) {
          obj[prop] = model[prop]
        }
      }
      if (model['orderTime'] && model['orderTime'].length === 2) {
        let orderTimeArr = this.getRangeData(model['orderTime'])
        obj['orderTime_Min'] = orderTimeArr[0]
        obj['orderTime_Max'] = orderTimeArr[1]
      }
      if (model['assignTime'] && model['assignTime'].length === 2) {
        let assignTimeArr = this.getRangeData(model['assignTime'])
        obj['assignTime_Min'] = assignTimeArr[0]
        obj['assignTime_Max'] = assignTimeArr[1]
      }
      delete obj['orderTime']
      delete obj['assignTime']
      searchParam = obj
      searchParam.pagesize = this.pageSize
      searchParam.pageindex = this.currentPage
      searchParam.objectType = this.objectType

      let url = qualityUrl + '/orderReInspectionSampling/startSample.do'
      this.axios
        .post(url, qs.stringify(searchParam))
        .then(function(response) {
          _this.recordsList = response.data.Data
          _this.total = response.data.Count
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '查询复检抽样数据发生错误',
          })
        })
    },
    // 查询数据
    searchSample() {
      this.getRecordsList()
    },
    handleCloseSaveStrategy() {
      this.saveStrategyVisible = false
    },
    // 点击table中编辑和保存按钮时数据状态的变化
    editTableCell(index, flag) {
      this.countHasError = false
      if (flag == 'edit') {
        this.editCountIndex = index
      } else {
        if (isNaN(this.currentDistribute[index])) {
          this.countHasError = true
          return false
        } else {
          // 是数字的逻辑处理
          if (parseInt(this.currentDistribute[index]) == 0) {
            // 如果是0，删除改行数据，同时该人员的选中状态去掉
            let _this = this
            this.distributeInspectorModel.people.forEach(function(i, n) {
              if (n.account == _this.tableData[index].account) {
                _this.distributeInspectorModel.people.splice(i, 1)
              }
            })
            this.tableData.splice(index, 1)
            this.currentDistribute.splice(index, 1)
          }
        }
        this.editCountIndex = ''
      }
    },
    // 检查当前分配输入的是否是数字
    checkNumber(index) {
      this.countHasError = false
      if (isNaN(this.currentDistribute[index])) {
        this.$message({
          type: 'error',
          message: '请输入数字',
        })
        event.target.focus()
        this.countHasError = true
        return false
      } else {
        if (parseInt(this.currentDistribute[index]) == 0) {
          // 如果是0，删除改行数据，同时该人员的选中状态去掉
          let _this = this
          this.distributeInspectorModel.people.forEach(function(i, n) {
            if (n.account == _this.tableData[index].account) {
              _this.distributeInspectorModel.people.splice(i, 1)
            }
          })
          this.tableData.splice(index, 1)
          this.currentDistribute.splice(index, 1)
        }
      }
    },
    // 控制table中编辑和保存状态时表格内容的展示
    checkShow(index, flag) {
      if (flag == 'edit' && this.editCountIndex !== index) {
        return true
      } else if (flag == 'save' && this.editCountIndex !== index) {
        return false
      } else if (flag == 'save' && this.editCountIndex === index) {
        return true
      } else {
        return false
      }
    },
    toggleContainer() {
      this.hidden = !this.hidden
    },
    recordPlayCloseHandler: function() {
      this.recordDialogVisible = false
      this.$store.commit('setPlayerInfo', {
        exist: false,
        extendClassName: '',
        maxCallback: null,
      })
      bus.$emit('closeToplayer')
    },
    recordPlayMinimizeHandler: function() {
      let self = this
      this.recordDialogVisible = false // 关闭弹窗
      this.$store.commit('setPlayerInfo', {
        isMaximization: false, // 播放器最小化
        exist: true, // 菜单出现播放器
        maxCallback: function() {
          self.recordDialogVisible = true
          self.$store.commit('setPlayerInfo', {
            isMaximization: true,
          })
        },
      })
    },
    // 调到录音播放页
    showDetail(orderNo, submiterName, submiter, recordFileURL) {
      let obj = {}
      obj.from = 'reInspectionSamplingOrder'
      obj.orderNo = orderNo
      obj.recordFileURL = recordFileURL
      obj.pageId = 'reInspectionSamplingOrder'
      obj.submiterName = submiterName
      obj.submiter = submiter
      this.$store.commit('setRecordingPlayPage', obj)
      // this.$router.push({path: '/recordingPlayOrder', query: obj})

      this.recordDialogVisible = true
      this.$store.commit('setPlayerInfo', {
        isMaximization: true,
        exist: true,
        extendClassName: 'recordingPlay', // 扩展样式
      })
      this.$refs.recordPlay && this.$refs.recordPlay.init()
    },
  },
  created() {
    if (
      this.recordingPlayPage.fromPage == 'reInspectionSamplingOrder' &&
      this.recordingPlayPage.searchModel.pageindex
    ) {
      this.currentPage = this.recordingPlayPage.searchModel.pageindex
    }
  },
  mounted() {
    if (
      this.recordingPlayPage.fromPage == 'reInspectionSamplingOrder' &&
      this.recordingPlayPage.searchModel.pageindex
    ) {
      this.currentPage = this.recordingPlayPage.searchModel.pageindex
      this.pageSize = this.recordingPlayPage.searchModel.pagesize
      this.$refs.myComp.model = this.recordingPlayPage.searchModel.searchObj
      this.getRecordsList()
    }
  },
  watch: {
    pageSize() {
      this.getRecordsList()
    },
    currentPage() {
      this.getRecordsList()
    },
  },
  computed: {
    rest() {
      let sum = 0
      this.currentDistribute.forEach(function(item) {
        if (!isNaN(parseInt(item))) {
          sum += parseInt(item)
        }
      })
      this.tempNum = this.checkedRecordList.length - sum
      return this.checkedRecordList.length - sum > 0
        ? this.checkedRecordList.length - sum
        : 0
    },
    rightSpan() {
      if (this.hidden) {
        return 24
      } else {
        return 12
      }
    },
    recordingPlayPage() {
      console.log(this.$store.state.recordingPlayPage)
      return this.$store.state.recordingPlayPage
    },
  },
}
</script>
<style lang="less">
@border-color: #d1dbe5;
.rapidSampleContainer {
  .recordingplayWrap {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    position: relative;
  }
  .single {
    &.el-dialog__wrapper {
      position: fixed;
      top: 106px;
      left: 20px;
      right: 20px;
      bottom: 12px;
      .el-dialog {
        width: 100%;
        height: 100%;
        margin: 0 !important;
      }
    }
    .el-dialog__header {
      display: none;
    }
    .el-dialog__body {
      padding: 10px 20px;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
    }
    .el-dialog--large {
      height: 84%;
      top: 5% !important;
    }
  }
  div {
    box-sizing: border-box;
  }
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
  .operation {
    box-sizing: border-box;
    height: 60px;
    line-height: 60px;
    padding: 0px 10px 0px 0px;
    border-bottom: 1px dashed @border-color;
    position: absolute;
    top: 0px;
    left: 10px;
    right: 10px;
    h3 {
      width: 65px;
      float: left;
      font-size: 14px;
      color: #5e6d82;
      font-weight: normal;
    }
  }
  .btns {
    float: right;
    button {
      width: 90px;
    }
  }
  .el-row {
    height: 100%;
    .el-col {
      height: 100%;
    }
  }
  .contentLeft,
  .contentRight {
    border-right: 1px solid @border-color;
    height: 100%;
    width: 100%;
    position: relative;
    .attrs {
      position: absolute;
      top: 60px;
      right: 0px;
      left: 0px;
      bottom: 0px;
      overflow-y: auto;
      .audioAttrs_part {
        border-bottom: 1px dashed @border-color;
        .audioAttrsInputs {
          padding: 10px;
          .el-form-item > label {
            font-size: 14px;
            color: #8691a5;
          }
        }
      }
      .audioAttrs_part:last-child {
        border-bottom: none;
      }
      h3 {
        padding-left: 10px;
        line-height: 30px;
        font-size: 14px;
        color: #9dadc2;
        font-weight: normal;
      }
    }
  }
  .editStrategy .attrs {
    bottom: 0px;
  }
  .attrs.customSample {
    padding: 10px;
  }
  .strategySample {
    .settingStrategy {
      width: 100%;
      box-sizing: border-box;
      padding-bottom: 10px;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      .detailContainer {
        cursor: pointer;
      }
      .noborder {
        visibility: hidden;
      }
    }
  }
  .records {
    .operation .btns {
      .el-button:last-child {
        padding-left: 10px;
      }
      .el-radio-group:first-child {
        margin-right: 10px;
      }
    }
    .recordsList {
      position: absolute;
      top: 60px;
      left: 0;
      right: 0;
      bottom: 50px;
      overflow-y: auto;
      p {
        text-align: center;
        font-size: 14px;
        color: #9dadc2;
        padding-top: 30px;
      }
    }
    .recordsList_table {
      padding: 10px;
    }
    .page {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0px;
      border-top: 1px solid @border-color;
      text-align: right;
      height: 50px;
      box-sizing: border-box;
      padding-top: 10px;
      .el-pagination {
        display: inline-block;
        height: 30px;
      }
    }
  }
  .el-checkbox-group {
    display: flex;
    flex-wrap: wrap;
    padding-top: 10px;
  }
  .recordDisplayBoxContainer {
    box-sizing: border-box;
    width: 100%;
    padding: 0px 10px;
  }
  .recordDisplayBox {
    position: relative;
    border: 1px solid @border-color;
    width: 100%;
    margin-bottom: 10px;
    height: 185px;
    box-sizing: border-box;
    & > div {
      padding: 0px 10px;
    }
    .recordDisplay_header {
      height: 45px;
      line-height: 45px;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      font-weight: bold;
      background: #eff2f7;
      & > span {
        margin-left: 10px;
        vertical-align: middle;
      }
      & > label {
        vertical-align: middle;
        span.el-checkbox__label {
          display: none;
        }
      }
    }
    .recordDisplay_content {
      position: absolute;
      top: 45px;
      left: 0;
      right: 0;
      bottom: 35px;
      overflow: hidden;
      &:hover {
        cursor: pointer;
      }
      .play {
        display: none;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 10;
        background: rgba(00, 00, 00, 0.4);
        text-align: center;
        line-height: 145px;
        img {
          display: inline;
          width: 51px;
          height: 51px;
        }
      }
    }
    .recordDisplay_footer {
      height: 35px;
      line-height: 35px;
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      background: #fbfdff;
      border-top: 1px solid @border-color;
      span:nth-child(2) {
        margin-right: 10px;
      }
    }
  }
  .recordDisplayBoxContainer_hidden {
    width: 50%;
    margin: 0px;
    box-sizing: border-box;
    padding-bottom: 10px;
    &:nth-child(2n + 1) {
      padding-left: 10px;
      padding-right: 5px;
    }
    &:nth-child(2n) {
      padding-right: 10px;
      padding-left: 5px;
    }
    .recordDisplayBox {
      margin: 0px;
    }
  }
  .distributeInspectorbtn {
    margin: 10px 0px 10px;
  }
  .currentDistributeCount {
    display: inline-block;
    width: 80px;
  }
  .hidden {
    display: none;
  }
  .toggleBtn {
    cursor: pointer;
    width: 20px;
    height: 30px;
    background-image: url('../../../assets/img/close.png');
    position: absolute;
    left: -20px;
    top: 45%;
    bottom: 0px;
    z-index: 999;
  }
  .toggle-hidden {
    left: 0px;
    transform: rotate(180deg);
  }
  .callId {
    &:hover {
      color: #20a0ff;
      cursor: pointer;
    }
  }
}
</style>
