<template>
  <div class="crossAnalyse" id="crossAnalyse">
    <div class="operation">
      <div class="operationContent">
        <el-form :model="searchModel" ref="searchModel" :inline="true">
          <div>
            <el-form-item label="时间：" style="margin-left:15px;"></el-form-item>
            <el-form-item prop="timeAreaType">
              <el-radio-group v-model="searchModel.timeAreaType" @change="resetTime">
                <el-radio label="1">近一天</el-radio>
                <el-radio label="2">近一周</el-radio>
                <el-radio label="3">近一月</el-radio>
                <el-radio label="4">其他</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item prop="callSTime_Min">
              <el-date-picker
                type="date"
                placeholder="开始日期"
                v-model="searchModel.callSTime_Min"
                @change="setMinTime"
              ></el-date-picker>
            </el-form-item>
            <el-form-item prop="callSTime_Max">
              <el-date-picker
                type="date"
                placeholder="结束日期"
                v-model="searchModel.callSTime_Max"
                @change="setMaxTime"
              ></el-date-picker>
            </el-form-item>
          </div>
          <el-form-item label="主维度" prop="mainMd">
            <el-select
              v-model="searchModel.mainMd"
              placeholder="请选择"
              clearable
              @change="changeDimention('mainMd')"
            >
              <el-option
                :label="item.value"
                :value="item.key"
                v-for="item in dimentions"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="mainMdVal">
            <el-select v-model="searchModel.mainMdVal" placeholder="请选择" clearable>
              <el-option
                :label="item[mainSubDimentionLabel]"
                :value="item[mainSubDimentionValue]"
                v-for="item in mainMdVals"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="副维度" prop="viceMd">
            <el-select
              v-model="searchModel.viceMd"
              placeholder="请选择"
              clearable
              @change="changeDimention('viceMd')"
            >
              <el-option
                :label="item.value"
                :value="item.key"
                v-for="item in dimentions"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item prop="viceMdVal">
            <el-select v-model="searchModel.viceMdVal" placeholder="请选择" clearable>
              <el-option
                :label="item[viceSubDimentionLabel]"
                :value="item[viceSubDimentionValue]"
                v-for="item in viceMdVals"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item style="float: right">
            <el-button
              funcId="000229"
              style="float: right;"
              @click="resetForm('searchModel')"
              >清空</el-button
            >
            <el-button
              style="float:right;margin-right:10px;"
              type="primary"
              @click="search"
              >查询</el-button
            >
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="contents">
      <div class="crossAnalyse_chart_setting">
        <el-popover ref="popover" placement="bottom" width="100" trigger="click">
          <div class="setting_content">
            <p>横坐标</p>
            <el-radio-group v-model="activeName" @change="handleChartClick">
              <el-radio label="1">柱状图</el-radio>
              <el-radio label="2">折线图</el-radio>
            </el-radio-group>
            <p>纵坐标</p>
            <el-radio-group v-model="yType" @change="changeYType">
              <el-radio label="1">录音量</el-radio>
              <el-radio label="2">平均时长</el-radio>
              <el-radio label="3">总通话时长</el-radio>
            </el-radio-group>
            <p>横坐标</p>
            <el-radio-group v-model="xAx" @change="changeXAx">
              <el-radio label="1">按天</el-radio>
              <el-radio label="2">按小时</el-radio>
            </el-radio-group>
          </div>
        </el-popover>
        <el-button type="primary" @click="exportResult" size="small">结果导出</el-button>
        <el-button funcId="000231" v-popover:popover size="small">展示配置</el-button>
      </div>
      <div id="crossAnalyse_chart" class="chart_box" style="overflow: hidden;"></div>
      <div class="subChart_container">
        <div class="chart_box" id="mainDimension_chart"></div>
        <div id="subDimension_chart" class="chart_box"></div>
      </div>
    </div>
  </div>
</template>
<script>
import qs from 'qs'
import cache from '../../../utils/cache.js'
import global from '../../../global.js'
let currentBaseUrl = global.currentBaseUrl
export default {
  data() {
    return {
      activeName: '1', // 主维度展示图表
      searchModel: {
        function: '1', // 统计的单位，1为录音量，2为平均时长，3为总通话时长
        callSTime_Min: '', // 录音时间低值
        callSTime_Max: '', // 录音时间高值
        mainMd: '', // 主维度下拉框
        viceMd: '', // 副维度下拉框
        mainMdVal: '', // 主维度的第二个下拉框值
        viceMdVal: '', // 副维度的第二个下拉框值
        timeAreaType: '4',
      },
      dimentions: [], // 主维度和副维度下拉框的值
      mainMdVals: [], // 主维度的第二个下拉框
      viceMdVals: [], // 副维度的第二个下拉框
      yType: '1', // 纵坐标
      xAx: '1', // 横坐标
      groupBy: '', // groupBy字段，统计主副维度数据时使用
      mainSubDimentionValue: '', // 主维度的二级维度下拉框Value
      mainSubDimentionLabel: '', // 主维度的二级维度下拉框Label
      viceSubDimentionValue: '', // 副维度的二级维度下拉框Value
      viceSubDimentionLabel: '', // 副维度的二级维度下拉框Label
    }
  },
  methods: {
    changeYType: function() {
      this.statistical()
      this.statisticalThree()
    },
    changeXAx: function() {
      this.statistical()
      this.statisticalThree()
    },
    handleChartClick() {
      this.statistical()
      this.statisticalThree()
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
    },
    search() {
      this.statisticalThree()
      this.statistical()
    },
    /*
     * 画交叉分析柱状图
     * */
    drawBarCrossChart(lineObject) {
      let config = {
        rotate: 90,
        align: 'left',
        verticalAlign: 'middle',
        position: 'insideBottom',
        distance: 15,
        onChange: function() {
          let labelOption = {
            normal: {
              rotate: config.rotate,
              align: config.align,
              verticalAlign: config.verticalAlign,
              position: config.position,
              distance: config.distance,
            },
          }
          myChart.setOption({
            series: [
              {
                label: labelOption,
              },
              {
                label: labelOption,
              },
              {
                label: labelOption,
              },
              {
                label: labelOption,
              },
            ],
          })
        },
      }
      let labelOption = {
        normal: {
          show: false,
          position: config.position,
          distance: config.distance,
          align: config.align,
          verticalAlign: config.verticalAlign,
          fontSize: 10,
          rich: {
            name: {
              textBorderColor: '#fff',
            },
          },
        },
      }
      let myChart = this.$echarts.dispose(document.querySelector('#crossAnalyse_chart'))
      let _this = this
      let option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
        },
        title: {
          text: '交叉分析柱状图',
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        legend: {
          type: 'scroll',
          left: 110,
          right: 170,
          data: [],
        },
        dataZoom: [
          {
            type: 'slider',
            show: true,
            xAxisIndex: [0],
            start: 1,
            end: 100,
            height: '5%',
            showDetail: false,
            bottom: 0,
          },
          {
            type: 'inside',
            xAxisIndex: [0],
            start: 1,
            end: 100,
            height: '5%',
          },
        ],
        grid: {
          top: '50',
          left: '20',
          right: '20',
          bottom: '10%',
          containLabel: true,
        },
        calculable: true,
        xAxis: [
          {
            type: 'category',
            axisTick: { show: false },
            data: [],
          },
        ],
        yAxis: [
          {
            type: 'value',
          },
        ],
        series: [],
      }
      if (lineObject) {
        option.legend.data = lineObject.XName
        option.xAxis[0].data = lineObject.X
        let Y = lineObject.Y
        for (let i = 0; i < Y.length; i++) {
          option.series.push({
            name: Y[i].name,
            type: Y[i].type,
            label: labelOption,
            data: Y[i].data,
            barGap: 0,
          })
        }
      }
      this.$nextTick(function() {
        let myChart = _this.$echarts.init(document.querySelector('#crossAnalyse_chart'))
        myChart.setOption(option)
      })
    },
    // 画交叉分析折线图
    // lineObject.abscissa，横坐标值
    // lineObject.lineName，曲线名称
    // lineObject.values，数据值
    drawLineCrossChart(lineObject) {
      this.$echarts.dispose(document.querySelector('#crossAnalyse_chart'))
      let _this = this
      let option = {
        tooltip: {
          trigger: 'axis',
        },
        title: {
          text: '交叉分析折线图',
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        legend: {
          type: 'scroll',
          left: 110,
          right: 170,
          data: [],
        },
        dataZoom: [
          {
            type: 'slider',
            show: true,
            xAxisIndex: [0],
            start: 1,
            end: 100,
            height: '5%',
            showDetail: false,
            bottom: 0,
          },
          {
            type: 'inside',
            xAxisIndex: [0],
            start: 1,
            end: 100,
            height: '5%',
          },
        ],
        grid: {
          top: '50',
          left: '20',
          right: '20',
          bottom: '10%',
          containLabel: true,
        },
        // color: [
        //   '#50b4ff',
        //   '#40e0b0',
        //   '#324157',
        //   '#a0a7e6',
        //   '#c4ebad',
        //   '#96dee8'
        // ],
        xAxis: {
          type: 'category',
          data: [],
          boundaryGap: false,
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // },
          axisLine: {
            show: false,
          },
          nameLocation: 'center',
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // },
          axisLine: {
            show: false,
          },
        },
        series: [],
      }
      if (lineObject) {
        option.legend.data = lineObject.lineName
        option.xAxis.data = lineObject.abscissa
        option.series = lineObject.values
      }
      this.$nextTick(function() {
        let chart = _this.$echarts.init(document.querySelector('#crossAnalyse_chart'))
        chart.setOption(option)
      })
    },
    /*
     * 绘制主副纬度折线图
     * */
    drawLineMainChart(title, divID, x, y) {
      let str = '#' + divID
      this.$echarts.dispose(document.querySelector(str))
      let _this = this
      let option = {
        tooltip: {
          trigger: 'axis',
        },
        title: {
          text: title,
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        legend: {
          data: [],
        },
        dataZoom: [
          {
            type: 'slider',
            show: true,
            xAxisIndex: [0],
            start: 1,
            end: 100,
            height: '5%',
            showDetail: false,
            bottom: 0,
          },
          {
            type: 'inside',
            xAxisIndex: [0],
            start: 1,
            end: 100,
            height: '5%',
          },
        ],
        grid: {
          top: '50',
          left: '20',
          right: '20',
          bottom: '10%',
          containLabel: true,
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        xAxis: {
          type: 'category',
          data: [],
          boundaryGap: false,
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // },
          axisLine: {
            show: false,
          },
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // },
          axisLine: {
            show: false,
          },
        },
        series: [],
      }
      option.xAxis.data = x
      let Y = y
      for (let i = 0; i < Y.length; i++) {
        option.series.push({
          name: '',
          type: 'line',
          data: y,
          smooth: true,
        })
      }
      this.$nextTick(function() {
        let chart = _this.$echarts.init(document.querySelector(str))
        chart.setOption(option)
      })
    },
    // 画条形图
    // title，标题
    // divID， div的ID值
    // x，[Array] 横坐标数据
    // x，[Array] 纵坐标数据
    drawBarChart(title, divID, x, y) {
      let str = '#' + divID
      this.$echarts.dispose(document.querySelector(str))
      let _this = this
      let option = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        title: {
          text: title,
          textStyle: {
            color: '#5e6d82',
            fontSize: 14,
            fontWieght: 'normal',
          },
        },
        grid: {
          top: '50',
          left: '20',
          right: '20',
          bottom: '10%',
          containLabel: true,
        },
        color: ['#50b4ff', '#40e0b0', '#324157', '#a0a7e6', '#c4ebad', '#96dee8'],
        dataZoom: [
          {
            type: 'slider',
            show: true,
            xAxisIndex: [0],
            start: 1,
            end: 30,
            height: '5%',
            showDetail: false,
            bottom: 0,
          },
          {
            type: 'inside',
            xAxisIndex: [0],
            start: 1,
            end: 30,
            height: '5%',
          },
        ],
        xAxis: {
          type: 'category',
          data: [1, 2, 3, 4],
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          //   // interval: 0,
          //   // rotate: 50
          // },
          axisLine: {
            show: false,
          },
        },
        yAxis: {
          type: 'value',
          splitLine: {
            show: true,
          },
          // axisLabel: {
          //   padding: [2, 2, 2, 2],
          //   borderWidth: 1,
          //   borderColor: '#797979',
          //   borderRadius: 3
          // },
          axisLine: {
            show: false,
          },
        },
        series: [
          {
            name: '样本数量',
            type: 'bar',
            stack: '总量',
            data: [10, 20, 30, 40],
          },
        ],
      }
      option.xAxis.data = x
      option.series[0].data = y
      this.$nextTick(function() {
        let chart = _this.$echarts.init(document.querySelector(str))
        chart.setOption(option)
      })
    },
    // 获取主维度和副维度下拉框的值
    getDimentions() {
      let _this = this
      let params = {
        dataCode: 'crossDimention',
      }
      let url = currentBaseUrl + '/pageConstant/getStandByCode.do'
      _this.axios
        .get(url, { params })
        .then(function(response) {
          _this.dimentions = response.data
          _this.$nextTick(() => {
            _this.searchModel.mainMd = 'immediatelyFilterTask'
          })
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '下拉列表获取失败',
          })
        })
    },
    clearAllSelect() {
      this['dimentions'] = []
      this['viceMdVals'] = []
    },
    // 监测一级维度变化，获取二级维度
    changeDimention(dimention) {
      let subDimentionObj = {}
      if (dimention === 'mainMd') {
        this.searchModel.mainMdVal = ''
        this.getStandByCode(dimention)
        subDimentionObj.value = 'mainSubDimentionValue'
        subDimentionObj.label = 'mainSubDimentionLabel'
      } else {
        this.searchModel.viceMdVal = ''
        subDimentionObj.value = 'viceSubDimentionValue'
        subDimentionObj.label = 'viceSubDimentionLabel'
      }
      console.log(this.searchModel[dimention])
      if (this.searchModel[dimention] == 'seatGroup') {
        this.listSeat(dimention, subDimentionObj)
      } else if (this.searchModel[dimention] == 'province') {
        this.listprovince(dimention, subDimentionObj)
      } else if (this.searchModel[dimention] == 'immediatelyFilterTask') {
        this.getImmeidatelyTaskList(dimention, subDimentionObj)
      }
    },
    getImmeidatelyTaskList(dimention, subDimentionObj) {
      this.axios
        .post(currentBaseUrl + '/pageConstant/getValue.do?keys=immediatelyProjects')
        .then((response) => {
          let dataList = response['data']['immediatelyProjects']
          this[dimention + 'Vals'] = dataList
          this[subDimentionObj.label] = 'name'
          this[subDimentionObj.value] = 'id'
        })
    },
    // 获取查询过程中所需要的groupBy字段,查询主维度副维度数据时需要
    getStandByCode(dimention) {
      let _this = this
      let params = {
        dataCode: 'cross_' + this.searchModel[dimention],
      }
      let url = currentBaseUrl + '/pageConstant/getStandByCode.do'
      _this.axios
        .get(url, { params })
        .then(function(response) {
          response.data.forEach(function(item) {
            if (item.key == 'groupBy') {
              _this.groupBy = item.value
            }
          })
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: 'groupBy字段获取失败',
          })
        })
    },
    // 获取坐席组数据
    listSeat(dimention, subDimentionObj) {
      let _this = this
      let params = {
        dpcpId: '',
        showAccount: '0',
      }
      let url = currentBaseUrl + '/pageConstant/listSeat.do'
      _this.axios
        .get(url, { params })
        .then(function(response) {
          _this[dimention + 'Vals'] = response.data
          _this[subDimentionObj.label] = 'name'
          _this[subDimentionObj.value] = 'id'
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '坐席组数据获取失败',
          })
        })
    },
    // 获取区域数据
    listprovince(dimention, subDimentionObj) {
      let _this = this
      let url = currentBaseUrl + '/mobiletoarea/listprovince.do'
      _this.axios
        .get(url)
        .then(function(response) {
          _this[dimention + 'Vals'] = response.data
          _this[subDimentionObj.label] = 'province'
          _this[subDimentionObj.value] = 'province'
        })
        .catch(function() {
          _this.$message({
            type: 'error',
            message: '区域数据获取失败',
          })
        })
    },
    // 获取交叉维度的数据
    statisticalThree() {
      let _this = this
      let params = {}
      params.mainMd = this.searchModel.mainMd || 'immediatelyFilterTask'
      params.viceMd = this.searchModel.viceMd
      params.callSTime_Min = this.gettimeform(this.searchModel.callSTime_Min)
      params.callSTime_Max = this.gettimeform(this.searchModel.callSTime_Max)
      params.function = this.yType
      params.xAx = this.xAx
      this.dealDimentionData(params)

      let url = currentBaseUrl + '/crossAnalysis/statisticalThree.do'
      _this.axios
        .post(url, qs.stringify(params))
        .then(function(response) {
          if (_this.activeName == '1') {
            _this.drawBarCrossChart(response.data.data)
          } else if (_this.activeName == '2') {
            _this.drawLineCrossChart(response.data)
          }
        })
        .catch(function() {
          _this.drawLineCrossChart()
          if (_this.searchModel.mainMd == '') {
            _this.$message({
              type: 'error',
              message: '请选择主维度',
            })
          } else {
            _this.$message({
              type: 'error',
              message: '获取交叉维度数据值失败',
            })
          }
        })
    },
    // 获取主副维度的数据
    statistical() {
      let _this = this
      let params = {}
      params.function = this.searchModel.function
      params.mainMd = this.searchModel.mainMd || 'immediatelyFilterTask'
      params.viceMd = this.searchModel.viceMd
      params.callSTime_Min = this.gettimeform(this.searchModel.callSTime_Min)
      params.callSTime_Max = this.gettimeform(this.searchModel.callSTime_Max)
      params.groupBy = this.groupBy
      this.dealDimentionData(params)
      let url = currentBaseUrl + '/crossAnalysis/statistical.do'
      _this.axios.post(url, qs.stringify(params)).then(function(response) {
        if (_this.activeName == '1') {
          _this.drawBarChart(
            '主维度',
            'mainDimension_chart',
            response.data.mainLatitudeCode,
            response.data.mainLatitudeValue
          )
          _this.drawBarChart(
            '副维度',
            'subDimension_chart',
            response.data.minorLatitudeCode,
            response.data.minorLatitudeValue
          )
        } else if (_this.activeName == '2') {
          _this.drawLineMainChart(
            '主维度',
            'mainDimension_chart',
            response.data.mainLatitudeCode,
            response.data.mainLatitudeValue
          )
          _this.drawLineMainChart(
            '副维度',
            'subDimension_chart',
            response.data.minorLatitudeCode,
            response.data.minorLatitudeValue
          )
        }
      })
    },
    gettimeform(val) {
      // 获取标准的时间样式
      if (!val) {
        return ''
      }
      let date = new Date(val)
      let year = date.getFullYear()
      let month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month
      }
      let day = date.getDate()
      if (day < 10) {
        day = '0' + day
      }
      let str = year + '-' + month + '-' + day
      return str
    },
    // 交叉分析结果导出
    exportResult() {
      let params = {}
      params.function = this.searchModel.function
      params.mainMd = this.searchModel.mainMd || '-1'
      params.viceMd = this.searchModel.viceMd || '-1'
      params.callSTime_Min = this.gettimeform(this.searchModel.callSTime_Min)
      params.callSTime_Max = this.gettimeform(this.searchModel.callSTime_Max)
      params.CASTGC = localStorage.getItem('tgt_id')
      this.dealDimentionData(params)

      let form = document.createElement('form')
      form.method = 'post'
      form.target = '_blank'
      for (let key in params) {
        let input = document.createElement('input')
        input.name = key
        input.value = params[key]
        form.appendChild(input)
      }
      form.action =
        currentBaseUrl + '/crossAnalysis/export.do?accessToken=' + cache.getItem('tgt_id')
      document.querySelector('body').appendChild(form)
      form.submit()
      document.querySelector('body').removeChild(form)
    },
    // 主维度、副维度、主维度的二级维度和副维度的二级维度数据需要特殊处理，该方法将处理结果加到params上
    dealDimentionData(params) {
      console.log('deal!')
      params['mainMdVal'] = this.searchModel.mainMdVal
      params['viceMdVal'] = this.searchModel.viceMdVal
    },
    // 根据选择的时间范围设置时间
    resetTime(val) {
      let myDate = new Date()
      if (val == '1') {
        myDate.setDate(myDate.getDate() - 1)
        this.searchModel.callSTime_Min = this.gettimeform(myDate)
        this.searchModel.callSTime_Max = this.gettimeform(new Date())
      } else if (val == '2') {
        myDate.setDate(myDate.getDate() - 7)
        this.searchModel.callSTime_Min = this.gettimeform(myDate)
        this.searchModel.callSTime_Max = this.gettimeform(new Date())
      } else if (val == '3') {
        myDate.setMonth(myDate.getMonth() - 1)
        this.searchModel.callSTime_Min = this.gettimeform(myDate)
        this.searchModel.callSTime_Max = this.gettimeform(new Date())
      } else if (val == '4') {
      }
    },
    // 选择时间后，时间区间类型变为其他
    setMinTime(val) {
      this.$nextTick(function() {
        if (val !== this.searchModel.callSTime_Min) {
          this.searchModel.timeAreaType = '4'
        }
      })
    },
    setMaxTime(val) {
      this.$nextTick(function() {
        if (val !== this.searchModel.callSTime_Max) {
          this.searchModel.timeAreaType = '4'
        }
      })
    },
  },
  mounted() {
    this.statisticalThree()
    this.statistical()
  },
  created() {
    this.searchModel.callSTime_Min = this.gettimeform(new Date())
    this.searchModel.callSTime_Max = this.gettimeform(new Date())
    this.getDimentions()
    // 默认主维度的二级选项
    let subDimentionObj = {}
    subDimentionObj.value = 'mainSubDimentionValue'
    subDimentionObj.label = 'mainSubDimentionLabel'
    this.getImmeidatelyTaskList('mainMd', subDimentionObj)
  },
}
</script>
<style lang="less" scoped>
@boder-color: #d1dbe5;
@operationHeight: 100px;
@padding: 10px;
// 组件样式
.crossAnalyse {
  .toggle-chart-tab {
    position: absolute;
    top: -10px;
    left: 0;
  }
  .operation {
    .el-form {
      .el-form-item {
        height: @operationHeight / 2;
        margin-bottom: 0px;
        padding-top: 5px;
        label,
        div {
          vertical-align: middle;
        }
      }
    }
  }
}

.el-form--inline .el-form-item {
  margin-right: 0;
}

// 页面样式
.crossAnalyse {
  padding: 0px @padding;
  height: 100%;
  box-sizing: border-box;
  position: relative;
  .line {
    text-align: center;
  }
  div {
    box-sizing: border-box;
  }
  .operation {
    height: @operationHeight;
    position: absolute;
    border-bottom: 1px dashed @boder-color;
    padding-right: @padding;
    top: 0px;
    left: 0;
    right: 0;
    margin: 0px @padding;
  }
  .contents {
    overflow: hidden;
    position: absolute;
    left: 0;
    right: 0;
    top: @operationHeight;
    bottom: 0;
    padding: @padding;
    div.crossAnalyse_chart_setting {
      position: absolute;
      z-index: 999;
      right: 20px;
      top: 20px;
    }
    div.chart_box {
      border: 1px solid @boder-color;
      margin-bottom: @padding;
      padding: @padding 0px;
      overflow-y: auto;
    }
    div#crossAnalyse_chart {
      position: absolute;
      top: 2%;
      left: @padding;
      right: @padding;
      height: 47%;
    }
    div.subChart_container {
      position: absolute;
      bottom: 2%;
      left: @padding;
      right: @padding;
      height: 47%;
      display: flex;
      justify-content: space-between;
      & > div {
        height: 100%;
        width: 50%;
        &:first-child {
          margin-right: @padding;
        }
      }
    }
  }
}

.setting_content {
  p {
    line-height: 20px;
  }
  div.el-radio-group {
    margin: 5px;
    & > label {
      float: left;
      margin: 5px 0px;
      width: 100%;
    }
  }
}
</style>
