<template>
  <div style="display: flex;">
    <div style="width: 100px;">
      <h3>Draggable 1</h3>
      <draggable
        class="dragArea list-group"
        :list="list1"
        :group="{ name: 'people', put: false }"
        @change="log"
      >
        <span class="list-group-item" v-for="element in list1" :key="element.name">
          {{ element.name }}
        </span>
      </draggable>
    </div>

    <div style="flex: 1;">
      <h3>Draggable 2</h3>
      <div
        v-for="val in list2"
        :key="val.name"
        :disabled="true"
        style="border: 1px solid red;margin-top: 10px;padding: 10px;"
      >
        <draggable
          :list="val.value"
          group="people"
          filter=".undraggable"
          @change="log"
          class="dragArea list-group"
        >
          <span
            class="child undraggable"
            v-for="element in val.value"
            :key="element.name"
            style="background: blue;color: white;margin: 10px;display: inline-block;transform: translate(0);
  transition-duration: 2000ms;"
          >
            {{ element.name }}
          </span>
        </draggable>
      </div>
    </div>
  </div>
</template>
<script>
import draggable from 'vuedraggable'
export default {
  name: 'two-lists',
  display: 'Two Lists',
  order: 1,
  components: {
    draggable,
  },
  data() {
    return {
      list1: [
        { name: 'John', id: 1 },
        { name: 'Joao', id: 2 },
        { name: 'Jean', id: 3 },
        { name: 'Gerard', id: 4 },
      ],
      list2: [
        {
          name: 'first',
          value: [{ name: 'Juan', id: 5 }, { name: 'Juan11', id: 11 }],
        },
        {
          name: 'second',
          value: [{ name: 'Edgard', id: 6 }, { name: 'Edgard22', id: 22 }],
        },
        {
          name: 'thired',
          value: [{ name: 'Johnson', id: 7 }, { name: 'Johnson33', id: 33 }],
        },
      ],
    }
  },
  mounted() {
    this.myclick()
  },
  methods: {
    myclick: function() {
      let cc = 100
      setInterval(function() {
        cc = cc + 100
        document.getElementsByClassName('child')[0].style.transform = `translate(${cc}px)`
      }, 3000)
    },
    add: function() {
      this.list.push({ name: 'Juan' })
    },
    replace: function() {
      this.list = [{ name: 'Edgard' }]
    },
    clone: function(el) {
      return {
        name: el.name + ' cloned',
      }
    },
    log: function(evt) {
      window.console.log(evt)
      return false
    },
  },
}
</script>
<style scoped></style>
