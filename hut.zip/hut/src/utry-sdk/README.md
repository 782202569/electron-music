# 文档原型

```
├── common // 公用方法
│   ├── constants // 表单验证规则
├── components // components组件
├── filters // 过滤器

```



