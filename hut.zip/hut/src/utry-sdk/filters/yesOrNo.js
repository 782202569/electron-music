// 审核状态
export default function(type) {
  return type == 0 ? '否' : '是'
}
