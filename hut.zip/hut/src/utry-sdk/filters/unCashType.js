// 记录类型 充值 or 提现
export default function(type) {
  return type == 1 ? '充值' : '提现'
}
