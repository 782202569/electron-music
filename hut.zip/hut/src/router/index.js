import Vue from 'vue'
import Router from 'vue-router'
import funcFilter from '@/utils/funcFilter.js'
import Cookie from 'vue-cookie'
Vue.use(Router)

const routes = [
  {
    path: '/',
    redirect: '/login',
  },
  {
    path: '/login',
    component: (resolve) => require(['../components/common/Login.vue'], resolve),
  },
  {
    name: 'home页面',
    path: '/home',
    meta: { checkPermission: false },
    component: (resolve) => require(['../components/common/Home.vue'], resolve),
    children: [
      {
        name: '首页',
        path: '/homepage', // 首页界面
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/home/HomePage.vue'], resolve),
      },
      {
        name: '快速筛选',
        path: '/integratedSearchHr', // 快速筛选
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/quickInquiry/Quick.vue'], resolve),
      },
      {
        name: '智能筛选',
        path: '/systemFilterIncoming', //
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/intelligent/Intelligent.vue'], resolve),
      },
      {
        name: '循环任务结果',
        path: '/loopTask_result', //
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/intelligent/loopTaskResult.vue'], resolve),
      },
      {
        name: '任务结果',
        path: '/task_result', //
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/intelligent/taskResult.vue'], resolve),
      },
      {
        name: '语音特征筛选',
        path: '/speechFeatureStats', // 语音特征分析
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/soundFeature/Soundfeature.vue'], resolve),
      },
      {
        name: '热点分析',
        path: '/hotAnalyse', // 热点分析
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/hotAnalyse/Hotanalyse.vue'], resolve),
      },
      {
        name: '智能筛选模板',
        path: '/clusterModelIndexHr', // 模板管理
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/template/Ietemplate.vue'], resolve),
      },
      {
        name: '主题聚类',
        path: '/clusterRule_hrlist', // 主题聚类
        meta: { checkPermission: true },
        // component: resolve => require(['../components/page/topic/topic.vue'], resolve)
        component: (resolve) =>
          require(['../components/page/topic/clusterTrain.vue'], resolve),
      },
      {
        name: '添加训练样本',
        path: '/addTrainSample',
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/topic/addTrainSample.vue'], resolve),
      },
      {
        name: '新增聚类',
        path: '/newPage', // 聚类管理
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/topic/newPage.vue'], resolve),
      },
      {
        name: '执行结果',
        path: '/result', // 聚类管理
        meta: { checkPermission: false },
        component: (resolve) => require(['../components/page/topic/result.vue'], resolve),
      },
      {
        name: '启用词表',
        path: '/enableThesaurus', // 聚类管理
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/topic/enableThesaurus.vue'], resolve),
      },
      {
        name: '标签管理',
        path: '/tagManager', // 标签管理
        // meta: {checkPermission: true},
        component: (resolve) =>
          require(['../components/page/tagManager/tagManage.vue'], resolve),
      },
      {
        path: '/slice',
        component: (resolve) => require(['../components/common/Slice.vue'], resolve),
      },
      {
        name: '质检评分模板',
        path: '/manalScoreModel_new', // 质检评分模板
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/business/manalScoreModel_new.vue'], resolve),
      },
      {
        name: '质检评分模板(订单)',
        path: '/manalScoreOrderModel_new', // 质检评分模板
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/business/manalScoreOrderModel_new.vue'], resolve),
      },
      // {
      //   name: '系统自动评分',
      //   path: '/sysAutoScoringInCall', // 系统自动评分
      //   meta: {checkPermission: true},
      //   component: resolve => require(['../components/page/quality/sysAutoScoringInCall.vue'], resolve)
      // },
      // {
      //   name: '系统自动评分结果',
      //   path: '/sysAutoScoringInCallResult', // 系统自动评分结果
      //   meta: {checkPermission: false},
      //   component: resolve => require(['../components/page/quality/sysAutoScoringInCallResult.vue'], resolve)
      // },
      // {
      //   name: 'detailCell',
      //   path: '/sysGetback', // 系统自动评分结果详情页
      //   meta: {checkPermission: false},
      //   component: resolve => require(['../components/page/quality/getbackPage.vue'], resolve)
      // },
      {
        name: '系统自动评分（订单)',
        path: '/sysAutoScoringInCallOrder', // 系统自动评分
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/quality/sysAutoScoringInCallOrder.vue'], resolve),
      },
      {
        name: '系统自动评分结果(订单)',
        path: '/sysAutoScoringInCallOrderResult', // 系统自动评分结果
        meta: { checkPermission: false },
        component: (resolve) =>
          require([
            '../components/page/quality/sysAutoScoringInCallOrderResult.vue',
          ], resolve),
      },
      {
        name: '词库管理',
        path: '/vocabulary_new', // 词库管理
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/businessConfig/vocabulary_new.vue'], resolve),
      },
      // {
      //   name: '质检抽样',
      //   path: '/taskList_new', // 质检抽样
      //   meta: {checkPermission: true},
      //   component: resolve => require(['../components/page/Aisample/Aisample.vue'], resolve)
      // },
      {
        name: '我的消息',
        path: '/my_message', // 我的消息
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/MessageManage/myMessage.vue'], resolve),
      },
      {
        name: '分析参数',
        path: '/analyse_new', // 分析配置
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/business/analyse_new.vue'], resolve),
      },
      // {
      //   name: '快速抽样',
      //   path: '/artificialSample', // 快速抽样
      //   meta: {checkPermission: true},
      //   component: resolve => require(['../components/page/RapidSampling/rapidSample.vue'], resolve)
      // },
      {
        name: '案例管理',
        path: '/caseManage_new', // 案例管理
        meta: { checkPermission: true },
        // component: resolve => require(['../components/page/quality/caseManage_new.vue'], resolve)
        component: (resolve) =>
          require(['../components/page/quality/newManage.vue'], resolve),
      },
      {
        name: '案例管理(订单)',
        path: '/caseManage_order', // 案例管理
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/quality/caseManage_order.vue'], resolve),
      },
      {
        name: '申诉管理',
        path: '/IVSshensuguanli', // 申诉管理
        meta: { checkPermission: true },
        // component: resolve => require(['../components/page/quality/IVSshensuguanli.vue'], resolve)
        component: (resolve) =>
          require(['../components/page/score/complianAll.vue'], resolve),
      },
      {
        name: '我的质检任务',
        path: '/myQaTasks', // 我的质检任务
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/quality/myQaTasks.vue'], resolve),
      },
      {
        name: '我的质检任务(订单)',
        path: '/myQaTasksOrder', // 我的质检任务（订单）
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/quality/myQaTasksOrder.vue'], resolve),
      },
      // {
      //   name: '样本池',
      //   path: '/samplepoll', // 样本池
      //   meta: {checkPermission: true},
      //   component: resolve => require(['../components/page/samplepoll/samplepoll.vue'], resolve)
      // },
      {
        name: '案例查看',
        path: '/watchCase', // 查看案例
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/quality/watchCase.vue'], resolve),
      },
      {
        name: '交叉分析',
        path: '/crossAnalyse', // 交叉分析
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/crossAnalysis/crossAnalyse.vue'], resolve),
      },
      // {
      //   name: '质检任务监控',
      //   path: '/taskMonitor', // 质检任务监控
      //   meta: {checkPermission: true},
      //   component: resolve => require(['../components/page/taskMonitor/taskMonitor.vue'], resolve)
      // },
      {
        name: '质检任务监控（订单）',
        path: '/taskOrderMonitor', // 质检任务监控
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/taskMonitor/taskOrderMonitor.vue'], resolve),
      },
      // {
      //   name: '录音播放',
      //   path: '/recordingPlay', // 录音播放
      //   meta: {checkPermission: false},
      //   // component: resolve => require(['../components/page/recordingPlay/recordingPlay.vue'], resolve)
      //   component: resolve => require(['../components/page/recordingPlay/recordingPlayNew.vue'], resolve)
      // },
      {
        name: '订单录音播放',
        path: '/recordingPlayOrder', // 录音播放
        meta: { checkPermission: false },
        component: (resolve) =>
          require([
            '../components/page/recordingPlayOrder/recordingPlayOrder.vue',
          ], resolve),
      },
      // {
      //   name: '智能抽样',
      //   path: '/zhinengchouyang',  // 智能抽样
      //   meta: {checkPermission: false},
      //   component: resolve => require(['../components/page/intellSample/intellSample.vue'], resolve)
      // },
      {
        name: '算法树模式',
        path: '/algorithmTree', // 算法树模式
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/Analysis/algorithmTree.vue'], resolve),
      },
      {
        name: '聚类',
        path: '/themeClustering', // 算法树模式
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/Analysis/themeClustering.vue'], resolve),
      },
      // {
      //   name: '智能抽样结果',
      //   path: '/assignView',
      //   meta: {checkPermission: false},
      //   component: resolve => require(['../components/page/intellSample/viewIntTask.vue'], resolve)
      // },
      {
        name: '订单智能抽样',
        path: '/zhinengchouyang_order', // 智能抽样dingdan
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/intellSample/intellSampleOrder.vue'], resolve),
      },
      {
        name: '订单智能抽样结果',
        path: '/assignViewOrder',
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/intellSample/viewIntTaskOrder.vue'], resolve),
      },
      // {
      //   name: '复检抽样',
      //   path: '/reInspectionSampling', // 复检抽样
      //   meta: {checkPermission: true},
      //   component: resolve => require(['../components/page/Aisample/recheckSample.vue'], resolve)
      // },
      {
        name: '质检校准会',
        path: '/qaCalibration', // 质检校准会质检员页面
        meta: { checkPermission: true },
        // component: resolve => require(['../components/page/calibration/qaCalibration.vue'], resolve)
        component: (resolve) =>
          require(['../components/page/calibration/calibMeet.vue'], resolve),
      },
      {
        name: '质检校准会（订单）',
        path: '/qaCalibrationOrder', // 质检校准会质检员页面
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/calibration/qaCalibrationOrder.vue'], resolve),
      },
      // {
      //   name: '我的收藏',
      //   path: '/myColList',
      //   meta: {checkPermission: true},
      //   component: resolve => require(['../components/page/quality/myColList.vue'], resolve)
      // },
      {
        name: '质检成绩',
        path: '/scoreResultInfo', //
        meta: { checkPermission: false },
        // component: resolve => require(['../components/page/score/scoreResultInfo.vue'], resolve)
        component: (resolve) =>
          require(['../components/page/score/resultViewall.vue'], resolve),
      },
      {
        name: '质检结果查看(订单)',
        path: '/scoreResultInfoOrder', //
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/score/scoreResultInfoOrder.vue'], resolve),
      },
      {
        name: '回访话术模板',
        path: '/returnVisitTemplate',
        component: (resolve) =>
          require(['../components/page/returnvisit/returnvisittemplate.vue'], resolve),
      },
      {
        name: '回访话术配置',
        path: '/returnVisitConfig',
        component: (resolve) =>
          require(['../components/page/returnvisit/returnvisitconfig.vue'], resolve),
      },
      {
        name: '专题分析',
        meta: { checkPermission: false },
        path: '/thematicAnalysis',
        // component: resolve => require(['../components/page/thematicAnalysis/thematicAnalysis.vue'], resolve)
        component: (resolve) =>
          require(['../components/page/thematicAnalysis/thematicDraw.vue'], resolve),
      },
      {
        name: '专题分析内容',
        meta: { checkPermission: false },
        path: '/thematicAnalysisSub',
        component: (resolve) =>
          require([
            '../components/page/thematicAnalysis/thematicAnalysisSub.vue',
          ], resolve),
      },
      {
        name: '样本池(订单)',
        path: '/samplepollOrder', // 样本池
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/samplepoll/samplepollOrder.vue'], resolve),
      },
      {
        name: '快速抽样(订单)',
        path: '/rapidSampleOrder',
        component: (resolve) =>
          require(['../components/page/RapidSampling/rapidSampleOrder.vue'], resolve),
      },
      {
        name: '复检抽样(订单)',
        path: '/reInspectionSamplingOrder', // 复检抽样
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/Aisample/recheckSampleOrder.vue'], resolve),
      },
      {
        name: '录音标签',
        path: '/recordLabel',
        component: (resolve) =>
          require(['../components/page/recordLabel/recordLabel.vue'], resolve),
      },
      {
        name: '录音分类',
        path: '/audioClassification',
        component: (resolve) =>
          require(['../components/page/Analysis/audioClassification.vue'], resolve),
      },
      {
        name: '质检评分-拨打人',
        path: '/orderQualityScoreC',
        component: (resolve) =>
          require([
            '../components/page/recordingPlayOrder/play/orderInitalQualityScoreC.vue',
          ], resolve),
      },
      {
        name: '质检参数',
        path: '/qualityParams',
        component: (resolve) =>
          require(['../components/page/quality/QualityParams.vue'], resolve),
      },
      {
        name: '申诉流程配置',
        path: '/appealProcConfParam',
        component: (resolve) =>
          require(['../components/page/quality/AppealProcConfParam.vue'], resolve),
      },
      {
        name: '申诉管理（订单）',
        path: '/orderAppeal',
        component: (resolve) =>
          require(['../components/page/orderAppeal/orderAppeal.vue'], resolve),
      },
      {
        name: '质检任务',
        path: '/qaTask',
        component: (resolve) =>
          require(['../components/page/quality/qaTaskNew.vue'], resolve),
      },
      {
        name: '录音池',
        path: '/recordingpoll', // 录音池
        meta: { checkPermission: true },
        component: (resolve) =>
          require(['../components/page/samplepoll/recordingPoll.vue'], resolve),
      },
      {
        name: '任务完成情况统计',
        path: '/taskManage',
        component: (resolve) =>
          require(['../components/page/quality/taskManage.vue'], resolve),
      },
      {
        name: '公告发件箱',
        path: '/sendMessage', // 我的消息
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/MessageManage/sendMessage.vue'], resolve),
      },
      {
        name: '质检报表',
        path: '/QualityInspectionReport',
        meta: { checkPermission: false },
        component: (resolve) =>
          require([
            '../components/page/InspectionReport/QualityInspectionReport.vue',
          ], resolve),
      },
      {
        name: '我的质检成绩',
        path: '/resultViewmon', // 我的质检成绩
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/score/resultViewmon.vue'], resolve),
      },
      {
        name: '坐席报表',
        path: '/SeatReport',
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/InspectionReport/SeatReport.vue'], resolve),
      },
      {
        name: '业务报表',
        path: '/statisticalReports',
        meta: { checkPermission: false },
        component: (resolve) =>
          require([
            '../components/page/InspectionReport/statisticalReports.vue',
          ], resolve),
      },

      {
        name: '坐席首页',
        path: '/seatHome',
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/seatHome/seatHome.vue'], resolve),
      },
      {
        name: '业务分析',
        path: '/operationalAnalysis',
        meta: { checkPermission: false },
        component: (resolve) =>
          require([
            '../components/page/reportForms/operationalAnalysis/operationalIndex',
          ], resolve),
      },
      {
        name: '通话时长分析',
        path: '/callDurationAnalysis',
        meta: { checkPermission: false },
        component: (resolve) =>
          require([
            '../components/page/reportForms/callDurationAnalysis/callDurationIndex',
          ], resolve),
      },
      {
        name: '重复来电分析',
        path: '/repeatedCallAnalysis',
        meta: { checkPermission: false },
        component: (resolve) =>
          require(['../components/page/Analysis/repeatedCall'], resolve),
      },
      {
        name: '质差分析',
        path: '/qualityAnalysis',
        meta: { checkPermission: false },
        component: (resolve) => require(['../components/page/Analysis/quality'], resolve),
      },
      {
        name: '热词分析',
        path: '/hotwordAnalysis',
        meta: { checkPermission: false },
        component: (resolve) =>
          require([
            '../components/page/reportForms/hotwordAnalysis/hotwordIndex',
          ], resolve),
      },
    ],
  },
]

const router = new Router({
  routes,
})

router.beforeEach((to, from, next) => {
  if (to.path == '/login') {
    // 判断该路由是否需要登录权限
    next()
  } else {
    if (
      localStorage.getItem('tgt_id') &&
      ((to.meta.checkPermission &&
        localStorage.getItem('sliderMenu').indexOf(to.path.replace('/', '')) > -1) ||
        !to.meta.checkPermission) &&
      Cookie.get('userNameHead')
    ) {
      // 通过vuex state获取当前的token是否存在
      next()
    } else {
      next({
        path: '/',
        query: { redirect: to.fullPath }, // 将跳转的路由path作为参数，登录成功后跳转到该路由
      })
    }
  }
})
// 解决刷新过滤按钮问题
router.afterEach((to, from, next) => {
  if (to.path == localStorage.getItem('routerPath')) {
    let menuId = localStorage.getItem('menuId')
    let path = to.path.replace('/', '')
    console.log('1111111')
    console.log(menuId)
    console.log(path)
    console.log('1111111')
    funcFilter(menuId, path)
  }
})
//funcFilter(localStorage.getItem('menuId'), localStorage.getItem('routerPath').replace('/', ''))
export default router
